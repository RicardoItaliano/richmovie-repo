# -*- coding: utf-8 -*-
# ============================================================================ #
# service.subtitles.richsubtitles
# service.py – hlavní entry point pro Kodi subtitle framework
# Součást RichMovie ekosystému | Richie | 2026
# ============================================================================ #

import os
import sys
import urllib.parse
import unicodedata
import shutil

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin


# ---------------------------------------------------------------------------- #
#  Addon globals
# ---------------------------------------------------------------------------- #

__addon__      = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__    = __addon__.getAddonInfo('version')

__cwd__        = xbmcvfs.translatePath(__addon__.getAddonInfo('path'))
__profile__    = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__temp__       = xbmcvfs.translatePath(os.path.join(__profile__, 'temp', ''))

sys.path.append(os.path.join(__cwd__, 'resources', 'lib'))

from titulky_client import TitulkyClient
from rs_utilities import log, extract_subtitles


# ---------------------------------------------------------------------------- #
#  Search – hledání titulků na titulky.com
# ---------------------------------------------------------------------------- #

def Search(item):
    """Vyhledá titulky a přidá výsledky do Kodi subtitle dialogu."""

    cli = TitulkyClient()
    found_subtitles = cli.search(item)

    if not found_subtitles:
        return

    for sub in found_subtitles:
        listitem = xbmcgui.ListItem(
            label=sub['lang'],
            label2=sub['filename']
        )
        listitem.setArt({
            'icon': str(sub['rating']),
            'thumb': sub['lang_flag']
        })
        listitem.setProperty('sync', 'true' if sub['sync'] else 'false')
        listitem.setProperty('hearing_imp', 'false')

        url = "plugin://%s/?action=download&id=%s&lang=%s&link_file=%s" % (
            __scriptid__,
            sub['id'],
            sub['lang'],
            urllib.parse.quote(sub['link_file'])
        )
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=url,
            listitem=listitem,
            isFolder=False
        )


# ---------------------------------------------------------------------------- #
#  Download – stažení vybraných titulků
# ---------------------------------------------------------------------------- #

def Download(sub_id, link_file):
    """Přihlásí se premium účtem, stáhne ZIP, rozbalí a vrátí seznam .srt."""

    # Vyčistit temp
    if xbmcvfs.exists(__temp__):
        shutil.rmtree(__temp__)
    xbmcvfs.mkdirs(__temp__)

    cli = TitulkyClient()

    # Login premium účtem
    if not cli.login():
        log("Login na titulky.com selhal")
        xbmcgui.Dialog().notification(
            __scriptname__,
            "Přihlášení selhalo",
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )
        return []

    # Stáhnout ZIP
    downloaded_file = cli.download(sub_id, link_file, __temp__)
    if downloaded_file is None:
        xbmcgui.Dialog().notification(
            __scriptname__,
            "Titulky se nepodařilo stáhnout",
            xbmcgui.NOTIFICATION_WARNING,
            3000
        )
        return []

    # Rozbalit a najít subtitle soubory
    subtitle_list = extract_subtitles(downloaded_file)
    log("Extrahované titulky: %s" % subtitle_list)

    if subtitle_list:
        xbmcgui.Dialog().notification(
            __scriptname__,
            "Titulky staženy ✓",
            xbmcgui.NOTIFICATION_INFO,
            2000
        )

    return subtitle_list


# ---------------------------------------------------------------------------- #
#  Helpers
# ---------------------------------------------------------------------------- #

def normalizeString(s):
    return unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('utf-8')


def get_params():
    """Parsuje URL parametry z sys.argv[2]."""
    params = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        cleaned = paramstring.lstrip('?').rstrip('/')
        for pair in cleaned.split('&'):
            parts = pair.split('=', 1)
            if len(parts) == 2:
                params[parts[0]] = parts[1]
    return params


# ---------------------------------------------------------------------------- #
#  Main
# ---------------------------------------------------------------------------- #

params = get_params()
action = params.get('action', '')

if action in ('search', 'manualsearch'):

    item = {
        'temp':               False,
        'rar':                False,
        'mansearch':          False,
        'year':               xbmc.getInfoLabel("VideoPlayer.Year"),
        'season':             str(xbmc.getInfoLabel("VideoPlayer.Season")),
        'episode':            str(xbmc.getInfoLabel("VideoPlayer.Episode")),
        'tvshow':             normalizeString(xbmc.getInfoLabel("VideoPlayer.TVshowtitle")),
        'title':              normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle")),
        'file_original_path': urllib.parse.unquote(xbmc.Player().getPlayingFile()),
        '3let_language':      [],
    }

    # Manuální vyhledávání
    if 'searchstring' in params:
        item['mansearch'] = True
        item['mansearchstr'] = urllib.parse.unquote(params['searchstring'])

    # Jazyky
    if 'languages' in params:
        for lang in urllib.parse.unquote(params['languages']).split(','):
            item['3let_language'].append(xbmc.convertLanguage(lang, xbmc.ISO_639_2))

    # Fallback title
    if not item['title']:
        item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.Title"))

    # Speciální epizoda
    if item['episode'].lower().find('s') > -1:
        item['season'] = '0'
        item['episode'] = item['episode'][-1:]

    # Detekce zdroje
    if item['file_original_path'].find('http') > -1:
        item['temp'] = True
    elif item['file_original_path'].find('rar://') > -1:
        item['rar'] = True
        item['file_original_path'] = os.path.dirname(item['file_original_path'][6:])
    elif item['file_original_path'].find('stack://') > -1:
        item['file_original_path'] = item['file_original_path'].split(' , ')[0][8:]

    log("Input: %s" % item)
    Search(item)


elif action == 'download':

    subs = Download(
        params['id'],
        urllib.parse.unquote(params.get('link_file', ''))
    )
    for sub in subs:
        listitem = xbmcgui.ListItem(label=sub)
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=sub,
            listitem=listitem,
            isFolder=False
        )


xbmcplugin.endOfDirectory(int(sys.argv[1]))
