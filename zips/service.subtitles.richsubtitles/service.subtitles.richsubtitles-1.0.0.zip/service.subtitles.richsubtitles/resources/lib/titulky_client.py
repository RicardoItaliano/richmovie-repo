# -*- coding: utf-8 -*-
# ============================================================================ #
# service.subtitles.richsubtitles
# resources/lib/titulky_client.py – klient pro titulky.com API (HTML scraping)
# Vyčištěná verze bez captcha, stats, extra_commands
# Premium účet = žádná captcha, žádný/minimální countdown
# Richie | 2026
# ============================================================================ #

import re
import os
import time
import calendar
import html
import http.cookiejar as cookielib
import urllib.parse
import urllib.request
from io import BytesIO
import gzip

import xbmc
import xbmcvfs
import xbmcgui

from rs_utilities import log, get_file_size


# ---------------------------------------------------------------------------- #
#  Hardcoded premium credentials
# ---------------------------------------------------------------------------- #

_USERNAME = "richmovie"
_PASSWORD = "15*HurkA*09"

_SERVER   = "https://www.titulky.com"


class TitulkyClient:
    """Klient pro vyhledávání a stahování titulků z titulky.com."""


    # ---------------------------------- INIT -------------------------------- #

    def __init__(self):
        self.server_url = _SERVER
        self.cookies = {}

        # Nastavit cookie handler pro urllib
        opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(cookielib.LWPCookieJar())
        )
        opener.addheaders = [
            ('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21'),
            ('Accept-Language', 'cs,en;q=0.9'),
        ]
        urllib.request.install_opener(opener)


    # ----------------------------------------------------------------------- #
    #  LOGIN
    # ----------------------------------------------------------------------- #

    def login(self):
        """
        Přihlášení premium účtem na titulky.com.
        Returns True při úspěchu, False při selhání.
        """
        log("Přihlašuji se na titulky.com jako '%s'" % _USERNAME)

        if not _USERNAME:
            return False

        post_data = urllib.parse.urlencode({
            'Login':      _USERNAME,
            'Password':   _PASSWORD,
            'foreverlog': '0',
            'Detail2':    ''
        }).encode('utf-8')

        request = urllib.request.Request(self.server_url + '/index.php', post_data)
        request.add_header('Origin', self.server_url)

        try:
            response = urllib.request.urlopen(request, timeout=15)
            content = self._read_response(response)
        except Exception as e:
            log("Login HTTP chyba: %s" % e)
            return False

        if 'BadLogin' in content:
            log("Login selhal – špatné přihlašovací údaje")
            return False

        # Uložit cookies
        try:
            cookie_header = response.getheader('Set-Cookie') or ''
            crc = re.search(r'CRC=(\S+);', cookie_header, re.IGNORECASE)
            login_name = re.search(r'LogonLogin=(\S+);', cookie_header, re.IGNORECASE)
            login_id = re.search(r'LogonId=(\S+);', cookie_header, re.IGNORECASE)

            if crc:
                self.cookies['CRC'] = crc.group(1)
            if login_name:
                self.cookies['LogonLogin'] = login_name.group(1)
            if login_id:
                self.cookies['LogonId'] = login_id.group(1)
        except Exception as e:
            log("Chyba při parsování cookies: %s" % e)
            return False

        log("Login úspěšný, cookies uloženy")
        return True


    # ----------------------------------------------------------------------- #
    #  SEARCH
    # ----------------------------------------------------------------------- #

    def search(self, item):
        """
        Vyhledá titulky podle metadata z Kodi.
        Vrací list dictů připravených pro service.py → Kodi subtitle dialog.
        """
        # Sestavit search query
        if item.get('mansearch'):
            title = item['mansearchstr']
        elif item.get('tvshow'):
            title = "%s S%02dE%02d" % (
                self._normalize_title(item['tvshow']),
                int(item['season']),
                int(item['episode'])
            )
        else:
            title = item.get('title', '')
            if not item.get('year'):
                title = xbmc.getCleanMovieTitle(title)[0]
            title = self._normalize_title(title)

        log("Search pattern: '%s'" % title)

        # HTTP search
        raw_subtitles = self._search_http(title)
        log("Nalezeno %d titulků" % len(raw_subtitles))

        if not raw_subtitles:
            return None

        # Žádný jazykový filtr – titulky.com má POUZE CZ/SK,
        # filtrovat je nesmysl a způsobuje problémy když uživatel
        # nemá v Kodi nastavené CZ/SK subtitle languages
        filtered = raw_subtitles

        # Detekce velikosti souboru pro sync matching
        file_size = get_file_size(item.get('file_original_path', ''), item.get('rar', False))
        if file_size != -1:
            file_size = round(float(file_size) / (1024 * 1024), 2)

        # Maximální počet stažení (pro rating normalizaci)
        max_down = max((s['down_count'] for s in filtered), default=1)

        # Sestavit výstup
        result = []
        for sub in filtered:
            filename = sub.get('version') or sub.get('title', '')
            if sub.get('author'):
                filename += " by " + sub['author']

            result.append({
                'filename':  html.unescape(filename),
                'link_file': sub['link_file'],
                'id':        sub['id'],
                'lang':      sub['lang'],
                'rating':    int(sub['down_count'] * 5 / max_down) if max_down > 0 else 0,
                'sync':      (sub.get('size') == file_size and file_size > 0),
                'lang_flag': xbmc.convertLanguage(sub['lang'], xbmc.ISO_639_1),
            })

        log("Výsledek: %d titulků" % len(result))
        return result


    # ----------------------------------------------------------------------- #
    #  DOWNLOAD
    # ----------------------------------------------------------------------- #

    def download(self, sub_id, link_file, dest_dir):
        """
        Stáhne titulky jako ZIP do dest_dir.
        Premium účet = žádná captcha, minimální/žádný countdown.
        Vrací cestu k ZIP souboru nebo None.
        """
        dest = os.path.join(dest_dir, "subtitles.zip")

        # Otevřít download stránku
        content = self._get_download_page(sub_id, link_file)
        if content is None:
            return None

        # Počkat countdown (premium má typicky 0)
        wait_time = self._parse_countdown(content)
        if wait_time > 0:
            log("Čekám %d sekund (countdown)" % wait_time)
            for i in range(wait_time):
                xbmcgui.Dialog().notification(
                    "RichSubtitles",
                    "Stahování za %d s..." % (wait_time - i),
                    xbmcgui.NOTIFICATION_INFO,
                    1000
                )
                time.sleep(1)

        # Získat finální download link
        download_link = self._parse_download_link(content)
        if not download_link:
            log("Nenalezen download link")
            return None

        log("Stahuji titulky z: %s" % download_link)

        # Stáhnout soubor
        try:
            data = self._http_get_binary(
                download_link,
                referer=self.server_url + '/idown.php'
            )
        except Exception as e:
            log("Chyba při stahování: %s" % e)
            return None

        # Uložit ZIP
        try:
            with open(dest, 'wb') as f:
                f.write(data)
            log("ZIP uložen: %s" % dest)
            return dest
        except Exception as e:
            log("Chyba při ukládání: %s" % e)
            return None


    # ----------------------------------------------------------------------- #
    #  PRIVATE – HTTP
    # ----------------------------------------------------------------------- #

    def _search_http(self, title):
        """Pošle search request a parsuje HTML výsledky."""
        url = self.server_url + '/index.php?' + urllib.parse.urlencode({
            'Fulltext': title,
            'FindUser': ''
        })
        log("HTTP GET: %s" % url)

        try:
            req = urllib.request.Request(url)
            response = urllib.request.urlopen(req, timeout=15)
            content = self._read_response(response)
        except Exception as e:
            log("Search HTTP chyba: %s" % e)
            return []

        return self._parse_search_results(content)


    def _get_download_page(self, sub_id, link_file):
        """Otevře download stránku (idown.php) s cookies."""
        url = self.server_url + '/idown.php?' + urllib.parse.urlencode({
            'R':         str(calendar.timegm(time.gmtime())),
            'titulky':   sub_id,
            'histstamp': '',
            'zip':       'z'
        })
        log("Download page: %s" % url)

        referer = self.server_url + '/' + link_file + '.htm'

        try:
            req = urllib.request.Request(url)
            self._add_cookies(req)
            req.add_header('Referer', referer)
            response = urllib.request.urlopen(req, timeout=15)
            return self._read_response(response)
        except Exception as e:
            log("Download page chyba: %s" % e)
            return None


    def _http_get_binary(self, url, referer=None):
        """Stáhne binární obsah (ZIP) s cookies."""
        req = urllib.request.Request(url)
        self._add_cookies(req)
        if referer:
            req.add_header('Referer', referer)

        response = urllib.request.urlopen(req, timeout=30)

        # Aktualizovat PHPSESSID pokud přijde
        cookie_header = response.getheader('Set-Cookie') or ''
        m = re.search(r'PHPSESSID=(\S+);', cookie_header, re.IGNORECASE)
        if m:
            self.cookies['PHPSESSID'] = m.group(1)

        return response.read()


    def _add_cookies(self, request):
        """Přidá uložené cookies do HTTP requestu."""
        if self.cookies:
            cookie_str = '; '.join(
                "%s=%s" % (k, v) for k, v in self.cookies.items()
            )
            request.add_header('Cookie', cookie_str)


    def _read_response(self, response):
        """Přečte HTTP response, dekomprimuje gzip pokud potřeba."""
        content = response.read()
        response.close()

        if response.getheader('Content-Encoding') == 'gzip':
            buf = BytesIO(content)
            content = gzip.GzipFile(fileobj=buf).read()

        content_type = response.getheader('Content-Type') or ''
        if content_type.startswith('text/'):
            content = content.decode('utf-8', errors='replace')

        return content


    # ----------------------------------------------------------------------- #
    #  PRIVATE – parsování HTML
    # ----------------------------------------------------------------------- #

    def _parse_search_results(self, content):
        """Parsuje tabulku výsledků z HTML stránky titulky.com."""
        subtitles = []

        for row in re.finditer(r'<tr class="r(.+?)</tr>', content, re.IGNORECASE | re.DOTALL):
            try:
                data = row.group(1)
                sub = {}

                # Link a ID
                m = re.search(r'<td[^<]+<a href="(?P<link>\S+)\.htm"', data, re.IGNORECASE | re.DOTALL)
                if not m:
                    continue
                sub['link_file'] = m.group('link')

                m = re.search(r'<a href="[\w-]+-(?P<id>\d+)\.htm"', data, re.IGNORECASE | re.DOTALL)
                if not m:
                    continue
                sub['id'] = m.group('id')

                # Název
                m = re.search(r'<td[^<]+<a[^>]+>(<div[^>]+>)?(?P<title>[^<]+)', data, re.IGNORECASE | re.DOTALL)
                sub['title'] = m.group('title') if m else ''

                # Verze (release name)
                try:
                    m = re.search(r'((.+?)</td>)[^>]+>[^<]*<a(.+?)title="(?P<ver>[^"]+)"', data, re.IGNORECASE | re.DOTALL)
                    sub['version'] = m.group('ver') if m else None
                except Exception:
                    sub['version'] = None

                # Počet stažení
                try:
                    m = re.search(r'((.+?)</td>){4}[^>]+>(?P<cnt>[^<]+)', data, re.IGNORECASE | re.DOTALL)
                    sub['down_count'] = int(m.group('cnt')) if m else 0
                except Exception:
                    sub['down_count'] = 0

                # Jazyk
                try:
                    m = re.search(r'((.+?)</td>){5}[^>]+><img alt="(?P<lang>\w{2})"', data, re.IGNORECASE | re.DOTALL)
                    if not m:
                        continue
                    lang = m.group('lang')
                    sub['lang'] = 'Czech' if lang == 'CZ' else ('Slovak' if lang == 'SK' else lang)
                except Exception:
                    continue

                # Velikost (MB)
                try:
                    m = re.search(r'((.+?)</td>){7}[^>]+>(?P<size>[\d.]+)', data, re.IGNORECASE | re.DOTALL)
                    sub['size'] = float(m.group('size')) if m else None
                except Exception:
                    sub['size'] = None

                # Autor
                try:
                    m = re.search(r'((.+?)</td>){8}[^>]+>[^>]+<a href[^>]+>(?P<author>[^<]+)', data, re.IGNORECASE | re.DOTALL | re.MULTILINE)
                    sub['author'] = m.group('author').strip() if m else None
                except Exception:
                    sub['author'] = None

                subtitles.append(sub)

            except Exception as e:
                log("Chyba při parsování řádku: %s" % e)
                continue

        return subtitles


    def _parse_countdown(self, content):
        """Parsuje CountDown(X) z download stránky."""
        m = re.search(r'CountDown\((\d+)\)', content, re.IGNORECASE)
        return int(m.group(1)) if m else 0


    def _parse_download_link(self, content):
        """Parsuje finální download link z download stránky."""
        m = re.search(r'<a.+id="downlink"\s+href="([^"]+)"', content, re.IGNORECASE | re.DOTALL)
        return (self.server_url + m.group(1)) if m else None


    # ----------------------------------------------------------------------- #
    #  PRIVATE – helpers
    # ----------------------------------------------------------------------- #

    def _normalize_title(self, title):
        """Normalizace názvu pro lepší search výsledky."""
        # "Movie, The" → "The Movie"
        if re.search(r', The$', title, re.IGNORECASE):
            title = "The " + re.sub(r'(?i), The$', '', title)

        # Odstranit závorky: [xy] a (xy) – pokud to není rok
        title = re.sub(r"(\[|\().+?(\]|\))", "", title)

        return title.strip()


    def _filter_by_language(self, set_languages, subtitles):
        """Filtruje titulky podle požadovaných jazyků."""
        if not set_languages:
            return subtitles

        filtered = []
        for sub in subtitles:
            lang_code = xbmc.convertLanguage(sub['lang'], xbmc.ISO_639_2)
            if lang_code in set_languages:
                filtered.append(sub)

        if not filtered:
            # Pokud uživatel nemá nastavené CZ/SK, upozornit
            if 'cze' not in set_languages and 'slo' not in set_languages:
                log("Žádné titulky – uživatel nemá nastavené CZ/SK jazyky")
            return None

        return filtered
