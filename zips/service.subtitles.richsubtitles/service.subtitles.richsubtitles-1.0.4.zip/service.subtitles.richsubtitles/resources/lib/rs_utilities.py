# -*- coding: utf-8 -*-
# ============================================================================ #
# service.subtitles.richsubtitles
# resources/lib/rs_utilities.py – pomocné funkce
# Richie | 2026
# ============================================================================ #

import os
import zipfile

import xbmc
import xbmcvfs


# ---------------------------------------------------------------------------- #
#  Logging
# ---------------------------------------------------------------------------- #

def log(msg, level=xbmc.LOGINFO):
    """Loguje zprávu do Kodi logu s prefixem [RichSubtitles]."""
    xbmc.log("[RichSubtitles] %s" % msg, level=level)


# ---------------------------------------------------------------------------- #
#  File helpers
# ---------------------------------------------------------------------------- #

# Podporované přípony titulků
SUBTITLE_EXTENSIONS = ('.srt', '.sub', '.txt', '.smi', '.ssa', '.ass')


def get_file_size(file_path, is_rar=False):
    """
    Vrací velikost souboru v bytech.
    -1 pokud nelze zjistit (stream, RAR, atd.).
    """
    if not file_path:
        return -1

    # HTTP streamy nemají lokální velikost
    if file_path.startswith('http'):
        return -1

    # RAR archivy – nespolehlivé
    if is_rar:
        return -1

    try:
        if xbmcvfs.exists(file_path):
            stat = xbmcvfs.Stat(file_path)
            return stat.st_size()
    except Exception:
        pass

    return -1


def extract_subtitles(zip_path):
    """
    Rozbalí ZIP archiv a vrátí seznam cest k nalezeným subtitle souborům.
    """
    if not zip_path or not os.path.exists(zip_path):
        log("ZIP neexistuje: %s" % zip_path)
        return []

    extract_dir = os.path.dirname(zip_path)
    subtitle_files = []

    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            for name in zf.namelist():
                # Přeskočit adresáře a skryté soubory
                if name.endswith('/') or name.startswith('.') or name.startswith('__'):
                    continue

                _, ext = os.path.splitext(name.lower())
                if ext in SUBTITLE_EXTENSIONS:
                    # Rozbalit do temp adresáře (flat, bez podadresářů)
                    safe_name = os.path.basename(name)
                    dest_path = os.path.join(extract_dir, safe_name)

                    with zf.open(name) as src, open(dest_path, 'wb') as dst:
                        dst.write(src.read())

                    subtitle_files.append(dest_path)
                    log("Extrahován: %s" % safe_name)

    except zipfile.BadZipFile:
        log("Poškozený ZIP: %s" % zip_path)
    except Exception as e:
        log("Chyba při extrakci: %s" % e)

    return subtitle_files
