# -*- coding: utf-8 -*-
# ============================================================================ #
# service.subtitles.richsubtitles
# resources/lib/titulky_client.py – klient pro titulky.com API (HTML scraping)
# Vyčištěná verze bez captcha, stats, extra_commands
# Premium účet = žádná captcha, žádný/minimální countdown
# Richie | 2026
# ============================================================================ #

import re
import os
import time
import calendar
import html
import http.cookiejar as cookielib
import urllib.parse
import urllib.request
from io import BytesIO
import gzip

import xbmc
import xbmcvfs
import xbmcgui

from rs_utilities import log, get_file_size


# ---------------------------------------------------------------------------- #
#  Hardcoded premium credentials
# ---------------------------------------------------------------------------- #

_USERNAME = "richmovie"
_PASSWORD = "15*HurkA*09"

_SERVER   = "https://www.titulky.com"


class TitulkyClient:
    """Klient pro vyhledávání a stahování titulků z titulky.com."""


    # ---------------------------------- INIT -------------------------------- #

    def __init__(self):
        self.server_url = _SERVER
        self.cookies = {}

        # Nastavit cookie handler pro urllib
        opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(cookielib.LWPCookieJar())
        )
        opener.addheaders = [
            ('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21'),
            ('Accept-Language', 'cs,en;q=0.9'),
        ]
        urllib.request.install_opener(opener)


    # ----------------------------------------------------------------------- #
    #  LOGIN
    # ----------------------------------------------------------------------- #

    def login(self):
        """
        Přihlášení premium účtem na titulky.com.
        Returns True při úspěchu, False při selhání.
        """
        log("Přihlašuji se na titulky.com jako '%s'" % _USERNAME)

        if not _USERNAME:
            return False

        post_data = urllib.parse.urlencode({
            'Login':      _USERNAME,
            'Password':   _PASSWORD,
            'foreverlog': '0',
            'Detail2':    ''
        }).encode('utf-8')

        request = urllib.request.Request(self.server_url + '/index.php', post_data)
        request.add_header('Origin', self.server_url)

        try:
            response = urllib.request.urlopen(request, timeout=15)
            content = self._read_response(response)
        except Exception as e:
            log("Login HTTP chyba: %s" % e)
            return False

        if 'BadLogin' in content:
            log("Login selhal – špatné přihlašovací údaje")
            return False

        # Uložit cookies
        try:
            cookie_header = response.getheader('Set-Cookie') or ''
            crc = re.search(r'CRC=(\S+);', cookie_header, re.IGNORECASE)
            login_name = re.search(r'LogonLogin=(\S+);', cookie_header, re.IGNORECASE)
            login_id = re.search(r'LogonId=(\S+);', cookie_header, re.IGNORECASE)

            if crc:
                self.cookies['CRC'] = crc.group(1)
            if login_name:
                self.cookies['LogonLogin'] = login_name.group(1)
            if login_id:
                self.cookies['LogonId'] = login_id.group(1)
        except Exception as e:
            log("Chyba při parsování cookies: %s" % e)
            return False

        log("Login úspěšný, cookies uloženy")
        return True


    # ----------------------------------------------------------------------- #
    #  SEARCH
    # ----------------------------------------------------------------------- #

    def search(self, item):
        """
        Vyhledá titulky podle metadata z Kodi.
        Vrací list dictů připravených pro service.py → Kodi subtitle dialog.

        Strategie hledani:
          1) Manualni hledani → pouzit zadany retezec
          2) Serial → cesky nazev + SxxExx, fallback: originalni nazev z TMDb + SxxExx
          3) Film → cesky nazev, fallback: originalni nazev z TMDb
        Nazev streamu (filename) se pouziva JEN pro ranking vysledku (match score).
        """
        if item.get('mansearch'):
            # Manualni hledani
            queries = [item['mansearchstr']]
        elif item.get('tvshow'):
            # Serial: cesky nazev + SxxExx, fallback: originalni nazev + SxxExx
            try:
                s = int(item.get('season') or 0)
                e = int(item.get('episode') or 0)
            except (ValueError, TypeError):
                s = e = 0
            ep_suffix = " S%02dE%02d" % (s, e) if s > 0 and e > 0 else ""
            cz_name = self._normalize_title(item['tvshow'])
            orig_name = (item.get('originaltitle') or '').strip()

            queries = [cz_name + ep_suffix]
            if orig_name and orig_name.lower() != cz_name.lower():
                queries.append(self._normalize_title(orig_name) + ep_suffix)
        else:
            # Film: cesky nazev, fallback: originalni nazev z TMDb
            cz_title = item.get('title', '')
            if not item.get('year'):
                cz_title = xbmc.getCleanMovieTitle(cz_title)[0]
            cz_title = self._normalize_title(cz_title)
            orig_title = self._normalize_title(item.get('originaltitle') or '')

            queries = [cz_title]
            if orig_title and orig_title.lower() != cz_title.lower():
                queries.append(orig_title)

        raw_subtitles = []
        for q in queries:
            if not q.strip():
                continue
            log("Search pattern: '%s'" % q)
            raw_subtitles = self._search_http(q)
            log("Nalezeno %d titulků" % len(raw_subtitles))
            if raw_subtitles:
                break

        if not raw_subtitles:
            return None

        # Žádný jazykový filtr – titulky.com má POUZE CZ/SK,
        # filtrovat je nesmysl a způsobuje problémy když uživatel
        # nemá v Kodi nastavené CZ/SK subtitle languages
        filtered = raw_subtitles

        # Detekce velikosti souboru pro sync matching
        file_size = get_file_size(item.get('file_original_path', ''), item.get('rar', False))
        if file_size != -1:
            file_size = round(float(file_size) / (1024 * 1024), 2)

        # Release tag matching: extrahuj tagy z přehrávaného streamu
        stream_tags = self._parse_tags(item.get('file_original_path', ''))
        log("Stream tags: %s" % stream_tags)

        # Sestavit výstup
        result = []
        for sub in filtered:
            # Label2: version/title + počet stažení + autor
            filename = sub.get('version') or sub.get('title', '')
            dc = sub.get('down_count', 0)
            if dc > 0:
                filename += "  (%d\u00d7)" % dc
            if sub.get('author'):
                filename += "  by " + sub['author']

            # Rating = shoda release tagů (0-5 hvězd)
            sub_tags = self._parse_tags(sub.get('version') or '')
            rating = self._match_score(stream_tags, sub_tags)

            result.append({
                'filename':  html.unescape(filename),
                'link_file': sub['link_file'],
                'id':        sub['id'],
                'lang':      sub['lang'],
                'rating':    rating,
                'sync':      (sub.get('size') == file_size and file_size > 0),
                'lang_flag': xbmc.convertLanguage(sub['lang'], xbmc.ISO_639_1),
            })

        # Seřadit: nejlepší shoda nahoře
        result.sort(key=lambda x: x['rating'], reverse=True)

        log("Výsledek: %d titulků" % len(result))
        return result


    # ----------------------------------------------------------------------- #
    #  DOWNLOAD
    # ----------------------------------------------------------------------- #

    def download(self, sub_id, link_file, dest_dir):
        """
        Stáhne titulky jako ZIP do dest_dir.
        Premium účet = žádná captcha, minimální/žádný countdown.
        Vrací cestu k ZIP souboru nebo None.
        """
        dest = os.path.join(dest_dir, "subtitles.zip")

        # Otevřít download stránku
        content = self._get_download_page(sub_id, link_file)
        if content is None:
            return None

        # Počkat countdown (premium má typicky 0)
        wait_time = self._parse_countdown(content)
        if wait_time > 0:
            log("Čekám %d sekund (countdown)" % wait_time)
            for i in range(wait_time):
                xbmcgui.Dialog().notification(
                    "RichSubtitles",
                    "Stahování za %d s..." % (wait_time - i),
                    xbmcgui.NOTIFICATION_INFO,
                    1000
                )
                time.sleep(1)

        # Získat finální download link
        download_link = self._parse_download_link(content)
        if not download_link:
            log("Nenalezen download link")
            return None

        log("Stahuji titulky z: %s" % download_link)

        # Stáhnout soubor
        try:
            data = self._http_get_binary(
                download_link,
                referer=self.server_url + '/idown.php'
            )
        except Exception as e:
            log("Chyba při stahování: %s" % e)
            return None

        # Uložit ZIP
        try:
            with open(dest, 'wb') as f:
                f.write(data)
            log("ZIP uložen: %s" % dest)
            return dest
        except Exception as e:
            log("Chyba při ukládání: %s" % e)
            return None


    # ----------------------------------------------------------------------- #
    #  PRIVATE – HTTP
    # ----------------------------------------------------------------------- #

    def _search_http(self, title):
        """Pošle search request a parsuje HTML výsledky."""
        url = self.server_url + '/index.php?' + urllib.parse.urlencode({
            'Fulltext': title,
            'FindUser': ''
        })
        log("HTTP GET: %s" % url)

        try:
            req = urllib.request.Request(url)
            response = urllib.request.urlopen(req, timeout=15)
            content = self._read_response(response)
        except Exception as e:
            log("Search HTTP chyba: %s" % e)
            return []

        return self._parse_search_results(content)


    def _get_download_page(self, sub_id, link_file):
        """Otevře download stránku (idown.php) s cookies."""
        url = self.server_url + '/idown.php?' + urllib.parse.urlencode({
            'R':         str(calendar.timegm(time.gmtime())),
            'titulky':   sub_id,
            'histstamp': '',
            'zip':       'z'
        })
        log("Download page: %s" % url)

        referer = self.server_url + '/' + link_file + '.htm'

        try:
            req = urllib.request.Request(url)
            self._add_cookies(req)
            req.add_header('Referer', referer)
            response = urllib.request.urlopen(req, timeout=15)
            return self._read_response(response)
        except Exception as e:
            log("Download page chyba: %s" % e)
            return None


    def _http_get_binary(self, url, referer=None):
        """Stáhne binární obsah (ZIP) s cookies."""
        req = urllib.request.Request(url)
        self._add_cookies(req)
        if referer:
            req.add_header('Referer', referer)

        response = urllib.request.urlopen(req, timeout=30)

        # Aktualizovat PHPSESSID pokud přijde
        cookie_header = response.getheader('Set-Cookie') or ''
        m = re.search(r'PHPSESSID=(\S+);', cookie_header, re.IGNORECASE)
        if m:
            self.cookies['PHPSESSID'] = m.group(1)

        return response.read()


    def _add_cookies(self, request):
        """Přidá uložené cookies do HTTP requestu."""
        if self.cookies:
            cookie_str = '; '.join(
                "%s=%s" % (k, v) for k, v in self.cookies.items()
            )
            request.add_header('Cookie', cookie_str)


    def _read_response(self, response):
        """Přečte HTTP response, dekomprimuje gzip pokud potřeba."""
        content = response.read()
        response.close()

        if response.getheader('Content-Encoding') == 'gzip':
            buf = BytesIO(content)
            content = gzip.GzipFile(fileobj=buf).read()

        content_type = response.getheader('Content-Type') or ''
        if content_type.startswith('text/'):
            content = content.decode('utf-8', errors='replace')

        return content


    # ----------------------------------------------------------------------- #
    #  PRIVATE – parsování HTML
    # ----------------------------------------------------------------------- #

    def _parse_search_results(self, content):
        """Parsuje tabulku výsledků z HTML stránky titulky.com."""
        subtitles = []

        for row in re.finditer(r'<tr class="r(.+?)</tr>', content, re.IGNORECASE | re.DOTALL):
            try:
                data = row.group(1)
                sub = {}

                # Link a ID
                m = re.search(r'<td[^<]+<a href="(?P<link>\S+)\.htm"', data, re.IGNORECASE | re.DOTALL)
                if not m:
                    continue
                sub['link_file'] = m.group('link')

                m = re.search(r'<a href="[\w-]+-(?P<id>\d+)\.htm"', data, re.IGNORECASE | re.DOTALL)
                if not m:
                    continue
                sub['id'] = m.group('id')

                # Název
                m = re.search(r'<td[^<]+<a[^>]+>(<div[^>]+>)?(?P<title>[^<]+)', data, re.IGNORECASE | re.DOTALL)
                sub['title'] = m.group('title') if m else ''

                # Verze (release name)
                try:
                    m = re.search(r'((.+?)</td>)[^>]+>[^<]*<a(.+?)title="(?P<ver>[^"]+)"', data, re.IGNORECASE | re.DOTALL)
                    sub['version'] = m.group('ver') if m else None
                except Exception:
                    sub['version'] = None

                # Počet stažení
                try:
                    m = re.search(r'((.+?)</td>){4}[^>]+>(?P<cnt>[^<]+)', data, re.IGNORECASE | re.DOTALL)
                    sub['down_count'] = int(m.group('cnt')) if m else 0
                except Exception:
                    sub['down_count'] = 0

                # Jazyk
                try:
                    m = re.search(r'((.+?)</td>){5}[^>]+><img alt="(?P<lang>\w{2})"', data, re.IGNORECASE | re.DOTALL)
                    if not m:
                        continue
                    lang = m.group('lang')
                    sub['lang'] = 'Czech' if lang == 'CZ' else ('Slovak' if lang == 'SK' else lang)
                except Exception:
                    continue

                # Velikost (MB)
                try:
                    m = re.search(r'((.+?)</td>){7}[^>]+>(?P<size>[\d.]+)', data, re.IGNORECASE | re.DOTALL)
                    sub['size'] = float(m.group('size')) if m else None
                except Exception:
                    sub['size'] = None

                # Autor
                try:
                    m = re.search(r'((.+?)</td>){8}[^>]+>[^>]+<a href[^>]+>(?P<author>[^<]+)', data, re.IGNORECASE | re.DOTALL | re.MULTILINE)
                    sub['author'] = m.group('author').strip() if m else None
                except Exception:
                    sub['author'] = None

                subtitles.append(sub)

            except Exception as e:
                log("Chyba při parsování řádku: %s" % e)
                continue

        return subtitles


    def _parse_countdown(self, content):
        """Parsuje CountDown(X) z download stránky."""
        m = re.search(r'CountDown\((\d+)\)', content, re.IGNORECASE)
        return int(m.group(1)) if m else 0


    def _parse_download_link(self, content):
        """Parsuje finální download link z download stránky."""
        m = re.search(r'<a.+id="downlink"\s+href="([^"]+)"', content, re.IGNORECASE | re.DOTALL)
        return (self.server_url + m.group(1)) if m else None


    # ----------------------------------------------------------------------- #
    #  PRIVATE – helpers
    # ----------------------------------------------------------------------- #

    # ----------------------------------------------------------------------- #
    #  PRIVATE – release tag matching
    # ----------------------------------------------------------------------- #

    # Normalizační tabulky (pattern → kanonický název)
    _RES_TAGS = [
        (r'2160p|(?<!\w)4k(?!\w)|(?<!\w)uhd(?!\w)', '2160p'),
        (r'1080p|(?<!\w)fhd(?!\w)|full[\.\s-]?hd', '1080p'),
        (r'1080i', '1080i'),
        (r'720p', '720p'),
        (r'480p|(?<!\w)sd(?!\w)', '480p'),
    ]
    _SRC_TAGS = [
        (r'(?<!\w)remux(?!\w)|bdremux', 'remux'),
        (r'blu[\.\s-]?ray|(?<!\w)bdrip(?!\w)|(?<!\w)brrip(?!\w)|(?<!\w)brip(?!\w)', 'bluray'),
        (r'web[\.\s-]?dl|(?<!\w)webdl(?!\w)', 'web-dl'),
        (r'webrip|web[\.\s-]?rip', 'webrip'),
        (r'(?<!\w)hdtv(?!\w)|(?<!\w)pdtv(?!\w)|(?<!\w)tvrip(?!\w)|(?<!\w)satrip(?!\w)', 'hdtv'),
        (r'(?<!\w)dvdrip(?!\w)|(?<!\w)dvdr(?!\w)|dvd[\.\s-]?r(?!\w)', 'dvdrip'),
        (r'(?<!\w)hdcam(?!\w)|(?<!\w)cam(?!\w)', 'cam'),
        (r'(?<!\w)telesync(?!\w)|(?<!\w)hdts(?!\w)|(?<![a-z])ts(?![a-z])', 'telesync'),
        (r'(?<!\w)screener(?!\w)|(?<!\w)dvdscr(?!\w)|(?<!\w)bdscr(?!\w)|(?<!\w)scr(?!\w)', 'screener'),
    ]
    _CODEC_TAGS = [
        (r'(?<!\w)x265(?!\w)|h[\.\s-]?265|(?<!\w)hevc(?!\w)', 'h265'),
        (r'(?<!\w)x264(?!\w)|h[\.\s-]?264|(?<!\w)avc(?!\w)', 'h264'),
        (r'(?<!\w)xvid(?!\w)', 'xvid'),
        (r'(?<!\w)divx(?!\w)', 'divx'),
        (r'(?<!\w)av1(?!\w)', 'av1'),
    ]

    def _parse_tags(self, name):
        """Extrahuje release tagy (resolution, source, codec, group) z názvu."""
        if not name:
            return {}
        tags = {}
        nl = name.lower()
        for table, key in [
            (self._RES_TAGS, 'resolution'),
            (self._SRC_TAGS, 'source'),
            (self._CODEC_TAGS, 'codec'),
        ]:
            for pattern, canonical in table:
                if re.search(pattern, nl):
                    tags[key] = canonical
                    break
        # Release group: poslední segment po '-' (před příponou)
        m = re.search(r'-([a-zA-Z0-9]{2,})(?:\.[a-z]{2,4})?$', name.strip())
        if m:
            tags['group'] = m.group(1).lower()
        return tags

    def _match_score(self, stream_tags, sub_tags):
        """Spočítá shodu 0-5 mezi tagy streamu a titulků."""
        if not sub_tags:
            return 0
        score = 0.0
        if (stream_tags.get('group') and sub_tags.get('group')
                and stream_tags['group'] == sub_tags['group']):
            score += 2.0
        if (stream_tags.get('source') and sub_tags.get('source')
                and stream_tags['source'] == sub_tags['source']):
            score += 1.5
        if (stream_tags.get('resolution') and sub_tags.get('resolution')
                and stream_tags['resolution'] == sub_tags['resolution']):
            score += 1.0
        if (stream_tags.get('codec') and sub_tags.get('codec')
                and stream_tags['codec'] == sub_tags['codec']):
            score += 0.5
        return min(int(round(score)), 5)

    def _extract_show_from_path(self, path):
        """Extrahuje anglický název seriálu z filename (část před SxxExx)."""
        if not path:
            return None
        try:
            name = path.rsplit('/', 1)[-1].rsplit('\\', 1)[-1]
            m = re.search(r'[._\s-]S\d{1,2}E\d{1,2}', name, re.IGNORECASE)
            if m:
                show_part = name[:m.start()]
                return re.sub(r'[._-]+', ' ', show_part).strip() or None
        except Exception:
            pass
        return None

    def _normalize_title(self, title):
        """Normalizace názvu pro lepší search výsledky."""
        # "Movie, The" → "The Movie"
        if re.search(r', The$', title, re.IGNORECASE):
            title = "The " + re.sub(r'(?i), The$', '', title)

        # Odstranit závorky: [xy] a (xy) – pokud to není rok
        title = re.sub(r"(\[|\().+?(\]|\))", "", title)

        return title.strip()


    def _filter_by_language(self, set_languages, subtitles):
        """Filtruje titulky podle požadovaných jazyků."""
        if not set_languages:
            return subtitles

        filtered = []
        for sub in subtitles:
            lang_code = xbmc.convertLanguage(sub['lang'], xbmc.ISO_639_2)
            if lang_code in set_languages:
                filtered.append(sub)

        if not filtered:
            # Pokud uživatel nemá nastavené CZ/SK, upozornit
            if 'cze' not in set_languages and 'slo' not in set_languages:
                log("Žádné titulky – uživatel nemá nastavené CZ/SK jazyky")
            return None

        return filtered
