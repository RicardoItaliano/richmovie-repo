# -*- coding: utf-8 -*-
"""
RichMovie – Next‑Up Service
---------------------------
• Sleduje přehrávání přes xbmc.Player().
• _N_ sekund před koncem (dle Settings → nextup_margin) spustí na pozadí
  `_search_episode()` a uloží výsledek do `plugin.NEXT_CACHE`.
• Funkci lze globálně vypnout v Settings → nextup_enable = False.
"""

from __future__ import annotations

# — Standard lib —
import threading
import urllib.parse            # ← NEW: URL‑encoding pro Container.Update
from dataclasses import asdict             # ← NOVÝ import



# – Kodi API –
import xbmc
import xbmcgui

# – Lokální moduly –
import plugin as _rm                       # hlavní modul RichMovie
from tmdb_client import TMDb, TMDbError

# – Nastavení z GUI (dobře reaguje i na živou změnu v průběhu) –
SETTINGS = _rm.ADDON
def _enabled() -> bool:  return SETTINGS.getSettingBool("nextup_enable")
def _margin()  -> int:   return SETTINGS.getSettingInt("nextup_margin") or 300


# – Nastavení intervalu kontroly –  
_CHECK_EVERY   = 5        # jak často (s) se dotazujeme na čas
_PROMPT_MARGIN = 15        # kolik sekund před koncem se zobrazí dialog


# ------------------------------------------------------------------ #
def _next_coords(tv_id: int, season: int, episode: int) -> tuple[int, int] | None:
    """Vrátí (next_season, next_episode) nebo None, pokud seriál skončil."""
    tmdb_key = SETTINGS.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        return None
    tmdb = TMDb(tmdb_key, lang="cs-CZ")

    # kolik dílů má aktuální série?
    eps = tmdb.season_details(tv_id, season)
    max_ep = max((e["episode_number"] for e in eps), default=0)
    if episode < max_ep:
        return season, episode + 1

    # zkusíme první díl další série
    show = tmdb.tv_details(tv_id)
    seasons = sorted(
        s["season_number"] for s in show.get("seasons", [])
        if s.get("season_number", 0) > season
    )
    if not seasons:
        return None
    next_season = seasons[0]
    eps2 = tmdb.season_details(tv_id, next_season)
    first_ep = min((e["episode_number"] for e in eps2), default=1)
    return next_season, first_ep


# ------------------------------------------------------------------ #
class _NextUpPlayer(xbmc.Player):
    """Player wrapper, který spouští pre‑fetch v dalším vlákně."""

    def onAVStarted(self):
        if _enabled():
            threading.Thread(target=self._watch_loop, daemon=True).start()





    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def _watch_loop(self) -> None:
        """
        Hlavní smyčka monitorující přehrávání:

        • (_margin s) před koncem → tichý pre‑fetch další epizody
        • (_PROMPT_MARGIN s)      → dotaz „Přehrát další díl?“
        • Fallback: pokud Kodi nezná TotalTime (0 s),
          použijeme ListItem property „richmovie.duration“.
        """
        prefetch_done = False
        asked         = False
        monitor       = xbmc.Monitor()

        while self.isPlaying():
            try:
                total   = int(self.getTotalTime())
                current = int(self.getTime())

                # Fallback na ručně uloženou délku
                if total <= 0:
                    try:
                        li = self.getPlayingItem()
                        total = int(li.getProperty("richmovie.duration") or 0)
                    except Exception:
                        total = 0                    # stále nevíme stopáž

                if total <= 0:                       # stále chybí údaje
                    if monitor.waitForAbort(_CHECK_EVERY):
                        break
                    continue

                remain = total - current

                # 1️⃣ Prefetch (jen jednou)
                if (not prefetch_done) and remain <= _margin():
                    self._prefetch()
                    prefetch_done = True

                # 2️⃣ Dialog Next‑Up
                if (not asked) and remain <= _PROMPT_MARGIN:
                    self._ask_next()
                    asked = True
                    break                            # smyčka může skončit

            except RuntimeError:                     # přehrávač zmizel
                break

            if monitor.waitForAbort(_CHECK_EVERY):
                break




    def _prefetch(self) -> None:
        """Tichý pre‑fetch příští epizody (uloží do RAM i disk‑cache)."""
        li       = self.getPlayingItem()
        tv_name  = li.getVideoInfoTag().getTVShowTitle()
        tv_id    = li.getProperty("richmovie.tv_id")

        try:
            season  = int(li.getProperty("richmovie.season")
                        or li.getVideoInfoTag().getSeason())
            episode = int(li.getProperty("richmovie.episode")
                        or li.getVideoInfoTag().getEpisode())
        except ValueError:
            return

        if not (tv_id and tv_name and season > 0 and episode > 0):
            return

        coords = _next_coords(int(tv_id), season, episode)
        if not coords:
            return
        next_season, next_ep = coords
        cache_key = (tv_id, next_season, next_ep)
        key_str   = f"{tv_id}:{next_season}:{next_ep}"

        if cache_key in _rm.NEXT_CACHE:                 # už v RAM
            return

        def _worker() -> None:
            rels = _rm._search_episode(
                tv_id, tv_name, next_season, next_ep
            )
            if rels:
                _rm.NEXT_CACHE[cache_key] = rels        # RAM‑cache
                # Disk‑cache (lenivá JSON)
                try:
                    _rm._disk_nextup_cache().put(
                        key_str, [asdict(r) for r in rels]
                    )
                except Exception:
                    pass

        threading.Thread(target=_worker, daemon=True).start()




    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def _ask_next(self) -> None:
        """
        Zobrazí Yes/No dialog s názvem příští epizody.
        • YES  → Container.Update() na `tv_play` (seznam releasů next‑ep).
        • NO   → Container.Update() na `tv_episodes` (seznam dílů aktuální série).
        """
        li       = self.getPlayingItem()
        tv_name  = li.getVideoInfoTag().getTVShowTitle()
        tv_id    = li.getProperty("richmovie.tv_id")

        try:
            season  = int(li.getProperty("richmovie.season")
                          or li.getVideoInfoTag().getSeason())
            episode = int(li.getProperty("richmovie.episode")
                          or li.getVideoInfoTag().getEpisode())
        except ValueError:
            return

        coords = _next_coords(int(tv_id), season, episode)
        if not coords:
            return
        next_season, next_ep = coords

        # – název epizody (TMDb) –
        ep_title = ""
        try:
            tmdb_key = SETTINGS.getSetting("tmdb_api_key").strip()
            if tmdb_key:
                ep_det = TMDb(tmdb_key, lang="cs-CZ").episode_details(
                    int(tv_id), next_season, next_ep)
                ep_title = ep_det.get("name") or ""
        except TMDbError:
            pass

        line = f"{tv_name}  S{next_season:02d}E{next_ep:02d}"
        if ep_title:
            line += f" – {ep_title}"

        play_next = xbmcgui.Dialog().yesno(
            "Přehrát další díl?", line,
            nolabel="Ne", yeslabel="Ano"
        )

        if play_next:
            url = _rm._url(
                action  = "tv_play",
                tv_id   = tv_id,
                tv_name = tv_name,
                season  = str(next_season),
                episode = str(next_ep),
            )
        else:
            url = _rm._url(
                action  = "tv_episodes",
                tv_id   = tv_id,
                tv_name = tv_name,
                season  = str(season),
            )

        xbmc.executebuiltin(f"Container.Update({url},replace)")




# ------------------------------------------------------------------ #
if __name__ == "__main__":
    player  = _NextUpPlayer()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(_CHECK_EVERY):
            break
