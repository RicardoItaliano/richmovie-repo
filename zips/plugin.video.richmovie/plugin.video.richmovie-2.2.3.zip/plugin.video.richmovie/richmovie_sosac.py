# -*- coding: utf-8 -*-
"""
richmovie_sosac.py
──────────────────
Lehký wrapper nad veřejnými JSON exporty Sosac.tv + skládání prémiových
Streamuj.tv URL. Využíván jako „provider“ pro doplněk **RichMovie**.

• SosacClient.search_movies(term) → list[{title, year, img, video_id}]
• SosacClient.search_tv(term)     → list[{title, year, img, video_id}]
• SosacClient.resolve(video_id)   → úplná Streamuj.tv URL
                                    (&pass=<user>:::<double‑MD5(pw)>&location=<n>)

Aktualizováno 22‑07‑2025 20 : 30 CEST
"""
from __future__ import annotations        # ← MUSÍ být hned za doc‑stringem!

# ──────────────────────────────  IMPORTS  ──────────────────────────────────
# Standardní knihovna – abecedně uvnitř skupiny
import hashlib
import json
from dataclasses import dataclass
from typing import Dict, List
import urllib.parse
import urllib.request

# Kodi API
import xbmcaddon

# ─────────────────────────────  KONSTANTY  ─────────────────────────────────
_JSON_SEARCH: str = "https://tv.sosac.to/jsonsearchapi.php?q="
_STREAMUJ:    str = "https://www.streamuj.tv/video/"
_ADDON                 = xbmcaddon.Addon()          # přístup k nastavením GUI
_IMG_DEF_MOVIE: str    = "DefaultVideo.png"         # fallback artwork
_IMG_DEF_SERIE: str    = "DefaultTVShows.png"

# ────────────────────────  DATOVÉ TŘÍDY  ───────────────────────────────────
@dataclass
class SosacItem:
    """Jedna položka výsledků vyhledávání."""
    title:    str
    year:     int
    img:      str
    video_id: str                                   # ID klipu pro Streamuj.tv


# ──────────────────────────  HLAVNÍ KLIENT  ────────────────────────────────
class SosacClient:
    """
    Mini‑klient k Sosac.tv:

    • Vyhledává přes anonymní JSON API (nepotřebuje cookies).
    • Údaje ke Streamuj.tv čte z nastavení doplňku a přidává je
      pouze při skládání prémiové URL (&pass=…).
    """

    # 2025‑07‑22 20:30 CEST – konstruktor
    def __init__(self) -> None:
        self.user:     str = _ADDON.getSetting("sosac_user").strip()
        self.password: str = _ADDON.getSetting("sosac_pass").strip()
        self.location: str = _ADDON.getSetting("sosac_location").strip()

    # 2025‑07‑22 20:30 CEST – privátní: stáhni JSON
    def _json_get(self, url: str) -> Dict:
        """
        Stáhne URL a převádí na dict.  Timeout 8 s → GUI nezamrzá.
        Vyhodí RuntimeError pro HTTP != 200.
        """
        with urllib.request.urlopen(url, timeout=8) as resp:
            if resp.status != 200:
                raise RuntimeError(f"HTTP {resp.status} pro {url}")
            return json.loads(resp.read().decode("utf‑8", "ignore"))

    # 2025‑07‑22 20:30 CEST – privátní: parsuj výsledky
    def _parse_results(self, js: Dict, kind: str) -> List[SosacItem]:
        """
        Konvertuje pole JSON → List[SosacItem].

        Args:
            js:   Pole slovníků vrácených z API.
            kind: "movie" | "tv" – filtruje typ obsahu.
        """
        out: List[SosacItem] = []

        for rec in js:
            vid: str = rec.get("l") or ""
            if not vid:
                continue

            # filtr dle požadovaného druhu
            if kind == "movie" and "#tvshow#" in vid:
                continue
            if kind == "tv" and "#tvshow#" not in vid:
                continue

            title: str = (
                rec.get("n", {}).get("cs")
                or rec.get("n", {}).get("en")
                or "Neznámý"
            )
            year: int = int(rec.get("y") or 0)

            img: str = (
                f"http://movies.sosac.tv/images/75x109/movie-{rec.get('i')}"
                if kind == "movie" else
                f"http://movies.sosac.tv/images/558x313/serial-{rec.get('i')}"
            )
            if not img:
                img = _IMG_DEF_MOVIE if kind == "movie" else _IMG_DEF_SERIE

            out.append(SosacItem(title, year, img, vid))

        return out

    # 2025‑07‑22 20:30 CEST – privátní: dvojité MD5
    def _double_md5(self, data: str) -> str:
        """
        Dvojité MD5 hashování (MD5(MD5(hesla))) – vyžaduje server Streamuj.tv.
        """
        return hashlib.md5(hashlib.md5(data.encode()).hexdigest().encode()).hexdigest()

    # 2025‑07‑23 09:10 CEST – opravené _premium_url
    def _premium_url(self, video_id: str) -> str:
        """
        Sestaví finální URL:
            https://www.streamuj.tv/video/<ID>?pass=USER:::HASH&location=N
        První parametr vždy začíná otazníkem, další se připojují „&“.
        """
        params: list[str] = []

        if self.user and self.password:
            params.append(f"pass={self.user}:::{self._double_md5(self.password)}")
        if self.location in {"1", "2"}:
            params.append(f"location={self.location}")

        query = ("?" + "&".join(params)) if params else ""
        return f"{_STREAMUJ}{video_id}{query}"






    # 2025‑07‑22 20:30 CEST – veřejné: hledej filmy
    def search_movies(self, term: str) -> List[SosacItem]:
        js = self._json_get(_JSON_SEARCH + urllib.parse.quote_plus(term))
        return self._parse_results(js, "movie")

    # 2025‑07‑22 20:30 CEST – veřejné: hledej seriály
    def search_tv(self, term: str) -> List[SosacItem]:
        js = self._json_get(_JSON_SEARCH + urllib.parse.quote_plus(term))
        return self._parse_results(js, "tv")

    # 2025‑07‑22 20:30 CEST – veřejné: převeď ID → URL
    def resolve(self, video_id: str) -> str:
        """Vrátí hotovou Streamuj.tv URL s prémiovým tokenem."""
        return self._premium_url(video_id)
