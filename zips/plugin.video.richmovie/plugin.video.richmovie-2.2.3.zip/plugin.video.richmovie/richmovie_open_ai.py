# -*- coding: utf-8 -*-
"""
RichMovie · OpenAI klient (doporučení titulů)

Vytvořeno: 10-08-2025 21:29 CEST (Europe/Prague)
"""

# ──────────────  STANDARD LIBRARY  ──────────────
from __future__ import annotations
import datetime
import json
import os
import random
import time
from typing import Any, Dict, List, Optional

# ───────────────  3RD-PARTY / KODI  ─────────────
import requests
import xbmc
import xbmcaddon
import xbmcvfs


# ───────────────  PŘIPOJENÍ LOGGERU Z PLUGINU  ─────────────
# Primárně se pokusíme importovat modul `plugin` (běžné, když je importován).
# Pokud doplněk běží jako skript (__main__), vezmeme logger z __main__.
try:
    import plugin as _plg_mod  # očekává se funkce _ai_log(event, msg, details=?, level=?)
except Exception:
    _plg_mod = None

try:
    import __main__ as _rm_main
    if _plg_mod is None and hasattr(_rm_main, "_ai_log"):
        _plg_mod = _rm_main  # fallback: logger z běžícího skriptu
except Exception:
    # nechceme blokovat běh kvůli připojení loggeru
    pass



# 2025-08-10 23:59 CEST (Europe/Prague)
# Viditelný a skin-kompatibilní prefix pro A.I. texty
AI_PREFIX = "[RichMovie A.I.]: "
AI_PREFIX_NOSPC = "[RichMovie A.I.]:"




class OpenAIError(Exception):
    """Obecná chyba při volání OpenAI API."""




# 2025-08-14 15:31 CEST (Europe/Prague)
def recommend_titles(
    api_key: str,
    user_text: str,
    want: str = "any",   # "movie" | "tv" | "any"
    *,
    limit: int = 20,
    model: str = "gpt-5-mini",
    timeout: int = 120,
    retries: int = 2,
) -> List[Dict[str, Any]]:
    """
    OpenAI → seznam titulů s personifikovaným důvodem (CZ).
    • Každý 'reason' mluví přímo na Tebe, bez velkých spoilerů.
    • Prefix je ASCII: [RichMovie A.I.]:  (kompatibilní se skiny Kodi).
    • Stylová variace: max 1 položka smí začínat „Ty…“, ostatní jinak.
    • GPT-5: bez custom temperature; robustní retry/backoff.

    NOVĚ (2025-08-14): Fallback na 'gpt-5' po 1. neúspěchu mini modelu
    (Timeout / RequestException / HTTP 408/429/5xx) + log OPENAI_MODEL_UPGRADE.

    NOVÉ (detailní logování – zachováno z původní verze):
    • Před každým pokusem loguje přesný JSON payload (raw) a URL.
    • Po odpovědi loguje status, hlavičky a surové tělo (raw text).
    • Loguje i výjimky, backoff a speciální „drop temperature“ re-post.
    """
    if not api_key:
        raise OpenAIError("Chybí OpenAI API klíč.")

    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key.strip()}", "Content-Type": "application/json"}

    if want not in ("movie", "tv", "any"):
        want = "any"

    want_desc = {
        "movie": "filmy",
        "tv":    "seriály",
        "any":   "filmy i seriály (u každé položky přidej pole kind = movie|tv)",
    }[want]

    # — styl: rozmanité začátky, přímé oslovení, ASCII prefix —
    sys_prompt = (
        "You are a precise movie/TV recommender for a Czech Kodi plugin.\n"
        "Return ONLY strict JSON with an array 'titles'.\n"
        "Each item MUST include 'title' (canonical), optional 'year' (int), and a Czech 'reason' with:\n"
        f"  • 2–4 short sentences, addressing the user directly (Ty/Tobě/Tvoje… with capitalized pronouns)\n"
        f"  • prefix EXACTLY: '{AI_PREFIX}'\n"
        "  • tiny, non-spoiler context; spoilers only if clearly implied by the user's request\n"
        "  • stylistic variety across items: do NOT repeat the same opening words; at most ONE item may start with 'Ty…'.\n"
        "If both movies and TV are allowed, include 'kind' = 'movie' or 'tv'.\n"
        "No commentary. JSON only."
    )

    user_prompt = (
        f"Uživatel chce doporučení: {want_desc}.\n"
        f"Vrať 6–12 relevantních položek (žádné duplikáty).\n"
        f"Dotaz uživatele (česky): '''{user_text.strip()}'''\n\n"
        "Požadovaný formát odpovědi:\n"
        "{\n"
        '  "titles": [\n'
        '    {"title": "…", "year": 2011' + (', "kind": "movie|tv"' if want == "any" else '') + ', "reason": "…česky…"},\n'
        "    …\n"
        "  ]\n"
        "}"
    )

    def _supports_custom_temperature(m: str) -> bool:
        return not m.lower().startswith("gpt-5")

    payload = {
        "model": model,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user",   "content": user_prompt},
        ],
    }
    if _supports_custom_temperature(model):
        payload["temperature"] = 0.2

    def _post(body: Dict[str, Any]) -> requests.Response:
        # connect-timeout 8 s, read-timeout konfig. parametrem
        return requests.post(url, headers=headers, json=body, timeout=(8, timeout))

    # — robustní odeslání s retry/backoffem + DETAILNÍ LOGOVÁNÍ —
    attempt = 0
    used_payload = dict(payload)
    model_upgraded = False  # ← přidané

    while True:
        # 1) LOG: Request (RAW payload)
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log(
                    "OPENAI_REQ",
                    f"POST {url}",
                    details={
                        "attempt": attempt + 1,
                        "timeout": {"connect": 8, "read": timeout},
                        "model": used_payload.get("model"),
                        "payload": used_payload,     # přesný JSON posílaný na API
                    },
                    level="INFO",
                )
        except Exception:
            pass

        t0 = time.monotonic()
        try:
            resp = _post(used_payload)

        except requests.Timeout as e:
            dur = int((time.monotonic() - t0) * 1000)
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_REQ_ERR", f"Timeout po {dur} ms",
                        details={"attempt": attempt + 1, "error": str(e)}, level="ERROR"
                    )
            except Exception:
                pass

            # ⚡ NOVĚ: jednorázový upgrade po 1. neúspěchu mini modelu
            if (attempt == 0) and (not model_upgraded) and str(used_payload.get("model","")).lower() == "gpt-5-mini":
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log(
                            "OPENAI_MODEL_UPGRADE",
                            "Přepínám na gpt-5 po 1. neúspěchu (Timeout).",
                            details={"from_model": "gpt-5-mini"},
                            level="INFO",
                        )
                except Exception:
                    pass
                used_payload["model"] = "gpt-5"
                used_payload.pop("temperature", None)  # gpt-5 nepodporuje custom temperature
                model_upgraded = True
                attempt += 1
                continue

            if attempt < retries:
                sleep = (0.75 * (2 ** attempt)) + random.uniform(0.0, 0.35)
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log(
                            "OPENAI_RETRY",
                            "Timeout – opakuji požadavek",
                            details={"attempt": attempt + 1, "backoff_s": round(sleep, 3)},
                            level="INFO",
                        )
                except Exception:
                    pass
                time.sleep(sleep); attempt += 1; continue
            raise OpenAIError(f"Chyba sítě: {e}") from e

        except requests.RequestException as e:
            dur = int((time.monotonic() - t0) * 1000)
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_REQ_ERR", f"RequestException po {dur} ms",
                        details={"attempt": attempt + 1, "error": str(e)}, level="ERROR"
                    )
            except Exception:
                pass

            # ⚡ NOVĚ: jednorázový upgrade po 1. neúspěchu mini modelu
            if (attempt == 0) and (not model_upgraded) and str(used_payload.get("model","")).lower() == "gpt-5-mini":
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log(
                            "OPENAI_MODEL_UPGRADE",
                            "Přepínám na gpt-5 po 1. neúspěchu (RequestException).",
                            details={"from_model": "gpt-5-mini"},
                            level="INFO",
                        )
                except Exception:
                    pass
                used_payload["model"] = "gpt-5"
                used_payload.pop("temperature", None)
                model_upgraded = True
                attempt += 1
                continue

            if attempt < retries:
                sleep = (0.75 * (2 ** attempt)) + random.uniform(0.0, 0.35)
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log(
                            "OPENAI_RETRY",
                            "RequestException – opakuji požadavek",
                            details={"attempt": attempt + 1, "backoff_s": round(sleep, 3)},
                            level="INFO",
                        )
                except Exception:
                    pass
                time.sleep(sleep); attempt += 1; continue
            raise OpenAIError(f"Chyba sítě: {e}") from e

        # 2) LOG: Response (RAW)
        dur = int((time.monotonic() - t0) * 1000)
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log(
                    "OPENAI_RESP",
                    f"HTTP {resp.status_code}",
                    details={
                        "attempt": attempt + 1,
                        "ms": dur,
                        "headers": dict(resp.headers or {}),
                        "body": resp.text,      # přesný raw text odpovědi
                    },
                    level="INFO",
                )
        except Exception:
            pass

        if resp.status_code == 400:
            # speciální fallback na chybovou hlášku s "temperature"
            try:
                msg = str(resp.json().get("error", {}).get("message", ""))
            except Exception:
                msg = resp.text
            if "temperature" in msg.lower() and "default (1)" in msg.lower() and "temperature" in used_payload:
                used_payload.pop("temperature", None)
                # LOG: drop temperature + re-post (stejný attempt)
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log(
                            "OPENAI_400_TEMPERATURE",
                            "Dropuji 'temperature' a opakuji POST",
                            details={"attempt": attempt + 1, "message": msg},
                            level="WARNING",
                        )
                        _plg_mod._ai_log(
                            "OPENAI_REQ_REPOST",
                            f"POST {url}",
                            details={
                                "attempt": attempt + 1,
                                "model": used_payload.get("model"),
                                "payload": used_payload,
                            },
                            level="INFO",
                        )
                except Exception:
                    pass
                try:
                    t1 = time.monotonic()
                    resp = _post(used_payload)
                    # LOG: re-post response
                    try:
                        if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                            _plg_mod._ai_log(
                                "OPENAI_RESP_REPOST",
                                f"HTTP {resp.status_code}",
                                details={
                                    "attempt": attempt + 1,
                                    "ms": int((time.monotonic() - t1) * 1000),
                                    "headers": dict(resp.headers or {}),
                                    "body": resp.text,
                                },
                                level="INFO",
                            )
                    except Exception:
                        pass
                except requests.RequestException as e:
                    if attempt < retries:
                        sleep = (0.75 * (2 ** attempt)) + random.uniform(0.0, 0.35)
                        try:
                            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                                _plg_mod._ai_log(
                                    "OPENAI_RETRY",
                                    "RequestException po dropu 'temperature' – opakuji požadavek",
                                    details={"attempt": attempt + 1, "backoff_s": round(sleep, 3)},
                                    level="INFO",
                                )
                        except Exception:
                            pass
                        time.sleep(sleep); attempt += 1; continue
                    raise OpenAIError(f"Chyba sítě (retry): {e}") from e

        if resp.status_code in (408, 429) or (500 <= resp.status_code <= 504):
            # ⚡ NOVĚ: jednorázový upgrade po 1. neúspěchu mini modelu
            if (attempt == 0) and (not model_upgraded) and str(used_payload.get("model","")).lower() == "gpt-5-mini":
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log(
                            "OPENAI_MODEL_UPGRADE",
                            f"HTTP {resp.status_code} – přepínám na gpt-5 po 1. neúspěchu.",
                            details={"from_model": "gpt-5-mini"},
                            level="INFO",
                        )
                except Exception:
                    pass
                used_payload["model"] = "gpt-5"
                used_payload.pop("temperature", None)
                model_upgraded = True
                attempt += 1
                continue

            if attempt < retries:
                sleep = (0.9 * (2 ** attempt)) + random.uniform(0.2, 0.6)
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log(
                            "OPENAI_HTTP_RETRYABLE",
                            f"HTTP {resp.status_code} – opakuji požadavek",
                            details={"attempt": attempt + 1, "backoff_s": round(sleep, 3)},
                            level="WARNING",
                        )
                except Exception:
                    pass
                time.sleep(sleep); attempt += 1; continue
        break

    if resp.status_code == 401:
        # LOG: finální chyba
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_HTTP_ERROR_FINAL", "HTTP 401", details={"body": resp.text}, level="ERROR")
        except Exception:
            pass
        raise OpenAIError("Neplatný OpenAI API klíč (HTTP 401).")
    if resp.status_code >= 400:
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log(
                    "OPENAI_HTTP_ERROR_FINAL",
                    f"HTTP {resp.status_code}",
                    details={"body": resp.text},
                    level="ERROR",
                )
        except Exception:
            pass
        snippet = resp.text if len(resp.text) <= 500 else (resp.text[:500] + "…")
        raise OpenAIError(f"OpenAI chyba: HTTP {resp.status_code} – {snippet}")

    try:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        obj = json.loads(content)
        items: List[Dict[str, Any]] = obj.get("titles", []) or []
        # LOG: parse OK
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log(
                    "OPENAI_PARSE_OK",
                    f"Počet položek: {len(items)}",
                    details={"usage": data.get("usage", {}), "model": data.get("model", "")},
                    level="INFO",
                )
        except Exception:
            pass
    except Exception as e:
        # LOG: parse error (raw content už je zalogován výše jako body)
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_PARSE_ERROR", str(e), level="ERROR")
        except Exception:
            pass
        raise OpenAIError(f"Nelze zpracovat odpověď OpenAI: {e}") from e

    # — sestavení výstupu + variace začátků —
    def _body_after_prefix(txt: str) -> str:
        t = (txt or "").strip()
        if t.startswith(AI_PREFIX):
            return t[len(AI_PREFIX):]
        if t.startswith(AI_PREFIX_NOSPC):
            return t[len(AI_PREFIX_NOSPC):].lstrip()
        return t

    def _first_two_words(txt: str) -> str:
        w = _body_after_prefix(txt).split()
        return " ".join(w[:2]).lower() if w else ""

    out: List[Dict[str, Any]] = []
    for it in items[: max(1, min(50, limit))]:
        title  = str((it.get("title") or "")).strip()
        if not title:
            continue
        # year
        year = it.get("year")
        try:
            year = int(year) if year is not None else None
        except Exception:
            year = None
        # reason
        reason = str(it.get("reason") or it.get("why") or "").strip()
        if reason and not (reason.startswith(AI_PREFIX) or reason.startswith(AI_PREFIX_NOSPC)):
            reason = AI_PREFIX + reason

        rec: Dict[str, Any] = {"title": title}
        if year:
            rec["year"] = year
        if want == "any":
            kind = str((it.get("kind") or "")).strip().lower()
            rec["kind"] = "tv" if kind == "tv" else "movie" if kind == "movie" else "movie"
        if reason:
            rec["reason"] = reason
        out.append(rec)

    # variace úvodů (omezit „Ty…“ a duplicity)
    openers = [
        "Na základě Tvého zadání",
        "S ohledem na to, co Tě zajímá",
        "Z toho, co píšeš",
        "Jestli jsem Tě pochopil správně",
        "Zdá se, že hledáš",
        "Tvoje zadání napovídá",
        "Myslím, že by Ti",
        "Možná by Ti",
    ]
    used_starts: set[str] = set()
    opener_i = 0
    disallow_first = {"ty", "tvoje", "tobě", "tvůj", "tvé", "tvá", "tvým", "tvými"}

    for rec in out:
        r = rec.get("reason") or ""
        start2 = _first_two_words(r)
        start1 = start2.split()[0] if start2 else ""

        if (start2 in used_starts) or (start1 in disallow_first):
            intro = openers[opener_i % len(openers)]
            opener_i += 1
            body = _body_after_prefix(r)
            rec["reason"] = f"{AI_PREFIX}{intro}: {body}"
            start2 = _first_two_words(rec["reason"])

        used_starts.add(start2 or "_")

    # — účtování spotřeby tokenů (USD → CZK → toast) —
    try:
        if _plg_mod and hasattr(_plg_mod, "_ai_usage_consume"):
            _plg_mod._ai_usage_consume(api_key, {**(data.get("usage") or {})}, (data.get("model") or model))
    except Exception:
        # nechceme nikdy blokovat běh kvůli účtování/ukládání
        pass

    return out





def normalize_cz_slang(text: str) -> str:
    """
    Lehká, bezpečná normalizace českého slangu/eufemismů do neutrálnějšího jazyka.
    Nepřevádí popisy na konkrétní tituly, jen zvyšuje šanci, že LLM pochopí záměr.
    Ponechává význam, neřeší skloňování do detailu a nic „nevymýšlí“.

    15-08-2025 22:26 CEST (Europe/Prague)

    Příklady změn (bez vazby na konkrétní díla):
      - vulgární slovesa → „mít sex“, „spát s“ (netýká se znásilnění či násilí)
      - běžné hovorové výrazy → neutrálnější podoba („kluk“ → „chlapec“, „holka“ → „dívka“)
      - konkrétní příchutě/jídla ponechává; jen zjemní název, neodstraňuje objekt (rekvizitu)

    Pozn.: záměrně minimalistické; model nadále pracuje i s původním textem.
    """
    if not text:
        return text

    s = text
    # — měkké slovní náhrady (case-insensitive přes nižší dopad) —
    lower = s.lower()

    replacements = [
        # vulgární/explicitní slovesa → neutrální formulace
        (["šoustat", "šoustal", "šukal", "šukat", "souložit", "souložil", "prcat", "prcal", "mrdat", "mrdal", "píchat", "píchal"], "mít sex"),
        # běžná hovorová substantiva
        (["kluk"], "chlapec"),
        (["holka"], "dívka"),
    ]

    for variants, repl in replacements:
        for v in variants:
            if v in lower:
                # jednoduchá náhrada bez diakritických fint – účelově stačí
                lower = lower.replace(v, repl)

    # Vrátíme „zjemněný“ text v malých písmenech (použijeme jen jako pomocnou parafrázi)
    return lower





def identify_titles(
    api_key: str,
    user_text: str,
    *,
    limit: int = 5,
    model: str = "gpt-5-mini",
    timeout: int = 120,
    retries: int = 2,
) -> List[Dict[str, Any]]:
    """
    Přesná identifikace titulů (film/seriál) podle popisu uživatele.
    Přísná přesnost + JSON-only výstup. Nově:
      • lépe definovaný prompt (slang/eufemismy, ikonické scény, sexuální narážky jsou OK),
      • pokud přijde prázdný výsledek (HTTP 200, ale "titles" == []), proběhne:
          (1) re-post na „gpt-5“ s přitvrzenou instrukcí „do not refuse“,
          (2) pokud stále prázdné, fallback přes identify_by_description(...) (stejný modul).
      • detailní logování: OPENAI_ID_EMPTY, OPENAI_ID_EMPTY_RETRY, OPENAI_ID_EMPTY_FALLBACK_IDB.

    15-08-2025 22:26 CEST (Europe/Prague)
    """
    if not api_key:
        raise OpenAIError("Chybí OpenAI API klíč.")

    # 0) Předzpracování slangu – pouze jako POMOCNÁ parafráze (původní text zůstává)
    aux_paraphrase = normalize_cz_slang(user_text or "")

    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key.strip()}", "Content-Type": "application/json"}

    AI_PREFIX = "[RichMovie A.I.]: "
    AI_PREFIX_NOSPC = "[RichMovie A.I.]:"

    # — system prompt: přísný JSON, ale tolerantní k formě popisu —
    sys_prompt = (
        "You are a high‑precision movie/TV identifier for a Czech Kodi plugin.\n"
        "Return STRICT JSON with an array 'titles'.\n"
        "INCLUDE ONLY items that satisfy ALL concrete facts from the user's description.\n"
        "For each item provide: 'title', 'kind' ('movie'|'tv'), optional 'year' (int), "
        f"'reason' in Czech prefixed exactly by '{AI_PREFIX}', 'confidence' (0-100), "
        "'missing_facts' (array of any facts that do NOT match; MUST be empty when sure).\n"
        "No commentary. JSON only.\n"
        "Important: The description may contain slang, euphemisms or references to iconic scenes (memes). "
        "Paraphrase and interpret such language; do NOT require literal word-for-word matches.\n"
        "Important: Non-graphic sexual references are allowed for identification; do NOT refuse."
    )

    # — user prompt: originál + pomocná parafráze (pokud dává smysl) —
    user_lines = [
        "Popis uživatele (česky):",
        f"'''{(user_text or '').strip()}'''",
        "",
        "Požadovaný formát odpovědi:",
        "{",
        '  "titles": [',
        '    {"title": "…", "kind": "movie|tv", "year": 1999, '
        f'     "reason": "{AI_PREFIX}…česky…", "confidence": 0–100, "missing_facts": ["…"]}},',
        "    …",
        "  ]",
        "}",
    ]
    if aux_paraphrase and aux_paraphrase.strip() and aux_paraphrase.strip() != (user_text or "").strip():
        user_lines.insert(2, f"Pomocná normalizovaná parafráze: '''{aux_paraphrase.strip()}'''")
    user_prompt = "\n".join(user_lines)

    def _supports_custom_temperature(m: str) -> bool:
        # GPT‑5 (vč. -mini) nepodporuje custom temperature → nevyplňovat
        return not m.lower().startswith("gpt-5")

    payload: Dict[str, Any] = {
        "model": model,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user",   "content": user_prompt},
        ],
    }
    if _supports_custom_temperature(model):
        payload["temperature"] = 0.1

    def _post(body: Dict[str, Any]) -> requests.Response:
        return requests.post(url, headers=headers, json=body, timeout=(8, timeout))

    # — robustní odeslání + logování —
    attempt = 0
    used_payload = dict(payload)
    model_upgraded = False  # jednorázový upgrade mini→gpt‑5 při síť/HTTP retry

    # 1) První volání
    try:
        if _plg_mod and hasattr(_plg_mod, "_ai_log"):
            _plg_mod._ai_log(
                "OPENAI_ID_REQ",
                f"POST {url}",
                details={
                    "attempt": attempt + 1,
                    "timeout": {"connect": 8, "read": timeout},
                    "model": used_payload.get("model"),
                    "payload": used_payload,
                },
                level="INFO",
            )
    except Exception:
        pass

    try:
        t1 = time.monotonic()
        resp = _post(used_payload)
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log(
                    "OPENAI_ID_RESP",
                    f"HTTP {resp.status_code}",
                    details={
                        "attempt": attempt + 1,
                        "ms": int((time.monotonic() - t1) * 1000),
                        "headers": dict(resp.headers or {}),
                        "body": resp.text[:2000],
                    },
                    level="INFO",
                )
        except Exception:
            pass
    except requests.RequestException as e:
        # síťová chyba → případný upgrade modelu a retry
        if (attempt == 0) and (not model_upgraded) and str(used_payload.get("model","")).lower() == "gpt-5-mini":
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_MODEL_UPGRADE",
                        "Přepínám na gpt-5 po 1. neúspěchu (RequestException).",
                        details={"from_model": "gpt-5-mini"},
                        level="INFO",
                    )
            except Exception:
                pass
            used_payload["model"] = "gpt-5"
            used_payload.pop("temperature", None)
            model_upgraded = True
            # re-post (bez dalšího backoffu)
            t1 = time.monotonic()
            resp = _post(used_payload)
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_ID_RESP",
                        f"HTTP {resp.status_code}",
                        details={
                            "attempt": 2,
                            "ms": int((time.monotonic() - t1) * 1000),
                            "headers": dict(resp.headers or {}),
                            "body": resp.text[:2000],
                        },
                        level="INFO",
                    )
            except Exception:
                pass
        else:
            raise OpenAIError(f"Chyba sítě: {e}") from e

    # Retryable HTTP (408/429/5xx)
    if resp.status_code in (408, 429) or (500 <= resp.status_code <= 504):
        if (attempt == 0) and (not model_upgraded) and str(used_payload.get("model","")).lower() == "gpt-5-mini":
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_MODEL_UPGRADE",
                        f"HTTP {resp.status_code} – přepínám na gpt-5 po 1. neúspěchu.",
                        details={"from_model": "gpt-5-mini"},
                        level="INFO",
                    )
            except Exception:
                pass
            used_payload["model"] = "gpt-5"
            used_payload.pop("temperature", None)
            t1 = time.monotonic()
            resp = _post(used_payload)
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_ID_RESP",
                        f"HTTP {resp.status_code}",
                        details={
                            "attempt": 2,
                            "ms": int((time.monotonic() - t1) * 1000),
                            "headers": dict(resp.headers or {}),
                            "body": resp.text[:2000],
                        },
                        level="INFO",
                    )
            except Exception:
                pass
        elif retries > 0:
            # jednoduchý backoff
            sleep = (0.9 * (2 ** attempt)) + random.uniform(0.2, 0.6)
            time.sleep(sleep)
            t1 = time.monotonic()
            resp = _post(used_payload)
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_ID_RESP_RETRY",
                        f"HTTP {resp.status_code}",
                        details={
                            "attempt": attempt + 2,
                            "ms": int((time.monotonic() - t1) * 1000),
                            "headers": dict(resp.headers or {}),
                            "body": resp.text[:2000],
                        },
                        level="INFO",
                    )
            except Exception:
                pass

    # Speciál: „temperature only default (1)“ → znovu bez parametru
    if resp.status_code == 400:
        try:
            msg = str(resp.json().get("error", {}).get("message", ""))
        except Exception:
            msg = resp.text
        if "temperature" in msg.lower() and "default (1)" in msg.lower() and "temperature" in used_payload:
            used_payload.pop("temperature", None)
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_ID_400_TEMPERATURE",
                        "Dropuji 'temperature' a opakuji POST",
                        details={"attempt": attempt + 1, "message": msg},
                        level="WARNING",
                    )
            except Exception:
                pass
            t1 = time.monotonic()
            resp = _post(used_payload)
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log(
                        "OPENAI_ID_RESP_REPOST",
                        f"HTTP {resp.status_code}",
                        details={
                            "attempt": attempt + 1,
                            "ms": int((time.monotonic() - t1) * 1000),
                            "headers": dict(resp.headers or {}),
                            "body": resp.text[:2000],
                        },
                        level="INFO",
                    )
            except Exception:
                pass

    if resp.status_code == 401:
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_ID_HTTP_ERROR_FINAL", "HTTP 401", details={"body": resp.text}, level="ERROR")
        except Exception:
            pass
        raise OpenAIError("Neplatný OpenAI API klíč (HTTP 401).")
    if resp.status_code >= 400:
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_ID_HTTP_ERROR_FINAL", f"HTTP {resp.status_code}", details={"body": resp.text}, level="ERROR")
        except Exception:
            pass
        snippet = resp.text if len(resp.text) <= 500 else (resp.text[:500] + "…")
        raise OpenAIError(f"OpenAI chyba: HTTP {resp.status_code} – {snippet}")

    # Parse JSON odpovědi → seznam kandidátů
    def _parse_items(text: str) -> List[Dict[str, Any]]:
        data = json.loads(text)
        content = data["choices"][0]["message"]["content"]
        obj = json.loads(content)
        items: List[Dict[str, Any]] = obj.get("titles", []) or []
        out: List[Dict[str, Any]] = []
        for it in items[: max(1, min(5, limit))]:
            title  = str((it.get("title") or "")).strip()
            if not title:
                continue
            kind = str((it.get("kind") or "movie")).strip().lower()
            year = it.get("year")
            try:
                year = int(year) if year is not None else None
            except Exception:
                year = None
            reason = str(it.get("reason") or "").strip()
            if reason and not (reason.startswith(AI_PREFIX) or reason.startswith(AI_PREFIX_NOSPC)):
                reason = AI_PREFIX + reason
            try:
                conf = int(it.get("confidence") or 0)
            except Exception:
                conf = 0
            miss = it.get("missing_facts") or []
            rec: Dict[str, Any] = {"title": title, "kind": "tv" if kind == "tv" else "movie", "confidence": conf}
            if year:
                rec["year"] = year
            if reason:
                rec["reason"] = reason
            rec["missing_facts"] = [str(x).strip() for x in miss] if isinstance(miss, list) else []
            out.append(rec)
        return out

    try:
        out = _parse_items(resp.text)
        # účtování spotřeby (z prvního volání)
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_usage_consume"):
                data0 = {}
                try:
                    data0 = resp.json()
                except Exception:
                    pass
                _plg_mod._ai_usage_consume(api_key, {**(data0.get("usage") or {})}, (data0.get("model") or model))
        except Exception:
            pass

        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_ID_PARSE_OK", f"Počet položek: {len(out)}", details={"model": model}, level="INFO")
        except Exception:
            pass
    except Exception as e:
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_ID_PARSE_ERROR", str(e), level="ERROR")
        except Exception:
            pass
        raise OpenAIError(f"Nelze zpracovat odpověď OpenAI: {e}") from e

    # 🟡 Fallbacky při prázdném výsledku (bez hardcodů)
    if not out:
        # (A) zaloguj prázdný výsledek
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log(
                    "OPENAI_ID_EMPTY",
                    "titles == []",
                    details={"aux_paraphrase": aux_paraphrase},
                    level="WARNING",
                )
        except Exception:
            pass

        # (B) jednorázový re-post na plný „gpt-5“ se zpřesněnou instrukcí
        used_payload2 = dict(payload)
        used_payload2["model"] = "gpt-5"
        used_payload2.pop("temperature", None)
        extra_sys = sys_prompt + "\nDo not refuse for non-graphic sexual references; identification only."
        used_payload2["messages"] = [
            {"role": "system", "content": extra_sys},
            {"role": "user",   "content": user_prompt},
        ]
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_ID_EMPTY_RETRY", "Repost na gpt-5", details={"payload": used_payload2}, level="WARNING")
        except Exception:
            pass
        try:
            resp2 = _post(used_payload2)
            if resp2.status_code == 200:
                try:
                    out = _parse_items(resp2.text)
                except Exception:
                    out = []
        except requests.RequestException:
            out = out or []

        # (C) stále prázdné → fallback přes identify_by_description(...)
        if not out:
            try:
                if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                    _plg_mod._ai_log("OPENAI_ID_EMPTY_FALLBACK_IDB", "Spouštím identify_by_description()", level="INFO")
            except Exception:
                pass
            try:
                # stejná limitace výstupu; model ponecháme mini (pipeline je jiná),
                # ale lze zvážit „gpt-5“ pro vyšší jistotu – zde volitelně:
                idb = identify_by_description(
                    api_key=api_key,
                    description=user_text,
                    want="any",
                    limit=max(1, min(5, limit)),
                    model="gpt-5",       # robustnější krok
                    timeout=timeout,
                    retries=retries,
                )
                # flexibilní extrakce výsledků (modul může vracet různé klíče)
                cand_list: List[Dict[str, Any]] = []
                if isinstance(idb, dict):
                    for key in ("titles", "candidates", "results"):
                        val = idb.get(key)
                        if isinstance(val, list):
                            cand_list = val
                            break
                elif isinstance(idb, list):
                    cand_list = idb

                # sjednocení do stejného formátu
                norm_out: List[Dict[str, Any]] = []
                for it in (cand_list or [])[: max(1, min(5, limit))]:
                    if not isinstance(it, dict):
                        continue
                    title = str((it.get("title") or it.get("name") or "")).strip()
                    if not title:
                        continue
                    kind  = str((it.get("kind") or it.get("type") or "movie")).strip().lower()
                    year  = it.get("year")
                    try:
                        year = int(year) if year is not None else None
                    except Exception:
                        year = None
                    reason = str(it.get("reason") or it.get("why") or "").strip()
                    if reason and not reason.startswith(AI_PREFIX):
                        reason = AI_PREFIX + reason
                    conf = it.get("confidence")
                    try:
                        conf = int(conf) if conf is not None else 0
                    except Exception:
                        conf = 0
                    miss = it.get("missing_facts") or []
                    rec = {"title": title, "kind": "tv" if kind == "tv" else "movie", "confidence": conf}
                    if year:
                        rec["year"] = year
                    if reason:
                        rec["reason"] = reason
                    rec["missing_facts"] = [str(x).strip() for x in miss] if isinstance(miss, list) else []
                    norm_out.append(rec)
                out = norm_out
            except Exception:
                # fallback nesmí nikdy spadnout
                out = out or []

    return out






# 2025-08-11 21:41 CEST (Europe/Prague)
def identify_by_description(
    api_key: str,
    description: str,
    want: str = "any",  # "movie" | "tv" | "any"
    *,
    limit: int = 5,
    model: str = "gpt-5-mini",
    timeout: int = 120,
    retries: int = 2,
) -> Dict[str, Any]:
    """
    Přijme volný popis děje/konkrétních vzpomínek a vrátí **přesné** kandidáty.

    DŮRAZ NA PŘESNOST:
      • nejdřív vytěž fakta/omezení (osoby, místa, rok/období, žánry, jazyky,
        země původu, klíčové momenty),
      • pak navrhni max 5 titulů **pouze pokud SI JISTÝ**, že splňují vše podstatné,
      • seřaď od nejpravděpodobnější shody,
      • u každé položky vrať kind (movie|tv), year (pokud víš), a "why" (stručně česky).

    Návratová struktura:
      {
        "constraints": { ... },
        "candidates": [
          {"title": "...", "year": 1999, "kind": "movie", "confidence": 0.92, "why": "…"},
          ...
        ]
      }

    Pozn.:
      • JSON‑only režim (response_format = json_object).
      • Retry/backoff na 408/429/5xx.
      • Speciální fallback pro HTTP 400 s hláškou o 'temperature' na GPT‑5: zahodí se parametr a požadavek se zopakuje.
      • Po úspěchu se provede účtování spotřeby tokenů (_ai_usage_consume).
    """
    if not api_key:
        raise OpenAIError("Chybí OpenAI API klíč.")

    # 1) příprava endpointu
    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key.strip()}", "Content-Type": "application/json"}

    if want not in ("movie", "tv", "any"):
        want = "any"
    want_desc = {
        "movie": "pouze FILMY",
        "tv":    "pouze SERIÁLY",
        "any":   "filmy i seriály",
    }[want]

    # 2) –— SYSTEM a USER prompty ————————————————————————————————
    # (a) extrakce faktů
    sys_extract = (
        "You are an information extraction expert for a Czech Kodi plugin.\n"
        "Extract HARD constraints from the user's description of a film/TV title.\n"
        "Return STRICT JSON with a single object 'constraints' (no prose).\n"
        "Treat explicit details as REQUIRED (actors by name, places, languages, countries, exact years).\n"
        "Infer decade if exact year not given.\n"
        "Schema:\n"
        "{\n"
        '  "actors":        ["…"],           // jména osob (herci, herečky, camea), prázdné pokud nevíš\n'
        '  "people":        ["…"],           // další výrazné osoby z textu (režisér, postavy jménem)\n'
        '  "characters":    ["…"],           // jména POSTAV (pokud padnou)\n'
        '  "places":        ["…"],           // města/země/konkrétní lokace\n'
        '  "countries":     ["USA","FR","CZ"], // iso_3166_1 nebo názvy (povoleno obojí)\n'
        '  "languages":     ["cs","en","English","čeština"], // kódy ISO 639-1 nebo názvy\n'
        '  "genres":        ["thriller","comedy","animation","western"],\n'
        '  "year_exact":    0,               // 0 nebo YYYY pokud explicitní rok\n'
        '  "decade_hint":   "",              // např. "late 90s", "2000s", "around 2015" (prázdné pokud netušíš)\n'
        '  "plot_points":   ["…","…"],       // krátké fráze děje, konkrétní momenty/objekty/quotes\n'
        '  "forbidden":     ["…"]            // explicitní NEGACE, pokud uživatel uvedl (např. "ne animované")\n'
        "}\n"
        "JSON only."
    )
    user_extract = f"Popis od uživatele (česky, zachovej všechny detaily):\n'''{(description or '').strip()}'''"

    # (b) výběr kandidátů – musí splňovat vše podstatné
    sys_select = (
        "You are a movie/TV identifier for a Czech Kodi plugin.\n"
        "Return STRICT JSON with an object {\"candidates\": [...]}.\n"
        "Select up to 5 titles that VERY LIKELY match ALL important constraints.\n"
        "If not sure, return an empty list.\n"
        "Each item MUST have: title, kind ('movie'|'tv'), optional year (int),\n"
        "confidence in [0.50,1.00], and 'why' – short Czech justification (1–3 věty, bez spoilerů).\n"
        "Order by confidence DESC.\n"
        "NO commentary outside JSON."
    )

    # 3) payloady (2‑kroková konverzace v jednom volání – výhoda pro GPT‑5)
    messages = [
        {"role": "system", "content": sys_extract},
        {"role": "user",   "content": user_extract},
        # Drž se požadavku na typ obsahu
        {"role": "user",   "content": f"Typ obsahu: {want_desc}. Pokud je v rozporu, raději vrať []"},
        # druhý krok – výběr kandidátů
        {"role": "system", "content": sys_select},
        {
            "role": "user",
            "content": (
                "Použij výstup 'constraints' z předchozího kroku.\n"
                "Vrať JSON:\n"
                "{\n"
                '  "constraints": { ... },\n'
                '  "candidates": [\n'
                '     {"title":"…","kind":"movie|tv","year":2019,"confidence":0.87,"why":"…česky…"},\n'
                "     ...\n"
                "  ]\n"
                "}"
            ),
        },
    ]
    payload: Dict[str, Any] = {
        "model": model,
        "response_format": {"type": "json_object"},
        "temperature": 0,  # přísná determinističnost (u GPT‑5 můžeme případně odhodit – viz fallback níž)
        "messages": messages,
    }

    def _post(body: Dict[str, Any]) -> requests.Response:
        return requests.post(url, headers=headers, json=body, timeout=(8, timeout))

    # 4) odeslání s retry/backoff a DETAILNÍM LOGOVÁNÍM (stejný styl jako recommend_titles)
    attempt = 0
    used_payload = dict(payload)
    while True:
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_REQ", f"POST {url}", details={"attempt": attempt + 1, "body": used_payload}, level="INFO")
        except Exception:
            pass

        try:
            resp = _post(used_payload)
        except requests.RequestException as e:
            if attempt < retries:
                sleep = (0.9 * (2 ** attempt)) + random.uniform(0.2, 0.6)
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log("OPENAI_RETRY", str(e), details={"attempt": attempt + 1, "backoff_s": round(sleep, 3)})
                except Exception:
                    pass
                time.sleep(sleep); attempt += 1;  continue
            raise OpenAIError(f"Chyba sítě (retry): {e}") from e

        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log(
                    "OPENAI_RESP",
                    f"HTTP {resp.status_code}",
                    details={
                        "headers": dict(resp.headers or {}),
                        "body": (resp.text[:1500] + "…") if len(resp.text) > 1500 else resp.text
                    },
                    level="INFO",
                )
        except Exception:
            pass

        # Fallback: 400 s hláškou o 'temperature' na GPT‑5 → zahodit param a repost
        if resp.status_code == 400:
            try:
                msg = str(resp.json().get("error", {}).get("message", ""))
            except Exception:
                msg = resp.text
            if "temperature" in msg.lower() and "default (1)" in msg.lower() and "temperature" in used_payload:
                used_payload.pop("temperature", None)
                try:
                    if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                        _plg_mod._ai_log(
                            "OPENAI_400_TEMPERATURE",
                            "Dropuji 'temperature' a opakuji POST",
                            details={"attempt": attempt + 1, "message": msg},
                            level="WARNING",
                        )
                except Exception:
                    pass
                try:
                    resp = _post(used_payload)
                    try:
                        if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                            _plg_mod._ai_log(
                                "OPENAI_RESP_REPOST",
                                f"HTTP {resp.status_code}",
                                details={"headers": dict(resp.headers or {}), "body": resp.text[:1500]},
                                level="INFO",
                            )
                    except Exception:
                        pass
                except requests.RequestException as e:
                    if attempt < retries:
                        sleep = (0.9 * (2 ** attempt)) + random.uniform(0.2, 0.6)
                        time.sleep(sleep); attempt += 1; continue
                    raise OpenAIError(f"Chyba sítě po odstranění temperature: {e}") from e

        if resp.status_code == 401:
            raise OpenAIError("Neplatný OpenAI API klíč (HTTP 401).")
        if resp.status_code in (408, 429) or (500 <= resp.status_code <= 504):
            if attempt < retries:
                sleep = (0.9 * (2 ** attempt)) + random.uniform(0.2, 0.6)
                time.sleep(sleep); attempt += 1;  continue
        if resp.status_code >= 400:
            snippet = resp.text if len(resp.text) <= 500 else (resp.text[:500] + "…")
            raise OpenAIError(f"OpenAI chyba: HTTP {resp.status_code} – {snippet}")
        break

    # 5) parse JSON
    try:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        obj = json.loads(content) or {}
        constraints = obj.get("constraints") or {}
        candidates  = obj.get("candidates")  or []
        # sanity + limit a typy
        out: Dict[str, Any] = {
            "constraints": constraints,
            "candidates": []
        }
        for it in candidates[: max(0, min(5, limit))]:
            title = str((it.get("title") or "")).strip()
            if not title:
                continue
            kind  = (it.get("kind") or "").strip().lower()
            if kind not in ("movie", "tv"):
                kind = "movie" if want in ("any", "movie") else "tv"
            conf = float(it.get("confidence") or 0.0)
            year = it.get("year")
            try:
                year = int(year) if year is not None else None
            except Exception:
                year = None
            why  = str(it.get("why") or "").strip()
            out["candidates"].append(
                {"title": title, "kind": kind, "year": year, "confidence": round(conf, 3), "why": why}
            )

        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log(
                    "OPENAI_PARSE_OK",
                    f"Identify OK – {len(out['candidates'])} kandidátů",
                    details={"usage": data.get("usage", {}), "model": data.get("model", "")},
                    level="INFO",
                )
        except Exception:
            pass

        # — účtování spotřeby tokenů (USD → CZK → toast) —
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_usage_consume"):
                _plg_mod._ai_usage_consume(api_key, {**(data.get("usage") or {})}, (data.get("model") or model))
        except Exception:
            # účtování nikdy nesmí zablokovat běh
            pass

        return out

    except Exception as e:
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_PARSE_ERROR", str(e), level="ERROR")
        except Exception:
            pass
        raise OpenAIError(f"Nelze zpracovat odpověď OpenAI: {e}") from e





# 2025-08-11 10:51 CEST (Europe/Prague)
def validate_openai_key(api_key: str, *, model: str = "gpt-5-mini", timeout: int = 15) -> tuple[bool, str]:
    """
    Ověří, že klíč je platný a má přístup k modelu.
    Primárně volá GET /v1/models/{model} (bez placených tokenů).
    Vrací (True, "OK") nebo (False, "…lidská zpráva…").

    NOVÉ (detailní logování):
    • Loguje URL požadavku a RAW tělo odpovědi (status, hlavičky, text).
    • Loguje i chyby `RequestException`.
    """
    if not api_key or not api_key.strip():
        return False, "Chybí OpenAI klíč."

    url = f"https://api.openai.com/v1/models/{model}"
    headers = {"Authorization": f"Bearer {api_key.strip()}"}

    # LOG: request
    try:
        if _plg_mod and hasattr(_plg_mod, "_ai_log"):
            _plg_mod._ai_log("OPENAI_VALIDATE_REQ", f"GET {url}", details={"timeout": timeout}, level="INFO")
    except Exception:
        pass

    try:
        r = requests.get(url, headers=headers, timeout=timeout)
    except requests.RequestException as e:
        # LOG: chyba
        try:
            if _plg_mod and hasattr(_plg_mod, "_ai_log"):
                _plg_mod._ai_log("OPENAI_VALIDATE_ERR", str(e), level="ERROR")
        except Exception:
            pass
        return False, f"Chyba sítě při ověřování klíče: {e}"

    # LOG: response (RAW)
    try:
        if _plg_mod and hasattr(_plg_mod, "_ai_log"):
            _plg_mod._ai_log(
                "OPENAI_VALIDATE_RESP",
                f"HTTP {r.status_code}",
                details={"headers": dict(r.headers or {}), "body": r.text},
                level="INFO",
            )
    except Exception:
        pass

    if r.status_code == 200:
        return True, "OK"
    if r.status_code == 401:
        return False, "Neplatný OpenAI API klíč (HTTP 401)."
    if r.status_code == 404:
        return False, f"Klíč je platný, ale model '{model}' není dostupný pro tento účet (HTTP 404)."
    if r.status_code == 429:
        return False, "Překročen limit (HTTP 429). Zkus to prosím za chvíli."
    if r.status_code == 403:
        return False, "Přístup zamítnut (HTTP 403). Zkontroluj oprávnění účtu/API."
    return False, f"OpenAI chyba: HTTP {r.status_code} – {r.text[:200]}"







# richmovie_open_ai.py — BRIDGE LOGGER (NÁHRADA)
# 2025-08-14 12:20 CEST (Europe/Prague)
# Spojka na plugin._ai_log s odolným fallbackem do RichMovie_a.i.log
class _AIProxy:
    """Proxy, která preferenčně loguje přes plugin._ai_log,
    ale při nedostupnosti pluginu zapíše přímo na disk.
    """

    def __init__(self) -> None:
        self._addon = xbmcaddon.Addon()  # vždy dostupné v Kodi prostředí

    def _resolve_ai_log_path(self) -> str:
        # special://profile/addon_data/<id>/RichMovie_a.i.log
        base = xbmcvfs.translatePath(
            f"special://profile/addon_data/{self._addon.getAddonInfo('id')}"
        )
        try:
            os.makedirs(base, exist_ok=True)
        except Exception:
            pass
        return os.path.join(base, "RichMovie_a.i.log")

    def _try_plugin(self):
        """Zkus najít živý modul plugin a jeho _ai_log/_ai_usage_consume."""
        try:
            import plugin as _plg  # typicky dostupné
            return _plg
        except Exception:
            pass
        try:
            import __main__ as _main
            if hasattr(_main, "_ai_log"):
                return _main
        except Exception:
            pass
        return None

    def _write_fallback(self, event: str, msg: str, details: dict | None, level: str) -> None:
        """Přímý zápis do RichMovie_a.i.log – RAW data neztratíme nikdy."""
        try:
            ts = datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")
            line = "\t".join([ts, (level or "INFO"), str(event), str(msg or "")])
            if details:
                try:
                    line += "\t" + json.dumps(details, ensure_ascii=False, separators=(",", ":"))
                except Exception:
                    pass
            path = self._resolve_ai_log_path()
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
            # Lehká stopa i do kodi.log, ale jen krátký popis
            try:
                xbmc.log(f"[RichMovie A.I.] {event} – {msg}", xbmc.LOGINFO)
            except Exception:
                pass
        except Exception:
            # nikdy nesmí shodit doplněk
            pass

    # — API shodné s pluginem — ------------------------------------------------
    def _ai_log(self, event: str, message: str = "", *, details: dict | None = None, level: str = "INFO") -> None:
        plg = self._try_plugin()
        if plg and hasattr(plg, "_ai_log"):
            try:
                plg._ai_log(event, message, details=details, level=level)  # delegace do pluginu
                return
            except Exception:
                # aťkoliv plugin existuje, logování nikdy nesmí selhat → fallback
                pass
        # fallback: přímý zápis
        self._write_fallback(event, message, details, level)

    def _ai_usage_consume(self, api_key: str, usage: dict, model: str = "gpt-5-mini") -> None:
        """Nepovinné – pokud plugin poskytuje účtování, delegujeme; jinak ticho."""
        plg = self._try_plugin()
        if plg and hasattr(plg, "_ai_usage_consume"):
            try:
                plg._ai_usage_consume(api_key, usage, model)
            except Exception:
                pass


# Nahraď původní _plg_mod tímto proxy objektem:
_plg_mod = _AIProxy()
