# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Pomocné třídy a funkce (SearchCache)
───────────────────────────────────────────────────────────────────────────────
Jednotná perzistentní cache výsledků vyhledávání (filmy + seriály).

• Každá položka má TTL 30 dní (pevně nastaveno – není v GUI).  
• Ukládá se do JSON v profilu doplňku:  
    special://profile/addon_data/plugin.video.richmovie/search_cache.json  
• API:  
      SEARCH_CACHE.get(key)  -> Optional[Any]  
      SEARCH_CACHE.put(key, value)  
      build_key(prefix, *parts)  -> str   # helper pro stabilní klíče

Autor: Richie – vytvořeno 28‑07‑2025 08:42 CEST
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY  (abecedně dle skupin)
# ─────────────────────────────────────────────────────────────────────────────
# — Standardní knihovna —
from __future__ import annotations

import datetime
import hashlib
import json
import threading
from pathlib import Path
from typing import Any, Optional

# — Kodi API —
import xbmcaddon
import xbmcvfs


# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
_TTL_SECS: int = 30 * 24 * 60 * 60          # 30 dní
_ADDON      = xbmcaddon.Addon()
_PROFILE    = Path(
    xbmcvfs.translatePath(f"special://profile/addon_data/{_ADDON.getAddonInfo('id')}")
)
_PROFILE.mkdir(parents=True, exist_ok=True)
_CACHE_PATH = _PROFILE / "search_cache.json"


# ─────────────────────────────────────────────────────────────────────────────
#  TŘÍDA  SearchCache
# ─────────────────────────────────────────────────────────────────────────────
class SearchCache:
    """
    Perzistentní JSON cache s TTL (30 dní).

    Klíčem je libovolný hash‑friendly string, hodnota může být jakýkoliv
    JSON‑serializovatelný objekt (typicky list slovníků → Release).
    """

    # 2025‑07‑28 08:42 CEST  – __init__
    def __init__(self, path: Path = _CACHE_PATH, ttl: int = _TTL_SECS) -> None:
        self._path = path
        self._ttl  = ttl
        self._data: dict[str, dict[str, Any]] = {}
        self._loaded = False
        self._lock   = threading.Lock()

    # – interní – -------------------------------------------------------------
    def _now(self) -> int:
        return int(datetime.datetime.now().timestamp())

    def _load(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            try:
                with open(self._path, "r", encoding="utf-8") as fh:
                    self._data = json.load(fh)
            except Exception:
                self._data = {}
            self._loaded = True
            self._purge_locked()

    def _flush_locked(self) -> None:
        try:
            with open(self._path, "w", encoding="utf-8") as fh:
                json.dump(self._data, fh, ensure_ascii=False, indent=2)
        except Exception:
            pass            # zápis cache nesmí shodit doplněk

    def _purge_locked(self) -> None:
        """Odstraní všechny položky starší než TTL."""
        cut = self._now() - self._ttl
        stale = [k for k, v in self._data.items() if v.get("ts", 0) < cut]
        for k in stale:
            del self._data[k]

    # – veřejné API – ---------------------------------------------------------
    # 2025‑07‑28 08:42 CEST  – get()
    def get(self, key: str) -> Optional[Any]:
        """
        Vrátí hodnotu z cache nebo ``None`` (nenalezeno či expirované).
        """
        self._load()
        with self._lock:
            rec = self._data.get(key)
            if not rec:
                return None
            if self._now() - rec.get("ts", 0) > self._ttl:
                # Expirace → smazat a vrátit None
                del self._data[key]
                self._flush_locked()
                return None
            return rec.get("val")

    # 2025‑07‑28 08:42 CEST  – put()
    def put(self, key: str, value: Any) -> None:
        """
        Zapíše (key, value) do cache a automaticky provede očistu starých
        záznamů.
        """
        self._load()
        with self._lock:
            self._data[key] = {"ts": self._now(), "val": value}
            self._purge_locked()
            self._flush_locked()

    # 2025‑07‑28 08:42 CEST  – build_key()
    @staticmethod
    def build_key(prefix: str, *parts: str) -> str:
        """
        Deterministicky vytvoří krátký hash‑klíč pro dané vstupy – hodí se,
        pokud potřebujeme složitý objekt zredukovat na jediný řetězec.
        """
        blob = "||".join(str(p) for p in parts)
        digest = hashlib.sha1(blob.encode()).hexdigest()
        return f"{prefix}:{digest}"


# — veřejná singleton instance —
SEARCH_CACHE = SearchCache()
