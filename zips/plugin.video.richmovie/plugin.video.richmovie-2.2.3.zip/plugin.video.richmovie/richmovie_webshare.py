# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Webshare SDK + autentizační a GUI helpery
───────────────────────────────────────────────────────────────────────────────
Tento modul slučuje **veškerou** logiku Webshare z původních souborů
`webshare_client.py` a fragmentů v `plugin.py` do jednoho, snadno udržovatelného
místa.

• **WebshareClient** – tenký wrapper nad REST API (původní implementace)
• **_JSONCache**     – lenivá JSON cache (stopáž, alt‑titles)
• **SessionManager** – odpovědný za token, login dialogy a VIP stav v GUI
• back‑compat funkce `_probe_cache_get / _probe_cache_put`

⚠️  DŮLEŽITÉ – VENDORED MediaInfo ⚠️
────────────────────────────────────
Doplněk obsahuje vlastní kopii:

    resources/lib/pymediainfo/
    resources/lib/libmediainfo.*   (Win / Linux x86 / ARM / arm64 …)

* `addon.xml` NESMÍ uvádět `<import addon="script.module.pymediainfo">`,
  aby instalace fungovala i bez repozitáře.
* Níže provádíme import v bloku try/except a uživateli jednou za relaci
  zobrazíme, zda se MediaInfo načetlo (pomáhá při ladění exotických boxů).

Autor: Richie (2023–2025) – refaktor 06/2025
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY  (ABECEDNĚ + tematické skupiny)
# ─────────────────────────────────────────────────────────────────────────────
# — Standardní knihovny —
from __future__ import annotations

import ctypes
import datetime
import hashlib
import io
import json
import logging
import os
import platform
import re
import shutil
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs




# — Lokální / projektové —
from tmdb_client import TMDbError


# --------------------------------------------------------------------------- #
#  MediaInfo – pokus o načtení vestavěné (vendored) knihovny
# --------------------------------------------------------------------------- #
try:
    from pymediainfo import MediaInfo                       # hledá v resources/lib
    MEDIAINFO_AVAILABLE = True
    xbmc.log("[RichMovie] MediaInfo OK – vendored copy loaded", xbmc.LOGDEBUG)
except ImportError:
    MEDIAINFO_AVAILABLE = False
    xbmc.log("[RichMovie] MediaInfo N/A – fall‑back na heuristický odhad stopáže", xbmc.LOGWARNING)




import requests                              # fallback HTTP klient

# — Dynamický import pluginu (kvůli sdílenému loggeru) —
try:
    import plugin as _plg_mod               # alias na _log_event a cesty k *.log
except Exception:
    _plg_mod = None

# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
API_URL      = "https://webshare.cz/api/"
PAGE_SIZE    = 100
ITOA64       = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

PROBE_CHUNK_KB = 256          # kolik KB stáhnout najednou při sondování
PROBE_MAX_MB   = 10           # horní limit dat ke stažení (MB)

# – Cesty k datovým a log souborům –
_ADDON       = xbmcaddon.Addon()
_PROFILE_DIR = Path(
    xbmcvfs.translatePath(f"special://profile/addon_data/{_ADDON.getAddonInfo('id')}")
)
_PROFILE_DIR.mkdir(parents=True, exist_ok=True)

_PROBE_CACHE_PATH      = _PROFILE_DIR / "probe_cache.json"
_ALT_TITLES_CACHE_PATH = _PROFILE_DIR / "alt_titles_cache.json"

_LOG_LOCK = threading.Lock()

# ─────────────────────────────────────────────────────────────────────────────
#  POMOCNÉ LOGOVACÍ FUNKCE
# ─────────────────────────────────────────────────────────────────────────────
def _log(msg: str) -> None:
    """Krátký INFO záznam do Kodi logu (viditelný v `~/.kodi/temp/kodi.log`)."""
    xbmc.log(f"[RichMovie] {msg}", xbmc.LOGINFO)


def _log_event(*parts: object) -> None:
    """
    Deleguje na ``plugin._log_event`` (pokud už je modul *plugin* načten).
    Mimo Kodi prostředí (např. unit‑test) zapisuje lokálně přes `_log()`.
    """
    if _plg_mod and hasattr(_plg_mod, "_log_event"):
        _plg_mod._log_event(*parts)         # type: ignore[attr-defined]
    else:
        _log(" | ".join(map(str, parts)))




def _handle_api_error(func, *args, **kwargs):
    """
    Ochranný wrapper: opakuje API volání až 3×, případně přepne jazyk (TMDb).

    Vrací výsledek volání, nebo znovu vyhazuje výjimku po vyčerpání pokusů.
    """
    max_retries = 3
    for attempt in range(1, max_retries + 1):
        try:
            return func(*args, **kwargs)
        except (APIError, TMDbError) as e:
            _log_event("API_ERROR", f"{func.__name__} attempt {attempt}: {e}")
            if attempt == max_retries:
                raise
            # speciální fallback pro TMDb – zkus EN
            if isinstance(e, TMDbError):
                kwargs["lang"] = "en-US"





def _probe_log(event: str, *params: object) -> None:
    """
    **Trvalý** logger pro sondování stopáže.

    ▸ vždy zapíše do rotačního logu (`richmovie_search.log`)  
    ▸ paralelně zapisuje i do souboru s příponou `.probe`
    """
    # 1) stopa v hlavním logu
    _log_event(event, *params)

    # 2) cesta k `.probe` souboru (sdílená s plugin.py)
    log_path = (
        getattr(_plg_mod, "_SEARCH_LOG_PATH", None)
        or getattr(_plg_mod, "_LOG_PATH", None)
        or xbmcvfs.translatePath("special://logpath/richmovie/fallback")
    ) + ".probe"

    # 3) zápis (thread‑safe)
    ts   = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = "\t".join([ts, event, *map(str, params)])
    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with _LOG_LOCK:
            with open(log_path, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except Exception:
        pass            # log nesmí nikdy shodit doplněk

# ─────────────────────────────────────────────────────────────────────────────
#  CACHE (lenivá JSON implementace)
# ─────────────────────────────────────────────────────────────────────────────
class _JSONCache:
    """
    Lenivě načítaná JSON cache *bez* proudového zápisu – uloží se jen při změně.

    Parametry
    ---------
    path : Path
        Soubor, do kterého se cache ukládá.
    """

    def __init__(self, path: Path) -> None:
        self._path   = path
        self._data   : dict[str, object] = {}
        self._loaded = False
        self._lock   = threading.Lock()

    # – interní –
    def _load(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            try:
                with open(self._path, "r", encoding="utf-8") as fh:
                    self._data = json.load(fh)
            except Exception:
                self._data = {}
            self._loaded = True

    def _flush(self) -> None:
        try:
            with self._lock:
                with open(self._path, "w", encoding="utf-8") as fh:
                    json.dump(self._data, fh, ensure_ascii=False, indent=2)
        except Exception as exc:
            _log(f"Cache flush failed: {exc}")

    # – veřejné API –
    def get(self, key: str) -> Optional[object]:
        self._load()
        return self._data.get(key)

    def put(self, key: str, value: object) -> None:
        self._load()
        self._data[key] = value
        self._flush()                   # okamžitý zápis → minimální riziko kolize

    def __len__(self) -> int:          # syntactic sugar → ``len(cache)``
        self._load()
        return len(self._data)


# Konkrétní cache instance (stopáž, alternativní názvy)
_ProbeCache     = _JSONCache(_PROBE_CACHE_PATH)
_AltTitlesCache = _JSONCache(_ALT_TITLES_CACHE_PATH)

# Back‑compat helpery (plugin.py na ně stále odkazuje)
def probe_cache_get(fid: str) -> Optional[int]:
    """Vrátí délku videa (sekundy) z cache nebo ``None``."""
    val = _ProbeCache.get(fid)
    return int(val) if isinstance(val, int) else None


def probe_cache_put(fid: str, seconds: int) -> None:
    """Uloží délku videa do cache."""
    _ProbeCache.put(fid, int(seconds))

# ─────────────────────────────────────────────────────────────────────────────
#  KRYPTOGRAFIE  (Webshare používá proprietární MD5‑crypt)
# ─────────────────────────────────────────────────────────────────────────────
def _to64(v: int, l: int) -> str:
    """Interní převodník pro MD5‑crypt."""
    s = ""
    while l:
        s += ITOA64[v & 0x3F]
        v >>= 6
        l -= 1
    return s


def md5_crypt(pw: str, salt: str, magic: str = "$1$") -> str:
    """
    Minimalistická implementace **MD5‑crypt** (nutná pro `/api/login/`).

    • Zkrácená a optimalizovaná verze – plně kompatibilní s PHP implementací  
    • Nekryptografická bezpečnost zde není kritická (hash posíláme po HTTPS)
    """
    salt = salt.split("$")[0][:8]
    pw_b = pw.encode()

    ctx = hashlib.md5()
    ctx.update(pw_b + magic.encode() + salt.encode())

    alt = hashlib.md5(pw_b + salt.encode() + pw_b).digest()
    for i in range(len(pw_b)):
        ctx.update(alt[i % 16 : i % 16 + 1])

    i = len(pw_b)
    while i:
        ctx.update(b"\x00" if i & 1 else pw_b[:1])
        i >>= 1

    final = ctx.digest()
    for i in range(1000):
        m = hashlib.md5()
        m.update(pw_b if i & 1 else final)
        if i % 3:
            m.update(salt.encode())
        if i % 7:
            m.update(pw_b)
        m.update(final if i & 1 else pw_b)
        final = m.digest()

    parts = (
        (final[0] << 16) | (final[6] << 8) | final[12],
        (final[1] << 16) | (final[7] << 8) | final[13],
        (final[2] << 16) | (final[8] << 8) | final[14],
        (final[3] << 16) | (final[9] << 8) | final[15],
        (final[4] << 16) | (final[10] << 8) | final[5],
        final[11],
    )
    enc = (
        _to64(parts[0], 4)
        + _to64(parts[1], 4)
        + _to64(parts[2], 4)
        + _to64(parts[3], 4)
        + _to64(parts[4], 4)
        + _to64(parts[5], 2)
    )
    return f"{magic}{salt}${enc}"

# ─────────────────────────────────────────────────────────────────────────────
#  VÝJIMKY KLIENTA
# ─────────────────────────────────────────────────────────────────────────────
class APIError(Exception):
    """Obecná chyba Webshare API (network error, HTTP 500…)."""


class TokenExpired(APIError):
    """Vypršela relace – je nutné se znovu přihlásit."""

# ─────────────────────────────────────────────────────────────────────────────
#  KLIENT WEBSHARE  (původní implementace beze změny)
# ─────────────────────────────────────────────────────────────────────────────
class WebshareClient:
    """
    Lehký wrapper nad REST API Webshare.cz
    -------------------------------------

    • login() / search() / file_info() / file_link()  
    • probe_duration() – přesný odhad stopáže (MediaInfo + HTTP range)  
    • get_alt_titles() – heuristická extrakce alternativních názvů
    """

    # ––– bootstrap MediaInfo knihovny (funguje na *všech* platformách) –––
    # ──────────────────────────────────────────────────────────────────
    #  KONSTRUKTOR
    # ──────────────────────────────────────────────────────────────────
    def __init__(self, token: str | None = None) -> None:
        """
        • uloží (volitelný) token
        • na Androidu zkopíruje libzen.so + libmediainfo.so do privátní
          cache aplikace, aby je linker mohl načíst
        • projde kandidáty knihoven v preferovaném pořadí a pokusí se je
          načíst přes ``ctypes.CDLL(mode=RTLD_GLOBAL)`` – na prvním úspěchu
          končí; selhání se jen zaloguje
        """
        self.token = token
        self._library_file: str | None = None      # absolutní cesta k nalezené .so

        # ░░░ Sandbox‑fix pro Android ░░░
        self._prepare_android_libs()

        # ░░░ Vlastní preload ░░░
        for cand in self._iter_mediainfo_candidates():
            if self._try_preload(cand):            # → True = úspěšně zavedená knihovna
                self._library_file = cand
                break
        else:
            _log("MediaInfo preload skipped – žádná binárka nešla načíst")





    def file_info_duration(self, ident: str) -> int | None:
        """
        Nejrychlejší cesta k délce videa – / api/file_info vrací <video_length>
        v sekundách.  Vrací int nebo None, nechytá výjimky.
        """
        root = self._post("file_info", ident=ident)
        try:
            secs = int(root.findtext("video_length", "0") or 0)
            return secs or None
        except ValueError:
            return None




    # ------------------------------------------------------------------ #
    #  ANDROID – jednorázově zkopírujeme libzen.so + libmediainfo.so
    #  do  /data/user/0/<pkg>/cache/richmovie/  (namespace-safe)
    # ------------------------------------------------------------------ #
    def _prepare_android_libs(self) -> None:
        """
        • Android: knihovny .so nesmí z /sdcard ⇒ zkopírujeme je do
          /data/user/0/<pkg>/cache/richmovie  (linker‑safe)
        • ostatní OS se této větve vůbec nedotknou
        """
        if platform.system().lower() != "linux" or "ANDROID_STORAGE" not in os.environ:
            return  # nejsme na Androidu

        # interní cache aplikace: special://xbmc  ->  …/cache/apk/assets
        # vezmeme parent.parent  ->  …/cache
        cache_root = Path(xbmcvfs.translatePath("special://xbmc")).parents[1]
        dst_dir    = cache_root / "richmovie"
        src_dir    = Path(__file__).resolve().parent / "resources/bin/armeabi-v7a"

        try:
            dst_dir.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            _log(f"Cache dir create failed: {exc}")
            return

        for name in ("libzen.so", "libmediainfo.so"):
            src = src_dir / name
            dst = dst_dir / name
            try:
                if src.exists() and (not dst.exists() or src.stat().st_mtime != dst.stat().st_mtime):
                    shutil.copy2(src, dst)
                    os.chmod(dst, 0o755)
                    _log(f"Copied {name} → {dst}")
            except Exception as exc:
                _log(f"Copy {name} failed: {exc}")

        # přidáme tento adresář na začátek seznamu kandidátů
        self._android_override = dst_dir
        _log(f"Android libs override: {dst_dir}")










    # ──────────────────────────────────────────────────────────────────
    #  _iter_mediainfo_candidates()
    #     → generátor vracející absolutní cesty v pořadí preference
    # ──────────────────────────────────────────────────────────────────

    def _iter_mediainfo_candidates(self):
        """
        Pořadí:
          1) interná cache (/data/…/cache/richmovie/) – pouze Android
          2) přesné mapování OS × architektur (resources/bin/<subdir>/…)
          3) speciální výjimka: 32‑bit ARM (armeabi‑v7a) na zařízeních
             s jádrem aarch64 / armv8l (Chromecast TV, Fire TV Stick 4K)
          4) libovolný soubor *mediainfo* nalezený rekurzivně ve stromu
             resources/bin/**  (poslední záchrana)
        """
        # ❶ interní cache (vzniká jen na Androidu)
        if getattr(self, "_android_override", None):
            yield str(self._android_override / "libmediainfo.so")

        root = Path(__file__).resolve().parent / "resources" / "bin"
        sys_os   = platform.system().lower()
        sys_arch = platform.machine().lower()

        mapping: dict[tuple[str, str], tuple[str, str]] = {
            ("windows", "amd64"):  ("win64",        "MediaInfo.dll"),
            ("windows", "x86"):    ("win32",        "MediaInfo.dll"),
            ("linux",   "x86_64"): ("x86_64",       "libmediainfo.so"),
            ("linux",   "aarch64"):("arm64-v8a",    "libmediainfo.so"),
            ("linux",   "armv8l"): ("arm64-v8a",    "libmediainfo.so"),
            ("linux",   "armv7l"): ("armeabi-v7a",  "libmediainfo.so"),
            ("darwin",  "arm64"):  ("darwin-arm64", "libmediainfo.dylib"),
            ("darwin",  "x86_64"): ("darwin-x86_64","libmediainfo.dylib"),
        }

        subdir, libname = mapping.get((sys_os, sys_arch), (None, None))
        tried: set[Path] = set()

        # ❷ přesné mapování
        if subdir:
            p = root / subdir / libname
            if p.exists():
                tried.add(p)
                yield str(p)

        # ❸ Chromecast / Fire TV: ARMv8 jádro, ale 32‑bit userspace
        if sys_os == "linux" and sys_arch in ("armv8l", "aarch64"):
            p = root / "armeabi-v7a" / "libmediainfo.so"
            if p.exists() and p not in tried:
                tried.add(p)
                yield str(p)

        # ❹ Fallback – první lib*mediainfo* v celém stromu
        patterns = {
            "windows": ["*MediaInfo.dll"],
            "linux":   ["*mediainfo.so"],
            "darwin":  ["*mediainfo.dylib"],
        }.get(sys_os, ["*mediainfo*"])

        for pat in patterns:
            for lib in root.rglob(pat):
                if lib not in tried:
                    yield str(lib)




    # ----------------------------------------------------------------- #
    #  HELPER 2 – samotný preload
    # ----------------------------------------------------------------- #
    @staticmethod
    def _try_preload(lib_path: str) -> bool:
        try:
            libdir = os.path.dirname(lib_path)
            dep = os.path.join(libdir, "libzen.so")
            if os.path.exists(dep):
                ctypes.CDLL(dep, mode=ctypes.RTLD_GLOBAL)
                _log(f"  ↳ libzen OK  ({dep})")
            ctypes.CDLL(lib_path, mode=ctypes.RTLD_GLOBAL)
            _log(f"MediaInfo preload OK ({lib_path})")
            return True
        except OSError as exc:
            _log(f"MediaInfo preload fail ({lib_path}): {exc}")
            return False




    # --------------------------------------------------------------------- #
    #  HELPERS
    # --------------------------------------------------------------------- #
    @staticmethod
    def _vendored_mediainfo_path() -> Optional[str]:
        """
        Vrátí absolutní cestu k přibalené `libMediaInfo.*` pro aktuální
        platformu.  Postup:
            1) pokus o přesné mapování (OS × arch) – tabulka `mapping`
            2) pokud selže, rekurzivně projde `resources/bin/**` a vezme
               první soubor odpovídající patternu *mediainfo*.

        Díky fallbacku funguje i na méně obvyklých hodnotách `platform.machine()`
        (např. „armv8l“ na některých Android TV zařízeních).
        """
        root = Path(__file__).resolve().parent / "resources" / "bin"
        sys_os   = platform.system().lower()
        sys_arch = platform.machine().lower()

        mapping: dict[tuple[str, str], tuple[str, str]] = {
            # (OS, arch)  →  (sub-dir, knihovna)
            ("windows", "amd64"):  ("win64",        "MediaInfo.dll"),
            ("windows", "x86"):    ("win32",        "MediaInfo.dll"),
            ("linux",   "x86_64"): ("x86_64",       "libmediainfo.so"),
            ("linux",   "aarch64"):("arm64-v8a",    "libmediainfo.so"),
            ("linux",   "armv8l"): ("arm64-v8a",    "libmediainfo.so"),  # Chromecast TV
            ("linux",   "armv8a"): ("arm64-v8a",    "libmediainfo.so"),
            ("linux",   "armv7l"): ("armeabi-v7a",  "libmediainfo.so"),
            ("darwin",  "arm64"):  ("darwin-arm64", "libmediainfo.dylib"),
            ("darwin",  "x86_64"): ("darwin-x86_64","libmediainfo.dylib"),
        }

        subdir, libname = mapping.get((sys_os, sys_arch), (None, None))
        if subdir:
            cand = root / subdir / libname
            if cand.exists():
                return str(cand)

        # –– Fallback: první soubor *mediainfo* v resources/bin ––
        patterns = {
            "windows": ["*MediaInfo.dll"],
            "linux":   ["*mediainfo.so"],
            "darwin":  ["*mediainfo.dylib"],
        }.get(sys_os, ["*mediainfo*"])

        for pat in patterns:
            for lib in root.rglob(pat):
                return str(lib)               # vezmeme první nalezený
        return None





    # --------------------------------------------------------------------- #
    def _post(self, func: str, **params):
        """Interní helper: POST → XML → ElementTree."""
        if self.token:
            params["wst"] = self.token
        data = urllib.parse.urlencode(params).encode()
        url  = f"{API_URL}{func}/"

        try:
            with urllib.request.urlopen(url, data=data, timeout=15) as r:
                body = r.read().decode()
        except Exception as e:
            _log(f"HTTP error: {e}")
            raise APIError("Síťová chyba") from e

        root = ET.fromstring(body)
        if root.findtext("status") != "OK":
            code = root.findtext("code") or "ERR"
            msg  = root.findtext("message") or "Unknown"
            _log(f"API {func} fail: {code} – {msg}")
            if code in ("SESSION_EXPIRED", "INVALID_TOKEN"):
                raise TokenExpired(msg)
            raise APIError(msg)
        return root

    # --------------------------------------------------------------------- #
    #                    VEŘEJNÉ API METODY
    # --------------------------------------------------------------------- #
    def login(self, user: str, pw: str) -> str:
        """Přihlášení – uloží a vrátí token."""
        salt   = self._post("salt", username_or_email=user).findtext("salt", "")
        digest = hashlib.sha1(md5_crypt(pw, salt).encode()).hexdigest()

        self.token = self._post(
            "login",
            username_or_email=user,
            password=digest,
            keep_logged_in=1,
        ).findtext("token", "")
        _log("login OK")
        return self.token

    # ------------------------------------------------------------------ #
    def account_info(self) -> dict:
        """Vrátí základní info o uživateli (VIP, kredit…)."""
        root = self._post("user_data")
        return {
            "username":  root.findtext("username", "") or "",
            "vip":       root.findtext("vip", "0") == "1",
            "vip_days":  int(root.findtext("vip_days", "0") or 0),
            "vip_until": root.findtext("vip_until", "") or "",
            "credit":    int(root.findtext("credit", "0") or 0),
        }

    # ------------------------------------------------------------------ #
    def file_link(
        self,
        ident: str,
        download_type: str | None = "video_stream",
        force_https: int = 1,
    ) -> str:
        """Vrátí přímý (VIP) odkaz na stream nebo download."""
        params = {"ident": ident, "force_https": force_https}
        if download_type:
            params["download_type"] = download_type
        return self._post("file_link", **params).findtext("link", "")

    # ------------------------------------------------------------------ #
    def file_info(self, ident: str) -> dict:
        """Detail souboru (viz `/api/file_info/`)."""
        root = self._post("file_info", ident=ident)
        _to_int = lambda x: int(x or 0)
        return {
            "ident":           ident,
            "name":            (root.findtext("name") or "").strip(),
            "size":            _to_int(root.findtext("size")),
            "password":        root.findtext("password", "0") == "1",
            "hash":            root.findtext("hash", ""),
            "video_length":    _to_int(root.findtext("video_length")),
            "video_width":     _to_int(root.findtext("video_width")),
            "video_height":    _to_int(root.findtext("video_height")),
            "audio_channels":  _to_int(root.findtext("audio_channels")),
            "positive_votes":  _to_int(root.findtext("positive_votes")),
            "negative_votes":  _to_int(root.findtext("negative_votes")),
            "downloads":       _to_int(root.findtext("downloads")),
            "created":         root.findtext("created", ""),
        }

    # ------------------------------------------------------------------ #
    def search(
        self,
        query: str,
        *,
        limit: int = PAGE_SIZE,
        offset: int = 0,
        file_type: str = "video",
    ) -> list[dict]:
        """Vyhledá soubory a vrátí list slovníků s metadata."""
        root = self._post(
            "search",
            what=query,
            offset=offset,
            limit=limit,
            type=file_type,
            order="relevance",
        )

        files: list[dict] = []
        for f in root.findall("file"):
            if f.findtext("removed") == "1":
                continue
            files.append(
                {
                    "ident":          f.findtext("ident", ""),
                    "name":           (f.findtext("name") or "").strip(),
                    "size":           int(f.findtext("size", "0") or 0),
                    "password":       f.findtext("password", "0") == "1",
                    "video_length":   int(f.findtext("video_length", "0") or 0),
                    "video_width":    int(f.findtext("video_width", "0") or 0),
                    "video_height":   int(f.findtext("video_height", "0") or 0),
                    "positive_votes": int(f.findtext("positive_votes", "0") or 0),
                    "negative_votes": int(f.findtext("negative_votes", "0") or 0),
                }
            )
        _log(f'search "{query}" → {len(files)} files')
        return files





    # ------------------------------------------------------------------ #
    def probe_duration(self, ident: str) -> Optional[int]:
        """
        Heuristicky změří reálnou stopáž souboru **bez** stahování celého videa
        a **po 256 kB blocích** (Range).  Čím dříve MediaInfo nalezne délku,
        tím dříve se smyčka ukončí.

        Postup
        ------
        1)  cache (`probe_cache_get`)
        2)  /file_info/ (pole `video_length`)
        3)  **iterativní HTTP Range** → MediaInfo.parse(buf) – každých 256 kB
            ▸ zapisuje `PROBE_SEG` a finální `PROBE_MI_LEN`
        """
        # ❶  cache
        if (cached := probe_cache_get(ident)) is not None:
            _probe_log("PROBE_CACHE_HIT", ident, cached)
            return cached

        # ❷  info z API (pokud Webshare délku zná)
        try:
            finfo = self.file_info(ident)
        except APIError:
            return None
        if finfo.get("video_length"):
            secs = int(finfo["video_length"])
            probe_cache_put(ident, secs)
            _probe_log("PROBE_API_LEN", ident, secs)
            return secs

        # ❸  fallback: MediaInfo + **iterativní** Range
        url        = self.file_link(ident, download_type=None)
        chunk_size = PROBE_CHUNK_KB * 1024                         # 256 kB
        max_bytes  = PROBE_MAX_MB * 1024 * 1024                    # 10 MB
        offset     = 0
        seg_no     = 0
        buf        = io.BytesIO()

        try:
            while offset < max_bytes:
                end     = min(offset + chunk_size - 1, max_bytes - 1)
                headers = {"Range": f"bytes={offset}-{end}"}
                with requests.get(url, headers=headers, timeout=15) as r:
                    buf.write(r.content)
                seg_no += 1
                _probe_log("PROBE_SEG", ident, seg_no, len(r.content))
                offset += chunk_size

                # zkusíme parsovat dřív, než stáhneme max_bytes
                dur = self._try_parse_duration(buf)
                if dur:
                    probe_cache_put(ident, dur)
                    _probe_log("PROBE_MI_LEN", ident, dur, seg_no)
                    return dur
        except Exception as exc:
            _probe_log("PROBE_FAIL", ident, exc)
        return None




    # ------------------------------------------------------------------ #
    def probe_mediainfo(self, ident: str) -> dict | None:
        """
        Vrátí **detailní MediaInfo** bez stahování celého souboru.
        Stahuje po 256 kB blocích až do zjištění délky nebo vyčerpání limitu.
        """
        try:
            url = self.file_link(ident, download_type=None)
        except APIError:
            return None

        chunk_size = PROBE_CHUNK_KB * 1024
        max_bytes  = PROBE_MAX_MB * 1024 * 1024
        offset     = 0
        seg_no     = 0
        buf        = io.BytesIO()

        try:
            while offset < max_bytes:
                end     = min(offset + chunk_size - 1, max_bytes - 1)
                headers = {"Range": f"bytes={offset}-{end}"}
                with requests.get(url, headers=headers, timeout=15) as r:
                    buf.write(r.content)
                seg_no += 1
                _probe_log("PROBE_SEG", ident, seg_no, len(r.content))
                offset += chunk_size

                if self._try_parse_duration(buf):        # délka už známa
                    break
        except Exception as exc:
            _probe_log("PROBE_MI_FAIL", ident, exc)
            return None

        # finální úplné parsování (tracks → dict)
        buf.seek(0)
        mi = MediaInfo.parse(buf, library_file=self._library_file or None)
        data = {
            "duration": int((next(                      # prefer General track
                (t.duration for t in mi.tracks
                 if t.track_type == "General" and t.duration),
                mi.tracks[0].duration if mi.tracks else 0
            ) or 0) / 1000),
            "tracks": [t.to_data() for t in mi.tracks],
        }
        _probe_log("PROBE_MI_OK", ident, data["duration"], seg_no)
        return data


    # ------------------------------------------------------------------ #
    def _try_parse_duration(self, buf: io.BytesIO) -> int | None:
        """
        Pomocná interní rutina: z aktuálního bufferu zkusí vydolovat délku.
        Vrací délku v sekundách (int) nebo None, pokud MediaInfo zatím
        potřebná metadata nenašel.
        """
        pos = buf.tell()
        try:
            buf.seek(0)
            mi = MediaInfo.parse(buf, library_file=self._library_file or None)
            dur_ms = next(
                (t.duration for t in mi.tracks
                 if t.track_type == "General" and t.duration),
                None
            ) or (mi.tracks[0].duration if mi.tracks else 0)
            return int(dur_ms / 1000) if dur_ms else None
        finally:
            buf.seek(pos)



    # ------------------------------------------------------------------ #
    #                      ALT‑TITLES (heuristické)
    # ------------------------------------------------------------------ #
    def get_alt_titles(self, tmdb_id: str | int) -> list[str]:
        """
        Vrátí *alternativní názvy* filmu podle TMDb ID.

        • Nejprve zkusí lokální cache  
        • Pak heuristicky prohledá Webshare (``search()``) a výsledek uloží
        """
        fid = str(tmdb_id)
        cached = _AltTitlesCache.get(fid)
        if cached:
            return list(cached)            # type: ignore[arg-type]

        alt: set[str] = set()
        try:
            for f in self.search(fid, limit=50):
                alt.add(f["name"])
        except Exception as exc:
            _log_event("ALT_TITLES_FAIL", fid, exc)

        titles = sorted(alt)
        _AltTitlesCache.put(fid, titles)
        _log_event("ALT_TITLES_CACHE_PUT", fid, len(titles))
        return titles

# ─────────────────────────────────────────────────────────────────────────────
#  SESSION MANAGER  (token + GUI helpery)
# ─────────────────────────────────────────────────────────────────────────────
class SessionManager:
    """
    Vyšší vrstva nad **WebshareClient** zajišťující:

    • získání klienta s uloženým tokenem  
    • login (tichý i interaktivní) s dialogem a retry  
    • aktualizaci VIP stavu v titulku hlavního menu
    """

    def __init__(self, addon: xbmcaddon.Addon, handle: int) -> None:
        self._addon  = addon
        self._handle = handle
        self.client  = WebshareClient(addon.getSetting("token") or None)

    # ───────────────────────────────────────────────────────────────────
    #  LOGIN WORKFLOW
    # ───────────────────────────────────────────────────────────────────
    def ensure_login(
        self, *, interactive: bool = False, max_attempts: int = 3
    ) -> None:
        """
        Zajistí platný token – může zobrazit přihlašovací dialog.
        Logika vychází z původního _ensure_login().
        """
        user  = self._addon.getSetting("username").strip()
        pw    = self._addon.getSetting("password").strip()
        token = self._addon.getSetting("token").strip()

        # 1) sirotek tokenu → zahodit
        if token and (not user or not pw):
            _log_event("LOGIN_ORPHAN_TOKEN", "token smazán – chybí cred")
            token = ""
            self._addon.setSetting("token", "")

        # 2) hotovo (token + cred)
        if token and user and pw:
            self.client.token = token
            return

        # 3) tichý login
        if user and pw:
            self.client.token = None
            try:
                self.client.login(user, pw)
                self._addon.setSetting("token", self.client.token)
                _notify("Úspěšně přihlášeno k Webshare.cz")
                _log_event("WEB_SHARE_LOGIN_OK_SILENT")
                return
            except APIError as e:
                _log_event("WEB_SHARE_LOGIN_SILENT_FAIL", str(e))
                # padáme na interaktivní dialog

        # 4) interaktivní kolečko
        if not interactive:
            interactive = True

        attempt = 0
        while attempt < max_attempts:
            user, pw = self._prompt_credentials()
            if not user or not pw:
                raise APIError("Přihlášení zrušeno uživatelem.")

            try:
                self.client.login(user, pw)
            except APIError as err:
                attempt += 1
                _log_event("WEB_SHARE_LOGIN_FAIL", f"attempt {attempt}", str(err))

                # ── NOVÉ: pouze 2 parametry ─────────────────────────
                msg = f"Chyba: {err}"
                if attempt < max_attempts:
                    msg += "\nZkuste to prosím znovu."
                xbmcgui.Dialog().ok("Webshare přihlášení", msg)
                # ----------------------------------------------------
                continue
            else:
                # uložíme do settings
                self._addon.setSetting("username", user)
                self._addon.setSetting("password", pw)
                self._addon.setSetting("token",    self.client.token)
                _notify("Úspěšně přihlášeno k Webshare.cz")
                _log_event("WEB_SHARE_LOGIN_OK_INTERACTIVE")
                return

        raise APIError("Nepodařilo se přihlásit k Webshare.cz.")





    # 2025-08-16 23:20 CEST (Europe/Prague) – rozšířeno: ukládáme vip_active/vip_days_left/vip_until
    def update_vip_status(self) -> None:
        """
        Aktualizuje GUI titulek a nastavení **vip_info**.

        • Při ONLINE stavu (API OK) zobrazí VIP / Free informace beze změny.
        • Při OFF‑LINE stavu:
              – uloží čitelnou hlášku
              – zobrazí toast „Offline – není přístup k internetu 🌐“
              – po dokončení toastu **automaticky ukončí plugin**
                (vyskočí zpět do seznamu doplňků).
        """
        OFF_MSG = "Offline – není přístup k internetu 🌐"

        try:
            info = self.client.account_info()  # ⇨ ONLINE?
        except (APIError, TokenExpired):
            # ── OFF‑LINE režim ────────────────────────────────────────────
            self._addon.setSetting("vip_info", OFF_MSG)

            # NOVĚ: vynuluj pomocné klíče pro rozhodování o toastu
            self._addon.setSetting("vip_active", "0")
            self._addon.setSetting("vip_days_left", "")
            self._addon.setSetting("vip_until", "")

            if self._handle >= 0:
                xbmcplugin.setPluginCategory(self._handle, f"RichMovie ({OFF_MSG})")

            xbmcgui.Dialog().notification(
                "RichMovie", OFF_MSG, xbmcgui.NOTIFICATION_ERROR, 4000
            )
            _log_event("VIP_STATUS", "OFFLINE")

            xbmc.sleep(4000)
            xbmc.executebuiltin("Action(Back)")
            return

        # ── ON‑LINE režim ──────────────────────────────────────────────────
        if self._handle >= 0:
            if info.get("vip"):
                xbmcplugin.setPluginCategory(
                    self._handle,
                    f"RichMovie (VIP {info.get('vip_days', 0)} dní)"
                )
            else:
                xbmcplugin.setPluginCategory(self._handle, "RichMovie (Free)")

        vip_text = (
            f"{info.get('username', '')} – VIP ještě "
            f"{info.get('vip_days', 0)} dní "
            f"(do {info.get('vip_until', '')})"
            if info.get("vip") else
            f"{info.get('username', '')} – Free účet"
        )
        self._addon.setSetting("vip_info", vip_text)

        # NOVĚ: ulož pomocná pole pro UI anti‑spam (1× denně / urgent <24h)
        self._addon.setSetting("vip_active", "1" if info.get("vip") else "0")
        self._addon.setSetting("vip_days_left", str(info.get("vip_days", 0)))
        self._addon.setSetting("vip_until", info.get("vip_until", "") or "")

        _log_event("VIP_STATUS", info.get("vip_days", 0))





    # ----------------------------------------------------------------- #
    def _prompt_credentials(self) -> tuple[str | None, str | None]:
        """
        Jednoduchý dialog s Kodi klávesnicí.

        Vrací: (username, password) – může obsahovat ``None``, pokud uživatel
        stiskl *Cancel*.
        """
        user = _keyboard_input("Uživatelské jméno Webshare")
        if not user:
            return None, None
        pw = _keyboard_input("Heslo k Webshare", hidden=True)
        if not pw:
            return None, None
        return user, pw









# ─────────────────────────────────────────────────────────────────────────────
#  MALÉ POMOCNÉ FUNKCE (UI, notifikace, klávesnice)
# ─────────────────────────────────────────────────────────────────────────────
def _keyboard_input(heading: str, hidden: bool = False) -> str | None:
    kb = xbmc.Keyboard("", heading, hidden)
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else None


def _notify(msg: str,
            lvl: int = xbmcgui.NOTIFICATION_INFO,
            ms: int = 4000) -> None:
    """Krátká Kodi notifikace + echo do logu."""
    xbmcgui.Dialog().notification("RichMovie", msg, lvl, ms)
    _log(msg)
