# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Vyhledávací a filtrační **ENGINE**
───────────────────────────────────────────────────────────────────────────────
Tento modul koncentruje *veškeré* know‑how doplňku RichMovie týkající se:

  • sestavení dotazů a paralelního volání API Webshare.cz  
  • heuristické filtrace a rankingu releaseů (kvalita, velikost, délka filmu)  
  • deduplikace a označení ★ MATCH (±5 min od cílové stopáže)  
  • parsování jazyků, bitrate a normalizace názvů  
  • čisté datové objekty → **žádná** závislost na Kodi!  
    (GUI si řeší až plugin.py pomocí `LabelFormatter`).

Při refaktoru (06/2025) jsme zachovali 100 % původní logiku i výstupní formát,
pouze kód rozdělili na srozumitelné třídy:

* `SearchEngine` – orchestrace dotazů; veřejné API `search_one()` a `search_wave()`  
* `ReleaseFilter` – statická pravidla pro vyřazení/obohacení WS souborů  
* `LabelFormatter` – převod `Release` → slovník s texty pro GUI  
* pomocné util‑funkce `norm()`, `base_title_key()`, `quality()`, `parse_langs()`

Autor: Richie (2023–2025), refaktor © VİÝVOJ  
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

# — Standard lib —
import concurrent.futures as _f
import contextlib                 # ← NOVĚ – pro _quick_duration()
import functools  
import hashlib                   # ← NOVĚ – pro tvorbu cache klíče
from itertools import permutations  # permutace aliasů (movie queries)
import json
import os
import re
import threading
import unicodedata
from dataclasses import asdict, dataclass, field
from typing import Callable, Iterable, List, Optional, Sequence, Tuple

from collections.abc import Callable  # přidejte jednou mezi importy
from collections import OrderedDict        # pořadí bez duplicit v QueryBuilder




# — 3rd‑party —
import requests                   # ← NOVĚ – pro HTTP HEAD v _quick_duration()

# – Kodi GUI (pouze pro _SearchProgress) –
import xbmcgui

# – Lokální moduly –
from richmovie_helpers import SEARCH_CACHE         # ← NOVÝ modul
from richmovie_webshare import (
    APIError,
    WebshareClient,
    probe_cache_get,
    probe_cache_put,
)

from tmdb_client import TMDb, TMDbError


# ─────────────────────────────────────────────────────────────────────────────
#  DALŠÍ KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
# Slova, která se ve jménech epizod vyskytují extrémně často a sama o sobě
# nejsou pro vyhledávání směrodatná („Episode 1“, „Pilot“, „Úvod“ apod.).
GENERIC_EP: set[str] = {
    # — anglicky —
    "episode", "ep", "pilot", "part", "chapter", "segment", "beginning", "start",
    # — česky/slovensky —
    "epizoda", "pilotní", "pilotni", "díl", "dil", "část", "cast",
    "úvod", "uvod", "od", "zacatek", "začátek", "zacatku", "začátku",
    # — další jazyky (běžné “Episode 1”) —
    "capitulo", "capitolo",
}









# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY  (sdílené i s plugin.py – ten je může importovat odsud)
# ─────────────────────────────────────────────────────────────────────────────
QUALITY_RANK = {               # nižší index = lepší
    "2160p": 0,
    "1080p": 1,
    "720p":  2,
    "480p":  3,
    "webrip": 4,
    "other":  5,
    "cam":    6,
}

BITRATE_MBPS = {               # odhad bit‑raty → _bytes_to_minutes()
    "2160p": 25,
    "1080p": 10,
    "720p":   6,
    "480p":   4,
    "webrip": 5,
    "other":  4,
    "cam":    3,
}

# — filtry —
ALLOWED_VIDEO_EXTS = {
    ".mkv", ".mp4", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".webm",
}

MIN_FILE_MB_BY_QUALITY = {
    "2160p": 2000, "1080p": 700, "720p": 350,
    "webrip": 300, "other": 250, "cam": 0,
}

MATCH_TOL         = 5      # ± minut pro ★ MATCH
LEN_TOL_SHORT     = 10
LEN_TOL_LONG      = 40
PROBE_MAX_RESULTS = 15
MAX_WS_RESULTS    = 120

# 2025‑07‑27 23:58 CEST  – úprava: regex zachytí i „_2017_“, „.2011.“
YEAR_RE = re.compile(r"(?<!\d)(19[5-9]\d|20[0-4]\d)(?!\d)")




PROBE_CHUNK_KB  = 512      # kolik dat stáhneme v jednom „kusu“
PROBE_MAX_KB    = 10_240   # hard-limit ≈ 10 MB


_BAD_REGEX_DEFAULT = re.compile(r"\b(trailer|sample|clip|preview)\b", re.I)


# ── filmové epizody (SxxEyy / 01x02[a‑z]) – u filmů je zakážeme úplně ──
_BAD_REGEX_MOVIE = re.compile(
    r'\b(?:s\d{1,2}e\d{1,2}[a-z]?|\d{1,2}x\d{1,2}[a-z]?)\b',   # S01E02a · 01x02b …
    re.I,
)





# ─────────────────────────────────────────────────────────────────────────────
#  UTIL FUNKCE – veřejné, aby je mohl používat i plugin.py
# ─────────────────────────────────────────────────────────────────────────────
def norm(s: str) -> str:
    """Odstraní diakritiku, lower‑case, ne‑alfa znaky → mezera, kolaps mezer."""
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    s = re.sub(r"[^0-9a-z]+", " ", s.lower()).strip()
    return re.sub(r"\s{2,}", " ", s)

# ––– kompatibilní alias pro staré volání –––
_norm = norm      # ← ⬅⬅⬅  **PŘIDEJTE TENTO ŘÁDEK**


def base_title_key(name: str) -> str:
    """
    Normalizovaný “kořen” názvu bez koncové číslovky/římské číslice.
    Usnadňuje deduplikaci různých releasů téhož filmu.
    """
    key = norm(name)
    key = re.sub(r'\b(?:part|episode|d[ií]l)\s+[0-9ivx]+$', '', key)
    key = re.sub(r'\s+(?:(?:[2-9]|1[0-9])(?!\d)|[ivx]{2,5})$', '', key)
    return re.sub(r'\s+', ' ', key).strip()


# --------------------------------------------------------------------------- #
# 2025‑07‑19 16:27  _is_adult_title() – final FIX (jediná verze v souboru)
# --------------------------------------------------------------------------- #
def _is_adult_title(title: str) -> bool:
    """
    Heuristicky odhadne, zda `title` naznačuje erotický obsah.

    Postup:
    1) Odstraní čtyřciferné roky a kódy SxxEyy / 01x02.
    2) Normalizuje řetězec (bez diakritiky, lowercase, kolaps mezer).
    3) Vrací True, pokud zůstane alespoň jedno erotické klíčové slovo.
    """
    # 1 • čistění
    cleaned = _RE_SXXEYY.sub("", title)
    cleaned = _RE_XXYY.sub("", cleaned)
    cleaned = re.sub(r"\b\d{4}\b", "", cleaned)

    # 2 • normalizace
    title_norm = norm(cleaned)

    # 3 • test klíčových slov
    return any(kw in title_norm for kw in (norm(w) for w in EROTIC_KEYWORDS))




@functools.lru_cache(maxsize=128)
def spin_tokens(
    tv_id: str,
    tmdb_key: str | None,
    *,
    lang: str = "en-US",
    logger: 'Callable[..., None]' | None = None,
) -> tuple[set[str], set[str]]:
    """
    2025-08-08 23:40 CEST – BUGFIX: bezpečný výběr root_word + preferuj „name“ před „original_name“ u ne‑latinky.

    Vrátí dvojici množin **(allow_tokens, ban_tokens)**, které spolehlivě
    rozlišují spin‑offy v rámci jedné franšízy (Stargate SG‑1 / Atlantis /
    Universe …).

    Parametry
    ---------
    tv_id      : TMDb ID aktuálního seriálu.
    tmdb_key   : TMDb API klíč.
    lang       : Jazyk pro TMDb dotazy (výchozí "en-US").
    logger     : Volitelný log handler (event, *params).

    Návrat
    ------
    (allow, ban) – dvojice *set(str)*, každá tokeny v lower‑case bez diakritiky.

    • **allow** – slova charakteristická pro _aktuální_ seriál
    • **ban**   – slova charakteristická pro _ostatní_ spin‑offy
    """
    # – 0) příprava loggeru ---------------------------------------------------
    log = logger or (lambda *_, **__: None)

    # – 1) validace vstupů ----------------------------------------------------
    if not (tv_id and tmdb_key):
        return set(), set()

    tmdb = TMDb(tmdb_key, lang=lang, logger=log)

    # – 2) zjistíme „kořenové“ slovo franšízy (bez pádu na prázdném řetězci) --
    try:
        me = tmdb._get_json(f"/tv/{tv_id}", {"api_key": tmdb_key, "language": lang})
        # Preferujeme `name` (lokalizovaný/EN), protože `original_name` může
        # obsahovat znaky mimo latinku (např. korejština) → po `norm()` by zbylo "".
        candidates = [me.get("name", ""), me.get("original_name", "")]
        root_word = ""
        for cand in candidates:
            words = norm(cand).split()
            if words:
                root_word = words[0]
                break

        # Fallback: zkusíme alternativní názvy, dokud nenajdeme první latinský token
        if not root_word:
            try:
                alts_json = tmdb._get_json(
                    f"/tv/{tv_id}/alternative_titles",
                    {"api_key": tmdb_key},
                )
                for rec in alts_json.get("results", []):
                    words = norm(rec.get("title", "")).split()
                    if words:
                        root_word = words[0]
                        break
            except TMDbError:
                pass

        if not root_word:
            return set(), set()
    except TMDbError:
        return set(), set()

    # – 3) najdeme všechny seriály se stejným kořenem ------------------------
    try:
        siblings = tmdb.search_tv(root_word, limit=30)
    except TMDbError:
        siblings = []

    def _tokens(title: str) -> set[str]:
        """Normalizované tokeny – bez kořenového slova („stargate“…)."""
        return {w for w in norm(title).split() if w and w != root_word}

    allow: set[str] = set()
    ban:   set[str] = set()

    for show in siblings:
        show_id = str(show["id"])
        toks    = _tokens(show.get("name") or show.get("original_name", ""))

        if show_id == str(tv_id):            # ➜ aktuální seriál → allow
            allow |= toks
            # + alternativní názvy (cz/sk/…)
            try:
                alts = tmdb._get_json(
                    f"/tv/{show_id}/alternative_titles",
                    {"api_key": tmdb_key},
                )
                for rec in alts.get("results", []):
                    allow |= _tokens(rec.get("title", ""))
            except TMDbError:
                pass
            continue

        # jiné spin‑offy → ban
        ban |= toks
        try:
            alts = tmdb._get_json(
                f"/tv/{show_id}/alternative_titles",
                {"api_key": tmdb_key},
            )
            for rec in alts.get("results", []):
                ban |= _tokens(rec.get("title", ""))
        except TMDbError:
            pass

    # – 4) vzájemné vyloučení + návrat ---------------------------------------
    ban -= allow
    log("SPIN_TOKENS", tv_id, f"allow={len(allow)} ban={len(ban)}")
    return allow, ban



# --------------------------------------------------------------------------- #
#  ADULT / EROTIC FILTER
# --------------------------------------------------------------------------- #
EROTIC_KEYWORDS: set[str] = {
    "porno", "porn", "xxx", "hentai", "bdsm", "lesb", "gay",
    "amateur", "orgasm", "anal", "cum", "cream", "hardcore",
    "fetish", "milf", "teen", "schoolgirl", "gangbang",
    "péčko", "erot", "sex",
}

_RE_SXXEYY = re.compile(r"[Ss]\d{1,2}[Ee]\d{1,2}")
_RE_XXYY   = re.compile(r"\d{1,2}[xX]\d{1,2}")






# ── ALT-TITLE FALLBACK KONSTANTY ───────────────────────────────────────
_ALT_THRESHOLD           = 4      # kolik releasů stačí k ukončení fallbacku
_ALT_MAX_TITLES          = 6      # max. alternativních názvů, které zkoušíme
_ALT_COUNTRY_WHITELIST   = {"CZ", "SK", "US", "GB", "CA", "PL"}
_NON_LATIN_RE            = re.compile(r"[\u0400-\u04FF\u4E00-\u9FFF]")
# ───────────────────────────────────────────────────────────────────────











_LANG_MAP: dict[str, str] = {
    # čeština
    "cz": "CZ", "czech": "CZ", "ces": "CZ", "čes": "CZ", "cesky": "CZ",
    # slovenština
    "sk": "SK", "slovak": "SK", "slovensky": "SK",
    # angličtina
    "en": "EN", "eng": "EN", "english": "EN",
    # němčina
    "de": "DE", "ger": "DE", "german": "DE", "deu": "DE",
    # francouzština
    "fr": "FR", "fre": "FR", "french": "FR",
    # španělština
    "es": "ES", "spa": "ES", "spanish": "ES",
}

_SUB_HINT = re.compile(r"\b(sub|srt|tit|titulky|titles?)\b", re.I)
_DUB_HINT = re.compile(r"\b(dab|dub|dubbing|audio)\b",       re.I)


def parse_langs(name: str) -> Tuple[List[str], List[str]]:
    """
    Detekuje ISO kódy jazyků (audio, titulky) v názvu souboru.  
    Vrací dvojici `(audios, subs)` – seznamy dvoupísmenných kódů.
    """
    n = name.lower()
    aud, sub = set(), set()

    for word in re.split(r"[\W_]+", n):
        code = _LANG_MAP.get(word)
        if not code:
            continue
        if _SUB_HINT.search(n) and not _DUB_HINT.search(n):
            sub.add(code)
        else:
            aud.add(code)

    return sorted(aud), sorted(sub)


_QUAL_PATTERNS = [
    ("2160p", re.compile(r'(2160p|\b4k\b|\buhd\b)', re.I)),
    ("1080p", re.compile(r'(1080p|full\.?hd)',       re.I)),
    ("720p",  re.compile(r'720p',                    re.I)),
    ("480p",  re.compile(r'(480p|\bsd\b)',           re.I)),
    ("webrip",re.compile(r'(webrip|web[-_.]?dl|hdrip|dvdrip)', re.I)),
    ("cam",   re.compile(r'\b(cam|hd[-_.]?ts|telesync|ts)\b',  re.I)),
]


def quality(name: str) -> str:
    """Heuristicky odhadne kvalitu release (‘2160p’, ‘1080p’, … ‘cam’)."""
    for q, pat in _QUAL_PATTERNS:
        if pat.search(name):
            return q
    return "other"


















# ─────────────────────────────────────────────────────────────────────────────
#  DATOVÉ TŘÍDY
# ─────────────────────────────────────────────────────────────────────────────
@dataclass(unsafe_hash=True)
class Release:
    ident:   str
    name:    str
    size:    int                       # B
    quality: str                       # viz quality()
    audios:  List[str] = field(default_factory=list)
    subs:    List[str] = field(default_factory=list)
    est_min: Optional[int] = None      # odhad délky (min)
    match:   bool = False              # ★ MATCH?
    score:   int = 0                   # agregované pořadí (nižší = lepší)

    # – derived –
    @property
    def size_mb(self) -> int:
        return round(self.size / 1_048_576)





# --------------------------------------------------------------------------- #
# 2025‑07‑20 10:45 CEST  class QueryBuilder  – centrální generátor dotazů
# --------------------------------------------------------------------------- #
class QueryBuilder:
    """
    **Jediné místo**, kde se sestavují vyhledávací řetězce pro Webshare.

    ▸ *Bez* závislosti na Kodi ani Webshare SDK  
    ▸ Vrací **list** v pořadí, jak bylo požadováno, ale se 100 % deduplikací  
    ▸ Metoda `tv()` implementuje všech 26 variant z vašeho scénáře  
      („S04E06 Window of Opportunity“, „Stargate SG‑1 4x06“, …)  
    ▸ Metoda `movie()` je 1‑to‑1 přesunutá stará `build_movie_queries()`
      (logika **zůstává nedotčená**).
    """

    # ––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    @staticmethod
    def _unique_seq() -> tuple[list[str], set[str]]:
        """Pomocný factory: (ordered list, seen‑set)."""
        return ([], set())




    # 2025‑08‑09 00:51 CEST  • QueryBuilder.tv() – zákaz „pilot“ v dotazech (nikdy)
    @staticmethod
    def tv(
        tv_names: Sequence[str],
        ep_names: Sequence[str],
        season: int,
        episode: int,
    ) -> list[str]:
        """
        Sestaví **unikátní** sadu dotazů pro TV epizodu (SxxEyy / 1xYY atd.).

        Zachována původní logika priorit (A→B→C→D), pouze **nikdy nezahrnujeme
        epizodní názvy obsahující „pilot“** (ani „pilotní“). Tím eliminujeme
        lavinu cizích „Pilot“ výsledků na Webshare.

        Kroky (shrnutí):
          1) kódy epizody (SxxEyy, 1xYY, 01xYY) ± krátký token seriálu
          2) název seriálu + NEobecný název epizody
          3) název(krátký) seriálu + kód epizody
          4) název seriálu + název epizody (s výjimkou „pilot“)
        """
        # --- lokální helpery -------------------------------------------------
        def _short_token(name: str) -> str:
            """První 2–3 písmena z 1. slova – stabilní a krátké."""
            m = re.match(r"\w{2,3}", name)
            return m.group(0) if m else ""

        def _is_generic(ep: str) -> bool:
            """Je epizodní název příliš obecný (Epizoda 1, Episode 1, apod.)?"""
            for w in re.split(r"[^\w]+", ep.lower()):
                if w.isdigit():
                    return True
                if w in GENERIC_EP:  # obsahuje mj. "pilot", "pilotní" apod.
                    return True
            return False

        def _has_pilot(ep: str) -> bool:
            """Obsahuje název epizody zakázané slovo 'pilot' (vč. 'pilotní')?"""
            for w in re.split(r"[^\w]+", ep.lower()):
                if w in {"pilot", "pilotni", "pilotní"}:
                    return True
            return False

        # --- příprava aliasů -------------------------------------------------
        tv_names = [t.strip() for t in tv_names if t and t.strip()]
        ep_names = [e.strip() for e in ep_names if e and e.strip()]

        # Klíčové: *vyřadíme* jakékoliv epizodní názvy obsahující "pilot"
        ep_names_no_pilot = [e for e in ep_names if not _has_pilot(e)]

        # --- kódy epizody ----------------------------------------------------
        sxe  = f"s{season:02d}e{episode:02d}"
        xep1 = f"{season}x{episode:02d}"
        xep2 = f"{season:02d}x{episode:02d}"

        out = OrderedDict()  # zachová pořadí přidání + eliminuje duplicity

        # 3‑A) samotné kódy epizody + krátký token seriálu (NE generická epizoda)
        for nm in tv_names:
            short_tok = _short_token(nm)
            if not short_tok:
                continue
            for code in (sxe, xep1, xep2):
                # generické názvy (vč. 'pilot') explicitně zahazujeme
                for ep in ep_names_no_pilot:
                    if _is_generic(ep):
                        continue
                out[f"{code} {short_tok}"] = None

        # 3‑B) jméno seriálu + NEobecný název epizody (a zároveň NE 'pilot')
        for ser in tv_names:
            for ep in ep_names_no_pilot:
                if _is_generic(ep):
                    continue
                out[f"{ser} {ep}"] = None

        # 3‑C) jméno seriálu + kód epizody
        for ser in tv_names:
            for code in (sxe, xep1, xep2):
                out[f"{ser} {code}"] = None

        # 3‑D) jméno seriálu + název epizody (už nefiltrujeme na generic),
        #      ale **pořád** platí zákaz 'pilot' → používáme ep_names_no_pilot
        for ser in tv_names:
            for ep in ep_names_no_pilot:
                out[f"{ser} {ep}"] = None

        return list(out.keys())













    # ––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    @staticmethod
    def movie(
        titles: Sequence[str],
        year: int | None,
        *,
        qualities: tuple[str, ...] = ("2160p", "1080p", "720p"),
        logger: Callable[..., None] | None = None,
    ) -> list[str]:
        """
        Přesunutá logika původního `build_movie_queries()` – beze změny.
        """
        log = logger or (lambda *_, **__: None)

        # – názvy + permutace – (stejný kód jako dřív) –
        names: set[str] = {t.strip() for t in titles if t.strip()}
        if len(names) == 2:
            for a, b in permutations(names, 2):
                names.add(f"{a} {b}")

        variants: list[str] = []
        for n in names:
            base = f"{n} {year}" if year else n
            variants.extend(f"{base} {q}" for q in qualities)
            variants.append(base)

        log("QUERY_VARIANTS", "/".join(titles), len(variants))
        return variants





# --------------------------------------------------------------------------- #
# 2025‑07‑20 10:45 CEST  build_movie_queries() – kompatibilní wrapper
# --------------------------------------------------------------------------- #
def build_movie_queries(
    title: str,
    original_title: str | None,
    year: int | None,
    *,
    qualities: tuple[str, ...] = ("2160p", "1080p", "720p"),
    logger: Callable[..., None] | None = None,
) -> list[str]:
    """
    ⚠️  ZACHOVÁNA signatura pro starší kód (plugin.py < 1.4).

    Interně jen přeposílá do `QueryBuilder.movie()`.
    """
    titles = [title] + ([original_title] if original_title else [])
    return QueryBuilder.movie(titles, year, qualities=qualities, logger=logger)






# ─────────────────────────────────────────────────────────────────────────────
#  FILTR
# ─────────────────────────────────────────────────────────────────────────────
class ReleaseFilter:
    """
    **Statické** metody pro vyřazení nevyhovujících souborů,
    enrich metadat a výpočet konečného *score*.
    """



    # 2025-08-19 11:27 CEST (Europe/Prague) – ReleaseFilter.enrich(): EP_RE nově dovolí i tvary „1x4“ (dříve jen „1x04“)
    @staticmethod
    def enrich(item: dict) -> Optional[Release]:
        """
        Převede syrovou dict strukturu z `WebshareClient.search()` na objekt
        `Release` nebo vrátí `None`, pokud release neprošel základními filtry
        (ext, min-size, přípona…).

        ✦ Úpravy 07/2025 – TV epizody:
            • pokud název obsahuje vzor SxxEyy nebo 1xYY → size-check se
              zjemní na 50 MB, aby epizody kolem 100 MB nepadaly
            • pro ostatní releasy zůstávají (snížené) limity z MIN_FILE_MB_BY_QUALITY

        ✦ Aktualizace 2025-08-19 11:27 CEST (Europe/Prague):
            • `EP_RE` sjednoceno na `(?:s\d{1,2}e\d{1,2}|\d{1,2}[xX]\d{1,2})` – zachytí i „1x4“,
              nejen „1x04“. Velikostní práh 50 MB pro epizody tím bude správně uplatněn i na tyto releasy.
        """
        name     = item["name"]
        size_mb  = item.get("size", 0) / 1_048_576
        ext      = os.path.splitext(name)[1].lower()

        # – 1) přípona –
        if ext not in ALLOWED_VIDEO_EXTS:
            return None

        # – 2) minimální velikost (dynamicky) –
        EP_RE        = re.compile(r"(?:s\d{1,2}e\d{1,2}|\d{1,2}[xX]\d{1,2})", re.I)
        is_episode   = bool(EP_RE.search(name))

        q            = quality(name)
        min_size_mb  = 50 if is_episode else MIN_FILE_MB_BY_QUALITY.get(q, 250)
        if size_mb < min_size_mb:
            return None

        # – 3) jazyky, kvalita, konstrukce Release –
        aud, sub = parse_langs(name)
        return Release(
            ident   = item["ident"],
            name    = name,
            size    = item["size"],
            quality = q,
            audios  = aud,
            subs    = sub,
            est_min = int(item.get("video_length", 0) / 60) or None,
        )




    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    @staticmethod
    def compute_score(r: Release) -> tuple[int, int, int]:
        """
        Lexikografické skóre pro řazení release-listu.

        1) ★ MATCH   – 0 (ano) / 1 (ne)                → potvrzené shody napřed
        2) kvalita   – QUALITY_RANK (0 = 2160p …)       → lepší rozlišení výš
        3) velikost  – -r.size (větší soubor = lepší)   → bitrate ve stejné řadě
        """
        star_flag = 0 if r.match else 1
        qual_rank = QUALITY_RANK.get(r.quality, 99)
        return (star_flag, qual_rank, -r.size)



# ─────────────────────────────────────────────────────────────────────────────
#  SEARCH ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class SearchEngine:
    """
    Orchestrace vyhledávání na Webshare.

    Parametry
    ---------
    get_client      : Callable[[], WebshareClient]
        Funkce, která kdykoliv vrátí *přihlášenou* instanci klienta.
        (plugin.py předá např. `lambda: _SESSION.client`)
    logger          : Callable[[str, object], None]
        Centralizovaný logger – používáme `plugin._log_event`.
    """

    # ------------------------------------------------------------------ #
    def __init__(
        self,
        get_client: Callable[[], WebshareClient],
        logger: Callable[..., None],
        *,                       # parametry za * jsou pouze pojmenované
        enable_probe: bool = True,
    ) -> None:
        """
        Inicializace vyhledávacího enginu.

        • `get_client`   – callback vracející přihlášený `WebshareClient`  
        • `logger`       – funkce pro logování (plugin._log_event)  
        • `enable_probe` – globální přepínač MediaInfo sondování
        """
        self._get_client   = get_client
        self._log          = logger
        self._enable_probe = enable_probe

        # RAM ‑ cache pro již zjištěné MediaInfo bloky
        self._mi_cache: dict[str, dict] = {}
        self._lock = threading.Lock()

        # ⚡ NOVĚ: cache před‑kompilovaných regexů na základě id(banned_keys)
        #         → minimalizuje režii při opakovaném vyhledávání dílů
        self._banned_re_cache: dict[int, re.Pattern] = {}




    # 2025-08-19 08:34 CEST (Europe/Prague) – Rule C: generické „Episode N“ musí mít i ser_part
    def search_one(  # noqa: C901
        self,
        query: str,
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        ep_title_variants: Sequence[Sequence[str]] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] | None = None,   # 2025-08-19 10:39 CEST (Europe/Prague)
        bad_regex: re.Pattern | None = None,

        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        probe: bool = True,
    ) -> List["Release"]:
        """
        Jeden `/search` dotaz → filtrovaný, seřazený seznam `Release`.

        [Aktualizováno: 2025-08-10 13:56 CEST] – DETAILNÍ LOGOVÁNÍ příčin odmítnutí (FILTER_REJECT) beze změny logiky.
        [Aktualizováno: 2025-08-19 08:03 CEST] – FIX: fallback `uncertain` kontroluje příponu z `rel.name` (splitext) proti `ALLOWED_VIDEO_EXTS`.
        [Aktualizováno: 2025-08-19 08:14 CEST] – FIX: fallback odmítne releasy s jiným ep-kódem (SxxEyy/xxXyy vč. „S01.E01“) nebo „E##“ bez sezóny.
        [Aktualizováno: 2025-08-19 08:34 CEST] – FIX (Rule C): pokud se chytne jen **generická** ep sada („episode 3“ apod.), je nutný i `ser_part`.
        [Aktualizováno: 2025-08-19 10:05 CEST] – SPEC: Jednoslovné názvy – Rule A vyžaduje, aby seriálový token stál na začátku názvu a hned po něm následoval kód SxxEyy/xxXyy.
        [Aktualizováno: 2025-08-19 10:39 CEST] – Filtr roku: podpora `allowed_years` (seriál + série + epizoda); zpětně kompatibilní s `movie_year`.

        
        """
        # 0) příprava -----------------------------------------------------------
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT
        self._log("RAW_SEARCH", query)
        probe = probe and self._enable_probe

        cli = self._get_client()
        ws_items = cli.search(query)[:MAX_WS_RESULTS]
        if not ws_items:
            self._log("WS_RESULTS", query, 0)
            return []

        # 1) blacklist regex (cache) -------------------------------------------
        banned_re: re.Pattern | None = None
        if banned_keys and len(banned_keys) > 300:
            key = id(banned_keys)
            banned_re = self._banned_re_cache.get(key)
            if banned_re is None:
                pat = r"(?<![0-9A-Za-z])(?:%s)(?![0-9A-Za-z])" % "|".join(re.escape(k) for k in banned_keys)
                banned_re = re.compile(pat, re.I)
                self._banned_re_cache[key] = banned_re

        # 2) tokenizace + před-výpočty -----------------------------------------
        STOP  = {"o", "a", "se", "of", "the", "and", "de", "le"}
        SE_RE = re.compile(r"(?:s\d{1,2}e\d{1,2}|\d{1,2}x\d{1,2})", re.I)

        tokens = [t for t in title_norms if t and t not in STOP]
        codes  = [t for t in tokens if SE_RE.fullmatch(t)]
        words  = [t for t in tokens if t not in codes]

        # Heuristika „krátký seriálový token“
        short_only = (not ep_title_variants) and (len(words) == 1 and len(words[0]) <= 3)
        if not ep_title_variants:
            ep_title_variants = [] if short_only else [words[-2:] if len(words) >= 2 else words]

        epi_all     = {w for v in ep_title_variants for w in v}
        ser_tokens  = [w for w in words if w not in epi_all]
        ep_sets     = [set(v) for v in ep_title_variants if v]
        code_re     = re.compile("|".join(map(re.escape, codes)), re.I) if codes else None

        # „globální“ příznak – dříve používaný (ponechán pro logging/kompat.)
        generic_ep = (bool(ep_sets) and all((w in GENERIC_EP or w.isdigit()) for v in ep_sets for w in v))

        # kontext do logu (informativní)
        try:
            ctx = {
                "query": query,
                "title_norms": list(title_norms),
                "codes": list(codes),
                "ser_tokens": list(ser_tokens),
                "ep_title_variants": [list(v) for v in ep_title_variants] if ep_title_variants else [],
                "generic_ep": bool(generic_ep),
            }
            self._log("FILTER_CTX", json.dumps(ctx, ensure_ascii=False))
        except Exception:
            pass

        releases:   List[Release] = []
        probe_cand: List[Release] = []

        # 3) hlavní filtrace ----------------------------------------------------
        for itm in ws_items:
            rel = ReleaseFilter.enrich(itm)
            if not rel:
                self._log("FILTER_REJECT", itm["ident"], "quick", itm["name"])
                continue

            n = norm(rel.name)
            name_words = set(n.split())

            has_code  = bool(code_re.search(n)) if code_re else False
            same_code = has_code if code_re else True
            ser_full  = all(w in name_words for w in ser_tokens) if ser_tokens else False
            ser_part  = any(w in name_words for w in ser_tokens) if ser_tokens else False
            ep_full   = any(all(w in name_words for w in v) for v in ep_sets)

            # Rozliš, zda se v názvu chytila jen „generická“ ep-sada
            ep_full_generic = any(
                all(w in name_words for w in v) and all((w in GENERIC_EP or w.isdigit()) for w in v)
                for v in ep_sets
            )
            ep_full_nongeneric = any(
                all(w in name_words for w in v) and not all((w in GENERIC_EP or w.isdigit()) for w in v)
                for v in ep_sets
            )

            # Původní A/B/C – jemně zpřesněné C pro generické „Episode N“
            rule_a = same_code and ser_full and has_code
            rule_b = same_code and ser_part and ep_full
            rule_c = (same_code and ser_part and ep_full and has_code) if generic_ep else (same_code and ep_full and has_code)

            # 2025-08-19 10:05 CEST (Europe/Prague) – SPEC: jednoslovné názvy
            # Pokud máme jen 1 seriálový token, zpřísníme Rule A:
            # token musí být na ZAČÁTKU názvu a okamžitě za ním musí následovat kód SxxEyy nebo xxXyy
            # (povolíme libovolné ne-alfanumerické oddělovače mezi tokenem a kódem).
            if len(ser_tokens) == 1 and rule_a:
                t = ser_tokens[0]
                # ^token [\W]* (SxxEyy|xxXyy) \b  … porovnáváme na normalizovaném `n`
                _ADJ_RE = re.compile(
                    rf"^{re.escape(t)}(?:\W+)?(?:s0?\d{{1,2}}\W*e0?\d{{1,2}}|0?\d{{1,2}}\W*x\W*0?\d{{1,2}})\b",
                    re.I,
                )
                if not _ADJ_RE.search(n):
                    rule_a = False

            # ★ NOVĚ: pokud se chytla jen generická ep-sada (např. „episode 3“),
            #          vyžaduj i ser_part, aby neprocházely cizí seriály.
            if ep_full_generic and not ep_full_nongeneric:
                rule_c = rule_c and ser_part

            allow_hit = rule_a or rule_b or rule_c
            if short_only and codes:
                allow_hit = False

            rel.uncertain = bool(codes) and (not allow_hit)

            # ----------------------- Fallback (jen když A/B/C selžou) --------
            if not allow_hit:
                # 0) bez ser_tokens fallback nedává smysl
                if not ser_tokens:
                    self._log("FILTER_REJECT", rel.ident, "no_ser_tokens",
                              json.dumps({"ser_tokens": [], "name_words": sorted(name_words)}, ensure_ascii=False),
                              rel.name)
                    continue

                # 1) blacklist
                banned_hit = ((banned_re and banned_re.search(n))
                              or (banned_keys and not banned_re and any(f" {bk} " in f" {n} " for bk in banned_keys)))
                if banned_hit:
                    bk = None
                    if banned_re:
                        m = banned_re.search(n);  bk = m.group(0) if m else None
                    elif banned_keys:
                        for k in banned_keys:
                            if f" {k} " in f" {n} ":
                                bk = k; break
                    self._log("FILTER_REJECT", rel.ident, "other_part",
                              json.dumps({"ban_hit": bk}, ensure_ascii=False), rel.name)
                    continue

                # 1a) 2025-08-19 08:14 CEST – pojistka „jiný díl“ (S01.E01/E## …)
                _ANY_CODE_RE = re.compile(r"\b(?:s0?\d{1,2}\W*e0?\d{1,2}|0?\d{1,2}\W*x\W*0?\d{1,2})\b", re.I)
                _E_ONLY_RE   = re.compile(r"(?<![a-z0-9])e0?\d{1,2}(?![a-z0-9])", re.I)
                target_norm = {re.sub(r"[^a-z0-9]", "", c.lower()) for c in codes} if codes else set()
                found_codes = [re.sub(r"[^a-z0-9]", "", m.group(0).lower()) for m in _ANY_CODE_RE.finditer(rel.name)]
                e_only_hits = [m.group(0).lower() for m in _E_ONLY_RE.finditer(n)]
                if found_codes and target_norm and not any(c in target_norm for c in found_codes):
                    self._log("FILTER_REJECT", rel.ident, "other_code",
                              json.dumps({"found": found_codes, "target": sorted(target_norm)}, ensure_ascii=False),
                              rel.name)
                    continue
                if e_only_hits and target_norm and not any(c in target_norm for c in found_codes):
                    self._log("FILTER_REJECT", rel.ident, "other_code_e_only",
                              json.dumps({"found_e": e_only_hits, "target": sorted(target_norm)}, ensure_ascii=False),
                              rel.name)
                    continue

                # 2) *words* bez GENERIC_EP → musí být aspoň 2 čisté tokeny
                clean_tokens = [t for t in words if t not in GENERIC_EP]
                if len(clean_tokens) < 2:
                    self._log("FILTER_REJECT", rel.ident, "few_tokens",
                              json.dumps({"clean_tokens": clean_tokens, "len": len(clean_tokens)}, ensure_ascii=False),
                              rel.name)
                    continue

                # 3) seriálové tokeny — (s kódem stačí 1 shoda)
                ser_needed = 1 if has_code or len(ser_tokens) < 2 else 2
                hit_ser_tokens = [t for t in ser_tokens if t in name_words]
                if len(hit_ser_tokens) < ser_needed:
                    self._log("FILTER_REJECT", rel.ident, f"token_ser_miss_{len(hit_ser_tokens)}/{ser_needed}",
                              json.dumps({"ser_tokens": ser_tokens, "hit_ser_tokens": hit_ser_tokens,
                                          "name_words": sorted(name_words), "has_code": bool(has_code)}, ensure_ascii=False),
                              rel.name)
                    continue

                # dlouhé tokeny (≥5) – aspoň jeden musí padnout
                long_tokens = [t for t in ser_tokens if len(t) >= 5]
                if long_tokens and not any(t in name_words for t in long_tokens):
                    self._log("FILTER_REJECT", rel.ident, "token_ser_long_miss",
                              json.dumps({"long_tokens": long_tokens, "name_words": sorted(name_words)}, ensure_ascii=False),
                              rel.name)
                    continue

                # 4) epizodní tokeny – u ne-generických epizod musí padnout ≥1 shoda
                if (not generic_ep) and ep_sets:
                    hit_ep_tokens = sorted({w for v in ep_sets for w in v if w in name_words})
                    if not hit_ep_tokens:
                        self._log("FILTER_REJECT", rel.ident, "ep_token_miss",
                                  json.dumps({"ep_sets": [sorted(list(v)) for v in ep_sets],
                                              "found": hit_ep_tokens, "name_words": sorted(name_words)}, ensure_ascii=False),
                                  rel.name)
                        continue

                # 5) globální limit shod — (s kódem stačí 1 „clean“ token)
                min_needed = 1 if has_code else (3 if generic_ep else 2)
                min_needed = min(min_needed, len(clean_tokens))
                hit_tokens = [t for t in clean_tokens if t in name_words]
                if len(hit_tokens) < min_needed:
                    self._log("FILTER_REJECT", rel.ident, f"token_miss_{len(hit_tokens)}/{min_needed}",
                              json.dumps({"clean_tokens": clean_tokens, "hit_tokens": hit_tokens,
                                          "name_words": sorted(name_words), "generic_ep": bool(generic_ep),
                                          "has_code": bool(has_code)}, ensure_ascii=False),
                              rel.name)
                    continue

                # 6) uncertain → min velikost + přípona videa  (OPRAVENO 2025-08-19)
                if rel.uncertain:
                    ext = os.path.splitext(rel.name)[1].lower()
                    video_ext_ok = ext in ALLOWED_VIDEO_EXTS
                    if (rel.size_mb is not None and rel.size_mb < 200) or (not video_ext_ok):
                        self._log("FILTER_REJECT", rel.ident, "uncertain_small_or_ext",
                                  json.dumps({"size_mb": rel.size_mb, "video_ext_ok": video_ext_ok}, ensure_ascii=False),
                                  rel.name)
                        continue

            # regex / rok / další rychlé filtry (beze změny)
            if bad_regex.search(rel.name):
                try:
                    self._log("FILTER_REJECT", rel.ident, "bad_regex",
                              json.dumps({"pattern": bad_regex.pattern}, ensure_ascii=False), rel.name)
                except Exception:
                    self._log("FILTER_REJECT", rel.ident, "bad_regex", rel.name)
                continue



            # (filmy) – quick pojistka „nepatří to k filmu“; u TV nepoužíváme
            if movie_year and _BAD_REGEX_MOVIE.search(rel.name):
                self._log("FILTER_REJECT", rel.ident, "bad_ep", rel.name)
                continue

            # 2025-08-19 10:39 CEST (Europe/Prague) – Kontrola roku (set povolených let)
            years_allowed = set(allowed_years or ([] if movie_year is None else [movie_year]))
            if years_allowed:
                yrs = {int(y) for y in YEAR_RE.findall(rel.name)}
                # Zachováváme původní přísnost: více než 1 rok v názvu je podezřelé
                if yrs and (len(yrs) > 1 or yrs.isdisjoint(years_allowed)):
                    payload = {
                        "allowed_years": sorted(years_allowed),
                        "yrs_in_name": sorted(yrs),
                    }
                    # pro zpětnou kompatibilitu přidáme i movie_year, je-li použit
                    if movie_year is not None:
                        payload["movie_year"] = movie_year
                    self._log("FILTER_REJECT", rel.ident, "year_miss",
                              json.dumps(payload, ensure_ascii=False), rel.name)
                    continue


            # kandidáti na MediaInfo probe
            if probe and rel.est_min is None and len(probe_cand) < PROBE_MAX_RESULTS:
                probe_cand.append(rel)

            releases.append(rel)
            self._log("FILTER_ACCEPT", rel.ident,
                      f"a={int(rule_a)} b={int(rule_b)} c={int(rule_c)} u={int(rel.uncertain)}",
                      rel.quality, rel.size_mb, rel.name)

        # 4) MediaInfo probe (paralelně) ---------------------------------------
        if probe and probe_cand:
            total = len(probe_cand)
            def _wrap(r: "Release", idx: int) -> None:
                self._probe(r)
                if progress_cb:
                    progress_cb(idx, total, "probe")
            with _f.ThreadPoolExecutor(max_workers=5) as pool:
                [f.result() for f in (pool.submit(_wrap, r, i) for i, r in enumerate(probe_cand, 1))]

        # 5) seřazení -----------------------------------------------------------
        self._log("WS_RESULTS", query, len(releases))
        for r in releases:
            r.score = ReleaseFilter.compute_score(r)
        releases.sort(key=lambda x: x.score)
        return releases






    def search_movie_one(  # 10-08-2025 18:26 CEST (Europe/Prague)               # noqa: C901
        self,
        query: str,
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] = (),      # ← NOVĚ: whitelist z TMDb
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        probe: bool = True,
    ) -> List["Release"]:
        """
        FILMOVÁ varianta `search_one()` se stejnou logikou jako dosud, ale
        rozšířenou o **whitelist roků** získaný z TMDb (produkční země + hlavní trhy).
        Dotazy dál používají jen `movie_year`; whitelist se uplatní pouze ve filtru.
        """
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT
        self._log("RAW_MOVIE_SEARCH", query)
        probe = probe and self._enable_probe

        # ❶ Webshare /search
        cli = self._get_client()
        ws_items = cli.search(query)[:MAX_WS_RESULTS]
        if not ws_items:
            self._log("WS_RESULTS", query, 0)
            return []

        # ❷ roky přímo z titulních tokenů (kvůli filmům typu „2012“ apod.)
        title_year_tokens: set[int] = {
            int(tok) for tok in title_norms if tok.isdigit() and len(tok) == 4
        }
        extra_years = {int(y) for y in allowed_years if isinstance(y, int)}

        # ❸ Filtry + enrich
        releases: list[Release] = []
        probe_cand: list[Release] = []

        for itm in ws_items:
            rel = ReleaseFilter.enrich(itm)
            if not rel:
                self._log("FILTER_REJECT", itm["ident"], "quick", itm["name"])
                continue

            n = norm(rel.name)

            # dynamické filtry
            if banned_keys and any(bk in n for bk in banned_keys):
                self._log("FILTER_REJECT", rel.ident, "other_part", rel.name)
                continue
            if title_norms and not any(t in n for t in title_norms):
                self._log("FILTER_REJECT", rel.ident, "title_miss", rel.name)
                continue
            if _BAD_REGEX_MOVIE.search(rel.name) or bad_regex.search(rel.name):
                self._log("FILTER_REJECT", rel.ident, "bad_regex", rel.name)
                continue

            # NOVÁ kontrola ROKU – whitelist z TMDb (produkční + hlavní trhy, ±1 rok)
            if movie_year:
                yrs = {int(y) for y in YEAR_RE.findall(rel.name)}
                if yrs:
                    allowed = ({movie_year} | title_year_tokens | extra_years)
                    if yrs - allowed:
                        self._log(
                            "FILTER_REJECT",
                            rel.ident,
                            "year_miss",
                            json.dumps(
                                {"movie_year": movie_year, "tmdb_allowed": sorted(extra_years), "yrs_in_name": sorted(yrs)},
                                ensure_ascii=False,
                            ),
                            rel.name,
                        )
                        continue

            # MediaInfo fronta
            if probe and rel.est_min is None and len(probe_cand) < PROBE_MAX_RESULTS:
                probe_cand.append(rel)

            releases.append(rel)
            self._log("FILTER_ACCEPT", rel.ident, rel.quality, rel.size_mb, rel.name)

        # ❹ MediaInfo probe (paralelně)
        if probe and probe_cand:
            total = len(probe_cand)

            def _wrap(r: "Release", idx: int) -> None:
                self._probe(r)
                if progress_cb:
                    progress_cb(idx, total, "probe")

            with _f.ThreadPoolExecutor(max_workers=5) as pool:
                [f.result() for f in (pool.submit(_wrap, r, i) for i, r in enumerate(probe_cand, 1))]

        self._log("WS_RESULTS", query, len(releases))

        # ❺ Délkový filtr + ★ MATCH
        if runtimes:
            lo_rt, hi_rt = min(runtimes), max(runtimes)
            keep: list[Release] = []
            for r in releases:
                est = r.est_min or 0
                if est and (est < lo_rt - LEN_TOL_SHORT or est > hi_rt + LEN_TOL_LONG):
                    self._log("FILTER_REJECT", r.ident, "len_out", r.name)
                    continue
                if any(abs(est - rt) <= MATCH_TOL for rt in runtimes):
                    r.match = True
                keep.append(r)
            releases = keep

        # ❻ Scoring + řazení
        for r in releases:
            r.score = ReleaseFilter.compute_score(r)
        releases.sort(key=lambda x: x.score)
        return releases




    def search_movie_wave(  # 10-08-2025 18:26 CEST (Europe/Prague)               # noqa: C901
        self,
        queries: Sequence[str],
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] = (),      # ← NOVĚ: posíláme z pluginu
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        max_quick_probe: int = 0,
        top_full_probe: int = 15,
    ) -> List["Release"]:
        """
        Filmová vlna s 30denní cache. Cache‑klíč nově zahrnuje i whitelist roků,
        aby se nepletly výsledky mezi různými pravidly povolených roků.
        """
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT

        # 1) CACHE – klíč = dotazy + (rok) + (seznam povolených roků)
        extra = f":{movie_year}" if movie_year else ""
        years_tag = f":{','.join(str(y) for y in sorted(set(allowed_years)))}" if allowed_years else ""
        cache_key = SEARCH_CACHE.build_key("movie", *sorted(queries)) + extra + years_tag
        if cached := SEARCH_CACHE.get(cache_key):
            self._log("CACHE_HIT", cache_key, len(cached))
            return [Release(**rec) for rec in cached]

        # 2) Paralelní hledání
        total_q = len(queries)
        pool_size = max(1, min(6, total_q))
        with _f.ThreadPoolExecutor(max_workers=pool_size) as pool:
            futs = [
                pool.submit(
                    self.search_movie_one,
                    q,
                    runtimes=runtimes,
                    title_norms=title_norms,
                    banned_keys=banned_keys,
                    movie_year=movie_year,
                    allowed_years=allowed_years,   # ← předáváme dovnitř
                    bad_regex=bad_regex,
                    progress_cb=progress_cb,
                    probe=False,
                )
                for q in queries
            ]

            all_items: List[Release] = []
            for idx, f in enumerate(_f.as_completed(futs), 1):
                all_items.extend(f.result())
                if progress_cb:
                    progress_cb(idx, total_q, "search")

        # 3) Deduplikace ID → (size, ext) – beze změn
        seen_ids: set[str] = set()
        uniq_id: List[Release] = []
        for r in sorted(all_items, key=lambda x: x.score):
            if r.ident not in seen_ids:
                uniq_id.append(r)
                seen_ids.add(r.ident)

        seen_sig: set[tuple[int, str]] = set()
        uniq_final: List[Release] = []
        for r in uniq_id:
            ext = os.path.splitext(r.name)[1].lower()
            sig = (r.size, ext)
            if sig in seen_sig:
                continue
            seen_sig.add(sig)
            uniq_final.append(r)

        result = uniq_final

        # 4) Uložit do cache
        try:
            SEARCH_CACHE.put(cache_key, [asdict(r) for r in result])
            self._log("CACHE_PUT", cache_key, len(result))
        except Exception:
            pass

        return result








    # ───────────────────────────────────────────────────────────────────
    #  ⚡ RYCHLÁ STOPÁŽ – lehké dotazy bez stahování dat
    # ───────────────────────────────────────────────────────────────────
    def _quick_duration(self, rel: "Release") -> None:
        """
        Zapíše `rel.est_min`, aniž by se cokoli stahovalo:

        1)  /api/file_info  → pole <video_length>
        2)  HTTP HEAD + hlavičky  Content‑Duration / X‑Content‑Duration
        """
        cli = self._get_client()

        # 1) REST  /file_info  (rozšířeno o light endpoint file_info_duration)
        with contextlib.suppress(Exception):
            secs = cli.file_info_duration(rel.ident)   # ← nová utilita v SDK
            if secs:
                rel.est_min = secs // 60
                return

        # 2) fallback HEAD
        with contextlib.suppress(Exception):
            url  = cli.file_link(rel.ident, download_type=None)
            head = requests.head(url, timeout=8, allow_redirects=True)
            hdr  = head.headers.get("Content-Duration") or head.headers.get("X-Content-Duration")
            if hdr:
                rel.est_min = int(float(hdr)) // 60





    # ─────────────────────────────────────────────────────────────────────────
    # 2025‑07‑28 08:42 CEST  SearchEngine.search_wave()  – doplněna CACHE 30 dní
    # ─────────────────────────────────────────────────────────────────────────
    def search_wave(  # noqa: C901
                    
        self,
        queries: Sequence[str],
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        ep_title_variants: Sequence[Sequence[str]] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] | None = None,   # 2025-08-19 10:39 CEST (Europe/Prague)
        bad_regex: re.Pattern | None = None,


        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        max_quick_probe: int = 0,
        top_full_probe: int = 15,
    ) -> List["Release"]:
        """
        Paralelní vlna vyhledávání + dvojí deduplikace **S PODPOROU CACHE**.

        Nově (07/2025)
        ---------------
        • Před samotným hledáním zkusí načíst výsledek z `SEARCH_CACHE`
          (TTL 30 dní).  
        • Po úspěšném hledání uloží seřazený list do cache.

        Ostatní logika zůstává beze změny.
        """
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT

        # 🔸 1) CACHE – zkusíme nejprve rychle vrátit uložené výsledky
        years_tag = f":{','.join(str(y) for y in sorted(set(allowed_years or ())))}" if allowed_years else ""
        cache_key = SEARCH_CACHE.build_key("tv", *sorted(queries)) + years_tag   # 2025-08-19 11:22 CEST (Europe/Prague)
        if cached := SEARCH_CACHE.get(cache_key):
            self._log("CACHE_HIT", cache_key, len(cached))
            return [Release(**rec) for rec in cached]


        # 🔸 2) Pokračujeme původní, výpočetně náročnou logikou -------------
        total_q   = len(queries)
        pool_size = max(1, min(6, total_q))

        with _f.ThreadPoolExecutor(max_workers=pool_size) as pool:
            futs = [
                pool.submit(
                    self.search_one,
                    q,
                    runtimes=runtimes,
                    title_norms=title_norms,
                    banned_keys=banned_keys,
                    ep_title_variants=ep_title_variants,
                    movie_year=movie_year,
                    allowed_years=allowed_years,   # 2025-08-19 10:39 CEST
                    bad_regex=bad_regex,
                    progress_cb=progress_cb,
                    probe=False,
                )

                for q in queries
            ]

            all_items: List[Release] = []
            for idx, f in enumerate(_f.as_completed(futs), 1):
                all_items.extend(f.result())
                if progress_cb:
                    progress_cb(idx, total_q, "search")

        # ––– (DE‑DUP #1 a #2) –––  beze změny oproti původní implementaci
        self._log("DEDUP_BEGIN", len(all_items))
        seen_ids: set[str] = set()
        uniq_id: List[Release] = []
        for r in sorted(all_items, key=lambda x: x.score):
            if r.ident not in seen_ids:
                uniq_id.append(r)
                seen_ids.add(r.ident)

        self._log("DEDUP2_BEGIN", len(uniq_id))
        seen_sig: set[tuple[int, str]] = set()
        uniq_final: List[Release] = []
        for r in uniq_id:
            ext = os.path.splitext(r.name)[1].lower()
            sig = (r.size, ext)
            if sig in seen_sig:
                continue
            seen_sig.add(sig)
            uniq_final.append(r)

        certain   = [r for r in uniq_final if not r.uncertain]
        result    = certain if certain else [r for r in uniq_final]

        # 🔸 3) Uložíme do cache  -------------------------------------------
        try:
            SEARCH_CACHE.put(cache_key, [asdict(r) for r in result])
            self._log("CACHE_PUT", cache_key, len(result))
        except Exception:
            pass            # cache nesmí shodit doplněk

        return result







    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    #  INTERNALS
    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def _probe(self, r: Release) -> None:
        """
        Doplní odhad délky + kompletní MediaInfo **jediným** HTTP dotazem.
        Výsledek ukládáme do paměťové cache a přímo na objekt `Release`.
        """
        if getattr(r, "mediainfo", None):
            return                          # už máme

        mi = self._get_client().probe_mediainfo(r.ident)
        if not mi:
            return

        # – stopáž –
        if mi.get("duration"):
            r.est_min = mi["duration"] // 60

        # – přilepíme MediaInfo k releaseu + do sdílené RAM cache –
        r.mediainfo = mi                   # atribut se vytvoří dynamicky
        with self._lock:
            self._mi_cache[r.ident] = mi




    # ------------------------------------------------------------------ #
    def get_mediainfo(self, ident: str) -> Optional[dict]:
        """
        Vrátí MediaInfo z RAM cache; pokud tam není, stáhne je jednorázově
        a uloží do cache.  Nikdy nestahuje víc než oněch ≈ 5 MB.
        """
        with self._lock:
            if ident in self._mi_cache:
                return self._mi_cache[ident]

        mi = self._get_client().probe_mediainfo(ident)
        if mi:
            with self._lock:
                self._mi_cache[ident] = mi
        return mi




# --------------------------------------------------------------------------- #
# 2025‑07‑20 20:27 CEST  LabelFormatter.format() – pouze rozlišení + velikost
# --------------------------------------------------------------------------- #
class LabelFormatter:
    """
    Připraví dvouřádkový popisek + pravý sloupec (jazyky) pro GUI.
    Nově na prvním řádku zobrazuje **pouze** rozlišení v hranatých závorkách
    a velikost souboru v MB; zbytek (název release) zůstává na druhém řádku.
    """

    @staticmethod
    def format(release: "Release", **kwargs) -> Dict[str, str]:
        """
        Vrací slovník {"label_left", "label_right"}.

        • první řádek:   „[1080P] – 495 MB“
        • druhý řádek:   originální název souboru (šedě)
        • pravý sloupec: AUD/SUB jazyky beze změny
        """

        # ––––––––––––––––––––––––– 1) první řádek ––––––––––––––––––––––––––– #
        qual_tag = f"[{release.quality.upper()}]"
        first_line = qual_tag

        if release.size:
            first_line += (
                f" – {release.size_mb:,}".replace(",", " ") + " MB"
            )

        # ––––––––––––––––––––––––– 2) druhý řádek ––––––––––––––––––––––––––– #
        second_line = f"[COLOR grey]\t\t\t{release.name}[/COLOR]"

        # ––––––––––––––––––––––––– 3) pravý sloupec ––––––––––––––––––––––––– #
        aud_txt = "/".join(release.audios) if release.audios else ""
        sub_txt = "/".join(release.subs)   if release.subs   else ""
        right = ""
        if aud_txt:
            right += f"AUD:{aud_txt}"
        if sub_txt:
            right += ("  " if right else "") + f"SUB:{sub_txt}"

        left = f"{first_line}\n{second_line}"
        return {"label_left": left, "label_right": right}





class _SearchProgress:
    """
    Jediný DialogProgress sdílený všemi vlákny *během jednoho hledání*.
    Čítače jsou kumulativní, takže procenta **nikdy neklesají** ani když
    paralelní vlákna hlásí své lokální rozsahy (Search / Probe).
    """
    _TXT = {"search": "Vyhledávání", "probe": "Analýza stopáže"}

    def __init__(self, heading: str = "RichMovie – Vyhledávání") -> None:
        self._dlg   = xbmcgui.DialogProgress()
        self._dlg.create("RichMovie", heading)
        self._last_pct: int           = -1
        self._totals: dict[str, int]  = {}
        self._done:   dict[str, int]  = {}
        self._lock   = threading.Lock()

    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def __call__(self, current: int, total: int, stage: str = "") -> None:
        """
        Callback z SearchEngine:
            current – aktuální index (1-based)
            total   – lokální limit v daném vlákně
            stage   – 'search' nebo 'probe'
        """
        with self._lock:
            # první blok daného typu → přičteme *total* jen jednou
            if stage not in self._totals or current == 1:
                self._totals[stage] = self._totals.get(stage, 0) + total
                self._done.setdefault(stage, 0)

            # přírůstek od minula (vlákno může skočit z 1→15 rovnou)
            if current > self._done[stage]:
                self._done[stage] = current

            done_all  = sum(self._done.values())
            total_all = sum(self._totals.values())
            pct       = int(done_all / total_all * 100) if total_all else 0
            pct       = max(pct, self._last_pct)        # procenta jen rostou
            self._last_pct = pct

            label = (
                f"{self._TXT.get(stage, stage)}: "
                f"{self._done[stage]} / {self._totals[stage]}"
            )
            self._dlg.update(pct, label)




    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def close(self) -> None:
        self._dlg.close()

