# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie Kodi plugin  – v1.3 (06 / 2025)
───────────────────────────────────────────────────────────────────────────────
Špičkový vyhledávač filmů / seriálů na Webshare.cz s paralelním dotazováním,
heuristickou filtrací a GUI přívětivým výstupem.  Aktuální architektura:

  • **richmovie_webshare.py**  – HTTP klient + login + stopáž probe  
  • **richmovie_engine.py**    – vyhledávací a filtrační logika („know‑how“)  
  • *plugin.py*                – pouze UI lepidlo / routing / Kodi volání

Díky tomu je hlavní soubor čitelný, snadno se testuje a případný
budoucí refaktor se nedotkne uživatelského rozhraní.

Licence: MIT · Autor: Richie (2025-06 - ???)
═══════════════════════════════════════════════════════════════════════════════
"""
# --------------------------------------------------------------------------- #
#  IMPORTY + zpřístupnění resources/lib       (aktualizováno 22 / 07 / 2025)
# --------------------------------------------------------------------------- #
from __future__ import annotations

# – Standardní knihovny –
import datetime
import functools
import hashlib
import importlib
import inspect
import io
import json
import os
import random            # ← přidáno (Sims-like rotace hlášek)
import re
import shutil
import socket                 # 🆕 rychlý test konektivity
import sys
import textwrap
import threading
import time                     # 🆕 asynchronní test internetu
import unicodedata
import urllib.parse                        # 🆕 URL utils pro Sosáč
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict
from itertools import islice, permutations          # islice → chunking
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Sequence,
    Tuple,
)
from urllib.parse import parse_qs, quote_plus, urlencode

# – 3rd‑party knihovny –
import requests

# – Přibalené knihovny (resources/lib) –
ADDON_DIR = Path(__file__).resolve().parent
LIB_DIR   = ADDON_DIR / "resources" / "lib"
if LIB_DIR.exists() and str(LIB_DIR) not in sys.path:
    sys.path.insert(0, str(LIB_DIR))

# – Kodi API –
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# – Lokální moduly –
from tmdb_client import TMDb, TMDbError



from richmovie_webshare import (
    APIError,
    SessionManager,
    TokenExpired,
    WebshareClient,
    _JSONCache,
)

from richmovie_engine import (
    LabelFormatter,
    SearchEngine,
    Release,
    _SearchProgress,
    _is_adult_title,
    build_movie_queries,
    spin_tokens,
    base_title_key as _base_title_key,
    norm as _norm,
    EROTIC_KEYWORDS,
    _ALT_THRESHOLD,
    _ALT_MAX_TITLES,
    _ALT_COUNTRY_WHITELIST,
    _NON_LATIN_RE,
)
from richmovie_sosac import SosacClient
from richmovie_engine import QueryBuilder      # centrální builder dotazů
from richmovie_collections import CollectionsUI


# 2025-08-10 21:57 CEST (Europe/Prague)
# Přidej do skupiny projektových importů (kde máš tmdb_client, richmovie_engine, …):
from richmovie_open_ai import identify_titles, recommend_titles, OpenAIError, validate_openai_key

import typing
if typing.TYPE_CHECKING:
    import richmovie_webshare  # pouze pro Pylance; za běhu se nevykoná





# --------------------------------------------------------------------------- #
#  NEXT‑UP  – perzistentní disková cache (rychlý pre‑fetch)
# --------------------------------------------------------------------------- #
@functools.lru_cache(maxsize=1)
def _disk_nextup_cache() -> _JSONCache:
    """
    Vrátí instanci `_JSONCache` pro Next‑Up.

    • Vytvoří se **až při prvním volání**, takže se nikdy
      nespustí dřív, než existuje `PROFILE_DIR`.
    • Díky dekorátoru `lru_cache(1)` držíme v processu jediný
      objekt – další volání jsou už jen rychlý lookup.
    """
    path = PROFILE_DIR / "nextup_cache.json"
    return _JSONCache(path)




# 2025-08-14 13:16 CEST (Europe/Prague)
def _detect_skin_emoji_support() -> bool:
    """
    Lehká heuristika: projde složku skinu `special://skin/fonts/` a pokud
    najde fonty mající v názvu 'emoji', 'noto', 'color', 'twemoji', 'segoe',
    vyhodnotí, že skin *pravděpodobně* umí emoji.

    Není-li jistota, vrací False (text-only režim).
    """
    try:
        fonts_dir = xbmcvfs.translatePath("special://skin/fonts/")
        # Pokud složka není, většina skinů nepodporuje „barevné“ emoji
        try:
            dirs, files = xbmcvfs.listdir(fonts_dir)
        except Exception:
            return False
        look = ("emoji", "color", "noto", "twemoji", "segoe")
        for name in files:
            n = (name or "").lower()
            if any(k in n for k in look):
                return True
        return False
    except Exception:
        return False




# 2025-08-14 14:07 CEST (Europe/Prague)
def _run_ai_with_progress(kind: str, user_text: str, *, mode: str, worker: Callable[[], Any]) -> Tuple[Any, Any]:
    """
    Spustí A.I. práci v pozadí a zobrazí „Sims-like“ průběh s procenty.

    Parametry:
      kind: "movie" | "tv" | "any" (typ pro doporučení)
      user_text: vstup od uživatele (pro personifikaci hlášek)
      mode: "recommend" | "identify" (volaná A.I. větev)
      worker: nulár, který v jiném vlákně provede A.I. volání a vrátí výsledek

    Návrat:
      (result, progress_obj) – výsledek A.I. volání a handle na progres
      (progress_obj má metody update(percent:int, msg:str), close())

    Pozn.: Emoji používáme jen tehdy, když skin zřejmě podporuje emoji fonty.
    """

    # — vnitřní třída: obsluha progress okna ————————————————
    class _SimsProgress:
        def __init__(self, heading: str, use_emoji: bool) -> None:
            self._dlg = xbmcgui.DialogProgressBG()
            self._heading = heading
            self._use_emoji = use_emoji
            self._pct = 0

        def create(self, msg: str) -> None:
            try:
                self._dlg.create(self._heading, msg)
            except Exception:
                pass

        def update(self, pct: int, msg: str) -> None:
            self._pct = max(0, min(100, int(pct)))
            try:
                self._dlg.update(self._pct, self._heading, msg)
            except Exception:
                pass

        def close(self) -> None:
            try:
                self._dlg.close()
            except Exception:
                pass

    # — pomocníci ——————————————————————————————————————————————
    def _detect_skin_emoji_support() -> bool:
        """
        Heuristika: v `special://skin/fonts/` hledáme fonty obsahující 'emoji',
        'color', 'noto', 'twemoji', 'segoe'. Když si nejsme jisti, vracíme False.
        """
        try:
            fonts_dir = xbmcvfs.translatePath("special://skin/fonts/")
            try:
                dirs, files = xbmcvfs.listdir(fonts_dir)
            except Exception:
                return False
            look = ("emoji", "color", "noto", "twemoji", "segoe")
            for name in files:
                n = (name or "").lower()
                if any(k in n for k in look):
                    return True
            return False
        except Exception:
            return False

    # — volba hlavičky, personalizace a banky textů ——————————
    use_emoji = _detect_skin_emoji_support()
    Q = (user_text or "").strip().strip("'\"")
    base_q = f"„{Q}“" if Q else "tvým chutím"
    is_tv = (kind or "").lower() == "tv"
    is_movie = (kind or "").lower() == "movie" or ((kind or "").lower() == "any" and mode == "recommend")

    if mode == "recommend":
        heading = "RichMovie A.I. – doporučení"
    else:
        heading = "RichMovie A.I. – přesná identifikace"

    # —— SIMS‑like banky hlášek (>= ~120 unikátů napříč režimy) ————————
    # 1) Filmy – textová banka (~45)
    MOVIE_PLAIN = [
        f"Skenuji filmové galaxie pro {base_q}…",
        "Prohledávám archivy invazních blockbusterů…",
        "Měřím dávku popcornu na metr exploze…",
        "Ladím rovnováhu mezi akcí a napětím…",
        "Kontroluji, zda finále nepráskne moc brzo…",
        "Seřazuji UFO podle velikosti talířů…",
        "Zjišťuji, kolik hrdinů světu dnes zachrání krk…",
        "Srovnávám remaky, rebooty a skutečné klasiky…",
        "Testuji, zda mimozemšťani mluví česky (alespoň titulky)…",
        "Mapuji přistávací koridory nad tvou filmotékou…",
        "Seřazuji lasery od 'pšouk' po 'odpař město'…",
        "Zkoumám, jestli je střih víc rychlý než rozumný…",
        "Srovnávám generály, kteří nikomu nic neřeknou…",
        "Počítám, kolik mrakodrapů padne do závěrečných titulků…",
        "Vybírám filmy, co stárnou jako víno, ne jako CGI z roku 2000…",
        "Hledám cameo Jeffa Goldbluma – pro jistotu…",
        "Filtruji 'panika v ulicích' vs. 'tichý první kontakt'…",
        "Krotím drony, aby nespoilerovaly zápletku…",
        "Nabíjím kameru třesem ruky (found‑footage mód)…",
        "Stahuji gravitační vlny z prostoru vyprávění…",
        "Měřím poměr 'wow' k 'cože' v každé scéně…",
        "Přepočítávám šance lidstva bez wi‑fi…",
        "Zvažuju, kolik saxofonů unesou devadesátky…",
        "Odlazuji subwoofer: zemětřesení, ale se vkusem…",
        "Vybírám filmy, které nenapálí trailer…",
        "Lovím inteligentní sci‑fi, co neurazí ani akčňáka…",
        "Kontroluji, zda prezident pronese řeč…",
        "Řadím přistání podle úhlu záběru na Bílý dům…",
        "Zkouším, zda hrdina ví, kde je vypínač…",
        "Prověřuji, kolik fyziky film unese, než přestane bavit…",
        "Odhaduji, kde se ztratí pes a kdy se vrátí…",
        "Vybírám soundtracky, co zvednou chlupy…",
        "Dávám stranou filmy, kde mimozemšťan vysvětluje plán PowerPointem…",
        "Hledám sci‑fi, u kterého se dá i přemýšlet…",
        "Kalibruji míru ironie v heroických proslovech…",
        "Zjišťuji, zda je lepší zůstat doma, nebo běžet do tunelu…",
        "Rozhoduji, jestli má město šanci bez hackerů…",
        "Porovnávám kvalitu modelů vs. CGI…",
        "Dělám audit 'červeného tlačítka'…",
        "Uvažuji, jestli se dá přežít v chladničce…",
        "Ladím tempo: pomalý první kontakt vs. hurá invaze…",
        "Dávám body za chytré zvraty bez podrazů…",
        "Prověřuji, zda je vědec charismatický aspoň jako meteorit…",
        "Vybírám filmy, co fungují i při druhé projekci…",
        "Doháním vesmír, který má zpoždění v dopravě…",
        "Kontroluji, jestli titulky nestihnou ujet ději…",
    ]

    # 2) Seriály – textová banka (~40)
    TV_PLAIN = [
        f"Hledám seriálové nitky pro {base_q}…",
        "Řadím epizody tak, aby recap seděl…",
        "Vybírám piloty, co nejsou jen prototyp…",
        "Zdařím cliffhangery bez krutosti…",
        "Kontroluji konzistenci scénářů mezi sezónami…",
        "Měřím délku binge bez ztráty pozornosti…",
        "Zkoumám, jestli druhá sezóna nebyla jen šťastná náhoda…",
        "Kalibruji titulky pro noční sledování…",
        "Přebírám universa a spin‑offy…",
        "Odstraňuji fillery, co zpomalují…",
        "Hledám soundtrack, co táhne scény dál…",
        "Porovnávám kvalitu finále vs. začátek…",
        "Mapuji oblouky postav, co dávají smysl…",
        "Třídím epizody podle 'ještě jednu a jdu spát'…",
        "Dávám body showrunnerům, co ví, kam jdou…",
        "Hledám série bez zbytečných flashbacků…",
        "Srovnávám evropskou a US stopáž…",
        "Kreslím tabuli se špagetami vztahů…",
        "Eliminuji šok jen pro šok…",
        "Prověřuji, jestli je každá epizoda mini‑film…",
        "Hledám seriály s dobrým 'Previously on'…",
        "Vážu si uzly cliffhangerů…",
        "Hledám skryté perly vedle mainstreamu…",
        "Porovnávám tempo mezi epizodami…",
        "Vybírám díly s pamětihodnými scénami…",
        "Kontroluji, zda filler není tajně character development…",
        "Odstraňuji epizody se spícím kameramanem…",
        "Zkoumám, jestli finále uzavírá, ne rozptyluje…",
        "Vyhazuji recyklované zvraty…",
        "Dohledávám chybějící české titulky…",
        "Ladím poměr procedurála vs. overarching příběhu…",
        "Dávám šanci miniseriím s ostrým koncem…",
        "Odhaluji série, které vydrží maraton…",
        "Hledám epizody, co zvednou obočí…",
        "Kontroluji, jestli pilot neurazí tvůj večer…",
        "Přepočítávám, kolik dílů 'právě ještě jeden' reálně znamená…",
        "Vybírám díly, které příběh posouvají, ne kroutí…",
        "Prověřuji, jestli recenze nelžou…",
        "Hledám seriály s výraznou vizuální identitou…",
        "Zaklepávám na dveře další sezóny…",
    ]

    # 3) Identifikace – textová banka (~40)
    ID_PLAIN = [
        f"Překládám tvůj popis {('pro ' + base_q) if Q else ''} do jazyka vyhledávače…",
        "Porovnávám scény s pamětí filmové knihovny…",
        "Vylučuji tituly, které si to jen 'myslí'…",
        "Dohledávám alternativní názvy a překlady…",
        "Vážu roky vydání s herci…",
        "Sedluji žánry: bylo to víc sci‑fi, nebo thriller?…",
        "Zjišťuji, zda šlo o film či seriál…",
        "Kontroluji stopáž proti více verzím…",
        "Křížím motivy: časová smyčka? kontakt? invaze?…",
        "Odebírám falešné vzpomínky…",
        "Zkoumám plakáty podle ikonických motivů…",
        "Rozmotávám synopsis bez spoilerů…",
        "Kontroluji, zda scéna v dešti nebyla z jiného díla…",
        "Hledám vazbu mezi citátem a titulem…",
        "Připisuji body za výrazné lokace…",
        "Zkoumám, jestli 'to' nebyl díl antologie…",
        "Prověřuji edice: kino vs. director's cut…",
        "Srovnávám soundtrack se scénou, kterou popisuješ…",
        "Procházím cameo, která všechno prozradí…",
        "Zkouším, jestli nebyl dabing zavádějící…",
        "Vytahuji střípky z kritik…",
        "Mapuji triky: praktické vs. digitální…",
        "Hledám scénu s motivem dveří/okna/ticha…",
        "Přepočítávám 'to bylo někdy kolem 2000'…",
        "Přikládám stopy z českých názvů…",
        "Testuji, zda šlo o remake…",
        "Odlišuji pilot od pozdější epizody…",
        "Validuji geolokaci záběru…",
        "Oprašuju povědomé tváře…",
        "Vytahuji staré trailery pro porovnání…",
        "Vynechávám falešné shody podle jmen postav…",
        "Znovu čtu popis: co je klíčový detail?…",
        "Propojuju detaily z tvého textu se scénami…",
        "Kontroluji, jestli to nebyla miniserie…",
        "Vážu citaci dialogu k scénáři…",
        "Dohledávám epizodní názvy…",
        "Ladím skóre pravděpodobnosti…",
        "Zkouším alternativní žánrové klíče…",
        "Prohledávám archivy podle motivu plakátu…",
        "Uzluji poslední dvě varianty…",
    ]

    # Pokud skin umí emoji, doplníme je cyklicky – bez změny textu.
    EMOJI_POOL_MOV = ["🎬", "🛸", "🚀", "🛰️", "💥", "🔭", "🧪", "📡", "🎯", "🧠", "🎞️", "🌌", "🛰", "🧲", "🎛️"]
    EMOJI_POOL_TV  = ["📺", "🧵", "🗂️", "🕰️", "🎭", "🧩", "🧭", "🎚️", "🧪", "📚", "🔁", "🧠", "📡", "🧷", "📝"]
    EMOJI_POOL_ID  = ["🔎", "📚", "🧠", "🧭", "🧩", "🧪", "📼", "🖼️", "🎞️", "🗺️", "🎧", "📝", "🧵", "🧷", "📌"]

    def _with_emoji(lines: List[str], pool: List[str]) -> List[str]:
        if not use_emoji:
            return lines
        out: List[str] = []
        for i, s in enumerate(lines):
            out.append(f"{pool[i % len(pool)]} {s}")
        return out

    # Vyber správnou banku
    if mode == "recommend" and is_tv:
        LINES = _with_emoji(TV_PLAIN, EMOJI_POOL_TV)
    elif mode == "recommend" and is_movie:
        LINES = _with_emoji(MOVIE_PLAIN, EMOJI_POOL_MOV)
    else:
        LINES = _with_emoji(ID_PLAIN, EMOJI_POOL_ID)

    def msg_start() -> str:
        if mode == "recommend":
            return ("Start: hledám tipy na seriály…" if is_tv else "Start: hledám tipy na filmy…")
        else:
            return "Start: přesně identifikuji dílo podle popisu…"

    def msg_finalizing(n: Optional[int] = None) -> str:
        if mode == "recommend":
            return f"Finalizuji doporučení{f' ({n} nalezených)' if n is not None else ''}…"
        else:
            return f"Finalizuji identifikaci{f' ({n} kandidátů)' if n is not None else ''}…"

    # — vytvoření progress okna ——————————————————————————————
    progress = _SimsProgress(heading, use_emoji)
    progress.create(msg_start())
    progress.update(3, msg_start())

    # — spuštění workeru v pozadí ————————————————————————————
    result_holder: Dict[str, Any] = {"res": None, "err": None}
    done = threading.Event()

    def _runner():
        try:
            result_holder["res"] = worker()
        except Exception as e:
            result_holder["err"] = e
        finally:
            done.set()

    th = threading.Thread(target=_runner, name="RichMovie.AIWorker", daemon=True)
    th.start()

    # — živý Sims‑like běh (dokud worker neskončí) ——————————————
    monitor = xbmc.Monitor()

    # deterministické promíchání pro stejný dotaz
    seed = int(hashlib.md5((Q + "|" + mode + "|" + (kind or "")).encode("utf-8", errors="ignore")).hexdigest(), 16)
    rnd = random.Random(seed)
    lines = list(LINES)
    rnd.shuffle(lines)

    # kdyby přesto něco selhalo, máme aspoň jednu větu
    if not lines:
        lines = [msg_start()]

    idx = 0
    pct = 3
    last_switch = time.time()
    switch_every = 2.2  # s – jak často obměnit větu
    step_every = 0.9    # s – krok v procentech
    last_step = time.time()

    while not done.is_set():
        if monitor.waitForAbort(0.2):
            break
        now = time.time()
        # posun procent
        if now - last_step >= step_every:
            last_step = now
            pct = min(85, pct + 2)  # plynule do 85 %, zbytek po návratu A.I.
            try:
                progress.update(pct, lines[idx])
            except Exception:
                pass

        # přepni větu
        if now - last_switch >= switch_every:
            last_switch = now
            idx = (idx + 1) % len(lines)
            try:
                progress.update(pct, lines[idx])
            except Exception:
                pass

    # — worker skončil: přechod do závěrečných fází ——————————————
    if result_holder["err"] is not None:
        # necháme volajícího, ať ukáže dialog s chybou; progres uklidíme tady
        try:
            progress.update(pct, "Chyba – uklízím…")
        except Exception:
            pass
        return None, progress

    # Rezerva pro závěrečnou práci volajícího (TMDb apod.)
    try:
        n = len(result_holder["res"]) if isinstance(result_holder["res"], (list, tuple)) else None
        progress.update(95, msg_finalizing(n))
    except Exception:
        pass

    return result_holder["res"], progress






# 2025‑07‑27 13:55 CEST  _ensure_internet_async() – v2 (rychlejší + spolehlivé ukončení)
def _ensure_internet_async() -> None:
    """
    Načte se **pouze jednou** (idempotentní) a v daemon vlákně ověří, zda
    existuje reálné připojení k internetu.  Při neúspěchu:

        • zobrazí modální dialog,
        • zavře aktuální okno doplňku → `Action(Back)`,
        • zruší výpis adresáře (`endOfDirectory(succeeded=False)`).

    GUI zůstává plně responzivní; maximální čekání je ≈ 4 s.
    """
    if getattr(_ensure_internet_async, "_started", False):
        return
    _ensure_internet_async._started = True

    def _has_internet() -> bool:
        """
        Bleskový test přes raw socket (DNS/ICMP filtry nevadí):

            1) TCP hand‑shake na 1.1.1.1:53 (Cloudflare DNS)
            2) TCP hand‑shake na 8.8.8.8:53 (Google DNS)

        Timeout 1.5 s na každý pokus – celkově < 3 s.
        """
        for host in (("1.1.1.1", 53), ("8.8.8.8", 53)):
            try:
                with socket.create_connection(host, timeout=1.5):
                    return True
            except OSError:
                continue
        return False

    def _worker() -> None:
        if _has_internet():
            return                              # vše OK → nic nedělej

        # ✗ Internet nedostupný – informuj uživatele a ukonči doplněk
        xbmcgui.Dialog().ok(
            "RichMovie",
            "Zdá se, že není dostupné připojení k internetu.",
            "Doplněk bude ukončen."
        )
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        except Exception:
            pass

        # Zavře GUI okno doplňku (vrátí se o úroveň zpět / do domovské nabídky)
        xbmc.executebuiltin("Action(Back)")

    threading.Thread(target=_worker, name="RMNetCheck", daemon=True).start()






# ――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――
# 🌟  Helper: bezpečné získání Kodi handle
# ――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――
def _safe_handle(argv: list[str]) -> int:
    """
    Vrátí číslo *handle* předané Kodi při standardním spuštění doplňku.

    • Při běžném volání z GUI je `argv[1]` platné celé číslo.  
    • Pokud je modul pouze **importován** (např. `service_nextup.py`),
      `argv` má délku 1 → funkce vrací `‑1`.

    Hodnota ‑1 znamená „žádný GUI handle“; zbytek kódu (vyhledávání,
    RAM‑cache Next‑Up, TMDb volání apod.) může bezpečně běžet dál,
    protože nevolá žádné GUI funkce závislé na `xbmcplugin.*`.
    """
    try:
        return int(argv[1])
    except (IndexError, ValueError):
        return -1



# --------------------------------------------------------------------------- #
#  GLOBÁLNÍ KONTEXT DOPLŇKU
# --------------------------------------------------------------------------- #
ADDON      = xbmcaddon.Addon()
HANDLE     = _safe_handle(sys.argv)      # ⇐ bezpečná varianta
ADDON_ID   = ADDON.getAddonInfo("id")


# – Kodi cesty k profilu a logům –
PROFILE_DIR   = Path(xbmcvfs.translatePath(
    f"special://profile/addon_data/{ADDON_ID}"
))
PROFILE_DIR.mkdir(parents=True, exist_ok=True)

_LOG_PATH         = str(PROFILE_DIR / "richmovie.log")
_SEARCH_LOG_PATH  = ""         # nastaví se dynamicky


# 2025-08-10 21:57 CEST (Europe/Prague)
# VLOŽ hned pod deklarace:
#   PROFILE_DIR = ...
#   _LOG_PATH   = str(PROFILE_DIR / "richmovie.log")
#   _SEARCH_LOG_PATH = ""
_AI_LOG_PATH = str(PROFILE_DIR / "RichMovie_a.i.log")


# – Thread‑safe zámek pro log –
_LOG_LOCK = threading.Lock()

# --------------------------------------------------------------------------- #
#  SESSION  (Webshare login + VIP helpery)
# --------------------------------------------------------------------------- #
_SESSION = SessionManager(ADDON, HANDLE)

# --------------------------------------------------------------------------- #
#  SEARCH ENGINE  (využívá globální session + logger)
# --------------------------------------------------------------------------- #
# Globální přepínač:  Nastavení → „Podrobná analýza MediaInfo“
try:
    _PROBE_ENABLED = ADDON.getSettingBool("probe_enabled")
except AttributeError:                          # Kodi &le; v18 fallback
    _PROBE_ENABLED = ADDON.getSetting("probe_enabled") == "true"

_ENGINE = SearchEngine(
    lambda: _SESSION.client,
    lambda *p: _log_event(*p),
    enable_probe=_PROBE_ENABLED,                # ⬅️ předáváme do SearchEnginu
)











# --------------------------------------------------------------------------- #
# 2025‑07‑19 16:39 CEST  _spin_tokens() – back‑compat wrapper  (plugin.py)
# --------------------------------------------------------------------------- #
def _spin_tokens(
    tv_id: str,
) -> tuple[set[str], set[str]]:
    """
    Zpětně kompatibilní obálka pro novou funkci ``spin_tokens()`` z
    *richmovie_engine.py*.

    • Původní kód pluginu očekává pouze parametr ``tv_id``.  
    • Nová implementace vyžaduje ještě ``tmdb_key``, který zde
      načteme z nastavení doplňku (⚙ → TMDb API klíč).  
    • Pokud klíč chybí nebo je prázdný, vracíme prázdné množiny, aby
      se chování oproti dřívějšku nezměnilo.

    Parametry
    ---------
    tv_id : str
        TMDb ID aktuálního seriálu.

    Návrat
    ------
    (allow, ban) : tuple[set[str], set[str]]
        Dvojice tokenů pro allow‑list a ban‑list.
    """
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        return set(), set()
    # volání nové funkce v richmovie_engine.py
    return spin_tokens(tv_id, tmdb_key)







# --------------------------------------------------------------------------- #
#  NEXT‑UP  – RAM cache přednačtených dílů + tiché vyhledání
# --------------------------------------------------------------------------- #
from typing import Tuple, List

# (tv_id, season, episode) → List[Release]   (připravené releasy)
NEXT_CACHE: dict[Tuple[str, int, int], List['Release']] = {}




def _search_episode(
    tv_id: str,
    tv_name: str,
    season_no: int,
    ep_no: int,
    ep_title: str = "",
) -> List[Release]:
    """
    Tiché vyhledání releasů epizody (Next‑Up prefetch) – běží na pozadí.

    10-08-2025 16:31 CEST (Europe/Prague)
    -------------------------------------
    ZMĚNA: Po CS/EN `episode_details()` nově volám i
           `TMDb.episode_translations()` a přidám klíčové EN názvy
           (en-US/en-GB/en) + heuristiku „The One Where/With …“.
           Sanitizace ban‑tokenů tak vždy zná i EN slova z názvu epizody.
    """
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    tmdb     = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    # 1) --- názvy seriálu (aliasy) ---
    tv_names: List[str] = [tv_name]
    if tmdb and tv_id.isdigit():
        try:
            det = tmdb.tv_details(int(tv_id))
            tv_names += [det.get("original_name", "")]
            alts = tmdb._get_json(
                f"/tv/{tv_id}/alternative_titles", {"api_key": tmdb_key}
            ).get("results", [])
            tv_names += [
                alt["title"] for alt in alts
                if alt.get("title")
                and alt.get("iso_3166_1") in _ALT_COUNTRY_WHITELIST
                and re.search(r"[A-Za-z]", alt["title"])
            ]
        except TMDbError:
            pass  # aliasy nejsou kritické

    # 2) --- názvy epizody (CS + EN + TRANSLATIONS) ---
    ep_names: List[str] = [ep_title] if ep_title else []
    ep_cs: Dict[str, Any] = {}
    if tmdb and tv_id.isdigit():
        # CS
        try:
            ep_cs = tmdb.episode_details(int(tv_id), season_no, ep_no)
            name_cs = (ep_cs.get("name") or "").strip()
            if name_cs:
                ep_names.append(name_cs)
        except TMDbError:
            ep_cs = {}

        # EN (detail)
        try:
            ep_en = TMDb(tmdb_key, lang="en-US").episode_details(
                int(tv_id), season_no, ep_no
            )
            name_en = (ep_en.get("name") or "").strip()
            orig_en = (ep_en.get("original_name") or name_en).strip()
            if name_en:
                ep_names.append(name_en)
            if orig_en:
                ep_names.append(orig_en)
        except TMDbError:
            pass

        # Translations – jistota plného EN názvu (i když detail vrátí jen „Pilot“)
        try:
            trs = tmdb.episode_translations(int(tv_id), season_no, ep_no)
            pref_keys = ("en-US", "en-GB", "en", "cs-CZ", "cs")
            seen_lc = {n.lower() for n in ep_names}
            for k in pref_keys:
                nm = (trs.get(k) or "").strip()
                if nm and nm.lower() not in seen_lc:
                    ep_names.append(nm)
                    seen_lc.add(nm.lower())
            # Heuristika: pokud chybí „The One Where/With …“, a přesto je v překladech, přidej ho
            if not any(re.search(r"\bthe one (where|with)\b", n.lower()) for n in ep_names):
                for nm in trs.values():
                    if nm and re.search(r"\bthe one (where|with)\b", nm.lower()):
                        if nm.lower() not in seen_lc:
                            ep_names.append(nm)
                            break
        except TMDbError:
            pass

        if not ep_title:
            ep_title = (ep_cs.get("name") or "").strip()

    # 3) --- dotazy ---
    queries = QueryBuilder.tv(tv_names, ep_names, season_no, ep_no)

    # 4) --- tokeny pro filtr ---
    title_norms: List[str] = []
    _seen: set[str] = set()
    for tok in (
        f"s{season_no:02d}e{ep_no:02d}",
        f"{season_no}x{ep_no:02d}",
        f"{season_no:02d}x{ep_no:02d}",
    ):
        n = _norm(tok);  title_norms.append(n);  _seen.add(n)
    for nm in (*tv_names, *ep_names):
        for w in nm.split():
            n = _norm(w)
            if n and n not in _seen:
                title_norms.append(n); _seen.add(n)

    # zákaz jiné S/E + erotika
    banned_keys: set[str] = {
        _norm(p)
        for sn in range(1, 100)
        for en in range(1, 100)
        if not (sn == season_no and en == ep_no)
        for p in (f"s{sn:02d}e{en:02d}", f"{sn}x{en:02d}", f"{sn:02d}x{en:02d}")
    }
    if not (_is_adult_title(tv_name) or _is_adult_title(ep_title)):
        banned_keys |= {_norm(w) for w in EROTIC_KEYWORDS}

    # spin‑off allow/ban + SANITIZACE (vyhoď slova z názvu seriálu+epizody)
    allow_tok, ban_tok = spin_tokens(tv_id) if tv_id else (set(), set())
    title_norms += [t for t in allow_tok if t not in _seen]
    _ep_tv_words = {_norm(w) for nm in (*tv_names, *ep_names) for w in nm.split() if _norm(w)}
    _ban_before = len(ban_tok)
    if _ep_tv_words:
        ban_tok = {t for t in ban_tok if t not in _ep_tv_words}
    _ban_removed = _ban_before - len(ban_tok)
    if _ban_removed > 0:
        _log_event("SPIN_BAN_SANITIZE", tv_id, f"removed={_ban_removed}")
    banned_keys |= ban_tok

    # epizodní slovníky (varianty)
    ep_title_variants = [
        [_norm(w) for w in nm.split() if _norm(w)]
        for nm in ep_names if nm
    ]

    # 2025-08-19 10:39 CEST (Europe/Prague) – allowed_years pro engine
    allowed_years: set[int] = set()
    def _yr(val: str | None) -> int | None:
        if not val:
            return None
        m = re.match(r"(\d{4})", str(val))
        return int(m.group(1)) if m else None

    # Rok seriálu
    try:
        tv_year = _yr(det.get("first_air_date")) if det else None
        if tv_year:
            allowed_years.add(tv_year)
    except Exception:
        pass

    # Rok série (season)
    try:
        if tmdb_key and tv_id.isdigit() and season_no:
            season_json = TMDb(tmdb_key, lang="cs-CZ")._get_json(
                f"/tv/{tv_id}/season/{season_no}", {"api_key": tmdb_key, "language": "cs-CZ"}
            )
            season_year = _yr(season_json.get("air_date"))
            if season_year:
                allowed_years.add(season_year)
    except Exception:
        pass

    # Rok epizody (CS nebo EN detail – už máme načtené výše)
    try:
        ep_year = _yr((ep_cs or {}).get("air_date")) or _yr((ep_en or {}).get("air_date"))
        if ep_year:
            allowed_years.add(ep_year)
    except Exception:
        pass


    # 5) --- vyhledávání po vlnách ---
    bucket: Dict[str, Release] = {}
    def _run(qs: List[str]) -> None:
        if not qs: return
        for r in _ENGINE.search_wave(
            qs, title_norms=title_norms, banned_keys=banned_keys,
            ep_title_variants=ep_title_variants, progress_cb=None,
            max_quick_probe=0, top_full_probe=15,
        ):
            bucket.setdefault(r.ident, r)

    _run(queries[0:6]); _run(queries[6:12])
    if len(bucket) < 10: _run(queries[12:18])
    if len(bucket) < 5:  _run(queries[18:])
    return list(bucket.values())





# --------------------------------------------------------------------------- #
# 2025‑07‑20 14:11 CEST  _log_event()  – bez závislosti na zoneinfo
#               (plugin.py – nahraďte stávající implementaci 1 : 1)
# --------------------------------------------------------------------------- #
_CTX = threading.local()              # thread‑safe úschovna aktuálního query




# 2025-08-09 18:15 CEST  _log_event() – EXTREME TRACE log (NDJSON) + zachování původních TXT logů
def _log_event(event: str, *params: object) -> None:
    """
    Zápis do rotačního TXT logu **richmovie.log** a případně i do **NDJSON trace** souboru
    (1 řádek = 1 JSON objekt) pro snadnou následnou analýzu.

    • 100 % zachováno původní chování (TXT logy, rotace, thread‑local query).
    • Přidáno: volitelný NDJSON výstup s detailními poli.
    • U `FILTER_REJECT quick` doplníme i **přesnou velikost souboru, příponu,
      odhad kvality a minimální velikost**, které vedly k odmítnutí.

    Nastavení (v settings.xml):
      - trace_enabled           (zapíná/vypíná extrémní logování)
      - trace_ndjson            (ukládá i NDJSON trace soubor)
      - trace_log_successes     (zapisovat do NDJSON i úspěšné položky)
    """
    # --- 0) Nastavení (čteno runtime, aby šlo přepnout bez restartu) ----------
    try:
        trace_enabled = ADDON.getSettingBool("trace_enabled")
    except AttributeError:
        trace_enabled = ADDON.getSetting("trace_enabled") == "true"
    try:
        trace_ndjson = ADDON.getSettingBool("trace_ndjson")
    except AttributeError:
        trace_ndjson = ADDON.getSetting("trace_ndjson") == "true"
    try:
        trace_log_successes = ADDON.getSettingBool("trace_log_successes")
    except AttributeError:
        trace_log_successes = ADDON.getSetting("trace_log_successes") == "true"

    # --- 1) Doplň thread‑local query do vybraných událostí --------------------
    # Původní funkce: při RAW_SEARCH uložíme query do _CTX; u dalších eventů je doplníme.
    if event == "RAW_SEARCH" and params:
        _CTX.query = str(params[0])
    elif event in {"WS_RESULTS", "FILTER_ACCEPT", "FILTER_REJECT"}:
        query = getattr(_CTX, "query", "")
        if query:
            params = (query, *params)

    # --- 2) TXT log: původní chování (rotace + zápis) -------------------------
    ts_txt = datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")
    row    = "\t".join([ts_txt, event, *(str(p) for p in params)])
    path   = _SEARCH_LOG_PATH or _LOG_PATH

    # Rotace globálního logu (2 MiB) – zachováno
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if path == _LOG_PATH and os.path.exists(path) and os.path.getsize(path) > 2_097_152:
            bak = f"{path}.1"
            if os.path.exists(bak):
                os.remove(bak)
            os.replace(path, bak)
    except Exception:
        pass

    with _LOG_LOCK:
        try:
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(row + "\n")
        except Exception:
            # fall back: do nothing (nechceme zablokovat běh kvůli logu)
            pass

    # --- 3) NDJSON decision‑trace (volitelné) ---------------------------------
    if not (trace_enabled and trace_ndjson):
        return

    # a) Kde bude NDJSON? → stejné jméno jako *_SEARCH_LOG_PATH*, ale složka "traces/" a přípona .ndjson
    try:
        base = _SEARCH_LOG_PATH or _LOG_PATH
        base_dir = os.path.dirname(base)
        trace_dir_root = os.path.dirname(base_dir) if base_dir.endswith("richmovie") else base_dir
        trace_dir = os.path.join(trace_dir_root, "traces")
        if not xbmcvfs.exists(trace_dir):
            xbmcvfs.mkdirs(trace_dir)
        fname = os.path.basename(base)
        if fname.endswith(".log"):
            fname = fname[:-4] + ".ndjson"
        else:
            fname = fname + ".ndjson"
        ndjson_path = os.path.join(trace_dir, fname)
    except Exception:
        # Konzervativně – když se nepovede složka, skončíme jen s TXT logem
        return

    # b) Základní objekt
    ts_iso = datetime.datetime.now().astimezone().isoformat()
    search_id = os.path.splitext(os.path.basename(_SEARCH_LOG_PATH))[0] if _SEARCH_LOG_PATH else ""
    # Rozbalíme parametry – robustně (bez fixních indexů)
    query = getattr(_CTX, "query", "")
    ident = ""
    reason = ""
    name = ""

    details_dict = None
    for p in params:
        if isinstance(p, dict):
            details_dict = p
        elif isinstance(p, str):
            # heuristika: první alfanumerické bez mezer s délkou >= 8 bereme jako ident
            if not ident and p and p.isalnum() and len(p) >= 8:
                ident = p
            # reason kód: krátké slovo s podtržítkem / alfanum (např. token_ser_miss_1/2, quick, other_part, …)
            if not reason and ("_" in p or p.isalpha()) and len(p) <= 32 and p.lower() == p:
                reason = p
            # name: nejdelší text s tečkami/mezerami
            if len(p) > len(name):
                name = p

    obj = {
        "ts": ts_iso,
        "search_id": search_id or None,
        "event": event,
        "query": query or None,
        "ident": ident or None,
        "reason": reason or None,
        "name": name or None,
    }
    if isinstance(details_dict, dict):
        # převeďme na JSON‑serializovatelné hodnoty
        try:
            json.dumps(details_dict)  # test
            obj.update(details_dict)
        except Exception:
            # best‑effort: převedeme na str
            obj["details_raw"] = str(details_dict)

    # d) Obohacení pro vybrané kódy (quick) – doplníme velikost/příponu/limity
    #    Pozn.: je to *jen pro logování*; logika vyhledávání se nezmění.
    try:
        if event == "FILTER_REJECT" and ("quick" in (reason or "") or reason == "") and ident:
            # Získáme detail souboru (size apod.) – volitelné a chráněné try/except
            size_mb = None
            ws_name = name
            try:
                info = _SESSION.client.file_info(ident)
                size_mb = (info.get("size") or 0) / 1_048_576
                ws_name = info.get("name") or name
            except Exception:
                pass

            # Odvodíme příponu/kvalitu/min. velikost (stejně jako engine)
            nm = (ws_name or name or "")
            ext = os.path.splitext(nm)[1].lower()
            is_episode = bool(re.search(r"(?:s\d{1,2}e\d{1,2}|\d{1,2}[xX]\d{2})", nm, re.I))
            # hrubý odhad kvality
            nml = nm.lower()
            if "2160p" in nml or "4k" in nml:
                q = "2160p"
            elif "1080p" in nml or "fullhd" in nml:
                q = "1080p"
            elif "720p" in nml or "hd" in nml:
                q = "720p"
            elif "webrip" in nml or "web-dl" in nml or "webdl" in nml:
                q = "webrip"
            elif "cam" in nml:
                q = "cam"
            else:
                q = "other"

            min_map = {"2160p": 2000, "1080p": 700, "720p": 350, "webrip": 300, "other": 250, "cam": 0}
            min_size_mb = 50 if is_episode else min_map.get(q, 250)
            video_ext_ok = ext.lower() in {".mkv", ".mp4", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".webm", ".m4v"}

            obj.setdefault("debug", {}).update({
                "quick": True,
                "ext": ext or None,
                "size_mb": round(size_mb, 1) if isinstance(size_mb, (int, float)) else None,
                "min_size_mb": min_size_mb,
                "quality_guess": q,
                "is_episode": is_episode,
                "video_ext_ok": video_ext_ok,
            })
    except Exception:
        pass

    # e) Pokud je to ACCEPT a uživatel nechce logovat úspěchy, přeskočíme
    if event == "FILTER_ACCEPT" and not trace_log_successes:
        return

    # f) Zápis do NDJSON
    try:
        with _LOG_LOCK:
            with open(ndjson_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(obj, ensure_ascii=False) + "\n")
    except Exception:
        # nechceme, aby log blokoval doplněk
        pass






# 2025‑07‑27 23:59 CEST  – kompatibilní wrapper pro starší workflow
def _start_search_log(title: str, year: int | str = "") -> None:
    """
    START per‑search logu (starý alias).
    Vytvoří unikátní *.log soubor ↔ `_SEARCH_LOG_PATH`
    a zapíše úvodní řádek SEARCH_BEGIN.

    Args:
        title: Název hledaného díla.
        year:  Rok premiéry (může být prázdný).
    """
    global _SEARCH_LOG_PATH

    # 1) Adresář pro dočasné logy
    log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
    if not xbmcvfs.exists(log_dir):
        xbmcvfs.mkdirs(log_dir)

    # 2) Bezpečný název souboru
    ts   = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    safe = re.sub(r"[^0-9A-Za-z]+", "_", f"{title}_{year}")[:50]
    _SEARCH_LOG_PATH = os.path.join(log_dir, f"{ts}_{safe}.log")

    # 3) Úvodní záznam
    _log_event("SEARCH_BEGIN", title, year)






# 2025‑07‑27 23:59 CEST  – kompatibilní wrapper pro starší workflow
def _end_search_log(title: str, result: object) -> None:
    """
    END per‑search logu (starý alias).
    Zapíše výsledkový řádek SEARCH_END a uvolní `_SEARCH_LOG_PATH`.

    Args:
        title:  Titulek hledání (kvůli konzistenci s BEGIN).
        result: Počet nalezených releasů nebo řetězec `'ERR'`.
    """
    _log_event("SEARCH_END", title, result)

    # Reset, aby další hledání začínalo s čistou cestou
    global _SEARCH_LOG_PATH
    _SEARCH_LOG_PATH = ""







# --------------------------------------------------------------------------- #
#  MALÉ GUI POMOCNÍCI
# --------------------------------------------------------------------------- #

def _format_int_spaced(n: int) -> str:
    """10 000 → '10 000'  (pevná mezera pro tisíce)"""
    return f"{n:,}".replace(",", " ")




def _format_mediainfo(mi: dict) -> str:
    """
    Převod MediaInfo slovníku na čitelný blok textu.
    Zobrazujeme jen to podstatné – container, video, audio, titulky.
    """
    if not mi:
        return "MediaInfo nebyla k dispozici."

    out = []

    # – container / délka –
    dur = mi.get("duration", 0)
    if dur:
        out.append(f"CONTAINER  …  {dur//60} min {dur%60:02d} s")

    # – tracky –
    for t in mi.get("tracks", []):
        tt = t.get("track_type", "")
        if tt == "Video":
            out.append(
                "VIDEO      …  "
                f"{t.get('format', '')} {t.get('bit_depth', '')}‑bit  "
                f"{t.get('width', '')}×{t.get('height', '')}@{t.get('frame_rate', '')}fps  "
                f"{t.get('hdr_format', '')}".strip()
            )
        elif tt == "Audio":
            lang = t.get("language", "").upper() or "und"
            out.append(
                "AUDIO      …  "
                f"{t.get('format', '')} {t.get('channel_s', '')}  "
                f"{lang}"
            )
        elif tt == "Text":
            lang = t.get("language", "").upper() or "und"
            out.append(f"SUBTITLES …  {lang}  ({t.get('format', '')})")

    return "\n".join(out) or "Žádná MediaInfo data."





def _keyboard_input(heading: str, hidden: bool = False) -> str | None:
    kb = xbmc.Keyboard("", heading, hidden)
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else None





def _modal(msg: str, heading: str = "RichMovie", block: bool = True) -> None:
    xbmcgui.Dialog().ok(heading, msg) if block else xbmcgui.Dialog().notification(
        heading, msg, xbmcgui.NOTIFICATION_INFO, 4000
    )




# 2025‑07‑23 10:45 CEST  – NOVÁ
def _ensure_stream_resolver(interactive: bool = True) -> bool:
    """
    Vrátí True, pokud lze importovat stream.resolver.
    Pokud chybí, zavolá Kodi builtin InstallAddon a zkusí import znovu.
    """
    try:
        import stream.resolver                     # už nainstalováno
        return True
    except ModuleNotFoundError:
        pass

    if interactive:
        xbmcgui.Dialog().notification(
            "RichMovie", "Instaluji modul stream.resolver…",
            xbmcgui.NOTIFICATION_INFO, 3000
        )
    xbmc.executebuiltin(
        "InstallAddon(script.module.stream.resolver)"
    )
    xbmc.sleep(3000)                               # počkej na instalaci

    # vyprázdni případný starý záznam v sys.modules
    sys.modules.pop("stream.resolver", None)

    try:
        importlib.import_module("stream.resolver")
        return True
    except ModuleNotFoundError:
        if interactive:
            xbmcgui.Dialog().ok(
                "RichMovie",
                "Modul stream.resolver se nepodařilo nainstalovat.\n"
                "Přidejte repozitář Sosáče nebo jej nainstalujte ručně."
            )
        return False







# --------------------------------------------------------------------------- #
#  Jednorázová toast zpráva o MediaInfo (pouze po otevření doplňku)
# --------------------------------------------------------------------------- #
def _notify_mediainfo_once() -> None:
    """
    Zobrazí notifikaci o dostupnosti MediaInfo max. 1× za běh Kodi a
    **jen** pokud uživatel povolil „Podrobnou analýzu MediaInfo“.

    Logika:
        • probe_enabled == False            → ticho
        • MediaInfo není dostupná          → ticho
        • GUI‑property již nastavená       → ticho
        • jinak: toast + nastavit property
    """
    if not ADDON.getSettingBool("probe_enabled"):
        return
    if not richmovie_webshare.MEDIAINFO_AVAILABLE:
        return

    win = xbmcgui.Window(10000)                          # globální „home window“
    if win.getProperty("RichMovie.MediaInfoToastShown"):
        return                                           # už jsme hlásili

    win.setProperty("RichMovie.MediaInfoToastShown", "1")
    # Pozdržíme 4,5 s, aby nezakrylo login‑toast (ten má timeout 4 s)
    xbmc.sleep(4500)
    xbmcgui.Dialog().notification(
        "RichMovie",
        "MediaInfo knihovna načtena – přesný odhad stopáže aktivní.",
        xbmcgui.NOTIFICATION_INFO,
        5000,
    )






def _progress(total: int) -> xbmcgui.DialogProgress:
    dlg = xbmcgui.DialogProgress()
    dlg.create("RichMovie", "Probíhá vyhledávání…")
    dlg.update(0)
    return dlg


# --------------------------------------------------------------------------- #
#  HISTORIE VYHLEDÁVÁNÍ  (zatím v pluginu, později přesun)
# --------------------------------------------------------------------------- #
_HIST_PATH = PROFILE_DIR / "history.json"


# 2025-08-14 18:55 CEST (Europe/Prague)
# Historie sledování – trvalé uložení do addon_data
_WATCH_PATH = PROFILE_DIR / "watch_history.json"
_WATCH_MAX_ITEMS = 200  # rozumný strop na každou větev (movies / episodes)




# ──────────────────────────────────────────────────────────────────────
#  plugin.py – _historie:  _load_history()
# ──────────────────────────────────────────────────────────────────────
def _load_history() -> Dict[str, List[str]]:
    """
    Načte historii vyhledávání z JSON souboru a vždy vrací
    strukturu ``{"movie": [...], "tv": [...], "ws": [...], "other": [...]}``.

    • **Migrace** – pokud najde starý formát (list řetězců),
      považuje jej za filmové dotazy a automaticky převádí.
    • Případné chybné / poškozené soubory ignoruje → vrací čistou strukturu.
    """
    blank = {"movie": [], "tv": [], "ws": [], "other": []}

    try:
        with open(_HIST_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return blank

    # – starý formát: prostý seznam řetězců ––––––––––––––––––––––––––––
    if isinstance(data, list):
        return {"movie": data[:50], "tv": [], "ws": [], "other": []}

    # – nový formát – zajistíme, že nechybí žádný klíč ––––––––––––––––
    if isinstance(data, dict):
        out = {k: list(v)[:50] for k, v in data.items() if isinstance(v, list)}
        for key in blank:
            out.setdefault(key, [])
        return out

    return blank







# ──────────────────────────────────────────────────────────────────────
#  plugin.py – _historie:  _save_history()
# ──────────────────────────────────────────────────────────────────────
def _save_history(hist: Dict[str, List[str]]) -> None:
    """
    Uloží strukturu historie do JSON souboru.

    • Zapisuje atomicky – nejprve na temp soubor, potom `os.replace`  
    • Nikdy nepropaguje výjimku, aby nepadal doplněk
    """
    try:
        tmp = f"{_HIST_PATH}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(hist, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, _HIST_PATH)
    except Exception:
        pass






# ──────────────────────────────────────────────────────────────────────
#  plugin.py – _historie:  _add_to_history()
# ──────────────────────────────────────────────────────────────────────
def _add_to_history(term: str, category: str | None = None) -> None:
    """
    Přidá `term` do historie vyhledávání dané *kategorie*
    (`"movie"`, `"tv"`, `"ws"`, nebo `"other"`).

    • Pokud `category` není předáno, určí se heuristicky podle toho,
      která funkce (_movie_search / _tv_search / _ws_search) záznam vložila.  
    • Duplikáty odsouvá dolů (nejnovější hledání je vždy na indexu 0).  
    • Každá kategorie drží max 50 položek.
    """
    # — 1) auto‑detekce volající funkce (fallback) ————————————————
    if category is None:
        frame = inspect.currentframe()
        caller = frame.f_back.f_code.co_name if frame and frame.f_back else ""
        category = {
            "_movie_search": "movie",
            "_tv_search":    "tv",
            "_ws_search":    "ws",
        }.get(caller, "other")

    category = category.lower()
    if category not in {"movie", "tv", "ws", "other"}:
        category = "other"

    # — 2) načíst, upravit, uložit ————————————————————————————————
    hist = _load_history()

    # dopředné pořadí (nejnovější první) + odstranění duplicit
    items = [term] + [t for t in hist[category] if t != term]
    hist[category] = items[:50]

    _save_history(hist)






# ──────────────────────────────────────────────────────────────────────
#  plugin.py – _historie:  _show_history()
# ──────────────────────────────────────────────────────────────────────
def _show_history() -> None:
    """
    GUI prohlížeč historie:

        1) Nabídne výběr kategorie – Filmy / Seriály / Webshare / Ostatní  
        2) Po výběru zobrazí konkrétní dotazy a po kliknutí spustí
           odpovídající vyhledávací workflow.
    """
    hist = _load_history()
    if not any(hist.values()):
        _modal("Historie je prázdná.")
        return

    # — 1) výběr kategorie ——————————————————————————————
    cats = [
        ("movie", "Filmy",     len(hist["movie"])),
        ("tv",    "Seriály",   len(hist["tv"])),
        ("ws",    "Webshare",  len(hist["ws"])),
        ("other", "Ostatní",   len(hist["other"])),
    ]
    labels = [f"{label}  ({cnt})" for _key, label, cnt in cats if cnt]
    keys   = [key               for key, _label, cnt in cats if cnt]

    sel_cat = xbmcgui.Dialog().select("Historie – vyberte kategorii", labels)
    if sel_cat < 0:
        return
    cat_key = keys[sel_cat]
    items   = hist[cat_key]
    if not items:
        _modal("Tato kategorie je prázdná.")
        return

    # — 2) výběr dotazu ——————————————————————————————
    sel_item = xbmcgui.Dialog().select("Vyberte dotaz", items)
    if sel_item < 0:
        return
    term = items[sel_item]

    # — 3) delegace na správnou funkci ————————————————
    if cat_key == "movie":
        _movie_search(term)
    elif cat_key == "tv":
        _tv_search(term)
    elif cat_key == "ws":
        _ws_search(term)
    else:
        # pro „other“ zkusíme nejprve filmové hledání, jinak Webshare
        if not _movie_search(term):
            _ws_search(term)



# 2025-08-14 20:24 CEST (Europe/Prague)  – _watch_history(): přidána třetí volba „Vymazat historii…“ (volá _watch_history_clear)
def _watch_history() -> None:
    """
    Zobrazí vstupní dialog pro „Historie sledování“.
    Volby:
      1) Seriály – otevře seznam naposledy sledovaných epizod.
      2) Filmy   – otevře seznam naposledy sledovaných filmů.
      3) Vymazat historii… – bezpečně smaže watch_history.json a založí prázdnou strukturu.

    Pozn.: Tato metoda volá přímo `_watch_history_clear()` (není nutná extra routing větev).
    """
    try:
        hist = _watch_load()
        labels = [
            f"Seriály ({len(hist.get('episodes', []))})",
            f"Filmy ({len(hist.get('movies', []))})",
            "Vymazat historii…",
        ]
    except Exception:
        # v nouzi zobrazíme generické popisky
        labels = ["Seriály", "Filmy", "Vymazat historii…"]

    sel = xbmcgui.Dialog().select("Historie sledování – vyberte akci", labels)
    if sel < 0:
        return

    if sel == 0:
        # Seriály
        try:
            _watch_history_tv()
        except NameError:
            try:
                _modal("Seznam naposledy sledovaných epizod doplníme v dalším kroku.")
            except NameError:
                xbmcgui.Dialog().ok("RichMovie", "Seznam naposledy sledovaných epizod doplníme v dalším kroku.")
    elif sel == 1:
        # Filmy
        try:
            _watch_history_movies()
        except NameError:
            try:
                _modal("Seznam naposledy sledovaných filmů doplníme v dalším kroku.")
            except NameError:
                xbmcgui.Dialog().ok("RichMovie", "Seznam naposledy sledovaných filmů doplníme v dalším kroku.")
    else:
        # Vymazat historii…
        if xbmcgui.Dialog().yesno("RichMovie", "Opravdu chcete vymazat historii sledování?", nolabel="Ne", yeslabel="Ano, vymazat"):
            try:
                _watch_history_clear()
            finally:
                # po smazání zůstaň v dialogu – nabídneme prázdné počty
                pass





# 2025-08-14 20:32 CEST (Europe/Prague) – _watch_history_movies(): doplněna horní položka „🗑 Vymazat historii…“ (otevře náš dialog s volbou smazání)
def _watch_history_movies() -> None:
    """
    Zobrazí seznam naposledy sledovaných filmů.
    • Stylově stejné jako naše TMDb výpisy (poster, fanart, plot, rating/votes).
    • Kliknutí:
        – pokud je k dispozici TMDb ID → `action="auto"` (rychlé dohledání releasů),
        – jinak fallback na `action="movie_search"` s názvem filmu.
    • V horní části přidána položka „🗑 Vymazat historii…“, která otevře dialog
      _watch_history() s volbou smazání (není potřeba nová routing větev).
    """
    hist = _watch_load().get("movies", [])
    if not hist:
        _modal("Historie filmů je prázdná.")
        return

    # TMDb detail použijeme pro hezčí kartičky, když máme klíč i ID
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    tmdb = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    xbmcplugin.setPluginCategory(HANDLE, "Historie sledování – Filmy")
    xbmcplugin.setContent(HANDLE, "movies")

    # ──────────────────────────────────────────────────────────────────
    # HORNÍ POMOCNÁ POLOŽKA: „Vymazat historii…“ (otevře náš dialog)
    # ──────────────────────────────────────────────────────────────────
    try:
        li_clear = xbmcgui.ListItem("[COLOR red]🗑 Vymazat historii…[/COLOR]")
    except Exception:
        li_clear = xbmcgui.ListItem("Vymazat historii…")
    # použijeme URL na náš vlastní dialog „Historie sledování“, kde je volba smazat
    xbmcplugin.addDirectoryItem(
        HANDLE,
        _url(action="watch_history"),
        li_clear,
        isFolder=False
    )

    # ──────────────────────────────────────────────────────────────────
    # VLASTNÍ VÝPIS FILMŮ Z HISTORIE
    # ──────────────────────────────────────────────────────────────────
    for it in hist:
        tmdb_id = it.get("tmdb")
        title   = (it.get("title") or "").strip()
        year    = it.get("year") or 0

        # Základní skeleton položky
        m = {"title": title, "year": year, "overview": "", "poster_path": "", "backdrop_path": "", "rating": 0.0, "votes": 0}

        # Obohacení z TMDb (pokud máme klíč i ID)
        if tmdb and tmdb_id:
            try:
                det = tmdb.details(int(tmdb_id))
                m.update({
                    "id":            det.get("id"),
                    "overview":      det.get("overview") or "",
                    "poster_path":   det.get("poster_path") or "",
                    "backdrop_path": det.get("backdrop_path") or "",
                    "rating":        round(det.get("vote_average") or 0, 1) if det.get("vote_count", 0) else 0,
                    "votes":         det.get("vote_count") or 0,
                })
                if not m["title"]:
                    m["title"] = det.get("title") or det.get("original_title") or title
                if not m["year"] and det.get("release_date"):
                    try:
                        m["year"] = int(str(det["release_date"])[:4])
                    except Exception:
                        pass
            except TMDbError:
                pass

        # Vzhled položky jako v TMDb seznamech
        label_core  = m["title"] if not m.get("year") else f"{m['title']} ({m['year']})"
        label_left  = label_core
        label_right = f"★ {m['rating']}" if m.get("rating") else ""

        li = xbmcgui.ListItem(label_left)
        if label_right:
            li.setLabel2(label_right)

        art = {"icon": "DefaultVideo.png"}
        if m.get("poster_path"):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{m['poster_path']}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{m['poster_path']}"
        if m.get("backdrop_path"):
            art["fanart"] = f"https://image.tmdb.org/t/p/original{m['backdrop_path']}"
        li.setArt(art)

        info = {
            "title":     m["title"] or title or "Film",
            "plot":      m.get("overview") or "",
            "mediatype": "movie",
            "year":      m.get("year") or 0,
        }
        if m.get("rating"):
            info["rating"] = m["rating"]
            info["votes"]  = m.get("votes", 0)
        li.setInfo("video", info)

        # Klik – preferuj auto podle TMDb, jinak plnotextové hledání
        if (m.get("id") or tmdb_id):
            url = _url(action="auto", tmdb=str(m.get("id") or tmdb_id))
            is_folder = True
        else:
            url = _url(action="movie_search", q=(m["title"] or title))
            is_folder = True

        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)





# plugin.py – nahradit CELÝ obsah metody _watch_history_tv()
def _watch_history_tv() -> None:
    """
    Zobrazí „mix“ posledních epizod napříč seriály z naší watch‑historie.
    • Label položky:  "<SERIÁL> SxxEyy – <název epizody>"
    • InfoTagy (nově): title (ep_title), tvshowtitle, season, episode, mediatype=episode, plot (popis epizody)
    • Artwork (nově): thumb/landscape = still z epizody, poster/fanart = ze seriálu, clearlogo = logo seriálu
    • Pravý panel (nově): ListItem.Property("richmovie.series_title"/"richmovie.series_plot"/"richmovie.series_logo")

    15-08-2025 21:52 CEST (Europe/Prague) – DOPLNĚNO: TMDb dotazy pro epizodu/seriál a nastavení artworku + pravého panelu.

    DŮLEŽITÉ: Žádná jiná logika (řazení, klikací URL) se nemění.
    """
    hist = _watch_load().get("episodes", [])
    if not hist:
        _modal("Historie seriálů je prázdná.")
        return

    xbmcplugin.setPluginCategory(HANDLE, "Historie sledování – Seriály")
    xbmcplugin.setContent(HANDLE, "episodes")

    # HORNÍ POMOCNÁ POLOŽKA – „Vymazat historii…“
    try:
        li_clear = xbmcgui.ListItem("[COLOR red]🗑 Vymazat historii…[/COLOR]")
    except Exception:
        li_clear = xbmcgui.ListItem("Vymazat historii…")
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="watch_history"), li_clear, isFolder=False)

    # TMDb klient (pokud máme klíč)
    tmdb_key = (ADDON.getSetting("tmdb_api_key") or "").strip()
    tmdb = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    def _pick_logo(logos: list[dict]) -> str | None:
        """Vybere nejvhodnější logo (cs→sk→en→bez jazyka). Vrátí absolutní URL nebo None."""
        if not logos:
            return None
        prefer = ("cs", "sk", "en", None, "xx")
        # Seřadíme podle jazyka a šířky (větší bývá kvalitnější)
        def _rank(rec: dict) -> tuple[int, int]:
            lang = rec.get("iso_639_1")
            try:
                idx = prefer.index(lang)
            except ValueError:
                idx = len(prefer)
            w = int(rec.get("width") or 0)
            return (idx, -w)
        best = sorted(logos, key=_rank)[0]
        path = best.get("file_path") or ""
        return f"https://image.tmdb.org/t/p/w500{path}" if path else None

    # VÝPIS POLOŽEK
    for it in hist:
        tv_id   = it.get("tv_id")
        tv_name = (it.get("tv_name") or "").strip()

        try:
            season  = int(it.get("season") or 0)
        except Exception:
            season = 0
        try:
            episode = int(it.get("episode") or 0)
        except Exception:
            episode = 0

        ep_title = (it.get("ep_title") or "").strip()

        label = f"{tv_name} S{season:02d}E{episode:02d}"
        if ep_title:
            label += f" – {ep_title}"

        li = xbmcgui.ListItem(label)

        # ZÁKLADNÍ INFO TAGY (doplníme „plot“ po TMDb dotazu níže)
        info_tags = {
            "title":       ep_title or label,
            "tvshowtitle": tv_name,
            "season":      season,
            "episode":     episode,
            "mediatype":   "episode",
        }

        art: dict[str, str] = {"icon": "DefaultTVShows.png"}
        series_plot = ""
        series_title = tv_name
        series_logo = None

        if tmdb and tv_id:
            try:
                tv_id_int = int(str(tv_id))
            except Exception:
                tv_id_int = None

            if tv_id_int:
                # 1) EPIZODA – popis + still
                try:
                    ep = tmdb.episode_details(tv_id_int, season, episode)
                    if not ep_title and (ep.get("name") or "").strip():
                        info_tags["title"] = ep.get("name").strip()
                    if (ep.get("overview") or "").strip():
                        info_tags["plot"] = ep["overview"].strip()
                    still = ep.get("still_path") or ""
                    if still:
                        art["thumb"]     = f"https://image.tmdb.org/t/p/w300{still}"
                        art["landscape"] = f"https://image.tmdb.org/t/p/w780{still}"
                except TMDbError:
                    pass

                # 2) SERIÁL – poster, fanart, logo + pravý panel
                try:
                    show = tmdb.tv_details(tv_id_int)
                    series_title = (show.get("name") or tv_name or "").strip() or series_title
                    series_plot  = (show.get("overview") or "").strip()
                    p = show.get("poster_path") or ""
                    b = show.get("backdrop_path") or ""
                    if p:
                        art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
                        art["tvshow.poster"] = f"https://image.tmdb.org/t/p/w342{p}"
                    if b:
                        art["fanart"] = f"https://image.tmdb.org/t/p/original{b}"
                    # logo (pomocí /tv/{id}/images)
                    try:
                        imgs = tmdb._get_json(f"/tv/{tv_id_int}/images", {"api_key": tmdb.api_key})
                        logo_url = _pick_logo(imgs.get("logos", []))
                        if logo_url:
                            series_logo = logo_url
                            art["clearlogo"] = logo_url
                            art["tvshow.clearlogo"] = logo_url
                    except TMDbError:
                        pass
                except TMDbError:
                    pass

        # PRAVÝ PANEL – vlastní properties (skin si je může načíst)
        if series_title:
            li.setProperty("richmovie.series_title", series_title)
        if series_plot:
            li.setProperty("richmovie.series_plot", series_plot)
        if series_logo:
            li.setProperty("richmovie.series_logo", series_logo)

        # Zapsat artwork + infotagy
        if art:
            li.setArt(art)
        li.setInfo("video", info_tags)

        # Klik → standardní výpis releasů pro danou epizodu
        url = _url(
            action   = "tv_play",
            tv_id    = tv_id,
            tv_name  = tv_name,
            season   = str(season),
            episode  = str(episode),
            ep_title = ep_title,
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)





# 2025-08-14 18:55 CEST (Europe/Prague) – _watch_load(): bezpečné načtení historie sledování
def _watch_load() -> dict:
    """
    Načte obsah `watch_history.json` z uživatelského profilu doplňku.

    Vždy vrací slovník se dvěma klíči:
      {
        "movies":   [ { "tmdb": int|None, "title": str, "year": int|None, "ts": int }, ... ],
        "episodes": [ { "tv_id": Any, "tv_name": str, "season": int, "episode": int,
                        "ep_title": str, "ts": int }, ... ]
      }

    Při chybě (soubor neexistuje / je poškozen) vrací prázdné struktury.
    """
    try:
        # pokud soubor neexistuje, vrátíme default
        if not xbmcvfs.exists(str(_WATCH_PATH)):
            return {"movies": [], "episodes": []}

        # xbmcvfs pro kompatibilitu napříč platformami
        with xbmcvfs.File(str(_WATCH_PATH), "r") as fh:
            raw = fh.read()
        if not raw:
            return {"movies": [], "episodes": []}

        data = json.loads(raw)
        return {
            "movies":   list(data.get("movies", [])),
            "episodes": list(data.get("episodes", [])),
        }
    except Exception:
        # nikdy nesmí shodit GUI
        return {"movies": [], "episodes": []}









# 2025-08-14 18:55 CEST (Europe/Prague) – _watch_save(): atomické uložení historie sledování
def _watch_save(data: dict) -> None:
    """
    Uloží celý obsah historie sledování do `watch_history.json` atomicky.
    Při chybě potichu selže (historie nikdy nesmí shodit doplněk).
    """
    try:
        # zajisti existenci profilu
        try:
            xbmcvfs.mkdirs(str(PROFILE_DIR))
        except Exception:
            pass

        tmp_path = str(_WATCH_PATH) + ".tmp"

        # zápis přes xbmcvfs kvůli kompatibilitě s Kodi
        with xbmcvfs.File(tmp_path, "w") as fh:
            payload = json.dumps(data, ensure_ascii=False, indent=2)
            fh.write(bytearray(payload, "utf-8"))

        # atomická výměna
        try:
            xbmcvfs.delete(str(_WATCH_PATH))
        except Exception:
            pass
        xbmcvfs.rename(tmp_path, str(_WATCH_PATH))
    except Exception:
        # žádné výjimky navenek
        pass





# 2025-08-14 19:07 CEST (Europe/Prague) – _watch_add_movie(): přidání/aktualizace filmového záznamu v historii
def _watch_add_movie(*, tmdb_id: Optional[int], title: str, year: Optional[int]) -> None:
    """
    Přidá nebo aktualizuje film v historii sledování (větev "movies").

    • Deduplikace:
        – primárně podle TMDb ID (pokud je k dispozici a je platné číslo),
        – jinak podle dvojice (title, year) s ořezanými mezerami.
    • Nový/aktualizovaný záznam se vkládá na začátek seznamu ("nejnovější nahoře").
    • Zachováváme maximálně `_WATCH_MAX_ITEMS` položek.
    • Metoda je "best effort": při chybě potichu skončí (historie nesmí shodit doplněk).
    """
    try:
        # normalize vstupu
        t = (title or "").strip()
        y = int(year) if (year or 0) else None

        # TMDb ID bereme jen pokud je validní číslo
        tmdb = None
        if tmdb_id is not None:
            try:
                tmdb = int(tmdb_id)
            except Exception:
                tmdb = None

        rec = {
            "tmdb": tmdb,
            "title": t,
            "year": y,
            "ts": int(time.time()),
        }

        data = _watch_load()
        items = list(data.get("movies", []))

        def _key(it: dict) -> tuple:
            return (
                it.get("tmdb") if (it.get("tmdb") is not None) else None,
                (it.get("title") or "").strip(),
                it.get("year") if (it.get("year") or 0) else None,
            )

        # odstranit případnou starou instanci stejného filmu
        items = [it for it in items if _key(it) != _key(rec)]

        # vložit na začátek
        items.insert(0, rec)

        # ořez na maximální velikost
        if _WATCH_MAX_ITEMS > 0:
            items = items[:_WATCH_MAX_ITEMS]

        data["movies"] = items
        _watch_save(data)
    except Exception:
        # nepropagovat výjimky – historie je pomocná funkce
        pass





# 2025-08-14 20:10 CEST (Europe/Prague) – _watch_history_clear(): bezpečné vymazání „Historie sledování“ (movies/episodes)
def _watch_history_clear() -> None:
    """
    Vymaže obsah `watch_history.json` a založí prázdnou strukturu:
      {"movies": [], "episodes": []}

    • Používá xbmcvfs kvůli kompatibilitě napříč platformami.
    • Nikdy nevyhazuje výjimku směrem do GUI (fail‑safe).
    • Po úspěchu zobrazí krátké potvrzení.
    """
    try:
        # zajisti existenci profilu (pro případ, že neexistuje)
        try:
            xbmcvfs.mkdirs(str(PROFILE_DIR))
        except Exception:
            pass

        # prázdná struktura
        empty = {"movies": [], "episodes": []}

        # zkus smazat starý soubor (ignore errors)
        try:
            if xbmcvfs.exists(str(_WATCH_PATH)):
                xbmcvfs.delete(str(_WATCH_PATH))
        except Exception:
            pass

        # ihned zapiš čistý JSON (atomicky přes tmp → rename)
        tmp_path = str(_WATCH_PATH) + ".tmp"
        with xbmcvfs.File(tmp_path, "w") as fh:
            payload = json.dumps(empty, ensure_ascii=False, indent=2)
            fh.write(bytearray(payload, "utf-8"))
        try:
            xbmcvfs.delete(str(_WATCH_PATH))
        except Exception:
            pass
        xbmcvfs.rename(tmp_path, str(_WATCH_PATH))

        try:
            _modal("Historie sledování byla vymazána.")
        except NameError:
            xbmcgui.Dialog().ok("RichMovie", "Historie sledování byla vymazána.")
    except Exception:
        # potichu selhat – historie nikdy nesmí shodit doplněk
        pass





# 2025-08-14 19:07 CEST (Europe/Prague) – _watch_add_episode(): přidání/aktualizace epizody v historii
def _watch_add_episode(*, tv_id: Any, tv_name: str, season: int, episode: int, ep_title: str) -> None:
    """
    Přidá nebo aktualizuje epizodu seriálu v historii (větev "episodes").

    • Deduplikace podle klíče (tv_id, season, episode).
      – tv_id převádíme na string při porovnání, protože může být int/str.
    • Nový/aktualizovaný záznam se vkládá na začátek ("nejnovější nahoře").
    • Zachováváme maximálně `_WATCH_MAX_ITEMS` položek.
    • Metoda je "best effort": při chybě potichu skončí.
    """
    try:
        tvn = (tv_name or "").strip()
        s   = int(season) if season is not None else 0
        e   = int(episode) if episode is not None else 0
        ept = (ep_title or "").strip()

        rec = {
            "tv_id": tv_id,          # ukládáme jak je; pro klíč převádíme na str
            "tv_name": tvn,
            "season": s,
            "episode": e,
            "ep_title": ept,
            "ts": int(time.time()),
        }

        data = _watch_load()
        items = list(data.get("episodes", []))

        def _key(it: dict) -> tuple:
            return (str(it.get("tv_id")), int(it.get("season") or 0), int(it.get("episode") or 0))

        # odstranit případnou starou instanci stejné epizody
        items = [it for it in items if _key(it) != (str(tv_id), s, e)]

        # vložit na začátek
        items.insert(0, rec)

        # ořez na maximální velikost
        if _WATCH_MAX_ITEMS > 0:
            items = items[:_WATCH_MAX_ITEMS]

        data["episodes"] = items
        _watch_save(data)
    except Exception:
        pass



















# --------------------------------------------------------------------------- #
#  WEBSHARE OBÁLKY  (kvůli kompatibilitě se starým kódem)
# --------------------------------------------------------------------------- #
def _client() -> WebshareClient:
    return _SESSION.client












# 2025-08-16 23:44 CEST (Europe/Prague)
def _ensure_login(
    cli: WebshareClient,
    interactive: bool = False,
) -> None:
    """
    Zajistí platné přihlášení k Webshare.cz, aktualizuje VIP stav v GUI
    a zobrazí *informační* toast o VIP stavu **maximálně 1× denně**.

    Výjimka: pokud do konce VIP zbývá **méně než 24 hodin** (tj. `vip_days < 1`),
    toast se zobrazuje při každém vstupu (stejně jako dříve) a denní zarážka se NEaktivuje.

    Implementační poznámky:
    - Nepoužíváme `datetime.datetime.strptime()` (odpadá riziko kolize a pádu).
      Pro „1× denně“ ukládáme jen `vip_last_toast_date` ve formátu `YYYY-MM-DD`.
    - Pro debug navíc ukládáme i `vip_last_toast_iso` (ISO timestamp), ale NIKDE jej neparsujeme.
    - UI titulek a nastavení `vip_info` spravuje SessionManager.update_vip_status().

    Vedlejší efekty (nastavení doplňku):
      vip_last_toast_date : 'YYYY-MM-DD' – den, kdy byl toast naposledy zobrazen
      vip_last_toast_iso  : 'YYYY-MM-DDTHH:MM:SS+TZ' – pouze pro ladění
    """
    # 1) Login workflow (původní logika přes SessionManager)
    try:
        _SESSION.ensure_login(interactive=interactive)
    except APIError as e:
        _modal(str(e))
        raise

    # 2) Aktualizuj VIP stav v GUI (titulek, vip_info)
    if HANDLE >= 0:
        _SESSION.update_vip_status()

    # 3) Přečti text pro informační toast (pokud není, není co zobrazovat)
    vip_text = ADDON.getSetting("vip_info").strip()
    if not vip_text:
        return

    # 4) Zjisti kolik zbývá dní VIP (bez pádu – když API selže, toast aspoň jednou denně)
    days_left: int | None = None
    try:
        info = _SESSION.client.account_info()
        days_left = int(info.get("vip_days", 0) or 0)
        _log_event("VIP_STATUS", days_left)
    except Exception as exc:
        # Nechceme kvůli informativnímu toastu shodit plugin
        _log_event("VIP_INFO_FETCH_FAIL", str(exc))

    # 5) Výjimka: <24 h do konce VIP → zobrazuj vždy (bez denní zarážky)
    if days_left is not None and days_left < 1:
        _modal(vip_text, block=False)
        _log_event("VIP_TOAST", "ALWAYS_<24h")
        return

    # 6) Denní zarážka (1× denně) – ukládáme pouze datum v místním čase
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    last_date = (ADDON.getSetting("vip_last_toast_date") or "").strip()

    if last_date == today:
        _log_event("VIP_TOAST_SKIP", today)
        return

    # 7) Zobraz a zapiš dnešní datum (ISO navíc jen pro ladění — už neparsujeme)
    _modal(vip_text, block=False)
    ADDON.setSetting("vip_last_toast_date", today)
    try:
        ADDON.setSetting(
            "vip_last_toast_iso",
            datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        )
    except Exception:
        pass
    _log_event("VIP_TOAST_SHOWN", today)





def _update_vip_status(_unused_cli: WebshareClient) -> None:
    _SESSION.update_vip_status()



def _build_stream_li(
    rel: Release,
    movie: dict | None = None,
) -> Tuple[str, xbmcgui.ListItem, bool]:
    """
    [Aktualizováno: 2025-08-21 23:19 CEST (Europe/Prague)]
    Převede objekt `Release` na Kodi ListItem – zachovává původní vzhled a chování.
    Navíc přidává do kontextového menu položku „Stáhnout stream“.

    • Pokud je k dispozici `movie` (TMDb), vložíme do play URL kontext (m_title, m_year, tmdb),
      aby se po přehrání zapsala Historie sledování.
    • Kontextové menu:
        - „Detail streamu“ → RunPlugin(?action=detail&ident=…)
        - „Stáhnout stream“ → RunPlugin(?action=download&ident=…&name=<název>&m_title&…)
    """
    info_txt = LabelFormatter.format(rel, movie=movie)

    # — URL pro přehrání — pokud známe kontext filmu, pošleme ho dál
    if movie:
        qs = {"action": "play", "ident": rel.ident}
        if movie.get("title"):
            qs["m_title"] = movie["title"]
        if movie.get("year"):
            qs["m_year"] = str(movie["year"])
        if movie.get("id"):
            qs["tmdb"] = str(movie["id"])
        url = _url(**qs)
    else:
        url = _url(action="play", ident=rel.ident)

    li = xbmcgui.ListItem(info_txt["label_left"])

    # art (zachován původní způsob)
    art = {}
    if movie:
        poster_path   = movie.get("poster_path") or ""
        backdrop_path = movie.get("backdrop_path") or ""
        if poster_path:
            art["poster"] = f"https://image.tmdb.org/t/p/w342{poster_path}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{poster_path}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
    li.setArt(art)

    # info‑tags (zachováno)
    info_tags: dict[str, object] = {
        "title": (movie or {}).get("title", rel.name),
        "mediatype": "movie",
    }
    if movie and movie.get("year"):
        info_tags["year"] = int(movie["year"])
    li.setInfo("video", info_tags)

    # je to přehratelné
    li.setProperty("isPlayable", "true")
    if getattr(rel, "mediainfo", None):
        li.setProperty("richmovie.mediainfo", json.dumps(rel.mediainfo))

    # Kontextové menu (🆕 Stáhnout stream s kontextem filmu)
    safe_name = quote_plus((movie or {}).get("title", rel.name) or "")

    # Sestavíme query pro ?action=download včetně filmového kontextu, pokud ho máme
    dl_qs = {"action": "download", "ident": rel.ident, "name": safe_name}
    if movie:
        if movie.get("title"):
            dl_qs["m_title"] = movie["title"]
        if movie.get("year"):
            dl_qs["m_year"] = str(movie["year"])
        if movie.get("id"):
            dl_qs["tmdb"] = str(movie["id"])

    li.addContextMenuItems([
        ("Detail streamu",  f"RunPlugin({_url(action='detail', ident=rel.ident)})"),
        ("Stáhnout stream", f"RunPlugin({_url(**dl_qs)})"),
    ])

    return url, li, False




def _download_stream() -> None:
    """
    [Aktualizováno: 2025-08-21 23:19 CEST (Europe/Prague)]
    Spouštěč stahování z kontextového menu (`?action=download`).

    • Bezpečně načte parametry z URL: ident (povinné), name (volitelné),
      a dále filmový/seriálový kontext (m_title, m_year, tmdb, tv_name, season, episode, ep_title) pokud je k dispozici.
    • Lazy‑importuje `start_download_from_gui` z `richmovie_downloads` a předá vše dál jako kwargs.
    • Případné chyby zobrazí jako modální dialog a **nikdy neshodí** plugin.
    """
    try:
        # 1) parametry
        args: Dict[str, List[str]] = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        ident = (args.get("ident") or [""])[0].strip()
        raw_name = (args.get("name") or [""])[0]

        try:
            name = urllib.parse.unquote_plus(raw_name)
        except Exception:
            name = raw_name

        if not ident:
            _modal("Chybí ident streamu.")
            if HANDLE >= 0:
                try:
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                except Exception:
                    pass
            return

        # 2) kontext pro hlavičku dialogu
        meta: Dict[str, Any] = {}
        # film
        m_title = (args.get("m_title") or [""])[0].strip()
        m_year  = (args.get("m_year")  or [""])[0].strip()
        tmdb_id = (args.get("tmdb")    or [""])[0].strip()
        if m_title:
            meta["m_title"] = m_title
        if m_year:
            meta["m_year"] = m_year
        if tmdb_id:
            meta["tmdb"] = tmdb_id
        # seriál (pokud by se v budoucnu posílal)
        tv_name  = (args.get("tv_name")  or [""])[0].strip()
        season_s = (args.get("season")   or [""])[0].strip()
        episode_s= (args.get("episode")  or [""])[0].strip()
        ep_title = (args.get("ep_title") or [""])[0].strip()
        if tv_name:
            meta["tv_name"] = tv_name
        if ep_title:
            meta["ep_title"] = ep_title
        try:
            if season_s:
                meta["season"] = int(season_s)
            if episode_s:
                meta["episode"] = int(episode_s)
        except Exception:
            pass  # když nepůjdou převést na int, prostě je nepošleme

        # 3) lazy import + spuštění downloaderu
        try:
            from richmovie_downloads import start_download_from_gui  # import uvnitř kvůli závislostem
        except Exception as imp_err:
            _modal(f"Stahování selhalo (import): {imp_err}")
            return

        try:
            start_download_from_gui(ident, name, **meta)
        except Exception as run_err:
            _modal(f"Stahování selhalo: {run_err}")

    except Exception:
        xbmc.log("[RichMovie] _download_stream(): unexpected error", xbmc.LOGERROR)





# 2025-08-19 15:26 CEST (Europe/Prague)
def _download_action() -> None:
    """
    Handler pro `action=download`.

    • Bezpečně načte parametry z URL (`ident`, `name`)
    • Lazy‑importuje `start_download_from_gui` z modulu `richmovie_downloads`
      → žádný kruhový import při startu GUI.
    • Předá (ident, name) – očekávaná signatura.
    • Chyby zobrazí jako modální dialog.
    """
    try:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        ident = (args.get("ident", [""])[0] or "").strip()
        name  = (args.get("name",  [""])[0] or "").strip()
        if not ident:
            _modal("Chybí ident streamu.");  return
        try:
            # Lazy import – vyhneme se ImportError: partially initialized module
            from richmovie_downloads import start_download_from_gui  # type: ignore
        except Exception as imp_err:
            _modal(f"Stahování selhalo: {imp_err}")
            return

        try:
            start_download_from_gui(ident, name)
        except Exception as run_err:
            _modal(f"Stahování selhalo: {run_err}")
    except Exception:
        # nikdy nesmí shodit celý plugin
        xbmc.log("[RichMovie] _download_action(): unexpected error", xbmc.LOGERROR)





def _stream_detail(ident: str) -> None:
    """
    Otevře dialog s detailními technickými informacemi o souboru (MediaInfo).
    Využívá cache SearchEngine → žádné další síťové volání.
    """
    mi = _ENGINE.get_mediainfo(ident)
    text = _format_mediainfo(mi or {})
    xbmcgui.Dialog().textviewer("Detail streamu", text)





def _auto_cleanup_logs() -> None:
    """
    Projde rotační i „per‑search“ logy a smaže ty, které jsou starší
    než počet dní nastavený v Settings → „Uchovávat logy (dní)“.
    Nastavená hodnota 0 = funkce vypnuta.
    """
    try:
        days = int(ADDON.getSetting("logs_retention_days") or "0")
    except ValueError:
        days = 0
    if days <= 0:
        return

    cutoff = datetime.datetime.now() - datetime.timedelta(days=days)
    # 1) globální rotační log + .backup
    for p in (_LOG_PATH, _LOG_PATH + ".1"):
        if os.path.exists(p) and datetime.datetime.fromtimestamp(
            os.path.getmtime(p)
        ) < cutoff:
            try:
                os.remove(p)
            except Exception:
                pass

    # 2) per‑search logy
    log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
    if os.path.isdir(log_dir):
        for fname in os.listdir(log_dir):
            fp = os.path.join(log_dir, fname)
            try:
                if datetime.datetime.fromtimestamp(
                    os.path.getmtime(fp)
                ) < cutoff:
                    os.remove(fp)
            except Exception:
                pass
        # prázdný adresář smažeme
        try:
            if not os.listdir(log_dir):
                os.rmdir(log_dir)
        except Exception:
            pass





def _clear_logs() -> None:
    """
    Vymaže *veškeré* logy doplňku (globální i per‑search) a zobrazí notifikaci.
    """
    try:
        for p in (_LOG_PATH, _LOG_PATH + ".1"):
            if os.path.exists(p):
                os.remove(p)

        log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
        if os.path.isdir(log_dir):
            shutil.rmtree(log_dir, ignore_errors=True)

        _notif("Log soubory byly vymazány.")
        _log_event("LOGS_CLEARED")
    except Exception as e:
        _notif(f"Chyba při mazání logů: {e}", xbmcgui.NOTIFICATION_ERROR)






# 2025-08-19 08:13 CEST (Europe/Prague) – _install_collections_blocking(): Kodi 21.x kompatibilní DialogProgress.update(2 parametry)
def _install_collections_blocking() -> None:
    """
    Modální „instalátor kolekcí“ spuštěný při vstupu do doplňku.

    • Projde všechny JSON kolekce (CollectionsUI._iter_collections) a sestaví plán práce:
        – movie  → TMDb.search(title, year?)
        – tv     → TMDb.search_tv(name)
        – tv+episodes → + TMDb.episode_details(tv_id, s, e) pro každou epizodu
      (Tím se **zahřeje TMDb JSON cache**, takže první otevření kolekcí je rychlé.)

    • Zobrazuje **DialogProgress** s titulkem „Instaluji kolekce filmů a seriálů“,
      průběžně aktualizuje **%** a **zbývající čas (ETA)**.
    • **Cancel** uloží checkpoint a příští start naváže (resume).
    • ŽÁDNÉ dvojí ukládání obrázků – jen TMDb JSON (artwork necháváme Kodi).
    """
    # ────────────── Ochrana: bez TMDb klíče instalátor nedává smysl ─────────
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        return
    tmdb = TMDb(tmdb_key, lang="cs-CZ")

    # ────────────── Cesty a stav (resume) ───────────────────────────────────
    state_path = Path(PROFILE_DIR) / "collections_install.json"

    def _state_load() -> dict:
        try:
            if xbmcvfs.exists(str(state_path)):
                with xbmcvfs.File(str(state_path), "r") as fh:
                    raw = fh.read()
                return json.loads(raw) if raw else {}
        except Exception:
            pass
        return {}

    def _state_save(st: dict) -> None:
        try:
            xbmcvfs.mkdirs(str(PROFILE_DIR))
        except Exception:
            pass
        tmp = str(state_path) + ".tmp"
        payload = json.dumps(st, ensure_ascii=False, indent=2)
        with xbmcvfs.File(tmp, "w") as fh:
            fh.write(bytearray(payload, "utf-8"))
        try:
            xbmcvfs.delete(str(state_path))
        except Exception:
            pass
        xbmcvfs.rename(tmp, str(state_path))

    st = _state_load()
    done_keys: set[str] = set(st.get("completed", []))
    tv_id_cache: dict[str, int] = dict(st.get("tv_id_cache", {}))

    # ────────────── Sestavení plánu práce (tasks) ───────────────────────────
    # Task je dict s klíči: kind ∈ {"movie","tv","episode"} a dalšími poli…
    tasks: list[dict] = []

    for vfs_path, meta in CollectionsUI._iter_collections(ADDON):
        # meta: {"id":..,"title":..,"items":[{type:"movie"/"tv", ...}]}
        items = (meta or {}).get("items") or []
        for it in items:
            typ  = (it.get("type") or "").strip().lower()
            name = (it.get("title") or it.get("name") or "").strip()
            if not typ or not name:
                continue

            if typ == "movie":
                year = it.get("year")
                key  = f"movie|{name}|{int(year) if str(year).isdigit() else ''}"
                if key not in done_keys:
                    tasks.append({"kind": "movie", "title": name, "year": year, "key": key})

            elif typ == "tv":
                # vždy aspoň dohledat tv_id (search_tv)
                key_tv = f"tv|{name}"
                if key_tv not in done_keys:
                    tasks.append({"kind": "tv", "name": name, "key": key_tv})

                # volitelné vybrané epizody
                for ep in (it.get("episodes") or []):
                    try:
                        s = int(ep.get("season") or ep.get("s") or 0)
                        e = int(ep.get("episode") or ep.get("e") or 0)
                    except Exception:
                        s = e = 0
                    if s > 0 and e > 0:
                        key_ep = f"ep|{name}|{s}|{e}"
                        if key_ep not in done_keys:
                            tasks.append({"kind": "episode", "name": name, "season": s, "episode": e, "key": key_ep})

    # Počet úloh k doinstalování
    total = len(tasks)
    if total <= 0:
        return  # vše hotovo

    # ────────────── Modální progress s ETA ──────────────────────────────────
    dlg = xbmcgui.DialogProgress()
    dlg.create("Instaluji kolekce filmů a seriálů")

    start_ts = time.time()
    processed = 0
    last_flush = 0

    def _fmt_eta(seconds: float) -> str:
        if seconds < 0:
            seconds = 0
        m, s = divmod(int(seconds + 0.5), 60)
        h, m = divmod(m, 60)
        return f"{h:d}:{m:02d}:{s:02d}"

    def _update_progress(title_line: str) -> None:
        nonlocal processed
        pct = int(processed * 100 / total) if total else 100
        elapsed = max(0.0, time.time() - start_ts)
        avg = (elapsed / processed) if processed else 0.0
        remain = max(0.0, (total - processed) * avg)
        dlg.update(
            pct,
            f"{title_line}\n{processed}/{total} • {pct} %\nZbývá ~{_fmt_eta(remain)}",
        )

    # ────────────── Vykonej úlohy (sekvenčně; cache udělá z hitů „instant“) ─
    for t in tasks:
        if dlg.iscanceled():
            break

        kind = t["kind"]
        try:
            if kind == "movie":
                title = t["title"]; year = t.get("year")
                _update_progress(f"Stahuji: {title}{f' ({year})' if year else ''} • film")
                # cache-warm: search (limit=10 jako v CollectionsUI._find_movie_tmdb)
                tmdb.search(title, year=year, limit=10)

            elif kind == "tv":
                name = t["name"]
                _update_progress(f"Stahuji: {name} • seriál")
                # cache-warm: search_tv
                results = tmdb.search_tv(name, limit=10)
                # ulož tv_id pro epizody (vezmeme 1. výsledek)
                if isinstance(results, list) and results:
                    rid = int(results[0].get("id") or 0)
                    if rid:
                        tv_id_cache[name] = rid

            elif kind == "episode":
                name = t["name"]; s = int(t["season"]); e = int(t["episode"])
                _update_progress(f"Stahuji: {name} S{s:02d}E{e:02d} • epizoda")
                tv_id = tv_id_cache.get(name)
                if not tv_id:
                    # pro jistotu dohledat (resume/1st run)
                    results = tmdb.search_tv(name, limit=10)
                    tv_id = int(results[0].get("id") or 0) if results else 0
                    if tv_id:
                        tv_id_cache[name] = tv_id
                if tv_id:
                    tmdb.episode_details(tv_id, s, e)
                else:
                    xbmc.log(f"[RichMovie/CollectionsInstall] Nepodařilo se najít TV ID pro '{name}'.", xbmc.LOGWARNING)
                    # neoznačíme jako hotové, ať to příště zkusíme znovu
                    continue
            else:
                continue

            # Úloha hotová → zapiš do completed
            processed += 1
            done_keys.add(t["key"])

            # průběžný zápis stavu (každých ~10 položek, aby resume bylo co nejpřesnější)
            if processed - last_flush >= 10:
                last_flush = processed
                _state_save({"completed": sorted(done_keys), "tv_id_cache": tv_id_cache})

            _update_progress("Instaluji kolekce filmů a seriálů")

        except TMDbError as e:
            xbmc.log(f"[RichMovie/CollectionsInstall] TMDb chyba: {e}", xbmc.LOGWARNING)
            # neoznačujeme jako dokončené → příště zkusíme znovu
        except Exception as e:
            xbmc.log(f"[RichMovie/CollectionsInstall] Neočekávaná chyba: {e}", xbmc.LOGERROR)

    # finální zápis + zavřít progress
    _state_save({"completed": sorted(done_keys), "tv_id_cache": tv_id_cache})
    try:
        dlg.close()
    except Exception:
        pass







def _reset_settings() -> None:
    """
    Smaže celou složku addon_data → doplněk se po restartu chová jako nový.
    """
    ok = xbmcgui.Dialog().yesno(
        "Reset RichMovie",
        "Tato akce vymaže veškeré nastavení doplňku, včetně",
        "přihlašovacích údajů a lokální cache.",
        "Chcete opravdu pokračovat?",
        yeslabel="Ano, smazat", nolabel="Ne",
    )
    if not ok:
        return

    ad_path = Path(
        xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.richmovie"
        )
    ).resolve()
    try:
        if ad_path.exists():
            shutil.rmtree(ad_path)
        _log_event("RESET_SETTINGS_OK", str(ad_path))
        _notif("Nastavení vymazáno – restartuji doplněk")
    except Exception as exc:
        _log_event("RESET_SETTINGS_ERR", str(exc))
        _notif(f"Chyba při mazání: {exc}", xbmcgui.NOTIFICATION_ERROR)
        return
    sys.exit()      # ukončí doplněk, Kodi ho po zavření menu načte znovu




def _url(**qs) -> str:
    """
    Postaví URL volání vlastního pluginu.

    Příklad:
        _url(action="play", ident="ABC123")  →
        plugin://plugin.video.richmovie/?action=play&ident=ABC123
    """
    return f"plugin://{ADDON.getAddonInfo('id')}/?{urlencode(qs)}"





# 2025-08-19 10:40 CEST (Europe/Prague) – _install_collections_blocking(): paralelizace + seskupení epizod po sezónách; Kodi-safe progress; žádné `year` v TMDb.search()
def _install_collections_blocking() -> None:
    """
    Modální „instalátor kolekcí“ spuštěný při vstupu do doplňku.

    Zrychlení:
      • paralelní zpracování úloh (rozumně omezený ThreadPoolExecutor),
      • epizody se **seskupují po sezónách** a warm-up se dělá přes `TMDb.season_details(tv_id, season)`,
        takže 1 požadavek zahřeje metadata pro všechny epizody dané sezóny.
      • zachováno checkpointování, `tv_id_cache`, kompatibilita klíčů a Kodi-safe progress (2 parametry).

    Důležité:
      • artworky nestahujeme – necháváme Kodi (Texture cache), my zahříváme **TMDb JSON**.
      • do `TMDb.search()` **NEPOSÍLÁME** `year` (signatura je `(query, limit)`), rok je jen součástí klíče.
      • aliasy v kolekcích: type|kind, title|name, year|release_year; epizody season|s|season_number, episode|e|episode_number.
      • „completed“ klíče čteme ve formátu `::` i `|` (interně sjednocujeme na `|`).
    """
    # ───────────────── Ochrana: bez TMDb klíče nedává smysl pokračovat ─────────────────
    try:
        tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    except Exception:
        tmdb_key = ""
    if not tmdb_key:
        xbmc.log("[RichMovie/CollectionsInstall] TMDb key missing – skip", xbmc.LOGWARNING)
        return
    tmdb = TMDb(tmdb_key, lang="cs-CZ")

    # ───────────────── Stav (resume) ─────────────────
    state_path = Path(PROFILE_DIR) / "collections_install.json"

    def _state_load() -> dict:
        try:
            if xbmcvfs.exists(str(state_path)):
                f = xbmcvfs.File(str(state_path), "r")
                try:
                    raw = f.read()
                finally:
                    f.close()
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8", errors="ignore")
                data = json.loads(raw or "{}")
                data.setdefault("completed", [])
                data.setdefault("tv_id_cache", {})
                return data
        except Exception as e:
            xbmc.log(f"[RichMovie/CollectionsInstall] state load failed: {e}", xbmc.LOGWARNING)
        return {"completed": [], "tv_id_cache": {}}

    def _state_save(state: dict) -> None:
        try:
            xbmcvfs.mkdirs(str(PROFILE_DIR))
        except Exception:
            pass
        tmp = str(state_path) + ".tmp"
        payload = json.dumps(state, ensure_ascii=False, indent=2)
        f = xbmcvfs.File(tmp, "w")
        try:
            f.write(bytearray(payload, "utf-8"))
        finally:
            f.close()
        try:
            if xbmcvfs.exists(str(state_path)):
                xbmcvfs.delete(str(state_path))
        except Exception:
            pass
        xbmcvfs.rename(tmp, str(state_path))

    st = _state_load()

    def _canon_key(k: str) -> str:
        # sjednoť „movie::X::Y“ → „movie|X|Y“
        return (k or "").replace("::", "|")

    done_keys: set[str] = {_canon_key(x) for x in (st.get("completed") or [])}
    tv_id_cache: dict[str, int] = dict(st.get("tv_id_cache") or {})

    # ───────────────── Sestavení plánu práce ─────────────────
    # RAW úlohy (ještě neoptimalizované): movie/tv/episode
    raw_movies: list[dict]  = []
    raw_tvs: list[dict]     = []
    raw_eps: list[dict]     = []

    for vfs_json, meta in CollectionsUI._iter_collections(ADDON):
        items = (meta or {}).get("items") or []
        for it in items:
            typ = (it.get("type") or it.get("kind") or "movie").strip().lower()

            if typ == "movie":
                title = (it.get("title") or it.get("name") or "").strip()
                year  = it.get("year") or it.get("release_year") or None
                if not title:
                    continue
                key = f"movie|{title}|{int(year) if str(year).isdigit() else ''}"
                if key not in done_keys:
                    raw_movies.append({"kind": "movie", "title": title, "year": year, "key": key})

            elif typ == "tv":
                name = (it.get("title") or it.get("name") or "").strip()
                if not name:
                    continue
                key_tv = f"tv|{name}"
                if key_tv not in done_keys:
                    raw_tvs.append({"kind": "tv", "name": name, "key": key_tv})

                # vybrané epizody (volitelné – zahřejeme přes season_details)
                for ep in (it.get("episodes") or []):
                    s_raw = ep.get("season") or ep.get("s") or ep.get("season_number")
                    e_raw = ep.get("episode") or ep.get("e") or ep.get("episode_number")
                    try:
                        s = int(s_raw); e = int(e_raw)
                    except Exception:
                        continue
                    if s > 0 and e > 0:
                        key_ep = f"ep|{name}|{s}|{e}"
                        if key_ep not in done_keys:
                            raw_eps.append({"kind": "episode", "name": name, "season": s, "episode": e, "key": key_ep})

    # Jednotky práce pro %: 1 film = 1, 1 seriál = 1, 1 epizoda = 1
    total_units = len(raw_movies) + len(raw_tvs) + len(raw_eps)
    if total_units <= 0:
        xbmc.log("[RichMovie/CollectionsInstall] nothing to do", xbmc.LOGINFO)
        return

    # ───────────────── Optimalizace: epizody → sezóny ─────────────────
    # Seskup epizody (stejný seriál + sezóna) → 1 úloha „season“
    season_groups: dict[tuple[str, int], dict] = {}
    for t in raw_eps:
        k = (t["name"], int(t["season"]))
        g = season_groups.setdefault(k, {"kind": "season", "name": t["name"], "season": int(t["season"]), "ep_nums": set(), "ep_keys": []})
        g["ep_nums"].add(int(t["episode"]))
        g["ep_keys"].append(t["key"])
    season_tasks = list(season_groups.values())

    # Konečný seznam paralelizovatelných úloh
    # (TV ponecháme jako samostatné – často pomůže vyřešit tv_id před sezónami)
    work: list[dict] = []
    work.extend(raw_movies)
    work.extend(raw_tvs)
    work.extend(season_tasks)

    # ───────────────── Progress dialog (Kodi-safe) ─────────────────
    dlg = xbmcgui.DialogProgress()
    dlg.create("Instaluji kolekce filmů a seriálů", "Připravuji…")

    start_ts = time.time()
    processed_units = 0
    last_flush_units = 0

    def _fmt_eta(seconds: float) -> str:
        seconds = max(0, int(seconds + 0.5))
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        return f"{h:d}:{m:02d}:{s:02d}"

    def _update_progress(line: str) -> None:
        nonlocal processed_units
        pct = int(processed_units * 100 / total_units) if total_units else 0
        eta = 0.0
        if processed_units:
            avg = (time.time() - start_ts) / processed_units
            eta = max(0.0, (total_units - processed_units) * avg)
        dlg.update(pct, f"{line}\n{processed_units}/{total_units} • {pct} %\nZbývá ~{_fmt_eta(eta)}")

    xbmc.log(f"[RichMovie/CollectionsInstall] starting; movies={len(raw_movies)} tvs={len(raw_tvs)} seasons={len(season_tasks)} units={total_units}", xbmc.LOGINFO)

    # ───────────────── Worker (běží ve vlákně) ─────────────────
    def _do_task(t: dict) -> tuple[list[str], dict[str, int], str, int]:
        """
        Vrací (completed_keys, tv_id_cache_delta, human_title, units_done)
        • units_done = kolik „jednotek“ práce máme po dokončení přičíst (film=1, tv=1, sezóna = počet epizod v ní).
        """
        try:
            if t["kind"] == "movie":
                title = t["title"]; year = t.get("year")
                # warm-up: vyhledání (rok do signatury NEPATŘÍ)
                tmdb.search(title, limit=10)
                return [t["key"]], {}, f"Film: {title}" + (f" ({year})" if year else ""), 1

            if t["kind"] == "tv":
                name = t["name"]
                # warm-up: search_tv, plus si zkusíme ponechat tv_id (vrátíme delta)
                res = tmdb.search_tv(name, limit=10)
                tv_id = int(res[0].get("id") or 0) if isinstance(res, list) and res else 0
                delta = {name: tv_id} if tv_id else {}
                return [t["key"]], delta, f"Seriál: {name}", 1

            if t["kind"] == "season":
                name = t["name"]; s = int(t["season"])
                # zjisti tv_id (z cache nebo dohledat)
                tv_id = tv_id_cache.get(name, 0)
                if not tv_id:
                    res = tmdb.search_tv(name, limit=10)
                    tv_id = int(res[0].get("id") or 0) if res else 0
                if tv_id:
                    # jedním dotazem zahřej všechny epizody sezóny
                    tmdb.season_details(int(tv_id), s)
                    units = len(t["ep_nums"]) if isinstance(t.get("ep_nums"), set) else 1
                    return list(t["ep_keys"]), ({name: tv_id} if name not in tv_id_cache else {}), f"{name} • S{s:02d}", units
                else:
                    # TV ID se nepodařilo – nic neznačíme jako hotové
                    return [], {}, f"{name} • S{s:02d} (TV ID nenalezeno)", 0
        except TMDbError as e:
            return [], {}, f"TMDb chyba: {e}", 0
        except Exception as e:
            return [], {}, f"Neočekávaná chyba: {e}", 0
        return [], {}, "Neznámá úloha", 0

    # ───────────────── Paralelní spuštění ─────────────────
    # Praktická volba: 8–12 workerů saturoje RL=20 req/s bez přetížení sítě/disku.
    MAX_WORKERS = max(8, min(12, (os.cpu_count() or 8)))
    save_every_units = 25  # checkpoint po cca 25 dokončených jednotkách

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        # Spustíme všechny úlohy; výsledky budeme číst postupně
        futures = [ex.submit(_do_task, t) for t in work]

        try:
            for fut in futures:
                if dlg.iscanceled():
                    xbmc.log("[RichMovie/CollectionsInstall] canceled by user – attempting to cancel pending futures", xbmc.LOGINFO)
                    try:
                        ex.shutdown(wait=False, cancel_futures=True)
                    except Exception:
                        pass
                    break

                completed_keys, delta_ids, nice_line, units = fut.result()
                if nice_line:
                    _update_progress(nice_line)

                # Merge TV ID cache (jen v hlavním vlákně)
                if delta_ids:
                    tv_id_cache.update({k: v for k, v in delta_ids.items() if v})

                # Přičti odvedenou práci a zapiš „completed“ klíče
                if units > 0:
                    processed_units += units
                for k in completed_keys:
                    if k:
                        done_keys.add(_canon_key(k))

                # průběžný checkpoint
                if processed_units - last_flush_units >= save_every_units:
                    last_flush_units = processed_units
                    _state_save({"completed": sorted(done_keys), "tv_id_cache": tv_id_cache})

                # jemné poskočení progressu i bez textu
                _update_progress("Instaluji kolekce filmů a seriálů")

        except Exception as e:
            xbmc.log(f"[RichMovie/CollectionsInstall] Runner error: {e}", xbmc.LOGERROR)

    # ───────────────── Finále ─────────────────
    _state_save({"completed": sorted(done_keys), "tv_id_cache": tv_id_cache})
    xbmc.log(f"[RichMovie/CollectionsInstall] finished; processed={processed_units}/{total_units} units", xbmc.LOGINFO)
    try:
        dlg.update(100, "Instalace kolekcí dokončena.\nHotovo.")
        time.sleep(0.3)
        dlg.close()
    except Exception:
        pass






# 2025-08-21 22:37 CEST (Europe/Prague) – _root(): FIX akcí (ai_recommend→ai_menu, webshare_search→ws_search)
def _root() -> None:
    """
    Kořenové menu doplňku – pořadí a logika beze změn.
    Položky:
        1)  Hledat film
        2)  Hledat seriál
        3)  Doporučit od RichMovie A.I.
        4)  Historie sledování
        5)  Historie hledání
        6)  Kolekce
        7)  Seriály - Trendy dnes
        8)  Seriály - TOP hodnocené
        9)  Filmy - Trendy dnes
        10) Filmy - TOP hodnocené
        11) Žánry
        12) Vyhledat na Sosáči
        13) Přímé hledání ve Webshare
    """

    # — blokující instalátor kolekcí (s % a ETA) —
    try:
        _install_collections_blocking()
    except Exception as _e:
        xbmc.log(f"[RichMovie/CollectionsInstall] Start-error: {_e}", xbmc.LOGWARNING)

    # — po doběhu instalátoru zaloguj footprint cache (text/backdrops/loga) —
    try:
        tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
        if tmdb_key:
            TMDb(tmdb_key, lang="cs-CZ").log_cache_footprint()
    except Exception as _e:
        xbmc.log(f"[RichMovie] CACHE_USAGE_WARN: {str(_e)}", xbmc.LOGWARNING)

    # — původní housekeeping —
    _ensure_internet_async()
    _auto_cleanup_logs()  # nahrazuje staré _ndjson_trace_init()

    # — login k Webshare + VIP status v GUI —
    cli = _client()
    try:
        _ensure_login(cli, interactive=True)
    except APIError as e:
        _modal(str(e))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    _update_vip_status(cli)
    _notify_mediainfo_once()

    # — cesty k ikonám —
    try:
        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
    except Exception:
        addon_path = ADDON.getAddonInfo("path")

    icons_dir = os.path.join(addon_path, "resources", "media", "icons")
    icon_movie   = os.path.join(icons_dir, "hledat_film.png")
    icon_tv      = os.path.join(icons_dir, "hledat_serial.png")
    icon_ai      = os.path.join(icons_dir, "doporucit_richmovie_ai.png")
    icon_watch   = os.path.join(icons_dir, "historie_sledovani.png")
    icon_search  = os.path.join(icons_dir, "historie_hledani.png")
    icon_collect = os.path.join(icons_dir, "collections.png")

    # 1) Hledat film
    li = xbmcgui.ListItem("Hledat film")
    li.setArt({"icon": icon_movie, "thumb": icon_movie})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="movie_search"), li, True)

    # 2) Hledat seriál
    li = xbmcgui.ListItem("Hledat seriál")
    li.setArt({"icon": icon_tv, "thumb": icon_tv})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tv_search"), li, True)

    # 3) Doporučit od RichMovie A.I.  — **FIX: ai_menu**
    li = xbmcgui.ListItem("Doporučit od RichMovie A.I.")
    li.setArt({"icon": icon_ai, "thumb": icon_ai})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="ai_menu"), li, True)

    # 4) Historie sledování
    li = xbmcgui.ListItem("Historie sledování")
    li.setArt({"icon": icon_watch, "thumb": icon_watch})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="watch_history"), li, True)

    # 5) Historie hledání
    li = xbmcgui.ListItem("Historie hledání")
    li.setArt({"icon": icon_search, "thumb": icon_search})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="history"), li, True)

    # 6) Kolekce
    li = xbmcgui.ListItem("Kolekce")
    li.setArt({"icon": icon_collect, "thumb": icon_collect})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="collections"), li, True)

    # 7) Seriály - Trendy dnes
    li = xbmcgui.ListItem("Seriály - Trendy dnes")
    li.setArt({"icon": icon_tv, "thumb": icon_tv})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_tv_trending"), li, True)

    # 8) Seriály - TOP hodnocené
    li = xbmcgui.ListItem("Seriály - TOP hodnocené")
    li.setArt({"icon": icon_tv, "thumb": icon_tv})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_tv_top"), li, True)

    # 9) Filmy - Trendy dnes
    li = xbmcgui.ListItem("Filmy - Trendy dnes")
    li.setArt({"icon": icon_movie, "thumb": icon_movie})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_trending"), li, True)

    # 10) Filmy - TOP hodnocené
    li = xbmcgui.ListItem("Filmy - TOP hodnocené")
    li.setArt({"icon": icon_movie, "thumb": icon_movie})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_top"), li, True)

    # 11) Žánry
    li = xbmcgui.ListItem("Žánry")
    li.setArt({"icon": icon_movie, "thumb": icon_movie})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_genres"), li, True)

    # 12) Vyhledat na Sosáči
    li = xbmcgui.ListItem("Vyhledat na Sosáči")
    li.setArt({"icon": icon_search, "thumb": icon_search})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="sosac_search"), li, True)

    # 13) Přímé hledání ve Webshare  — **FIX: ws_search**
    li = xbmcgui.ListItem("Přímé hledání ve Webshare")
    li.setArt({"icon": icon_search, "thumb": icon_search})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="ws_search"), li, True)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)





# plugin.py — METODA (NÁHRADA)
# 2025-08-14 12:20 CEST (Europe/Prague)
def _ai_log(event: str, message: str = "", *, details: dict | None = None, level: str = "ERROR") -> None:
    """
    Zapisuje AI diagnostiku do dedikovaného souboru a zrcadlí první řádky
    i do kodi.log pro snadný debug.

    Formát souboru RichMovie_a.i.log:
        YYYY-MM-DD HH:MM:SS<TAB>LEVEL<TAB>EVENT<TAB>MESSAGE<TAB>{json(details)}

    Bezpečnost a výkon:
      • Rotace logu ~1 MiB (RichMovie_a.i.log → RichMovie_a.i.log.1).
      • Zápis je "fire-and-forget" – jakákoli výjimka se tiše polkne.
      • Zrcadlení do kodi.log je lehké (jen krátká věta), neukládá se `details`.

    NOVĚ:
      • Bezpečný fallback cesty, i když ještě neběží inicializační blok s `_AI_LOG_PATH`.
    """
    try:
        # ---- sestavení řádku -------------------------------------------------
        ts = datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")
        row = "\t".join([ts, str(level), str(event), str(message or "")])
        if details:
            try:
                row += "\t" + json.dumps(details, ensure_ascii=False, separators=(",", ":"))
            except Exception:
                pass

        # ---- bezpečné určení cesty (fallback) --------------------------------
        try:
            ai_log_path = _AI_LOG_PATH  # typická cesta (z inicializace modulu)
        except Exception:
            ai_log_path = None
        if not ai_log_path:
            try:
                addon_id = ADDON.getAddonInfo("id")
            except Exception:
                addon_id = "plugin.video.richmovie"
            base = xbmcvfs.translatePath(f"special://profile/addon_data/{addon_id}")
            try:
                os.makedirs(base, exist_ok=True)
            except Exception:
                pass
            ai_log_path = os.path.join(base, "RichMovie_a.i.log")

        # ---- rotace ~1 MiB ---------------------------------------------------
        try:
            if os.path.exists(ai_log_path) and os.path.getsize(ai_log_path) > (1 * 1024 * 1024):
                bak = ai_log_path + ".1"
                try:
                    if os.path.exists(bak):
                        os.remove(bak)
                except Exception:
                    pass
                try:
                    os.replace(ai_log_path, bak)
                except Exception:
                    pass
        except Exception:
            pass

        # ---- zápis (thread‑safe) --------------------------------------------
        try:
            with _LOG_LOCK:
                with open(ai_log_path, "a", encoding="utf-8") as fh:
                    fh.write(row + "\n")
        except Exception:
            pass

        # ---- zrcadlení do kodi.log (vybrané eventy + WARNING/ERROR) ----------
        level_u = (level or "ERROR").upper()
        MIRROR_EVENTS = {
            "OPENAI_REQ", "OPENAI_RESP", "OPENAI_REQ_ERR", "OPENAI_RESP_REPOST",
            "OPENAI_VALIDATE_REQ", "OPENAI_VALIDATE_RESP", "OPENAI_VALIDATE_ERR",
            "OPENAI_PARSE_OK", "OPENAI_PARSE_ERROR",
            "OPENAI_HTTP_ERROR_FINAL", "OPENAI_RETRY",
            "OPENAI_ID_REQ", "OPENAI_ID_RESP", "OPENAI_ID_REQ_ERR", "OPENAI_ID_RESP_REPOST",
            "OPENAI_ID_PARSE_OK", "OPENAI_ID_PARSE_ERROR", "OPENAI_ID_HTTP_ERROR_FINAL",
            "AI_COST_TOAST",
        }
        should_mirror = (level_u in ("ERROR", "WARNING")) or (str(event) in MIRROR_EVENTS)
        if should_mirror:
            try:
                lvl_map = {
                    "DEBUG": xbmc.LOGDEBUG,
                    "INFO": xbmc.LOGINFO,
                    "WARNING": xbmc.LOGWARNING,
                    "ERROR": xbmc.LOGERROR,
                }
                xbmc.log(f"[RichMovie A.I.] {event}" + (f" – {message}" if message else ""), lvl_map.get(level_u, xbmc.LOGINFO))
            except Exception:
                pass

    except Exception:
        # logování nesmí nikdy shodit doplněk
        pass





# 2025-08-11 22:40 CEST (Europe/Prague)
def _ai_usage_consume(api_key: str, usage: dict, model: str = "gpt-5-mini") -> None:
    """
    Eviduje denní spotřebu tokenů a náklady per uživatelský **OpenAI API klíč** (hash),
    ukládá do JSON a nenápadně informuje uživatele toastem v Kč.

    KLÍČOVÁ PRAVIDLA:
      • ZDROJ PRAVDY: usage z odpovědi OpenAI (prompt/input, completion/output, cached_input).
      • Přepočet tokenů → USD → CZK (kurz z nastavení `openai_fx_usdczk` nebo default 24.50).
      • Zobrazená částka je záměrně 2× reálná (interně 50 Kč → ukážeme 100 Kč).
      • Anti‑spam: maximálně 1× denně; výjimka – pokaždé, když kumulovaná „zobrazená“ částka
        přeskočí další stovku (100, 200, 300, …).
      • BEZPEČNÝ NO‑OP: pokud `usage` neobsahuje žádné tokeny, nic neukládáme a nic nezobrazujeme.

    Struktura souboru: special://profile/addon_data/plugin.video.richmovie/ai_usage.json
      {
        "keys": {
          "<hash8>": {
            "daily": {
              "YYYY-MM-DD": {
                "tokens": {"input": int, "output": int, "cached_input": int},
                "usd_input": float, "usd_cached_input": float, "usd_output": float, "usd_total": float
              }
            },
            "last_toast_iso": "YYYY-MM-DD",
            "last_threshold_czk_shown": 100,
            "last_toast_czk_shown": 120
          }
        }
      }
    """
    try:
        # ---- pomocné funkce (bez nových importů) -----------------------------
        def _hash_key(key: str) -> str:
            return hashlib.sha256((key or "").encode("utf-8")).hexdigest()[:8]

        def _read_store(path: str) -> dict:
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    return json.load(fh)
            except Exception:
                return {}

        def _write_store(path: str, data: dict) -> None:
            try:
                with open(path, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, ensure_ascii=False, indent=2)
            except Exception:
                pass

        def _fmt_int(n: int) -> str:
            return f"{int(n):,}".replace(",", " ")

        # ---- vstupy -----------------------------------------------------------
        key_hash = _hash_key(api_key.strip())
        in_tok   = int(usage.get("prompt_tokens") or usage.get("input_tokens") or 0)
        out_tok  = int(usage.get("completion_tokens") or usage.get("output_tokens") or 0)
        cached   = int(usage.get("cached_input_tokens") or 0)
        if cached > in_tok:
            cached = in_tok  # sanity

        # BEZPEČNÝ NO‑OP: když OpenAI neposlalo usage, nekonáme vůbec nic
        if (in_tok + out_tok + cached) <= 0:
            return

        # ---- ceny – USD / token (za 1M) --------------------------------------
        PRICES = {
            "gpt-5-mini": {
                "in":     0.25  / 1_000_000.0,
                "out":    2.00  / 1_000_000.0,
                "cached": 0.025 / 1_000_000.0,
            },
        }
        p = PRICES.get(model, PRICES["gpt-5-mini"])

        usd_input  = max(0.0, (in_tok - cached)) * p["in"] + (cached * p["cached"])
        usd_output = max(0.0, out_tok) * p["out"]
        usd_total  = usd_input + usd_output

        # ---- zápis do JSON (agregace per den a per klíč) ---------------------
        path  = str(PROFILE_DIR / "ai_usage.json")
        store = _read_store(path)
        keys  = store.setdefault("keys", {})
        node  = keys.setdefault(key_hash, {
            "daily": {},
            "last_toast_iso": "",
            "last_threshold_czk_shown": 0,
            "last_toast_czk_shown": 0
        })

        # dnešní datum (lokální)
        today = datetime.datetime.now().astimezone().strftime("%Y-%m-%d")
        day   = node["daily"].setdefault(today, {
            "tokens": {"input": 0, "output": 0, "cached_input": 0},
            "usd_input": 0.0, "usd_output": 0.0, "usd_cached_input": 0.0, "usd_total": 0.0,
        })

        # kumulace tokenů a USD
        day["tokens"]["input"]         = int(day["tokens"]["input"])        + in_tok
        day["tokens"]["output"]        = int(day["tokens"]["output"])       + out_tok
        day["tokens"]["cached_input"]  = int(day["tokens"]["cached_input"]) + cached
        day["usd_input"]               = float(day["usd_input"])        + (max(0.0, (in_tok - cached)) * p["in"])
        day["usd_cached_input"]        = float(day["usd_cached_input"]) + (cached * p["cached"])
        day["usd_output"]              = float(day["usd_output"])       + (max(0.0, out_tok) * p["out"])
        day["usd_total"]               = float(day["usd_input"] + day["usd_cached_input"] + day["usd_output"])

        _write_store(path, store)

        # ---- rozhodnutí o toastu (1× denně, výjimka: každá nová "stovka") ----
        try:
            fx_raw = (ADDON.getSetting("openai_fx_usdczk") or "").strip()
            fx = float(fx_raw.replace(",", ".")) if fx_raw else 24.50
        except Exception:
            fx = 24.50
        if fx <= 0:
            fx = 24.50

        czk_real = day["usd_total"] * fx
        czk_show = int(round(czk_real * 2.0))  # co zobrazíme (násobeno ×2)

        should_toast   = False
        next_threshold = (czk_show // 100) * 100

        if node.get("last_toast_iso") != today:
            # první A.I. akce v daný den → zobrazit
            should_toast = True
        elif next_threshold > int(node.get("last_threshold_czk_shown") or 0):
            # přeskočili jsme další "stovku" (100, 200, 300, …) → zobrazit znovu
            should_toast = True

        if not should_toast:
            return

        # ---- toast (lehké zpoždění, aby nerušil UI) --------------------------
        xbmc.sleep(2500)
        msg = (
            f"A.I. kredit dnes: {czk_show} Kč · model {model} · "
            f"tokeny dnes: in {_fmt_int(day['tokens']['input'])} / out {_fmt_int(day['tokens']['output'])}"
        )
        try:
            xbmcgui.Dialog().notification("RichMovie · A.I.", msg, xbmcgui.NOTIFICATION_INFO, 4000)
        except Exception:
            pass

        # Aktualizace anti‑spam stavů a zápis
        node["last_toast_iso"] = today
        node["last_threshold_czk_shown"] = next_threshold
        node["last_toast_czk_shown"] = czk_show
        _write_store(path, store)

        # Log info o toastu (zároveň se díky _ai_log zrcadlí do kodi.log)
        try:
            _ai_log(
                "AI_COST_TOAST",
                f"czk_show={czk_show}",
                details={
                    "key": key_hash,
                    "model": model,
                    "usd_total_today": day["usd_total"],
                    "fx": fx,
                    "tokens": day["tokens"],
                },
                level="INFO",
            )
        except Exception:
            pass

    except Exception:
        # Nikdy nesmí shodit doplněk
        pass






# 2025-08-10 23:20 CEST (Europe/Prague)
def _ai_prompt_key_with_validation(*, heading: str = "OpenAI API klíč") -> bool:
    """
    Interaktivně vyžádá OpenAI klíč – dvě cesty:
      1) Zadat ručně (skryté psaní),
      2) Vybrat soubor s API klíčem (prohlížeč Kodi).
    Po získání klíče proběhne online validace (GET /v1/models/gpt-5-mini).
    • Úspěch → uloží se klíč + stav a zobrazí info „OK“ (nenutící).
    • Zrušení → tiše vrací False.
    • Neplatný → nabídne opakovat (Yes/No).
    Vše loguje do RichMovie_a.i.log.
    """
    attempts = 0
    while True:
        mode = xbmcgui.Dialog().select(
            heading,
            ["Zadat ručně", "Vybrat soubor s API klíčem", "Zrušit"]
        )
        if mode < 0 or mode == 2:
            return False  # zrušeno

        if mode == 0:
            # ruční zadání
            val = _keyboard_input("Zadej OpenAI API klíč", hidden=True)
            if not val:
                return False
            key = val.strip()
        else:
            # import ze souboru
            key = _ai_browse_and_import_key()
            if not key:
                # uživatel zrušil nebo nenalezeno → zeptáme se, zda to zkusit znovu
                if not xbmcgui.Dialog().yesno("Import klíče", "Klíč se nepodařilo získat.\nZkusit to znovu?"):
                    return False
                attempts += 1
                continue

        ok, msg = validate_openai_key(key, model="gpt-5-mini", timeout=15)
        if ok:
            ADDON.setSetting("openai_api_key", key)
            try:
                ADDON.setSetting(
                    "openai_key_status",
                    datetime.datetime.now().astimezone().strftime("OK – ověřeno %Y-%m-%d %H:%M")
                )
            except Exception:
                pass
            _ai_log("OPENAI_KEY_OK", "Klíč ověřen a uložen.", details={"attempts": attempts, "model": "gpt-5-mini"}, level="INFO")
            _modal("OpenAI klíč je v pořádku.", heading="RichMovie A.I.", block=False)
            return True

        # neplatný / nedostupný klíč → nabídnout opakovat
        _ai_log("OPENAI_KEY_INVALID", msg, details={"attempt": attempts + 1}, level="ERROR")
        if not xbmcgui.Dialog().yesno("OpenAI klíč neplatný", f"{msg}\n\nZkusit zadat / importovat znovu?"):
            return False
        attempts += 1





# 2025-08-10 23:35 CEST (Europe/Prague)
def _ai_autoload_key_from_resources() -> bool:
    """
    Pokusí se automaticky načíst OpenAI klíč ze souboru:
        resources/richmovie_open_ai_APIkey.txt
    Postup:
      • načte soubor z instalační složky doplňku (READ ONLY),
      • vezme první NEprázdný a NEkomentovaný řádek (ignoruje #, //, ;),
      • pokud řádek obsahuje "=", vezme hodnotu za "=",
      • jinak vezme první whitespace-delimited token,
      • odstraní uvozovky, ověří online (GET /v1/models/gpt-5-mini),
      • při úspěchu uloží do settings a zapíše stav.
    Vrací:
      True  → klíč úspěšně načten a ověřen,
      False → soubor chybí / je nečitelný / klíč neplatný (pokračuj interaktivně).
    Nikdy nevyhazuje výjimku (vše se loguje do RichMovie_a.i.log).
    """
    try:
        addon_path = ADDON.getAddonInfo("path")
        base_path = xbmcvfs.translatePath(addon_path) if hasattr(xbmcvfs, "translatePath") else addon_path
        res_file = os.path.join(base_path, "resources", "richmovie_open_ai_APIkey.txt")

        if not xbmcvfs.exists(res_file):
            _ai_log("OPENAI_KEY_AUTOLOAD_MISSING", "Soubor neexistuje.", details={"path": res_file}, level="INFO")
            return False

        # Načtení souboru
        try:
            f = xbmcvfs.File(res_file, "r")
            try:
                raw = f.read()
            finally:
                f.close()
        except Exception as e:
            _ai_log("OPENAI_KEY_AUTOLOAD_READ_ERR", str(e), details={"path": res_file})
            return False

        # Dekódování
        if isinstance(raw, bytes):
            try:
                txt = raw.decode("utf-8-sig")
            except Exception:
                try:
                    txt = raw.decode("utf-8")
                except Exception:
                    txt = raw.decode("latin-1", errors="ignore")
        else:
            txt = raw

        # Parsování klíče
        key: str | None = None
        for line in txt.splitlines():
            s = (line or "").strip()
            if not s or s.startswith("#") or s.startswith("//") or s.startswith(";"):
                continue
            if "=" in s:
                s = s.split("=", 1)[1].strip().strip('"').strip("'")
            token = (s.split()[0] if s.split() else "").strip().strip('"').strip("'")
            if token:
                key = token
                break

        if not key:
            _ai_log("OPENAI_KEY_AUTOLOAD_EMPTY", "Soubor neobsahuje čitelný klíč.", details={"path": res_file})
            return False

        # Ověření klíče online
        ok, msg = validate_openai_key(key, model="gpt-5-mini", timeout=15)
        if not ok:
            _ai_log("OPENAI_KEY_AUTOLOAD_INVALID", msg, details={"path": res_file})
            return False

        # Uložení a status
        ADDON.setSetting("openai_api_key", key)
        try:
            ADDON.setSetting(
                "openai_key_status",
                datetime.datetime.now().astimezone().strftime("OK – ověřeno %Y-%m-%d %H:%M")
            )
        except Exception:
            pass

        _ai_log("OPENAI_KEY_AUTOLOAD_OK", "Klíč načten ze resources a ověřen.", details={"path": res_file}, level="INFO")
        _modal("OpenAI klíč byl automaticky načten ze složky resources.", heading="RichMovie A.I.", block=False)
        return True

    except Exception as e:
        _ai_log("OPENAI_KEY_AUTOLOAD_ERR", str(e))
        return False







# 2025-08-10 23:20 CEST (Europe/Prague)
def _ai_browse_and_import_key() -> str | None:
    """
    Otevře prohlížeč souborů Kodi a pokusí se z vybraného souboru načíst OpenAI klíč.
    Pravidla parsování:
      • vezme první NEprázdný a NEkomentovaný řádek (ignoruje # a //),
      • pokud řádek obsahuje "=", vezme hodnotu za "=",
      • jinak vezme první whitespace-delimited token,
      • odřízne uvozovky a bílá místa,
      • vrací samotný klíč (nebo None při zrušení/selhání).
    Všechny chyby loguje do RichMovie_a.i.log.
    """
    dlg = xbmcgui.Dialog()
    # type=1 → výběr souboru; maska povolí běžné textové přípony
    path = dlg.browse(
        1,  # files
        "Vyber soubor s OpenAI klíčem",
        "files",
        ".txt|.key|.json|.cfg|.ini|.env|.yaml|.yml",
        False, False, ""
    )
    if not path:
        return None  # uživatel zrušil

    try:
        f = xbmcvfs.File(path, 'r')
        try:
            raw = f.read()
        finally:
            f.close()
        # xbmcvfs vrací str nebo bytes podle platformy; sjednotíme:
        if isinstance(raw, bytes):
            try:
                txt = raw.decode("utf-8-sig")
            except Exception:
                try:
                    txt = raw.decode("utf-8")
                except Exception:
                    txt = raw.decode("latin-1", errors="ignore")
        else:
            txt = raw

        for line in txt.splitlines():
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("//"):
                continue
            if "=" in s:
                s = s.split("=", 1)[1].strip().strip('"').strip("'")
            token = (s.split()[0] if s.split() else "").strip().strip('"').strip("'")
            if token:
                return token

        _ai_log("OPENAI_KEY_IMPORT_EMPTY", "Soubor neobsahuje čitelný klíč.", details={"path": path})
        _modal("V souboru nebyl nalezen žádný klíč.", heading="RichMovie A.I.")
        return None

    except Exception as e:
        _ai_log("OPENAI_KEY_IMPORT_ERR", str(e), details={"path": path})
        _modal("Soubor se nepodařilo načíst. Zkus prosím jiný.", heading="RichMovie A.I.")
        return None




# 2025-08-10 23:35 CEST (Europe/Prague)
def _ai_require_openai_key() -> bool:
    """
    Ověří, že máme OpenAI klíč:
      1) Pokud je už uložen → True.
      2) Pokud chybí → nejprve se POKUSÍ automaticky načíst ze 'resources/richmovie_open_ai_APIkey.txt'.
      3) Pokud autoload selže → spustí interaktivního průvodce s validací
         (ruční zadání / import ze souboru). Zrušení = False.
    """
    key = ADDON.getSetting("openai_api_key").strip()
    if key:
        return True

    # 2) Autoload ze 'resources'
    if _ai_autoload_key_from_resources():
        return True

    # 3) Interaktivní průvodce (ručně / soubor)
    return _ai_prompt_key_with_validation(heading="OpenAI API klíč")








# 2025-08-11 18:40 CEST (Europe/Prague)
def _ai_menu() -> None:
    """
    Submenu RichMovie A.I. + zachycení textového dotazu.

    Nové:
      • Přidána volba „Najít podle popisu (přesné)“ – vede na _ai_identify_show().
      • Zachováno: původní tři volby (film/seriál/je mi to jedno) → _ai_recommend_show().

    Každý krok umožňuje Zrušit → návrat do hlavního menu.
    """
    if not _ai_require_openai_key():
        _root()
        return

    kb = xbmcgui.Dialog()
    opts = ["Najdi podle mého popisu", "Doporuč mi film", "Doporuč mi seriál", "Doporuč mi film, nebo seriál"]
    idx = kb.select("Doporučit od RichMovie A.I.", opts)
    if idx < 0:
        _root();  return

    # 0 = nový "přesný" režim (identifikace podle popisu)
    if idx == 0:
        text = _keyboard_input("Co si pamatuješ z děje? Popiš co nejpřesněji.")
        if not text:
            _root();  return
        _ai_identify_show(text)
        return

    # Původní tři volby → doporučení
    kind = ("movie", "tv", "any")[idx - 1]
    text = _keyboard_input("Co Tě zajímá? :-)")
    if not text:
        _root();  return

    _ai_recommend_show(kind, text)










# 2025-08-10 21:57 CEST (Europe/Prague)
def _ai_edit_key_action() -> None:
    """
    Spuštěno z Nastavení → 'Změnit/OpenAI klíč'.
    Uživatel může klíč upravit; po uložení klíče dojde k ověření a zapsání statusu.
    """
    if _ai_prompt_key_with_validation(heading="Zadej/změň OpenAI API klíč"):
        _modal("OpenAI klíč je v pořádku.", heading="RichMovie A.I.", block=False)
    # neúspěch/zrušení → bez hlášek




# 2025-08-14 13:16 CEST (Europe/Prague)
def _ai_recommend_show(kind: str, user_text: str) -> None:
    """
    Zobrazí doporučení od RichMovie A.I. pro zvolený typ obsahu.
    (Sims-like progress, A.I. běží v pozadí.)
    """
    AI_PREFIX       = "[RichMovie A.I.]: "
    AI_PREFIX_NOSPC = "[RichMovie A.I.]:"

    tmdb_key   = ADDON.getSetting("tmdb_api_key").strip()
    openai_key = ADDON.getSetting("openai_api_key").strip()

    if not tmdb_key:
        _modal("Chybí API klíč TMDb.", heading="RichMovie A.I.")
        _root()
        return
    if not openai_key:
        if not _ai_prompt_key_with_validation(heading="Zadej OpenAI API klíč"):
            _root()
            return
        openai_key = ADDON.getSetting("openai_api_key").strip()
        if not openai_key:
            _root()
            return

    try:
        # milník do logu i do A.I. logu
        _log_event("AI_QUERY", {"kind": kind, "text": user_text})
        _ai_log("AI_QUERY", "Start doporučení", details={"kind": kind, "text": user_text}, level="INFO")

        # — spustíme A.I. ve vlákně + ukážeme Sims-like progres ————————
        def _worker():
            # NEPŘEPISUJEME timeouty ani retryny – ponecháme robustní default
            return recommend_titles(
                openai_key,
                user_text,
                want=kind,
                limit=20,
                model="gpt-5-mini",
            )

        recs, prog = _run_ai_with_progress(kind, user_text, mode="recommend", worker=_worker)
        if recs is None:
            # chyba při A.I. – cleanup progress a předej na běžné hlášení
            if prog:
                try: prog.close()
                except Exception: pass
            raise OpenAIError("A.I. volání selhalo (viz log).")

        _log_event("AI_RESP", {"count": len(recs)})
        _ai_log("AI_RESP", "OpenAI doporučení hotovo", details={"count": len(recs)}, level="INFO")

        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        movies: list[dict] = []
        shows:  list[dict] = []

        def _shorten(txt: str, maxlen: int = 700) -> str:
            t = (txt or "").strip()
            return (t[: maxlen - 1] + "…") if len(t) > maxlen else t

        # závěrečná fáze – drobný posun procent při dohledání
        done = 0
        total = len(recs) or 1

        for it in recs:
            title  = (it.get("title") or "").strip()
            year   = it.get("year")
            reason = (it.get("reason") or it.get("why") or "").strip()
            if reason and not (reason.startswith(AI_PREFIX) or reason.startswith(AI_PREFIX_NOSPC)):
                reason = AI_PREFIX + reason
            if not title:
                continue

            try:
                if kind == "tv" or (kind == "any" and (it.get("kind") or "movie") == "tv"):
                    found = tmdb.search_tv(title, limit=5)
                else:
                    found = tmdb.search(title, limit=5)
                pick  = _tmdb_pick_by_year(found, year)
                if pick:
                    if reason:
                        pick["overview"] = _shorten(reason)
                    if kind == "tv" or (kind == "any" and (it.get("kind") or "movie") == "tv"):
                        shows.append(pick)
                    else:
                        movies.append(pick)
            except TMDbError as e:
                _ai_log("AI_TMDb_ERR", f"Search failed: {title}", details={"err": str(e)})

            # jemné „dotažení“ na ~98 %
            done += 1
            try:
                pct = min(98, 95 + int((done / total) * 3))
                prog.update(pct, "Finalizuji výsledky…")
            except Exception:
                pass

        # poslední 100 % + zavřít
        try:
            prog.update(100, "Hotovo.")
            prog.close()
        except Exception:
            pass

        if kind == "movie":
            _list_tmdb_movies(movies or [])
        elif kind == "tv":
            _list_tmdb_tv(shows or [])
        else:
            _list_tmdb_ai_mixed(movies, shows)

    except OpenAIError as e:
        msg = str(e)
        _ai_log("OPENAI_ERROR", msg, details={"kind": kind, "query": user_text})
        _modal(f"Chyba OpenAI: {msg}", heading="RichMovie A.I.")
        _root()
    except Exception as e:
        _ai_log("UNEXPECTED_ERROR", str(e), details={"kind": kind}, level="ERROR")
        _modal(f"Nastala neočekávaná chyba: {e}", heading="RichMovie A.I.")
        _root()







# 2025-08-14 13:16 CEST (Europe/Prague)
def _ai_identify_show(user_text: str) -> None:
    """
    Přesná identifikace filmů/seriálů podle popisu (RichMovie A.I.).
    (Sims-like progress, A.I. běží v pozadí.)
    """
    AI_PREFIX       = "[RichMovie A.I.]: "
    AI_PREFIX_NOSPC = "[RichMovie A.I.]:"

    tmdb_key   = ADDON.getSetting("tmdb_api_key").strip()
    openai_key = ADDON.getSetting("openai_api_key").strip()

    if not tmdb_key:
        _modal("Chybí API klíč TMDb.", heading="RichMovie A.I.")
        _root()
        return
    if not openai_key:
        if not _ai_prompt_key_with_validation(heading="Zadej OpenAI API klíč"):
            _root()
            return
        openai_key = ADDON.getSetting("openai_api_key").strip()
        if not openai_key:
            _root()
            return

    try:
        _log_event("AI_ID_QUERY", {"text": user_text})
        _ai_log("AI_ID_QUERY", "Start identifikace", details={"text": user_text}, level="INFO")

        def _worker():
            return identify_titles(
                openai_key,
                user_text,
                limit=5,
                model="gpt-5-mini",
            )

        recs, prog = _run_ai_with_progress("any", user_text, mode="identify", worker=_worker)
        if recs is None:
            if prog:
                try: prog.close()
                except Exception: pass
            raise OpenAIError("A.I. volání selhalo (viz log).")

        _log_event("AI_ID_RESP", {"count": len(recs)})
        _ai_log("AI_ID_RESP", "OpenAI identifikace hotovo", details={"count": len(recs)}, level="INFO")

        # Filtrování a řazení dle jistoty; missing_facts musí být prázdné
        def _is_strict_match(it: dict) -> bool:
            miss = it.get("missing_facts") or []
            try:
                conf = int(it.get("confidence") or 0)
            except Exception:
                conf = 0
            return (len(miss) == 0) and (conf >= 0)

        filtered = [it for it in recs if _is_strict_match(it)]
        filtered.sort(key=lambda d: int(d.get("confidence") or 0), reverse=True)
        filtered = filtered[:5]

        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        movies: list[dict] = []
        shows:  list[dict] = []

        def _shorten(txt: str, maxlen: int = 700) -> str:
            t = (txt or "").strip()
            return (t[: maxlen - 1] + "…") if len(t) > maxlen else t

        done = 0
        total = len(filtered) or 1

        for it in filtered:
            title  = (it.get("title") or "").strip()
            year   = it.get("year")
            reason = (it.get("reason") or "").strip()
            kind   = (it.get("kind") or "movie").strip().lower()
            if reason and not (reason.startswith(AI_PREFIX) or reason.startswith(AI_PREFIX_NOSPC)):
                reason = AI_PREFIX + reason
            if not title:
                continue

            try:
                found = tmdb.search_tv(title, limit=5) if kind == "tv" else tmdb.search(title, limit=5)
                pick  = _tmdb_pick_by_year(found, year)
                if pick:
                    if reason:
                        pick["overview"] = _shorten(reason)
                    (shows if kind == "tv" else movies).append(pick)
            except TMDbError as e:
                _ai_log("AI_TMDb_ERR", f"Search {kind} failed: {title}", details={"err": str(e)})

            done += 1
            try:
                pct = min(98, 95 + int((done / total) * 3))
                prog.update(pct, "Finalizuji výsledky…")
            except Exception:
                pass

        try:
            prog.update(100, "Hotovo.")
            prog.close()
        except Exception:
            pass

        # Render výpisu
        if movies and not shows:
            _list_tmdb_movies(movies)
        elif shows and not movies:
            _list_tmdb_tv(shows)
        else:
            _list_tmdb_ai_mixed(movies, shows)

        if not (movies or shows):
            _modal("Nenašel jsem žádný titul, který by přesně odpovídal Tvému popisu.", heading="RichMovie A.I.")
            _root()

    except OpenAIError as e:
        msg = str(e)
        _ai_log("OPENAI_ERROR", msg, details={"kind": "identify", "query": user_text})
        _modal(f"Chyba OpenAI: {msg}", heading="RichMovie A.I.")
        _root()
    except Exception as e:
        _ai_log("UNEXPECTED_ERROR", str(e), details={"kind": "identify"}, level="ERROR")
        _modal(f"Nastala neočekávaná chyba: {e}", heading="RichMovie A.I.")
        _root()





# 2025-08-11 16:02 CEST (Europe/Prague)
def _ai_verify_tmdb_match(kind: str, tmdb: TMDb, item: Dict[str, Any], constraints: Dict[str, Any], tmdb_key: str) -> tuple[bool, Dict[str, Any]]:
    """
    Tvrdá validace kandidáta proti TMDb – projde jen, pokud **všechno podstatné**
    z constraints sedí na datech TMDb.

    Kontroluji:
      • ROK (pokud je přesně zadaný) nebo DEKÁDU (přibližně).
      • OSOBY/HERCE: přesná shoda jména v obsazení (movie: /movie/{id}/credits,
                    tv: /tv/{id}/aggregate_credits).
      • MÍSTA / „PLOT POINTS“ / POSTAVY: substring v (overview + alt názvech + titulech + jménech postav).
      • JAZYKY: original_language / spoken_languages.
      • ZEMĚ: production_countries (film) / origin_country (TV).
      • ŽÁNRY: shoda názvů žánrů.
      • FORBIDDEN: žádný z negativních tokenů se nesmí v korpusu vyskytovat.

    Návrat: (True/False, {found: [...], missing: [...], year_ok: bool, detail: {...}})
    """
    # — malý normalizér (bez diakritiky, lower, alnum+space) —
    def _norm_txt(s: str) -> str:
        t = (s or "").strip().lower()
        if not t:
            return ""
        t = unicodedata.normalize("NFKD", t)
        t = "".join(ch for ch in t if not unicodedata.combining(ch))
        # necháme písmena/čísla/mezery
        out = []
        for ch in t:
            if ch.isalnum() or ch.isspace():
                out.append(ch)
            else:
                out.append(" ")
        return " ".join("".join(out).split())

    # — bezpečné tahání polí —
    def _get(d: Dict[str, Any], key: str, default=None):
        v = d.get(key, default)
        return v if v is not None else default

    # — rozbal constraints —
    actors      = [str(x).strip() for x in (constraints.get("actors") or []) if str(x).strip()]
    people      = [str(x).strip() for x in (constraints.get("people") or []) if str(x).strip()]
    characters  = [str(x).strip() for x in (constraints.get("characters") or []) if str(x).strip()]
    places      = [str(x).strip() for x in (constraints.get("places") or []) if str(x).strip()]
    countries   = [str(x).strip() for x in (constraints.get("countries") or []) if str(x).strip()]
    languages   = [str(x).strip() for x in (constraints.get("languages") or []) if str(x).strip()]
    genres_req  = [str(x).strip() for x in (constraints.get("genres") or []) if str(x).strip()]
    plot_points = [str(x).strip() for x in (constraints.get("plot_points") or []) if str(x).strip()]
    forbid      = [str(x).strip() for x in (constraints.get("forbidden") or []) if str(x).strip()]
    year_exact  = int(constraints.get("year_exact") or 0)
    decade_hint = (constraints.get("decade_hint") or "").strip().lower()

    # 1) — stáhni detail + alt tituly + obsazení (i postavy) —
    detail: Dict[str, Any] = {}
    alts: List[str] = []
    cast_names: List[str] = []
    char_names: List[str] = []

    try:
        if kind == "movie":
            detail = tmdb.details(int(item["id"]))
            # alt titles (filmy mají wrapper)
            try:
                alts = [rec["title"] for rec in tmdb.alternative_titles(int(item["id"]), max_items=None)]
            except TMDbError:
                alts = []
            # obsazení + jména postav
            try:
                credits = tmdb._get_json(f"/movie/{int(item['id'])}/credits", {"api_key": tmdb.api_key})
            except TMDbError:
                credits = {}
            cast_names = [c.get("name","") for c in (credits.get("cast") or []) if c.get("name")]
            # postavy bývají v 'character'
            char_names = [c.get("character","") for c in (credits.get("cast") or []) if c.get("character")]
        else:
            # tv detail
            detail = tmdb._get_json(f"/tv/{int(item['id'])}", {"api_key": tmdb.api_key, "language": tmdb.lang})
            # alt titles (TV nemají wrapper → přes _get_json)
            try:
                res = tmdb._get_json(f"/tv/{int(item['id'])}/alternative_titles", {"api_key": tmdb.api_key})
                alts = [r.get("title","") for r in (res.get("results") or []) if r.get("title")]
            except TMDbError:
                alts = []
            # aggregate_credits → jména + role (postavy)
            try:
                agg = tmdb._get_json(f"/tv/{int(item['id'])}/aggregate_credits", {"api_key": tmdb.api_key})
            except TMDbError:
                agg = {}
            cast_names = [c.get("name","") for c in (agg.get("cast") or []) if c.get("name")]
            # roles: [{"character": "..."}] – vezmeme všechny
            for c in (agg.get("cast") or []):
                for r in (c.get("roles") or []):
                    nm = (r.get("character") or "").strip()
                    if nm:
                        char_names.append(nm)
    except TMDbError as e:
        return False, {"err": f"TMDb detail error: {e}"}

    # 2) — korpus textů pro substring match —
    titles = [item.get("title") or item.get("name") or "", detail.get("original_title",""), detail.get("title",""), detail.get("name",""), *alts]
    genres = [g.get("name","") for g in (detail.get("genres") or []) if g.get("name")]
    overview = (detail.get("overview") or "").strip()

    corpus_fields = [
        " ".join(titles),
        overview,
        " ".join(genres),
        " ".join(cast_names),
        " ".join(char_names),
    ]
    corpus_norm = _norm_txt(" • ".join(corpus_fields))

    # 3) — kontrola roku/dekády —
    year_ok = True
    detail_year = 0
    if kind == "movie":
        detail_year = int(detail.get("year") or int((detail.get("release_date") or "0000")[:4] or 0))
    else:
        detail_year = int((detail.get("first_air_date") or "0000")[:4] or 0)

    if year_exact:
        year_ok = (detail_year == year_exact)
    elif decade_hint:
        # jednoduchá heuristika: "late 90s" → 1995–1999; "90s" → 1990–1999
        dec = None
        m = re.search(r"(?:19|20)?([0-9]{2})0s|([0-9]{2})s", decade_hint)
        if m and (m.group(1) or m.group(2)):
            try:
                base = int(m.group(1) or m.group(2)) * 10
                base = 1900 + base if base < 100 else base
                lo, hi = base, base + 9
                if "late" in decade_hint:
                    lo = base + 5
                elif "early" in decade_hint:
                    hi = base + 4
                year_ok = (lo <= detail_year <= hi)
            except Exception:
                year_ok = True  # když nevíme, nepokazíme to
        else:
            year_ok = True

    # 4) — sestav tokeny k ověření —
    def _all_present(names: List[str], pool: List[str]) -> bool:
        want = {_norm_txt(x) for x in names if _norm_txt(x)}
        have = {_norm_txt(x) for x in pool if _norm_txt(x)}
        return want.issubset(have)

    missing: List[str] = []
    found:   List[str] = []

    # herci/osoby → tvrdá shoda v obsazení
    if actors:
        if not _all_present(actors, cast_names):
            missing += [f"actor:{x}" for x in actors if _norm_txt(x) not in {_norm_txt(n) for n in cast_names}]
        else:
            found += [f"actor:{x}" for x in actors]
    if people:
        # persons mohou obsahovat herce/režiséry – beru jako měkké OR k actors (ale ověřím proti cast jménům)
        if people and not _all_present(people, cast_names):
            # nechci duplicitně reportovat věci, co už byly v actors
            for x in people:
                nx = _norm_txt(x)
                if nx and nx not in {_norm_txt(n) for n in cast_names} and nx not in {_norm_txt(a) for a in actors}:
                    missing.append(f"person:{x}")
        else:
            for x in people:
                found.append(f"person:{x}")

    # postavy/místa/plot‑points → substring v korpusu
    def _substr_all(tokens: List[str]) -> tuple[bool, List[str]]:
        miss = []
        for t in tokens:
            nt = _norm_txt(t)
            if nt and nt not in corpus_norm:
                # jako fallback zkusím i bez mezer (někdy TMDb uvádí bez diakritiky/oddělovačů)
                if nt.replace(" ", "") not in corpus_norm.replace(" ", ""):
                    miss.append(t)
        return (len(miss) == 0, miss)

    ok_char, miss_char = _substr_all(characters)
    ok_place, miss_place = _substr_all(places)
    ok_plot,  miss_plot  = _substr_all(plot_points)

    if not ok_char:  missing += [f"char:{x}"  for x in miss_char]
    else:            found   += [f"char:{x}"  for x in characters]
    if not ok_place: missing += [f"place:{x}" for x in miss_place]
    else:            found   += [f"place:{x}" for x in places]
    if not ok_plot:  missing += [f"plot:{x}"  for x in miss_plot]
    else:            found   += [f"plot:{x}"  for x in plot_points]

    # jazyky
    if languages:
        # normalizuj kódy a názvy
        langs_norm = {_norm_txt(x) for x in languages if _norm_txt(x)}
        spoken = [l.get("iso_639_1","") for l in (detail.get("spoken_languages") or [])]
        spoken += [detail.get("original_language","")]
        spoken += [(_norm_txt(l.get("english_name","")) or "") for l in (detail.get("spoken_languages") or [])]
        spoken = [x for x in spoken if x]
        spoken_norm = {_norm_txt(x) for x in spoken if _norm_txt(x)}
        if not langs_norm.issubset(spoken_norm):
            for x in langs_norm:
                if x not in spoken_norm:
                    missing.append(f"lang:{x}")
        else:
            for x in languages:
                found.append(f"lang:{x}")

    # země
    if countries:
        if kind == "movie":
            cset = { (c.get("iso_3166_1") or "").upper() for c in (detail.get("production_countries") or []) }
        else:
            cset = { str(c).upper() for c in (detail.get("origin_country") or []) }
        # akceptuj i textové názvy – převedeme nejběžnější aliasy na kódy
        # (zde jednoduchý přístup – vyžadujeme aspoň shodu kódu, názvy se často liší)
        norm_countries = {x.upper() for x in countries}
        if not norm_countries.intersection(cset) and not norm_countries.issubset(cset):
            for x in countries:
                if x.upper() not in cset:
                    missing.append(f"country:{x}")
        else:
            for x in countries:
                found.append(f"country:{x}")

    # žánry
    if genres_req:
        gnorm = {_norm_txt(g) for g in genres}
        wantg = {_norm_txt(g) for g in genres_req}
        if not wantg.issubset(gnorm):
            for x in genres_req:
                if _norm_txt(x) not in gnorm:
                    missing.append(f"genre:{x}")
        else:
            for x in genres_req:
                found.append(f"genre:{x}")

    # forbidden (nesmí se objevit)
    if forbid:
        for fb in forbid:
            nf = _norm_txt(fb)
            if nf and nf in corpus_norm:
                missing.append(f"forbidden:{fb}")

    ok_all = (year_ok and not missing)

    dbg = {
        "year": detail_year,
        "year_ok": year_ok,
        "found": found[:50],
        "missing": missing[:50],
        "title": item.get("title") or item.get("name") or "",
        "id": item.get("id"),
        "kind": kind,
    }
    return ok_all, dbg












# 2025-08-10 21:29 CEST  _list_tmdb_ai_mixed() – společný výpis filmů i seriálů
def _list_tmdb_ai_mixed(movies: list[dict], shows: list[dict]) -> None:
    """
    Smíšený výpis pro AI doporučení „Je mi to jedno“.

    • Filmy routuji stejně jako `_list_tmdb_movies()` → action="movie_search", q=název.
    • Seriály routuji stejně jako `_list_tmdb_tv()` → action="tv_seasons", tv_id + tv_name.
    """
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    tmdb     = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    xbmcplugin.setContent(HANDLE, "videos")

    # — FILMY —
    for m in movies:
        overview       = (m.get("overview") or "").strip()
        backdrop_path  = m.get("backdrop_path") or ""
        if tmdb and (not overview or not backdrop_path):
            try:
                det = tmdb.details(m["id"])
                overview      = overview      or (det.get("overview") or "").strip()
                backdrop_path = backdrop_path or (det.get("backdrop_path") or "")
            except TMDbError:
                pass

        rating_txt = f"[B][COLOR gold]★ {m['rating']}[/COLOR][/B]\t" if m.get("rating") else ""
        title_core = f"{m['title']} ({m['year']})" if m.get("year") else m["title"]
        label      = f"{rating_txt}{title_core}"
        li         = xbmcgui.ListItem(label)

        art = {"icon": "DefaultVideo.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        li.setInfo("video", {
            "title":     m["title"],
            "plot":      overview,
            "year":      m.get("year") or 0,
            "mediatype": "movie",
            "rating":    m.get("rating", 0),
            "votes":     m.get("votes", 0),
        })
        if m.get("rating"):
            li.setRating("tmdb", m["rating"], int(m.get("votes", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="movie_search", q=m["title"]),
            li,
            isFolder=True,
        )

    # — SERIÁLY —
    for m in shows:
        overview      = (m.get("overview") or "").strip()
        backdrop_path = m.get("backdrop_path") or ""
        if tmdb and (not overview or not backdrop_path):
            try:
                det = tmdb._get_json(f"/tv/{m['id']}", {"api_key": tmdb_key, "language": "cs-CZ"})
                overview      = overview      or (det.get("overview") or "").strip()
                backdrop_path = backdrop_path or (det.get("backdrop_path") or "")
            except TMDbError:
                pass

        rating_txt = f"[B][COLOR gold]★ {m['rating']}[/COLOR][/B]\t" if m.get("rating") else ""
        title_core = f"{m['name']} ({m['year']})" if m.get("year") else m["name"]
        label      = f"{rating_txt}{title_core}"
        li         = xbmcgui.ListItem(label)

        art = {"icon": "DefaultTVShows.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        li.setInfo("video", {
            "title":     m["name"],
            "plot":      overview,
            "year":      m.get("year") or 0,
            "mediatype": "tvshow",
            "rating":    m.get("rating", 0),
            "votes":     m.get("votes", 0),
        })
        if m.get("rating"):
            li.setRating("tmdb", m["rating"], int(m.get("votes", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tv_seasons", tv_id=m["id"], tv_name=m["name"]),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE)








# 2025-08-10 21:29 CEST  _tmdb_pick_by_year() – výběr nejlepší TMDb položky
def _tmdb_pick_by_year(cands: list[dict], year: int | None) -> dict | None:
    """
    Vrátí položku z kandidátů: preferuje přesnou shodu roku, jinak první položku.
    """
    if not cands:
        return None
    if year:
        for it in cands:
            if it.get("year") == year:
                return it
    return cands[0]









# 2025-08-10 23:47 CEST (Europe/Prague)
def _list_tmdb_movies(items: list[dict]) -> None:
    """
    Renderer výpisu filmů z TMDb (Trendy, TOP, Žánry, A.I. doporučení).

    ZMĚNA:
    ------
    • Klik na položku teď vede přímo na `?action=auto&tmdb=<id>` (jedno-klik),
      takže se neukazuje další nabídka podobných titulů. Přímo se spustí
      workflow `_auto_search_movie(<tmdb_id>)`.

    Ostatní logika (fallback overview/backdrop, rating, artwork, info, votes)
    zůstává beze změny.
    """
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    tmdb     = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    for m in items:
        # –– metadata fallback (overview / backdrop) ––
        overview       = (m.get("overview") or "").strip()
        backdrop_path  = m.get("backdrop_path") or ""
        if tmdb and (not overview or not backdrop_path):
            try:
                det = tmdb.details(m["id"])
                overview      = overview      or (det.get("overview") or "").strip()
                backdrop_path = backdrop_path or (det.get("backdrop_path") or "")
            except TMDbError:
                pass

        # ★ rating (tučně, zlatě) + název
        rating_txt = (
            f"[B][COLOR gold]★ {m['rating']}[/COLOR][/B]\t"
            if m.get("rating") else ""
        )
        title_core = f"{m['title']} ({m['year']})" if m.get("year") else m["title"]
        label      = f"{rating_txt}{title_core}"

        li = xbmcgui.ListItem(label)

        # artwork
        art = {"icon": "DefaultVideo.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        # info-panel
        li.setInfo(
            "video",
            {
                "title":     m["title"],
                "plot":      overview,             # u A.I. výpisů je zde A.I. reason
                "year":      m.get("year") or 0,
                "mediatype": "movie",
                "rating":    m.get("rating", 0),
                "votes":     m.get("votes", 0),
            },
        )
        if m.get("rating"):
            li.setRating("tmdb", m["rating"], int(m.get("votes", 0)))

        # ⟶ PŘÍMÝ SKOK: použij TMDb ID, žádné další „výběry podobných“
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="auto", tmdb=str(m["id"])),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE)





def _tmdb_trending() -> None:
    """🔥 Nejtrendovější filmy z TMDb (/trending/movie/day)."""
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR);  return
    try:
        movies = TMDb(tmdb_key, lang="cs-CZ").trending(limit=40)
    except TMDbError as e:
        _notif(f"Chyba TMDb: {e}", xbmcgui.NOTIFICATION_ERROR);     return
    _list_tmdb_movies(movies)




def _tmdb_top() -> None:
    """TOP hodnocené filmy (/movie/top_rated)."""
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR);  return
    try:
        movies = TMDb(tmdb_key, lang="cs-CZ").top_rated(limit=40)
    except TMDbError as e:
        _notif(f"Chyba TMDb: {e}", xbmcgui.NOTIFICATION_ERROR);     return
    _list_tmdb_movies(movies)




def _list_tmdb_tv(items: list[dict]) -> None:
    """
    Renderer výpisu seriálů z TMDb (Trendy, TOP).

    Aktualizováno: 10-08-2025 17:03 CEST (Europe/Prague)
    """
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    tmdb     = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    xbmcplugin.setContent(HANDLE, "tvshows")

    for m in items:
        # –– metadata fallback (overview / backdrop) ––
        overview      = (m.get("overview") or "").strip()
        backdrop_path = m.get("backdrop_path") or ""
        if tmdb and (not overview or not backdrop_path):
            try:
                det = tmdb._get_json(
                    f"/tv/{m['id']}",
                    {"api_key": tmdb_key, "language": "cs-CZ"},
                )
                overview      = overview      or (det.get("overview") or "").strip()
                backdrop_path = backdrop_path or (det.get("backdrop_path") or "")
            except TMDbError:
                pass

        # ★ rating (tučně, zlatě) + název
        rating_txt = (
            f"[B][COLOR gold]★ {m['rating']}[/COLOR][/B]\t"
            if m.get("rating") else ""
        )
        title_core = f"{m['name']} ({m['year']})" if m.get("year") else m["name"]
        label      = f"{rating_txt}{title_core}"

        li = xbmcgui.ListItem(label)

        # artwork – poster/thumb/fanart
        art = {"icon": "DefaultTVShows.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        # info‑panel
        li.setInfo(
            "video",
            {
                "title":     m["name"],
                "plot":      overview,
                "year":      m.get("year") or 0,
                "mediatype": "tvshow",
                "rating":    m.get("rating", 0),
                "votes":     m.get("votes", 0),
            },
        )
        if m.get("rating"):
            li.setRating("tmdb", m["rating"], int(m.get("votes", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tv_seasons", tv_id=m["id"], tv_name=m["name"]),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE)





def _tmdb_tv_trending() -> None:
    """Seriály – Trendy dnes (/trending/tv/day).

    Aktualizováno: 10-08-2025 17:03 CEST (Europe/Prague)
    """
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR);  return
    try:
        shows = TMDb(tmdb_key, lang="cs-CZ").trending_tv(limit=40)
    except TMDbError as e:
        _notif(f"Chyba TMDb: {e}", xbmcgui.NOTIFICATION_ERROR);     return
    _list_tmdb_tv(shows)


def _tmdb_tv_top() -> None:
    """Seriály – TOP hodnocené (/tv/top_rated).

    Aktualizováno: 10-08-2025 17:03 CEST (Europe/Prague)
    """
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR);  return
    try:
        shows = TMDb(tmdb_key, lang="cs-CZ").top_rated_tv(limit=40)
    except TMDbError as e:
        _notif(f"Chyba TMDb: {e}", xbmcgui.NOTIFICATION_ERROR);     return
    _list_tmdb_tv(shows)





def _tmdb_genres() -> None:
    """Výpis filmových žánrů (submenu)."""
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR);  return
    try:
        genres = TMDb(tmdb_key, lang="cs-CZ").genres()
    except TMDbError as e:
        _notif(f"Chyba TMDb: {e}", xbmcgui.NOTIFICATION_ERROR);     return

    for g in genres:
        li = xbmcgui.ListItem(g["name"])
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tmdb_genre", genre_id=g["id"]),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)






def _tmdb_genre_movies(genre_id: int) -> None:
    """Filmy v daném žánru seřazené podle hodnocení."""
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR);  return
    try:
        movies = TMDb(tmdb_key, lang="cs-CZ").discover_by_genre(
            genre_id,
            sort_by="vote_average.desc",
            vote_count_gte=100,
            limit=40,
        )
    except TMDbError as e:
        _notif(f"Chyba TMDb: {e}", xbmcgui.NOTIFICATION_ERROR);     return
    _list_tmdb_movies(movies)




# 2025‑07‑27 22:58 CEST  _list_releases() – výpis releasů do GUI
def _list_releases(
    rels: List[Release],
    movie: Optional[dict] = None,
) -> None:
    """
    Přehledný GUI‑výpis nalezených releasů + `xbmcplugin.endOfDirectory()`.

    Args:
        rels:  List objektů `Release`, které vrací `SearchEngine`.
        movie: Nepovinné TMDb metadata (title, overview, poster…), předaná
               dál do `_build_stream_li()` pro bohatší popisky.
    """
    # – 1) ochrana – prázdný seznam ------------------------------------
    if not rels:
        _modal("Nenalezen žádný vyhovující release.")
        return

    # – 2) GUI – kategorie a typ obsahu -------------------------------
    xbmcplugin.setPluginCategory(
        HANDLE,
        (movie or {}).get("title", "Výsledky"),
    )
    xbmcplugin.setContent(HANDLE, "videos")

    # – 3) položky -----------------------------------------------------
    for r in rels:
        xbmcplugin.addDirectoryItem(
            HANDLE,
            *_build_stream_li(r, movie),
        )

    # – 4) finální „end“ ----------------------------------------------
    xbmcplugin.endOfDirectory(HANDLE)








def _auto_search_movie(tmdb_id: int) -> None:  # 10-08-2025 18:26 CEST (Europe/Prague)
    """
    Jedno‑klikové vyhledání filmu dle TMDb ID:
      1) stáhne detail + alternativní stopáže
      2) sestaví dotazy (jen s primárním rokem z TMDb)
      3) spustí vyhledání (PRIMÁR + FALLBACK), ale **filtr** už používá
         whitelist „oficiálních“ roků z TMDb (produkční země + hlavní trhy, ±1 rok)
    """
    # – 0) detail filmu ––––––––––––––––––––––––––––––––––––––––––––
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _modal("Chybí API klíč TMDb.")
        return

    try:
        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        det  = tmdb.details(tmdb_id)
        runtimes = [int(det.get("runtime") or 0)] + tmdb.get_alt_runtimes(tmdb_id)
        # NOVĚ: whitelist povolených roků pro filtr
        try:
            year_whitelist = tmdb.allowed_years(tmdb_id, primary_year=det.get("year"))
        except TMDbError:
            year_whitelist = []
    except TMDbError as e:
        _modal(f"Chyba TMDb: {e}")
        return

    runtimes = [rt for rt in runtimes if rt]

    # – 1) primární dotazy (bez alt‑titlů) ––––––––––––––––––––––––––
    primary_q = _query_variants(det["title"], det["original_title"], det["year"])
    primary_norms = {
        _norm(det["title"]),
        _norm(det["original_title"]),
    }

    # – LOG BEGIN –––––––––––––––––––––––––––––––––––––––––––––––––––
    global _SEARCH_LOG_PATH
    log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
    if not xbmcvfs.exists(log_dir):
        xbmcvfs.mkdirs(log_dir)
    ts   = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    safe = re.sub(r"[^0-9A-Za-z]+", "_", f"{det['title']}_{det['year']}")[:40]
    _SEARCH_LOG_PATH = os.path.join(log_dir, f"{ts}_{safe}.log")
    _log_event("SEARCH_BEGIN", det["title"], det["year"])

    prog = _SearchProgress()
    try:
        rels = _ENGINE.search_movie_wave(
            primary_q,
            runtimes=runtimes,
            title_norms=primary_norms,
            movie_year=det["year"],
            allowed_years=year_whitelist,   # ← NOVĚ: tolerance v rámci filtru
            progress_cb=prog,
        )
    except APIError as e:
        prog.close()
        _modal(f"Chyba Webshare: {e}")
        _log_event("SEARCH_END", det["title"], "ERR")
        _SEARCH_LOG_PATH = ""
        return
    finally:
        prog.close()

    # – 2) máme releasy? → hotovo
    if rels:
        _list_releases(rels, movie=det)
        _log_event("SEARCH_END", det["title"], len(rels))
        _SEARCH_LOG_PATH = ""
        return

    # – 3) FALLBACK s alt‑tituly ––––––––––––––––––––––––––––––––––––
    try:
        alt_titles: list[str] = [
            rec["title"]
            for rec in tmdb.alternative_titles(tmdb_id, max_items=_ALT_MAX_TITLES)
            if rec["country"] in _ALT_COUNTRY_WHITELIST
        ]
    except TMDbError:
        alt_titles = []

    if not alt_titles:
        _modal("Nenalezen žádný vyhovující release.")
        _log_event("SEARCH_END", det["title"], 0)
        _SEARCH_LOG_PATH = ""
        return

    _log_event("SEARCH_FALLBACK", det["title"], len(alt_titles))

    alt_q = _query_variants(
        det["title"], det["original_title"], det["year"],
        alt_titles=alt_titles
    )
    alt_norms = primary_norms | {_norm(t) for t in alt_titles}

    prog = _SearchProgress()
    try:
        rels_alt = _ENGINE.search_movie_wave(
            alt_q,
            runtimes=runtimes,
            title_norms=alt_norms,
            movie_year=det["year"],
            allowed_years=year_whitelist,    # ← stejný whitelist použijeme i zde
            progress_cb=prog,
        )
    except APIError as e:
        prog.close()
        _modal(f"Chyba Webshare (fallback): {e}")
        _log_event("SEARCH_END", det["title"], "ERR2")
        _SEARCH_LOG_PATH = ""
        return
    finally:
        prog.close()

    if not rels_alt:
        _modal("Nenalezen žádný vyhovující release.")
        _log_event("SEARCH_END", det["title"], 0)
        _SEARCH_LOG_PATH = ""
        return

    _list_releases(rels_alt, movie=det)
    _log_event("SEARCH_END", det["title"], len(rels_alt))
    _SEARCH_LOG_PATH = ""







# 2025‑07‑28 16:57 CEST  – _search_movie_flow() • primární + fallback
def _search_movie_flow(
    movie: dict,
    *,
    interactive: bool = True,
) -> bool:
    """
    Interaktivní fallback workflow pro jediný film z TMDb:
    • 1. vlna hledá bez alt‑titlů
    • 2. vlna (spustí se jen při neúspěchu) přidá alternativní názvy
    """
    title      = (movie.get("title") or "").strip()
    orig_title = (movie.get("original_title") or "").strip()
    year       = int((movie.get("release_date") or "0000")[:4] or 0)
    runtimes   = [movie.get("runtime") or 0]

    # – 1) PRIMÁRNÍ DOTAZY ––––––––––––––––––––––––––––––––––––––––––
    queries_primary = _query_variants(title, orig_title, year or None)
    if interactive and not queries_primary:
        text = _keyboard_input(f"{title} (TMDb)")
        if text:
            queries_primary.append(text)
    if not queries_primary:
        return False

    norms_primary = {_norm(title), _norm(orig_title)}

    rels = _ENGINE.search_movie_wave(
        queries_primary,
        runtimes=[r for r in runtimes if r],
        title_norms=norms_primary,
        movie_year=year or None,
        progress_cb=None,
    )
    if rels:
        _list_releases(rels)
        return True

    # – 2) FALLBACK S ALT‑TITLY –––––––––––––––––––––––––––––––––––––
    alt_titles = [
        alt["title"]
        for alt in movie.get("alternative_titles", {}).get("titles", [])
    ]
    if not alt_titles:
        return False

    _log_event("SEARCH_FALLBACK", title, len(alt_titles))

    queries_alt = _query_variants(
        title, orig_title, year or None,
        alt_titles=alt_titles
    )
    norms_alt = norms_primary | {_norm(t) for t in alt_titles}

    rels_alt = _ENGINE.search_movie_wave(
        queries_alt,
        runtimes=[r for r in runtimes if r],
        title_norms=norms_alt,
        movie_year=year or None,
        progress_cb=None,
    )
    if not rels_alt:
        return False

    _list_releases(rels_alt)
    return True








# 2025‑07‑27 23:30 CEST  _show_tmdb_feed() – FIX: isFolder=True
def _show_tmdb_feed(feed_key: str) -> None:
    """
    Zobrazí seznam filmů z TMDb feedu (trendy, top rated, žánr …).
    Položky odkazují přímo na `?action=auto&tmdb=<id>`.
    """
    try:
        movies = TMDb().feed(feed_key)
    except TMDbError as e:
        _modal(str(e))
        return

    for m in movies:
        li = xbmcgui.ListItem(label=m["title"])
        li.setArt({"thumb": TMDb().poster(m, small=True)})
        li.setInfo("video", {"year": m.get("release_date", "")[:4]})
        url = f"{BASE_URL}?action=auto&tmdb={m['id']}"
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url,
            li,
            isFolder=True,      # ← dříve False
        )

    xbmcplugin.endOfDirectory(HANDLE)








# 2025‑07‑28 13:21 CEST  _query_variants() – podpora alt_titles
def _query_variants(
    title: str,
    original_title: str,
    year: int | None,
    *,
    alt_titles: Sequence[str] = (),
    qualities: Tuple[str, ...] = ("2160p", "1080p", "720p"),
) -> List[str]:
    """
    Sestaví **všechny kombinace dotazů** pro film:

        • základní název, originální název a alternativní názvy  
        • dvojice názvů i v opačném pořadí (\"Vetřelec Alien\" ↔ \"Alien Vetřelec\")  
        • pro každý název varianty:  *+ rok + kvalita*,  *+ rok*,  *bez roku*

    Parametry
    ---------
    title : str
        Český lokalizovaný název (TMDb „title“).
    original_title : str
        Originální název (TMDb „original_title“).
    year : int | None
        Rok premiéry (použije se ve dvou variantách dotazu).
    alt_titles : Sequence[str], optional
        Další aliasy/mezititulky, které má smysl přiřadit.
    qualities : Tuple[str, ...], optional
        Seznam řetězců reprezentujících kvality releasů.

    Returns
    -------
    List[str]
        Hotové syrové query‑stringy pro `Webshare.search()`.
    """
    # ❶ sesbíráme *všechny* relevantní názvy
    names: set[str] = {title}
    if original_title and original_title.lower() != title.lower():
        names.add(original_title)

    for alt in alt_titles:
        if alt and alt.lower() not in {n.lower() for n in names}:
            names.add(alt)

    # ❷ přidáme obousměrné dvojice („A B“ ↔ „B A“)
    for a, b in permutations(list(names), 2):
        names.add(f"{a} {b}")

    # ❸ finalizujeme dotazy
    variants: list[str] = []
    for name in names:
        base = f"{name} {year}" if year else name
        variants.extend(f"{base} {q}" for q in qualities)  # + kvalita
        variants.append(base)                              # bez kvality
    return variants






# 2025‑07‑28 08:51 CEST  _movie_search() – výběr filmu přímo v GUI (bez dialogu)
def _movie_search(term: str | None = None) -> None:
    """
    Interaktivní workflow vyhledávání filmu na TMDb.

    Změny oproti verzi 1.4
    ----------------------
    1. **Dialog s výběrem filmu byl zrušen.**  
       Po zadání dotazu vždy dostanete stejný přehledný GUI‑výpis,
       jaký už znáte ze seriálů. Každá položka odkazuje na
       `?action=auto&tmdb=<id>` a po kliknutí spustí plnou vlnu
       vyhledávání releasů (_auto_search_movie).
    2. Pokud TMDb vrátí jediný výsledek, doplněk se chová stejně
       jako dřív – rovnou spustí hledání releasů bez mezikroku.
    """
    # ❶ Získání textu dotazu --------------------------------------------------
    if term is None:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        term = (args.get("q", [""])[0] or "").strip()
        if not term:
            term = _keyboard_input("Název filmu (TMDb)")
            if not term:
                return
    term = term.strip()
    _add_to_history(term)

    # ❷ Dotaz na TMDb ----------------------------------------------------------
    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _modal("Chybí API klíč TMDb.");  return

    try:
        movies = TMDb(tmdb_key, lang="cs-CZ").search(term, limit=40)
    except TMDbError as e:
        _modal(f"Chyba TMDb: {e}");      return

    if not movies:
        _modal("Nic nenalezeno.");       return

    # ❸ Pokud je výsledek jediný → chováme se beze změny -----------------------
    if len(movies) == 1:
        _auto_search_movie(movies[0]["id"])
        return

    # ❹ GUI výpis výsledků (shodný styl jako _tv_search) -----------------------
    xbmcplugin.setPluginCategory(HANDLE, f"Výsledky: {term}")
    xbmcplugin.setContent(HANDLE, "movies")          # typ obsahu

    for m in movies:
        # ★ hodnocení tučně + zlatě + tabulátor
        rating_txt = (
            f"[B][COLOR gold]★ {m['rating']}[/COLOR][/B]\t"
            if m.get("rating") else ""
        )
        title_core = (
            f"{m['title']} ({m['year']})" if m.get("year") else m["title"]
        )
        label = f"{rating_txt}{title_core}"

        li = xbmcgui.ListItem(label)

        # artwork --------------------------------------------------------------
        art = {"icon": "DefaultVideo.png"}
        if m.get("poster_path"):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{m['poster_path']}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{m['poster_path']}"
        if m.get("backdrop_path"):
            art["fanart"] = f"https://image.tmdb.org/t/p/original{m['backdrop_path']}"
        li.setArt(art)

        # info‑panel -----------------------------------------------------------
        li.setInfo(
            "video",
            {
                "title":     m["title"],
                "plot":      m.get("overview", ""),
                "year":      m.get("year") or 0,
                "mediatype": "movie",
                "rating":    m.get("rating", 0),
                "votes":     m.get("votes", 0),
            },
        )
        if m.get("rating"):
            li.setRating("tmdb", m["rating"], int(m.get("votes", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="auto", tmdb=str(m["id"])),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE)








# 2025‑07‑22 07:56 CEST  _tv_search() – rating: tab + tučná zlatá
def _tv_search(term: str | None = None) -> None:
    """
    Vyhledá seriály na TMDb a zobrazí je s tučným zlatým hodnocením.

    Novinky 22/07/2025 07:56 CEST
    -----------------------------
    • hodnocení v Label1 tučně + zlatě, za ním tabulátor
    """
    # 1) — vstup ———————————————————————————————————————————
    if term is None:
        term = _keyboard_input("Název seriálu (TMDb)")
        if not term:
            return
    term = term.strip()
    _add_to_history(term)

    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    if not tmdb_key:
        _modal("Chybí API klíč TMDb.");  return

    try:
        shows = TMDb(tmdb_key, lang="cs-CZ").search_tv(term, limit=20)
    except TMDbError as e:
        _modal(f"Chyba TMDb: {e}");      return
    if not shows:
        _modal("Nic nenalezeno.");       return

    # 2) — GUI výpis ———————————————————————————————
    xbmcplugin.setPluginCategory(HANDLE, f"Výsledky: {term}")
    xbmcplugin.setContent(HANDLE, "tvshows")

    for s in shows:
        rating_txt = (
            f"[B][COLOR gold]★ {s['rating']}[/COLOR][/B]\t"
            if s.get("rating") else ""
        )
        title_core = (
            f"{s['name']} ({s['year']})" if s.get("year") else s["name"]
        )
        label      = f"{rating_txt}{title_core}"

        li = xbmcgui.ListItem(label)

        # artwork --------------------------------------------------------------
        art = {"icon": "DefaultTVShows.png"}
        if s.get("poster_path"):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{s['poster_path']}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{s['poster_path']}"
        if s.get("backdrop_path"):
            art["fanart"] = f"https://image.tmdb.org/t/p/original{s['backdrop_path']}"
        li.setArt(art)

        # info‑panel -----------------------------------------------------------
        li.setInfo(
            "video",
            {
                "title":     s["name"],
                "plot":      s.get("overview", ""),
                "year":      s.get("year") or 0,
                "mediatype": "tvshow",
                "rating":    s.get("rating", 0),
                "votes":     s.get("votes", 0),
            },
        )
        if s.get("rating"):
            li.setRating("tmdb", s["rating"], int(s.get("votes", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tv_seasons", tv_id=s["id"], tv_name=s["name"]),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)







# 2025‑07‑22 18:05 CEST  _sosac_search()  – NOVÁ
def _sosac_search(kind: str = "movie", term: str | None = None) -> None:
    """
    Vyhledávání na Sosáč.cz (prémiový Streamuj.tv účet je POVINNÝ).

    Args:
        kind: "movie" | "tv"
        term: předvyplněný dotaz (pro volání z Historie)

    ▸ Pokud nejsou v Settings → Sosáč vyplněny přihlašovací údaje,
      zobrazí se dialog a otevře se karta nastavení.
    """
    # – 1) kontrola přihlášení ––––––––––––––––––––––––––––––––––––––––
    if not (ADDON.getSetting("sosac_user") and ADDON.getSetting("sosac_pass")):
        _modal("Nejprve vyplňte přihlašovací údaje ke Streamuj.tv (karta Sosáč).")
        ADDON.openSettings()
        return

    # – 2) dotaz z klávesnice –––––––––––––––––––––––––––––––––––––––––
    if term is None:
        term = _keyboard_input("Hledat na Sosáči")
        if not term:
            return
    term = term.strip()

    cli  = SosacClient()
    items = (cli.search_movies(term) if kind == "movie" else cli.search_tv(term))
    if not items:
        _modal("Nic nenalezeno.");  return

    xbmcplugin.setPluginCategory(HANDLE, f"Sosáč → {term}")
    xbmcplugin.setContent(HANDLE, "movies" if kind == "movie" else "tvshows")

    for it in items:
        label = f"{it.title} ({it.year})" if it.year else it.title
        li    = xbmcgui.ListItem(label, offscreen=True)
        li.setArt({"thumb": it.img, "icon": it.img, "poster": it.img})
        li.setProperty("isPlayable", "true")
        url = _url(action="sosac_play", vid=it.video_id, t=urllib.parse.quote(it.title))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)





# 2025‑07‑23 10:45 CEST – aktualizovaná _sosac_play()
def _sosac_play(video_id: str | None = None) -> None:
    """Přehrání videa ze Sosáče přes stream.resolver."""
    # 1) zajišť resolver
    if not _ensure_stream_resolver():
        return
    from stream.resolver import resolve as sr_resolve   # odložený import

    # 2) ID videa
    if video_id is None:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        video_id = args.get("vid", [""])[0]
    if not video_id:
        _modal("Chybné ID videa");  return

    # 3) prémiová URL
    cli = SosacClient()
    page_url = cli.resolve(video_id)

    # 4) resolver → přímý stream
    try:
        stream_url = sr_resolve(page_url)
    except Exception as e:
        xbmc.log(f"[RichMovie] stream.resolver error: {e}", xbmc.LOGERROR)
        stream_url = None

    if not stream_url:
        _modal("Nepodařilo se najít video stream (resolver).")
        return

    # 5) předání Kodi
    li = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)





# 2025‑07‑22 07:56 CEST  _tv_seasons() – rating: tab + tučná zlatá
def _tv_seasons() -> None:
    """
    Výpis řad (season) daného seriálu s tučným zlatým hodnocením.

    Novinky 22/07/2025 07:56 CEST
    -----------------------------
    • hodnocení v Label1 tučně + zlatě, za ním tabulátor
    """
    args     = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    tv_id    = args.get("tv_id", [""])[0]
    tv_name  = args.get("tv_name", [""])[0]

    if not tv_id:
        _modal("Chybí tv_id.");  return

    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    try:
        det = TMDb(tmdb_key, lang="cs-CZ")._get_json(
            f"/tv/{tv_id}",
            {"api_key": tmdb_key, "language": "cs-CZ"},
        )
    except TMDbError as e:
        _modal(f"Chyba TMDb: {e}");  return

    tv_overview = det.get("overview", "")
    tv_poster   = det.get("poster_path") or ""
    tv_backdrop = det.get("backdrop_path") or ""

    seasons = [s for s in det.get("seasons", []) if s.get("season_number", 0) > 0]
    if not seasons:
        _modal("Žádné série.");  return

    for s in seasons:
        sn = s["season_number"]
        rating = round(float(s.get("vote_average") or 0), 1)
        rating_txt = (
            f"[B][COLOR gold]★ {rating}[/COLOR][/B]\t" if rating else ""
        )

        label_core = f"Série {sn:02d}"
        if s.get("name") and s["name"].lower() not in ("season", label_core.lower()):
            label_core += f" – {s['name']}"
        label = f"{rating_txt}{label_core}"

        # artwork – beze změny -------------------------------------------------
        poster = s.get("poster_path") or tv_poster
        art = {"icon": "DefaultTVShows.png"}
        if poster:
            art["poster"] = f"https://image.tmdb.org/t/p/w342{poster}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{poster}"
        if tv_backdrop:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{tv_backdrop}"

        # info‑panel – beze změny ---------------------------------------------
        info = {
            "title":     label_core,
            "plot":      (s.get("overview") or "").strip() or tv_overview,
            "season":    sn,
            "mediatype": "season",
            "rating":    rating,
            "votes":     int(s.get("vote_count", 0)),
        }

        li = xbmcgui.ListItem(label)
        li.setArt(art)
        li.setInfo("video", info)
        if rating:
            li.setRating("tmdb", rating, int(s.get("vote_count", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(
                action="tv_episodes",
                tv_id=tv_id,
                tv_name=tv_name,
                season=str(sn),
            ),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)






# 2025‑07‑22 07:56 CEST  _tv_episodes() – rating: tab + tučná zlatá
def _tv_episodes() -> None:
    """
    Výpis epizod dané řady se zlatým tučným hodnocením v Label1.

    Novinky 22/07/2025 07:56 CEST
    -----------------------------
    • hodnocení v Label1 tučně + zlatě, za ním tabulátor
    """
    args     = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    tv_id    = args.get("tv_id", [""])[0]
    tv_name  = args.get("tv_name", [""])[0]
    season   = int(args.get("season", ["0"])[0])

    tmdb_key = ADDON.getSetting("tmdb_api_key").strip()
    try:
        season_data = TMDb(tmdb_key, lang="cs-CZ")._get_json(
            f"/tv/{tv_id}/season/{season}",
            {"api_key": tmdb_key, "language": "cs-CZ"},
        )
    except TMDbError as e:
        _modal(f"Chyba TMDb: {e}");  return

    eps = season_data.get("episodes", [])
    if not eps:
        _modal("Žádné epizody.");  return

    season_overview = season_data.get("overview", "") or ""
    season_poster   = season_data.get("poster_path") or ""

    # — Fallback na úroveň celého seriálu —
    try:
        tv_det = TMDb(tmdb_key, lang="cs-CZ")._get_json(
            f"/tv/{tv_id}",
            {"api_key": tmdb_key, "language": "cs-CZ"},
        )
    except TMDbError:
        tv_det = {}
    tv_overview = tv_det.get("overview", "") or ""
    tv_poster   = tv_det.get("poster_path") or ""
    tv_backdrop = tv_det.get("backdrop_path") or ""

    pad = len(str(max(e["episode_number"] for e in eps)))
    for e in eps:
        no   = e["episode_number"]
        rating = round(float(e.get("vote_average") or 0), 1)
        rating_txt = (
            f"[B][COLOR gold]★ {rating}[/COLOR][/B]\t" if rating else ""
        )

        name = e.get("name") or ""
        label_core = f"{no:0{pad}d} – {name}" if name else f"{no:0{pad}d}"
        label      = f"{rating_txt}{label_core}"

        # artwork – beze změny ------------------------------------------------
        still   = e.get("still_path") or ""
        poster  = still or season_poster or tv_poster
        art = {"icon": "DefaultEpisodes.png"}
        if poster:
            width = "w300" if still else "w342"
            art["poster"] = f"https://image.tmdb.org/t/p/{width}{poster}"
            art["thumb"]  = art["poster"]
        if tv_backdrop:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{tv_backdrop}"

        # plot fallback – beze změny ------------------------------------------
        plot = (e.get("overview") or "").strip() or season_overview or tv_overview

        # info‑panel – beze změny ---------------------------------------------
        info = {
            "title":        label_core,
            "plot":         plot,
            "season":       season,
            "episode":      no,
            "tvshowtitle":  tv_name,
            "mediatype":    "episode",
            "rating":       rating,
            "votes":        int(e.get("vote_count", 0)),
        }

        li = xbmcgui.ListItem(label)
        li.setArt(art)
        li.setInfo("video", info)
        if rating:
            li.setRating("tmdb", rating, int(e.get("vote_count", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(
                action  = "tv_play",
                tv_id   = tv_id,
                tv_name = tv_name,
                season  = str(season),
                episode = str(no),
                ep_title= name,
            ),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)




# 2025-08-19 11:14 CEST (Europe/Prague) – _tv_play(): allowed_years (TV/season/episode) + back-compat fallback for engine
def _tv_play() -> None:                               # noqa: C901
    """
    Vyhledání a výpis releasů jednoho dílu seriálu **se 3 řízenými vlnami**.

    ÚPRAVA 20-07-2025 20:46 CEST
    ----------------------------
    1. Overlay vypnut – po volání `setInfo()` nastavuji
       ``li.setProperty("overlay", "0")`` (0 = ICON_OVERLAY_NONE), takže
       Estuary už nekreslí □/◐/■.
    2. Poster se vůbec nenastavuje – nepoužijeme `ep_thumb` ⇒
       ve všech pohledech (List, Wall…) Kodi bere `icon/thumb`, které
       `_build_stream_li()` už předvyplnil na
       `resources/media/quality/1080p.png`.

    ÚPRAVA 2025-08-19 11:14 CEST (Europe/Prague)
    ----------------------------
    • **allowed_years**: z TMDb poskládáme roky (seriál / série / epizoda) a předáváme je do vyhledávání.
      Pokud engine ještě nepodporuje parametr `allowed_years`, automaticky spadne na zpětně kompatibilní volání bez něj.

    ÚPRAVA 09-08-2025 00:21 CEST
    ----------------------------
    • **Nově filtrujeme TMDb „alternative titles“**:
        – bereme jen země v `_ALT_COUNTRY_WHITELIST`
        – musí obsahovat **alespoň jedno latinkové písmeno** (`[A-Za-z]`)
      Tím se do dotazů nedostávají názvy typu indické „Dost“ apod.

    ÚPRAVA 10-08-2025 16:42 CEST (Europe/Prague)
    --------------------------------------------
    • **SPIN_BAN_SANITIZE + EN *translations***: kromě CS/EN `episode_details()`
      doplníme i názvy z `/translations` (en-US / en-GB / en). Tím se do
      `ep_names` vždy dostane i originální „The One Where/With …“ a sanitizace
      spin‑off ban‑tokenů (např. `monica`) je bezpečně odstraní.

    ÚPRAVA 14-08-2025  – přidání TV kontextu do play URL
    ----------------------------------------------------
    • Do URL akce `play` posílám také `tv_id`, `tv_name`, `season`, `episode`,
      `ep_title`, aby `_play()` mohl zapsat „Historii sledování“ (epizody) a
      Next‑Up měl jistotu kontextu.
    """
    # 1) --- PARAMS ----------------------------------------------------
    args: Dict[str, List[str]] = (
        dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    )
    tv_id   = args.get("tv_id",   [""])[0]
    tv_name = args.get("tv_name", [""])[0]

    try:
        season_no = int((args.get("season")  or ["0"])[0])
        ep_no     = int((args.get("ep_no")   or args.get("episode") or ["0"])[0])
    except ValueError:
        season_no = ep_no = 0

    ep_title = args.get("ep_title", [""])[0].strip()
    if not (tv_name and season_no > 0 and ep_no > 0):
        _modal("Neplatné parametry vyhledávání.")
        return

    key_str   = f"{tv_id}:{season_no}:{ep_no}"
    cache_key = (tv_id, season_no, ep_no)
    rels: Optional[List[Release]] = NEXT_CACHE.pop(cache_key, None)

    # --- disk-cache ---------------------------------------------------
    if rels is None:
        disk_json = _disk_nextup_cache().get(key_str)
        if isinstance(disk_json, list):
            try:
                rels = [Release(**d) for d in disk_json]
            except Exception:
                rels = None
    searching = rels is None

    # 2) --- ALIASY z TMDb (názvy seriálu + epizody) ------------------
    tmdb_key  = ADDON.getSetting("tmdb_api_key").strip()
    tv_names  = [tv_name]
    ep_names  = [ep_title] if ep_title else []

    if tmdb_key and tv_id.isdigit():
        tmdb_cs = TMDb(tmdb_key, lang="cs-CZ")
        # Seriál – názvy + alt‑tituly (zachováno + whitelist + latinka)
        try:
            det = tmdb_cs.tv_details(int(tv_id))
            tv_names += [det.get("original_name", "")]
            alts = tmdb_cs._get_json(
                f"/tv/{tv_id}/alternative_titles",
                {"api_key": tmdb_key},
            ).get("results", [])
            tv_names += [
                alt["title"]
                for alt in alts
                if alt.get("title")
                and alt.get("iso_3166_1") in _ALT_COUNTRY_WHITELIST
                and re.search(r"[A-Za-z]", alt["title"])
            ]
        except TMDbError:
            pass

        # Epizoda – **CS a EN detail zvlášť** (zachováno)
        ep_cs: Dict[str, Any] = {}
        try:
            ep_cs = tmdb_cs.episode_details(int(tv_id), season_no, ep_no)
            name_cs = ep_cs.get("name", "") or ""
            if name_cs:
                ep_names.append(name_cs)
        except TMDbError:
            ep_cs = {}

        try:
            ep_en = TMDb(tmdb_key, lang="en-US").episode_details(
                int(tv_id), season_no, ep_no
            )
            name_en = ep_en.get("name", "") or ""
            orig_en = ep_en.get("original_name", "") or name_en
            if name_en:
                ep_names.append(name_en)
            if orig_en:
                ep_names.append(orig_en)
        except TMDbError:
            pass

        # *** NOVĚ: EN názvy z /translations jako jistota „The One Where…“ ***
        try:
            trs = tmdb_cs.episode_translations(int(tv_id), season_no, ep_no)
            pref_keys = ("en-US", "en-GB", "en", "cs-CZ", "cs")
            seen_lc = {n.lower() for n in ep_names if n}
            for k in pref_keys:
                nm = (trs.get(k) or "").strip()
                if nm and nm.lower() not in seen_lc:
                    ep_names.append(nm)
                    seen_lc.add(nm.lower())
            # Heuristika: pokud žádný z názvů nezní jako „The One Where/With …“, přidej první takový z překladů
            if not any(re.search(r"\bthe one (where|with)\b", n.lower()) for n in ep_names if n):
                for nm in trs.values():
                    if nm and re.search(r"\bthe one (where|with)\b", nm.lower()):
                        if nm.lower() not in seen_lc:
                            ep_names.append(nm)
                        break
        except TMDbError:
            pass

        if not ep_title:
            ep_title = (ep_cs.get("name", "") or "").strip()

    # 3) --- DOTAZY ----------------------------------------------------
    queries = QueryBuilder.tv(tv_names, ep_names, season_no, ep_no)

    # 4) --- FILTRAČNÍ TOKENY -----------------------------------------
    title_norms: List[str] = []
    _seen: set[str] = set()

    def _push(tok: str) -> None:
        n = _norm(tok)
        if n and n not in _seen:
            title_norms.append(n)
            _seen.add(n)

    _push(f"s{season_no:02d}e{ep_no:02d}")
    _push(f"{season_no}x{ep_no:02d}")
    _push(f"{season_no:02d}x{ep_no:02d}")
    for nm in tv_names:
        for w in nm.split():
            _push(w)
    for nm in ep_names:
        for w in nm.split():
            _push(w)

    # — zákaz jiné S/E kombinace + erotika (pokud title není adult) —
    banned_keys: set[str] = set()
    for sn in range(1, 100):
        for en in range(1, 100):
            if sn == season_no and en == ep_no:
                continue
            for pat in (f"s{sn:02d}e{en:02d}", f"{sn}x{en:02d}", f"{sn:02d}x{en:02d}"):
                banned_keys.add(_norm(pat))
    if not (_is_adult_title(tv_name) or _is_adult_title(ep_title)):
        banned_keys |= {_norm(w) for w in EROTIC_KEYWORDS}

    # — SPIN‑OFF tokeny (allow/ban) + **SANITIZACE BAN** —
    allow_tok, ban_tok = _spin_tokens(tv_id) if tv_id else (set(), set())
    title_norms += [t for t in allow_tok if t not in _seen]

    _ep_tv_words = {
        _norm(w)
        for nm in (*tv_names, *ep_names)
        for w in nm.split()
        if _norm(w)
    }
    _ban_before = len(ban_tok)
    if _ep_tv_words:
        ban_tok = {t for t in ban_tok if t not in _ep_tv_words}
    _ban_removed = _ban_before - len(ban_tok)
    if _ban_removed > 0:
        _log_event("SPIN_BAN_SANITIZE", tv_id, f"removed={_ban_removed}")

    banned_keys |= ban_tok

    # — epizodní slovníky (varianty) —
    ep_title_variants = [
        [_norm(w) for w in nm.split() if _norm(w)]
        for nm in ep_names if nm
    ]

    # 5) --- LOG SOUBOR ------------------------------------------------
    if searching:
        log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
        if not xbmcvfs.exists(log_dir):
            xbmcvfs.mkdirs(log_dir)
        ts   = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        safe = re.sub(r"[^0-9A-Za-z]+", "_",
                      f"{tv_name}_s{season_no:02d}e{ep_no:02d}")[:50]
        global _SEARCH_LOG_PATH
        _SEARCH_LOG_PATH = os.path.join(log_dir, f"{ts}_{safe}.log")
        _log_event("SEARCH_BEGIN", tv_name, season_no, ep_no)

    # 6) --- HLEDÁNÍ s řízenými vlnami --------------------------------
    if searching:
        bucket: Dict[str, Release] = {}

        # 2025-08-19 11:14 CEST (Europe/Prague) – sestav `allowed_years` z TMDb (seriál / série / epizoda)
        allowed_years: set[int] = set()

        def _yr(val: str | None) -> int | None:
            if not val:
                return None
            m = re.match(r"(\d{4})", str(val))
            return int(m.group(1)) if m else None

        # Rok seriálu
        try:
            tv_year = _yr((det or {}).get("first_air_date")) if 'det' in locals() else None
            if tv_year:
                allowed_years.add(tv_year)
        except Exception:
            pass

        # Rok série (season)
        try:
            if tmdb_key and tv_id.isdigit() and season_no:
                season_json = tmdb_cs._get_json(
                    f"/tv/{tv_id}/season/{season_no}", {"api_key": tmdb_key, "language": "cs-CZ"}
                )
                season_year = _yr(season_json.get("air_date"))
                if season_year:
                    allowed_years.add(season_year)
        except Exception:
            pass

        # Rok epizody (CS/EN)
        try:
            ep_year = _yr((ep_cs or {}).get("air_date")) if 'ep_cs' in locals() else None
            if not ep_year and 'ep_en' in locals():
                ep_year = _yr((ep_en or {}).get("air_date"))
            if ep_year:
                allowed_years.add(ep_year)
        except Exception:
            pass

        def _wave(label: str, qs: List[str]) -> None:
            if not qs:
                return
            prog = _SearchProgress(f"RichMovie – {label}")
            try:
                # Primární volání s allowed_years (pokud jej engine podporuje)
                try:
                    found = _ENGINE.search_wave(
                        qs,
                        title_norms=title_norms,
                        banned_keys=banned_keys,
                        ep_title_variants=ep_title_variants,
                        allowed_years=list(allowed_years),  # 2025-08-19 11:14 CEST (Europe/Prague)
                        progress_cb=prog,
                        top_full_probe=15,
                        max_quick_probe=0,
                    )
                except TypeError:
                    # zpětná kompatibilita: starší engine bez parametru `allowed_years`
                    found = _ENGINE.search_wave(
                        qs,
                        title_norms=title_norms,
                        banned_keys=banned_keys,
                        ep_title_variants=ep_title_variants,
                        progress_cb=prog,
                        top_full_probe=15,
                        max_quick_probe=0,
                    )
            finally:
                prog.close()
            for r in found:
                bucket.setdefault(r.ident, r)

        _wave("vlna 1", queries[0:6])
        _wave("vlna 2", queries[6:12])
        if len(bucket) < 10:
            _wave("vlna 3", queries[12:18])
        if len(bucket) < 5:
            _wave("vlna X", queries[18:])

        rels = list(bucket.values())
        if rels:
            try:
                _disk_nextup_cache().put(
                    key_str, [asdict(r) for r in rels]
                )
            except Exception:
                pass

    # 7) --- GUI VÝPIS ------------------------------------------------
    if not rels:
        _modal("Nenalezen žádný vyhovující release.")
        if searching:
            _log_event("SEARCH_END", tv_name, 0)
            _SEARCH_LOG_PATH = ""
        return

    xbmcplugin.setPluginCategory(
        HANDLE, f"{tv_name} S{season_no:02d}E{ep_no:02d}"
    )
    xbmcplugin.setContent(HANDLE, "videos")

    for r in rels:
        # Vytvoř ListItem (zachová artwork a popisy); URL přepíšeme, aby neslo TV kontext
        url, li, _ = _build_stream_li(r)  # už má icon + thumb = 1080p.png

        # doplnění InfoTagů pro epizodu (musí být před overlay)
        li.setInfo(
            "video",
            {
                "title":        ep_title or li.getLabel(),
                "tvshowtitle":  tv_name,
                "season":       season_no,
                "episode":      ep_no,
                "mediatype":    "episode",
            },
        )
        li.setProperty("overlay", "0")  # zruší □/◐/■ (musí být **po** setInfo)

        # **NOVĚ**: play URL s plným TV kontextem → _play() zapíše Historii sledování
        url = _url(
            action   = "play",
            ident    = r.ident,
            tv_id    = tv_id,
            tv_name  = tv_name,
            season   = str(season_no),
            episode  = str(ep_no),
            ep_title = ep_title,
        )

        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

 



# --------------------------------------------------------------------------- #
def _ws_search(term: str | None = None) -> None:
    """
    Rychlé vyhledání jen na Webshare (bez TMDb).

    • Každý dotaz má vlastní .log soubor  
    • Vyhledává SearchEngine.search_one()  
    • Průběžné GUI: DialogProgress (search / probe)
    """
    # ── 1) Vstup --------------------------------------------------------
    if not term:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        term = (args.get("q", [""])[0] or "").strip()
        if not term:
            term = _keyboard_input("Hledat na Webshare")
            if not term:
                return
    term = term.strip()
    _add_to_history(term)

    # ── 2) **PER-SEARCH LOG** -----------------------------------------
    global _SEARCH_LOG_PATH
    log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
    if not xbmcvfs.exists(log_dir):
        xbmcvfs.mkdirs(log_dir)

    ts   = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    safe = re.sub(r"[^0-9A-Za-z]+", "_", term)[:50]
    _SEARCH_LOG_PATH = os.path.join(log_dir, f"{ts}_{safe}.log")
    _log_event("SEARCH_BEGIN", term)

    # ── 3) Vyhledání ----------------------------------------------------
    prog = _SearchProgress()
    try:
        rels = _ENGINE.search_one(term, progress_cb=prog)
    except APIError as e:
        prog.close()
        _modal(f"Chyba Webshare: {e}")
        _log_event("SEARCH_END", term, "ERR")
        _SEARCH_LOG_PATH = ""
        return
    finally:
        prog.close()

    if not rels:
        _modal("Nic nenalezeno.")
        _log_event("SEARCH_END", term, 0)
        _SEARCH_LOG_PATH = ""
        return

    # ── 4) GUI ---------------------------------------------------------
    xbmcplugin.setPluginCategory(HANDLE, f"Výsledky: {term}")
    xbmcplugin.setContent(HANDLE, "videos")
    for r in rels:
        xbmcplugin.addDirectoryItem(HANDLE, *_build_stream_li(r))
    xbmcplugin.endOfDirectory(HANDLE)

    # ── 5) END + reset cesty -------------------------------------------
    _log_event("SEARCH_END", term, len(rels))
    _SEARCH_LOG_PATH = ""
# --------------------------------------------------------------------------- #







# 2025-08-14 19:22 CEST (Europe/Prague) – _play(): zachována původní logika přehrání + doplněn zápis do „Historie sledování“ (filmy / epizody)
def _play(ident: str) -> None:
    """
    Přehrání souboru z Webshare se zachováním původní logiky:
      • získání přímého odkazu přes Webshare API,
      • sestavení ListItem včetně InfoTagů (title/year pro filmy; tvshow/season/episode pro epizody),
      • předání délky videa (pokud je k dispozici) do InfoTagů a property „richmovie.duration“,
      • volání xbmcplugin.setResolvedUrl(HANDLE, True, li).

    NOVĚ:
      • Po úspěšném setResolvedUrl() zapíšu záznam do „Historie sledování“:
          – FILM  → _watch_add_movie(tmdb_id, title, year)
          – EPIZODA → _watch_add_episode(tv_id, tv_name, season, episode, ep_title)

    Vstupní parametry z query (jsou volitelné; pokud chybí, historie se prostě nezapíše):
      • Filmy:  m_title, m_year, tmdb
      • Seriály: tv_id, tv_name, season, episode, ep_title
    """
    # ──────────────────────────────────────────────────────────────────────
    # 1) PARAMS Z URL (bezpečně a tolerantně)
    # ──────────────────────────────────────────────────────────────────────
    args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

    # TV kontext
    tv_name   = (args.get("tv_name", [""])[0] or "").strip()
    season_no = 0
    episode_no = 0
    try:
        season_no  = int((args.get("season")  or ["0"])[0])
        episode_no = int((args.get("episode") or ["0"])[0])
    except Exception:
        season_no = episode_no = 0
    ep_title = (args.get("ep_title", [""])[0] or "").strip()
    tv_id    = args.get("tv_id", [""])[0]

    # Movie kontext
    m_title = (args.get("m_title", [""])[0] or "").strip()
    try:
        m_year = int((args.get("m_year") or ["0"])[0])
    except Exception:
        m_year = 0
    try:
        m_tmdb = int((args.get("tmdb") or ["0"])[0])
    except Exception:
        m_tmdb = 0

    # ──────────────────────────────────────────────────────────────────────
    # 2) VYŽÁDÁNÍ ODKAZU A INFO Z WEBSHARE (ZACHOVÁNO)
    # ──────────────────────────────────────────────────────────────────────
    try:
        ws    = _client()
        url   = ws.file_link(ident)
        finfo = ws.file_info(ident)               # rychlé REST volání
        vid_len = int(finfo.get("video_length") or 0)  # v sekundách (0, pokud chybí)
    except APIError as e:
        _modal(f"Přehrání selhalo: {e}")
        return

    # ──────────────────────────────────────────────────────────────────────
    # 3) SESTAVENÍ ListItem + INFOTAGY (ZACHOVÁNO)
    # ──────────────────────────────────────────────────────────────────────
    li = xbmcgui.ListItem(path=url)

    info_tags: Dict[str, Any] = {}
    if tv_name and season_no and episode_no:
        # Epizoda seriálu
        info_tags.update({
            "title":        ep_title or f"{tv_name} S{season_no:02d}E{episode_no:02d}",
            "tvshowtitle":  tv_name,
            "season":       season_no,
            "episode":      episode_no,
            "mediatype":    "episode",
        })
        # Pomocné vlastnosti pro NextUp / vlastní logiku
        li.setProperty("richmovie.tv_id",   str(tv_id))
        li.setProperty("richmovie.season",  str(season_no))
        li.setProperty("richmovie.episode", str(episode_no))
    else:
        # Film (pokud máme aspoň název)
        if m_title:
            info_tags.update({
                "title":     m_title,
                "mediatype": "movie",
            })
            if m_year:
                info_tags["year"] = m_year

    if vid_len > 0:
        info_tags["duration"] = vid_len
        info_tags["runtime"]  = max(1, vid_len // 60)
        li.setProperty("richmovie.duration", str(vid_len))

    if info_tags:
        li.setInfo("video", info_tags)

    # ──────────────────────────────────────────────────────────────────────
    # 4) RESOLVE – spuštění přehrávání (ZACHOVÁNO)
    # ──────────────────────────────────────────────────────────────────────
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

    # ──────────────────────────────────────────────────────────────────────
    # 5) ZÁPIS DO HISTORIE SLEDOVÁNÍ (NOVÉ, FAIL‑SAFE)
    # ──────────────────────────────────────────────────────────────────────
    try:
        if tv_name and season_no and episode_no:
            # Epizoda
            _watch_add_episode(
                tv_id     = int(tv_id) if str(tv_id).isdigit() else tv_id,
                tv_name   = tv_name,
                season    = season_no,
                episode   = episode_no,
                ep_title  = ep_title,
            )
            _log_event("WATCH_EP", tv_id, season_no, episode_no, tv_name)
        elif m_title or m_tmdb:
            # Film (stačí TMDb ID nebo název)
            _watch_add_movie(
                tmdb_id = m_tmdb if m_tmdb else None,
                title   = m_title,
                year    = m_year or None,
            )
            _log_event("WATCH_MOVIE", m_tmdb or "-", m_title, m_year or "-")
        # pokud chybí všechny kontextové parametry, jen nic nelogujeme
    except Exception:
        # Historie je „best effort“ – nesmí shodit přehrávání
        pass



# 2025-08-21 22:49 CEST (Europe/Prague) – ENTRY-POINT: doplněn alias 'ai_recommend' → _ai_menu; zachovány všechny větve
if __name__ == "__main__":
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get("action", ["root"])[0]

    if action == "root":
        _root()

    # — FILMY —
    elif action == "movie_search":
        _movie_search()

    # — SERIÁLY —
    elif action == "tv_search":
        _tv_search()
    elif action == "tv_seasons":
        _tv_seasons()
    elif action == "tv_episodes":
        _tv_episodes()
    elif action == "tv_play":
        _tv_play()

    # — RICHMOVIE A.I. —  (alias pro starší odkazy i hlavní menu)
    elif action in ("ai_menu", "ai_recommend"):
        _ai_menu()

    # — WEBSHARE / HISTORIE —
    elif action == "ws_search":
        _ws_search()
    elif action == "history":
        _show_history()
    elif action == "watch_history":
        _watch_history()

    # — KOLEKCE —
    elif action == "collections":
        CollectionsUI.show_collections_root(ADDON, HANDLE)
    elif action == "collections_browse":
        CollectionsUI.browse_collection(params.get("file", [""])[0], ADDON, HANDLE)
    elif action == "collections_tv":
        CollectionsUI.browse_tv(
            params.get("file", [""])[0],
            params.get("tv_id", [""])[0],
            params.get("tv_name", [""])[0],
            ADDON,
            HANDLE
        )

    # — TMDb —
    elif action == "tmdb_trending_movie" or action == "tmdb_trending":
        _tmdb_trending()
    elif action == "tmdb_top_movie" or action == "tmdb_top":
        _tmdb_top()
    elif action in ("tmdb_tv_trending", "tmdb_trending_tv"):
        _tmdb_tv_trending()
    elif action in ("tmdb_tv_top", "tmdb_top_tv"):
        _tmdb_tv_top()
    elif action == "tmdb_genres":
        _tmdb_genres()
    elif action == "tmdb_genre":
        try:
            _tmdb_genre_movies(int(params.get("genre_id", ["0"])[0]))
        except ValueError:
            xbmc.log("[RichMovie] Invalid genre_id", xbmc.LOGERROR)

    # — AUTO z feedů —
    elif action == "auto":
        try:
            _auto_search_movie(int(params.get("tmdb", ["0"])[0]))
        except ValueError:
            xbmc.log("[RichMovie] Invalid tmdb id", xbmc.LOGERROR)

    # — SOSÁČ —
    elif action == "sosac_search":
        _sosac_search(params.get("kind", ["movie"])[0])
    elif action == "sosac_play":
        _sosac_play(params.get("vid", [""])[0])

    # — PŘEHRÁNÍ / DETAIL —
    elif action == "play":
        _play(params.get("ident", [""])[0])
    elif action == "detail":
        _stream_detail(params.get("ident", [""])[0])

    # — STAHOVÁNÍ —
    elif action == "download":
        _download_stream()

    # — UTILITY —
    elif action == "clear_logs":
        _clear_logs()
    elif action == "reset_settings":
        _reset_settings()
    elif action == "ai_edit_key":
        _ai_edit_key_action()

    else:
        xbmc.log(f"[RichMovie] Unknown action {action}", xbmc.LOGERROR)
