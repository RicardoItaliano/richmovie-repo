# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Správce stahování (fronta + GUI)
───────────────────────────────────────────────────────────────────────────────
• Kontextové menu „Stáhnout stream…“ pro každý release
• „Uložit jako…“ (volba složky + jméno souboru)
• Průběh: rychlost, % staženo, MB/GB, ETA, možnost přepnout „na pozadí“ nebo „zrušit“
• Fronta: v jednu chvíli běží pouze **1 stahování**, další čekají
• Background režim: toast každé +1 % („p/100 · soubor i/n · ETA“)

Autor: Vývoj · RichMovie
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY  (ABECEDNĚ + tematické skupiny)
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

# — Standardní knihovny —
import contextlib
import dataclasses
import datetime
import math
import os
import re
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Deque, Optional, Tuple

# — 3rd‑party —
import requests

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin  # noqa: F401 (pouze pro typovou návaznost v doplňku)
import xbmcvfs

# — Lokální / projektové —
from richmovie_webshare import WebshareClient, APIError  # typy + chybové stavy
import plugin as _plg_mod  # kvůli sdílenému _SESSION a loggeru (_log_event)

# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY + GLOBÁLNÍ OBJEKTY
# ─────────────────────────────────────────────────────────────────────────────
_ADDON = xbmcaddon.Addon()
_ADDON_ID = _ADDON.getAddonInfo("id")

# bezpečné velikosti bufferu
_CHUNK_SIZE = 1024 * 1024        # 1 MB blok
_SPEED_WINDOW = 3.0              # průměrovací okno pro rychlost (s)

# ikony pro notifikace
_ICON_INFO = xbmcgui.NOTIFICATION_INFO
_ICON_ERR  = xbmcgui.NOTIFICATION_ERROR

# ─────────────────────────────────────────────────────────────────────────────
#  POMOCNÉ FUNKCE (formátování / sanitizace)
# ─────────────────────────────────────────────────────────────────────────────

def _ts_now_prg() -> str:
    """
    2025-08-19 14:43 CEST (Europe/Prague) – aktuální razítko pro log/debug.
    """
    # Pozn.: Zapisujeme fixně CEST/CET textem, protože Kodi běží lokálně;
    # v GUI potřebujeme jen lidsky srozumitelné razítko.
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M") + " CEST (Europe/Prague)"


def _fmt_bytes(n: int) -> str:
    """
    2025-08-19 14:43 CEST (Europe/Prague)
    Převod bajtů na lidsky čitelné jednotky (MB/GB s jedním desetinným místem).
    """
    if n < 1024:
        return f"{n} B"
    if n < 1024**2:
        return f"{n/1024:.1f} kB"
    if n < 1024**3:
        return f"{n/1024/1024:.1f} MB"
    return f"{n/1024/1024/1024:.2f} GB"


def _fmt_speed(bps: float) -> str:
    """
    2025-08-19 14:43 CEST (Europe/Prague)
    Rychlost ve tvaru „x.xx MB/s“.
    """
    if bps <= 0:
        return "0 MB/s"
    return f"{bps/1024/1024:.2f} MB/s"


def _fmt_eta(seconds: float) -> str:
    """
    2025-08-19 14:43 CEST (Europe/Prague)
    Zbývající čas ve formátu H:MM:SS (bez hodin, pokud < 1 h).
    """
    if seconds < 0 or math.isinf(seconds) or math.isnan(seconds):
        return "?"
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, s = divmod(rem, 60)
    return f"{h:d}:{m:02d}:{s:02d}" if h else f"{m:d}:{s:02d}"


def _sanitize_filename(name: str) -> str:
    """
    2025-08-19 14:43 CEST (Europe/Prague)
    Odstraní zakázané znaky pro běžné FS (Windows/Unix/Android).
    """
    name = name.strip().replace("\n", " ").replace("\r", " ")
    name = re.sub(r'[<>:"/\\|?*]+', "_", name)
    name = re.sub(r"\s+", " ", name)
    return name or "video"


def _notif(msg: str, icon=_ICON_INFO, time_ms: int = 2500) -> None:
    """
    2025-08-19 14:43 CEST (Europe/Prague)
    Jednotný toast (fallback, když nechceme používat plugin._modal()).
    """
    try:
        xbmcgui.Dialog().notification("RichMovie", msg, icon, time_ms)
    except Exception:
        xbmc.log(f"[RichMovie/Downloads] NOTIF_FAIL: {msg}", xbmc.LOGWARNING)


# ─────────────────────────────────────────────────────────────────────────────
#  DATOVÉ TYPY
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class DownloadJob:
    """
    2025-08-19 14:43 CEST (Europe/Prague)
    Popis jedné položky ke stažení (immutable metadata + runtime stav).
    """
    ident: str
    url: str
    name: str
    total: int
    dest_path: str
    created_at: float = field(default_factory=time.time)

    # runtime
    background: bool = False
    canceled: bool = False

    # vnitřní metriky (průběžně aktualizované)
    downloaded: int = 0
    last_percent: int = -1
    started_at: float = 0.0


# ─────────────────────────────────────────────────────────────────────────────
#  SPRÁVCE STAŽENÍ – SINGLETON
# ─────────────────────────────────────────────────────────────────────────────

class DownloadManager:
    """
    2025-08-19 14:43 CEST (Europe/Prague)
    Fronta stahování: v jeden okamžik běží přesně 1 download; ostatní čekají.

    • enqueue() přidá do fronty (první spustí)
    • přepnutí do pozadí → toasty každé +1 %
    • možnost Zrušit (odstraní .part)
    """

    _instance_lock = threading.Lock()
    _instance: Optional["DownloadManager"] = None

    @classmethod
    def instance(cls) -> "DownloadManager":
        """
        2025-08-19 14:43 CEST (Europe/Prague)
        Přístup k singletonu.
        """
        with cls._instance_lock:
            if not cls._instance:
                cls._instance = cls()
        return cls._instance

    def __init__(self) -> None:
        """
        2025-08-19 14:43 CEST (Europe/Prague)
        Inicializace prázdné fronty + synchronizační objekty.
        """
        self._q: Deque[DownloadJob] = deque()
        self._worker: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._stop = False
        self._progress: Optional[xbmcgui.DialogProgress] = None
        self._completed = 0  # kolik položek již doběhlo v rámci aktuální session

    # ------------------------------------------------------------------ #
    def enqueue(self, job: DownloadJob, show_dialog: bool) -> None:
        """
        2025-08-19 14:43 CEST (Europe/Prague)
        Vloží job do fronty a spustí worker, pokud neběží.

        • show_dialog=True → u *aktuálně* spouštěného jobu zobraz Progress okno.
        """
        with self._lock:
            self._q.append(job)
            queue_pos = len(self._q)
            total_in_batch = self._completed + len(self._q)
            _plg_mod._log_event("DL_ENQUEUE", job.ident, queue_pos, total_in_batch)

            if self._worker is None or not self._worker.is_alive():
                # první v pořadí → vytvoř dialog (pokud je žádán)
                first = self._q[0]
                if show_dialog:
                    self._progress = xbmcgui.DialogProgress()
                    self._progress.create("Stahování...", "Připravuji…")
                    first.background = False
                else:
                    first.background = True

                self._worker = threading.Thread(target=self._worker_loop, name="RichMovie-DL", daemon=True)
                self._worker.start()
            else:
                # běží jiný → info toast
                _notif(f"Zařazeno do fronty (#{total_in_batch}).")

    # ------------------------------------------------------------------ #
    def _worker_loop(self) -> None:
        """
        2025-08-19 14:43 CEST (Europe/Prague)
        Hlavní smyčka: vytahuje joby z fronty a zpracovává je sekvenčně.
        """
        while True:
            with self._lock:
                if not self._q or self._stop:
                    # úklid dialogu, pokud zůstal viset
                    if self._progress:
                        try:
                            self._progress.close()
                        except Exception:
                            pass
                        self._progress = None
                    self._worker = None
                    return
                job = self._q[0]

            try:
                self._download_one(job)
                # úspěch → posun ve frontě
                with self._lock:
                    self._q.popleft()
                    self._completed += 1
            except Exception as e:
                # fatální chyba → log + odstraň z fronty
                with self._lock:
                    try:
                        self._q.popleft()
                    except Exception:
                        pass
                _plg_mod._log_event("DL_FAIL", job.ident, str(e))
                _notif(f"Chyba stahování: {e}", _ICON_ERR, 4000)

    # ------------------------------------------------------------------ #
    def _download_one(self, job: DownloadJob) -> None:
        """
        2025-08-19 14:43 CEST (Europe/Prague)
        Vlastní stažení do „*.part“ s průběhem; po dokončení rename → cílový soubor.

        • Cancel v dialogu → dotaz: „Zrušit“ vs. „Na pozadí“
        • Background → pouze toast při každém +1 %
        """
        # příprava cest
        dest_vfs = job.dest_path
        dest_tmp = dest_vfs + ".part"

        # vytvoř cíl. složku (bez pádu)
        ddir = os.path.dirname(xbmcvfs.translatePath(dest_vfs))
        try:
            if ddir and not xbmcvfs.exists(ddir):
                xbmcvfs.mkdirs(ddir)
        except Exception:
            pass

        # UI – základní údaje o pořadí (i/n)
        with self._lock:
            total_in_batch = self._completed + len(self._q)
            index_now = self._completed + 1  # právě běžící = první ve frontě

        # měření rychlosti (klouzavé okno)
        job.started_at = time.time()
        window: Deque[Tuple[float, int]] = deque()  # (timestamp, bytes_downloaded_total)

        # HTTP: stream
        with requests.get(job.url, stream=True, timeout=30) as resp:
            resp.raise_for_status()
            # fallback na Content-Length, pokud file_info bylo 0
            total = job.total or int(resp.headers.get("Content-Length", "0") or 0)
            if total:
                job.total = total

            # otevři výstup
            f = xbmcvfs.File(dest_tmp, "wb")
            try:
                for chunk in resp.iter_content(chunk_size=_CHUNK_SIZE):
                    if not chunk:
                        continue
                    if job.canceled:
                        break

                    # zápis + metriky
                    try:
                        f.write(chunk)
                    except TypeError:
                        # některé boxy očekávají str → dekódovat latin-1 beze ztrát
                        f.write(chunk.decode("latin-1"))
                    job.downloaded += len(chunk)

                    # rychlost – klouzavé okno
                    now = time.time()
                    window.append((now, job.downloaded))
                    while window and (now - window[0][0]) > _SPEED_WINDOW:
                        window.popleft()

                    bps = 0.0
                    if len(window) >= 2:
                        dt = (window[-1][0] - window[0][0]) or 1e-6
                        db = (window[-1][1] - window[0][1])
                        bps = max(0.0, db / dt)

                    # procenta/ETA
                    pct = int(job.downloaded * 100 / job.total) if job.total else 0
                    rem = (job.total - job.downloaded) if job.total else 0
                    eta = rem / bps if (bps > 0 and rem > 0) else float("inf")

                    # GUI – background vs dialog
                    if job.background:
                        if pct != job.last_percent and pct % 1 == 0:
                            job.last_percent = pct
                            msg = f"{pct}% · {index_now}/{total_in_batch} · zbývá { _fmt_eta(eta) }"
                            _notif(msg)
                        continue

                    # interaktivní dialog
                    if self._progress:
                        line1 = f"[B]{_sanitize_filename(job.name)}[/B]"
                        line2 = f"Rychlost: {_fmt_speed(bps)} · Staženo: {_fmt_bytes(job.downloaded)}/{_fmt_bytes(job.total)}"
                        line3 = f"Zbývá: {_fmt_eta(eta)} · Soubor {index_now}/{total_in_batch}"
                        self._progress.update(pct, f"{line1}\n{line2}\n{line3}")


                        if self._progress.iscanceled():
                            # nabídni: Zrušit vs Na pozadí
                            yes = xbmcgui.Dialog().yesno(
                                "Stahování",
                                "Chcete stahování [B]zrušit[/B]?\n\nZvolte [B]Ne[/B] pro pokračování [B]na pozadí[/B].",
                                yeslabel="Zrušit",
                                nolabel="Na pozadí",
                            )
                            if yes:
                                job.canceled = True
                                break
                            else:
                                # přepnout do pozadí
                                try:
                                    self._progress.close()
                                except Exception:
                                    pass
                                self._progress = None
                                job.background = True
                                _notif(f"Pokračuji na pozadí… ({index_now}/{total_in_batch})")

                # konec smyčky
            finally:
                try:
                    f.close()
                except Exception:
                    pass

        # rozhodnutí podle stavu
        if job.canceled:
            try:
                if xbmcvfs.exists(dest_tmp):
                    xbmcvfs.delete(dest_tmp)
            except Exception:
                pass
            _plg_mod._log_event("DL_CANCEL", job.ident, _ts_now_prg())
            _notif("Stahování zrušeno.", _ICON_INFO)
            return

        # přejmenuj .part → cílový soubor
        try:
            if xbmcvfs.exists(job.dest_path):
                xbmcvfs.delete(job.dest_path)
            # některé FS neumí rename přes hranici FS – v takovém případě kopie
            if not xbmcvfs.rename(dest_tmp, job.dest_path):
                xbmcvfs.copy(dest_tmp, job.dest_path)
                xbmcvfs.delete(dest_tmp)
        except Exception as e:
            _plg_mod._log_event("DL_RENAME_FAIL", job.ident, str(e))
            _notif(f"Chyba při ukládání: {e}", _ICON_ERR, 4000)
            return

        # finální oznámení
        base = os.path.basename(job.dest_path)
        _plg_mod._log_event("DL_DONE", job.ident, base, _ts_now_prg())
        _notif(f"Uloženo: {base}", _ICON_INFO, 3000)

    # ------------------------------------------------------------------ #
    def open_save_dialog(self, default_name: str) -> Optional[str]:
        """
        2025-08-19 14:43 CEST (Europe/Prague)
        Interaktivní „Uložit jako…“ (vybere složku a jméno souboru). Vrací
        plnou VFS cestu, nebo None při zrušení.
        """
        dlg = xbmcgui.Dialog()

        # 1) vyber složku
        # type=3 → adresáře; shares="files" pro obecné FS
        out_dir = dlg.browse(3, "Vyber složku pro uložení", "files")
        if not out_dir:
            return None

        # 2) uprav název
        safe = _sanitize_filename(default_name)
        if not safe.lower().endswith((".mkv", ".mp4", ".avi", ".m4v", ".ts", ".mpg")):
            # default koncovka – pokud ji Webshare jménem nedodal
            safe += ".mkv"

        kb = xbmc.Keyboard(safe, "Název souboru")
        kb.doModal()
        if not kb.isConfirmed():
            return None
        fname = _sanitize_filename(kb.getText() or safe)

        # 3) složka + název → výsledná cesta
        if out_dir.endswith("/") or out_dir.endswith("\\"):
            dest = out_dir + fname
        else:
            dest = out_dir + ("/" if "/" in out_dir else "\\") + fname

        # kolize
        if xbmcvfs.exists(dest):
            overwrite = dlg.yesno("Uložit soubor", f"Soubor [B]{fname}[/B] již existuje.\nPřepsat?", yeslabel="Přepsat", nolabel="Zrušit")
            if not overwrite:
                return None

        return dest


# ─────────────────────────────────────────────────────────────────────────────
#  VEŘEJNÉ VSTUPNÍ API MODULU
# ─────────────────────────────────────────────────────────────────────────────



def start_download_from_gui(ident: str, name: str = "", **meta) -> None:
    """
    [Aktualizováno: 2025-08-21 23:40 CEST (Europe/Prague)]
    Interaktivní stažení jednoho souboru z Webshare s kvalitní GUI prezentací.

    Změny v této verzi:
    • V režimu na pozadí jsou vypnuté průběžné toasty (dříve “po 1 %” s cooldownem).
    • Zůstává pouze závěrečný toast po dokončení (a toast při zrušení).
    • Zachováno: hlavička dialogu (film/seriál + rok + epizoda), 1×/s refresh UI, přesný název
      souboru převzatý z Webshare, výběr složky od rootu a pamatování poslední složky.
    """
    # 1) Webshare klient (preferuj sdílený session z pluginu, jinak vytvoř nový)
    ws: WebshareClient | None = None
    try:
        if hasattr(_plg_mod, "_SESSION") and getattr(_plg_mod._SESSION, "client", None):
            ws = _plg_mod._SESSION.client  # typ: WebshareClient
    except Exception:
        ws = None
    if not isinstance(ws, WebshareClient):
        ws = WebshareClient(xbmcaddon.Addon().getSetting("token") or None)

    # 2) URL a přesný název souboru
    try:
        url = ws.file_link(ident, download_type=None)  # standardní download link
        finfo = ws.file_info(ident) or {}
    except APIError as e:
        xbmcgui.Dialog().ok("Stahování selhalo", str(e))
        return

    remote_name = (finfo.get("name") or name or ident).strip()
    safe_name   = _sanitize_filename(remote_name)
    total_size  = int(finfo.get("size") or 0)

    # 3) cílová složka – od rootu + pamatovat poslední
    _ADDON = xbmcaddon.Addon()
    last_dir = _ADDON.getSetting("last_download_dir").strip()
    # type=0 (adresář), shares="files" → root zařízení/sdílení; defaultt = poslední složka (pokud je)
    target_dir = xbmcgui.Dialog().browse(0, "Vyber cílovou složku", "files", "", False, False, last_dir or "")
    if not target_dir:
        return
    if not target_dir.endswith(("/", "\\")):
        target_dir += "/"
    try:
        _ADDON.setSetting("last_download_dir", target_dir)
    except Exception:
        pass

    target_path = target_dir + safe_name
    if xbmcvfs.exists(target_path):
        if not xbmcgui.Dialog().yesno("Soubor existuje", f"Přepsat '{safe_name}'?", nolabel="Ne", yeslabel="Ano"):
            return
        with contextlib.suppress(Exception):
            xbmcvfs.delete(target_path)

    # 4) hlavička dialogu (film/seriál + rok + epizoda)
    def _make_heading(m: dict) -> str:
        title = (m.get("tv_name") or m.get("m_title") or "").strip()
        year  = (m.get("m_year") or "").strip()
        ep    = (m.get("ep_title") or "").strip()
        s_no  = m.get("season")
        e_no  = m.get("episode")
        parts = []
        if title:
            parts.append(title)
        if year:
            parts[-1] = f"{parts[-1]} ({year})"
        if ep:
            parts.append(ep)
        if isinstance(s_no, int) and isinstance(e_no, int) and s_no and e_no:
            parts.append(f"S{s_no:02d}E{e_no:02d}")
        return " — ".join(parts) if parts else "Stahování"

    heading = _make_heading(meta)

    # 5) dialog (foreground) + možnost přejít na pozadí
    dlg = xbmcgui.DialogProgress()
    dlg.create(heading, safe_name)

    to_background = False
    bg: xbmcgui.DialogProgressBG | None = None

    # stav pro řízení refreshu
    last_pct   = -1
    next_ui_ts = 0.0

    # měření rychlosti – delší klouzavé okno pro stabilní ETA
    window: Deque[Tuple[float, int]] = deque()
    SPEED_WINDOW = 8.0  # s

    # 6) HTTP stream + zápis
    tmp_path = target_path + ".part"
    try:
        with requests.get(url, stream=True, timeout=30) as resp:
            resp.raise_for_status()
            if total_size <= 0:
                try:
                    total_size = int(resp.headers.get("Content-Length") or 0)
                except Exception:
                    total_size = 0

            f = xbmcvfs.File(tmp_path, "wb")
            try:
                downloaded = 0
                for chunk in resp.iter_content(chunk_size=1024 * 1024):  # 1 MB blok
                    if not chunk:
                        continue
                    # zápis
                    try:
                        f.write(chunk)
                    except Exception as werr:
                        raise RuntimeError(f"Zápis na disk selhal: {werr}")

                    # metriky
                    downloaded += len(chunk)
                    now = time.time()
                    window.append((now, downloaded))
                    while window and (now - window[0][0]) > SPEED_WINDOW:
                        window.popleft()

                    # rychlost
                    bps = 0.0
                    if len(window) >= 2:
                        dt = (window[-1][0] - window[0][0]) or 1e-6
                        db = (window[-1][1] - window[0][1])
                        bps = max(0.0, db / dt)

                    # procenta/ETA
                    pct = int(downloaded * 100 / total_size) if total_size > 0 else 0
                    remain = max(0, total_size - downloaded) if total_size > 0 else 0
                    eta_s = int(remain / bps) if (bps > 0 and remain > 0) else 0

                    # GUI refresh max. 1×/s nebo při změně %
                    if now >= next_ui_ts or pct != last_pct:
                        next_ui_ts = now + 1.0
                        last_pct = pct

                        line2 = f"Rychlost: {_fmt_speed(bps)} · Staženo: {_fmt_bytes(downloaded)}/{_fmt_bytes(total_size or downloaded)}"
                        line3 = f"Zbývá: {_fmt_eta(eta_s) if eta_s else '--:--'}"

                        if not to_background:
                            # foreground dialog – první řádek = přesný název souboru
                            dlg.update(pct, f"[B]{safe_name}[/B]\n{line2}\n{line3}")

                            if dlg.iscanceled():
                                # nabídni: Zrušit vs Na pozadí
                                go_bg = xbmcgui.Dialog().yesno(
                                    "Stahování",
                                    "Chceš pokračovat na pozadí?",
                                    nolabel="Zrušit",
                                    yeslabel="Na pozadí",
                                )
                                if not go_bg:
                                    raise KeyboardInterrupt("Uživatel zrušil stahování")
                                to_background = True
                                with contextlib.suppress(Exception):
                                    dlg.close()
                                bg = xbmcgui.DialogProgressBG()
                                bg.create(heading, safe_name)
                                next_ui_ts = 0.0  # vynutit okamžitý update
                        else:
                            # background – pouze tichý BG update (Kodi samo ukazuje % vpravo nahoře)
                            if bg:
                                msg = f"{pct}% · {_fmt_speed(bps)} · {_fmt_bytes(downloaded)}/{_fmt_bytes(total_size or downloaded)} · ETA {_fmt_eta(eta_s) if eta_s else '--:--'}"
                                bg.update(pct, heading=heading, message=msg)
                # konec smyčky
            finally:
                with contextlib.suppress(Exception):
                    f.close()

        # 7) přejmenuj .part → cílový soubor (s fallbackem pro FS bez rename)
        try:
            if xbmcvfs.exists(target_path):
                xbmcvfs.delete(target_path)
            if not xbmcvfs.rename(tmp_path, target_path):
                src = xbmcvfs.File(tmp_path, "rb")
                dst = xbmcvfs.File(target_path, "wb")
                try:
                    while True:
                        buf = src.read(1024 * 1024)
                        if not buf:
                            break
                        dst.write(buf)
                finally:
                    with contextlib.suppress(Exception):
                        src.close()
                    with contextlib.suppress(Exception):
                        dst.close()
                    with contextlib.suppress(Exception):
                        xbmcvfs.delete(tmp_path)
        except Exception as rr:
            with contextlib.suppress(Exception):
                if xbmcvfs.exists(tmp_path):
                    xbmcvfs.delete(tmp_path)
            raise RuntimeError(f"Přejmenování souboru selhalo: {rr}")

        # 8) finální UI – závěrečný toast vždy (FG i BG)
        if to_background:
            with contextlib.suppress(Exception):
                if bg:
                    bg.close()
        else:
            with contextlib.suppress(Exception):
                dlg.update(100, f"[B]{safe_name}[/B]\nDokončeno.")
                time.sleep(0.2)
                dlg.close()

        xbmcgui.Dialog().notification("RichMovie", f"Staženo: {safe_name}", xbmcgui.NOTIFICATION_INFO, 4000)

    except KeyboardInterrupt:
        # uživatel zrušil stahování
        with contextlib.suppress(Exception):
            if bg:
                bg.close()
        with contextlib.suppress(Exception):
            dlg.close()
        with contextlib.suppress(Exception):
            if xbmcvfs.exists(tmp_path):
                xbmcvfs.delete(tmp_path)
        xbmcgui.Dialog().notification("RichMovie", "Stahování zrušeno.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    except Exception as e:
        # jiná chyba
        with contextlib.suppress(Exception):
            if bg:
                bg.close()
        with contextlib.suppress(Exception):
            dlg.close()
        with contextlib.suppress(Exception):
            if xbmcvfs.exists(tmp_path):
                xbmcvfs.delete(tmp_path)
        xbmcgui.Dialog().ok("Stahování selhalo", str(e))
        return

