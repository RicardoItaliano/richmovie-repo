# -*- coding: utf-8 -*-
"""richmovie_prefetched — přednačtené streamy filmu: klik v Trendech / ČSFD TV tipech = seznam streamů HNED (P15, 14.11.2026).

PROČ
----
Richie 14.11.2026: „až bude všechno hotovo a streamy budou přednačteny, budeme dělat push. Teď jsem zkoušel trendy asi pátý
film a stejně to spouštělo okno hledání místo toho, aby se streamy zobrazilo rovnou.“ Gate v noci prohledá Trendy a ČSFD TV
tipy STEJNÝM jádrem `rm_core` a STEJNOU kaskádou jako doplněk a u filmů, které jdou pustit, uloží přijaté streamy
(`asdict(Release)` sady Webshare + SkTorrent, `trendy_streams`, mig 0058).

P16 (Richie 14.11.2026 po testu: „je na hovno vidět streamy, u kterých neznáme dabing … mi2 kompletní aby se nerefreshovalo
a hned zobrazil až po dokončení streamy seřazené“): po kliknutí doplněk spustí MediaInfo snímku HNED (náskok), v popředí
BĚŽNÉ hledání účtem zařízení (Fastshare, čerstvé soubory → `SEARCH_CACHE`), pak MediaInfo VŠECH streamů a vykreslí JEDNOU
— seřazené, bez pozdější obnovy; okno průběhu jen, když to trvá (`LazyProgress`). Pravidlo „nikdy méně streamů“ (Richie
29.09.2026): úplné hledání = konečný výpis; neúplné = snímek + ověření na pozadí (`run_verify`) jako pojistka.

KONTRAKT (Gate `app/trendy/router.py` `streams`)
-----------------------------------------------
    POST /v1/tmdb/streams   tělo = identita (`identity_body`) + {"kind": "movie", "tmdb_id": int}
    200 {"status": "ok", "core": "<verze>+<otisk>", "wave": "P"|"ALT", "computed_at": "<iso>", "releases": [asdict(Release)…]}
      | {"status": "none", "core": …}
Cokoli jiného (síť, 4xx, 5xx, 429, jiný tvar, pomalá odpověď, jiné jádro, nečitelný záznam) = žádný snímek = dnešní
cesta s oknem hledání (R2: chyba se nikam neukládá). Záznamy převádí SSOT `rm_core.model.releases_from_records`
(tentýž převod jako `SEARCH_CACHE`); jediný nečitelný záznam = žádný snímek (z výpisu by jinak tiše zmizel stream).

PAMĚŤ RELACE
------------
Jen po NEÚPLNÉM hledání (P16): snímek se drží ve vlastnosti okna Kodi (Window 10000, `richmovie_winprops`) po dobu
`SESSION_TTL_S` — obnova výpisu od MI2 a návrat Zpět jdou znovu přes `action=auto` (cesta návratu) a vykreslí ho bez sítě.
Ověření na pozadí ho po úspěchu SMAŽE (`forget`) — další návrat jde dnešní cestou přes `SEARCH_CACHE`. Na disk nic.

OVĚŘENÍ NA POZADÍ (pojistka po neúplném hledání)
------------------------------------------------
`run_verify` (vlákno pluginu) = běžné hledání → `verify_decision` → `forget` / `refresh_listing`. Obnova výpisu z pozadí žije
TADY, ne v `plugin.py` (lint scénáře 89: akce na klik v pluginu `background` nepředávají; pozadí = MI2, D11, toto ověření).

Modul je čistý kromě `fetch` (síť přes `richmovie_gate_transport`, lazy import), paměti relace (Window props) a ověření na
pozadí (lazy importy Kodi, brány obnov a měření aktivity diváka).
Python 3.8 (Kodi 21 Windows) — `from __future__ import annotations`, žádné `X | None` za běhu.
"""
from __future__ import annotations

import json
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

ENDPOINT = "/v1/tmdb/streams"            # pod prefixem tunelu `v1/tmdb` a v `_IDEMPOTENT_POST_PATHS` (čtení bez vedlejších účinků)
KIND_MOVIE = "movie"
WAVES = frozenset({"P", "ALT"})          # = Gate `store.STREAM_WAVES` = štítky vln `rm_core.cascade`
MAX_RELEASES = 1000                      # = Gate `settings.STREAMS_MAX_CEILING` (víc = vadná odpověď)

# Rozpočet: snímek je zrychlení, bez něj výpis funguje (dnešní cesta) → divák nesmí čekat. Timeout 2,5 s na pokus, celý
# dotaz nejvýš 3 s (rychlá chyba dostane druhý pokus, timeout ne); 429 se nikdy neopakuje (`richmovie_http`).
REQUEST_TIMEOUT_S = 2.5
REQUEST_BUDGET_S = 3.0
REQUEST_MAX_ATTEMPTS = 2

SESSION_TTL_S = 30 * 60                  # paměť relace: obnova od MI2 / Zpět během prohlížení výpisu
PROP_PREFIX = "richmovie.prefetched."
INDEX_PROP = PROP_PREFIX + "index"       # {id: čas uložení} pro úklid (ne číslo → nekoliduje s `prop_name`)
SESSION_MAX_FILMS = 40                   # nejvýš tolik snímků v paměti relace (nejstarší pryč)

REASON_OK = "ok"
REASON_NONE = "none"                     # Gate snímek nemá (nebo starý / jiné jádro na Gate / vypnuto)
REASON_INVALID = "invalid"
REASON_CORE = "core_mismatch"
REASON_RECORDS = "records"
REASON_NO_IDENTITY = "no_identity"
REASON_UNAVAILABLE = "unavailable"


class Snapshot(object):
    """Přednačtený výsledek hledání jednoho filmu: `releases` = `rm_core.model.Release` (pořadí ze serveru — výpis si
    pořadí počítá sám), `records` = původní záznamy (paměť relace)."""

    __slots__ = ("tmdb_id", "releases", "records", "wave", "computed_at", "core", "source")

    def __init__(self, tmdb_id: int, releases: List[Any], records: List[Dict[str, Any]], wave: str, computed_at: str,
                 core: str, source: str) -> None:
        self.tmdb_id = int(tmdb_id)
        self.releases = releases
        self.records = records
        self.wave = wave
        self.computed_at = computed_at
        self.core = core
        self.source = source              # "gate" (z odpovědi) | "session" (z paměti relace)


# ── čisté funkce ──────────────────────────────────────────────────────────────────────────────────────────────────────
def build_request(tmdb_id: Any) -> Dict[str, Any]:
    return {"kind": KIND_MOVIE, "tmdb_id": int(tmdb_id)}


def parse_response(status: Any, body: Any) -> Tuple[Optional[Dict[str, Any]], str]:
    """Přesný tvar odpovědi → (data, "ok") nebo (None, důvod). Data: core, wave, computed_at, records."""
    if type(status) is not int or status != 200 or not isinstance(body, dict):      # bool / float / text = vadný tvar
        return None, ("http_%s" % (status,) if type(status) is int and status != 200 else REASON_INVALID)
    st = body.get("status")
    if st == REASON_NONE:
        return None, REASON_NONE
    if st != "ok":
        return None, REASON_INVALID
    core, wave, computed, records = body.get("core"), body.get("wave"), body.get("computed_at"), body.get("releases")
    if not isinstance(core, str) or not core or wave not in WAVES or not isinstance(computed, str) or not computed:
        return None, REASON_INVALID
    if not isinstance(records, list) or not records or len(records) > MAX_RELEASES:
        return None, REASON_INVALID
    for rec in records:
        if not isinstance(rec, dict) or not isinstance(rec.get("ident"), str) or not rec.get("ident"):
            return None, REASON_INVALID
    return {"core": core, "wave": wave, "computed_at": computed, "records": records}, REASON_OK


def build_snapshot(tmdb_id: int, data: Dict[str, Any], *, local_core: Optional[Tuple[str, str]],
                   core_matches: Callable[[Any, Optional[Tuple[str, str]]], bool],
                   records_to_releases: Callable[[Any], Optional[List[Any]]], source: str) -> Tuple[Optional[Snapshot], str]:
    """Snímek pro výpis, nebo (None, důvod): jen STEJNÉ jádro jako toto zařízení a všechny záznamy čitelné."""
    if not core_matches(data.get("core"), local_core):
        return None, REASON_CORE
    rels = records_to_releases(data.get("records"))
    if not rels:
        return None, REASON_RECORDS
    return Snapshot(tmdb_id, rels, list(data["records"]), str(data["wave"]), str(data["computed_at"]), str(data["core"]),
                    source), REASON_OK


def same_idents(a: List[Any], b: List[Any]) -> bool:
    """Ukazuje výpis tytéž streamy? (identy bez ohledu na pořadí — pořadí počítá výpis na zařízení)."""
    return sorted(str(getattr(r, "ident", "")) for r in a) == sorted(str(getattr(r, "ident", "")) for r in b)


def new_idents(fresh: List[Any], snap_releases: List[Any]) -> int:
    """Kolik streamů čerstvé hledání našlo NAVÍC proti snímku (třeba Fastshare, nově nahrané soubory)."""
    known = {str(getattr(r, "ident", "")) for r in snap_releases}
    return len({str(getattr(r, "ident", "")) for r in fresh} - known)


VERIFY_KEEP = "keep"            # ověření neúplné: snímek zůstává v paměti relace, výpis beze změny
VERIFY_FORGET = "forget"        # úplné a stejné streamy: snímek pryč (návrat jde přes SEARCH_CACHE), výpis beze změny
VERIFY_REFRESH = "refresh"      # úplné a jiné streamy: snímek pryč + obnova výpisu (čerstvý výsledek z SEARCH_CACHE)


def verify_decision(rels: List[Any], authoritative: bool, info: Dict[str, Any], snap_releases: List[Any],
                    aborted: bool = False) -> str:
    """Co udělat po ověření na pozadí — čistá funkce. Neúplný výsledek (zrušeno, chyba vlny, 429, prázdno bez autority)
    snímek NENAHRADÍ (pravidlo „nikdy méně streamů“, R2); úplný ano a při jiných streamech se výpis obnoví."""
    if aborted or info.get("cancelled") or info.get("errors") or info.get("rate_limited"):
        return VERIFY_KEEP
    if not rels and not authoritative:
        return VERIFY_KEEP
    return VERIFY_FORGET if same_idents(rels, snap_releases) else VERIFY_REFRESH


def prop_name(tmdb_id: Any) -> str:
    return "%s%d" % (PROP_PREFIX, int(tmdb_id))


# ── ověření na pozadí (vlákno pluginu) ────────────────────────────────────────────────────────────────────────────────
VERIFY_PURPOSE = "prefetch_verify"      # `purpose` hledání = měření `SEARCH_PHASES` (outcome) i řádek logu
REFRESH_REASON = "prefetch_verify"      # důvod obnovy v logu brány (`CONTAINER_REFRESH reason=…`)
# Nejvýš jedno ověření téhož filmu najednou (meziprocesově, `richmovie_guard`): klik → Zpět → klik během hledání by jinak
# pustil totéž hledání dvakrát. TTL = hledání (desítky s) + čekání na klid (`wait_while_busy` ≤ 90 s) s rezervou.
VERIFY_CLAIM_PREFIX = "prefetch_verify."
VERIFY_CLAIM_TTL_S = 240.0
VERIFY_BUSY = "busy"                    # ověření téhož filmu už běží (jiná invokace) — nic dalšího
REFRESH_SENT = "sent"
REFRESH_HOLD_BROWSING = "hold_browsing"
REFRESH_ABORT = "abort"
REFRESH_LEFT = "left"                   # divák z výpisu odešel — nic k obnovení
REFRESH_WAIT_BROWSING = "browsing"      # důvod čekání: fokus mimo začátek výpisu a přibyly streamy
# Čekání na vhodnou chvíli k obnově (divák přestane ovládat / vrátí se na začátek výpisu). Vlákno pluginu drží interpret
# Kodi → krátce: obvyklý konec čekání je odchod z výpisu (pustí stream) — ten se pozná do `REFRESH_POLL_S`.
REFRESH_WAIT_MAX_S = 120.0
REFRESH_POLL_S = 0.5
REFRESH_SETTLE_S = 10.0                 # jak dlouho čekat, než Kodi ukáže nový výpis (jinak divák odešel dřív, než se usadil)
# Opakovaný pokus o ověření téhož filmu (paměť relace po neúplném ověření): značka návratu `richmovie.auto.done.<id>` v Kodi
# vydrží do restartu, takže „nový klik“ od obnovy MI2 / Zpět odlišit nejde (audit Fable F10 V1) — ověření se pustí při
# KAŽDÉM vykreslení ze snímku, nejvýš jednou za `VERIFY_RETRY_S` (obnova MI2 / Zpět přijde do sekund, opakovaný klik později).
VERIFY_RETRY_PREFIX = "prefetch_verify_try."
VERIFY_RETRY_S = 60.0


# ── úplný výpis po kliknutí (P16) ─────────────────────────────────────────────────────────────────────────────────────
# Richie 14.11.2026: „je na hovno vidět streamy, u kterých neznáme dabing … u přednačtených streamů bych udělal mi2
# kompletní aby se nerefreshovalo a hned zobrazil až po dokončení streamy seřazené“. Klik = snímek (MI2 hned) + běžné
# hledání účtem zařízení + MediaInfo VŠECH streamů → JEDNO vykreslení. Okno průběhu jen, když to trvá déle.
PROGRESS_DELAY_S = 1.0                  # do té doby bez okna (teplá MI cache na NASu = výpis bez okna)
PHASE_SEARCH = "Hledám streamy…"


class LazyProgress(object):
    """Okno průběhu, které se ukáže až po `delay_s` od KLIKNUTÍ (vytvoření objektu na začátku obsluhy) — při prvním
    hlášení průběhu nebo tiku po té době (engine hlásí průběh hledání po dotazech, čekání na MediaInfo tiká v každém
    kroku, i když se počet vyřízených nemění — audit Fable F11 V4). Rozhraní = `_SearchProgressWithTips` / `CancelOnly`
    (`set_phase`, volání `(current, total, stage)`, `tick`, `iscanceled`, `close`). `factory` = vytvoření skutečného
    okna; chyba = bez okna (okno je ozdoba, výpis nesmí spadnout). Po vytvoření se přehraje poslední hlášená fáze.
    Okno vytváří jen vlákno pluginu (`set_phase` / volání / `tick`); `iscanceled` čtou i vlákna dotazů hledání a okno
    nevytváří."""

    def __init__(self, factory: Callable[[], Any], delay_s: float = PROGRESS_DELAY_S,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self._factory, self._delay, self._clock = factory, float(delay_s), clock
        self._t0 = clock()
        self._dlg: Any = None
        self._closed = False
        self._ever = False                  # okno se aspoň jednou ukázalo (měření `window=` v logu)
        self._last: Optional[Tuple[str, Optional[int], Optional[int]]] = None

    @property
    def shown(self) -> bool:
        """Ukázalo se okno aspoň jednou (i po `close`)?"""
        return self._ever

    def _ensure(self) -> Any:
        if self._dlg is None and not self._closed and self._clock() - self._t0 >= self._delay:
            try:
                self._dlg = self._factory()
            except Exception:
                self._closed = True
                return None
            self._ever = True
            if self._last is not None:
                try:
                    self._dlg.set_phase(*self._last)
                except Exception:
                    pass
        return self._dlg

    def set_phase(self, text: str, done: Optional[int] = None, total: Optional[int] = None) -> None:
        self._last = (text, done, total)
        dlg = self._ensure()
        if dlg is not None:
            try:
                dlg.set_phase(text, done, total)
            except Exception:
                pass

    def __call__(self, current: int = 0, total: int = 0, stage: str = "") -> None:
        dlg = self._ensure()
        if dlg is not None:
            try:
                dlg(current, total, stage)
            except Exception:
                pass

    def tick(self) -> None:
        """Čekání bez nového hlášení: po prahu ukáže okno (s poslední fází), aby divák viděl průběh a mohl zrušit."""
        self._ensure()

    def iscanceled(self) -> bool:
        dlg = self._dlg
        try:
            return bool(dlg is not None and dlg.iscanceled())
        except Exception:
            return False

    def close(self) -> None:
        self._closed = True
        dlg, self._dlg = self._dlg, None
        if dlg is not None:
            try:
                dlg.close()
            except Exception:
                pass


def verify_due(tmdb_id: int, *, guard: Any = None) -> bool:
    """Pustit ověření po tomto vykreslení ze snímku? Ano nejvýš jednou za `VERIFY_RETRY_S` na film (meziprocesově,
    `richmovie_guard.note_once`): první vykreslení ano, obnova MI2 / Zpět hned po něm ne, další klik po neúplném ověření ano.
    Chyba = ano (souběh téhož filmu stejně hlídá claim v `run_verify`)."""
    try:
        g = guard if guard is not None else _guard()
        return bool(g.note_once(VERIFY_RETRY_PREFIX + str(int(tmdb_id)), VERIFY_RETRY_S))
    except Exception:
        return True


def run_verify(tmdb_id: int, snap: Snapshot, listing_key: str, *, search: Callable[..., Tuple[List[Any], Any, bool]],
               log: Callable[..., None], monitor: Any = None, props: Any = None,
               refresh: Optional[Callable[[str, Any, int], str]] = None, guard: Any = None,
               on_verified: Optional[Callable[[], None]] = None) -> str:
    """Ověření přednačteného výpisu BĚŽNÝM hledáním účtem zařízení (Fastshare, čerstvé soubory → `SEARCH_CACHE`).

    Běží ve vlákně pluginu po vykreslení (jako MI2: Kodi na vlákna interpretu pluginu čeká, i na `daemon`; hledání se ptá
    monitoru na vypnutí po každé vlně). `search` = `plugin._search_movie` (stejný kontext a kaskáda jako výpis),
    `log(msg, warn=False)`. Nejvýš jedno ověření téhož filmu najednou (claim `richmovie_guard`, jinak `VERIFY_BUSY`).
    Rozhodnutí = `verify_decision`: neúplný výsledek nic nemění (snímek zůstává v paměti relace a další vykreslení ověření
    pustí znovu — cross-check Argon H1/H4, F10 V1), úplný: `on_verified()` (plugin zapíše značku návratu — teprve teď je
    výsledek v `SEARCH_CACHE`, audit Fable F10b V2), snímek z paměti relace pryč (návrat jde přes `SEARCH_CACHE`) a při jiných
    streamech obnova výpisu (`refresh_listing`). Vrací akci. Nikdy nevyhodí výjimku."""
    try:
        guard = guard if guard is not None else _guard()
        token = guard.claim(VERIFY_CLAIM_PREFIX + str(int(tmdb_id)), VERIFY_CLAIM_TTL_S)
    except Exception as exc:
        _safe_log(log, "PREFETCH_VERIFY tmdb=%d status=error err=claim:%s" % (int(tmdb_id), type(exc).__name__), warn=True)
        return VERIFY_KEEP
    if not token:
        _safe_log(log, "PREFETCH_VERIFY tmdb=%d status=busy" % int(tmdb_id))
        return VERIFY_BUSY
    try:
        return _verify(tmdb_id, snap, listing_key, search=search, log=log, monitor=monitor, props=props, refresh=refresh,
                       on_verified=on_verified)
    finally:
        try:
            guard.release(VERIFY_CLAIM_PREFIX + str(int(tmdb_id)), token)
        except Exception:
            pass


def _verify(tmdb_id: int, snap: Snapshot, listing_key: str, *, search: Callable[..., Tuple[List[Any], Any, bool]],
            log: Callable[..., None], monitor: Any, props: Any, refresh: Optional[Callable[[str, Any, int], str]],
            on_verified: Optional[Callable[[], None]] = None) -> str:
    t0 = time.monotonic()
    info: Dict[str, Any] = {}
    try:
        monitor = monitor if monitor is not None else _monitor()
        rels, _det, authoritative = search(int(tmdb_id), should_cancel=monitor.abortRequested, info=info,
                                           purpose=VERIFY_PURPOSE)
        action = verify_decision(rels, authoritative, info, snap.releases, aborted=bool(monitor.abortRequested()))
    except Exception as exc:                            # síť, TMDb, přihlášení: výpis zůstává ze snímku
        _safe_log(log, "PREFETCH_VERIFY tmdb=%d status=error err=%s" % (int(tmdb_id), type(exc).__name__), warn=True)
        return VERIFY_KEEP
    ms = int((time.monotonic() - t0) * 1000)
    if action == VERIFY_KEEP:
        _safe_log(log, "PREFETCH_VERIFY tmdb=%d status=incomplete n=%d errors=%s rate_limited=%s cancelled=%s ms=%d"
                  % (int(tmdb_id), len(rels), info.get("errors"), info.get("rate_limited"), info.get("cancelled"), ms))
        return action
    if on_verified is not None:                         # PŘED `forget`: návrat po zapomenutí musí najít značku (F10b V2)
        try:
            on_verified()
        except Exception as exc:
            _safe_log(log, "PREFETCH_VERIFY tmdb=%d on_verified=%s" % (int(tmdb_id), type(exc).__name__), warn=True)
    forget(tmdb_id, props=props)
    outcome, adds = "-", new_idents(rels, snap.releases)
    if action == VERIFY_REFRESH:
        try:
            outcome = (refresh or refresh_listing)(listing_key, monitor, adds)
        except Exception as exc:
            outcome = "error:%s" % type(exc).__name__
    _safe_log(log, "PREFETCH_VERIFY tmdb=%d status=ok n=%d snap=%d added=%d action=%s refresh=%s ms=%d"
              % (int(tmdb_id), len(rels), len(snap.releases), adds, action, outcome, ms))
    return action


def refresh_listing(listing_key: str, monitor: Any, adds: int = 0, *, wait_max_s: float = REFRESH_WAIT_MAX_S) -> str:
    """Obnova výpisu Z POZADÍ po ověření — nikdy pod rukama (audit Fable F10 V3 / V4). Smyčka à `REFRESH_POLL_S`, nejvýš
    `wait_max_s`, pak konec (čerstvý výsledek je v `SEARCH_CACHE`, ukáže ho další otevření):
    - divák z výpisu ODEŠEL (pustil stream, Zpět, jiný výpis) = konec, nic se neobnovuje — až PO usazení výpisu na obrazovce
      (`REFRESH_SETTLE_S`; ověření z teplé cache doběhne dřív, než ho Kodi ukáže — F10b V3);
    - divák ve výpisu vybírá (fokus mimo 1. řádek, `richmovie_listing.viewer_browsing`, B3-06 jako závěrečná obnova MI2):
      když čerstvé hledání jen UBRALO / přeskládalo = konec (`hold_browsing`); když našlo streamy NAVÍC (`adds` > 0, třeba
      Fastshare) = počkat, až se fokus vrátí na začátek výpisu (pravidlo „nikdy méně streamů“, Richie 29.09.2026, bez rizika,
      že OK pustí jiný řádek, než na který se divák díval);
    - divák právě ovládá (`user_active`) = počkat na klid; jiné odmítnutí brány (přehrávač, start přehrávání, busy dialog,
      konec Kodi) = konec;
    - jinak JEDINÁ brána obnov `refresh_container(background=True, expect_path=…)`. Vrací výsledek pro log."""
    import xbmc
    import richmovie_listing as _listing
    import richmovie_playback_dispatch as _dispatch
    target = _dispatch.listing_id(listing_key)
    started = time.monotonic()
    deadline = started + float(wait_max_s)
    seen = False
    while True:
        try:
            here = _dispatch.listing_id(_listing.listing_key_from_kodi())
        except Exception:
            here = ""
        if target and here == target:
            seen = True
        elif not target or seen or time.monotonic() - started >= REFRESH_SETTLE_S:
            return REFRESH_LEFT
        else:
            # Výpis se ještě neusadil: ověření z teplé cache doběhne dřív, než Kodi přepne `Container.FolderPath` na nový
            # výpis (audit Fable F10b V3) — čekat nejvýš `REFRESH_SETTLE_S`; odchod = až nesoulad PO usazení.
            if monitor.waitForAbort(REFRESH_POLL_S):
                return REFRESH_ABORT
            continue
        try:
            browsing = _listing.viewer_browsing(xbmc.getInfoLabel("Container.CurrentItem"))
        except Exception:
            browsing = False
        if browsing:
            if int(adds) <= 0:
                return REFRESH_HOLD_BROWSING
            why = REFRESH_WAIT_BROWSING
        else:
            why = _dispatch.refresh_block_reason(_dispatch.probe_refresh(background=True))
            if not why:
                sent = _dispatch.refresh_container(REFRESH_REASON, background=True, expect_path=listing_key)
                return REFRESH_SENT if sent else "skip:gate"
            if why != _dispatch.REFRESH_BLOCK_USER_ACTIVE:
                return "skip:%s" % why
        if time.monotonic() >= deadline:
            return "skip:wait_%s" % why
        if monitor.waitForAbort(REFRESH_POLL_S):
            return REFRESH_ABORT


def _safe_log(log: Callable[..., None], msg: str, warn: bool = False) -> None:
    try:
        log(msg, warn=warn)
    except Exception:
        pass


def _monitor() -> Any:
    import xbmc
    return xbmc.Monitor()


def _guard() -> Any:
    import richmovie_guard as _g
    return _g


# ── síť ───────────────────────────────────────────────────────────────────────────────────────────────────────────────
def request_profile(http_mod: Any) -> Any:
    return http_mod.profile_foreground().replace(
        budget_s=REQUEST_BUDGET_S, timeout_s=REQUEST_TIMEOUT_S, max_attempts=REQUEST_MAX_ATTEMPTS)


def _deps() -> Tuple[Callable[[Any, Optional[Tuple[str, str]]], bool], Optional[Tuple[str, str]], Callable[[Any], Any]]:
    import richmovie_trendy as _trendy                      # SSOT pojistky jádra (`core_matches`, `local_core`)
    import richmovie_core_path  # noqa: F401
    from rm_core.model import releases_from_records
    return _trendy.core_matches, _trendy.local_core(), releases_from_records


def fetch(tmdb_id: int) -> Tuple[Optional[Snapshot], str]:
    """Snímek z Gate: (Snapshot, "ok") nebo (None, důvod). Nikdy nevyhodí výjimku a nic neukládá."""
    try:
        import richmovie_gate_transport as _gt
        import richmovie_http as _http
        from richmovie_sync_queue import identity_body
        matches, local, to_rels = _deps()
    except Exception:
        return None, REASON_UNAVAILABLE
    try:
        body = identity_body(build_request(tmdb_id))
        if not body.get("ws_proof"):
            return None, REASON_NO_IDENTITY             # bez identity by Gate odmítl — nic neposílat
        status, resp = _gt.post_json(ENDPOINT, body, profile=request_profile(_http))
    except Exception as exc:                            # síť, offline, jistič hostu, zrušení, nepřečtená identita
        return None, "transport:%s" % type(exc).__name__
    data, reason = parse_response(status, resp)
    if data is None:
        return None, reason
    return build_snapshot(int(tmdb_id), data, local_core=local, core_matches=matches, records_to_releases=to_rels,
                          source="gate")


# ── paměť relace (Window 10000) ─────────────────────────────────────────────────────────────────────────────────────
def remember(snap: Snapshot, *, props: Any = None, now: Optional[float] = None) -> None:
    """Uloží snímek do paměti relace Kodi (obnova od MI2 / Zpět) a uklidí prošlé (index `INDEX_PROP`). Chyba = nic
    (vykreslení proběhlo i tak)."""
    try:
        props = props or _props()
        t = float(now if now is not None else time.time())
        payload = {"ts": t, "core": snap.core, "wave": snap.wave, "computed_at": snap.computed_at, "records": snap.records}
        props.set_prop(prop_name(snap.tmdb_id), json.dumps(payload, ensure_ascii=False))
        _index_update(props, t, add=int(snap.tmdb_id))
    except Exception:
        pass


def _index_update(props: Any, now: float, *, add: Optional[int] = None, drop: Optional[int] = None) -> None:
    """Úklid paměti relace (audit Fable F10 V5): Kodi běží na televizích týdny a snímek po neúplném ověření by jinak ve
    Window(10000) zůstal do restartu. Index {id: čas uložení}; prošlé (`SESSION_TTL_S`), nečitelné a nad `SESSION_MAX_FILMS`
    (nejstarší) se smažou i s vlastností snímku. Best-effort: souběžný zápis jiné invokace může položku z indexu ztratit —
    ta se pak uklidí při vlastním `recall` / `forget`."""
    try:
        idx = json.loads(props.get_prop(INDEX_PROP, "") or "{}")
    except Exception:
        idx = {}
    if not isinstance(idx, dict):
        idx = {}
    if drop is not None:
        idx.pop(str(int(drop)), None)
    if add is not None:
        idx[str(int(add))] = float(now)
    alive = []
    for key, ts in idx.items():
        ok = key.isdigit() and isinstance(ts, (int, float)) and not isinstance(ts, bool) and 0.0 <= now - ts <= SESSION_TTL_S
        if ok:
            alive.append((float(ts), key))
        elif key.isdigit():
            props.clear_prop(prop_name(int(key)))
    alive.sort(reverse=True)
    for _ts, key in alive[SESSION_MAX_FILMS:]:
        props.clear_prop(prop_name(int(key)))
    kept = {key: ts for ts, key in alive[:SESSION_MAX_FILMS]}
    if kept:
        props.set_prop(INDEX_PROP, json.dumps(kept, sort_keys=True))
    else:
        props.clear_prop(INDEX_PROP)


def recall(tmdb_id: int, *, props: Any = None, now: Optional[float] = None,
           deps: Optional[Tuple[Callable[..., bool], Optional[Tuple[str, str]], Callable[[Any], Any]]] = None
           ) -> Optional[Snapshot]:
    """Snímek z paměti relace, nebo None (není / starší než `SESSION_TTL_S` / vadný / jiné jádro). Vadný a starý se smaže."""
    try:
        props = props or _props()
        raw = props.get_prop(prop_name(tmdb_id), "")
        if not raw:
            return None
        try:
            payload = json.loads(raw)
            ts = float(payload.get("ts") or 0.0)
        except Exception:                                # nečitelný záznam paměti relace = pryč, výpis jde dnešní cestou
            props.clear_prop(prop_name(tmdb_id))
            return None
        t = float(now if now is not None else time.time())
        if not (0.0 <= t - ts <= SESSION_TTL_S):
            props.clear_prop(prop_name(tmdb_id))
            return None
        matches, local, to_rels = deps or _deps()
        snap, _reason = build_snapshot(int(tmdb_id), payload, local_core=local, core_matches=matches,
                                       records_to_releases=to_rels, source="session")
        if snap is None:
            props.clear_prop(prop_name(tmdb_id))
        return snap
    except Exception:
        return None


def forget(tmdb_id: int, *, props: Any = None, now: Optional[float] = None) -> None:
    """Snímek z paměti relace pryč (po ověření na pozadí: návrat pak jde přes SEARCH_CACHE s čerstvým výsledkem)."""
    try:
        props = props or _props()
        props.clear_prop(prop_name(tmdb_id))
        _index_update(props, float(now if now is not None else time.time()), drop=int(tmdb_id))
    except Exception:
        pass


def _props() -> Any:
    import richmovie_winprops as _wp
    return _wp
