# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Vyhledávací a filtrační **ENGINE**
───────────────────────────────────────────────────────────────────────────────
Tento modul koncentruje *veškeré* know‑how doplňku RichMovie týkající se:

  • sestavení dotazů a paralelního volání API Webshare.cz  
  • heuristické filtrace a rankingu releaseů (kvalita, velikost, délka filmu)  
  • deduplikace a označení ★ MATCH (±5 min od cílové stopáže)  
  • parsování jazyků, bitrate a normalizace názvů  
  • čisté datové objekty → **žádná** závislost na Kodi!  
    (GUI si řeší až plugin.py pomocí `LabelFormatter`).

Při refaktoru (06/2025) jsme zachovali 100 % původní logiku i výstupní formát,
pouze kód rozdělili na srozumitelné třídy:

* `SearchEngine` – orchestrace dotazů; veřejné API `search_one()` a `search_wave()`  
* `ReleaseFilter` – statická pravidla pro vyřazení/obohacení WS souborů  
* `LabelFormatter` – převod `Release` → slovník s texty pro GUI  
* pomocné util‑funkce `norm()`, `base_title_key()`, `quality()`, `parse_langs()`

Autor: Richie (2023–2025), refaktor © VİÝVOJ  
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

# — Standard lib —
import concurrent.futures as _f
import datetime
import functools
import hashlib
import json
import os
import random
import re
import threading
import time
import unicodedata
from dataclasses import asdict, dataclass, field, fields as _dc_fields
from typing import TYPE_CHECKING, Any, Callable, Iterable, List, Optional, Sequence, Tuple

if TYPE_CHECKING:  # jen pro anotace (Φ5A: pyflakes „undefined name“ brána bez výjimek)
    from richmovie_fastshare import FastshareClient  # noqa: F401

from collections.abc import Callable  # přidejte jednou mezi importy
from collections import OrderedDict        # pořadí bez duplicit v QueryBuilder





# – Kodi GUI (pouze pro _SearchProgress) –
import xbmcgui  # type: ignore
import xbmcaddon  # type: ignore
import xbmcvfs    # type: ignore
import xbmc      # type: ignore  # PRIORITA A: abortRequested/Android detekce

# – Lokální moduly –
# – Sdílené jádro hledání (G1): čistá standardní knihovna, tentýž balík používá Gate. –
import richmovie_core_path  # noqa: F401  (resources/lib na sys.path dřív než první import rm_core)
from rm_core.text import (  # noqa: F401
    ALLOWED_VIDEO_EXTS,
    EROTIC_KEYWORDS,
    FILTER_PROGRESS_EVERY,
    GENERIC_EP,
    LEN_TOL_LONG,
    LEN_TOL_SHORT,
    MATCH_TOL,
    MAX_WS_RESULTS,
    MIN_FILE_MB_BY_QUALITY,
    PAGING_VIDEO_EXTS,
    PROBE_MAX_RESULTS,
    QUALITY_RANK,
    YEAR_RE,
    _BAD_REGEX_DEFAULT,
    _BAD_REGEX_MOVIE,
    _BAN_STOP,
    _CODE_CANON_RE,
    _DUB_HINT,
    _EXT_AFTER_SPACE_RE,
    _FRANCHISE_FILM_RE,
    _LANG_AUD_GLUED_RE,
    _LANG_AUD_SUFFIX,
    _LANG_MAP,
    _LANG_SPLIT_RE,
    _LANG_SUB_GLUED_RE,
    _LANG_SUB_SUFFIX,
    _OTHER_EP_RE,
    _QUAL_PATTERNS,
    _RE_SXXEYY,
    _RE_XXYY,
    _ROMAN,
    _SUB_HINT,
    _alpha_word_count,
    _is_adult_title,
    _norm,
    _phrase_contains,
    base_title_key,
    canon_ep_codes,
    extract_langs_from_mediainfo,
    norm,
    other_episode_code_hit,
    parse_langs,
    quality,
    sane_item,
    sanitize_ban_tokens,
    video_ext_of,
)
from rm_core.queries import (  # noqa: F401
    QueryBuilder,
    _ALT_COUNTRY_WHITELIST,
    _ALT_MAX_TITLES,
    _ALT_THRESHOLD,
    _NON_LATIN_RE,
)
from rm_core.model import (  # noqa: F401
    Release,
    ReleaseFilter,
    releases_from_records,
    score_sort_key,
    score_text,
)
from rm_core.dedupe import (  # noqa: F401
    FetchResult,
    _dedupe_multi_source,
)
from rm_core.filter_tv import (  # noqa: F401
    TvFilterContext,
    _TV_CODE_POS_RE,
    _TV_META_OK,
    _TV_SE_RE,
    _TV_STOP,
    filter_tv_items,
    tv_filter_context,
    tv_title_penalty,
)
from rm_core.filter_movie import (  # noqa: F401
    MOVIE_BAN_GENERIC,
    MOVIE_UNAMBIGUOUS_MIN_WORDS,
    _MOVIE_TITLE_STOP,
    filter_movie_items,
    movie_ban_hit,
)
import rm_core.dedupe as _rm_dedupe
import rm_core.filter_movie as _rm_filter_movie
import rm_core.filter_tv as _rm_filter_tv
import rm_core.mi_flags as _rm_mi_flags
from rm_core.mi_flags import _mi2_norm_code  # noqa: F401
import rm_core.context as _rm_context

from richmovie_helpers import SEARCH_CACHE         # ← NOVÝ modul
import richmovie_quality as _rm_quality            # Φ-D (30.09.2026): SSOT kvality (štítek = třída řazení)
import richmovie_winprops as _winprops             # S2 (10.10.2026): Window(10000) jen přes SSOT (audit Fable F-2)
from richmovie_webshare import (
    PAGE_SIZE as WS_PAGE_SIZE,
    RateLimited as WsRateLimited,
    WebshareClient,
)

from tmdb_client import TMDb, TMDbError
from richmovie_helpers import net_error_message  # Φ2: česká věta místo technického textu
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)

# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.83): diagnosticky logger pro dřív
# TICHÁ except místa (spin_tokens heuristika, probe futures, tip-state I/O).
# Event log self._log (per-search soubor) zůstává NEDOTČEN — tohle je druhý,
# NAS-routovaný kanál pro problémy. Fallback = no-op (engine nesmí spadnout
# kvůli diagnostice; best-effort filozofie).
try:
    from richmovie_logging import make_legacy_logger as _eng_make_legacy_logger
    _diag_log = _eng_make_legacy_logger("richmovie.engine", "RichMovie/Engine")
except Exception:
    def _diag_log(msg, level=1, *, context=None):
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  DALŠÍ KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────


def _pool_size(requested: int) -> int:
    """Vraci pool size omezeny na 2 workery na Androidu (prevence OOM/CPU saturation)."""
    try:
        if xbmc.getCondVisibility("system.platform.android"):
            return max(1, min(2, requested))
    except Exception:
        pass
    return requested


# ── S2 (10.10.2026, Gate mig 0043): souběžnost STAHOVÁNÍ dotazů vlny hledání per zařízení ─────────────────────────
# Vlna hledání stahuje dotazy souběžně, filtr běží JEDNOU nad sjednocením (Φ-B) — Androidí strop 2 (21.02.2026) vznikl
# kvůli CPU filtru ×N, který už neběží. Kolik smí konkrétní zařízení, nastaví správce na Gate (A/B na jednom zařízení,
# rozhodnutí Richieho 10.10.2026); výchozí chování flotily se NEMĚNÍ. Když zařízení s vyšší souběžností narazí na
# brzdění Webshare (HTTP 429) nebo na nedostatek paměti, vrátí se samo na výchozí na `FETCH_FALLBACK_S`.
FETCH_PARALLEL_MAX = 6
ANDROID_FETCH_DEFAULT = 2
FETCH_FALLBACK_S = 24 * 3600.0
_FETCH_FALLBACK_PROP = "richmovie.search.fetch_fallback_until"   # time.time() konce návratu (Window(10000), Kodi běh)


def fetch_parallel_limit(gate_value: Optional[int], android: bool, fallback_active: bool) -> Optional[int]:
    """ČISTÁ: strop souběžných stažení vlny. Hodnota správce (1–6) platí, dokud zařízení nebylo vráceno na výchozí;
    výchozí = Android 2, jinak None (bez zvláštního stropu — jen `FETCH_PARALLEL_MAX`). Návrat po 429 / paměti NIKDY
    nezvýší souběžnost: výchozí platformy, nejvýš hodnota správce (cross-check Codex #3 — desktop se 3 by skočil na 6)."""
    default = ANDROID_FETCH_DEFAULT if android else None
    if gate_value is None or not 1 <= int(gate_value) <= FETCH_PARALLEL_MAX:
        return default
    if not fallback_active:
        return int(gate_value)
    return min(int(gate_value), default if default else FETCH_PARALLEL_MAX)


def _fetch_fallback_active(now: Optional[float] = None) -> bool:
    try:
        until = float(_winprops.get_prop(_FETCH_FALLBACK_PROP, "") or 0.0)
    except (TypeError, ValueError):
        return False
    return until > (time.time() if now is None else now)


def _fetch_pool_size(requested: int) -> Tuple[int, str, bool]:
    """(velikost poolu vlny, zdroj stropu `gate` | `fallback` | `android` | `default`, sníží návrat na výchozí STROP
    zařízení?) — zdroj jde do `SEARCH_PHASES`; třetí hodnota rozhoduje `_note_fetch_pressure`. Porovnávají se stropy,
    ne velikost této vlny: krátká vlna (2 dotazy) by jinak 429 spolkla a další dlouhá jela dál na stropu správce
    (ověřovací kolo Fable N-1)."""
    try:
        import richmovie_gate as _rm_gate
        gate_value = _rm_gate.search_fetch_parallel()
    except Exception:
        gate_value = None
    try:
        android = bool(xbmc.getCondVisibility("system.platform.android"))
    except Exception:
        android = False
    fallback = gate_value is not None and _fetch_fallback_active()

    def _cap(limit: Optional[int]) -> int:
        return min(FETCH_PARALLEL_MAX, limit if limit else FETCH_PARALLEL_MAX)
    cap = _cap(fetch_parallel_limit(gate_value, android, fallback))
    fallback_reduces = _cap(fetch_parallel_limit(gate_value, android, True)) < cap
    size = max(1, min(int(requested), cap))
    if gate_value is not None and not fallback:
        return size, "gate", fallback_reduces
    return size, ("fallback" if fallback else ("android" if android else "default")), fallback_reduces


def _note_fetch_pressure(exc: BaseException, pool_size: int, source: str, fallback_reduces: bool,
                         log: Callable[..., Any]) -> None:
    """Brzdění Webshare (429) / nedostatek paměti při souběžnosti nastavené správcem → návrat na výchozí na
    `FETCH_FALLBACK_S` (jen v tomto běhu Kodi). Rozhoduje TYP výjimky. Návrat se zapíše JEN když sníží STROP zařízení
    (audit Fable F-3: desktop se správcovskou hodnotou ≤ výchozí by jinak hlásil `pool_fallback`, který nenastal, a A/B
    měření by lhalo; N-1: rozhoduje strop, ne velikost vlny). Nikdy nevyhazuje."""
    if source != "gate" or not isinstance(exc, (WsRateLimited, MemoryError)):
        return
    if not fallback_reduces:
        try:
            _diag_log.info("FETCH_PRESSURE_NOOP reason=%s pool=%d (návrat by nic nesnížil)"
                           % (type(exc).__name__, pool_size))
        except Exception:
            pass
        return
    try:
        _winprops.set_prop(_FETCH_FALLBACK_PROP, repr(time.time() + FETCH_FALLBACK_S))
        log("FETCH_PARALLEL_FALLBACK", type(exc).__name__, pool_size)
        _diag_log.warning("FETCH_PARALLEL_FALLBACK reason=%s pool=%d → výchozí na %d h"
                          % (type(exc).__name__, pool_size, int(FETCH_FALLBACK_S // 3600)))
    except Exception as exc2:
        try:   # návrat se nezapsal → příští vlna pojede se souběžností správce; musí to být vidět (Codex #3)
            _diag_log.warning("FETCH_PARALLEL_FALLBACK_FAILED reason=%s err=%r" % (type(exc).__name__, exc2))
        except Exception:
            pass







# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY  (sdílené i s plugin.py – ten je může importovat odsud)
# ─────────────────────────────────────────────────────────────────────────────

# HΦ-D P2-1 (2026-07-07, re-audit night2): `BITRATE_MBPS` SMAZÁN — byl MRTVÝ
# KÓD (0 použití; `_bytes_to_minutes` nikdy neexistoval). HΦ-C len_out korektnost
# STOJÍ na tom, že est_min je VŽDY měřený (žádný odhad z bitrate) — smazání
# konstanty ten invariant zamyká (nikdo ji omylem nezapojí zpět).















PROBE_CHUNK_KB  = 512      # kolik dat stáhneme v jednom „kusu“
PROBE_MAX_KB    = 10_240   # hard-limit ≈ 10 MB

























# ───────────────────────────────────────────────────────────────────────












































    # `QueryBuilder.movie()` a obálka `build_movie_queries()` ODSTRANĚNY (Φ-C, 30.09.2026, E2 inventura):
    # nikdo je nevolal. Dotazy filmu staví `richmovie_movie_search.query_variants` (přesun do QueryBuilderu je kandidát
    # samostatné změny — mění pořadí dotazů, proto až s měřením původu).



# Neúplný výsledek vlny (selhal dotaz) smí v cache žít jen po dobu práce s jedním výpisem.
PARTIAL_RESULT_TTL_S = 600









# ─────────────────────────────────────────────────────────────────────────────
#  SEARCH ENGINE
# ─────────────────────────────────────────────────────────────────────────────




def _source_error_kind(exc: BaseException) -> str:
    """Druh selhání zdroje pro měření a větu divákovi (S31) — podle TŘÍDY výjimky a její příčiny, nikdy podle textu:
    `host_down` = jistič hostu v `richmovie_http` (rychlé selhání bez sítě), `transport` = síť / vypršení,
    `rate_limited` = 429, jinak jméno třídy (odpověď API, kontrakt)."""
    import richmovie_http as _rm_http
    chain = []
    cur: Optional[BaseException] = exc
    while cur is not None and len(chain) < 4:
        chain.append(cur)
        cur = cur.__cause__ or cur.__context__
    if any(isinstance(e, _rm_http.HostDownError) for e in chain):
        return "host_down"
    if any(isinstance(e, WsRateLimited) for e in chain):
        return "rate_limited"
    if any(isinstance(e, (_rm_http.TransientError, OSError)) for e in chain):
        return "transport"
    return type(exc).__name__






@functools.lru_cache(maxsize=128)
def spin_tokens(
    tv_id: str,
    tmdb_key: str | None,
    *,
    lang: str = "en-US",
    logger: 'Callable[..., None]' | None = None,
) -> tuple[set[str], set[str]]:
    """(allow_tokens, ban_tokens) spin-offů téže franšízy — SSOT `rm_core.context.compute_spin_tokens` (G1);
    tady jen TMDb klient doplňku a `lru_cache` procesu."""
    log = logger or (lambda *_, **__: None)
    if not (tv_id and tmdb_key):
        return set(), set()
    tmdb = TMDb(tmdb_key, lang=lang, logger=log)
    return _rm_context.compute_spin_tokens(tmdb, tv_id, tmdb_key, lang=lang, log=log, diag=_diag_log)


class SearchCancelled(Exception):
    """Uživatel hledání zrušil (Zrušit / Zpět v dialogu) — Φ5A, 29.09.2026, audit A06 R10.

    Vlna se ukončí BEZ zápisu do cache a bez spuštění MediaInfo: částečný výsledek se nesmí uložit jako
    hotový (R2 — marker „hotovo“ až po absolutním úspěchu). Dřív engine zrušení nečetl vůbec a seznam se
    po „Zrušit“ stejně vykreslil."""


def _cancel_fn(progress_cb: Any) -> Optional[Callable[[], bool]]:
    """`iscanceled` dialogu hledání, pokud ho `progress_cb` má (jinak None = nelze zrušit)."""
    fn = getattr(progress_cb, "iscanceled", None)
    return fn if callable(fn) else None


def _raise_if_cancelled(cancel_check: Optional[Callable[[], bool]]) -> None:
    if cancel_check is None:
        return
    try:
        cancelled = bool(cancel_check())
    except Exception:
        cancelled = False
    if cancelled:
        raise SearchCancelled()


class SearchEngine:
    """
    Orchestrace vyhledávání na Webshare (+ volitelně Fastshare).

    Parametry
    ---------
    get_client      : Callable[[], WebshareClient]
        Funkce, která kdykoliv vrátí *přihlášenou* instanci klienta.
        (plugin.py předá např. `lambda: _SESSION.client`)
    logger          : Callable[[str, object], None]
        Centralizovaný logger – používáme `plugin._log_event`.
    get_fastshare_client : Callable[[], FastshareClient | None]  (volitelné)
        Callback vracející přihlášený FastshareClient nebo None.
        Pokud je None nebo vrátí None, Fastshare se nepoužije.
    """

    # ------------------------------------------------------------------ #
    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › třída SearchEngine
    # __init__  (upraveno: 21.01.2026 23:15 CET, Europe/Prague – přidán get_fastshare_client)
    # ---------------------------------------------------------------------------- #
    def __init__(
        self,
        get_client: Callable[[], WebshareClient],
        logger: Callable[..., None],
        *,                       # parametry za * jsou pouze pojmenované
        enable_probe: bool = True,
        get_fastshare_client: Callable[[], "FastshareClient | None"] | None = None,
        today_fn: Callable[[], datetime.date] | None = None,
    ) -> None:
        """
        Inicializace vyhledávacího enginu.

        • `get_client`           – callback vracející přihlášený `WebshareClient`
        • `logger`               – funkce pro logování (plugin._log_event)
        • `enable_probe`         – globální přepínač MediaInfo sondování
        • `get_fastshare_client` – callback vracející přihlášený `FastshareClient` nebo None
                                   (Fastshare integrace 21.01.2026)
        """
        self._get_client   = get_client
        self._log          = logger
        self._enable_probe = enable_probe
        # jádro 1.2.0: dnešní datum pro filtr filmu (slabá shoda názvu u nového filmu, `filter_movie.weak_title_needs_proof`)
        # — čas je v jádře vstříknutý; replay a testy dodávají pevné datum (deterministický snímek)
        self._today = today_fn or datetime.date.today

        # — NOVĚ: Fastshare integrace (21.01.2026) —
        self._get_fs_client = get_fastshare_client

        # RAM ‑ cache pro již zjištěné MediaInfo bloky
        self._mi_cache: dict[str, dict] = {}
        self._lock = threading.Lock()

        # ⚡ NOVĚ: cache před‑kompilovaných regexů na základě id(banned_keys)
        #         → minimalizuje režii při opakovaném vyhledávání dílů
        self._banned_re_cache: dict[int, re.Pattern] = {}







    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # search_one (upraveno: 27.12.2025 19:49 CET (Europe/Prague) – SANITIZE: (1) banned_keys nikdy nesmí “banovat” token, který je součástí některé TMDb varianty názvu seriálu,
    #  (2) title_penalty: TMDb title tokeny nikdy nesmí být “bad”,
    #  (3) title_penalty se spouští pouze pro skutečně “one-word” seriály (primary TMDb varianta po STOP/epi filtraci); zachováno vše ostatní včetně numeric signature a guardů)
    # ---------------------------------------------------------------------------- #
    def search_one(  # noqa: C901
        self,
        query: str,
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        ser_title_variants: Sequence[Sequence[str]] = (),  # 26.12.2025 – OR přes varianty názvu seriálu (hlavní/alt)
        banned_keys: Sequence[str] = (),
        ep_title_variants: Sequence[Sequence[str]] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] | None = None,   # 2025-08-19 10:39 CEST (Europe/Prague)
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
        probe: bool = True,
        ep_soft: bool = False,  # 15.11.2025 19:07 CET, Europe/Prague – SOFT režim pro Vlnu X
        stats: Optional[dict] = None,   # Φ-E: `errors` += 1, když zdroj dotazu selhal (výsledek není úplný)
        ban_other_episodes: bool = False,  # Φ5B: zákaz jiného dílu kódem (místo 20k ban tokenů)
        homonym_variants: Sequence[Sequence[str]] = (),  # jádro 1.2.2 F2: varianty názvu, které nese i jiný seriál
    ) -> List["Release"]:
        """
        Jeden `/search` dotaz → filtrovaný, seřazený seznam `Release`.

        [Aktualizováno: 2025-08-10 13:56 CEST] – DETAILNÍ LOGOVÁNÍ příčin odmítnutí (FILTER_REJECT) beze změny logiky.
        [Aktualizováno: 2025-08-19 08:03 CEST] – FIX: fallback `uncertain` kontroluje příponu z `rel.name` (splitext) proti `ALLOWED_VIDEO_EXTS`.
        [Aktualizováno: 2025-08-19 08:14 CEST] – FIX: fallback odmítne releasy s jiným ep-kódem (SxxEyy/xxXyy vč. „S01.E01“) nebo „E##“ bez sezóny.
        [Aktualizováno: 2025-08-19 08:34 CEST] – FIX (Rule C): pokud se chytne jen **generická** ep sada („episode 3“ apod.), je nutný i `ser_part`.
        [Aktualizováno: 2025-08-19 10:05 CEST] – SPEC: Jednoslovné názvy – Rule A (zpřísnění adjacency) používáme jen u krátkých názvů (≤5 znaků).
        [Aktualizováno: 2025-08-19 10:39 CEST] – Filtr roku: podpora `allowed_years` (seriál + série + epizoda); zpětně kompatibilní s `movie_year`.
        [Aktualizováno: 2025-12-26 16:35 CET] – FIX: numeric/alias názvy (11.22.63 vs Dallas 63) + Guard proti falešným průchodům Rule C bez tokenu seriálu.
        [Aktualizováno: 2025-12-26 21:06 CET] – FIX: ser_full (AND přes alt názvy) → OR přes varianty názvu seriálu (ser_title_variants).
        [Aktualizováno: 2025-12-27 19:49 CET] – SANITIZE: banned_keys a title_penalty „bad“ ignorují TMDb title tokeny; title_penalty běží jen pro “one-word” seriály.
        [Aktualizováno: 2026-09-30] – Φ-A: stažení (`_fetch_query`) a filtr (`_tv_filter`) jsou oddělené;
            vlna (`search_wave`) stahuje dotazy souběžně a filtruje sjednocení JEDNOU.
        """
        fetched = self._fetch_query(query, raw_event="RAW_SEARCH", cancel_check=cancel_check)
        if fetched.error and stats is not None:
            stats["errors"] = int(stats.get("errors", 0) or 0) + 1
        _items = [it for it in (sane_item(x) for x in fetched.items) if it is not None]
        return self._tv_filter(
            _items, label=query, runtimes=runtimes, title_norms=title_norms,
            ser_title_variants=ser_title_variants, banned_keys=banned_keys,
            ep_title_variants=ep_title_variants, movie_year=movie_year, allowed_years=allowed_years,
            bad_regex=bad_regex, progress_cb=progress_cb, probe=probe, ep_soft=ep_soft,
            ban_other_episodes=ban_other_episodes, homonym_variants=homonym_variants,
        )

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # _fetch_query / _fetch_wave / _union_fetched / _log_wave_yield
    # (Φ-A 30.09.2026 — SSOT stahování pro film i seriál + původ identu; plán PLAN_search_efficiency_20260929)
    # ---------------------------------------------------------------------------- #
    def _fetch_query(
        self,
        query: str,
        *,
        raw_event: str,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> FetchResult:
        """Syrové položky jednoho dotazu: stránky Webshare + Fastshare, sloučené (`_dedupe_multi_source`).
        Jen síť a logy dotazu — žádné rozhodování filtru. `raw_event` = `RAW_SEARCH` (seriál) nebo
        `RAW_MOVIE_SEARCH` (film); formát řádků logu je stejný jako před rozdělením."""
        res = FetchResult(query)
        _t0 = time.monotonic()
        self._log(raw_event, query)

        # ❶ Webshare /search (smart pagination: min 2, max 5 stránek)
        #    Po 2 stránkách zkontrolujeme, zda máme video soubory.
        #    Pokud ne (API category filtr selhal), stahujeme další stránky.
        cli = self._get_client()
        ws_items: List[dict] = []
        # D4 (4.0.0): stránka má `WS_PAGE_SIZE` = 200 položek (dřív 100) → první požadavek přinese, co dřív dva;
        # strop 3 stránky = 600 položek (dřív 5 × 100 = 500 — nikdy méně).
        _WS_MAX_PAGES = 3
        try:
            for _pg in range(_WS_MAX_PAGES):
                _raise_if_cancelled(cancel_check)   # Φ5A: Zrušit mezi stránkami
                page = cli.search(query, offset=_pg * WS_PAGE_SIZE)
                res.ws_pages += 1
                if not page:
                    break
                clean = self._sane_items(page)
                for it in clean:
                    res.page_of.setdefault(it.get("ident"), str(_pg + 1))
                ws_items.extend(clean)
                if len(page) < WS_PAGE_SIZE:
                    break
                # po první stránce (= dřívějších 200 položkách ze dvou stránek): další jen když ještě není video
                has_video = any(os.path.splitext(str(it.get("name", "") or ""))[1].lower() in PAGING_VIDEO_EXTS
                                for it in ws_items)
                if has_video:
                    break
                self._log("WS_NO_VIDEO_YET", query, len(ws_items))
        except SearchCancelled:
            raise                               # zrušení diváka řeší vlna jako dřív
        except Exception as ws_err:
            # S31 (08.11.2026): výpadek Webshare NESMÍ přeskočit Fastshare (dřív výjimka opustila dotaz a Fastshare
            # se vůbec nezeptal — hledání 2–5 min s nulou, i když Fastshare soubory měl). Stránky stažené před
            # chybou zůstávají; výsledek je neúplný → do paměti dotazů ani cache hledání jako úplný nejde (R2).
            res.ws_error = _source_error_kind(ws_err)
            res.ws_exc = ws_err
            self._log("WS_ERROR", query, res.ws_error, repr(ws_err)[:160])
        res.ws_raw = len(ws_items)
        self._log("WS_RESULTS", query, len(ws_items))

        # — Fastshare integrace (21.01.2026) —
        _raise_if_cancelled(cancel_check)       # Φ5A: Zrušit před Fastshare
        fs_items: List[dict] = []
        if self._get_fs_client:
            try:
                fs_cli = self._get_fs_client()
                if fs_cli:
                    res.fs_calls = 1
                    fs_items = self._sane_items(fs_cli.search(query, limit=200))
                    self._log("FS_RESULTS", query, len(fs_items))
            except SearchCancelled:
                raise
            except Exception as fs_err:
                res.fs_error = _source_error_kind(fs_err)
                self._log("FS_ERROR", query, str(fs_err))
                # Toast při chybě - ale nerozbijeme flow
                try:
                    # Φ2: česká věta podle třídy chyby (detail je v FS_ERROR výše)
                    _rm_notif(net_error_message(fs_err)[0], xbmcgui.NOTIFICATION_WARNING, 3000, "Fastshare")
                except Exception:
                    pass
        res.fs_raw = len(fs_items)
        for it in fs_items:
            res.page_of.setdefault(
                it.get("ident"), "fsy" if it.get("_fs_match_mode") == "year_stripped" else "fs")
        if any(it.get("_fs_match_mode") == "year_stripped" for it in fs_items):
            res.fs_calls = 2

        res.error = "+".join(name for name, err in (("ws", res.ws_error), ("fs", res.fs_error)) if err)
        # Sloučení výsledků (WS + unikátní FS)
        res.ws_list, res.fs_list = ws_items, fs_items
        res.items = _dedupe_multi_source(ws_items, fs_items)
        self._log("MERGED_RESULTS", query, len(res.items))
        res.ms = int((time.monotonic() - _t0) * 1000)
        try:
            self._log("FETCH_STATS", json.dumps(
                {"q": query, "pages": res.ws_pages, "ws": res.ws_raw, "fs": res.fs_raw,
                 "fs_calls": res.fs_calls, "merged": len(res.items), "ms": res.ms,
                 "ws_err": res.ws_error, "fs_err": res.fs_error}, ensure_ascii=False))
        except Exception:
            pass
        _raise_if_cancelled(cancel_check)       # Φ5A: Zrušit před filtrem (CPU)
        return res

    def fetch_raw(self, query: str, cap: Optional[int] = None) -> "FetchResult":
        """Přímé hledání bez filtru názvu (`plugin._ws_search`): syrové položky Webshare + Fastshare TOUTÉŽ cestou jako
        vlny hledání (S31, 08.11.2026) — výpadek jednoho zdroje nezastaví druhý, chyba zdroje je v `ws_error` /
        `fs_error` (+ původní výjimka Webshare v `ws_exc`, např. vypršelé přihlášení). Dřív měl plugin vlastní kopii
        stahování (Webshare před Fastshare, výjimka přeskočila Fastshare).
        `cap` = strop položek KAŽDÉHO zdroje PŘED odstraněním duplicit (pořadí jako dřív v pluginu: duplicita z Fastshare,
        jejíž verze z Webshare spadne za strop, se neztratí — cross-check Codex 08.11.2026)."""
        res = self._fetch_query(query, raw_event="RAW_SEARCH")
        if cap is not None:
            res.items = _dedupe_multi_source(res.ws_list[:cap], res.fs_list[:cap])
        return res

    def _sane_items(self, items: object) -> List[dict]:
        """Položky zdroje v použitelném tvaru (`sane_item`); nepoužitelné jdou do logu, ne do výjimky —
        jedna vadná položka nesmí shodit dotaz ani vlnu (audit Fable F1-V5)."""
        out: List[dict] = []
        for raw in (items if isinstance(items, (list, tuple)) else []):
            it = sane_item(raw)
            if it is None:
                self._log("FILTER_REJECT", "", "item_error", repr(raw)[:160])
            else:
                out.append(it)
        return out

    def _fetch_wave(
        self,
        queries: Sequence[str],
        *,
        raw_event: str,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        stats: Optional[dict] = None,
        memo: Optional[dict] = None,
    ) -> Optional[List[FetchResult]]:
        """Stáhne dotazy vlny souběžně (jen síť). Vrací výsledky v pořadí DOTAZŮ, nebo None při zrušení.
        Selhání jednoho dotazu vlnu nepřeruší (prázdný výsledek + `WAVE_QUERY_ERR`); počet selhání jde do
        `stats["errors"]` — volající podle něj pozná, že „nic nenalezeno“ není autoritativní (R2)."""
        _cancel_check = _cancel_fn(progress_cb)   # Φ5A: Zrušit v dialogu
        fetched: List[FetchResult] = [FetchResult(q) for q in queries]
        # Φ-C (30.09.2026, E1-F04 / E2-F04): TENTÝŽ dotaz se v jednom hledání stahuje JEDNOU. Vlna WX+ skládá
        # znovu dotazy z W1/W3/WX a záložní vlna filmu znovu primární dotazy — výsledek je týž, jen se podruhé
        # platilo sítí (8 % všech volání Webshare, špička 132 volání za minutu z jednoho zařízení). Shoda
        # je DOSLOVNÁ (stejný řetězec), paměť žije jen po dobu jednoho hledání a výsledek s chybou se do ní
        # neukládá (R2: selhání se neperzistuje).
        todo: dict = {}
        for i, q in enumerate(queries):
            if memo is not None and q in memo:
                fetched[i] = memo[q].as_reused()
            elif q in todo:
                todo[q].append(i)
            else:
                todo[q] = [i]
        for i, r in enumerate(fetched):
            if r.reused:
                self._log("FETCH_REUSED", r.query, len(r.items))
        total_q = len(todo)
        # S2 (10.10.2026): strop souběžných stažení = hodnota správce z Gate, jinak výchozí (Android 2) — `_fetch_pool_size`
        pool_size, pool_src, pool_fallback_reduces = _fetch_pool_size(max(1, min(FETCH_PARALLEL_MAX, total_q)))
        if todo:
            self._log("FETCH_POOL", pool_size, pool_src)   # → `SEARCH_PHASES` (`pool`, `pool_src`) — A/B měření S2
        errors = 0
        _cancelled = False
        if todo:
            with _f.ThreadPoolExecutor(max_workers=pool_size) as pool:
                futs = {pool.submit(self._fetch_query, q, raw_event=raw_event, cancel_check=_cancel_check): q
                        for q in todo}
                for idx, f in enumerate(_f.as_completed(list(futs)), 1):
                    q = futs[f]
                    first = todo[q][0]
                    try:
                        fetched[first] = f.result()
                        if fetched[first].ws_exc is not None:
                            # S2: brzdění Webshare / paměť uvnitř dotazu (S31 ho už nepouští ven) → stejná pojistka
                            _note_fetch_pressure(fetched[first].ws_exc, pool_size, pool_src, pool_fallback_reduces,
                                                 self._log)
                            fetched[first].ws_exc = None   # výjimka se zásobníkem nemá žít s výsledkem vlny
                    except SearchCancelled:
                        _cancelled = True
                    except Exception as _wave_exc:
                        # Beta.7 fix: log per-query exception místo silent
                        # swallow. Když všechny queries selžou, plugin pak může
                        # rozlišit "0 výsledků" vs "selhání" pro user-facing
                        # error message. Legacy behavior (no raise) zachováno —
                        # jednotlivé selhání nesmí přerušit celou vlnu.
                        errors += 1
                        fetched[first].error = "query"
                        self._log("WAVE_QUERY_ERR", repr(_wave_exc)[:200])
                        _note_fetch_pressure(_wave_exc, pool_size, pool_src, pool_fallback_reduces, self._log)
                    if _cancelled:
                        # Φ5A: čekající dotazy se už nespustí (běžící dojedou do svého timeoutu)
                        for _pending in futs:
                            _pending.cancel()
                        break
                    if progress_cb:
                        progress_cb(idx, total_q, "search")
        for q, idxs in todo.items():
            src = fetched[idxs[0]]
            if memo is not None and not src.error and not _cancelled:
                memo[q] = src
            for dup in idxs[1:]:
                fetched[dup] = src.as_reused()
                fetched[dup].error = src.error
                self._log("FETCH_REUSED", q, len(src.items))
        # selhání ZDROJE (Webshare nebo Fastshare) uvnitř jinak doběhlého dotazu = neúplný výsledek (R2); celé
        # selhání dotazu (`query`) se započítalo už výše
        errors += sum(1 for x in fetched if x.error and x.error != "query" and not x.reused)
        if stats is not None and any("rate_limited" in (x.ws_error, x.fs_error) for x in fetched):
            stats["rate_limited"] = True      # 429 od zdroje: hledání na pozadí nahlásí odklad na účet (Televize, §10.5)
        if stats is not None:
            stats["errors"] = int(stats.get("errors", 0)) + errors
        if _cancelled or (_cancel_check is not None and _cancel_check()):
            # Φ5A (R2): zrušená vlna NIC nekešuje a nespouští MI2 — částečný výsledek není hotový
            self._log("WAVE_CANCELLED", sum(len(x.items) for x in fetched))
            if stats is not None:
                stats["cancelled"] = True
            return None
        return fetched

    def _note_partial_hit(self, cache_key: str, stats: Optional[dict]) -> None:
        """Výsledek z cache pochází z vlny, ve které selhal dotaz → volající ho MUSÍ vidět jako neúplný
        (`stats["errors"]`), jinak by se z něj odvozený závěr bral jako autoritativní (R2; cross-check Pro A1)."""
        try:
            if not SEARCH_CACHE.is_partial(cache_key):
                return
            self._log("CACHE_HIT_PARTIAL", cache_key)
            if stats is not None:
                stats["errors"] = int(stats.get("errors", 0) or 0) + 1
                stats["cache_partial"] = True
        except Exception as exc:
            self._log("CACHE_HIT_PARTIAL_ERR", cache_key, repr(exc)[:200])

    def _cache_wave_result(self, cache_key: str, result: Sequence["Release"], wave_errors: int) -> None:
        """Uloží výsledek vlny do cache hledání. Vlna, ve které selhal některý dotaz (Webshare nebo
        Fastshare), je NEÚPLNÁ: uloží se jen na `PARTIAL_RESULT_TTL_S` — to stačí na překreslení téhož
        výpisu (obnova po MediaInfo spouští hledání znovu a čte cache), ale výpadek zdroje se tím
        nezapamatuje na 30 dní (R2: selhání se neperzistuje; cross-check Flash F3/F4, 30.09.2026)."""
        try:
            if wave_errors > 0:
                SEARCH_CACHE.put(cache_key, [asdict(r) for r in result], ttl_s=PARTIAL_RESULT_TTL_S)
                self._log("CACHE_PUT_PARTIAL", cache_key, len(result), "errors=%d" % wave_errors,
                          "ttl_s=%d" % PARTIAL_RESULT_TTL_S)
            else:
                SEARCH_CACHE.put(cache_key, [asdict(r) for r in result])
                self._log("CACHE_PUT", cache_key, len(result))
        except Exception as exc:
            self._log("CACHE_PUT_ERR", cache_key, repr(exc)[:200])

    def _union_fetched(self, fetched: Sequence[FetchResult]) -> Tuple[List[dict], dict]:
        """Sjednocení syrových položek dotazů (SSOT `rm_core.dedupe.union_fetched`)."""
        return _rm_dedupe.union_fetched(fetched, self._log)

    def _log_wave_yield(self, fetched: Sequence[FetchResult], origin: dict,
                        accepted: Sequence["Release"]) -> None:
        """Výtěžnost dotazů vlny do logu (`WAVE_YIELD`) — SSOT `rm_core.dedupe.log_wave_yield`."""
        _rm_dedupe.log_wave_yield(fetched, origin, accepted, self._log)

    def _log_wave_timing(self, t_fetch: float, t_filter: float) -> None:
        """Rozpad času vlny do logu: stažení (souběžně, čas na hodinách) a filtr (CPU)."""
        try:
            self._log("WAVE_TIMING", json.dumps({
                "fetch_ms": int((t_filter - t_fetch) * 1000),
                "filter_ms": int((time.monotonic() - t_filter) * 1000)}))
        except Exception:
            pass

    @staticmethod
    def _apply_origin(releases: Sequence["Release"], origin: dict) -> None:
        """Původ (dotazy a stránky) na přijaté položky — SSOT `rm_core.dedupe.apply_origin`."""
        _rm_dedupe.apply_origin(releases, origin)

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # _tv_filter  (Φ-A 30.09.2026 — tělo filtru dílu vyčleněné ze `search_one`, rozhodnutí beze změny)
    # ---------------------------------------------------------------------------- #
    def _tv_filter(  # noqa: C901
        self,
        ws_items: List[dict],
        *,
        label: str,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        ser_title_variants: Sequence[Sequence[str]] = (),
        banned_keys: Sequence[str] = (),
        ep_title_variants: Sequence[Sequence[str]] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] | None = None,
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        probe: bool = True,
        ep_soft: bool = False,
        ban_other_episodes: bool = False,
        scope: bool = False,
        homonym_variants: Sequence[Sequence[str]] = (),
    ) -> List["Release"]:
        """Filtr dílu (SSOT `rm_core.filter_tv.filter_tv_items`). Rozhodnutí je čistě po položkách; síťová část
        (MediaInfo) je injektovaná `_probe_many`."""
        return _rm_filter_tv.filter_tv_items(
            ws_items, label=label, log=self._log, runtimes=runtimes, title_norms=title_norms,
            ser_title_variants=ser_title_variants, banned_keys=banned_keys, ep_title_variants=ep_title_variants,
            movie_year=movie_year, allowed_years=allowed_years, bad_regex=bad_regex, progress_cb=progress_cb,
            probe=probe and self._enable_probe, ep_soft=ep_soft, ban_other_episodes=ban_other_episodes, scope=scope,
            banned_re_cache=self._banned_re_cache, probe_many=self._probe_many, homonym_variants=homonym_variants)

    def _probe_many(self, probe_cand: List["Release"],
                    progress_cb: Optional[Callable[[int, int, str], None]] = None) -> None:
        """MediaInfo probe vybraných kandidátů filtru (paralelně, Android 2 vlákna); selhání položky hledání nezastaví."""
        total = len(probe_cand)

        def _wrap(r: "Release", idx: int) -> None:
            self._probe(r)
            if progress_cb:
                progress_cb(idx, total, "probe")

        with _f.ThreadPoolExecutor(max_workers=_pool_size(5)) as pool:
            for f in (pool.submit(_wrap, r, i) for i, r in enumerate(probe_cand, 1)):
                try:
                    f.result()
                except Exception as _pf_e:
                    # Dřív tiché: pád probe workeru (MI hint chybí).
                    _diag_log(f"probe future fail: {_pf_e}", 0)






    def search_movie_one(  # 2025-09-27 12:03 CEST (Europe/Prague)               # noqa: C901


        self,
        query: str,
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] = (),
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
        probe: bool = True,
    ) -> List["Release"]:
        """
        FILMOVÁ varianta search_one() – logiku zachovává, ALE:
        • `banned_keys` už se běžně používá (předává plugin)
        • NOVĚ: `FILTER_ACCEPT` loguje **důvod průchodu** (JSON),
            abychom v ladicím logu přesně viděli, co rozhodlo.

        Sprint 2026-05-02 (P0) — Gate /v1/search PATH DROPPED:
          Phase 3c experiment (2026-04-19 → 2026-04-30) byla odstraněna.
          Důvod: Gate-side ranking/filter nedosahoval parity s addon-side
          ReleaseFilter (banned_keys z TMDb collection_parts, year_whitelist
          z release_dates per country, title_penalty token-aware match,
          runtime_sanity ±10%) — half-year-tuned heuristics. Aktivace Gate
          path (test 2026-04-30 14:42, Metráček 1972) vrátila 71 releases
          zaplavených 1972-junk filmy s actual Metráček.avi na pozici #47.
          Filter parity port (option B, ~3 dny) nedával ROI smysl pro hobby
          projekt — option A (drop) gives clean SSOT (single ReleaseFilter
          implementation in addon). Plan: Handoff/session_2026-05-02_drop_
          gate_search_settings_ssot.md.
        """
        items = self._movie_fetch(query, cancel_check=cancel_check)
        return self._movie_filter(
            items, label=query, runtimes=runtimes, title_norms=title_norms, banned_keys=banned_keys,
            movie_year=movie_year, allowed_years=allowed_years, bad_regex=bad_regex,
            progress_cb=progress_cb, probe=probe,
        )

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # _movie_fetch / _movie_filter  (Φ5B, 29.09.2026 — rozděleno ze search_movie_one, audit A06 R05)
    # ---------------------------------------------------------------------------- #
    def _movie_fetch(self, query: str, *, cancel_check: Optional[Callable[[], bool]] = None) -> List[dict]:
        """Syrové položky jednoho dotazu: stránky Webshare + Fastshare, sloučené (`_dedupe_multi_source`).
        Jen síť a logy dotazu — žádné rozhodování filtru."""
        return self._fetch_query(query, raw_event="RAW_MOVIE_SEARCH", cancel_check=cancel_check).items

    def _movie_filter(
        self,
        ws_items: List[dict],
        *,
        label: str,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] = (),
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        probe: bool = True,
    ) -> List["Release"]:
        """Filtr filmu (SSOT `rm_core.filter_movie.filter_movie_items`)."""
        return _rm_filter_movie.filter_movie_items(
            ws_items, label=label, log=self._log, runtimes=runtimes, title_norms=title_norms, banned_keys=banned_keys,
            movie_year=movie_year, allowed_years=allowed_years, bad_regex=bad_regex, progress_cb=progress_cb,
            probe=probe and self._enable_probe, probe_many=self._probe_many, today_year=self._today().year)








    def search_movie_wave(  # 14.12.2025 20:36 CET (Europe/Prague)               # noqa: C901
        self,
        queries: Sequence[str],
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] = (),      # ← NOVĚ: posíláme z pluginu
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        max_quick_probe: int = 0,
        top_full_probe: int = 15,
        stats: Optional[dict] = None,          # Φ-A: výstup pro volajícího (errors, cancelled, cache_hit)
        fetch_memo: Optional[dict] = None,     # Φ-C: paměť stažených dotazů TOHOTO hledání (viz `_fetch_wave`)
        kick_mi2: bool = True,                 # False = hledání na pozadí bez skenu MediaInfo
    ) -> List["Release"]:
        """
        14.12.2025 20:36 CET (Europe/Prague)

        Filmová vlna s 30denní cache. Cache-klíč nově zahrnuje i whitelist roků,
        aby se nepletly výsledky mezi různými pravidly povolených roků.
        """
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT

        # 1) CACHE – klíč = dotazy + (rok) + (seznam povolených roků)
        extra = f":{movie_year}" if movie_year else ""
        years_tag = f":{','.join(str(y) for y in sorted(set(allowed_years)))}" if allowed_years else ""
        cache_key = SEARCH_CACHE.build_key("movie", *sorted(queries)) + extra + years_tag
        cached = SEARCH_CACHE.get(cache_key)
        _from_cache = releases_from_records(cached, self._log) if cached else None
        if _from_cache is not None:
            self._log("CACHE_HIT", cache_key, len(_from_cache))
            if stats is not None:
                stats["cache_hit"] = True
            self._note_partial_hit(cache_key, stats)
            return _from_cache

        # 2) Paralelní hledání
        # Φ5B (29.09.2026, audit A06 R05): dotazy se STÁHNOU souběžně (jen síť), syrové položky se sjednotí
        # podle identu a filtr proběhne JEDNOU. Dřív každý dotaz filtroval sám → tytéž soubory ~3,3× a na
        # Androidu (2 vlákna) filtr blokoval síť dalších dotazů (4 dotazy: 12,3 s oproti 0,6 s na desktopu).
        # Φ-A (30.09.2026): stahování i sjednocení = SSOT společné se seriálem; sjednocení drží PŮVOD identu.
        _t_fetch = time.monotonic()
        _wstats = stats if stats is not None else {}
        _err0 = int(_wstats.get("errors", 0) or 0)
        fetched = self._fetch_wave(queries, raw_event="RAW_MOVIE_SEARCH", progress_cb=progress_cb, stats=_wstats,
                                   memo=fetch_memo)
        if fetched is None:
            return []
        _t_filter = time.monotonic()
        union, origin = self._union_fetched(fetched)
        all_items: List[Release] = self._movie_filter(
            union, label=" | ".join(queries), runtimes=runtimes, title_norms=title_norms,
            banned_keys=banned_keys, movie_year=movie_year, allowed_years=allowed_years,
            bad_regex=bad_regex, progress_cb=progress_cb, probe=False,
        )
        self._apply_origin(all_items, origin)
        self._log_wave_yield(fetched, origin, all_items)
        self._log_wave_timing(_t_fetch, _t_filter)

        # 3) Deduplikace ID → (size, ext) — SSOT `rm_core.dedupe.dedupe_movie_wave`
        result = _rm_dedupe.dedupe_movie_wave(all_items, self._log)

        # 4) Uložit do cache
        self._cache_wave_result(cache_key, result, int(_wstats.get("errors", 0) or 0) - _err0)

        if not kick_mi2:
            return result

        # 5) MI2 lazy-enrichment: rozjeď krokové zjišťování MediaInfo (FILMY parity se SERIÁLY)
        #    Pozn.: richmovie_mi2 importuje richmovie_engine → proto lazy import až tady, aby nevznikl circular import.
        try:
            from richmovie_mi2 import MediaInfoSecondEdition as _MI2
            _MI2.start(
                releases=result[:32],        # skenuj jen rozumný „viditelný” výřez
                client_factory=self._get_client,
                fs_client_factory=self._get_fs_client,  # 21.02.2026 – Fastshare MI2 podpora
                first_batch=8,               # první refresh po ~8 položkách
                max_items=32,
                refresh=True,
                key=_listing_key(),
            )
            # Log pro rychlou diagnostiku – uvidíš v kodi.log
            self._log(
                "MI2_START",
                f"count={min(len(result), 32)} first_batch=8 refresh=True",
            )
        except Exception as _mi2_err:
            self._log("MI2_KICK_FAIL", str(_mi2_err))

        return result








    # `_quick_duration` (HTTP HEAD pro odhad stopáže) ODSTRANĚNA ve Φ4 (29.09.2026): nikdo ji nevolal
    # a kvůli ní se při každém kliku importoval `requests` (audit A08 F2).

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # search_wave (upraveno: 27.12.2025 19:52 CET (Europe/Prague) – SANITIZE: CACHE_HIT title_penalty:
    #   (1) title_penalty se dopočítá jen pro skutečně “one-word” seriály (primary TMDb varianta po STOP/epi filtraci),
    #   (2) tokeny z TMDb variant názvu seriálu nikdy nesmí být penalizovány jako “bad”,
    #   (3) zachováno: title_penalty i na CACHE_HIT + MI2 kick i na CACHE_HIT + ser_title_variants (OR přes varianty názvu))
    # ---------------------------------------------------------------------------- #
    def search_wave(  # noqa: C901
        self,
        queries: Sequence[str],
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        ser_title_variants: Sequence[Sequence[str]] = (),  # 26.12.2025 – OR přes varianty názvu seriálu
        banned_keys: Sequence[str] = (),
        ep_title_variants: Sequence[Sequence[str]] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] | None = None,   # 2025-08-19 10:39 CEST (Europe/Prague)
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        max_quick_probe: int = 0,
        top_full_probe: int = 15,
        ep_soft: bool = False,  # 2025-11-15 19:16 CET (Europe/Prague) – SOFT režim pro Vlnu X
        ban_other_episodes: bool = False,   # Φ5B: zákaz jiného dílu kódem
        homonym_variants: Sequence[Sequence[str]] = (),  # jádro 1.2.2 F2: varianty názvu, které nese i jiný seriál
        stats: Optional[dict] = None,       # Φ-A: výstup pro volajícího (errors, cancelled, cache_hit)
        fetch_memo: Optional[dict] = None,  # Φ-C: paměť stažených dotazů TOHOTO hledání (viz `_fetch_wave`)
        kick_mi2: bool = True,              # False = hledání na pozadí bez skenu MediaInfo
    ) -> List["Release"]:
        """
        Paralelní vlna vyhledávání + dvojí deduplikace **S PODPOROU CACHE**.

        Nově (07/2025)
        ---------------
        • Před samotným hledáním zkusí načíst výsledek z `SEARCH_CACHE`
          (TTL 30 dní).
        • Po úspěšném hledání uloží seřazený list do cache.

        Úprava (2025-09-07)
        -------------------
        • Po sestavení výsledků se **asynchronně** startne MI2 (MediaInfo
          „second edition“) pro **lazy** doplnění „CZ dabing / CZ titulky“,
          a zapíše se log `MI2_START …`. GUI refresh zajišťuje MI2 modul.

        Úprava (2025-11-15 20:52 CET)
        ------------------------------
        • Cache klíč pro TV hledání rozšířen o příznak režimu `:strict`/`:soft`,
          aby se nepletly výsledky přísných a tolerantních vln (důležité pro
          kombinaci „TV dotaz“ + následná Vlna X s `ep_soft=True`).

        Úprava (26.12.2025)
        -------------------
        • Při `CACHE_HIT` se nově **také** provede MI2 kick, jinak u seriálů po
          cache-hitu často nevzniknou toasty + finální refresh.
        • Forwardujeme `ser_title_variants` až do `search_one` (OR přes varianty názvu).

        Úprava (27.12.2025)
        -------------------
        • SANITIZE (CACHE_HIT title_penalty):
          - title_penalty se dopočítá jen pro skutečně “one-word” seriály (primary TMDb varianta),
          - tokeny z TMDb variant názvu seriálu se nikdy nesmí penalizovat jako “bad”.
        """
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT

        # 🔸 1) CACHE – zkusíme nejprve rychle vrátit uložené výsledky
        years_tag = (
            f":{','.join(str(y) for y in sorted(set(allowed_years or ())))}"
            if allowed_years else ""
        )
        soft_tag = ":soft" if ep_soft else ":strict"
        # jádro 1.2.2 F2: výsledek filtru závisí i na stejnojmenných variantách z TMDb (příznak `uncertain`) — bez nich
        # v klíči by výpis z výpadku TMDb (bez ochrany) držela mezipaměť 30 dní
        _hom = sorted(" ".join(v) for v in (homonym_variants or ()) if v)
        hom_tag = (":hom=" + hashlib.sha1("|".join(_hom).encode("utf-8")).hexdigest()[:10]) if _hom else ""
        cache_key = (
            SEARCH_CACHE.build_key("tv", *sorted(queries))
            + years_tag
            + soft_tag   # 2025-11-15 20:52 CET (Europe/Prague) – rozlišení strict/soft režimu
            + hom_tag
        )
        cached = SEARCH_CACHE.get(cache_key)
        result = releases_from_records(cached, self._log) if cached else None
        if result is not None:
            self._log("CACHE_HIT", cache_key, len(result))

            if stats is not None:
                stats["cache_hit"] = True
            self._note_partial_hit(cache_key, stats)

            # 🔸 1b) SPEC: jednoslovné seriály – title_penalty i na CACHE_HIT
            # Stará cache (bez title_penalty) se dopočítá i tady — STEJNOU funkcí jako hlavní cesta
            # (`tv_title_penalty`, včetně výjimky HΦ5; dřív druhá kopie výpočtu bez ní — E3-F04).
            try:
                fc = tv_filter_context(title_norms, ser_title_variants, ep_title_variants)
                if fc.one_word_set and fc.codes:
                    for r in result:
                        try:
                            penalty, _pen_events = tv_title_penalty(getattr(r, "name", "") or "", fc)
                        except Exception as _pen_exc:
                            penalty = 0
                            self._log("TITLE_PENALTY_ERR", getattr(r, "ident", ""), repr(_pen_exc)[:200])
                        try:
                            setattr(r, "title_penalty", int(penalty))
                        except Exception:
                            pass
                        try:
                            base_score = ReleaseFilter.compute_score(r)
                            setattr(r, "score", tuple(base_score) + (int(penalty),))
                        except Exception:
                            pass
                    try:
                        result.sort(key=lambda x: score_sort_key(getattr(x, "score", None)))
                    except Exception:
                        pass
            except Exception:
                pass

            if not kick_mi2:
                return result

            # ✅ MI2 kick i na CACHE_HIT (jinak u seriálů po cache-hitu často chybí toasty + finální refresh)
            try:
                from richmovie_mi2 import MediaInfoSecondEdition as _MI2
                _MI2.start(
                    releases=result[:32],
                    client_factory=self._get_client,
                    fs_client_factory=self._get_fs_client,  # 21.02.2026 – Fastshare MI2 podpora
                    first_batch=8,
                    max_items=32,
                    refresh=True,
                    key=_listing_key(),
                )
                self._log("MI2_START", "ctx=search_wave_cache", f"count={min(len(result), 32)}")
            except Exception as _mi2_err:
                self._log("MI2_KICK_FAIL", str(_mi2_err))

            return result

        # 🔸 2) Stažení dotazů vlny souběžně → sjednocení podle identu → filtr JEDNOU -------------
        # Φ-A (30.09.2026, E4-F02): dřív každý dotaz filtroval sám (`search_one` ve vlákně) → tentýž soubor
        # se posuzoval až 6× (82 % posouzení opakovaných). Rozhodnutí na dotazu nezávisí, výsledek je shodný
        # (brána `full_replay diff`); který dotaz soubor našel, drží `WAVE_ORIGIN` a `Release.origin`.
        _t_fetch = time.monotonic()
        _wstats = stats if stats is not None else {}
        _err0 = int(_wstats.get("errors", 0) or 0)
        fetched = self._fetch_wave(queries, raw_event="RAW_SEARCH", progress_cb=progress_cb, stats=_wstats,
                                   memo=fetch_memo)
        if fetched is None:
            return []
        _t_filter = time.monotonic()
        union, origin = self._union_fetched(fetched)
        all_items: List[Release] = self._tv_filter(
            union, label=" | ".join(queries), scope=True, runtimes=runtimes, title_norms=title_norms,
            ser_title_variants=ser_title_variants, banned_keys=banned_keys,
            ep_title_variants=ep_title_variants, movie_year=movie_year, allowed_years=allowed_years,
            bad_regex=bad_regex, progress_cb=progress_cb,
            probe=(top_full_probe > 0 or max_quick_probe > 0),
            ep_soft=ep_soft, ban_other_episodes=ban_other_episodes, homonym_variants=homonym_variants,
        )
        self._apply_origin(all_items, origin)
        self._log_wave_yield(fetched, origin, all_items)
        self._log_wave_timing(_t_fetch, _t_filter)

        # ––– (DE-DUP #1 a #2) ––– SSOT `rm_core.dedupe.dedupe_tv_wave` (WS má přednost před FS při shodném score)
        result = _rm_dedupe.dedupe_tv_wave(all_items, self._log)

        # 4) Uložit do cache
        self._cache_wave_result(cache_key, result, int(_wstats.get("errors", 0) or 0) - _err0)

        if not kick_mi2:
            return result

        # 5) MI2 lazy-enrichment: rozjeď krokové zjišťování MediaInfo (FILMY parity se SERIÁLY)
        #    Pozn.: richmovie_mi2 importuje richmovie_engine → proto lazy import až tady, aby nevznikl circular import.
        try:
            from richmovie_mi2 import MediaInfoSecondEdition as _MI2
            _MI2.start(
                releases=result[:32],        # skenuj jen rozumný „viditelný” výřez
                client_factory=self._get_client,
                fs_client_factory=self._get_fs_client,  # 21.02.2026 – Fastshare MI2 podpora
                first_batch=8,               # první refresh po ~8 položkách
                max_items=32,
                refresh=True,
                key=_listing_key(),
            )
            self._log(
                "MI2_START",
                f"count={min(len(result), 32)} first_batch=8 refresh=True",
            )
        except Exception as _mi2_err:
            self._log("MI2_KICK_FAIL", str(_mi2_err))

        return result









    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    #  INTERNALS
    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    # 2025-09-07 15:14 CEST (Europe/Prague)
    def _probe(self, r: Release) -> None:
        """
        ÚČEL: Jediným síťovým dotazem vytáhnout MediaInfo (± pár MB, Range) a
        doplnit:
          • odhad délky (minuty) do `r.est_min`
          • syrové MI do `r.mediainfo` (+ RAM cache)
          • NOVĚ: sloučit jazyky z MI do `r.audios` / `r.subs` (super‑set)

        Zachována původní logika a limity (bez změny paralelizace).
        """
        if getattr(r, "mediainfo", None):
            return  # už máme

        mi = self._get_client().probe_mediainfo(r.ident)
        if not mi:
            return

        # – délka (sekundy → minuty) –
        if mi.get("duration"):
            r.est_min = mi["duration"] // 60

        # – jazyky z MediaInfo (sloučení s tím, co padlo z názvu souboru) –
        try:
            aud_mi, sub_mi = extract_langs_from_mediainfo(mi)
            if aud_mi:
                r.audios = sorted(set(r.audios) | set(aud_mi))
            if sub_mi:
                r.subs   = sorted(set(r.subs)   | set(sub_mi))
        except Exception:
            # selhání extrakce jazyků nesmí shodit sondu
            pass

        # – ulož do objektu i do sdílené RAM cache –
        r.mediainfo = mi
        with self._lock:
            self._mi_cache[r.ident] = mi



    # ------------------------------------------------------------------ #
    def get_mediainfo(self, ident: str) -> Optional[dict]:
        """
        Vrátí MediaInfo z RAM cache; pokud tam není, stáhne je jednorázově
        a uloží do cache.  Nikdy nestahuje víc než oněch ≈ 5 MB.
        """
        with self._lock:
            if ident in self._mi_cache:
                return self._mi_cache[ident]

        mi = self._get_client().probe_mediainfo(ident)
        if mi:
            with self._lock:
                self._mi_cache[ident] = mi
        return mi




# 2025-09-07 16:46 CEST (Europe/Prague)
# ─────────────────────────────────────────────────────────────────────────────
#  MediaInfo 2nd-pass – thread-safe hinty pro LabelFormatter (CZ dabing/titulky)
#  13.12.2025 17:19 CET – NOVĚ: perzistence na disk (mi2_cache.json) + robustní normalizace
# ─────────────────────────────────────────────────────────────────────────────
_MI2_HINTS: dict[str, dict] = {}
_MI2_LOCK  = threading.Lock()

# disková cache (kvůli Container.Refresh, které často spustí listing v nové instanci)
_MI2_DISK: dict[str, dict] = {}
_MI2_DISK_LOADED: bool = False
_MI2_DISK_STAMP: Optional[tuple] = None     # otisk souboru (mtime_ns, velikost), ze kterého je `_MI2_DISK`


def _mi2_file_stamp() -> Optional[tuple]:
    if not _MI2_CACHE_PATH:
        return None
    try:
        st = os.stat(_MI2_CACHE_PATH)
        return (int(st.st_mtime_ns), int(st.st_size))
    except OSError:
        return None


def _log_mi2_warning(text: str) -> None:
    try:
        xbmc.log("[RichMovie] %s" % text, xbmc.LOGWARNING)
    except Exception:
        pass
_MI2_TTL_SECS: int = 180 * 24 * 60 * 60  # 180 dní (metadata jazyků se prakticky nemění)

#  21.12.2025 17:58 CET (Europe/Prague)
# FÁZE 2: debounce zápisu mi2_cache.json (disk I/O optimalizace)
_MI2_DISK_DIRTY: bool = False
_MI2_DISK_DIRTY_COUNT: int = 0
_MI2_DISK_LAST_FLUSH_TS: int = 0

# Debounce flush – disk je pomalý a mi2_publish může běžet ve smyčce nad 20+ releasy.
# Hodnoty jsou konzervativní: chceme výrazně snížit I/O, ale pořád průběžně perzistovat.
_MI2_DISK_FLUSH_MIN_INTERVAL_SECS: int = 1          # max 1× za sekundu
_MI2_DISK_FLUSH_EVERY_N_CHANGES: int = 10           # nebo po 10 změnách

# 21.02.2026 – FÁZE B: retry politika pro negativní cache (exponenciální backoff)
# Formát: {reason: (base_delay_secs, multiplier, max_retries, permanent_after_days)}
#   base_delay_secs     – čekání před prvním retry (po retry_count=0)
#   multiplier          – delay = base * multiplier^retry_count (s capem)
#   max_retries         – po vyčerpání je fail permanentní
#   permanent_after_days – absolutní strop od prvního selhání (pojistka)
_MI2_RETRY_POLICY: dict[str, tuple[int, float, int, int]] = {
    #                    base_delay  mult  max_retries  permanent_after_days
    "timeout":          (   3600,    2.0,      5,             30),   # 1h→2h→4h→8h→16h → permanent
    "error":            (   7200,    2.0,      4,             30),   # 2h→4h→8h→16h → permanent
    "empty":            (  86400,    3.0,      2,             14),   # 1d→3d → permanent
    # 3.5.129 (incident PeterFM): odkaz autoritativně nevydal médium (HTML stránka
    # Free účtu, CDN 4xx). Je to vlastnost ÚČTU/IP/odkazu, ne souboru — po obnovení
    # VIP soubor hraje. Proto prakticky nikdy permanentní: backoff 1h→2h→…→ strop
    # 7 dní (_MI2_RETRY_MAX_DELAY_SECS) a pak týdenní opakování; permanentní až po
    # 365 pokusech (~7 let), permanent_after_days=0 = absolutní strop vypnutý.
    "not_media":        (   3600,    2.0,    365,              0),
}
# 4.5.3 (15.11.2026, „zprovoznit mi2 u mp4“): důvody, které už nikdo nezapisuje — značka = jako by záznam nebyl (sonda hned).
# `skip_mp4` = doplněk MP4 záměrně neměřil (Gate četl jen začátek, `moov` za daty nenašel); od nové sondy Gate (atomy ISO
# BMFF) se MP4 měří jako ostatní a staré značky z disků flotily se tím samy přepíšou, bez jednorázové migrace.
_MI2_OBSOLETE_FAIL_REASONS: frozenset = frozenset({"skip_mp4"})
_MI2_RETRY_MAX_DELAY_SECS: int = 7 * 24 * 60 * 60   # cap 7 dní (pojistka proti přetečení)
_MI2_RETRY_DEFAULT_POLICY: tuple[int, float, int, int] = (7200, 2.0, 3, 30)  # pro neznámé reason
_MI2_MAX_ENTRIES: int = 5000  # max počet záznamů v disk cache (ochrana proti OOM)



try:
    _MI2_ADDON_ID = xbmcaddon.Addon().getAddonInfo("id")
    _MI2_PROFILE_DIR = xbmcvfs.translatePath(f"special://profile/addon_data/{_MI2_ADDON_ID}")
except Exception:
    _MI2_PROFILE_DIR = ""

_MI2_CACHE_PATH = os.path.join(_MI2_PROFILE_DIR, "mi2_cache.json") if _MI2_PROFILE_DIR else ""







def _mi2_now_ts() -> int:
    try:
        return int(datetime.datetime.now().timestamp())
    except Exception:
        return 0


# 21.02.2026 – FÁZE B: retry helper funkce
def _mi2_compute_next_retry_ts(reason: str, retry_count: int, last_fail_ts: int) -> int:
    """Vypocita next_retry_ts pro fail marker.  Vraci 0 = permanentni (zadne dalsi retry)."""
    policy = _MI2_RETRY_POLICY.get(reason, _MI2_RETRY_DEFAULT_POLICY)
    base_delay, multiplier, max_retries, _perm_days = policy
    if max_retries <= 0 or base_delay <= 0:
        return 0
    if retry_count >= max_retries:
        return 0
    delay = base_delay * (multiplier ** retry_count)
    delay = int(min(delay, _MI2_RETRY_MAX_DELAY_SECS))
    return last_fail_ts + delay


def _mi2_fail_is_retryable(fail: dict, disk_ts: int = 0) -> bool:
    """Rozhodne, zda je fail marker zpusobily pro re-probe (retry je na rade).

    Args:
        fail:    sub-dict "fail" z MI2 cache val
        disk_ts: casovy razitko obalu na disku (fallback pro stare zaznamy)

    Returns:
        True  = ident by se mel znovu probovat
        False = jeste v backoff okne nebo permanentne selhal
    """
    if not isinstance(fail, dict):
        return False

    reason = str(fail.get("reason", "")).strip()
    if reason in _MI2_OBSOLETE_FAIL_REASONS:
        return True                       # zastaralá značka (např. skip_mp4) = změřit znovu hned
    policy = _MI2_RETRY_POLICY.get(reason, _MI2_RETRY_DEFAULT_POLICY)
    base_delay, multiplier, max_retries, permanent_after_days = policy

    # Permanentni reason nebo nulova konfigurace
    if max_retries <= 0 or base_delay <= 0:
        return False

    # Metadata z fail markeru (zpetne kompatibilni defaulty)
    retry_count = int(fail.get("retry_count", 0) or 0)
    first_fail_ts = int(fail.get("first_fail_ts", 0) or 0)
    last_fail_ts = int(fail.get("last_fail_ts", 0) or 0)
    next_retry_ts = int(fail.get("next_retry_ts", 0) or 0)

    # Backward compat: stare zaznamy nemaji timestampy → pouzij disk_ts
    if not last_fail_ts:
        last_fail_ts = disk_ts or 0
    if not first_fail_ts:
        first_fail_ts = last_fail_ts

    now = _mi2_now_ts()

    # Pojistka: absolutni strop od prvniho selhani
    if permanent_after_days > 0 and first_fail_ts > 0:
        ceiling = first_fail_ts + (permanent_after_days * 86400)
        if now > ceiling:
            return False

    # Max retries vycerpany
    if retry_count >= max_retries:
        return False

    # Preferovana cesta: predpocitane next_retry_ts
    if next_retry_ts > 0:
        return now >= next_retry_ts

    # Fallback: vypocet z last_fail_ts + backoff (pro stare zaznamy)
    if last_fail_ts <= 0:
        return True  # zadne casove info → povol retry
    delay = base_delay * (multiplier ** retry_count)
    delay = int(min(delay, _MI2_RETRY_MAX_DELAY_SECS))
    return now >= (last_fail_ts + delay)


def _mi2_ensure_dir() -> None:
    """Best-effort vytvoření profilu doplňku (pro zápis mi2_cache.json)."""
    try:
        if _MI2_PROFILE_DIR and (not xbmcvfs.exists(_MI2_PROFILE_DIR)):
            xbmcvfs.mkdirs(_MI2_PROFILE_DIR)
    except Exception:
        pass





def _mi2_load_disk_locked() -> None:
    """Načte mi2_cache.json do RAM (jen jednou) + provede TTL purge.

    21.12.2025 17:58 CET (Europe/Prague)

    FÁZE 2 – optimalizace:
      • TTL purge už při načtení může odstranit staré položky.
        Původně se tím jen zmenšila RAM reprezentace, ale soubor na disku zůstal
        “nafouknutý”.
      • NOVĚ: při purge označíme diskovou cache jako “dirty” a necháme ji
        zapsat až debouncovaně (nebo force před Container.Refresh).
    """
    global _MI2_DISK_LOADED, _MI2_DISK, _MI2_DISK_STAMP
    global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT

    # Φ-E (30.09.2026, audit Fable F2-V2): MediaInfo je od 3.5.173 vstupem řazení (kvalita, dabing, délka).
    # Služba žije dny a plugin je nový proces na každé kliknutí — co změřil jeden, musí vidět druhý, jinak
    # automatický výběr a první řádek výpisu vyjdou různě. Soubor se proto čte znovu, když ho mezitím
    # změnil jiný proces (otisk); záznamy TOHOTO procesu, které ještě nejsou na disku, zůstávají.
    stamp = _mi2_file_stamp()
    if _MI2_DISK_LOADED and stamp == _MI2_DISK_STAMP:
        return

    mine = dict(_MI2_DISK) if (_MI2_DISK_LOADED and _MI2_DISK_DIRTY) else {}
    _MI2_DISK_LOADED = True
    _MI2_DISK_STAMP = stamp
    if stamp is None:
        _MI2_DISK = mine
        return

    try:
        with open(_MI2_CACHE_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh) or {}
        disk = raw if isinstance(raw, dict) else {}
    except Exception as exc:
        # nečitelný soubor (zámek jiného procesu): pracuje se s tím, co je v paměti, příště znovu
        _MI2_DISK_STAMP = ("unreadable",)
        _log_mi2_warning("mi2 cache unreadable now: %r" % (exc,))
        return
    for k, v in mine.items():
        if (v or {}).get("ts", 0) >= (disk.get(k) or {}).get("ts", 0):
            disk[k] = v
    _MI2_DISK = disk

    # TTL purge
    try:
        cut = _mi2_now_ts() - _MI2_TTL_SECS
        stale = [k for k, v in (_MI2_DISK or {}).items() if (v or {}).get("ts", 0) < cut]
        for k in stale:
            _MI2_DISK.pop(k, None)

        # FÁZE 2: purge označíme jako “dirty”, ale NEflushujeme hned (aby listing neškubal diskem)
        if stale:
            _MI2_DISK_DIRTY = True
            _MI2_DISK_DIRTY_COUNT += len(stale)
    except Exception:
        pass

    # Max size cap to prevent OOM on low-memory devices
    try:
        if len(_MI2_DISK) > _MI2_MAX_ENTRIES:
            # Evict oldest entries by timestamp
            sorted_keys = sorted(
                _MI2_DISK,
                key=lambda k: float((_MI2_DISK[k] or {}).get("ts", 0) or 0),
            )
            for _ek in sorted_keys[:len(_MI2_DISK) - _MI2_MAX_ENTRIES]:
                _MI2_DISK.pop(_ek, None)
            _MI2_DISK_DIRTY = True
            _MI2_DISK_DIRTY_COUNT += len(sorted_keys) - _MI2_MAX_ENTRIES
    except Exception:
        pass





def _mi2_flush_disk_locked(*, force: bool = False) -> bool:
    """Zapíše mi2_cache.json (atomicky přes .tmp).

    21.12.2025 17:58 CET (Europe/Prague)

    FÁZE 2 – optimalizace:
      • Původně se flushovalo na disk po KAŽDÉ `mi2_publish()` → při 20 releasích = 20 zápisů celého JSON.
      • NOVĚ:
          - držíme “dirty” flag + počítadlo změn
          - flush je **debouncovaný** (max 1× za ~1s) nebo po N změnách
          - `force=True` obejde debounce (použijeme pro „kritické“ body)

    Pozn.:
      • Tato funkce předpokládá, že volající drží `_MI2_LOCK`.
    """
    global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT, _MI2_DISK_LAST_FLUSH_TS

    if not _MI2_CACHE_PATH:
        return False

    # Pokud není co zapisovat, nic nedělej (typicky: cache se jen četla)
    if (not force) and (not _MI2_DISK_DIRTY):
        return False

    now_ts = _mi2_now_ts()

    # Debounce: pokud jsme flushovali “před chvílí” a změn je málo, odlož zápis
    if not force:
        try:
            min_int = int(_MI2_DISK_FLUSH_MIN_INTERVAL_SECS or 1)
        except Exception:
            min_int = 1
        try:
            every_n = int(_MI2_DISK_FLUSH_EVERY_N_CHANGES or 10)
        except Exception:
            every_n = 10

        if _MI2_DISK_LAST_FLUSH_TS and (now_ts - int(_MI2_DISK_LAST_FLUSH_TS)) < max(1, min_int):
            if int(_MI2_DISK_DIRTY_COUNT or 0) < max(1, every_n):
                return False

    _mi2_ensure_dir()

    try:
        # 3.5.123: trvanlivý atomický zápis přes SSOT. Dřívější „fallback na
        # přímý zápis, když os.replace selže" byl přesně ten neatomický zápis,
        # před kterým měl replace chránit — selhání se teď hlásí, ne obchází.
        import richmovie_atomic as _atomic
        # Φ-C (30.09.2026, E4-F05): kompaktně — odsazení na Pythonu 3.8 vypíná rychlý kodér (59 → 16 ms na flush)
        if not _atomic.write_json(_MI2_CACHE_PATH, _MI2_DISK or {}, separators=(",", ":")):
            return False

        # Flush OK → reset “dirty”
        _MI2_DISK_DIRTY = False
        _MI2_DISK_DIRTY_COUNT = 0
        _MI2_DISK_LAST_FLUSH_TS = now_ts
        return True
    except Exception:
        return False







# ---------------------------------- METODA ---------------------------------- #
# richmovie_engine.py › mi2_flush_disk
# (vytvořeno: 21.12.2025 17:58 CET (Europe/Prague) – FÁZE 2: veřejný flush pro MI2; force=True pro „kritické“ body)
# ---------------------------------------------------------------------------- #
def mi2_flush_disk(*, force: bool = False) -> bool:
    """
    21.12.2025 17:58 CET (Europe/Prague)

    Veřejný flush pro MI2 disk cache (`mi2_cache.json`).

    Proč existuje:
      • Ve FÁZI 2 už `mi2_publish()` NEflushuje disk po každé položce.
      • Když Kodi udělá `Container.Refresh()`, často se listing vykreslí v nové instanci.
        Proto je občas potřeba umět disk flushnout “teď hned”.

    Použití:
      • MI2 worker volá před `Container.Refresh` (force=True)
      • kdokoli jiný může volat bez force – uplatní se debounce v `_mi2_flush_disk_locked`.
    """
    with _MI2_LOCK:
        _mi2_load_disk_locked()
        return _mi2_flush_disk_locked(force=bool(force))











# ---------------------------------- METODA ---------------------------------- #
# richmovie_engine.py › mi2_publish
# (upraveno: 22.12.2025 20:58 CET (Europe/Prague) – FÁZE A: negativní MI2 cache (fail marker) + merge-safe zachování původní logiky)
# ---------------------------------------------------------------------------- #
def mi2_publish(
    ident: str,
    aud_langs: Iterable[str] = (),
    sub_langs: Iterable[str] = (),
    *,
    video_w: int | None = None,
    video_h: int | None = None,
    sub_present: bool | None = None,
    duration_s: int | None = None,
    fail_reason: str | None = None,
    fail_detail: str | None = None,
    hdr: str | None = None,
    dv_profile: int | None = None,
    dv_compat: str | None = None,
) -> None:
    """
    22.12.2025 20:58 CET (Europe/Prague)

    Noc 03.11.2026 (4.0.6, Φ3): `hdr` ('DOVI', 'HDR10'…), `dv_profile` (5, 7, 8…) a `dv_compat` ('hdr10', 'sdr',
    'hlg', 'none') — Dolby Vision ve výpisu streamů podle schopností zařízení (`richmovie_quality.dv_playability`).
    Stejná zásada jako u videa: „nevím“ nepřepíše známé.

    Uloží „hinty“ z MI2 (MediaInfo) pro daný ident – pro listing (LabelFormatter)
    i pro finální logiku v pluginu.

    ZÁSADY:
      • Merge-safe: nové info jen doplňuje / zpřesňuje. “Nevím” nesmí přepsat stav.
      • Video rozměry (video_w/video_h) ukládáme i když aud/sub nevyšly.
      • sub_present=False znamená: titulky prokazatelně nejsou → listing nemá ukazovat “CZ tit?”.
      • duration_s (sekundy) – využije runtime sanity (TMDb runtime ±10 %).

    NOVĚ (FÁZE A – stabilita / Android / “žádné re-probe po dokončení”):
      • fail_reason uloží “fail marker” do MI2 cache (mi2_cache.json).
        To se bere jako cache-hit → MI2 už daný ident znovu neprobuje,
        dokud uživatel nedá „Reset cache“ (mi2_clear_cache).
      • Při úspěšném publish (aud/sub/video/duration/sub_present) se existující fail marker
        odstraní (aby nezůstal “negativní” stav, když už data máme).

    FÁZE 2 – výkon/IO:
      • Původně: `mi2_publish()` flushoval disk po každém identu.
      • NOVĚ: `mi2_publish()` jen označí disk cache jako “dirty” a flushuje debouncovaně.
        Když potřebuješ “flush hned” (např. před Container.Refresh), zavolej `mi2_flush_disk(force=True)`.
    """
    ident = str(ident or "").strip()
    if not ident:
        return

    # --- normalizace jazyků (používáme existující helper) ---
    _mi = _rm_mi_flags.normalize_mi_fields(aud_langs, sub_langs, video_w, video_h, duration_s, hdr,
                                           dv_profile, dv_compat)
    aud, sub, vw, vh, ds, hdr_v, dvp, dvc = (_mi["aud"], _mi["sub"], _mi["vw"], _mi["vh"], _mi["ds"],
                                             _mi["hdr_v"], _mi["dvp"], _mi["dvc"])

    # --- fail marker (negativní cache) ---
    try:
        fr = str(fail_reason or "").strip()
    except Exception:
        fr = ""
    fr = fr or None

    try:
        fd = str(fail_detail or "").strip()
    except Exception:
        fd = ""
    if fd:
        # zmenši riziko “rozjetí” jsonu / logů; drž to krátké
        fd = fd.replace("\r", " ").replace("\n", " ").strip()
        if len(fd) > 240:
            fd = fd[:240] + "…"
    else:
        fd = ""

    has_lang_info = bool(aud or sub)
    has_video_info = bool(vw or vh or hdr_v or dvp is not None or dvc)
    has_sub_presence_info = (sub_present is True) or (sub_present is False)
    has_duration_info = bool(ds)
    has_fail_info = bool(fr)

    # Když nemáme vůbec nic, nedává smysl ukládat.
    if (not has_lang_info) and (not has_video_info) and (not has_sub_presence_info) and (not has_duration_info) and (not has_fail_info):
        return

    ts = _mi2_now_ts()

    with _MI2_LOCK:
        global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT

        # načti disk (kvůli merge)
        _mi2_load_disk_locked()

        existing_disk = None
        try:
            existing_disk = _MI2_DISK.get(ident, {}).get("val")
        except Exception:
            existing_disk = None

        existing_ram = _MI2_HINTS.get(ident) if isinstance(_MI2_HINTS.get(ident), dict) else None

        base: dict = {}
        if isinstance(existing_disk, dict):
            base.update(existing_disk)
        elif isinstance(existing_ram, dict):
            base.update(existing_ram)

        new_val = dict(base)

        # --- Fail marker: nastav (nebo odstraň při úspěšném publish) ---
        # FÁZE B (21.02.2026): retry-aware fail marker s exponenciálním backoffem
        if fr:
            fv = {"reason": fr}
            if fd:
                fv["detail"] = fd

            # Retry counter management: inkrementuj pokud stejný reason, jinak fresh
            existing_fail = None
            try:
                existing_fail = base.get("fail") if isinstance(base.get("fail"), dict) else None
            except Exception:
                existing_fail = None

            now_ts_f = _mi2_now_ts()

            if existing_fail and str(existing_fail.get("reason", "")) == fr:
                # Stejný reason jako předtím → retry selhal znovu → inkrementuj
                prev_count = int(existing_fail.get("retry_count", 0) or 0)
                fv["retry_count"] = prev_count + 1
                fv["first_fail_ts"] = int(existing_fail.get("first_fail_ts", 0) or 0) or now_ts_f
                fv["last_fail_ts"] = now_ts_f
            else:
                # První selhání (nebo jiný reason) → fresh fail marker
                fv["retry_count"] = 0
                fv["first_fail_ts"] = now_ts_f
                fv["last_fail_ts"] = now_ts_f

            # Předpočítej next_retry_ts pro rychlý check v mi2_get_flags()
            fv["next_retry_ts"] = _mi2_compute_next_retry_ts(
                fr, fv["retry_count"], fv["last_fail_ts"]
            )

            new_val["fail"] = fv
        else:
            # pokud jsme získali nějaká data, fail už nedává smysl → smaž ho
            if "fail" in new_val and (has_lang_info or has_video_info or has_sub_presence_info or has_duration_info):
                try:
                    del new_val["fail"]
                except Exception:
                    pass

        # Audio / titulky / video / délka: merge jen toho, co víme („nevím“ nepřepisuje) — SSOT `rm_core.mi_flags`
        _rm_mi_flags.merge_flags(new_val, aud, sub, sub_present, vw, vh, hdr_v, dvp, dvc, ds)

        # RAM + DISK
        _MI2_HINTS[ident] = dict(new_val)
        _MI2_DISK[ident] = {"ts": ts, "val": dict(new_val)}

        # FÁZE 2: označ jako dirty; samotný flush je debouncovaný
        _MI2_DISK_DIRTY = True
        try:
            _MI2_DISK_DIRTY_COUNT = int(_MI2_DISK_DIRTY_COUNT or 0) + 1
        except Exception:
            _MI2_DISK_DIRTY_COUNT = 1

        # Bezpečnostní “lazy flush”: max 1× za ~1s nebo po N změnách.
        _mi2_flush_disk_locked(force=False)








# ---------------------------------- METODA ---------------------------------- #
# richmovie_engine.py › mi2_get_flags
# (upraveno: 21.02.2026 – FÁZE B: retry logika pro fail markery s exponenciálním backoffem)
# ---------------------------------------------------------------------------- #
def mi2_get_flags(ident: str) -> dict:
    """Vrátí slovník s MI2 hinty (cz_dub, cz_sub, aud, sub, video_h, video_w, sub_present, duration_s).
    Může vracet i klíč "fail" (negativní cache).

    Čte: 1) RAM _MI2_HINTS  2) diskovou cache mi2_cache.json (s TTL)

    FÁZE A (22.12.2025): fail marker = cache-hit (neprobuje se znovu).
    FÁZE B (21.02.2026): fail marker s retry logikou – transientní selhání (timeout, error)
      se po exponenciálním backoffu zkusí znovu. Permanentní selhání (vyčerpané retries) zůstávají
      cache-hit navždy; zastaralé důvody (`_MI2_OBSOLETE_FAIL_REASONS`, 4.5.3: skip_mp4) = měřit hned.
      Viz _mi2_fail_is_retryable().
    """
    ident = str(ident or "").strip()
    if not ident:
        return {}

    with _MI2_LOCK:
        global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT

        # 1) RAM
        rec = _MI2_HINTS.get(ident)
        if isinstance(rec, dict) and rec:
            return dict(rec)

        # 2) DISK
        _mi2_load_disk_locked()
        disk_rec = (_MI2_DISK or {}).get(ident) or {}
        ts = int((disk_rec or {}).get("ts", 0) or 0)
        val = (disk_rec or {}).get("val") or {}

        # FÁZE B (21.02.2026): fail marker s retry logikou
        is_fail = False
        fail_obj = None
        try:
            fail_obj = val.get("fail") if isinstance(val, dict) else None
            is_fail = isinstance(fail_obj, dict) and bool(fail_obj)
        except Exception:
            is_fail = False

        if is_fail:
            if _mi2_fail_is_retryable(fail_obj, disk_ts=ts):
                # Retry je na řadě: smaž z RAM (ale NE z disku – tam zůstane retry_count
                # pro mi2_publish(), který ho přečte a inkrementuje při dalším selhání)
                _MI2_HINTS.pop(ident, None)
                return {}   # vypadá jako "není v cache" → MI2 znovu probuje
            else:
                # Ještě v backoff okně nebo permanentně selhal → cache-hit
                if isinstance(val, dict) and val:
                    _MI2_HINTS[ident] = dict(val)
                    return dict(val)
                return {}

        # TTL pro pozitivní cache (beze změny)
        if ts and (_mi2_now_ts() - ts) > _MI2_TTL_SECS:
            _MI2_DISK.pop(ident, None)
            _MI2_DISK_DIRTY = True
            try:
                _MI2_DISK_DIRTY_COUNT = int(_MI2_DISK_DIRTY_COUNT or 0) + 1
            except Exception:
                _MI2_DISK_DIRTY_COUNT = 1
            return {}

        if isinstance(val, dict) and val:
            _MI2_HINTS[ident] = dict(val)
            return dict(val)

        return {}







# ---------------------------------- METODA ---------------------------------- #
# richmovie_engine.py › mi2_clear_cache
# (upraveno: 21.12.2025 17:58 CET (Europe/Prague) – FÁZE 2: mi2_clear_cache vždy force flushne disk (jinak by debounce mohl přeskočit smazání souboru))
# ---------------------------------------------------------------------------- #
def mi2_clear_cache() -> dict:
    """
    21.12.2025 17:58 CET (Europe/Prague)

    Vymaže MI2 cache (RAM + disk).

    Použití:
      • voláno z plugin.py v „Reset cache vyhledávání“, aby se dalo testovat „od nuly“.
    """
    with _MI2_LOCK:
        global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT

        ram_before = len(_MI2_HINTS)
        _MI2_HINTS.clear()

        _mi2_load_disk_locked()
        disk_before = len(_MI2_DISK)
        _MI2_DISK.clear()

        # po clear je disk jednoznačně dirty → force flush (musí fyzicky přepsat soubor)
        _MI2_DISK_DIRTY = True
        _MI2_DISK_DIRTY_COUNT = max(int(_MI2_DISK_DIRTY_COUNT or 0), 1)

        ok = _mi2_flush_disk_locked(force=True)

    return {"mi2_ram_before": ram_before, "mi2_disk_before": disk_before, "mi2_file_ok": ok}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_engine.py
# mi2_clear_fail_reason  (vytvořeno: 02.09.2026 23:05 CEST, Europe/Prague – 3.5.129)
# ---------------------------------------------------------------------------- #
def mi2_clear_fail_reason(reason: str) -> int:
    """Smaže z MI2 cache (RAM + disk) VŠECHNY fail markery s daným `reason`,
    ostatní hinty (aud/sub/video/duration) položek zachová. Vrací počet.

    PROČ (Fable audit 03.09.2026, F-06): marker `not_media` je vlastnost ÚČTU
    (Free), ne souboru. Po obnovení VIP by jinak exponenciální backoff držel
    MI2 metadata (dabing/titulky/délka) mimo výpis až 7 dní. Volá
    `richmovie_account_state.refresh_now` při přechodu Free → VIP.
    """
    reason = str(reason or "").strip()
    if not reason:
        return 0
    cleared_idents: set = set()
    with _MI2_LOCK:
        global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT
        _mi2_load_disk_locked()
        for ident, val in list(_MI2_HINTS.items()):
            fail = val.get("fail") if isinstance(val, dict) else None
            if isinstance(fail, dict) and str(fail.get("reason", "")) == reason:
                del val["fail"]
                cleared_idents.add(ident)
                if not val:
                    _MI2_HINTS.pop(ident, None)   # prázdný obal bez hintů
        for ident, wrapper in list(_MI2_DISK.items()):
            val = wrapper.get("val") if isinstance(wrapper, dict) else None
            fail = val.get("fail") if isinstance(val, dict) else None
            if isinstance(fail, dict) and str(fail.get("reason", "")) == reason:
                del val["fail"]
                cleared_idents.add(ident)
                if not val:
                    _MI2_DISK.pop(ident, None)
        if cleared_idents:
            _MI2_DISK_DIRTY = True
            _MI2_DISK_DIRTY_COUNT = max(int(_MI2_DISK_DIRTY_COUNT or 0), 1)
            _mi2_flush_disk_locked(force=True)
    return len(cleared_idents)





# --------------------------------------------------------------------------- #
# 2025‑07‑20 20:27 CEST  LabelFormatter.format() – pouze rozlišení + velikost
# --------------------------------------------------------------------------- #
# 4.5.3 (B3-04): zobrazení třídy kvality OTHER ve výpisu (SSOT `LabelFormatter.quality_label` — popisek i šířka sloupce)
QUALITY_UNKNOWN_DISPLAY = "?"
# 4.5.3 (B3-04, audit flotily A4-04/A4-06): první řádek výpisu řekne, PROČ je první (jen když opravdu jde pustit)
RECOMMENDED_BADGE = "[COLOR FF7CFC00]★ Doporučeno[/COLOR]"


class LabelFormatter:
    """
    Připraví dvouřádkový popisek + pravý sloupec (jazyky) pro GUI.
    Nově na prvním řádku zobrazuje **pouze** rozlišení v hranatých závorkách
    a velikost souboru v MB; zbytek (název release) zůstává na druhém řádku.
    """



    # Zobrazení jazyka zvuku (ISO 639-1 z MediaInfo → štítek) — původní znění i ostatní jisté dabingy (16.11.2026)
    _LANG_DISP = {
        "ko": "KOR", "ja": "JPN", "zh": "CHN",
        "de": "GER", "fr": "FR", "es": "ESP",
        "it": "ITA", "ru": "RUS", "pl": "POL",
        "uk": "UKR", "hu": "HUN", "pt": "POR", "tr": "TUR",
    }
    _OTHER_AUD_MAX = 2   # „RUS/UKR dab +1“ — víc kódů by řádek přeplnilo

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class LabelFormatter # format
    # (upraveno: 27.12.2025 16:19 CET (Europe/Prague) – fallback (uncertain) „do šeda“, dokud runtime není potvrzen (runtime_confirmed); zachováno runtime_mismatch šedění)
    # ---------------------------------------------------------------------------- #
    # Beta.7 (2026-04-25): tabular alignment helpers.
    # U+2007 FIGURE SPACE = digit-width space v tabular figures fontech
    # (Kodi default Estuary používá NotoSans-Regular, který tabular figures má).
    # Ostatní mezery v label by se s proporcionálním fontem nezarovnaly.
    _DIGIT_SPACE = " "

    @staticmethod
    def _pad_left(s: str, width: int, pad_char: str = " ") -> str:
        """Right-align `s` v `width` znacích pomocí U+2007 (digit-width space)."""
        if width <= 0:
            return s
        return pad_char * max(0, width - len(s)) + s

    @staticmethod
    def quality_label(release: "Release", flags: Optional[dict] = None) -> str:
        """Štítek kvality v hranatých závorkách — SSOT pro popisek i pro šířku sloupce ve výpisu."""
        q_raw = (getattr(release, "quality", "") or "").strip().lower()
        label = _rm_quality.quality_rank(
            flags if isinstance(flags, dict) else {}, getattr(release, "ws_width", None),
            getattr(release, "ws_height", None), q_raw, getattr(release, "name", ""))[1]
        if label == _rm_quality.LABEL_OTHER and q_raw and q_raw != "other":
            label = q_raw.upper()              # značka zdroje, kterou SSOT nezná (např. „HDTV“)
        if label == _rm_quality.LABEL_OTHER:
            # 4.5.3 (B3-04, audit flotily A4-04): divák nečte „OTHER“ — neznámá kvalita je „?“ (třída řazení se nemění)
            label = QUALITY_UNKNOWN_DISPLAY
        return label

    @staticmethod
    def format(
        release: "Release",
        *,
        show_source_prefix: bool = False,
        size_pad_width: int = 0,
        quality_pad_width: int = 0,
        **kwargs,
    ) -> dict[str, str]:
        """
        Beta.7 (2026-04-25) — tabular column alignment + source prefix:

          • show_source_prefix=True → WS/FS prefix u všech releasů (užitečné
            když user má FS i WS sources mixed → vidí, odkud je který stream).
            Detekce v plugin.py: any(r.source == "fastshare" for r in rels).
          • size_pad_width=N → padding U+2007 vlevo k size sloupci, aby čísla
            byla pod sebou. Caller spočítá max šířku napříč listingem.
          • quality_pad_width=N → padding kvality (1080P / 720P / WEBRip)
            uvnitř `[]` na fixní šířku.

        27.12.2025 16:19 CET (Europe/Prague):

        FINÁL Varianta A (listing):

        1) Kvalita v []:
           • vždy jen: 2160P / 1080P / 720P / 576P / 480P / 360P / 320P / 240P
           • když známe výšku videa (WS nebo MI2), nikdy neukazujeme OTHER
           • DVDRip / WEBRip / CAM necháváme, pokud je to jisté z názvu/heuristiky

        2) Badge (NOVĚ – bez placeholderů):
           • CZ dab:
               - MI2 cz_dub=True  → zobraz
               - MI2 cz_dub=False → nezobrazuj nic (žádná “negativní” informace)
               - MI2 neví         → zobraz CZ dab? jen když heuristika názvu naznačuje CZ audio
               - jinak            → nezobrazuj nic
           • CZ tit:
               - sub_present=False → nezobrazuj nic
               - MI2 cz_sub=True   → zobraz CZ tit
               - MI2 cz_sub=False  → nezobrazuj nic
               - MI2 neví          → zobraz CZ tit? jen když heuristika názvu naznačuje CZ titulky
               - jinak             → nezobrazuj nic
           • EN dab (jen když je jisté z MI2)
           • ORIG dab (např. KOR dab) jen když TMDb říká originál ≠ CZ/EN a MI2 má jisté audio

        3) Runtime sanity (TV):
           • pokud release.runtime_mismatch=True → celý label je šedý (žádné zlaté/modré zvýraznění),
             aby “špatná stopáž” stream nebila do očí (a současně je stejně řazen na konec seznamu).

        4) NOVĚ: Fallback sanity (TV):
           • pokud release.uncertain=True a máme runtime_ref_available=True a runtime_confirmed!=True → celý label šedě.
             (tj. „vidím to, ale stopáž to nepotvrdila“)
        """
        # ---------- MI2 flags ----------
        flags: dict = {}
        try:
            flags = mi2_get_flags(getattr(release, "ident", "")) or {}
        except Exception:
            flags = {}

        # ---------- 1. řádek: kvalita + velikost ----------
        # Φ-D (30.09.2026): štítek kvality = TŘÍDA, podle které se řadí (SSOT `richmovie_quality`): rozměry
        # obrazu (MediaInfo, pak Webshare; šířka i výška) mají přednost před názvem souboru. Dřív se štítek
        # bral z názvu a řadilo se podle výšky → „1080P“ pod „720P“ a širokoúhlý film 1920×800 jako 720p.
        display_q = LabelFormatter.quality_label(release, flags)

        # Source prefix (Beta.7 — multi-source viditelnost).
        # show_source_prefix=True (set by caller když user má FS) → WS/FS u všech
        # show_source_prefix=False (legacy) → jen FS prefix u Fastshare releasů
        source = getattr(release, "source", "webshare")
        if show_source_prefix:
            prefix = (
                "[COLOR FF888888]FS[/COLOR] " if source == "fastshare"
                else "[COLOR FF888888]WS[/COLOR] "
            )
        else:
            prefix = "[COLOR FF888888]FS[/COLOR] " if source == "fastshare" else ""

        # Quality block — natural width uvnitř `[]` + padding U+2007 ZA `]`
        # (čisté vizuálně: `[1080P]` `[720P]  ` `[WEBRip] ` — žádné mezery
        # uvnitř závorek). Padding dorovná total šířku quality bloku včetně
        # závorek na `quality_pad_width + 2` (= max content width + brackets).
        quality_block = f"[{display_q}]"
        if quality_pad_width > 0:
            target_total = quality_pad_width + 2  # `[` + content + `]`
            quality_block += LabelFormatter._DIGIT_SPACE * max(
                0, target_total - len(quality_block),
            )
        first_line = prefix + quality_block

        # Size column — right-align celého "X XXX MB" stringu na size_pad_width
        # chars pomocí U+2007 (digit-width space).
        try:
            if getattr(release, "size", None):
                size_str = f"{release.size_mb:,}".replace(",", " ") + " MB"
                if size_pad_width > 0:
                    size_str = LabelFormatter._pad_left(
                        size_str, size_pad_width, LabelFormatter._DIGIT_SPACE,
                    )
                first_line += " - " + size_str
        except Exception:
            pass

        # ---------- Badges (Beta.7 rozšíření 2026-04-25) ----------
        # Pravidlo: každá detekovaná stopa s jasným language tagem dostane
        # badge. Neznámé jazyky ('?', 'und', 'Undefined') se IGNORUJÍ — user
        # explicitně nechce zobrazovat "neumíme rozeznat". Heuristika z názvu
        # (Release.audios/subs vyplněné parsingem release tagů) přidává jen
        # `CZ dab?`/`CZ tit?` (šedé "?") když MI2 nezná stopy vůbec.
        badges: list[str] = []

        # Heuristika z názvu (release tag parser → uppercase 2-letter codes)
        try:
            name_aud = {str(x).strip().upper()[:2] for x in (getattr(release, "audios", None) or []) if x}
        except Exception:
            name_aud = set()
        try:
            name_sub = {str(x).strip().upper()[:2] for x in (getattr(release, "subs", None) or []) if x}
        except Exception:
            name_sub = set()

        # MI2 detekované jazyky (lowercase ISO codes z mediainfo)
        try:
            aud_list = flags.get("aud") or []
            aud_set = {str(x).strip().lower()[:2] for x in aud_list if x}
        except Exception:
            aud_set = set()
        try:
            sub_list = flags.get("sub") or []
            sub_set = {str(x).strip().lower()[:2] for x in sub_list if x}
        except Exception:
            sub_set = set()

        # Vyloučit neznámé tagy ('?', 'un' from "und"/"Undefined")
        _UNKNOWN_LANG = {"", "?", "un"}
        aud_set -= _UNKNOWN_LANG
        sub_set -= _UNKNOWN_LANG

        # ─── AUDIO badges ────────────────────────────────────────────────
        # CZ dab — preferuj engine flag `cz_dub` (preprocessed); fallback
        # na heuristiku z názvu pokud MI2 neumí.
        if "cz_dub" in flags:
            if bool(flags.get("cz_dub")):
                badges.append("[COLOR gold]CZ dab[/COLOR]")
        elif not aud_set:  # MI2 nezná žádné audio → heuristika z názvu
            if "CZ" in name_aud:
                badges.append("[COLOR grey]CZ dab?[/COLOR]")

        # SK dab — Slovak audio (CZ users to chápou; common v CZ/SK rip)
        if "sk" in aud_set:
            badges.append("[COLOR FFADD8E6]SK dab[/COLOR]")

        # EN — anglické audio. 4.5.3 (B3-04, A4-06): u titulu, jehož původní jazyk je angličtina, to NENÍ dabing → „EN orig“
        movie = kwargs.get("movie")
        _orig_lang = (movie.get("original_language") or "").strip().lower() if isinstance(movie, dict) else ""
        if "en" in aud_set:
            badges.append("[COLOR FF87CEFA]EN orig[/COLOR]" if _orig_lang == "en" else "[COLOR FF87CEFA]EN dab[/COLOR]")

        # ORIG — TMDb original_language ≠ CZ/EN/SK + MI2 audio v tom jazyce = původní znění („KOR orig“, dřív „KOR dab“)
        orig_iso = ""
        if isinstance(movie, dict):
            orig_iso = (movie.get("original_language") or "").strip().lower()
            if orig_iso in {"cs", "cz"}:
                orig_iso = "cs"
            if orig_iso and orig_iso not in {"cs", "en", "sk"}:
                disp = LabelFormatter._LANG_DISP.get(orig_iso, orig_iso.upper())
                if orig_iso[:2] in aud_set:
                    badges.append(f"[COLOR FF32CD32]{disp} orig[/COLOR]")
        # Ostatní JISTÉ jazyky zvuku z MI2 (16.11.2026, Richie: Ebenezer TS „Dragon Money Studio“ jen s ruskou stopou —
        # „proč to není vidět?“): stream s jediným cizím dabingem musí být poznat dřív, než ho divák pustí. Jen MediaInfo
        # (název souboru jazyk zvuku spolehlivě neurčí), bez CZ / SK / EN a bez jazyka originálu (ty mají vlastní štítek),
        # nejvýš `_OTHER_AUD_MAX` kódů + „+N“; klidná barva, ať nepřebije CZ dabing.
        _shown_aud = {"cs", "cz", "sk", "en", orig_iso[:2]}
        _other_aud = sorted(a for a in aud_set if a and a not in _shown_aud)
        if _other_aud:
            _codes = [LabelFormatter._LANG_DISP.get(a, a.upper()) for a in _other_aud[:LabelFormatter._OTHER_AUD_MAX]]
            _more = len(_other_aud) - LabelFormatter._OTHER_AUD_MAX
            badges.append("[COLOR FFB0BEC5]%s dab%s[/COLOR]" % ("/".join(_codes), (" +%d" % _more) if _more > 0 else ""))

        # ─── SUBTITLE badges ──────────────────────────────────────────────
        # sub_present=False → MI2 jistě říká "žádné titulky" → vůbec nic
        sub_present = flags.get("sub_present", None)
        if sub_present is not False:
            # CZ tit — preferuj engine flag `cz_sub`; fallback heuristika
            if "cz_sub" in flags:
                if bool(flags.get("cz_sub")):
                    badges.append("[COLOR deepskyblue]CZ tit[/COLOR]")
            elif not sub_set:  # MI2 nezná → heuristika z názvu
                if "CZ" in name_sub:
                    badges.append("[COLOR grey]CZ tit?[/COLOR]")

            # SK tit — slovenské titulky
            if "sk" in sub_set:
                badges.append("[COLOR FF9FCFE3]SK tit[/COLOR]")

            # EN tit — anglické titulky (common pro mezinárodní rip + user
            # může doplnit CZ titulky přes RichSubtitles)
            if "en" in sub_set:
                badges.append("[COLOR FF87CEEB]EN tit[/COLOR]")

        if badges:
            first_line += " | " + " | ".join([b for b in badges if b])
        # 4.5.3 (B3-04): „★ Doporučeno – důvod“ jen u řádku, který volající vybral (`plugin._recommend_reason`)
        _rec = str(kwargs.get("recommended") or "").strip()
        if _rec:
            first_line += " | %s [COLOR FF9E9E9E]– %s[/COLOR]" % (RECOMMENDED_BADGE, _rec)
        # jádro 1.2.2 (audit Fable F28 V8): nejistý díl, který automat nepustí — štítek proč (`plugin._unsure_label`)
        # a celý řádek šedě (níž); dřív šedý jen s referencí délky, cizí seriál s podobnou délkou vypadal jako běžný řádek
        _unsure = str(kwargs.get("unsure") or "").strip()
        if _unsure:
            first_line += " | %s" % _unsure

        # ---------- 2. řádek: název releasu ----------
        second_line = f"[COLOR grey]\t\t\t{release.name}[/COLOR]"
        left = f"{first_line}\n{second_line}"

        # Runtime sanity (TV) + Fallback sanity (TV):
        #   • runtime_mismatch=True → vše šedě
        #   • fallback (uncertain) + máme runtime_ref_available + runtime_confirmed != True → vše šedě
        force_grey = bool(getattr(release, "runtime_mismatch", False)) or bool(_unsure)
        if not force_grey:
            try:
                if (
                    bool(getattr(release, "uncertain", False))
                    and bool(getattr(release, "runtime_ref_available", False))
                    and (not bool(getattr(release, "runtime_confirmed", False)))
                ):
                    force_grey = True
            except Exception:
                pass

        if force_grey:
            try:
                # odstraníme vnořené barvy (gold/deepskyblue/…), aby bylo VŠE šedé
                plain = re.sub(r"\[/?COLOR[^\]]*\]", "", left)
                left = f"[COLOR FF9E9E9E]{plain}[/COLOR]"
            except Exception:
                left = f"[COLOR FF9E9E9E]{left}[/COLOR]"

        # Varianta A: Label2 nepoužíváme (skin to často nezobrazuje)
        return {"label_left": left, "label_right": ""}







class _SearchProgress:
    """
    Jediný DialogProgress sdílený všemi vlákny *během jednoho hledání*.
    Čítače jsou kumulativní, takže procenta **nikdy neklesají** ani když
    paralelní vlákna hlásí své lokální rozsahy (Search / Probe).
    """
    _TXT = {"search": "Vyhledávání", "probe": "Analýza stopáže"}

    def __init__(self, heading: str = "RichMovie – Vyhledávání") -> None:
        self._dlg   = xbmcgui.DialogProgress()
        self._dlg.create("RichMovie", heading)
        self._last_pct: int           = -1
        self._totals: dict[str, int]  = {}
        self._done:   dict[str, int]  = {}
        self._lock   = threading.Lock()

    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def __call__(self, current: int, total: int, stage: str = "") -> None:
        """
        Callback z SearchEngine:
            current – aktuální index (1-based)
            total   – lokální limit v daném vlákně
            stage   – 'search' nebo 'probe'
        """
        with self._lock:
            # první blok daného typu → přičteme *total* jen jednou
            if stage not in self._totals or current == 1:
                self._totals[stage] = self._totals.get(stage, 0) + total
                self._done.setdefault(stage, 0)

            # přírůstek od minula (vlákno může skočit z 1→15 rovnou)
            if current > self._done[stage]:
                self._done[stage] = current

            done_all  = sum(self._done.values())
            total_all = sum(self._totals.values())
            pct       = int(done_all / total_all * 100) if total_all else 0
            pct       = max(pct, self._last_pct)        # procenta jen rostou
            self._last_pct = pct

            label = (
                f"{self._TXT.get(stage, stage)}: "
                f"{self._done[stage]} / {self._totals[stage]}"
            )
            self._dlg.update(pct, label)




    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def close(self) -> None:
        self._dlg.close()


# ═══════════════════════════════════════════════════════════════════════════════
#  SEARCH TIPS  – Sims-like rotujici hlasky pro vyhledavani
# ═══════════════════════════════════════════════════════════════════════════════


def _load_search_tips(addon_dir: str, ws_username: str, seed: int) -> list[str]:
    """
    Nacte search tips z JSON (bez persistence – zpetna kompatibilita).
    Pro persistenci pouzij _load_tip_persistent_state + _TipRotator(persistent_state=...).

    Vzdy nacte default.json. Pokud existuje <username>.json, primícha
    personalizovane tipy do defaultnich (ale jen pro daneho uzivatele).
    """
    tips_dir = os.path.join(addon_dir, "resources", "search_tips")
    loaded: list[str] = []

    # -- vzdy nacti defaultni tipy --
    default_file = os.path.join(tips_dir, "default.json")
    try:
        with open(default_file, encoding="utf-8") as f:
            data = json.load(f)
        loaded = data.get("tips", [])
    except Exception as _tp_e:
        _diag_log(f"search tips default load fail: {_tp_e}", 0)
        loaded = []

    # -- primichej personalizovane tipy pro uzivatele (pomer 2:1) --
    if ws_username:
        user_file = os.path.join(tips_dir, ws_username.lower() + ".json")
        if os.path.isfile(user_file):
            try:
                with open(user_file, encoding="utf-8") as f:
                    data = json.load(f)
                user_tips = data.get("tips", [])
                if user_tips and loaded:
                    # Zopakuj osobni tipy, aby pomer byl ~2 osobni : 1 obecna
                    repeat = max(1, round(2 * len(loaded) / len(user_tips)))
                    loaded.extend(user_tips * repeat)
                elif user_tips:
                    loaded = list(user_tips)
            except Exception as _tp_e:
                _diag_log(f"search tips user load fail: {_tp_e}", 0)

    if not loaded:
        return ["Hledám…"]

    rnd = random.Random(seed)
    tips = list(loaded)
    rnd.shuffle(tips)
    return tips


def _save_tip_state(profile_dir: str, order: list[int],
                    seen_count: int, pool_size: int, interleave_seen: int = 0) -> None:
    """Atomicky ulozi stav tipu do tip_state.json (+ `interleave_seen`, 3.5.157)."""
    if not profile_dir:
        return
    state_path = os.path.join(profile_dir, "tip_state.json")
    try:
        payload = {"order": order, "seen_count": seen_count,
                   "pool_size": pool_size, "interleave_seen": int(interleave_seen or 0)}
        import richmovie_atomic as _atomic
        if not _atomic.write_json(state_path, payload):
            _diag_log("tip_state save fail", 0)
    except Exception as _tp_e:
        _diag_log(f"tip_state save fail: {_tp_e}", 0)


def _load_tip_persistent_state(addon_dir: str, ws_username: str,
                               profile_dir: str = "") -> dict:
    """
    Nacte tips a persistent stav. Vraci dict s klici:
      tips, order, seen_count, pool_size, profile_dir
    Pro pouziti v _TipRotator.

    Vzdy nacte default.json. Pokud existuje <username>.json, primícha
    personalizovane tipy do defaultnich (ale jen pro daneho uzivatele).
    """
    tips_dir = os.path.join(addon_dir, "resources", "search_tips")
    loaded: list[str] = []
    interleave: dict = {}

    # -- vzdy nacti defaultni tipy --
    default_file = os.path.join(tips_dir, "default.json")
    try:
        with open(default_file, encoding="utf-8") as f:
            data = json.load(f)
        loaded = data.get("tips", [])
    except Exception as _tp_e:
        _diag_log(f"search tips default load fail: {_tp_e}", 0)
        loaded = []

    # -- primichej personalizovane tipy pro uzivatele (pomer 2:1) --
    if ws_username:
        user_file = os.path.join(tips_dir, ws_username.lower() + ".json")
        if os.path.isfile(user_file):
            try:
                with open(user_file, encoding="utf-8") as f:
                    data = json.load(f)
                user_tips = data.get("tips", [])
                if user_tips and loaded:
                    # Zopakuj osobni tipy, aby pomer byl ~2 osobni : 1 obecna
                    repeat = max(1, round(2 * len(loaded) / len(user_tips)))
                    loaded.extend(user_tips * repeat)
                elif user_tips:
                    loaded = list(user_tips)
                # 3.5.157 (Richie 27.09.2026, Robišek): `interleave` = vlastní seznam, ze kterého jde
                # KAŽDÁ N-tá zobrazená hláška (vlastní pořadí, bez opakování, přežije restart).
                interleave = parse_interleave(data.get("interleave"))
            except Exception as _tp_e:
                _diag_log(f"search tips user load fail: {_tp_e}", 0)

    if not loaded:
        return {"tips": loaded, "order": [], "seen_count": 0,
                "pool_size": 0, "profile_dir": profile_dir, "interleave": interleave, "interleave_seen": 0}

    pool_size = len(loaded)
    state_path = os.path.join(profile_dir, "tip_state.json") if profile_dir else ""
    order: list[int] = []
    seen_count: int = 0
    interleave_seen: int = 0

    if state_path:
        try:
            if os.path.isfile(state_path):
                with open(state_path, encoding="utf-8") as f:
                    st = json.load(f)
                saved_pool = st.get("pool_size", 0)
                saved_order = st.get("order", [])
                saved_seen = st.get("seen_count", 0)
                if (saved_pool == pool_size
                        and len(saved_order) == pool_size
                        and 0 <= saved_seen <= pool_size):
                    order = saved_order
                    seen_count = saved_seen
                try:
                    interleave_seen = max(0, int(st.get("interleave_seen") or 0))
                except (TypeError, ValueError):
                    interleave_seen = 0
        except Exception:
            pass

    if not order or len(order) != pool_size:
        rnd = random.Random(int(time.time()))
        order = list(range(pool_size))
        rnd.shuffle(order)
        seen_count = 0

    # Pokud uz vsechny videl, reshuffluj
    if seen_count >= pool_size:
        rnd = random.Random(int(time.time()))
        order = list(range(pool_size))
        rnd.shuffle(order)
        seen_count = 0

    return {"tips": loaded, "order": order, "seen_count": seen_count,
            "pool_size": pool_size, "profile_dir": profile_dir,
            "interleave": interleave, "interleave_seen": interleave_seen}


def parse_interleave(raw: object) -> dict:
    """Čistá (3.5.157): `{"every": N ≥ 2, "tips": [str, …]}` → {"every", "tips"}; jinak {} (žádné prokládání)."""
    if not isinstance(raw, dict):
        return {}
    try:
        every = int(raw.get("every") or 0)
    except (TypeError, ValueError):
        return {}
    tips = [str(t).strip() for t in (raw.get("tips") or []) if isinstance(t, str) and str(t).strip()]
    if every < 2 or not tips:
        return {}
    return {"every": every, "tips": tips}


class _TipRotator:
    """
    Sdileny stav tipu mezi vlnami (W1 -> W2 -> ... -> WX+).
    Index se nikdy neresetuje – kazda dalsi vlna pokracuje kde predchozi skoncila.
    Persistuje stav do tip_state.json – pamatuje si, ktere tipy uz byly zobrazeny.
    """

    def __init__(self, tips: list[str], switch_every: float = 3.0,
                 persistent_state: dict = None) -> None:
        self._switch_every = switch_every
        self._lock = threading.Lock()
        self._last_switch = time.time()

        if persistent_state and persistent_state.get("tips"):
            raw_tips = persistent_state["tips"]
            self._order = list(persistent_state.get("order", []))
            self._seen_count = persistent_state.get("seen_count", 0)
            self._pool_size = persistent_state.get("pool_size", len(raw_tips))
            self._profile_dir = persistent_state.get("profile_dir", "")
            # Sestav seznam: nejdriv nezobrazene, pak zobrazene
            unseen = [raw_tips[self._order[i]]
                      for i in range(self._seen_count, self._pool_size)]
            seen = [raw_tips[self._order[i]]
                    for i in range(0, self._seen_count)]
            self._tips = unseen + seen if unseen else (seen if seen else ["Hledám…"])
            self._persistent = True
            _inter = persistent_state.get("interleave") or {}
            self._inter_tips = list(_inter.get("tips") or [])
            self._inter_every = int(_inter.get("every") or 0) if self._inter_tips else 0
            self._inter_seen = int(persistent_state.get("interleave_seen") or 0)
        else:
            self._tips = tips if tips else ["Hledám…"]
            self._order = []
            self._seen_count = 0
            self._pool_size = len(self._tips)
            self._profile_dir = ""
            self._persistent = False
            self._inter_tips = []
            self._inter_every = 0
            self._inter_seen = 0

        self._idx = 0
        self._shown_in_session = 0      # zobrazených hlášek z POOLU v této session (pro persistenci)
        self._display_no = 0            # pořadové číslo zobrazení v této session (kadence prokládání)
        self._current = self._tips[0]
        self._saved = False

    def current_tip(self) -> str:
        with self._lock:
            return self._current

    def maybe_advance(self) -> str:
        """Posune tip pokud ubehl dostatecny cas. Vraci aktualni tip.

        3.5.157: každé `interleave.every`-té zobrazení bere hlášku z prokládaného seznamu (vlastní
        cyklus `_inter_seen`, přežívá restart); pool se přitom NEposune, takže žádná hláška z poolu
        nepropadne. Kadence počítá zobrazení v session — přesně „každá pátá", jak Richie chtěl.
        """
        with self._lock:
            now = time.time()
            if now - self._last_switch >= self._switch_every:
                self._last_switch = now
                self._display_no += 1
                if self._inter_every and self._display_no % self._inter_every == 0:
                    self._current = self._inter_tips[self._inter_seen % len(self._inter_tips)]
                    self._inter_seen += 1
                else:
                    self._idx = (self._idx + 1) % len(self._tips)
                    self._shown_in_session += 1
                    self._current = self._tips[self._idx]
            return self._current

    @property
    def last_switch_time(self) -> float:
        with self._lock:
            return self._last_switch

    def save_final_state(self) -> None:
        """Ulozi finalni stav pri zavreni. Volat jednou na konci."""
        if not self._persistent or not self._profile_dir or self._saved:
            return
        self._saved = True
        with self._lock:
            # +1 protoze prvni tip (idx=0) se taky zobrazil
            total_shown = self._shown_in_session + 1
            new_seen = self._seen_count + total_shown
            order = list(self._order)
            pool_size = self._pool_size
            profile_dir = self._profile_dir
            inter_seen = self._inter_seen % len(self._inter_tips) if self._inter_tips else 0
        # File I/O mimo lock
        try:
            if new_seen >= pool_size:
                rnd = random.Random(int(time.time()))
                new_order = list(range(pool_size))
                rnd.shuffle(new_order)
                _save_tip_state(profile_dir, new_order, 0, pool_size, inter_seen)
            else:
                _save_tip_state(profile_dir, order, new_seen, pool_size, inter_seen)
        except Exception:
            pass


def _listing_key():
    """
    Klic listingu, pro ktery MI2 davka bezi.

    MUSI to byt URL invokace pluginu (`sys.argv`), NE `Container.FolderPath` —
    engine startuje MI2 uvnitr stavby adresare, kde je FolderPath jeste cesta,
    ze ktere se odchazi. Presne to vyrobilo 19.09.2026 klic
    `?action=show_recommendations` u vypisu streamu Terminatora 2.

    Runtime smoke 19.09.2026 20:04 odhalil, ze tyhle tri call sites v enginu
    klic nepredavaly a padaly do legacy fallbacku (`KEY_FALLBACK` v kodi.log).
    """
    try:
        import richmovie_listing as _L
        return _L.current_listing_key()
    except Exception:
        return None


def search_sources_text() -> str:
    """Text fáze hledání podle zdrojů, které TENTO účet opravdu prohledává (SSOT pro film i díl). „…a Fastshare“ četlo
    i 10 ze 17 účtů, které Fastshare nemají (audit flotily 10.11.2026 A4). Neznámý stav = text jako dřív."""
    try:
        import richmovie_fastshare as _fs_txt
        import richmovie_settings as _set_txt
        fs_active = bool(_fs_txt.is_fastshare_allowed(_set_txt.get_str("username").strip()))
    except Exception:
        fs_active = True
    return "Hledám na Webshare a Fastshare" if fs_active else "Hledám na Webshare"


class _SearchProgressWithTips:
    """
    JEDEN pravdivý průběh od kliknutí do seznamu streamů (Φ5A, 29.09.2026 — audit A06 R01/R03).

    Hlavní řádek = co se právě děje, česky a s počty („Hledám na Webshare a Fastshare (2/4)…“,
    „Zjišťuji dabing a kvalitu (3/10)…“); druhý řádek = hláška (tip), která se střídá sama.
    Procenta patří AKTUÁLNÍ fázi — dřív stála na 100 % celých až 12 s čekání na MediaInfo a dialog
    se pak ještě 0–4 s držel „kvůli hlášce“ (`close_with_min_display`, zrušeno — D4: tip běží jen
    po dobu skutečné práce; kontinuitu hlášek drží `tip_state.json`).

    Volání: engine `progress_cb(current, total, stage)` (fáze hledání), plugin `set_phase(text, done,
    total)` (názvy, třídění, MediaInfo, příprava seznamu). `iscanceled()` čtou engine i plugin —
    Zrušit opravdu ukončí hledání (A06 R10). `close()` je idempotentní.
    """
    #: Fáze, které hlásí engine přes `progress_cb` (stage) → text hlavního řádku.
    STAGE_TEXT = {"search": "Hledám na Webshare a Fastshare", "filter": "Třídím nalezené",
                  "probe": "Zjišťuji stopáž"}

    def __init__(self, heading: str, rotator: Optional[_TipRotator],
                 first_phase: str = "Připravuji hledání…") -> None:
        self._dlg = xbmcgui.DialogProgress()
        # 3.5.131: rotátor sestavuje `richmovie_search_tips.build_rotator` (SSOT);
        # None = sestavení selhalo → dialog jede s jednou neutrální hláškou,
        # hledání nikdy nespadne kvůli UX ozdobě.
        self._rotator = rotator if rotator is not None else _TipRotator([])
        self._heading = heading
        self._lock = threading.Lock()
        self._closed = False
        self._phase = first_phase
        self._pct = 0
        self._totals: dict[str, int] = {}
        self._done: dict[str, int] = {}
        self._dlg.create("RichMovie", self._message_locked(self._rotator.current_tip()))
        self._timer_stop = threading.Event()
        self._timer = threading.Thread(
            target=self._tip_loop,
            name="RichMovie.TipRotator",
            daemon=True,
        )
        self._timer.start()

    def _message_locked(self, tip: str) -> str:
        return f"{self._phase}\n{tip}" if tip else self._phase

    def _render_locked(self) -> None:
        try:
            self._dlg.update(max(0, min(100, int(self._pct))), self._message_locked(self._rotator.current_tip()))
        except Exception:
            pass

    def _tip_loop(self) -> None:
        """Background thread: střídá hlášku (druhý řádek); fázi a procenta nemění."""
        while not self._timer_stop.is_set():
            self._timer_stop.wait(0.5)
            if self._timer_stop.is_set():
                break
            self._rotator.maybe_advance()
            with self._lock:
                if self._closed:
                    break
                self._render_locked()

    def set_phase(self, text: str, done: Optional[int] = None, total: Optional[int] = None) -> None:
        """Nová fáze (hlavní řádek). S `done/total` se text doplní o „(done/total)“ a procenta jsou
        podíl téhle fáze; bez nich procenta zůstanou (fáze bez měřitelného pokroku)."""
        with self._lock:
            if self._closed:
                return
            if done is not None and total:
                self._phase = "%s (%d/%d)…" % (text.rstrip("…").rstrip(), int(done), int(total))
                self._pct = int(100 * max(0, min(int(done), int(total))) / int(total))
            else:
                self._phase = text
            self._render_locked()

    def __call__(self, current: int, total: int, stage: str = "") -> None:
        """Callback z SearchEngine — pokrok fáze hledání (součet přes dotazy vlny)."""
        with self._lock:
            if self._closed:
                return
            if stage not in self._totals or current == 1:
                self._totals[stage] = self._totals.get(stage, 0) + total
                self._done.setdefault(stage, 0)
            if current > self._done[stage]:
                self._done[stage] = current
            done_s = self._done.get(stage, 0)
            total_s = self._totals.get(stage, 0)
            if stage == "search":
                # jednou za dialog (cross-check 12.11. A4): zdroje účtu se během hledání nemění, čtení nastavení na krok ne
                if getattr(self, "_search_label", None) is None:
                    self._search_label = search_sources_text()
                label = self._search_label
            else:
                label = self.STAGE_TEXT.get(stage, "Hledám")
            self._phase = "%s (%d/%d)…" % (label, done_s, total_s) if total_s else "%s…" % label
            self._pct = int(100 * done_s / total_s) if total_s else 0
            self._render_locked()

    def iscanceled(self) -> bool:
        """
        Zmackl uzivatel Zrusit / Zpet?

        `xbmcgui.DialogProgress` to umi odjakziva, ale cekaci smycky se ho
        neptaly - na Sony BRAVIA 19.09.2026 se stisk Zpet ignoroval po celou
        dobu 60s cekani na MediaInfo (plugin.py `_wait_for_mi2_window`).
        Best-effort: po zavreni dialogu vracime False, at se volajici smycka
        nechyti na mrtvem okne.
        """
        with self._lock:
            if self._closed:
                return False
        try:
            return bool(self._dlg.iscanceled())
        except Exception:
            return False

    def tick(self) -> None:
        """Čekání bez nového hlášení (rozhraní průběhu, P16 / audit Fable F11 V4). Tohle okno je otevřené od začátku
        a hlášky střídá vlastní časovač → nic; líné okno přednačteného výpisu (`richmovie_prefetched.LazyProgress`)
        se při něm ukáže, když čekání překročí práh."""
        return None

    def close(self) -> None:
        """Zastav timer, uloz stav tipu a zavri dialog. Idempotentní."""
        self._timer_stop.set()
        with self._lock:
            if self._closed:
                return
            self._closed = True
        try:
            self._timer.join(timeout=1.0)
        except Exception:
            pass
        try:
            self._rotator.save_final_state()
        except Exception:
            pass
        try:
            self._dlg.close()
        except Exception:
            pass

