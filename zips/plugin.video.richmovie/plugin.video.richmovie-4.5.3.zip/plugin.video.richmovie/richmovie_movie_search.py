# -*- coding: utf-8 -*-
"""
richmovie_movie_search — SSOT hledání streamů FILMU (kontext filtru + primární a záložní vlna).

Proč (plán `Handoff/PLAN_televize_vod_20261108.md`, F2): tělo hledání filmu žilo v `plugin._auto_search_movie_run`,
provázané s dialogem, výpisem a chybovými hláškami, takže ho bez UI nešlo zavolat. Nabídka lepší verze při
sledování Televize potřebuje PŘESNĚ totéž hledání jako ruční výpis (stejné dotazy, stejný filtr, stejná cache).
Tenhle modul je přesun 1 : 1 — vzor `richmovie_episode_search`; UI (dialog, MediaInfo, výpis, SkTorrent, hlášky)
zůstává v `plugin.py`.

Modul nesmí importovat `plugin` (knihovna). Python 3.8 (Kodi).
"""
from __future__ import annotations

from itertools import permutations
from typing import Any, Callable, Dict, List, Optional, Sequence, Set, Tuple

from richmovie_engine import Release
from richmovie_webshare import APIError, TokenExpired
from tmdb_client import TMDbError

import richmovie_core_path  # noqa: F401
from rm_core.context import (  # noqa: F401  (build_context a spol. jsou SSOT v rm_core, G1)
    _MANUAL_BANNED,
    MovieSearchContext,
    alt_titles_of,
    build_movie_context as build_context,
    note_movie_tmdb_failure as _note_tmdb_failure,
)
from rm_core.cascade import WAVE_ALT, WAVE_PRIMARY, movie_alt_wave, movie_empty_is_authoritative
from rm_core.queries import query_variants  # noqa: F401

PHASE_PRIMARY = "Hledám na Webshare a Fastshare…"
PHASE_ALT = "Hledám i pod jinými názvy…"


STAGE_LOGIN = "login"
STAGE_API = "api"


LogFn = Callable[..., None]




class CascadeResult(object):
    """Výsledek `run_cascade`: `rels` = streamy té vlny, která je našla (P, jinak ALT); `alt_titles` = alternativní
    názvy záložní vlny ([] = záložní vlna nebyla z čeho sestavit); `errors` > 0 = některý dotaz selhal (R2)."""

    __slots__ = ("rels", "wave", "cancelled", "alt_titles", "errors", "waves", "rate_limited")

    def __init__(self) -> None:
        self.rels: List[Release] = []
        self.wave = ""
        self.cancelled = False
        self.alt_titles: List[str] = []
        self.errors = 0
        self.waves: List[str] = []
        self.rate_limited = False


class WaveFailed(Exception):
    """Vlna skončila chybou zdroje. `stage` = `login` (obnova přihlášení selhala) | `api` (chyba Webshare),
    `wave` = P | ALT, `cause` = původní výjimka. Kód konce hledání i hlášku určuje volající."""

    def __init__(self, stage: str, wave: str, cause: BaseException) -> None:
        super().__init__("%s/%s: %r" % (stage, wave, cause))
        self.stage = stage
        self.wave = wave
        self.cause = cause


class CancelOnly(object):
    """Náhrada dialogu pro hledání bez UI: jediné, co umí, je říct „zrušeno“ (engine čte `iscanceled`)."""

    def __init__(self, should_cancel: Callable[[], bool]) -> None:
        self._should_cancel = should_cancel

    def __call__(self, *_a: Any, **_k: Any) -> None:
        return None

    def iscanceled(self) -> bool:
        try:
            return bool(self._should_cancel())
        except Exception:
            return False

    def set_phase(self, *_a: Any, **_k: Any) -> None:
        return None

    def tick(self) -> None:
        return None


def mark_wave(rels: Optional[List[Release]], tag: str) -> None:
    """Φ-A: vlna, která stream přinesla do výpisu (film P / ALT) — jen u položek bez značky (první vlna vyhrává).
    Nese se v cache až k `PLAY_PICK`."""
    for r in (rels or ()):
        try:
            if not getattr(r, "wave", ""):
                r.wave = tag
        except Exception:
            pass










def run_cascade(engine: Any, ctx: MovieSearchContext, *, log_event: LogFn, progress: Any = None,
                relogin: Optional[Callable[[], None]] = None,
                should_cancel: Optional[Callable[[], bool]] = None,
                kick_mi2: bool = True) -> CascadeResult:
    """Primární vlna, a když nic nenašla, záložní vlna s alternativními názvy.

    `progress` = dialog (nebo `CancelOnly`), `relogin` = obnova přihlášení po `TokenExpired`, po ní vlna běží znovu
    bez dialogu (bez `relogin` výjimka propaguje). `should_cancel` se ptá po každé vlně. `kick_mi2=False` = hledání
    na pozadí nespouští sken MediaInfo. Chyba zdroje = `WaveFailed`; zrušené ani neúplné hledání se neukládá (R2,
    hlídá engine)."""
    det = ctx.det
    banned = sorted(ctx.banned_keys)   # G1: pořadí nezávislé na hash seedu procesu (P2)
    memo: Dict[str, Any] = {}     # Φ-C: záložní vlna obsahuje i primární dotazy a nestahuje je podruhé
    result = CascadeResult()
    prog = {"cur": progress}

    def _wave(queries: Sequence[str], norms: Any, tag: str) -> List[Release]:
        stats: Dict[str, Any] = {}

        def _call(cb: Any) -> List[Release]:
            return engine.search_movie_wave(
                queries, runtimes=ctx.runtimes, title_norms=norms, banned_keys=banned,
                movie_year=det["year"], allowed_years=ctx.year_whitelist, progress_cb=cb,
                fetch_memo=memo, stats=stats, kick_mi2=kick_mi2,
            )

        try:
            found = _call(prog["cur"])
        except TokenExpired:
            if relogin is None:
                raise
            prog["cur"] = None
            try:
                relogin()
                found = _call(None)
            except Exception as exc:
                raise WaveFailed(STAGE_LOGIN, tag, exc) from exc
        except APIError as exc:
            raise WaveFailed(STAGE_API, tag, exc) from exc
        result.errors += int(stats.get("errors") or 0)
        result.rate_limited = result.rate_limited or bool(stats.get("rate_limited"))
        result.waves.append(tag)
        if should_cancel is not None and should_cancel():
            result.cancelled = True
        if stats.get("cancelled"):
            result.cancelled = True
        return found

    def _phase(text: str) -> None:
        if prog["cur"] is not None:
            prog["cur"].set_phase(text)

    _phase(PHASE_PRIMARY)
    rels = _wave(ctx.primary_q, ctx.primary_norms, WAVE_PRIMARY)
    if result.cancelled:
        return result
    mark_wave(rels, WAVE_PRIMARY)
    if rels:
        result.rels = rels
        result.wave = WAVE_PRIMARY
        return result

    _phase(PHASE_ALT)
    try:
        result.alt_titles = alt_titles_of(ctx.tmdb, ctx.tmdb_id)
    except TMDbError as exc:
        result.alt_titles = []
        _note_tmdb_failure(ctx, exc)
    if not result.alt_titles:
        return result

    log_event("SEARCH_FALLBACK", det["title"], len(result.alt_titles))
    alt_q, alt_norms = movie_alt_wave(ctx, result.alt_titles)
    rels_alt = _wave(alt_q, alt_norms, WAVE_ALT)
    if result.cancelled:
        return result
    mark_wave(rels_alt, WAVE_ALT)
    if rels_alt:
        result.rels = rels_alt
        result.wave = WAVE_ALT
    return result


def empty_is_authoritative(result: CascadeResult, ctx: MovieSearchContext) -> bool:
    """Smí se „nic nenalezeno“ zapamatovat? SSOT `rm_core.cascade.movie_empty_is_authoritative` (R2)."""
    return movie_empty_is_authoritative(result, ctx)
