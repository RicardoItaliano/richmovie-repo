# -*- coding: utf-8 -*-
"""Úklid místa na zařízení — jen při potřebě a s potvrzením (4.5.3, S68, 20.11.2026).

Proč: Martinin Chromecast měl 194 MB volna (446 → 194 za tři týdny). Android pak maže mezipaměť aplikace, kam Kodi
rozbaluje svůj Python a certifikáty z APK → chybějící moduly (`gzip`, `hmac`, `fractions`), `CERTIFICATE_VERIFY_FAILED`,
pády Kodi. Richie 20.11.2026: „a jsme schopni, aby to zajistil doplněk? … Nějaké čištění bezpečné s potvrzením?“ ·
„pouze v případě potřeby?“ (plán `Handoff/PLAN_ai_a_misto_20261120.md` F2, BACKLOG S68; cross-check a audit Fable F33).

Pravidla (každé hlídá harness 133):
  • Jen při potřebě: volno dat doplňku (`richmovie_diag.profile_free_mb` = totéž číslo jako `SESSION_ENV disk_free_mb`)
    pod `LOW_FREE_MB`; další nabídka až v čase `next_offer_at` ze značky `storage_offer.json` (týden po odpovědi, den po
    „Připomeň zítra“, oknu bez odpovědi, přerušeném nebo neúplném úklidu). Značka se zapíše PŘED oknem (pád Kodi uprostřed
    okna = týden klid) a těsně před oknem se přečte znovu (druhá instance služby po aktualizaci doplňku).
  • Jen s potvrzením a do klidu: okno ukáže změřená čísla po položkách; bez „Uvolnit“ se nesmaže nic. Nikdy přes
    přehrávač (ani pauzu), relaci přehrávání (mezera mezi díly), jiné modální okno (i okna RichMovie) ani kolečko Kodi.
    Okno bez odpovědi se po `ASK_AUTOCLOSE_MS` zavře samo.
  • Jen bezpečné (vždy z ČERSTVÉHO měření po potvrzení):
      (a) NAŠE staré ZIPy v `special://home/addons/packages/` — jen `plugin.video.richmovie-<verze>.zip` s verzí
          STARŠÍ než nainstalovaná (nainstalovaná ani novější = rozběhnutá aktualizace se nikdy nemaže; 4.5 = 4.5.0);
      (b) NAŠE logy hledání `special://logpath/richmovie/` starší `SEARCH_LOG_KEEP_DAYS` (data jsou v `user_logs`);
      (c) mezipaměť obrázků Kodi nepoužitá `TEXTURE_UNUSED_DAYS` dní — JEN JSON-RPC `Textures.RemoveTexture` (Kodi smaže
          soubor i řádek databáze a obrázek při dalším zobrazení stáhne znovu); soubory `Thumbnails/` se napřímo nemažou.
    Šetrně (`select_for_target`, Richie 20.11.: „co nejmenší efekt na uživatele“): (a) a (b) celé, obrázky od nejdéle
    nezobrazených (při shodě nejméně použitých) JEN dokud volno nedosáhne `TARGET_FREE_MB`.
    Nikdy: nastavení, historie, osobní data profilu, jiné doplňky, jiné aplikace.
  • Neúplné měření (RPC obrázků selhalo, strop času) nikdy nevede k radě „víc uvolnit nejde“ ani k týdenní značce.
  • Chyba jedné položky úklid nezastaví; výsledek se loguje (`STORAGE_MEASURE`, `STORAGE_OFFER`, `STORAGE_CLEANUP`).
Vědomé meze: měření `STORAGE_MEASURE` běží při každém startu s nízkým volnem (data, kdo místo bere — plán F2 c); Kodi
zapisuje `lastused` obrázků po dávkách, takže „nepoužité 30 dní“ je dolní odhad (nevadí — obrázek se stáhne znovu);
na zařízeních s novým vzhledem se okno ukáže až mimo okna RichMovie (nikdy přes ně).
Bez importu `plugin`; čisté funkce bez Kodi (harness).
"""
from __future__ import annotations

import json
import os
import re
import time
from typing import Any, Callable, Dict, Iterable, List, NamedTuple, Optional, Sequence, Tuple

try:
    import xbmc  # type: ignore
    import xbmcgui  # type: ignore
    import xbmcvfs  # type: ignore
except Exception:  # pragma: no cover — mimo Kodi (harness bez stubů)
    xbmc = None  # type: ignore
    xbmcgui = None  # type: ignore
    xbmcvfs = None  # type: ignore

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.storage", "RichMovie/Storage")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):  # type: ignore
        pass


LOW_FREE_MB = 500                 # pod tímhle volnem se nabídka zvažuje (flotila 20.11.: Martina 194, reno0 282, jinak ≥ 900)
TARGET_FREE_MB = 2 * LOW_FREE_MB  # úklid maže jen tolik, aby volno dosáhlo této hodnoty (Richie 20.11.: co nejmenší dopad)
OFFER_EVERY_S = 7 * 86400         # po odpovědi nejvýš jednou za týden na zařízení
RETRY_SOON_S = 86400              # „Připomeň zítra“, okno bez odpovědi, přerušený / neúplný úklid → znovu za den
FIRST_CHECK_DELAY_S = 90.0        # po startu služby: Kodi dobíhá start, uvítání a „Kdo se dívá?“
TICK_S = 15.0                     # jak často zkusit, jestli jde okno ukázat
SHOW_WAIT_MAX_S = 30 * 60         # nejdéle čekat na vhodnou chvíli (pak příští start)
SEARCH_LOG_KEEP_DAYS = 7
TEXTURE_UNUSED_DAYS = 30
MIN_WORTH_MB = 30                 # méně = okno jen poradí, kde místo uvolnit
MEASURE_MAX_S = 20.0              # strop času měření obrázků (velikosti souborů)
PROGRESS_EVERY = 50               # obnova průběhu po N smazaných položkách
ASK_AUTOCLOSE_MS = 120000         # okno bez odpovědi se po 2 min zavře samo
REPLY_TIMEOUT_SLACK_S = 2.0       # okno otevřené aspoň (autoclose − 2 s) a „ne“ = zavřelo se samo, nikdo neodpověděl
OFFER_FILE = "storage_offer.json"
ADDON_ID = "plugin.video.richmovie"
ADDON_ZIP_RE = re.compile(r"^plugin\.video\.richmovie-(\d+(?:\.\d+){1,3})\.zip$")
_LASTUSED_FMT = "%Y-%m-%d %H:%M:%S"
_MB = 1024 * 1024

# odpovědi a výsledky (značka + log)
ANSWER_ASKED = "asked"             # zapsáno PŘED oknem
ANSWER_FREE = "free"               # úklid proběhl celý
ANSWER_LATER = "later"             # „Teď ne“
ANSWER_INFO = "info"               # nebylo co uvolnit — rada, „Rozumím“
ANSWER_REMIND = "remind"           # rada, „Připomeň zítra“
ANSWER_UNANSWERED = "unanswered"   # okno se zavřelo samo
ANSWER_STOPPED = "stopped"         # úklid přerušilo ukončení Kodi
ANSWER_PARTIAL = "partial"         # čerstvé měření po potvrzení neúplné → smazáno, co bylo jisté, zbytek zítra

REPLY_YES = "yes"
REPLY_NO = "no"
REPLY_TIMEOUT = "timeout"


class Plan(NamedTuple):
    zips: List[Tuple[str, int]]          # (cesta, bajty)
    logs: List[Tuple[str, int]]          # (cesta, bajty)
    textures: List[Tuple[int, int]]      # (textureid, bajty) — od NEJMÉNĚ potřebného (`stale_textures`)
    thumbs_bytes: int                    # celá mezipaměť obrázků (změřená část)
    measured_all: bool                   # False = RPC obrázků selhalo / strop času / ukončení Kodi
    stale_bytes: int = 0                 # všechny zastaralé obrázky (před výběrem `select_for_target`) — jen log

    def total_bytes(self) -> int:
        return sum(b for _p, b in self.zips) + sum(b for _p, b in self.logs) + sum(b for _t, b in self.textures)


# ---------------------------------------------------------------------------
# Čistá rozhodnutí (bez Kodi, bez disku)
# ---------------------------------------------------------------------------

def needs_attention(free_mb: int, *, low_mb: int = LOW_FREE_MB) -> bool:
    """Volno pod prahem? Neznámé volno (-1) = ne (nic se nenabízí naslepo)."""
    return 0 <= int(free_mb) < int(low_mb)


def offer_due(next_offer_at: Optional[float], now: float) -> bool:
    """Nabídka je na řadě: značka není, nebo nastal její čas `next_offer_at`. Čas dál než týden a den v budoucnosti
    (posunuté hodiny) se nebere vážně — jinak by se nabídka zablokovala navždy."""
    if next_offer_at is None:
        return True
    try:
        nxt = float(next_offer_at)
    except (TypeError, ValueError):
        return True
    if nxt > now + OFFER_EVERY_S + 86400:
        return True
    return now >= nxt


def next_offer_after(answer: str, now: float) -> float:
    """Kdy nabídnout znovu po dané odpovědi / výsledku (JEDINÉ místo, kde se to rozhoduje)."""
    if answer in (ANSWER_REMIND, ANSWER_UNANSWERED, ANSWER_STOPPED, ANSWER_PARTIAL):
        return now + RETRY_SOON_S
    return now + OFFER_EVERY_S


def classify_reply(result: bool, elapsed_s: float, *, autoclose_ms: int = ASK_AUTOCLOSE_MS) -> str:
    """Odpověď z `Dialog().yesno` s `autoclose`: Kodi vrátí False i po vypršení → rozliší to doba otevření okna."""
    if result:
        return REPLY_YES
    if elapsed_s >= autoclose_ms / 1000.0 - REPLY_TIMEOUT_SLACK_S:
        return REPLY_TIMEOUT
    return REPLY_NO


def can_show(*, player: bool, modal: bool, busy: bool) -> bool:
    """Okno jen do klidu: žádný přehrávač ani relace přehrávání, žádné jiné modální okno, žádné kolečko Kodi."""
    return not (player or modal or busy)


def _version_tuple(text: str) -> Optional[Tuple[int, ...]]:
    """Verze jako n-tice bez koncových nul — `4.5` a `4.5.0` jsou TÁŽ verze (cross-check 20.11.: `(4, 5) < (4, 5, 0)`
    by smazal ZIP nainstalované verze)."""
    try:
        parts = [int(p) for p in str(text).strip().split(".")]
    except (TypeError, ValueError):
        return None
    while len(parts) > 1 and parts[-1] == 0:
        parts.pop()
    return tuple(parts)


def old_addon_zips(entries: Iterable[Tuple[str, int]], installed_version: str) -> List[Tuple[str, int]]:
    """Ze záznamů `(jméno souboru, bajty)` složky packages vybere NAŠE ZIPy s verzí STARŠÍ než nainstalovaná.
    Neznámá nainstalovaná verze = nic (bez jistoty se nemaže)."""
    installed = _version_tuple(installed_version)
    if not installed:
        return []
    out = []
    for name, size in entries:
        m = ADDON_ZIP_RE.match(str(name))
        if not m:
            continue
        ver = _version_tuple(m.group(1))
        if ver is not None and ver < installed:
            out.append((str(name), int(size)))
    return out


def old_logs(entries: Iterable[Tuple[str, float, int, bool]], now: float,
             keep_days: int = SEARCH_LOG_KEEP_DAYS) -> List[Tuple[str, int]]:
    """Ze záznamů `(jméno, mtime, bajty, je_soubor)` NAŠÍ složky logů vybere soubory starší než `keep_days`."""
    cutoff = now - keep_days * 86400
    return [(str(n), int(s)) for n, mt, s, is_file in entries if is_file and float(mt) < cutoff]


def _lastused_epoch(text: Any) -> Optional[float]:
    try:
        return time.mktime(time.strptime(str(text).strip(), _LASTUSED_FMT))
    except Exception:
        return None


def stale_textures(textures: Sequence[Dict[str, Any]], now: float, size_of: Callable[[str], int], *,
                   unused_days: int = TEXTURE_UNUSED_DAYS,
                   deadline: Optional[float] = None,
                   clock: Callable[[], float] = time.monotonic,
                   should_stop: Optional[Callable[[], bool]] = None) -> Tuple[List[Tuple[int, int]], int, bool]:
    """Obrázky z `Textures.GetTextures` (`textureid`, `cachedurl`, `sizes[].lastused`, `sizes[].usecount`) nepoužité
    `unused_days` dní. Rozhoduje NEJNOVĚJŠÍ použití ze všech velikostí; bez data / nečitelné datum / bez id = ponechat
    (bez jistoty se nemaže).
    Dvě fáze (audit Fable F34 V3, cross-check P5): (1) BEZ disku stáří a počty použití → kandidáti od nejméně potřebného;
    (2) velikosti JEN kandidátů v tomto pořadí — strop času / ukončení Kodi tak odřízne ty potřebnější, ne nejstarší; celek
    mezipaměti (jen pro log) až nakonec a jen když zbude čas (pak je to dolní odhad).
    Konečné pořadí (cross-check P1): DEN posledního použití, počet použití, VĚTŠÍ soubor dřív (stejné místo = méně
    smazaných obrázků, které se budou stahovat znovu), id. Velikost nečitelná u většiny kandidátů = neúplné měření (F34 V4).
    Vrací (zastaralé [(id, bajty)], bajty změřených, kandidáti změření celí?)."""
    cutoff = now - unused_days * 86400
    cands: List[Tuple[int, int, int, Optional[str]]] = []    # (den, počet použití, id, cachedurl)
    rest: List[str] = []                                     # cachedurl ostatních — jen celek pro log
    for tex in textures:
        if should_stop is not None and should_stop():
            return [], 0, False
        if not isinstance(tex, dict):
            continue
        tid = tex.get("textureid")
        if not isinstance(tid, int) or isinstance(tid, bool):
            continue
        cached = tex.get("cachedurl")
        cached = cached if isinstance(cached, str) and cached else None
        sizes = [s for s in (tex.get("sizes") or []) if isinstance(s, dict)]
        uses = [_lastused_epoch(s.get("lastused")) for s in sizes]
        if uses and all(u is not None for u in uses) and max(uses) < cutoff:
            count = 0
            for s in sizes:
                c = s.get("usecount")
                if isinstance(c, int) and not isinstance(c, bool) and c > 0:
                    count += c
            cands.append((int(max(uses) // 86400), count, tid, cached))
        elif cached:
            rest.append(cached)
    cands.sort(key=lambda r: (r[0], r[1], r[2]))

    def _expired() -> bool:
        return (deadline is not None and clock() > deadline) or (should_stop is not None and should_stop())

    sized: List[Tuple[int, int, int, int, int]] = []         # (den, počet, −bajty, id, bajty)
    unknown = 0
    total = 0
    done = True
    for day, count, tid, cached in cands:
        if _expired():
            done = False
            break
        size = 0
        if cached:
            try:
                size = max(0, int(size_of(cached)))
            except Exception:
                unknown += 1
        total += size
        sized.append((day, count, -size, tid, size))
    if cands and unknown * 2 >= len(cands):
        done = False
    if done:
        for cached in rest:
            if _expired():
                break
            try:
                total += max(0, int(size_of(cached)))
            except Exception:
                pass
    sized.sort()
    return [(tid, size) for _d, _c, _n, tid, size in sized], total, done


def select_for_target(plan: Plan, free_mb: int, *, target_mb: int = TARGET_FREE_MB) -> Plan:
    """Šetrný výběr (Richie 20.11.2026: „aby to mělo co nejmenší efekt na uživatele“): naše staré ZIPy a logy vždy
    celé (na nich nic nevisí), obrázky od nejméně potřebného JEN do chvíle, kdy volno dosáhne `target_mb`; obrázek bez
    změřené velikosti nic neuvolní → nevybírá se. Nestačí-li ani všechny, vezmou se všechny zastaralé."""
    need = max(0, int(target_mb) - int(free_mb)) * _MB
    need -= sum(b for _p, b in plan.zips) + sum(b for _p, b in plan.logs)
    picked: List[Tuple[int, int]] = []
    for tid, size in plan.textures:
        if need <= 0:
            break
        if size <= 0:
            continue
        picked.append((tid, size))
        need -= size
    return plan._replace(textures=picked, stale_bytes=sum(b for _t, b in plan.textures))


def thumb_rel_parts(cached: str) -> Optional[List[str]]:
    """`cachedurl` z Kodi (relativní `b/bc589d21.jpg`, výjimečně `special://thumbnails/…`) → části cesty uvnitř
    složky obrázků; cokoli, co by z ní vedlo ven (`..`, písmeno disku, prázdné), = None (jen měření, mazání jde přes RPC)."""
    rel = str(cached).replace("\\", "/")
    if rel.startswith("special://thumbnails/"):
        rel = rel[len("special://thumbnails/"):]
    rel = rel.lstrip("/")
    parts = [p for p in rel.split("/") if p]
    if not parts or any(p == ".." or ":" in p for p in parts):
        return None
    return parts


def _mb(nbytes: int) -> int:
    return int(round(max(0, nbytes) / _MB))


def offer_text(free_mb: int, plan: Plan) -> Tuple[bool, str, str]:
    """(stojí za to?, nadpis, text okna). Pod `MIN_WORTH_MB` jen pravdivá rada, kde místo uvolnit."""
    heading = "Na zařízení dochází místo"
    total = _mb(plan.total_bytes())
    if total < MIN_WORTH_MB:
        return False, heading, (
            "Volné místo: %d MB. Když dojde úplně, Kodi začne padat.\n"
            "RichMovie samo bezpečně uvolní jen %d MB – zbytek zabírají jiné aplikace nebo jiné části Kodi.\n"
            "Uvolni místo v nastavení zařízení (Úložiště): nepoužívané aplikace odinstaluj, u velkých vymaž mezipaměť."
            % (int(free_mb), total))
    lines = ["Volné místo: %d MB. Když dojde úplně, Kodi začne padat." % int(free_mb),
             "RichMovie může uvolnit asi %d MB – po úklidu bude volno asi %d MB:" % (total, int(free_mb) + total)]
    tex = _mb(sum(b for _t, b in plan.textures))
    zips = _mb(sum(b for _p, b in plan.zips))
    logs = _mb(sum(b for _p, b in plan.logs))
    if plan.zips:
        lines.append("• staré verze RichMovie (%d MB)" % zips)
    if plan.logs:
        lines.append("• staré záznamy hledání (%d MB)" % logs)
    if plan.textures:
        only_needed = plan.stale_bytes > sum(b for _t, b in plan.textures)
        lines.append("• obrázky, které se nejdéle nezobrazily (%d MB)%s – při dalším zobrazení se samy stáhnou"
                     % (tex, " – jen kolik je potřeba" if only_needed else ""))
    return True, heading, "\n".join(lines)


def done_text(freed_bytes: int, free_after_mb: int, *, partial: bool = False) -> str:
    head = "Uvolněno %d MB%s" % (_mb(freed_bytes), " (zbytek zkusím zítra)" if partial else "")
    if free_after_mb >= 0:
        return "%s · volno teď %d MB" % (head, free_after_mb)
    return head


def cleanup(plan: Plan, *, remove_file: Callable[[str], None], remove_texture: Callable[[int], bool],
            should_stop: Callable[[], bool] = lambda: False,
            progress: Optional[Callable[[int, int], None]] = None) -> Dict[str, int]:
    """Smaže položky plánu. Chyba jedné položky ostatní nezastaví; `should_stop` (ukončení Kodi) přeruší mezi položkami.
    Vrací počty a bajty po druzích + `errors`, `stopped`."""
    out = {"zips": 0, "zips_bytes": 0, "logs": 0, "logs_bytes": 0, "textures": 0, "textures_bytes": 0,
           "errors": 0, "stopped": 0}
    steps = len(plan.zips) + len(plan.logs) + len(plan.textures)
    done = 0

    def _tick():
        if progress is not None and (done % PROGRESS_EVERY == 0 or done == steps):
            try:
                progress(done, steps)
            except Exception:
                pass

    for kind, items in (("zips", plan.zips), ("logs", plan.logs)):
        for path, size in items:
            if should_stop():
                out["stopped"] = 1
                return out
            try:
                remove_file(path)
                out[kind] += 1
                out[kind + "_bytes"] += int(size)
            except Exception:
                out["errors"] += 1
            done += 1
            _tick()
    for tid, size in plan.textures:
        if should_stop():
            out["stopped"] = 1
            return out
        try:
            if remove_texture(tid):
                out["textures"] += 1
                out["textures_bytes"] += int(size)
            else:
                out["errors"] += 1
        except Exception:
            out["errors"] += 1
        done += 1
        _tick()
    return out


def freed_bytes(result: Dict[str, int]) -> int:
    return int(result.get("zips_bytes", 0)) + int(result.get("logs_bytes", 0)) + int(result.get("textures_bytes", 0))


# ---------------------------------------------------------------------------
# Kodi a disk
# ---------------------------------------------------------------------------

def _translate(path: str) -> str:
    try:
        return xbmcvfs.translatePath(path) if xbmcvfs is not None else path
    except Exception:
        return path


def packages_dir() -> str:
    return _translate("special://home/addons/packages/")


def search_log_dir() -> str:
    """Složka logů hledání — tatáž jako u `plugin._auto_cleanup_logs`."""
    return _translate("special://logpath/richmovie/")


def thumbnails_dir() -> str:
    return _translate("special://thumbnails/")


def free_mb() -> int:
    """Volno dat doplňku v MB — JEDINÁ definice `richmovie_diag.profile_free_mb` (= `SESSION_ENV disk_free_mb`)."""
    try:
        import richmovie_diag
        return int(richmovie_diag.profile_free_mb())
    except Exception:
        return -1


def _installed_version() -> str:
    try:
        import xbmcaddon  # type: ignore
        return str(xbmcaddon.Addon(ADDON_ID).getAddonInfo("version") or "")
    except Exception:
        return ""


def _scan_files(directory: str) -> List[Tuple[str, float, int, bool]]:
    out = []
    try:
        with os.scandir(directory) as it:
            for e in it:
                try:
                    st = e.stat(follow_symlinks=False)
                    out.append((e.name, float(st.st_mtime), int(st.st_size), e.is_file(follow_symlinks=False)))
                except OSError:
                    continue
    except OSError:
        return []
    return out


def _rpc(method: str, params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """JSON-RPC Kodi; None = chyba (nic se nerozhoduje naslepo)."""
    if xbmc is None:
        return None
    try:
        req = {"jsonrpc": "2.0", "id": 1, "method": method}
        if params:
            req["params"] = params
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return None
    if not isinstance(resp, dict) or "error" in resp:
        return None
    return resp


def parse_textures_response(resp: Optional[Dict[str, Any]]) -> Optional[List[Dict[str, Any]]]:
    """Přesný tvar odpovědi `Textures.GetTextures`: `{"result": {"textures": [...]}}`; jiný tvar / chyba = None
    (neúplné měření). Prázdná mezipaměť Kodi vrací `result` bez klíče `textures` = [] (žádné obrázky)."""
    if not isinstance(resp, dict):
        return None
    result = resp.get("result")
    if not isinstance(result, dict):
        return None
    tex = result.get("textures", [])
    return tex if isinstance(tex, list) else None


def _textures() -> Optional[List[Dict[str, Any]]]:
    return parse_textures_response(_rpc("Textures.GetTextures", {"properties": ["cachedurl", "sizes"]}))


def _remove_texture(textureid: int) -> bool:
    resp = _rpc("Textures.RemoveTexture", {"textureid": int(textureid)})
    return bool(resp) and resp.get("result") == "OK"


def measure(now: Optional[float] = None, should_stop: Optional[Callable[[], bool]] = None) -> Plan:
    """Změří, co jde bezpečně uvolnit (cesty jsou absolutní a jen uvnitř naší složky packages / logů). Obrázky jen přes
    JSON-RPC; chyba RPC = žádné obrázky a `measured_all = False` (neúplné měření nesmí vést k radě „víc nejde“)."""
    now = time.time() if now is None else now
    pkg = packages_dir()
    zip_entries = [(n, s) for n, _m, s, f in _scan_files(pkg) if f]
    zips = [(os.path.join(pkg, n), s) for n, s in old_addon_zips(zip_entries, _installed_version())]
    logd = search_log_dir()
    logs = [(os.path.join(logd, n), s) for n, s in old_logs(_scan_files(logd), now)]
    textures: List[Tuple[int, int]] = []
    thumbs = 0
    measured_all = True
    tex = _textures()
    if tex is None:
        measured_all = False
    else:
        base = thumbnails_dir()

        def _size(cached: str) -> int:
            parts = thumb_rel_parts(cached)
            return 0 if parts is None else os.path.getsize(os.path.join(base, *parts))
        textures, thumbs, measured_all = stale_textures(tex, now, _size, deadline=time.monotonic() + MEASURE_MAX_S,
                                                        should_stop=should_stop)
    return Plan(zips=zips, logs=logs, textures=textures, thumbs_bytes=thumbs, measured_all=measured_all)


def _marker_path() -> str:
    import richmovie_paths
    return str(richmovie_paths.account_path(OFFER_FILE))


def read_next_offer(data: Any) -> Optional[float]:
    """Čas další nabídky ze značky; starší tvar bez `next_offer_at` = `offered_at` + týden. Vadná značka = None."""
    if not isinstance(data, dict):
        return None
    nxt = data.get("next_offer_at")
    if isinstance(nxt, (int, float)) and not isinstance(nxt, bool):
        return float(nxt)
    off = data.get("offered_at")
    if isinstance(off, (int, float)) and not isinstance(off, bool):
        return float(off) + OFFER_EVERY_S
    return None


def _read_next_offer() -> Optional[float]:
    try:
        import richmovie_atomic
        data, _state = richmovie_atomic.read_json(_marker_path(), {}, name=OFFER_FILE, expected_type=dict)
        return read_next_offer(data)
    except Exception:
        return None


def _write_offer(now: float, answer: str, free: int) -> bool:
    """Značka nabídky; nezapsaná značka (plný disk) se zaloguje — nabídka pak přijde i při dalším startu (je potřeba)."""
    ok = False
    try:
        import richmovie_atomic
        ok = bool(richmovie_atomic.write_json(_marker_path(), {
            "offered_at": float(now), "answer": answer, "free_mb": int(free),
            "next_offer_at": next_offer_after(answer, now)}))
    except Exception:
        ok = False
    if not ok:
        _log("STORAGE_MARKER_WRITE_FAILED answer=%s free_mb=%d" % (answer, int(free)), 2)
    return ok


def _cond(expr: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(expr)) if xbmc is not None else False
    except Exception:
        return False


def _show_state() -> Tuple[bool, bool, bool]:
    """(přehrávač nebo relace přehrávání, modální okno, kolečko) — z JEDINÝCH definic `richmovie_playback_dispatch`
    (`player_present`, `session_active` = mezera mezi díly před autoplay, `busy_dialog_active`); nečitelný stav = ano."""
    try:
        import richmovie_playback_dispatch as _dispatch
        player = bool(_dispatch.player_present(on_error=True)) or bool(_dispatch.session_active())
        busy = bool(_dispatch.busy_dialog_active(on_error=True))
    except Exception:
        player, busy = True, True
    return player, _cond("System.HasActiveModalDialog"), busy


def _dialog(heading: str, text: str, *, nolabel: str, yeslabel: str) -> str:
    """Okno s `autoclose` → `REPLY_YES` / `REPLY_NO` / `REPLY_TIMEOUT` (zavřelo se samo — nikdo neodpověděl)."""
    started = time.monotonic()
    result = bool(xbmcgui.Dialog().yesno(heading, text, nolabel=nolabel, yeslabel=yeslabel, autoclose=ASK_AUTOCLOSE_MS))
    return classify_reply(result, time.monotonic() - started)


def _ask(heading: str, text: str) -> str:
    return _dialog(heading, text, nolabel="Teď ne", yeslabel="Uvolnit")


def _inform(heading: str, text: str) -> str:
    return _dialog(heading, text, nolabel="Připomeň zítra", yeslabel="Rozumím")


def _toast(msg: str) -> None:
    try:
        from richmovie_helpers import notif
        notif(msg, heading="RichMovie")
    except Exception:
        pass


def _plan_log(free: int, plan: Plan) -> str:
    return ("free_mb=%d pkgs_mb=%d pkgs=%d logs_mb=%d logs=%d thumbs_mb=%d thumbs_stale_mb=%d textures=%d measured_all=%s"
            % (free, _mb(sum(b for _p, b in plan.zips)), len(plan.zips), _mb(sum(b for _p, b in plan.logs)),
               len(plan.logs), _mb(plan.thumbs_bytes),
               _mb(plan.stale_bytes or sum(b for _t, b in plan.textures)), len(plan.textures), plan.measured_all))


def run_service(monitor) -> str:
    """Tělo vlákna služby (jednou za start služby). Vrací výsledek (pro log a harness)."""
    if monitor.waitForAbort(FIRST_CHECK_DELAY_S):
        return "abort"
    free = free_mb()
    if free < 0:
        # nezjištěné volno nesmí mlčet (vypadalo by stejně jako „místa dost“)
        _log("STORAGE_CHECK free_mb=-1 (volno nezjištěno → nic se nenabízí)", 2)
        return "unknown_space"
    if not needs_attention(free):
        _log("STORAGE_CHECK free_mb=%d ok (práh %d MB)" % (free, LOW_FREE_MB), 0)
        return "ok_space"
    full = measure(should_stop=monitor.abortRequested)
    _log("STORAGE_MEASURE " + _plan_log(free, full), 1)
    if monitor.abortRequested():
        return "abort"
    plan = select_for_target(full, free)
    if not offer_due(_read_next_offer(), time.time()):
        _log("STORAGE_OFFER skip:recent free_mb=%d" % free, 1)
        return "recent"
    waited = 0.0
    while not can_show(**dict(zip(("player", "modal", "busy"), _show_state()))):
        if waited >= SHOW_WAIT_MAX_S:
            _log("STORAGE_OFFER skip:no_quiet_moment free_mb=%d" % free, 1)
            return "no_quiet_moment"
        if monitor.waitForAbort(TICK_S):
            return "abort"
        waited += TICK_S
    # znovu těsně před oknem: během čekání mohla nabídku ukázat jiná instance služby (restart po aktualizaci doplňku)
    if not offer_due(_read_next_offer(), time.time()):
        _log("STORAGE_OFFER skip:recent_after_wait free_mb=%d" % free, 1)
        return "recent"
    # čísla okna z volna TĚSNĚ před oknem (čekání až 30 min — F34 V2, cross-check P3): místo se mohlo mezitím uvolnit
    fresh = free_mb()
    if fresh >= 0:
        free = fresh
        if not needs_attention(free):
            _log("STORAGE_OFFER skip:space_recovered free_mb=%d" % free, 1)
            return "ok_space"
        plan = select_for_target(full, free)
    worth, heading, text = offer_text(free, plan)
    reclaim = _mb(plan.total_bytes())
    if not worth and not plan.measured_all:
        # neúplné měření (RPC obrázků selhalo / strop času) NESMÍ vést k radě „víc uvolnit nejde“ ani k značce
        _log("STORAGE_OFFER skip:measure_incomplete free_mb=%d reclaimable_mb=%d" % (free, reclaim), 1)
        return "measure_incomplete"
    # značka PŘED oknem: pád Kodi uprostřed okna = týden klid (odpověď ji pak přepíše)
    _write_offer(time.time(), ANSWER_ASKED, free)
    if not worth:
        reply = _inform(heading, text)
        answer = {REPLY_YES: ANSWER_INFO, REPLY_NO: ANSWER_REMIND}.get(reply, ANSWER_UNANSWERED)
        _write_offer(time.time(), answer, free)
        _log("STORAGE_OFFER %s free_mb=%d reclaimable_mb=%d" % (answer, free, reclaim), 1)
        return answer
    reply = _ask(heading, text)
    if reply != REPLY_YES:
        answer = ANSWER_LATER if reply == REPLY_NO else ANSWER_UNANSWERED
        _write_offer(time.time(), answer, free)
        _log("STORAGE_OFFER %s free_mb=%d reclaimable_mb=%d" % (answer, free, reclaim), 1)
        return answer
    bg = None
    try:
        bg = xbmcgui.DialogProgressBG()
        bg.create("RichMovie", "Připravuji úklid…")
    except Exception:
        bg = None

    def _progress(done: int, steps: int) -> None:
        if bg is not None and steps:
            bg.update(int(100 * done / steps), "RichMovie", "Uvolňuji místo…")

    try:
        # čerstvý plán: okno mohlo čekat na odpověď — obrázek, který se mezitím zobrazil, ani ZIP z aktualizace, která
        # mezitím proběhla, se nesmaže (cross-check 20.11., P5 d / e)
        fresh_free = free_mb()
        plan = select_for_target(measure(should_stop=monitor.abortRequested), fresh_free if fresh_free >= 0 else free)
        result = cleanup(plan, remove_file=os.remove, remove_texture=_remove_texture,
                         should_stop=monitor.abortRequested, progress=_progress)
    finally:
        if bg is not None:
            try:
                bg.close()
            except Exception:
                pass
    after = free_mb()
    if result["stopped"] or monitor.abortRequested():
        answer = ANSWER_STOPPED
    elif not plan.measured_all and (after < 0 or after < TARGET_FREE_MB):
        # neúplné měření A cíl nedosažen = zbytek zítra (F35 V3: cíl dosažený i z neúplného měření = hotovo)
        answer = ANSWER_PARTIAL
    else:
        answer = ANSWER_FREE
    _write_offer(time.time(), answer, after if after >= 0 else free)
    _log("STORAGE_CLEANUP %s freed_mb=%d zips=%d logs=%d textures=%d errors=%d free_before_mb=%d free_after_mb=%d"
         % (answer, _mb(freed_bytes(result)), result["zips"], result["logs"], result["textures"], result["errors"],
            free, after), 1)
    if answer != ANSWER_STOPPED:
        _toast(done_text(freed_bytes(result), after, partial=answer == ANSWER_PARTIAL))
    return answer
