# -*- coding: utf-8 -*-
"""rm_core.context — kontext filtru a stavba dotazů pro film i díl seriálu z údajů TMDb (přesun 1 : 1, G1).

Vstupem je objekt TMDb (doplněk: `tmdb_client.TMDb`, Gate: `rm_core.tmdb_logic.MemoryTmdb`); síť ani disk tady nejsou.
Doplněk dál volá své obálky (`richmovie_movie_search`, `richmovie_episode_search`)."""
from __future__ import annotations

import datetime
import re
from typing import Any, Callable, List, Optional, Sequence, Set, Tuple

from rm_core.errors import TMDbError, TMDbNotFoundError
from rm_core.filter_tv import TV_TITLE_STOP
from rm_core.queries import _ALT_COUNTRY_WHITELIST, _ALT_MAX_TITLES, QueryBuilder, query_variants
from rm_core.text import EROTIC_KEYWORDS, _is_adult_title, norm as _norm
from rm_core.text import _phrase_contains, norm, sanitize_ban_tokens  # noqa: F401  (spin_tokens)

LogFn = Callable[..., None]

# Jemná ruční doplnění pro známé série (nebo když kolekce chybí)
_MANUAL_BANNED = ("prometheus", "covenant", "resurrection", "aliens", "predator", "avp")
# Samostatné slovo z názvu jiného dílu kolekce jako ban: z lokalizovaného názvu od 4 znaků (beze změny), z originálního
# od 6 znaků (jádro 1.2.0, audit Fable F18 V2).
BAN_WORD_MIN = 4
ORIGINAL_BAN_WORD_MIN = 6


class MovieSearchContext(object):
    """Vstupy hledání filmu. Počítá `build_context` — jednou pro výpis i pro hledání bez UI."""

    __slots__ = ("tmdb", "tmdb_id", "det", "runtimes", "year_whitelist", "banned_keys",
                 "primary_q", "primary_norms", "degraded")


def note_movie_tmdb_failure(ctx: MovieSearchContext, exc: BaseException) -> None:
    """„Nenalezeno“ je autoritativní odpověď; cokoli jiného znamená chudší kontext → prázdný výsledek pak není
    autoritativní (R2, stejný výklad jako `richmovie_episode_search`)."""
    if not isinstance(exc, TMDbNotFoundError):
        ctx.degraded += 1


def build_movie_context(tmdb: Any, tmdb_id: int) -> MovieSearchContext:
    """Detail, stopáže, roky, lokalizované názvy, BAN klíče kolekce, dotazy primární vlny.

    `TMDbError` z detailu nebo stopáží propaguje (bez detailu se hledat nedá, hlášku určí volající); selhání
    doplňkových údajů znamená chudší kontext (`degraded`), hledání běží dál. `det["rm_runtimes"]` = referenční
    stopáže pro runtime sanity ve výpisu (parita s TV listem)."""
    ctx = MovieSearchContext()
    ctx.tmdb = tmdb
    ctx.tmdb_id = tmdb_id
    ctx.degraded = 0

    det, det_complete = tmdb.details_ex(tmdb_id)
    ctx.det = det
    if not det_complete:
        # Částečný detail / obohacení po chybě = chudší dotazy (např. nelatinkový název) → prázdno není autoritativní (R2)
        ctx.degraded = int(ctx.degraded or 0) + 1

    # Stopáže: primární + alternativní
    runtimes = [int(det.get("runtime") or 0)] + tmdb.get_alt_runtimes(tmdb_id)

    # Whitelist povolených roků pro FILTR (produkční + hlavní trhy)
    try:
        ctx.year_whitelist = tmdb.allowed_years(tmdb_id, primary_year=det.get("year"))
    except TMDbError as exc:
        ctx.year_whitelist = []
        note_movie_tmdb_failure(ctx, exc)

    # vyčistit stopáže (minuty > 0) + dedupe
    runtimes = [rt for rt in runtimes if rt]
    try:
        runtimes = sorted({int(rt) for rt in runtimes if int(rt) > 0})
    except Exception:
        pass
    ctx.runtimes = runtimes

    # NOVĚ: reference stopáže pro runtime sanity ve výpisu streamů (best-effort)
    try:
        det["rm_runtimes"] = list(runtimes)
    except Exception:
        pass

    # BAN klíče z TMDb kolekce (vyřadí Prometheus/Covenant/… i když v názvu není rok)
    # collection_parts() VRACÍ LIST ŘETĚZCŮ (titulů), nikoli dict – proto s nimi pracujeme jako s texty.
    banned_keys: Set[str] = set()
    coll = det.get("belongs_to_collection") or {}
    coll_id = 0
    if isinstance(coll, dict):
        try:
            coll_id = int(coll.get("id") or 0)
        except Exception:
            coll_id = 0

    # Φ-B (30.09.2026, E3-F02): oficiální lokalizované názvy (EN, CS, SK, PL) — JEN pro filtr (shoda názvu,
    # vlastní slova cíle se nebanují). Dotazy se nemění (žádný požadavek navíc na Webshare / Fastshare).
    try:
        loc_titles = [t for t in tmdb.movie_localized_titles(tmdb_id)
                      if _norm(t) and _norm(t) not in (_norm(det.get("title") or ""),
                                                       _norm(det.get("original_title") or ""))]
    except TMDbError as exc:
        loc_titles = []
        note_movie_tmdb_failure(ctx, exc)
    loc_norms = {_norm(t) for t in loc_titles}

    base_norms = {_norm(det.get("title") or ""), _norm(det.get("original_title") or "")} | loc_norms
    base_norms.discard("")
    base_words = {w for nm in base_norms for w in nm.split() if w}

    if coll_id:
        try:
            # 2025-09-28 FIX: ban-klíče z kolekce nesmí odstřelit aktuální díl
            #  • Jednoslovný kořen, který je součástí názvu aktuálního filmu, NEBANUJEME.
            #  • Víceslovou frázi přidáme jen tehdy, pokud obsahuje aspoň JEDNO slovo mimo aktuální název.
            # Jádro 1.2.0: i ORIGINÁLNÍ názvy dílů (Hunger Games: „the-hunger-games-the-ballad-of-songbirds…“ dřív prošlo,
            # bany znaly jen české názvy). Z originálů jen fráze a slova od ORIGINAL_BAN_WORD_MIN znaků — kratší anglická
            # slova („with“, „free“, „good“, „live“) bývají i ve jménech správného filmu (audit Fable F18 V2).
            parts = [(t, BAN_WORD_MIN) for t in (tmdb.collection_parts(coll_id) or [])]
            parts += [(t, ORIGINAL_BAN_WORD_MIN) for t in (tmdb.collection_part_originals(coll_id) or [])]
            for title, word_min in parts:
                nt = _norm(title)
                if not nt or nt in base_norms:
                    # přesný název právě hledaného dílu nebanovat
                    continue

                nt_words = [w for w in nt.split() if w]

                # 1) celá fráze JEN když má ≥2 slova A není čistým subsetem slov aktuálního filmu
                #    – falešné zásahy typu "equalizer" u "equalizer 2" nebo "john wick" u "john wick 2"
                if len(nt_words) >= 2 and not set(nt_words).issubset(base_words):
                    banned_keys.add(nt)

                # 2) výrazná slova (≥4 znaky; z originálu ≥ 6), která nejsou součástí aktuálního filmu
                for w in nt_words:
                    if len(w) >= word_min and w not in base_words:
                        banned_keys.add(w)

        except TMDbError as exc:
            note_movie_tmdb_failure(ctx, exc)

    for w in _MANUAL_BANNED:
        if w not in base_words:
            banned_keys.add(w)

    # Sanity: odfiltruj prázdné/čistě číselné tokeny
    ctx.banned_keys = {bk for bk in banned_keys if bk and not bk.isdigit()}

    # primární dotazy (bez alt-titlů)
    ctx.primary_q = query_variants(det["title"], det["original_title"], det["year"])
    primary_norms = {_norm(det["title"]), _norm(det["original_title"])} | loc_norms
    ctx.primary_norms = primary_norms
    return ctx


def alt_titles_of(tmdb: Any, tmdb_id: int) -> List[str]:
    """Alternativní názvy pro záložní vlnu. Selhání TMDb = žádná záložní vlna (vyhodnotí volající)."""
    return [rec["title"]
            for rec in tmdb.alternative_titles(tmdb_id, max_items=_ALT_MAX_TITLES)
            if rec["country"] in _ALT_COUNTRY_WHITELIST]


class EpisodeBase(object):
    """Údaje o dílu z TMDb, které potřebuje VYKRESLENÍ výpisu i hledání (vše z lokální cache TMDb)."""

    __slots__ = ("tv_id", "tv_name", "season_no", "ep_no", "ep_title", "det", "ep_cs", "ep_en",
                 "tv_names", "ep_names", "tmdb_cs", "tmdb_key", "degraded")


def note_episode_tmdb_failure(base: "EpisodeBase", exc: BaseException) -> None:
    """Selhání TMDb při stavbě kontextu hledání. „Nenalezeno“ je autoritativní odpověď (titul ten údaj nemá);
    cokoli jiného (síť, 5xx, 429, odmítnutá identita) znamená, že hledání poběží s CHUDŠÍMI dotazy, než by
    mělo → prázdný výsledek pak není autoritativní (R2; audit Fable F1-V3)."""
    if not isinstance(exc, TMDbNotFoundError):
        base.degraded = int(getattr(base, "degraded", 0) or 0) + 1


class EpisodeSearchContext(object):
    """Vstupy hledání dílu: dotazy + parametry filtru. Počítá `build_context` — jednou pro obě cesty."""

    __slots__ = ("base", "tv_names", "ep_names", "queries", "title_norms", "ser_title_variants",
                 "ep_title_variants", "banned_keys", "allowed_years", "ban_removed", "extra_w3", "degraded",
                 "homonym_variants", "homonym_unknown", "homonym_partial")


# Jádro 1.2.2 (audit Fable F28 V1): u kolika stejnojmenných seriálů se v jednom kontextu ptáme na řady (`tv_episode_counts`,
# 1 dotaz TMDb s cache 7 dní na jmenovce). Za stropem se jmenovec počítá bez kontroly (přísněji, nikdy volněji).
HOMONYM_DETAIL_MAX = 6


def _canon_title(name: Any) -> Tuple[str, ...]:
    """Název seriálu k porovnání: normalizovaná slova bez stop slov TV (jako `filter_tv`)."""
    return tuple(t for t in (_norm(w) for w in str(name or "").split()) if t and t not in TV_TITLE_STOP)


def homonym_candidates(own_id: Any, variants: Sequence[Sequence[str]], results: Sequence[Any]) -> List[Any]:
    """JINÉ seriály z výsledků `TmdbLogic.search_tv_names`, jejichž název (`name` nebo `original_name`) je vlastní variantou
    názvu seriálu (`ser_title_variants`, porovnání bez stop slov TV) — jednou podle id, v pořadí výsledků. Čistá funkce."""
    own = str(own_id or "")
    mine = {tuple(t for t in v if t and t not in TV_TITLE_STOP) for v in (variants or ())}
    mine.discard(())
    out: List[Any] = []
    seen: Set[str] = set()
    for r in results or ():
        if not isinstance(r, dict):
            continue
        rid = str(r.get("id") or "")
        if not rid or rid == own or rid in seen:
            continue
        if any(_canon_title(r.get(key)) in mine for key in ("name", "original_name")):
            seen.add(rid)
            out.append(r)
    return out


def can_have_episode(counts: Any, season_no: Any, ep_no: Any, airing: bool = False) -> bool:
    """Má seriál s řadami `counts` ({řada: počet dílů}, `TmdbLogic.tv_episode_counts`) díl `season_no` × `ep_no`? U právě
    vysílaného seriálu (`airing`, `TmdbLogic.tv_airing`) může poslední řada mít díly, které TMDb / cache ještě nezná → v ní
    jakýkoli díl (audit Fable F29 V3 c: jinak by soubor vysílaného jmenovce prošel jako jistý). Čistá funkce."""
    try:
        s, e = int(season_no), int(ep_no)
        if e < 1 or not counts or s not in counts:
            return False
        if airing and s == max(int(k) for k in counts):
            return True
        return int(counts.get(s) or 0) >= e
    except (TypeError, ValueError, AttributeError):
        return False


def homonym_variants(own_id: Any, variants: Sequence[Sequence[str]], results: Sequence[Any]) -> List[List[str]]:
    """Jádro 1.2.2 F2 (`Handoff/PLAN_autoplay_jiny_porad_20261116.md`): vlastní varianty názvu seriálu
    (`ser_title_variants`), které nese i JINÝ seriál z `results` (`name` nebo `original_name`). Volající (`build_episode_context`)
    předá jen jmenovce, kteří hledaný díl mohou mít (`homonym_candidates` + `can_have_episode`, audit Fable F28 V1).
    Incident 16.11.2026: slovenské „Mesto tieňov“ (33886) má česky „Město stínů“ = česky španělské „Ciudad de sombras“
    (277752); anglicky „The City of Shadows“ × „City of Shadows“. Čistá funkce; porovnání bez stop slov TV."""
    own = str(own_id or "")
    others = set()
    for r in results or ():
        if not isinstance(r, dict) or str(r.get("id") or "") == own:
            continue
        for key in ("name", "original_name"):
            c = _canon_title(r.get(key))
            if c:
                others.add(c)
    out: List[List[str]] = []
    for v in variants or ():
        c = tuple(t for t in v if t and t not in TV_TITLE_STOP)
        if c and c in others and list(v) not in out:
            out.append(list(v))
    return out


def episode_key(tv_id: Any, season_no: Any, ep_no: Any) -> str:
    """Klíč dílu — stejný tvar jako klíč diskové cache předstažení (`tv_id:řada:díl`)."""
    return "%s:%s:%s" % (str(tv_id or "").strip(), int(season_no), int(ep_no))


def search_key(tv_id: Any, season_no: Any, ep_no: Any) -> str:
    """Klíč MĚŘENÍ hledání dílu (`SEARCH_PHASES`, snímek výpisu, `PLAY_PICK`) — JEDINÁ skladba pro výpis, předstažení
    i přehrání. S10 (10.10.2026): výpis skládal klíč sám jen z parametru `episode`, výpis epizod ale posílá `ep_no` →
    klíč `tv:<id>:<řada>:0`, snímek výpisu se s `PLAY_PICK` nepotkal a ruční klik na díl ztratil pozici, vlnu i původ."""
    return "tv:" + episode_key(tv_id, season_no, ep_no)


def _yr(val: Any) -> Optional[int]:
    if not val:
        return None
    m = re.match(r"(\d{4})", str(val))
    return int(m.group(1)) if m else None


def load_episode_base(tv_id: str, tv_name: str, season_no: int, ep_no: int, ep_title: str = "",
                      tmdb_key: str = "", *, tmdb_factory: Callable[[str], Any]) -> EpisodeBase:
    """Detail seriálu a dílu (CZ + EN) z TMDb. Selhání TMDb = prázdná pole (hledání běží dál s tím, co má)."""
    b = EpisodeBase()
    b.tv_id, b.tv_name, b.season_no, b.ep_no = str(tv_id or ""), tv_name, int(season_no), int(ep_no)
    b.ep_title = ep_title
    b.det = None
    b.ep_cs = {}
    b.ep_en = {}
    b.tv_names = [tv_name]
    b.ep_names = [ep_title] if ep_title else []
    b.degraded = 0
    b.tmdb_cs = None
    b.tmdb_key = tmdb_key or ""

    if b.tmdb_key and b.tv_id.isdigit():
        b.tmdb_cs = tmdb_factory("cs-CZ")

        # Seriál – detail (lokální cache TMDb)
        try:
            b.det = b.tmdb_cs.tv_details(int(b.tv_id))
            b.tv_names += [b.det.get("original_name", "")]
        except TMDbError as _tmdb_exc:
            note_episode_tmdb_failure(b, _tmdb_exc)
            b.det = None  # det nemusí být k dispozici

        # Epizoda – CZ/EN detail (lokální cache TMDb)
        try:
            b.ep_cs = b.tmdb_cs.episode_details(int(b.tv_id), b.season_no, b.ep_no)
            nm = (b.ep_cs.get("name") or "").strip()
            if nm:
                b.ep_names.append(nm)
        except TMDbError as _tmdb_exc:
            note_episode_tmdb_failure(b, _tmdb_exc)
            b.ep_cs = {}

        try:
            b.ep_en = tmdb_factory("en-US").episode_details(int(b.tv_id), b.season_no, b.ep_no)
            nm = (b.ep_en.get("name") or "").strip()
            orig_en = (b.ep_en.get("original_name") or nm).strip()
            if nm:
                b.ep_names.append(nm)
            if orig_en:
                b.ep_names.append(orig_en)
        except TMDbError as _tmdb_exc:
            note_episode_tmdb_failure(b, _tmdb_exc)
            pass

        if not b.ep_title:
            b.ep_title = (b.ep_cs.get("name", "") or "").strip()
    return b


def air_date(base: EpisodeBase) -> Optional[datetime.date]:
    """Datum premiéry dílu (None = neznámé). Volající rozhoduje, co s budoucí premiérou (dialog × tichý skip)."""
    air_iso = ((base.ep_cs or {}).get("air_date") or (base.ep_en or {}).get("air_date") or "").strip()
    try:
        y, m, d = [int(x) for x in air_iso.split("-", 2)] if air_iso else (0, 0, 0)
        return datetime.date(y, m, d) if y else None
    except Exception:
        return None


def build_episode_context(base: EpisodeBase, *, tmdb_factory: Callable[[str], Any],
                          spin_tokens_fn: Callable[[Any, Any], Tuple[set, set]],
                          log_event: Optional[LogFn] = None) -> EpisodeSearchContext:
    """Dotazy a parametry filtru pro díl. Přesun 1 : 1 z `plugin._tv_play_run` (3.5.170)."""
    log = log_event or (lambda *a: None)
    tv_id, tv_name, season_no, ep_no = base.tv_id, base.tv_name, base.season_no, base.ep_no
    tmdb_cs, tmdb_key, det = base.tmdb_cs, base.tmdb_key, base.det
    tv_names = list(base.tv_names)
    en_added = ""
    en_name_full = ""          # anglický název z TMDb (i když už v `tv_names` je) — hledání stejnojmenného seriálu (F2)
    ep_names = list(base.ep_names)

    if tmdb_cs is not None:
        # Alt-tituly seriálu (whitelist + latinka) — jen s detailem seriálu
        try:
            if det is None:
                raise TMDbError("tv_details nedostupný → bez alt-titulů")
            alts = tmdb_cs.tv_alternative_titles(int(tv_id))
            tv_names += [
                alt.get("title", "")
                for alt in alts
                if alt.get("title")
                and alt.get("iso_3166_1") in _ALT_COUNTRY_WHITELIST
                and re.search(r"[A-Za-z]", alt.get("title", ""))
            ]
        except TMDbError as _tmdb_exc:
            note_episode_tmdb_failure(base, _tmdb_exc)
            pass

        # HΦ5 (2026-07-07): oficiální lokalizované názvy seriálu z translations (cs/sk/pl)
        try:
            _tv_tr = tmdb_cs.tv_translations(int(tv_id))
            for _lc in ("cs-CZ", "cs", "sk-SK", "sk", "pl-PL", "pl"):
                _nm = (_tv_tr.get(_lc) or "").strip()
                if _nm and re.search(r"[A-Za-z]", _nm) and _nm not in tv_names:
                    tv_names.append(_nm)
        except TMDbError as _tmdb_exc:
            note_episode_tmdb_failure(base, _tmdb_exc)
            pass

        # Anglický název seriálu (TMDb en-US). Předstažení ho před sjednocením mělo, výpis ne — a originál
        # bývá neanglický („La casa de papel“ × „Money Heist“). Pravidlo „nikdy méně streamů“: SSOT je
        # NADMNOŽINA obou dřívějších cest. Název jde do filtru a do vlny WX+, ale PLÁN DOTAZŮ vln W1–WX se
        # staví bez něj (jinak by ve W3 vytlačil dotazy s krátkým tokenem do WX, která běží jen pod prahem 3);
        # jeho dotazy se do W3 PŘIDÁVAJÍ navíc (audit Fable F1-V2).
        try:
            _en_name = (tmdb_factory("en-US").tv_details(int(tv_id)).get("name") or "").strip()
            en_name_full = _en_name
            if (_en_name and re.search(r"[A-Za-z]", _en_name)
                    and _en_name.lower() not in {str(n).lower() for n in tv_names}):
                en_added = _en_name
        except TMDbError as _tmdb_exc:
            note_episode_tmdb_failure(base, _tmdb_exc)
            pass

        # Translations – jistota plného EN názvu ("The One Where/With …")
        try:
            trs = tmdb_cs.episode_translations(int(tv_id), season_no, ep_no)
            pref_keys = ("en-US", "en-GB", "en", "cs-CZ", "cs")
            seen_lc = {n.lower() for n in ep_names if n}
            for k in pref_keys:
                nm = (trs.get(k) or "").strip()
                if nm and nm.lower() not in seen_lc:
                    ep_names.append(nm)
                    seen_lc.add(nm.lower())
            if not any(re.search(r"\bthe one (where|with)\b", n.lower()) for n in ep_names if n):
                for nm in trs.values():
                    if nm and re.search(r"\bthe one (where|with)\b", nm.lower()):
                        if nm.lower() not in seen_lc:
                            ep_names.append(nm)
                        break
        except TMDbError as _tmdb_exc:
            note_episode_tmdb_failure(base, _tmdb_exc)
            pass

    c = EpisodeSearchContext()
    c.base = base

    # 3) --- DOTAZY ----------------------------------------------------
    c.queries = QueryBuilder.tv(tv_names, ep_names, season_no, ep_no)
    c.extra_w3 = []
    if en_added:
        _known = set(c.queries)
        c.extra_w3 = [q for q in ("%s %s" % (en_added, code) for code in (
            f"s{season_no:02d}e{ep_no:02d}", f"{season_no}x{ep_no:02d}", f"{season_no:02d}x{ep_no:02d}"))
            if q not in _known]
        tv_names.append(en_added)
    c.tv_names = tv_names
    c.ep_names = ep_names

    # 3b) --- VARIANTY NÁZVU SERIÁLU (OR přes varianty v enginu) -----------------
    ser_title_variants: List[List[str]] = []
    try:
        for nm in tv_names:
            toks = [_norm(w) for w in str(nm).split() if _norm(w)]
            toks = [t for t in toks if t]
            if len(toks) == 1 and len(toks[0]) <= 3:
                continue
            if toks and toks not in ser_title_variants:
                ser_title_variants.append(toks)
    except Exception:
        ser_title_variants = []
    c.ser_title_variants = ser_title_variants

    # 3c) --- STEJNOJMENNÝ SERIÁL (jádro 1.2.2 F2) ----------------------------------------------
    # Hledání TMDb podle českého a anglického názvu (2 dotazy, cache 7 dní): které vlastní varianty nese i jiný seriál, který
    # hledaný díl MŮŽE mít (řady jmenovce, `tv_episode_counts`; audit Fable F28 V1 — bez toho dostalo 20 % autoplayů flotily
    # jmenovce, např. HIMYM × ruský seriál se 2 řadami). Filtr pak díl, který sedí JEN sdíleným názvem, označí `uncertain`.
    # Selhání TMDb (ne 404) se neuloží do cache dílu (R2, audit Fable F28 V5); do `degraded` se nepočítá — dotazy hledání
    # jsou úplné, jde jen o přísnost výběru automatu. Dvě různá selhání (audit Fable F30 V5):
    #   • `homonym_unknown` — stejnojmennost se NEZJISTILA (hledání jmenovců selže, nebo chybí detail seriálu — F30 V4):
    #     automat doplňku pustí i jistý díl jen s potvrzením (`plugin._autoplay_eligible`);
    #   • `homonym_partial` — jmenovec nalezen, jen jeho řady selžou → jmenovec zůstává (přísněji: jeho soubory jsou
    #     nejisté) a výsledek se jen neukládá; další přísnost automatu netřeba.
    c.homonym_variants = []
    c.homonym_unknown = False
    c.homonym_partial = False
    if (tmdb_cs is not None and det is None and ser_title_variants and tv_id.isdigit()
            and int(getattr(base, "degraded", 0) or 0)):
        c.homonym_unknown = True          # detail seriálu selhal (ne 404) → jmenovce nelze hledat (F30 V4)
    if tmdb_cs is not None and det is not None and ser_title_variants and tv_id.isdigit():
        _hom_results: List[Any] = []
        for _lang, _name in (("cs-CZ", (det.get("name") or tv_name or "")), ("en-US", en_name_full)):
            if not str(_name or "").strip():
                continue
            try:
                _hom_results += tmdb_factory(_lang).search_tv_names(str(_name))
            except TMDbError as _hom_exc:
                c.homonym_unknown = True
                log("EP_CTX_WARN", "homonym_search", _lang, repr(_hom_exc)[:160])
        _hom_kept: List[Any] = []
        _hom_dropped: List[str] = []
        for _i, _cand in enumerate(homonym_candidates(tv_id, ser_title_variants, _hom_results)):
            if _i >= HOMONYM_DETAIL_MAX:
                _hom_kept.append(_cand)
                continue
            try:
                _counts = tmdb_cs.tv_episode_counts(int(_cand["id"]))
                _airing = tmdb_cs.tv_airing(int(_cand["id"]))       # tatáž odpověď z cache (F29 V3 c)
            except TMDbNotFoundError:
                _hom_dropped.append(str(_cand["id"]))
                continue
            except TMDbError as _hom_exc:
                c.homonym_partial = True
                _hom_kept.append(_cand)
                log("EP_CTX_WARN", "homonym_seasons", _cand.get("id"), repr(_hom_exc)[:160])
                continue
            if can_have_episode(_counts, season_no, ep_no, airing=_airing):
                _hom_kept.append(_cand)
            else:
                _hom_dropped.append(str(_cand["id"]))
        c.homonym_variants = homonym_variants(tv_id, ser_title_variants, _hom_kept)
        if c.homonym_variants or _hom_dropped:
            log("EP_HOMONYM", tv_id, [" ".join(v) for v in c.homonym_variants],
                "kept=%s" % ",".join(str(r.get("id")) for r in _hom_kept), "no_episode=%s" % ",".join(_hom_dropped))

    # 4) --- FILTRAČNÍ TOKENY -----------------------------------------
    title_norms: List[str] = []
    _seen: set = set()

    def _push(tok: str) -> None:
        n = _norm(tok)
        if n and n not in _seen:
            title_norms.append(n)
            _seen.add(n)

    _push(f"s{season_no:02d}e{ep_no:02d}")
    _push(f"{season_no}x{ep_no:02d}")
    _push(f"{season_no:02d}x{ep_no:02d}")
    for nm in tv_names:
        for w in nm.split():
            _push(w)
    for nm in ep_names:
        for w in nm.split():
            _push(w)

    # — erotika (pokud title není adult); zákaz jiného dílu = režim enginu `ban_other_episodes` (Φ5B) —
    banned_keys: set = set()
    if not (_is_adult_title(tv_name) or _is_adult_title(base.ep_title)):
        banned_keys |= {_norm(w) for w in EROTIC_KEYWORDS}

    # — SPIN-OFF tokeny (allow/ban) + **SANITIZACE BAN** —
    allow_tok, ban_tok = (spin_tokens_fn(tv_id, tmdb_key) if (tv_id and tmdb_key) else (set(), set()))
    title_norms += [t for t in allow_tok if t not in _seen]

    _ep_tv_words = {
        _norm(w)
        for nm in (*tv_names, *ep_names)
        for w in nm.split()
        if _norm(w)
    }
    _ban_before = len(ban_tok)
    if _ep_tv_words:
        ban_tok = {t for t in ban_tok if t not in _ep_tv_words}
    c.ban_removed = _ban_before - len(ban_tok)
    if c.ban_removed > 0:
        log("SPIN_BAN_SANITIZE", tv_id, f"removed={c.ban_removed}")
    banned_keys |= ban_tok

    c.title_norms = title_norms
    c.banned_keys = banned_keys
    c.ep_title_variants = [[_norm(w) for w in n.split() if _norm(w)] for n in ep_names if n]

    # allowed_years: roky ze seriálu / série / epizody
    allowed_years: set = set()
    try:
        tv_year = _yr((det or {}).get("first_air_date"))
        if tv_year:
            allowed_years.add(tv_year)
    except Exception:
        pass
    try:
        if tmdb_key and tv_id.isdigit() and season_no:
            season_year = _yr(tmdb_factory("cs-CZ").season_air_date(int(tv_id), season_no))
            if season_year:
                allowed_years.add(season_year)
    except Exception as exc:
        log("EP_CTX_WARN", "season_air_date", repr(exc)[:160])
    try:
        ep_year = _yr((base.ep_cs or {}).get("air_date")) or _yr((base.ep_en or {}).get("air_date"))
        if ep_year:
            allowed_years.add(ep_year)
    except Exception as exc:
        log("EP_CTX_WARN", "episode_air_date", repr(exc)[:160])
    c.allowed_years = allowed_years
    c.degraded = int(getattr(base, "degraded", 0) or 0)
    return c


def label_for(base: EpisodeBase) -> str:
    return f"{base.tv_name} S{base.season_no:02d}E{base.ep_no:02d}"


def compute_spin_tokens(tmdb: Any, tv_id: str, tmdb_key: str, *, lang: str = "en-US",
                        log: LogFn = (lambda *_a, **_k: None), diag: Any = (lambda *_a, **_k: None),
                        ) -> Tuple[set, set]:
    """Tokeny spin-offů téže franšízy: (allow, ban). `tmdb` = objekt TMDb (doplněk: `tmdb_client.TMDb`, Gate: `MemoryTmdb`);
    TMDb a logování dodává volající, `functools.lru_cache` a výběr `TMDb` zůstávají v obalu `richmovie_engine.spin_tokens`."""
    _diag_log = diag
    # – 2) zjistíme „kořenové“ slovo franšízy (bez pádu na prázdném řetězci) --
    try:
        # Φ-C (30.09.2026, A06 F07): vstupy spin-off filtru z lokální cache TMDb (30 d) — dřív ~9 dotazů
        # přes Gate při KAŽDÉM hledání dílu (detail + alt. názvy každého sourozence).
        me = tmdb._get_json_cached(f"/tv/{tv_id}", {"api_key": tmdb_key, "language": lang},
                                   key=f"spin_me:{tv_id}:{lang}", ttl_s=tmdb.STATIC_META_TTL_S,
                                   what="spin_tokens")
        # Preferujeme `name` (lokalizovaný/EN), protože `original_name` může
        # obsahovat znaky mimo latinku (např. korejština) → po `norm()` by zbylo "".
        candidates = [me.get("name", ""), me.get("original_name", "")]
        root_word = ""
        for cand in candidates:
            words = norm(cand).split()
            if words:
                root_word = words[0]
                break

        # Fallback: zkusíme alternativní názvy, dokud nenajdeme první latinský token
        if not root_word:
            try:
                for rec in tmdb.tv_alternative_titles(int(tv_id)):
                    words = norm(rec.get("title", "")).split()
                    if words:
                        root_word = words[0]
                        break
            except TMDbError as _st_e:
                # Dřív tiché: degradace spin-filtru (kořen bez alt-titles).
                _diag_log(f"spin_tokens root alt-titles fail: {_st_e}", 0)

        if not root_word:
            return set(), set()
    except TMDbError as _st_e:
        # Dřív tiché: spin-off filtr se celý vypne → do výsledků můžou
        # proklouznout epizody cizích spin-offů. Za WARNING (viditelné).
        _diag_log(f"spin_tokens disabled (TMDb fail): {_st_e}", 3)
        return set(), set()

    # – 3) najdeme všechny seriály se stejným kořenem ------------------------
    try:
        siblings = tmdb.search_tv(root_word, limit=30)
    except TMDbError as _st_e:
        _diag_log(f"spin_tokens siblings search fail: {_st_e}", 0)
        siblings = []

    def _tokens(title: str) -> set[str]:
        """Normalizované tokeny – bez kořenového slova („stargate“…)."""
        return {w for w in norm(title).split() if w and w != root_word}

    def _phrase(title: str) -> str:
        """HΦ-B (2026-07-07): CELÁ normalizovaná fráze názvu (s kořenem). Pro
        sibling VETO — spin-off jako „Suits LA" sdílí základní titul + kód a
        prochází přes rule_a; jednoznačně ho identifikuje až celá víceslovná
        fráze („suits la" / cz alt „kravataci la"). Distinguisher je často
        krátký token („la"), který NELZE bezpečně banovat samostatně."""
        return norm(title).strip()

    allow: set[str] = set()
    ban:   set[str] = set()
    ban_phrases: set[str] = set()
    allow_phrases: set[str] = set()   # HΦ-B: celé tituly aktuálního seriálu

    for show in siblings:
        show_id = str(show["id"])
        toks    = _tokens(show.get("name") or show.get("original_name", ""))

        if show_id == str(tv_id):            # ➜ aktuální seriál → allow
            allow |= toks
            _me_ph = _phrase(show.get("name") or show.get("original_name", ""))
            if _me_ph:
                allow_phrases.add(_me_ph)
            # + alternativní názvy (cz/sk/…)
            try:
                for rec in tmdb.tv_alternative_titles(int(show_id)):
                    allow |= _tokens(rec.get("title", ""))
                    _me_alt = _phrase(rec.get("title", ""))
                    if _me_alt:
                        allow_phrases.add(_me_alt)
            except TMDbError as _st_e:
                _diag_log(f"spin_tokens allow alt-titles fail: {_st_e}", 0)
            continue

        # jiné spin‑offy → ban (tokeny) + víceslovná fráze (veto)
        ban |= toks
        _sib_ph = _phrase(show.get("name") or show.get("original_name", ""))
        if " " in _sib_ph:
            ban_phrases.add(_sib_ph)
        try:
            for rec in tmdb.tv_alternative_titles(int(show_id)):
                ban |= _tokens(rec.get("title", ""))
                _alt_ph = _phrase(rec.get("title", ""))
                if " " in _alt_ph:
                    ban_phrases.add(_alt_ph)
        except TMDbError as _st_e:
            _diag_log(f"spin_tokens ban alt-titles fail: {_st_e}", 0)

    # – 4) vzájemné vyloučení + návrat ---------------------------------------
    ban -= allow
    # HΦ-B: víceslovné sibling fráze → do ban setu (banned_keys je bere jako
    # fráze; filtr je aplikuje jako VETO nad rule matchem, viz search_one).
    # Dva guardy proti falešnému vetu SPRÁVNÉHO seriálu:
    #  (1) fráze tvořená VÝHRADNĚ allow tokeny — patří aktuálnímu seriálu;
    #  (2) fráze je ADJACENT PODŘETĚZEC některého titulu aktuálního seriálu —
    #      kritické pro seriály, co OBSAHUJÍ kratší sibling jako prefix
    #      (aktuální „Law and Order SVU“, sibling „Law and Order“ → fráze
    #      „law and order“ by vetovala i správný SVU soubor). Delší sibling
    #      fráze (obsahující aktuální titul) se NEchává — správný základní
    #      díl ji nenese.
    for ph in ban_phrases:
        if set(ph.split()) <= allow:
            continue
        if any(_phrase_contains(ap, ph) for ap in allow_phrases):
            continue
        ban.add(ph)
    # HΦ-D: hygiena ban tokenů NENÍ tady — dělá se u POINTU POUŽITÍ v search_one
    # (banned_keys_eff), aby pokryla VŠECHNY zdroje banů (spin_tokens, kolekce,
    # budoucí) jedním SSOT místem a byla testovatelná replay harnessem.
    log("SPIN_TOKENS", tv_id,
        f"allow={len(allow)} ban={len(ban)} phrases={len(ban_phrases)}")
    return allow, ban
