# -*- coding: utf-8 -*-
"""rm_core.cascade — sans-I/O automat vln hledání dílu a filmu: JEDNA kaskáda, dva vykonavatelé (S3 §1).

Doplněk (`richmovie_episode_search.run_cascade`, `richmovie_movie_search.run_cascade`) ho pohání vlákny přes
`SearchEngine`, Gate (`POST /v1/go/search`) přes kroky stažení na televizi. Rozhodnutí — prahy vln, sloučení do výsledku
(první vlna vyhrává), záchrana číselným značením, co je autoritativně prázdné (R2) — jsou JEN tady."""
from __future__ import annotations

import re
from typing import Any, Dict, List, NamedTuple, Optional, Sequence, Tuple

from rm_core.model import Release
from rm_core.queries import query_variants
from rm_core.text import norm as _norm

# Prahy vln (13.12.2025): W1 vždy · W2 když po W1 < 10 · W3 když < 5 · WX a WX+ když < 3
THRESH_W2 = 10
THRESH_W3 = 5
THRESH_WX = 3
RESCUE_MIN_BYTES = 120 * 1_048_576     # záchrana číslem: menší soubory jsou klipy
RESCUE_NEAR_WORDS = 3                  # číslo dílu nejvýš tolik slov za názvem seriálu

WAVE_PRIMARY = "P"
WAVE_ALT = "ALT"

RESCUE_NO_EPCODE_RE = re.compile(
    r"(?:\bs\d{1,2}\s*e\d{1,2}\b|\b\d{1,2}[xX]\d{1,2}\b|\be\d{2,3}\b)",
    re.I,
)


class EpisodeWave(NamedTuple):
    """Krok automatu dílu: stáhnout `queries`, filtrovat s `ep_soft`, výsledek předat `wave_done`."""
    tag: str
    queries: List[str]
    ep_soft: bool
    threshold: int


def episode_wave_plan(ctx: Any) -> List[Tuple[str, List[str], bool, int]]:
    """Plán kaskády: (značka vlny, dotazy, měkký režim, práh „spustit jen když je ve výsledku méně než“).
    W1 běží vždy (prázdný výsledek je pod každým prahem)."""
    b = ctx.base
    codes = [f"s{b.season_no:02d}e{b.ep_no:02d}", f"{b.season_no}x{b.ep_no:02d}", f"{b.season_no:02d}x{b.ep_no:02d}"]
    ser_code_qs = [f"{ser} {code}" for ser in ctx.tv_names for code in codes]
    q = ctx.queries
    return [
        ("W1", list(q[0:6]), False, THRESH_W2),
        ("W2", list(q[6:12]), False, THRESH_W2),
        ("W3", list(q[12:18]) + list(getattr(ctx, "extra_w3", None) or []), False, THRESH_W3),
        ("WX", list(q[18:]), True, THRESH_WX),
        ("WX+", ser_code_qs, True, THRESH_WX),
    ]


class EpisodeCascade:
    """Automat kaskády dílu: `next_wave` → stáhni, filtruj (`rm_core.filter_tv.filter_tv_items` + `dedupe`) → `wave_done`;
    žádná vlna už nic nepřidala a nic se nenašlo → `needs_rescue` → `rescue_queries` / `rescue_accept`. Bez sítě a času."""

    def __init__(self, ctx: Any) -> None:
        self.ctx = ctx
        self.bucket: Dict[str, Release] = {}
        self.info: Dict[str, Any] = {"waves": [], "cancelled": False, "errors": 0, "rescue": None,
                                     "ctx_errors": int(getattr(ctx, "degraded", 0) or 0),
                                     # jádro 1.2.2 (audit Fable F28 V5): stejnojmennost se nepodařilo zjistit celou
                                     "homonym_unknown": bool(getattr(ctx, "homonym_unknown", False)),
                                     # F30 V5: jmenovec nalezen, jeho řady selhaly — jen neukládat
                                     "homonym_partial": bool(getattr(ctx, "homonym_partial", False))}
        self._plan = episode_wave_plan(ctx)
        self._i = 0

    def next_wave(self, cancelled: bool = False) -> Optional[EpisodeWave]:
        """Další vlna ke stažení; vlna se přeskočí, když je výsledek už nad jejím prahem, při zrušení nebo bez dotazů."""
        while self._i < len(self._plan):
            tag, qs, ep_soft, threshold = self._plan[self._i]
            self._i += 1
            if len(self.bucket) >= threshold or cancelled:
                continue
            if not qs:
                continue
            return EpisodeWave(tag, qs, ep_soft, threshold)
        return None

    def wave_done(self, wave: EpisodeWave, found: Sequence[Release], stats: Dict[str, Any]) -> int:
        """Výsledek vlny: počty chyb a sloučení do výsledku (první vlna vyhrává). Vrací počet přidaných položek."""
        self.info["errors"] += int(stats.get("errors") or 0)
        if stats.get("rate_limited"):
            self.info["rate_limited"] = True
        if stats.get("cancelled"):
            self.info["cancelled"] = True
        added = 0
        for r in found:
            if r.ident not in self.bucket:
                try:
                    if not getattr(r, "wave", ""):
                        r.wave = wave.tag
                except Exception:
                    pass
                self.bucket[r.ident] = r
                added += 1
        self.info["waves"].append(wave.tag)
        return added

    @property
    def needs_rescue(self) -> bool:
        return not self.bucket and not self.info["cancelled"]

    def rescue_queries(self) -> List[str]:
        base = self.ctx.base
        return rescue_queries(base.tv_name, base.ep_no)


def rescue_queries(tv_name: str, ep_no: int) -> List[str]:
    """Dotazy záchrany pro staré seriály s názvy jako „Esmeralda 01.avi“ (jen když kaskáda nic nenašla)."""
    base = (tv_name or "").strip()
    if not base or ep_no <= 0:
        return []
    return [
        f"{base} {ep_no:02d}",
        f"{base} {ep_no}",
        f"{base} ep {ep_no}",
        f"{base} díl {ep_no}",
        f"{base} dil {ep_no}",
        f"{base} episode {ep_no}",
        f"{base} capitulo {ep_no}",
    ]


def rescue_near_enough(name_norm: str, tv_words: Sequence[str], ep_no: int) -> bool:
    """Číslo dílu je v normalizovaném názvu nejvýš `RESCUE_NEAR_WORDS` slov za názvem seriálu."""
    words = [w for w in name_norm.split() if w]
    L = len(tv_words)
    start = -1
    for i in range(0, len(words) - L + 1):
        if words[i:i + L] == list(tv_words):
            start = i + L
            break
    if start < 0:
        return False
    window = words[start:start + RESCUE_NEAR_WORDS]
    ep_tokens = {str(ep_no), f"{ep_no:02d}"}
    return any(w in ep_tokens for w in window)


def episode_empty_is_authoritative(rels: Any, info: Optional[Dict[str, Any]]) -> bool:
    """Smí se „nic nenalezeno“ zapamatovat? Jen když hledání doběhlo CELÉ a BEZ chyby přenosu (R2: selhání
    se neperzistuje) — tedy ne po zrušení, ne po chybě dotazu, ne když se hledání přeskočilo."""
    if rels or not isinstance(info, dict):
        return False
    return (not info.get("cancelled") and not int(info.get("errors") or 0)
            and not int(info.get("ctx_errors") or 0)
            and not info.get("skipped") and bool(info.get("waves")))


def episode_result_cacheable(info: Optional[Dict[str, Any]]) -> bool:
    """Smí se NALEZENÝ výsledek hledání dílu uložit do cache dílu (`nextup_cache.json`, 30 dní)? SSOT pro výpis dílu
    i předstažení ve službě (jádro 1.2.2, audit Fable F28 V5): jen hledání, které doběhlo (ne zrušené), bez chyby dotazu,
    s úplným kontextem TMDb a se zjištěnou stejnojmenností — jinak by se 30 dní ukazoval výstup filtru z výpadku (např.
    cizí pořad bez příznaku nejistoty, „★ Doporučeno“ na něm). R2: selhání se neperzistuje."""
    if not isinstance(info, dict):
        return False
    return (not info.get("cancelled") and not int(info.get("errors") or 0)
            and not int(info.get("ctx_errors") or 0) and not info.get("homonym_unknown")
            and not info.get("homonym_partial"))


class MovieWave(NamedTuple):
    """Krok automatu filmu: stáhnout `queries`, filtrovat s názvy `norms` (`rm_core.filter_movie`), výsledek předat `wave_done`."""
    tag: str
    queries: List[str]
    norms: Any


class MovieCascade:
    """Automat kaskády filmu: primární vlna → (když nic nenašla) záložní vlna s alternativními názvy.
    Doplněk stejné kroky prochází v `richmovie_movie_search.run_cascade`, Gate (`POST /v1/go/search`) přes tenhle automat."""

    def __init__(self, ctx: Any) -> None:
        self.ctx = ctx
        self.rels: List[Release] = []
        self.wave = ""
        self.cancelled = False
        self.errors = 0
        self.waves: List[str] = []
        self.alt_titles: List[str] = []
        self.alt_checked = False          # volající alternativní názvy dodal (i prázdné = TMDb žádné nemá)
        self._next: Optional[str] = WAVE_PRIMARY

    def next_wave(self) -> Optional[MovieWave]:
        """Další vlna, nebo None. Záložní vlnu lze chtít až po `set_alt_titles` (alternativní názvy dodá volající z TMDb)."""
        if self._next == WAVE_PRIMARY:
            self._next = None
            return MovieWave(WAVE_PRIMARY, list(self.ctx.primary_q), self.ctx.primary_norms)
        if self._next == WAVE_ALT:
            self._next = None
            alt_q, alt_norms = movie_alt_wave(self.ctx, self.alt_titles)
            return MovieWave(WAVE_ALT, alt_q, alt_norms)
        return None

    @property
    def needs_alt_titles(self) -> bool:
        """Primární vlna nic nenašla (a nebylo zrušeno): volající dodá alternativní názvy `set_alt_titles`."""
        return bool(self.waves) and self.waves[-1] == WAVE_PRIMARY and not self.rels and not self.cancelled and self._next is None

    def set_alt_titles(self, alt_titles: Sequence[str]) -> None:
        """Alternativní názvy z TMDb; prázdný seznam = TMDb žádné nemá (autoritativně). Selhání TMDb volající NEhlásí
        prázdným seznamem, ale `note_movie_tmdb_failure` (ochuzený kontext) — jinak by prázdno vyšlo autoritativně."""
        self.alt_titles = list(alt_titles or ())
        self.alt_checked = True
        if self.alt_titles:
            self._next = WAVE_ALT

    def wave_done(self, wave: MovieWave, found: Sequence[Release], stats: Dict[str, Any]) -> None:
        self.errors += int(stats.get("errors") or 0)
        self.waves.append(wave.tag)
        if stats.get("cancelled"):
            self.cancelled = True
            return
        for r in found:
            if not getattr(r, "wave", ""):
                r.wave = wave.tag
        if found:
            self.rels = list(found)
            self.wave = wave.tag

    def authoritative_empty(self) -> bool:
        """Smí se „nic“ zapamatovat? Navíc k `movie_empty_is_authoritative`: záložní vlna musí být VYŘEŠENÁ — prázdná
        primární vlna bez dodaných alternativních názvů není celá kaskáda (R2; cross-check G1 13.11.2026 A2-Q1)."""
        if not self.rels and not self.alt_checked:
            return False
        if self._next is not None:          # naplánovaná vlna (ALT) neproběhla — kaskáda není celá (audit Fable T2 P1)
            return False
        return movie_empty_is_authoritative(self, self.ctx)


def movie_alt_wave(ctx: Any, alt_titles: Sequence[str]) -> Tuple[List[str], Any]:
    """(dotazy, názvy pro filtr) záložní vlny filmu podle alternativních názvů."""
    det = ctx.det
    alt_q = query_variants(det["title"], det["original_title"], det["year"], alt_titles=alt_titles, qualities=())
    alt_norms = ctx.primary_norms | {_norm(t) for t in alt_titles}
    return alt_q, alt_norms


def movie_empty_is_authoritative(result: Any, ctx: Any) -> bool:
    """Smí se „nic nenalezeno“ zapamatovat? Jen po celé kaskádě bez chyby přenosu a s plným kontextem (R2)."""
    return (not result.rels and not result.cancelled and not result.errors
            and not int(getattr(ctx, "degraded", 0) or 0) and bool(result.waves))
