# -*- coding: utf-8 -*-
"""rm_core.model — datový objekt `Release`, skóre a pravidla enrich/score. Čistá standardní knihovna. Přesun 1 : 1 (G1).
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields as _dc_fields
from typing import Callable, List, Optional, Tuple

import re

from rm_core.text import (
    MIN_FILE_MB_BY_QUALITY,
    QUALITY_RANK,
    parse_langs,
    quality,
    video_ext_of,
)

# ─────────────────────────────────────────────────────────────────────────────
#  DATOVÉ TŘÍDY
# ─────────────────────────────────────────────────────────────────────────────
@dataclass(unsafe_hash=True)
class Release:
    """
    2025-10-12 07:42 CEST (Europe/Prague)
    Rozšířený datový objekt releasu. Kromě stávajících polí (ident, name, size,
    quality, audios, subs, est_min, match, score) nově nese i *nepovinná* pole
    s metadaty z Webshare `/search` – využíváme je pouze pro diagnostiku/log.

    ws_width   … šířka videa (px) z Webshare API (pokud je k dispozici)
    ws_height  … výška videa (px)
    ws_len_s   … délka v sekundách (video_length)
    ws_pos     … kladné hlasy (positive_votes)
    ws_neg     … záporné hlasy (negative_votes)
    """
    ident:   str
    name:    str
    size:    int                       # B
    quality: str                       # viz quality()
    audios:  List[str] = field(default_factory=list)
    subs:    List[str] = field(default_factory=list)
    est_min: Optional[int] = None      # odhad délky (min)
    match:   bool = False              # ★ MATCH?
    score:   int = 0                   # agregované pořadí (nižší = lepší)

    # — NOVĚ: volitelná meta z Webshare `/search` (pouze pro log) —
    ws_width:  Optional[int] = None
    ws_height: Optional[int] = None
    ws_len_s:  Optional[int] = None
    ws_pos:    Optional[int] = None
    ws_neg:    Optional[int] = None
    runtime_mismatch: bool = False   # mimo ±10 % TMDb runtime (TV) → šedé + na konec listu
    title_penalty: int = 0          # penalizace názvu (SPEC: jednoslovné seriály) → tlačí balast dolů už před MI2
    len_penalty: int = 0            # HΦ-C (2026-07-07): mírný délkový nesoulad → penalta řazení (dřív tvrdý drop len_out)
    ws_rel: int = 0                 # P2 #11 (2026-07-07): relevance k termínu ručního WS hledání (0 = neutrální; plní jen _ws_search) → řadí přesný zásah nad velký cizí soubor

    # — NOVĚ: multi-source podpora (Fastshare integrace 21.01.2026) —
    source: str = "webshare"                  # "webshare" | "fastshare"
    fs_download_url: Optional[str] = None     # přímá URL pro Fastshare streaming
    fs_hash: Optional[str] = None             # Fastshare cookie hash

    # — Φ-A (30.09.2026): měření hledání + E1-F01 —
    uncertain: bool = False   # přijato jen záložní cestou filtru (dřív atribut mimo dataclass → do cache se neuložil)
    # jádro 1.2.2 (audit Fable F28 V1 / V4): proč je nejistý — `UNCERTAIN_*` v `rm_core.filter_tv` (automat ho smí pustit jen
    # s potvrzením kontinuitou, doplněk `richmovie_continuity.confirms_uncertain`); "" = jistý
    uncertain_reason: str = ""
    origin: str = ""          # dotazy a stránky, které soubor vrátily: "0:1,2:fs" (index dotazu vlny : stránka WS | fs | fsy)
    wave: str = ""            # vlna, která soubor přinesla do výpisu (W1…WX+, RESCUE; film: P = primární, ALT)

    # — Jádro 1.2.0 (15.11.2026): nahrávka z kina podle jména (`rm_core.source_grade`; filtr ho zná s názvem titulu) —
    source_grade: str = ""    # "cam" | "cam?" | "audio" | "audio?" | "scr" | "" — jen štítek a pořadí, nikdy filtr
    source_marker: str = ""   # značka, která rozhodla (log, telemetrie)


    # – derived –
    @property
    def size_mb(self) -> int:
        return round(self.size / 1_048_576)


def releases_from_records(records: object, log: Optional[Callable[..., None]] = None) -> Optional[List["Release"]]:
    """Streamy ze záznamů cache (`asdict(Release)` uložené jako JSON) — SSOT pro cache hledání i cache
    předstaženého dílu.

    Cache sdílí víc verzí doplňku (aktualizace za běhu: služba stará, plugin nový; návrat ke starší verzi).
    Klíč, který tahle verze nezná, se proto zahodí (a zaloguje), chybějící pole má výchozí hodnotu.
    Záznam, ze kterého stream postavit NEJDE, znehodnotí celý seznam → vrací None a volající hledá znovu
    (tichým vynecháním jednoho záznamu by se z výpisu ztratil stream). None i pro vstup, který není seznam."""
    if not isinstance(records, list):
        return None
    known = {f.name for f in _dc_fields(Release)}
    out: List[Release] = []
    dropped: set = set()
    for rec in records:
        if not isinstance(rec, dict):
            if log:
                log("CACHE_RECORD_BAD", "not_dict", type(rec).__name__)
            return None
        extra = [k for k in rec if k not in known]
        dropped.update(extra)
        try:
            out.append(Release(**{k: v for k, v in rec.items() if k in known}))
        except Exception as exc:
            if log:
                log("CACHE_RECORD_BAD", repr(exc)[:200], str(rec.get("ident") or ""))
            return None
    if dropped and log:
        log("CACHE_RECORD_UNKNOWN_KEYS", ",".join(sorted(str(k) for k in dropped)), len(out))
    return out


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_engine.py
# score_sort_key / score_text  (vytvořeno: 29.09.2026 14:44 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
# Φ0 (plán ux_latency, audit A06 F12): `Release.score` je od ranking v2 N-TICE (`tuple(base_score) +
# (penalty,)`, řazení vzestupně = nižší je lepší), dataclass ale deklaruje `int = 0` a volající
# s ním zacházeli jako s číslem: `int(score)` v logu STREAM_ORDER_FINAL i v SEARCH SUMMARY
# vyhodil TypeError, který `except: pass` tiše spolkl (0 řádků za 60 dní), a řazení pickeru
# nového UI (`-float(score)`) spadlo celé. Jedno pravidlo pro řazení a jedno pro text.
def score_sort_key(score: object) -> tuple:
    """Řadicí klíč skóre releasu (nižší = lepší) pro všechny tvary, které se v kódu vyskytují:
    n-tice z rankingu, list po průchodu JSONem (`release_view.json`), číslo (výchozí `0`), None."""
    if isinstance(score, (tuple, list)):
        return tuple(score)
    if isinstance(score, (int, float)):
        return (score,)
    return ()


def score_text(score: object) -> str:
    """Čitelný tvar skóre pro logy: `(0, 1, 3)` → `0/1/3`; prázdné → `-`."""
    key = score_sort_key(score)
    if not key:
        return "-"
    return "/".join(str(int(v)) if isinstance(v, (int, float)) and float(v).is_integer() else str(v)
                    for v in key)


# ─────────────────────────────────────────────────────────────────────────────
#  FILTR
# ─────────────────────────────────────────────────────────────────────────────
class ReleaseFilter:
    """
    **Statické** metody pro vyřazení nevyhovujících souborů,
    enrich metadat a výpočet konečného *score*.
    """



    # 2025-08-19 11:27 CEST (Europe/Prague) – ReleaseFilter.enrich(): EP_RE nově dovolí i tvary „1x4“ (dříve jen „1x04“)
    @staticmethod
    def enrich(item: dict) -> Optional[Release]:
        r"""
        Převede syrovou dict strukturu z `WebshareClient.search()` na objekt
        `Release` nebo vrátí `None`, pokud release neprošel základními filtry
        (ext, min-size, přípona…).

        ✦ Úpravy 07/2025 – TV epizody:
            • pokud název obsahuje vzor SxxEyy nebo 1xYY → size-check se
              zjemní na 50 MB, aby epizody kolem 100 MB nepadaly
            • pro ostatní releasy zůstávají (snížené) limity z MIN_FILE_MB_BY_QUALITY

        ✦ Aktualizace 2025-08-19 11:27 CEST (Europe/Prague):
            • `EP_RE` sjednoceno na `(?:s\d{1,2}e\d{1,2}|\d{1,2}[xX]\d{1,2})` – zachytí i „1x4“,
              nejen „1x04“. Velikostní práh 50 MB pro epizody tím bude správně uplatněn i na tyto releasy.
        """
        name     = item["name"]
        size_mb  = item.get("size", 0) / 1_048_576
        # – 1) přípona (SSOT `video_ext_of`) –
        if not video_ext_of(name):
            return None

        # – 2) minimální velikost (dynamicky) –
        EP_RE        = re.compile(r"(?:s\d{1,2}e\d{1,2}|\d{1,2}[xX]\d{1,2})", re.I)
        is_episode   = bool(EP_RE.search(name))

        q            = quality(name)
        min_size_mb  = 50 if is_episode else MIN_FILE_MB_BY_QUALITY.get(q, 250)
        if size_mb < min_size_mb:
            return None

        # – 3) jazyky, kvalita, konstrukce Release –
        aud, sub = parse_langs(name)
        return Release(
            ident   = item["ident"],
            name    = name,
            size    = item["size"],
            quality = q,
            audios  = aud,
            subs    = sub,
            est_min = int(item.get("video_length", 0) / 60) or None,

            # — NOVĚ: metadata z Webshare `/search` pro logovací summary —
            ws_width  = int(item.get("video_width") or 0) or None,
            ws_height = int(item.get("video_height") or 0) or None,
            ws_len_s  = int(item.get("video_length") or 0) or None,
            ws_pos    = (int(item.get("positive_votes") or 0)
                         if "positive_votes" in item else None),
            ws_neg    = (int(item.get("negative_votes") or 0)
                         if "negative_votes" in item else None),

            # — NOVĚ: multi-source podpora (Fastshare integrace 21.01.2026) —
            source         = item.get("source", "webshare"),
            fs_download_url = item.get("fs_download_url"),
            fs_hash        = item.get("fs_hash"),
        )




    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    @staticmethod
    def compute_score(r: Release) -> tuple[int, int, int]:
        """
        Lexikografické skóre pro řazení release-listu.

        1) ★ MATCH   – 0 (ano) / 1 (ne)                → potvrzené shody napřed
        2) kvalita   – QUALITY_RANK (0 = 2160p …)       → lepší rozlišení výš
        3) velikost  – -r.size (větší soubor = lepší)   → bitrate ve stejné řadě
        """
        star_flag = 0 if r.match else 1
        qual_rank = QUALITY_RANK.get(r.quality, 99)
        return (star_flag, qual_rank, -r.size)
