# -*- coding: utf-8 -*-
"""Okno Televize „jak pro rok 2030“ — tenké napojení stavového automatu na Kodi (F4c, 08.11.2026).

Plán `Handoff/PLAN_televize_F4_20261108.md` §3–§5, zkouška architektury `Temp/livetv_f4/measure/F4_0_PC_VYSLEDKY.md`
(video v `videowindow` modálního dialogu hraje, vlastnosti položky dorazí do `getPlayingItem()`, FullScreen celou obrazovku
neotevře, `onAction` akci nespotřebuje → FF dojde i k přehrávači, `PlayerControl(Play)` vrátí rychlost, 60 FPS s panelem).

KDO CO ROZHODUJE
  * `richmovie_tv_state.TvState` = VŠECHNA rozhodnutí („co znamená ▲ teď“, předvýběr, čísla, Zpět po vrstvách, pauza,
    přeladění, nečinnost, odmítnutý tiket, přetočení). Okno převádí klávesy / myš / události služby na jeho vstupy
    a PROVÁDÍ jeho povely.
  * Navigace UVNITŘ panelu (▲▼ v seznamu, čipy, kolečko myši) je nativní seznam Kodi (plynulý `scrolltime`, myš,
    filtrovaný pohled) — automatu se jen hlásí, na kterém kanálu fokus stojí (`set_panel_focus`). Přesun kanálu jde do
    automatu jako ▲▼ (`select` položí, `back` vrátí); dvojče seznamu jen ukazuje výsledné `channels`.
  * Stav přehrávání píše JEN služba (`richmovie_livetv.PROP_LIVE_STATE`, JSON `{gen, channel, csid, stage, code, at}`);
    okno ho čte à tik a podle `stage` volá `playback_started` / `playback_failed`. Druhá podtřída `xbmc.Player` NENÍ.
  * Spuštění kanálu = JEDINÉ místo `richmovie_playback_dispatch.request_live` (video v okně), položka = JEDINÝ stavitel
    `richmovie_livetv.build_live_item`, tiket `open_session`, konec `end_session` (vše `richmovie_livetv`).
  * Osobní pořadí, ★, skryté, poslední kanál = `richmovie_livetv_prefs`; kanály a „teď / potom“ = `richmovie_livetv_epg`
    (start z disku, obnova s ETagem); ztlumení = `richmovie_tv_audio.MuteOwnership` (při odchodu vrátí jen své).
  * Pohyb = tokeny `richmovie_motion` (XML okna prochází lintem L7; řetězce pro `setAnimations` skládá jen `motion`).

NEPORUŠITELNÉ (linty a scénář 108)
  * Data se mění NA MÍSTĚ (`getListItem(i).setLabel/setProperty`, průběh přes `InfoTagVideo.setResumePoint`) — `reset()` /
    `addItem(s)` seznamů okna JEN ve funkcích `_refill_filtered` (filtr / složení pohledu) a `_enter_reorder` (L8).
  * Síť jen přes `richmovie_http` (skrz `richmovie_livetv` / `richmovie_livetv_epg`), obnovu výpisu Kodi okno nevolá,
    přehrávač spouští jen dispatcher.
  * Vlákna jsou zrušitelná: tik čeká `Monitor.waitForAbort`, síť má rozpočty `richmovie_http` (při vypnutí Kodi
    `cancel_all` v `shutdown`).
  * Okno NIKDY nezapisuje návratový popis (`mark_play_from_ui`) — o odchodu z Televize rozhoduje okno, služba nikam nenaviguje.
  * Srdeční tep okna (`richmovie_livetv.TV_WINDOW_HEARTBEAT_*`, claim `richmovie_guard`) = hlídač sirotka ve službě:
    živý kanál bez tepu okna služba zastaví.

Testovatelné bez Kodi: Kodi se sahá jen přes malé metody (`_cond`, `_info`, `_builtin`, `_player_*`, `_spawn`, `_ctl`,
`_set`, `_focus`), které harness (`_tools/net_resilience_sim/scenario_tv_window.py`, scénář 108) nahradí.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import threading
import time
import unicodedata
import urllib.parse
import uuid
from typing import Any, Callable, Dict, List, Optional, Sequence, Set, Tuple

import xbmc
import xbmcaddon
import xbmcgui

import richmovie_guard as _guard
import richmovie_livetv as _tv
import richmovie_livetv_epg as _epg
import richmovie_livetv_prefs as _prefs
import richmovie_motion as _motion
import richmovie_playback_dispatch as _dispatch
import richmovie_tv_audio as _audio
import richmovie_tv_prefetch as _prefetch
import richmovie_tv_state as _st
import richmovie_ui_common as _uc

XML_FILE = "RichMovieTV.xml"

# ── ovládací prvky (= id v RichMovieTV.xml) ─────────────────────────────────────────────────────────────────────────
VIDEO = 1
FOCUS_SCREEN = 9001          # držák fokusu v čistém obraze
HOT_EDGE = 9002              # myš k levému okraji
FOCUS_REORDER = 9011         # držák fokusu při přesunu kanálu
LIST = 9000                  # seznam kanálů (panel)
LIST_REORDER = 9010          # dvojče seznamu pro přesun (fixedlist, pevná pozice drženého řádku)
CHIPS = 9100
SEARCH = 9200
ALPHA = 9300
MUTE_BUTTON = 9400
CARD_GROUP = 9500            # grouplist voleb karty zprávy
CARD_BUTTONS = (9501, 9502, 9503, 9504)
ACT_FAV, ACT_MOVE, ACT_HIDE = 9600, 9601, 9602
REORDER_UP, REORDER_DOWN, REORDER_DROP = 9012, 9013, 9014
BAR_PROGRESS = 8101
PREVIEW_GROUP = 200
ACTION_BUTTONS = (ACT_FAV, ACT_MOVE, ACT_HIDE)
PANEL_CONTROLS = (LIST, CHIPS, SEARCH, ALPHA, MUTE_BUTTON) + ACTION_BUTTONS   # fokus „v panelu“ (`_ensure_panel_focus`)
LISTS = (LIST, LIST_REORDER, CHIPS, ALPHA)   # seznamy okna (lint L8)

# geometrie pro morph karty náhledu z řádku (souřadnice 1080i — viz XML)
LIST_X, LIST_Y, LIST_W, ROW_H = 30, 200, 700, 100
PREVIEW_RECT = (780, 120, 520, 860)
PANEL_RIGHT_PX = 1320        # myš vpravo od panelu + karty = „pryč z panelu“

# ── časy (laditelné z jednoho místa) ────────────────────────────────────────────────────────────────────────────────
TICK_S = 0.25                # tik okna (plán §3.4: politika à 250 ms)
SEEK_RETUNE_GAP_S = 15.0     # přeladění kvůli přetočení nejvýš 1× za tolik — pojistka proti smyčce, kdyby Kodi / ISA
                             # přetáčelo samo (4.2.1, cross-check H1); divák dvakrát za 15 s „zpět na živé“ nepotřebuje
TICK_PANEL_S = 0.1           # otevřený panel: fokus seznamu se sleduje rychleji (karta náhledu bez čekání, Richie
                             # 08.11.2026: „strašně dlouho trvá, než se zobrazí náhled označené stanice“)
SEARCH_CALM_S = 0.15         # hledání psaním filtruje po klidu
PROGRESS_REFRESH_S = 30.0    # průběh pořadů na místě (posun o 1–3 px oko čte jako plynulý)
TUNE_SLOW_S = 6.0            # „Pořád ladím…“ (plán §4.8)
HINT_S = 3.0                 # krátké potvrzení v nápovědě
FIRST_HINT_S = 6.0           # jednou na zařízení: jak se Televize ovládá (§4.9)
MOUSE_AWAY_S = 0.8           # myš pryč z panelu a karty → panel odjede (§5)
MOUSE_BAR_S = 0.5            # pohyb myši obnoví lištu nejvýš jednou za tolik (Kodi posílá desítky událostí za sekundu)
IDLE_ANSWER_S = 60.0         # „Díváš se ještě?“: bez odpovědi = konec Televize (§3.7)
PREVIEW_HOURS = 8            # „Dál dnes“: od teď −1 h do +8 h
END_JOIN_S = _tv.END_TIMEOUT_S + 0.5   # zavření: na konec relace se čeká nejvýš tolik (rozpočet `end_session`)
TICKETS_KEPT = 8             # kolik posledních tiketů okno zná (stav služby k jiným relacím se ignoruje)

FIRST_HINT_TEXT = "OK = seznam kanálů  ·  ▲▼ = přepínání  ·  Zpět = konec"
TEXT_LIVE = "● ŽIVĚ"
TEXT_PRESELECT = "OK = přepnout"
TEXT_PAUSED = "Pozastaveno · OK = živě"
TEXT_RELEASED = "Místo uvolněno · OK = živě"
TEXT_RETUNE = "Obnovuji vysílání…"
TEXT_LOADING = "Načítám kanály…"

#: kanonické kategorie Gate (`app/livetv/categories.py`; pořadí čipů posílá Gate v `categories`) → české popisky
CATEGORY_LABELS = {
    "general": "Hlavní", "news": "Zprávy", "sport": "Sport", "movies": "Filmy a seriály", "kids": "Děti",
    "docs": "Dokumenty a kultura", "music": "Hudba", "regional": "Regionální", "lifestyle": "Životní styl",
    "foreign": "Zahraniční", "adult": "Pro dospělé", "other": "Ostatní",
}
#: barvy monogramu (index z `richmovie_livetv.monogram`, 6 tónů palety Estoril)
MONO_COLORS = ("FF2B5C9E", "FF6E3FA0", "FF23806A", "FFA0612E", "FF9E2F55", "FF3A6F8F")

F_FAV, F_ALL, F_HIDDEN, F_CAT, F_SEARCH = "fav", "all", "hidden", "cat:", "search:"

# ── klávesy: jména akcí z `xbmcgui` (nikdy čísla) → vstup automatu ───────────────────────────────────────────────────
_KEY_ACTIONS = (
    ("ACTION_MOVE_UP", "up"), ("ACTION_MOVE_DOWN", "down"), ("ACTION_MOVE_LEFT", "left"),
    ("ACTION_MOVE_RIGHT", "right"), ("ACTION_SELECT_ITEM", "select"), ("ACTION_NAV_BACK", "back"),
    ("ACTION_PREVIOUS_MENU", "back"), ("ACTION_PAGE_UP", "ch_up"), ("ACTION_PAGE_DOWN", "ch_down"),
    ("ACTION_CHANNEL_UP", "ch_up"), ("ACTION_CHANNEL_DOWN", "ch_down"), ("ACTION_SHOW_INFO", "info"),
    ("ACTION_CONTEXT_MENU", "menu"), ("ACTION_PAUSE", "pause"), ("ACTION_PLAYER_PLAYPAUSE", "pause"),
    ("ACTION_PLAYER_PLAY", "play"), ("ACTION_PLAYER_FORWARD", "ff"), ("ACTION_PLAYER_REWIND", "rw"),
    ("ACTION_NEXT_ITEM", "ff"), ("ACTION_PREV_ITEM", "rw"), ("ACTION_STOP", "stop"),
    ("ACTION_MOUSE_MOVE", "mouse_move"), ("ACTION_MOUSE_WHEEL_UP", "wheel_up"),
    ("ACTION_MOUSE_WHEEL_DOWN", "wheel_down"), ("ACTION_MOUSE_LEFT_CLICK", "click"),
)
#: číslice: klávesnice / IR ovladač posílá REMOTE_0..9, ovladač přes CEC (Sony) 2–9 jako SMS skok (keymap `<two>JumpSMS2`)
_DIGIT_ACTIONS = tuple(("REMOTE_%d" % d, d) for d in range(10)) + tuple(("ACTION_JUMP_SMS%d" % d, d) for d in range(2, 10))


def action_map(ns: Any = None) -> Dict[int, Tuple[str, Optional[int]]]:
    """id akce Kodi → (vstup automatu, číslice | None). Jména z `xbmcgui` přes `getattr` — chybějící jméno (starší Kodi,
    stub) se přeskočí. Číslice `REMOTE_n` I `ACTION_JUMP_SMSn` (bez SMS by na Sony přes CEC šly jen 0 a 1).
    Ztlumení (`ACTION_MUTE`) tu záměrně NENÍ: akci zpracuje Kodi samo (okno akci nespotřebuje, H5) — přepnout ji ještě
    oknem = dvojí přepnutí = nic. Ikony řídí `Player.Muted`, tlačítko v panelu jde přes `MuteOwnership`."""
    ns = xbmcgui if ns is None else ns
    out: Dict[int, Tuple[str, Optional[int]]] = {}
    for name, key in _KEY_ACTIONS:
        aid = getattr(ns, name, None)
        if isinstance(aid, int) and aid not in out:
            out[aid] = (key, None)
    for name, digit in _DIGIT_ACTIONS:
        aid = getattr(ns, name, None)
        if isinstance(aid, int):
            out[aid] = ("digit", digit)
    return out


# ── logování (routovaný logger → user_logs na NASu) ─────────────────────────────────────────────────────────────────
def _log(msg: str, warning: bool = False) -> None:
    try:
        import richmovie_logging as _rl
        lg = _rl.get_logger("richmovie.livetv")
        (lg.warning if warning else lg.info)(msg)
    except Exception:
        try:
            xbmc.log("[RichMovie/Televize] %s" % msg, xbmc.LOGWARNING if warning else xbmc.LOGINFO)
        except Exception:
            pass


# ── čisté pomocníky (testovatelné bez okna) ─────────────────────────────────────────────────────────────────────────
def fold(text: str) -> str:
    """Text pro hledání a abecední lištu: bez diakritiky, malá písmena („ČT 24“ → „ct 24“)."""
    norm = unicodedata.normalize("NFKD", str(text or ""))
    return "".join(c for c in norm if not unicodedata.combining(c)).casefold()


def initial_of(name: str) -> str:
    """Písmeno abecední lišty: první znak bez diakritiky velkým písmenem, číslice → „0-9“."""
    f = fold(name).strip()
    if not f:
        return ""
    c = f[0]
    if c.isdigit():
        return "0-9"
    return c.upper() if c.isalpha() else ""


def _row_art(fields: dict) -> Dict[str, str]:
    """Art řádku kanálu: `thumb` = logo, `card` = obrázek karty náhledu (přednačítá ho seznam)."""
    return {"thumb": fields["thumb"], "card": fields["card"]}


def meta_text(current: Optional[dict]) -> str:
    """„seriál · 12+ · ★ 71 %“ z běžícího pořadu (žánry nejvýš 2)."""
    if not isinstance(current, dict):
        return ""
    parts = []
    genres = [str(g) for g in (current.get("genres") or []) if g][:2]
    if genres:
        parts.append(", ".join(genres))
    age = current.get("rating_age")
    if isinstance(age, (int, float)) and not isinstance(age, bool) and age > 0:
        parts.append("%d+" % int(age))
    score = current.get("score_percent")
    if isinstance(score, (int, float)) and not isinstance(score, bool) and score > 0:
        parts.append("★ %d %%" % int(score))
    return " · ".join(parts)


def _seek_count(value: Any) -> int:
    """Počet přetočení ze stavu služby (`seeks`); cokoli jiného než nezáporné celé číslo = 0."""
    return value if isinstance(value, int) and not isinstance(value, bool) and value > 0 else 0


def card_buttons(code: str, ch: Optional[str], offer_lines: Sequence[Tuple[str, str, str]], playing_ch: Optional[str],
                 name_of: Callable[[Optional[str]], str]) -> List[Tuple[str, str]]:
    """Volby karty chyby (plán §4.6, §4.8 — každý stav má cestu ven), nejvýš `len(CARD_BUTTONS)`:
    plno = „Přidat se k X“ (běžící kanály skupiny, nové místo nespotřebuje); přechodná chyba = „Zkusit znovu“ (trvalá
    nikdy); hraje-li jiný kanál = „Zůstat na Y“; vždy „Jiný kanál“ (panel)."""
    out: List[Tuple[str, str]] = []
    if code == "slots_full":
        out += [("Přidat se k %s" % jname, "join:" + jch) for jch, jname, _line in offer_lines]
    elif not _tv.LiveError(code).permanent:
        out.append(("Zkusit znovu", "retry"))     # ruční pokus smí i po 429 — automaticky se neopakuje nikdy
    if playing_ch and playing_ch != ch:
        out.append(("Zůstat na %s" % name_of(playing_ch), "close"))
    other = ("Jiný kanál", "other")
    return out[:len(CARD_BUTTONS) - 1] + [other]


def _clock(value: Any) -> str:
    return _tv.clock_text(value) if value else ""


class TvWindow(_uc.RMNavMixin, xbmcgui.WindowXMLDialog):
    """Okno Televize. Kodi: `TvWindow(XML_FILE, cesta_doplňku, "default", "1080i")`, `start_channel` nastaví volající
    (konstruktor okna Kodi neunese vlastní argumenty), pak `doModal()`; úklid VŽDY `shutdown()` ve `finally` (`open_window`)."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.start_channel: Optional[str] = None
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._rm_closed = False                  # `uc.fetch_async` kontrakt (okno pryč = nesahat na prvky)
        self._actions = action_map()
        self.state: Optional[_st.TvState] = None
        self._mute: Optional[_audio.MuteOwnership] = None
        self._hb_token: Optional[str] = None
        self._hb_at = 0.0
        # data
        self._rows: Dict[str, dict] = {}
        self._provider: List[dict] = []
        self._categories: List[str] = []
        self._bases: List[str] = []
        self._probed: Dict[str, bool] = {}
        self._img_base: Optional[str] = None
        self._now_rec: Optional[dict] = None
        self._ch_rec: Optional[dict] = None
        self._view: Optional[_prefs.ChannelView] = None
        self._data_running = {"now": False, "channels": False}
        self._data_next = {"now": 0.0, "channels": 0.0}       # nástěnný čas další obnovy (i po selhání — žádná smyčka)
        self._epg_wake_at: Optional[float] = None
        self._progress_at = 0.0
        self._preview_epg: Dict[str, Tuple[float, list]] = {}
        # seznamy (index → kanál) a co je v řádcích (porovnání pro aktualizaci na místě)
        self._list_ids: List[str] = []
        self._reorder_ids: List[str] = []
        self._reorder_origin: Optional[int] = None
        self._row_cache: Dict[int, Dict[int, dict]] = {LIST: {}, LIST_REORDER: {}}
        self._filter = ""
        self._filter_before_search = ""
        self._pending_flags = False              # ★ / skryté změněné v otevřeném panelu → složení až při dalším otevření
        self._search_text = ""
        self._search_at: Optional[float] = None
        self._panel_digits = ""
        self._panel_digits_at = 0.0
        # panel / náhled / myš
        self._focus_cid: Optional[str] = None
        self._focus_since = 0.0
        self._preview_cid: Optional[str] = None
        self._prefetch_busy = False                     # běží dávka programu (nejvýš JEDNA — F4d-2)
        self._prefetch_inflight: Set[str] = set()
        self._prefetch_retry_at = 0.0                   # po selhání dávky další pokus nejdřív (hodiny okna)
        self._prefetch_last_at = -1e9                   # začátek poslední dávky (rozestup `MIN_INTERVAL_S`)
        self._prefetch_dir = _prefetch.DOWN
        self._prefetch_prev_idx: Optional[int] = None
        self._mouse_away_since: Optional[float] = None
        self._mouse_bar_at = 0.0
        # přehrávání
        self._isa_cached: Optional[bool] = None
        self._tickets: Dict[str, str] = {}       # csid → kanál (tikety, které okno vyžádalo; nejvýš TICKETS_KEPT)
        self._opening: Optional[Tuple[str, str, float]] = None   # (kanál, csid, t_key)
        self._playing: Optional[Tuple[str, str]] = None          # (kanál, csid) — obraz naskočil
        self._playing_since = 0.0
        self._watched_noted: Optional[str] = None
        self._expected_stops: set = set()
        self._last_state_raw = ""
        self._seek_seen: Tuple[str, int] = ("", 0)       # (relace, počet přetočení) — viz `_on_live_seek`
        self._seek_retune_at = -1e9                     # poslední přeladění kvůli přetočení (pojistka smyčky)
        self._zap: Dict[str, float] = {}
        # karty, které vlastní okno
        self._card_kind = ""                     # "" | "tune" | "msg"
        self._card_ch: Optional[str] = None
        self._card_offer: Optional[dict] = None
        self._card_acts: List[str] = []
        self._card_window_only = False           # karta mimo vrstvu CARD automatu (pauza uvolnila místo, nečinnost…)
        self._tune_card_at = 0.0
        self._idle_deadline: Optional[float] = None
        self._hint_until: Optional[float] = None
        self._number_digits = ""
        self._leaving = False
        self._leave_thread: Optional[threading.Thread] = None
        self._end_threads: List[threading.Thread] = []
        self._FX: Dict[str, Callable[[dict], None]] = {
            "tune": self._fx_tune, "retune": self._fx_retune, "bar_show": self._fx_bar_show,
            "bar_hide": self._fx_bar_hide, "panel_open": self._fx_panel_open, "panel_close": self._fx_panel_close,
            "panel_focus": self._fx_panel_focus, "number_show": self._fx_number_show,
            "number_hide": self._fx_number_hide, "leave": self._fx_leave, "mute_toggle": self._fx_mute_toggle,
            "pause": self._fx_pause, "pause_release": self._fx_pause_release, "normalize_speed": self._fx_normalize,
            "error_card": self._fx_error_card, "idle_ask": self._fx_idle_ask, "reorder_start": self._fx_reorder_start,
            "reorder_move": self._fx_reorder_move, "reorder_commit": self._fx_reorder_commit,
            "reorder_cancel": self._fx_reorder_cancel, "release_card": self._fx_release_card,
        }

    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    #  Kodi přístupy (jediná místa — harness je nahradí)
    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    def _cond(self, cond: str) -> bool:
        try:
            return bool(xbmc.getCondVisibility(cond))
        except Exception:
            return False

    def _info(self, label: str) -> str:
        try:
            return str(xbmc.getInfoLabel(label) or "")
        except Exception:
            return ""

    def _builtin(self, cmd: str) -> None:
        xbmc.executebuiltin(cmd)

    def _player_stop(self) -> None:
        xbmc.Player().stop()

    def _player_present(self) -> bool:
        """Přehrávač existuje (hraje i pozastavený) — JEDINÁ definice `richmovie_playback_dispatch.player_present`;
        nečitelný stav = zkusit zastavit (stop bez přehrávače nic nedělá)."""
        return _dispatch.player_present(on_error=True)

    def _home_prop(self, key: str) -> str:
        try:
            return xbmcgui.Window(10000).getProperty(key) or ""
        except Exception:
            return ""

    def _wait(self, seconds: float) -> None:
        xbmc.Monitor().waitForAbort(seconds)

    def _spawn(self, name: str, fn: Callable[[], None]) -> threading.Thread:
        """Vlákno práce na pozadí (síť přes `richmovie_http` = s rozpočtem a zrušitelné). Nedaemonické — Kodi na něj
        při vypnutí čeká a `cancel_all` (`shutdown`) ho uvolní (S23)."""
        th = threading.Thread(target=fn, name=name, daemon=False)
        th.start()
        return th

    def _now(self) -> float:
        return time.monotonic()

    def _set(self, key: str, value: Any) -> None:
        try:
            self.setProperty(key, "" if value is None else str(value))
        except Exception:
            pass

    def _get(self, key: str) -> str:
        try:
            return self.getProperty(key) or ""
        except Exception:
            return ""

    def _ctl(self, cid: int):
        try:
            return self.getControl(cid)
        except Exception:
            return None

    def _focus(self, cid: int) -> None:
        try:
            self.setFocusId(cid)
        except Exception:
            pass

    def _focused(self) -> int:
        try:
            return int(self.getFocusId())
        except Exception:
            return 0

    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    #  Životní cyklus
    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    def onInit(self) -> None:
        if self.state is not None:        # Kodi volá onInit znovu po zavření dialogu nad oknem — nic nespouštět znovu
            return
        try:
            _motion.sync_reduced_property()
        except Exception as exc:
            _log("TV_WINDOW motion property: %r" % (exc,), warning=True)
        pc = _uc.device_mode() == "pc"
        self._set("tv_search_on", "1" if pc else "")     # PC / Mac: hledání psaním
        self._set("tv_alpha_on", "" if pc else "1")      # ovladač: abecední lišta (žádná klávesnice Kodi přes Televizi)
        with self._lock:
            self._bootstrap(self._now())
            self._data_running.update(now=True, channels=True)   # první obnovu dělá `_initial_refresh`, ne tik
        self._spawn("RMTvTick", self._tick_loop)
        self._spawn("RMTvData", self._initial_refresh)

    def _bootstrap(self, now: float) -> None:
        """Start z mezipaměti (žádné čekání na síť): kanály + program z disku, osobní pořadí, automat, srdeční tep,
        první naladění (`live_play&ch=` / poslední kanál profilu), jinak panel na prvním oblíbeném / prvním kanálu."""
        self._mute = _audio.MuteOwnership()
        self._heartbeat(now, force=True)
        self._ch_rec = _epg.load("channels")
        self._now_rec = _epg.load("now")
        self._adopt_channels(self._ch_rec)
        visible = list(self._view.visible) if self._view else []
        last_ch, _prev = _prefs.last_channel()
        target = self.start_channel or (last_ch if last_ch in self._rows else None)
        first = self._view.favorites[0] if (self._view and self._view.favorites) else (visible[0] if visible else None)
        self.state = _st.TvState(visible, target or first, now)
        self._set("tv_stale", self._stale_text())
        self._show_first_hint(now)
        if target:
            _log("TV_WINDOW open start=%s source=%s" % (target, "param" if self.start_channel else "last"))
            self._run(self.state.start(target, now))
        else:
            _log("TV_WINDOW open start=- (bez posledního kanálu → panel)")
            self._run(self.state.key("select", now))

    def _initial_refresh(self) -> None:
        """Hned po otevření: obnova kanálů a programu (ETag → většinou 304) + sonda cesty k NASu pro obrázky."""
        self._refresh_data("channels")
        self._probe_image_base()
        self._refresh_data("now")

    def shutdown(self) -> None:
        """Úklid po `doModal` (volá `open_window` ve `finally`): tik stojí, tep uvolněn, ztlumení vrácené; při vypnutí
        Kodi zrušit rozběhnutá spojení (Kodi čeká na všechna vlákna, S23). Konec relace má vlastní rozpočet."""
        self._rm_closed = True
        self._stop.set()
        deadline = time.monotonic() + END_JOIN_S
        if self._leave_thread is not None and self._leave_thread is not threading.current_thread():
            self._leave_thread.join(timeout=max(0.0, deadline - time.monotonic()) + 0.5)
        for th in list(self._end_threads):
            th.join(timeout=max(0.0, deadline - time.monotonic()))
        if self._mute is not None:
            try:
                self._mute.leave()
            except Exception as exc:
                _log("TV_WINDOW mute leave: %r" % (exc,), warning=True)
        if self._hb_token:
            _guard.release(_tv.TV_WINDOW_HEARTBEAT_NAME, self._hb_token)
            self._hb_token = None
        if self._abort_requested():
            try:
                import richmovie_http as _rm_http
                _rm_http.cancel_all("tv_window_abort")
            except Exception:
                pass
        _log("TV_WINDOW closed")

    def _abort_requested(self) -> bool:
        try:
            return bool(xbmc.Monitor().abortRequested())
        except Exception:
            return False

    # ── srdeční tep okna (hlídač sirotka ve službě) ─────────────────────────────────────────────────────────────────
    def _heartbeat(self, now: float, force: bool = False) -> None:
        """Claim `TV_WINDOW_HEARTBEAT_NAME` (TTL `…_TTL_S`), obnova à `…_RENEW_S`. Okno Televize je modální a v Kodi
        nejvýš jedno → cizí nevypršelý držitel = sirotek minulého okna (pád) → `take_over` (čekat na jeho TTL by nechalo
        hrající kanál chvíli bez tepu a služba by ho zastavila)."""
        if self._stop.is_set() or (not force and now - self._hb_at < _tv.TV_WINDOW_HEARTBEAT_RENEW_S):
            return                                # po `shutdown` už tep nevzniká znovu (uvolněný claim)
        self._hb_at = now
        name, ttl = _tv.TV_WINDOW_HEARTBEAT_NAME, _tv.TV_WINDOW_HEARTBEAT_TTL_S
        if self._hb_token and _guard.renew(name, self._hb_token, ttl):
            return
        token = _guard.claim(name, ttl)
        if token is None:
            token = _guard.take_over(name, ttl)
            _log("TV_WINDOW_HEARTBEAT take_over ok=%s" % bool(token), warning=True)
        self._hb_token = token

    # ── tik ─────────────────────────────────────────────────────────────────────────────────────────────────────────
    def _tick_loop(self) -> None:
        """Vlákno tiku. Smrt vlákna = konec srdečního tepu = služba zastaví divákovi obraz (sirotek) → každé kolo
        v `try` s logem a s čekáním i po chybě (žádná rychlá smyčka chyb) — cross-check A2-Q6."""
        mon = xbmc.Monitor()
        while not self._stop.is_set():
            try:
                if mon.waitForAbort(self._tick_interval()):
                    _log("TV_WINDOW kodi_abort → odchod")
                    with self._lock:
                        self._leave("kodi_abort", fast=True)
                    return
                self._tick_once(self._now())
            except Exception as exc:
                _log("TV_WINDOW tick: %r" % (exc,), warning=True)
                self._stop.wait(TICK_S)

    def _tick_interval(self) -> float:
        """Otevřený panel = rychlejší tik (karta náhledu hned); jinak `TICK_S`. Bez výjimky (čte se mimo zámek)."""
        st = self.state
        return TICK_PANEL_S if (st is not None and st.layer == _st.PANEL) else TICK_S

    def _tick_once(self, now: float) -> None:
        """Jedno kolo: srdeční tep MIMO zámek okna (dlouhá operace pod zámkem nesmí divákovi zastavit obraz jako
        sirotka — cross-check H4-b), pak tik pod zámkem."""
        if self._stop.is_set():
            return
        self._heartbeat(now)
        with self._lock:
            self._tick(now)

    def _tick(self, now: float) -> None:
        """Jeden tik (à 250 ms): tep, stav služby, automat (předvýběr, lišta, pauza, politika rychlosti, přeladění,
        nečinnost), karty, panel, poslední kanál, obnova dat na místě, nápověda, odpočet nečinnosti. Přetočení hlásí
        služba (`seeks` ve stavu — `_on_live_seek`), pozice přehrávače se neměří (4.2.1)."""
        if self.state is None or self._leaving:
            return
        self._run(self._poll_live_state(now))
        if self._leaving:
            return
        paused, speed = self._player_speed()
        self._run(self.state.tick(now, paused=paused, speed=speed))
        self._update_pause_hint()
        self._tune_card_progress(now)
        self._panel_tick(now)
        self._note_watched(now)
        self._data_tick(now)
        try:
            self._rm_data_rev_tick()             # doména `tv` (jiné zařízení profilu / pull služby) → on_data_changed
        except Exception:
            pass
        if self._hint_until is not None and now >= self._hint_until:
            self._hint_until = None
            self._set("tv_hint", "")
        if self._idle_deadline is not None:
            left = self._idle_deadline - now
            if left <= 0:
                _log("TV_WINDOW idle_timeout → odchod")
                self._idle_deadline = None
                self._leave("idle_timeout")
            else:
                self._set("tv_m_text", "Bez odpovědi za %d s Televizi vypnu a uvolním místo na NASu." % int(left + 0.99))

    def _player_speed(self) -> Tuple[bool, float]:
        if not self._cond("Player.HasVideo"):
            return False, 1.0
        paused = self._cond("Player.Paused")
        if self._cond("Player.Forwarding"):
            return paused, 2.0
        if self._cond("Player.Rewinding"):
            return paused, -2.0
        return paused, 1.0

    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    #  Vstupy
    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    def onAction(self, action) -> None:
        aid = action.getId()
        _uc.device_observe_action(aid)
        key, digit = self._actions.get(aid, ("", None))
        if not key:
            return
        with self._lock:
            if self.state is None or self._leaving:
                return
            if key in ("mouse_move", "click"):
                self._mouse(key, action)
                return
            self._key(key, digit)

    def _key(self, key: str, digit: Optional[int] = None) -> None:
        """Klávesa → automat podle vrstvy a fokusu (navigaci v panelu, na čipech a tlačítkách karty dělá nativně Kodi)."""
        now = self._now()
        if key == "stop":
            self._leave("stop")                       # Stop na ovladači = odchod z Televize (§5)
            return
        layer = self.state.layer
        focus = self._focused()
        if self._idle_deadline is not None:
            if focus in CARD_BUTTONS and key in ("left", "right", "select"):
                return                                # volba v dotazu (OK = onClick)
            self._presence(now)                       # jakýkoli jiný vstup = divák je tu
            return
        if key in ("wheel_up", "wheel_down"):
            if layer == _st.REORDER:
                self._run(self.state.key("up" if key == "wheel_up" else "down", now))
            return                                    # v panelu kolečko posouvá nativní seznam
        if layer == _st.REORDER:
            self._run(self.state.key(key, now, digit))
            return
        if layer == _st.PANEL:
            self._key_panel(key, digit, focus, now)
            return
        if self._card_kind == "msg" and focus in CARD_BUTTONS:
            if key in ("left", "right", "select"):
                return                                # ◀▶ mezi volbami řeší Kodi, OK = onClick
            if key == "back" and self._card_window_only:
                self._hide_card()                     # karta okna (pauza uvolnila místo…) — Zpět ji jen zavře
                return
        self._run(self.state.key(key, now, digit))

    def _key_panel(self, key: str, digit: Optional[int], focus: int, now: float) -> None:
        if key == "back":
            if focus in ACTION_BUTTONS:
                self._focus(LIST)                     # Zpět z akcí řádku = zpět do seznamu (§5)
                return
            self._run(self.state.key("back", now))
            return
        if key == "digit" and digit is not None:
            self._panel_digit(digit, now)
            return
        if key == "menu":
            if focus == LIST and self._focus_cid:
                self._show_preview(self._focus_cid)
                self._focus(ACT_FAV)                  # akce řádku (★ / ⇅ / Skrýt); bez tlačítka Menu stačí ▶
            return
        if key in ("pause", "play"):
            self._run(self.state.key(key, now))
        # ▲▼◀▶, OK, Ch± → nativní navigace Kodi (seznam, čipy, tlačítka; OK = onClick); FF / RW řeší tik

    def onFocus(self, control_id: int) -> None:
        if control_id != HOT_EDGE:
            return
        with self._lock:
            if self.state is not None and not self._leaving and self.state.layer != _st.PANEL:
                self._run(self.state.key("hot_edge", self._now()))

    def _mouse(self, key: str, action) -> None:
        now = self._now()
        layer = self.state.layer
        if layer != _st.PANEL:
            if key == "mouse_move" and layer in (_st.CLEAN, _st.BAR) and now - self._mouse_bar_at >= MOUSE_BAR_S:
                self._mouse_bar_at = now
                self._run(self.state.key("info", now))   # pohyb myši = lišta (§5)
            return
        x = self._mouse_x(action)
        outside = x is not None and x > PANEL_RIGHT_PX
        if key == "click" and outside:
            self._run(self.state.key("away", now))       # klik do videa = panel odjede (bez obrazu zůstane)
            return
        if key == "mouse_move":
            self._mouse_away_since = (self._mouse_away_since or now) if outside else None

    def _mouse_x(self, action) -> Optional[float]:
        """Poloha myši v souřadnicích okna 1080i (Kodi posílá pixely obrazovky)."""
        try:
            x = float(action.getAmount1())
            w = float(xbmcgui.getScreenWidth() or 0)
        except Exception:
            return None
        return x * 1920.0 / w if w > 0 else None

    def onClick(self, control_id: int) -> None:
        with self._lock:
            if self.state is None or self._leaving:
                return
            now = self._now()
            if control_id == LIST:
                self._click_row(now)
            elif control_id == CHIPS:
                self._click_chip()
            elif control_id == ALPHA:
                self._click_alpha()
            elif control_id == MUTE_BUTTON:
                self._run(self.state.key("mute", now))
            elif control_id in CARD_BUTTONS:
                self._click_card(CARD_BUTTONS.index(control_id), now)
            elif control_id == ACT_FAV:
                self._toggle_flag(_prefs.FAV)
            elif control_id == ACT_HIDE:
                self._toggle_flag(_prefs.HIDE)
            elif control_id == ACT_MOVE:
                self._run(self.state.set_panel_focus(self._focus_cid))
                self._run(self.state.start_reorder(now))
            elif control_id in (REORDER_UP, REORDER_DOWN, REORDER_DROP):
                key = {REORDER_UP: "up", REORDER_DOWN: "down", REORDER_DROP: "select"}[control_id]
                self._run(self.state.key(key, now))
                if self.state.layer == _st.REORDER:
                    self._focus(FOCUS_REORDER)

    def on_data_changed(self, domains) -> None:
        """`RMNavMixin`: osobní seznam změnilo jiné zařízení profilu / pull služby → přestavět pohled (na místě)."""
        if _prefs.DATA_REV_DOMAIN in set(domains or ()):
            self._reload_view(reason="data_rev")

    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    #  Povely automatu
    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    def _run(self, effects: Optional[Sequence[Tuple[str, dict]]]) -> None:
        effects = list(effects or ())
        tuned = any(name == "tune" for name, _kw in effects)
        for name, kw in effects:
            handler = self._FX.get(name)
            if handler is None:
                _log("TV_WINDOW unknown effect %s" % name, warning=True)
                continue
            if name == "number_hide":
                kw = dict(kw, _tuned=tuned)
            try:
                handler(kw)
            except Exception as exc:
                _log("TV_WINDOW effect %s failed: %r" % (name, exc), warning=True)

    # ── naladění ────────────────────────────────────────────────────────────────────────────────────────────────────
    def _fx_tune(self, kw: dict) -> None:
        self._begin_tune(kw["ch"], retune=False)

    def _fx_retune(self, kw: dict) -> None:
        _log("TV_WINDOW retune ch=%s attempt=%s" % (kw.get("ch"), kw.get("attempt")))
        self._begin_tune(kw["ch"], retune=True)

    def _begin_tune(self, ch: str, *, retune: bool) -> None:
        if self._leaving:
            return
        self._zap = {"t_key": self._now()}
        self._show_tune_card(ch, retune)
        self._spawn("RMTvTune", lambda: self._tune_worker(ch))

    def _isa(self) -> bool:
        """Přehrávač živého vysílání (ISA) — jednou za otevření okna (pojistka `ensure_isa`, služba ho zapíná sama)."""
        if self._isa_cached is None:
            import richmovie_livetv_ui as _live_ui
            self._isa_cached = bool(_live_ui.ensure_isa())
        return self._isa_cached

    def _probe(self, base: str) -> bool:
        """Sonda `/tv/health` jen při otevření okna a po chybě — výsledek drží okno (plán §3.6)."""
        if base not in self._probed:
            self._probed[base] = bool(_tv.health_probe(base))
        return self._probed[base]

    def _tune_worker(self, ch: str) -> None:
        """Tiket → cesta k NASu → JEDINÝ stavitel položky → JEDINÉ spuštění (`request_live`, video v okně)."""
        csid = str(uuid.uuid4())
        try:
            isa = self._isa()
            sess = _tv.open_session(ch, isa=isa, client_session_id=csid)
            t_ticket = self._now()
            url = _tv.pick_url(sess["urls"], self._probe)
            if url is None:
                raise _tv.LiveError("nas_unreachable")
        except _tv.LiveError as err:
            _log("LIVE_ZAP_FAILED ch=%s code=%s status=%s detail=%s" % (ch, err.code, err.status, err.detail[:160]),
                 warning=True)
            with self._lock:
                self._ticket_failed(ch, err)
            return
        except Exception as exc:     # zrušené spojení při vypnutí Kodi / nečekaná chyba — okno nesmí zůstat viset
            _log("LIVE_ZAP_FAILED ch=%s err=%r" % (ch, exc), warning=True)
            with self._lock:
                self._ticket_failed(ch, _tv.LiveError("livetv_error", detail=repr(exc)))
            return
        with self._lock:
            stale = self._leaving or self.state is None or self.state.opening != ch
            if not stale:
                self._remember_ticket(csid, ch)
                self._opening = (ch, csid, self._zap.get("t_key", t_ticket))
                self._zap["t_ticket"] = t_ticket
            cur = _epg.now_of(self._now_rec, ch).get("current") or {}
            name, logo = self._name(ch), self._logo(ch, 512)
        if stale:                     # okno odchází / otevírání vypršelo — místo na NASu hned uvolnit
            _log("LIVE_ZAP_ABANDONED ch=%s" % ch)
            self._end_session_async(csid, "tv_abandoned")
            return
        li = _tv.build_live_item(url, channel=ch, name=name, csid=csid, isa=isa, logo=logo,
                                 plot=str(cur.get("title") or ""))
        result = _dispatch.request_live(url, li, channel=ch)
        with self._lock:
            self._zap["t_play"] = self._now()
            if result == "sent":
                _log("LIVE_ZAP_SENT ch=%s csid=%s isa=%s base=%s" % (ch, csid[:8], isa, _tv.base_of(url)))
                self._on_play_sent(ch)
                return
            _log("LIVE_ZAP_FAILED ch=%s dispatch=%s" % (ch, result), warning=True)
            self._opening = None
            self._ticket_failed(ch, _tv.LiveError("livetv_error", detail="dispatch_" + str(result)))
        self._end_session_async(csid, "tv_dispatch_" + str(result))

    def _on_play_sent(self, ch: str) -> None:
        """`request_live` odeslal kanál přehrávači: Kodi dosavadní obraz NAHRADÍ (i když se nový neotevře) → okno ani
        automat ho už nesmí brát jako hrající („● hraje“, „Zůstat na …“, návrat po odmítnutí — audit Fable W-3)."""
        if self._playing is not None:
            self._playing = None
            self._mark_playing_rows()
        self._run(self.state.play_sent(ch))

    def _remember_ticket(self, csid: str, ch: str) -> None:
        self._tickets[csid] = ch
        while len(self._tickets) > TICKETS_KEPT:
            self._tickets.pop(next(iter(self._tickets)))

    def _ticket_failed(self, ch: str, err: "_tv.LiveError") -> None:
        """Tiket / spuštění selhalo. Hraje-li starý kanál, nebo jde o kód, který se automaticky neopakuje (409, 429,
        trvalé) → `tune_rejected` (starý kanál hraje dál, karta s větou nemodálně); jinak (nic nehraje, přechodná
        chyba) → `playback_failed` = automatické přeladění nejvýš 3× (automat)."""
        if self.state is None or self._leaving:
            return
        now = self._now()
        self._probed.clear()                          # po chybě se cesta k NASu ověří znovu
        self._card_offer = err.offer if err.code == "slots_full" else None
        playing = self._playing is not None and not self.state.released
        if err.code in _st.NO_RETRY_CODES or playing:
            fx = self.state.tune_rejected(now, err.code)
        else:
            fx = self.state.playback_failed(now, err.code)
        _log("TV_WINDOW ticket_failed ch=%s code=%s playing=%s → %s" % (
            ch, err.code, self._playing[0] if self._playing else "-", ",".join(n for n, _k in fx) or "retune_later"))
        self._run(fx)
        if self._card_kind == "tune" and self.state.opening is None and self.state.retune_due is None:
            self._hide_card()

    # ── stav přehrávání od služby ───────────────────────────────────────────────────────────────────────────────────
    def _poll_live_state(self, now: float) -> List[Tuple[str, dict]]:
        raw = self._home_prop(_tv.PROP_LIVE_STATE)
        if not raw or raw == self._last_state_raw:
            return []
        self._last_state_raw = raw
        try:
            st = json.loads(raw)
        except ValueError:
            return []
        if not isinstance(st, dict):
            return []
        csid, stage = str(st.get("csid") or ""), str(st.get("stage") or "")
        if csid not in self._tickets:
            return []                                 # cizí / staré přehrávání — okna se netýká
        ch = str(st.get("channel") or "") or self._tickets[csid]
        if stage == "playing":
            if not (self._playing and self._playing[1] == csid):
                self._seek_seen = (csid, _seek_count(st.get("seeks")))   # přetočení PŘED obrazem v okně se nepočítá
                return self._on_playing(ch, csid, now)
            return self._on_live_seek(csid, st.get("seeks"), now)
        playing_it = bool(self._playing and self._playing[1] == csid)
        opening_it = bool(self._opening and self._opening[1] == csid)
        if stage in ("ended", "error"):
            if not (playing_it or opening_it):
                return []
            self._playing = None if playing_it else self._playing
            self._opening = None if opening_it else self._opening
            self._probed.clear()
            _log("TV_WINDOW playback %s ch=%s code=%s" % (stage, ch, st.get("code") or "-"))
            return self.state.playback_failed(now, str(st.get("code") or "livetv_error"))
        if stage == "stopped" and (playing_it or opening_it) and csid not in self._expected_stops:
            _log("TV_WINDOW stopped zvenku ch=%s → odchod" % ch)   # i když „playing“ zapadl v témže tiku (Fable W-5)
            self._playing = None
            self._opening = None
            self._leave("stopped_externally")         # Televize hraje jen s oknem a okno jen s Televizí
        return []

    def _on_playing(self, ch: str, csid: str, now: float) -> List[Tuple[str, dict]]:
        if self._playing and self._playing[1] == csid:
            return []
        self._playing = (ch, csid)
        self._playing_since = now
        self._watched_noted = None
        if self._opening and self._opening[1] == csid:
            t_key = self._opening[2]
            self._opening = None
            z = self._zap
            _log("LIVE_ZAP ch=%s t_ticket_ms=%d t_play_ms=%d t_av_ms=%d" % (
                ch, int((z.get("t_ticket", now) - t_key) * 1000), int((z.get("t_play", now) - t_key) * 1000),
                int((now - t_key) * 1000)))
        if self._card_kind == "tune" or (self._card_kind == "msg" and self._card_window_only):
            self._hide_card()
        self._mark_playing_rows()
        fx = self.state.playback_started(ch, now)
        if self._get("tv_bar") == "1":
            self._fill_bar(self.state.preselect or self.state.current)
        return fx

    # ── lišta ───────────────────────────────────────────────────────────────────────────────────────────────────────
    def _fx_bar_show(self, kw: dict) -> None:
        if self._card_kind == "msg":
            self._hide_card()                         # ▲▼ / Info nad kartou = divák jde dál, lišta ji nahradí (§4.6)
        self._fill_bar(kw.get("ch"))
        self._set("tv_bar", "1")

    def _fx_bar_hide(self, _kw: dict) -> None:
        self._set("tv_bar", "")
        if self._card_kind == "msg" and not self._card_window_only:
            self._hide_card()                         # Zpět z karty chyby (vrstva CARD automatu)

    def _fill_bar(self, ch: Optional[str]) -> None:
        if not ch:
            return
        now_dt = _epg.server_now(self._now_rec, time.time())
        slot = _epg.now_of(self._now_rec, ch)
        cur, nxt = slot.get("current"), slot.get("next")
        self._set_logo_props("tv_b", ch, 512)
        self._set("tv_b_num", self._number(ch))
        self._set("tv_b_name", self._name(ch))
        self._set("tv_b_title", (cur or {}).get("title") or "")
        self._set("tv_b_meta", meta_text(cur))
        self._set("tv_b_start", _clock((cur or {}).get("start")))
        self._set("tv_b_end", _clock((cur or {}).get("end")))
        self._set("tv_b_left", _tv.remaining_text(cur, now_dt) if cur else "")
        frac = _tv.progress(cur, now_dt)
        bar = self._ctl(BAR_PROGRESS)
        if bar is not None and frac is not None:
            try:
                bar.setPercent(frac * 100.0)
            except Exception:
                pass
        nxt_text = ""
        if isinstance(nxt, dict) and nxt.get("title"):
            nxt_text = "Pak %s %s" % (_clock(nxt.get("start")), nxt["title"])
        self._set("tv_b_next", nxt_text)
        audio = [str(a).upper() for a in ((self._rows.get(ch) or {}).get("audio") or []) if a]
        extra = [" · ".join(audio)] if audio else []
        stale = _epg.stale_label(self._now_rec, time.time())
        if stale:
            extra.append(stale)
        self._set("tv_b_extra", "   ".join(extra))
        self._set("tv_b_up", self._neighbour_text(ch, -1, "▲"))
        down = self._neighbour_text(ch, 1, "▼")
        if self.state is not None and self.state.previous:
            down = (down + "      0 = předchozí").strip()
        self._set("tv_b_down", down)
        self._set("tv_b_status", self._status_text(ch))

    def _status_text(self, ch: str) -> str:
        st = self.state
        if st is None:
            return ""
        if st.preselect == ch and ch != st.current:
            return TEXT_PRESELECT
        if st.released:
            return TEXT_RELEASED
        if st.paused_at is not None:
            return TEXT_PAUSED
        if st.retune_due is not None or (st.opening == ch and st.retune_attempt):
            return TEXT_RETUNE
        return TEXT_LIVE if (self._playing and self._playing[0] == ch) else ""

    def _neighbour_text(self, ch: str, delta: int, arrow: str) -> str:
        chans = self.state.channels if self.state else []
        if ch not in chans or len(chans) < 2:
            return ""
        nb = chans[(chans.index(ch) + delta) % len(chans)]
        title = (_epg.now_of(self._now_rec, nb).get("current") or {}).get("title") or ""
        return "%s %s %s%s" % (arrow, self._number(nb), self._name(nb), (": " + title) if title else "")

    # ── panel ───────────────────────────────────────────────────────────────────────────────────────────────────────
    def _fx_panel_open(self, kw: dict) -> None:
        ch = kw.get("ch")
        if self._pending_flags:
            self._pending_flags = False
            self._reload_view(reason="panel_open", refill=False)
        if not self._filter:
            self._filter = F_FAV if (self._view and ch in self._view.favorites) else F_ALL
        if ch and ch not in self._ids_for(self._filter):
            self._filter = F_ALL                      # fokus vždy na aktuálním kanálu (§4.3)
        if not self._list_ids or self._list_ids != self._ids_for(self._filter):
            self._refill_filtered(animate=False)
        if self._card_kind:
            self._hide_card()
        self._select_row(ch)
        self._focus_cid = ch
        self._focus_since = self._now()
        self._preview_cid = None
        self._mouse_away_since = None
        self._run(self.state.set_panel_focus(ch))
        self._set("tv_bar", "")
        self._set("tv_preview", "")
        self._set("tv_panel", "1")
        self._focus(LIST)
        self._ensure_panel_focus()                    # prázdný filtr (★ zrušené jinde): fokus na čipy (Fable F21-4)

    def _ensure_panel_focus(self) -> None:
        """Otevřený panel a fokus mimo jeho ovládací prvky (Kodi nedá fokus prázdnému seznamu — první spuštění bez
        kanálů, skrytý poslední oblíbený, prázdný filtr; 4.2.1) → do seznamu, je-li v něm něco, jinak na čipy (cesta ven).
        Fokus karty, akcí řádku ani hledání se nebere. JEDINÉ místo — volá ho `_refill_filtered`."""
        if self.state is None or self.state.layer != _st.PANEL:
            return
        focus = self._focused()
        if focus in CARD_BUTTONS or (focus in PANEL_CONTROLS and not (focus == LIST and not self._list_ids)):
            return
        self._focus(LIST if self._list_ids else CHIPS)

    def _fx_panel_close(self, _kw: dict) -> None:
        self._set("tv_panel", "")
        self._set("tv_preview", "")
        self._preview_cid = None
        self._panel_digits = ""
        self._mouse_away_since = None
        self._focus(FOCUS_SCREEN)
        if self._pending_flags:
            self._reload_view(reason="panel_close", refill=False)   # čísla a ▲▼ bez skrytých hned; řádky při otevření

    def _fx_panel_focus(self, kw: dict) -> None:
        self._select_row(kw.get("ch"))

    def _panel_tick(self, now: float) -> None:
        """Panel: fokus seznamu → automat, karta náhledu po klidu, hledání psaním, číslo, myš pryč."""
        if self.state.layer != _st.PANEL:
            return
        if self._focused() == LIST:
            cid = self._selected_cid()
            if cid and cid != self._focus_cid:
                self._focus_cid = cid
                self._focus_since = now
                self._run(self.state.set_panel_focus(cid))
        if self._focus_cid and self._focus_cid != self._preview_cid:
            self._show_preview(self._focus_cid)          # karta HNED: text, obrázek i „Dál dnes“ z přednačtení
        self._prefetch_tick(now)
        self._search_tick(now)
        if self._panel_digits and now - self._panel_digits_at >= _st.NUMBER_S:
            self._panel_digits = ""
        if self._mouse_away_since is not None and now - self._mouse_away_since >= MOUSE_AWAY_S:
            self._mouse_away_since = None
            self._run(self.state.key("away", now))     # myš pryč: panel odjede jen nad obrazem (jinak je domovem)

    def _selected_cid(self) -> Optional[str]:
        lst = self._ctl(LIST)
        if lst is None:
            return None
        try:
            i = int(lst.getSelectedPosition())
        except Exception:
            return None
        return self._list_ids[i] if 0 <= i < len(self._list_ids) else None

    def _select_row(self, ch: Optional[str]) -> None:
        if not ch or ch not in self._list_ids:
            return
        lst = self._ctl(LIST)
        if lst is not None:
            try:
                lst.selectItem(self._list_ids.index(ch))
            except Exception:
                pass

    def _click_row(self, now: float) -> None:
        cid = self._selected_cid()
        if not cid:
            return
        if self._filter == F_HIDDEN or self._is_hidden(cid):
            self._toggle_flag(_prefs.HIDE, cid)       # „Skrytý · OK = vrátit“ (§4.5)
            return
        self._run(self.state.set_panel_focus(cid))
        self._run(self.state.key("select", now))

    def _panel_digit(self, digit: int, now: float) -> None:
        """Číslice v panelu = skok na kanál s tím číslem (v aktuálním pohledu, R-3)."""
        self._panel_digits = (self._panel_digits + str(digit))[:_st.NUMBER_MAX_DIGITS]
        self._panel_digits_at = now
        cid = self._view.channel_by_number(self._panel_digits) if self._view else None
        if cid and cid in self._list_ids:
            self._select_row(cid)

    def _show_preview(self, cid: str) -> None:
        """Karta náhledu pořadu HNED při změně fokusu (Richie 08.11.2026: „strašně dlouho trvá, než se zobrazí náhled“):
        text z dat `/now`, obrázek `_card_image` (tutéž adresu Kodi přednačetl řádkům — `preloaditems`), popis a „Dál
        dnes“ z přednačteného programu (`_prefetch_tick`; dorazí-li později, doplní se na místě). Poprvé se karta
        rozloží z řádku (morph), další změny fokusu mění obsah na místě (obrázek se prolne `fadetime`)."""
        first = self._preview_cid is None
        self._preview_cid = cid
        cur = _epg.now_of(self._now_rec, cid).get("current") or {}
        self._set("tv_p_name", self._name(cid))
        self._set("tv_p_title", cur.get("title") or self._name(cid))
        times = ("%s–%s" % (_clock(cur.get("start")), _clock(cur.get("end")))) if cur.get("start") else ""
        self._set("tv_p_meta", " · ".join(p for p in (times, meta_text(cur)) if p))
        self._set("tv_p_img", self._card_image(cid) or self._preview_epg_view(cid)[2])
        self._set_action_labels(cid)
        self._apply_preview_epg(cid, image=False)   # popis + „Dál dnes“ JEDNÍM zápisem (bez mazání — H3-b)
        if first:
            self._morph_preview()
            self._set("tv_preview", "1")

    def _morph_preview(self) -> None:
        """Karta se rozloží z obdélníku zaměřeného řádku (`Container(9000).Position` = řádek na obrazovce)."""
        try:
            pos = int(self._info("Container(%d).Position" % LIST) or 0)
        except ValueError:
            pos = 0
        src = (LIST_X, LIST_Y + max(0, pos) * ROW_H, LIST_W, ROW_H)
        reduced = self._home_prop("rm_motion") == "reduced"
        anims = (_motion.morph_from(src, PREVIEW_RECT, direction="in", reduced=reduced)
                 + _motion.morph_from(src, PREVIEW_RECT, direction="out", reduced=reduced))
        grp = self._ctl(PREVIEW_GROUP)
        if grp is not None:
            try:
                grp.setAnimations(anims)
            except Exception as exc:          # záloha = zoom ze středu z XML (H10)
                _log("TV_WINDOW morph fallback: %r" % (exc,), warning=True)

    def _prefetch_tick(self, now: float) -> None:
        """Přednačtení programu kolem fokusu (F4d-2): fokus + 10 kanálů po směru listování + 1 proti směru jedním
        dotazem `/epg?channels=`; nejvýš JEDEN dotaz naráz, další plán až po jeho konci podle AKTUÁLNÍHO fokusu
        (rychlé listování nestaví frontu starých dávek); po selhání odklad `FAIL_BACKOFF_S`."""
        if (self._prefetch_busy or now < self._prefetch_retry_at or not self._focus_cid
                or now - self._prefetch_last_at < _prefetch.MIN_INTERVAL_S):
            return
        try:
            idx = self._list_ids.index(self._focus_cid)
        except ValueError:
            return
        self._prefetch_dir = _prefetch.direction(self._prefetch_prev_idx, idx, self._prefetch_dir)
        self._prefetch_prev_idx = idx
        fetched = {ch: rec[0] for ch, rec in self._preview_epg.items()}
        asked = _prefetch.plan(self._list_ids, self._focus_cid, self._prefetch_dir, fetched,
                               self._prefetch_inflight, now)
        if not asked:
            return
        self._prefetch_busy, self._prefetch_inflight, self._prefetch_last_at = True, set(asked), now
        try:
            self._spawn("RMTvPrefetch", lambda: self._prefetch_worker(asked))
        except Exception as exc:                  # vlákno nevzniklo → nic neběží, příští tik to zkusí po odkladu
            _log("TV_PREFETCH spawn failed: %r" % (exc,), warning=True)
            self._prefetch_busy, self._prefetch_inflight = False, set()
            self._prefetch_retry_at = now + _prefetch.FAIL_BACKOFF_S

    def _prefetch_worker(self, asked: List[str]) -> None:
        """Jedna dávka programu (vlákno). Uloží JEN kanály, které odpověď opravdu nese (R2: chybějící = příště znovu);
        zaměřený kanál mezi nimi → karta se doplní na místě. Konec vždy uvolní single-flight (i po výjimce)."""
        t0 = time.monotonic()
        failed = True
        try:
            utc = _dt.datetime.now(_dt.timezone.utc)
            q = urllib.parse.urlencode({
                "channels": ",".join(asked),
                "from": (utc - _dt.timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "to": (utc + _dt.timedelta(hours=PREVIEW_HOURS)).strftime("%Y-%m-%dT%H:%M:%SZ")})
            try:
                data = _tv.call("GET", "/v1/livetv/epg?" + q, background=True)
            except _tv.LiveError as err:
                _log("TV_PREFETCH failed n=%d code=%s ms=%d" % (len(asked), err.code, (time.monotonic() - t0) * 1000))
                return
            got, missing = _prefetch.split_batch(data, asked)
            failed = bool(missing)                # neúplná odpověď = selhání kontraktu → odklad (H2-a), uložené zůstane
            with self._lock:
                if self._rm_closed:
                    return
                stamp = self._now()                   # hodiny okna (monotonic) = tytéž jako plán (H2-c)
                for ch, events in got.items():
                    self._preview_epg[ch] = (stamp, events)
                if self._preview_cid in got:
                    self._apply_preview_epg(self._preview_cid)
            _log("TV_PREFETCH n=%d ok=%d missing=%d ms=%d" % (len(asked), len(got), len(missing),
                                                             (time.monotonic() - t0) * 1000))
        finally:
            with self._lock:
                self._prefetch_busy, self._prefetch_inflight = False, set()
                if failed:
                    self._prefetch_retry_at = self._now() + _prefetch.FAIL_BACKOFF_S

    def _card_image(self, cid: Optional[str]) -> str:
        """Obrázek karty náhledu = pozadí běžícího pořadu 640 px (`card_path` z `/now`), jinak plakát. JEDINÉ místo:
        řádek seznamu ho nese jako art `card` (Kodi ho přednačte — `preloaditems`) a karta bere tutéž adresu."""
        if not cid:
            return ""
        cur = _epg.now_of(self._now_rec, cid).get("current") or {}
        return self._image(cur.get("card_path") or cur.get("poster_path"))

    def _apply_preview_epg(self, cid: str, image: bool = True) -> None:
        """Popis a „Dál dnes“ karty z přednačteného programu — každá hodnota JEDNÍM zápisem (bez dat prázdné);
        obrázek z programu jen když `/now` žádný nedal (`_card_image`)."""
        plot, nexts, img = self._preview_epg_view(cid)
        self._set("tv_p_plot", plot)
        for i, text in enumerate(nexts, 1):
            self._set("tv_p_next%d" % i, text)
        if image and img and not self._card_image(cid):
            self._set("tv_p_img", img)

    def _preview_epg_view(self, cid: str) -> Tuple[str, List[str], str]:
        """(popis běžícího pořadu, „Dál dnes“ × 3, obrázek z programu) z přednačtení; bez dat prázdné."""
        cached = self._preview_epg.get(cid)
        now_dt = _epg.server_now(self._now_rec, time.time())
        current, upcoming = None, []
        for ev in (cached[1] if cached else []):
            start, end = _tv.parse_iso(ev.get("start")), _tv.parse_iso(ev.get("end"))
            if start is None or end is None:
                continue
            if start <= now_dt < end:
                current = ev
            elif start >= now_dt:
                upcoming.append(ev)
        plot = (current.get("description") or "") if current is not None else ""
        img = self._image(current.get("card_path") or current.get("backdrop_path") or current.get("poster_path")) \
            if current is not None else ""
        nexts = [("%s  %s" % (_clock(ev.get("start")), ev.get("title") or "")) if ev else ""
                 for ev in (upcoming[i] if len(upcoming) > i else None for i in range(3))]
        return plot, nexts, img

    def _set_action_labels(self, cid: str) -> None:
        fav, hidden = self._is_fav(cid), self._is_hidden(cid)
        self._set("tv_p_fav_label", "★  Oblíbený" if fav else "+  Do oblíbených")
        self._set("tv_p_hide_label", "Vrátit" if hidden else "Skrýt")
        self._set("tv_p_hidden", "1" if hidden else "")

    # ── čipy, hledání, abeceda ──────────────────────────────────────────────────────────────────────────────────────
    def _chips(self) -> List[Tuple[str, str]]:
        """(klíč filtru, popisek): ★ Oblíbené (jen když jsou) · Vše · kategorie (jen neprázdné, pořadí Gate) ·
        Skryté (n) (jen když jsou)."""
        v = self._view
        if v is None:
            return []
        out = []
        if v.favorites:
            out.append((F_FAV, "★ Oblíbené"))
        out.append((F_ALL, "Vše"))
        present = {self._category(c) for c in v.visible}
        for code in self._categories:
            if code in present:
                out.append((F_CAT + code, CATEGORY_LABELS.get(code, code)))
        if v.hidden:
            out.append((F_HIDDEN, "Skryté (%d)" % len(v.hidden)))
        return out

    def _category(self, cid: str) -> str:
        return str((self._rows.get(cid) or {}).get("category") or "other")

    def _ids_for(self, flt: str) -> List[str]:
        v = self._view
        if v is None:
            return []
        if flt == F_FAV:
            return list(v.favorites)
        if flt == F_HIDDEN:
            return list(v.hidden)
        if flt.startswith(F_CAT):
            code = flt[len(F_CAT):]
            return [c for c in v.visible if self._category(c) == code]
        if flt.startswith(F_SEARCH):
            needle = fold(flt[len(F_SEARCH):]).strip()
            return [c for c in v.visible if needle in fold(self._name(c))] if needle else list(v.visible)
        return list(v.visible)

    def _click_chip(self) -> None:
        lst = self._ctl(CHIPS)
        if lst is None:
            return
        try:
            key = lst.getSelectedItem().getProperty("key")
        except Exception:
            return
        if key and key != self._filter:
            self._filter = key
            self._refill_filtered(animate=True)
            self._select_row(self.state.current or self.state.panel_focus)   # bez naladěného kanálu kurzor
        self._focus(LIST)

    def _search_tick(self, now: float) -> None:
        if self._focused() != SEARCH:
            return
        edit = self._ctl(SEARCH)
        if edit is None:
            return
        try:
            text = str(edit.getText() or "")
        except Exception:
            return
        if text != self._search_text:
            self._search_text = text
            self._search_at = now
            return
        if self._search_at is None or now - self._search_at < SEARCH_CALM_S:
            return
        self._search_at = None
        if text.strip():
            if not self._filter.startswith(F_SEARCH):
                self._filter_before_search = self._filter
            self._filter = F_SEARCH + text.strip()
        elif self._filter.startswith(F_SEARCH):
            self._filter = self._filter_before_search or F_ALL
        else:
            return
        self._refill_filtered(animate=True)

    def _click_alpha(self) -> None:
        lst = self._ctl(ALPHA)
        if lst is None:
            return
        try:
            letter = lst.getSelectedItem().getLabel()
        except Exception:
            return
        for cid in self._list_ids:
            if initial_of(self._name(cid)) == letter:
                self._select_row(cid)
                break
        self._focus(LIST)

    # ── ★ / skryté ──────────────────────────────────────────────────────────────────────────────────────────────────
    def _flag_now(self, kind: str, cid: str) -> bool:
        try:
            return _prefs.flag_on(_prefs.load_state(), kind, cid)
        except Exception:
            return False

    def _is_fav(self, cid: str) -> bool:
        """Pohled (`_view`) se přestaví až při dalším otevření panelu — změna v otevřeném panelu se čte ze souboru."""
        return self._flag_now(_prefs.FAV, cid) if self._pending_flags else bool(self._view and self._view.is_fav(cid))

    def _is_hidden(self, cid: str) -> bool:
        return self._flag_now(_prefs.HIDE, cid) if self._pending_flags else bool(self._view and self._view.is_hidden(cid))

    def _toggle_flag(self, kind: str, cid: Optional[str] = None) -> None:
        """★ / skrýt na zaměřeném kanálu: řádek se změní NA MÍSTĚ (hvězda, ztlumení na 40 % se štítkem); složení
        seznamu se změní až při dalším otevření panelu (žádný přeskok řádků pod rukou, okamžité „zpět“, §4.5)."""
        cid = cid or self._focus_cid or self._selected_cid()
        if not cid:
            return
        new = _prefs.toggle_fav(cid) if kind == _prefs.FAV else _prefs.toggle_hide(cid)
        if new is None:
            self._hint("Změnu se nepodařilo uložit — zkus to znovu.")
            return
        self._pending_flags = True
        self._snapshot_rev()
        self._refresh_row(cid)
        self._set_action_labels(cid)
        if kind == _prefs.FAV:
            self._hint("%s %s" % (self._name(cid), "je mezi oblíbenými" if new else "už není mezi oblíbenými"))
        else:
            self._hint("%s %s" % (self._name(cid), "je skrytý · OK = vrátit" if new else "je zpět v seznamu"))

    # ── zadávání čísla ──────────────────────────────────────────────────────────────────────────────────────────────
    def _fx_number_show(self, kw: dict) -> None:
        digits = str(kw.get("digits") or "")
        self._number_digits = digits
        self._set("tv_n_digits", digits + ("_" if len(digits) < _st.NUMBER_MAX_DIGITS else ""))
        n = int(digits) if digits.isdigit() else 0
        chans = self.state.channels
        if 1 <= n <= len(chans):
            ch = chans[n - 1]
            self._set_logo_props("tv_n", ch, 256)
            self._set("tv_n_name", self._name(ch))
            self._set("tv_n_title", (_epg.now_of(self._now_rec, ch).get("current") or {}).get("title") or "")
        else:
            for k in ("tv_n_logo", "tv_n_mono", "tv_n_name"):
                self._set(k, "")
            self._set("tv_n_title", "Kanál %s v seznamu není" % digits)
        self._set("tv_number", "1")

    def _fx_number_hide(self, kw: dict) -> None:
        self._set("tv_number", "")
        digits, self._number_digits = self._number_digits, ""
        if not kw.get("_tuned") and digits.isdigit() and not 1 <= int(digits) <= len(self.state.channels):
            self._hint("Kanál %s v seznamu není" % digits)

    # ── ztlumení, pauza, rychlost, skok ─────────────────────────────────────────────────────────────────────────────
    def _fx_mute_toggle(self, _kw: dict) -> None:
        if self._mute is not None:
            self._mute.toggle()                       # cílový stav podle Kodi; ikony řídí Player.Muted v XML

    def _fx_pause(self, _kw: dict) -> None:
        self._update_pause_hint()

    def _update_pause_hint(self) -> None:
        """Pozastavený kanál: nápověda „Pozastaveno · OK = živě“ drží, dokud pauza trvá (lišta sama odjede)."""
        st = self.state
        paused = st.paused_at is not None and not st.released
        if paused and self._hint_until is None and self._get("tv_hint") != TEXT_PAUSED:
            self._set("tv_hint", TEXT_PAUSED)
        elif not paused and self._get("tv_hint") == TEXT_PAUSED:
            self._set("tv_hint", "")

    def _fx_pause_release(self, _kw: dict) -> None:
        """Pauza trvá `PAUSE_RELEASE_S` (R-2: nejvýš 2 min) → zastavit přehrávač a ukončit relaci na NASu (místo ve
        skupině je volné); na obrazovce karta kanálu, OK = nový tiket = živé vysílání."""
        ch, csid = self._playing if self._playing else (self.state.current, "")
        _log("LIVE_POLICY action=pause_release ch=%s" % ch)
        if csid:
            self._expected_stops.add(csid)
        self._stop_player()
        self._playing = None
        if csid:
            self._end_session_async(csid, "pause_release")
        self._set("tv_hint", "")
        self._show_release_card(ch)

    def _fx_release_card(self, kw: dict) -> None:
        """Panel zavřený nad uvolněnou pauzou (Zpět / myš pryč) → zpět její karta (jinak černá plocha bez ovládání)."""
        self._show_release_card(kw.get("ch") or self.state.current)

    def _show_release_card(self, ch: Optional[str]) -> None:
        self._show_msg_card(ch, "Pauza uvolnila místo na NASu",
                            "Obraz stál přes 2 minuty, tak jsme ho zastavili — ať se může dívat i někdo jiný.",
                            [("▶  Zpět do živého vysílání", "live"), ("Odejít z Televize", "leave")], window_only=True)

    def _fx_normalize(self, _kw: dict) -> None:
        """FF / RW v živém vysílání → normální rychlost. `PlayerControl(Play)` při rychlosti 1 PŘEPNE pauzu → jen když
        přehrávač opravdu zrychluje (klávesa mohla k přehrávači dojít až po nás — pak rychlost dožene tik)."""
        if self._cond("Player.Forwarding") or self._cond("Player.Rewinding"):
            _log("LIVE_POLICY action=normalize_speed reason=ff_rw")
            self._builtin("PlayerControl(Play)")

    def _on_live_seek(self, csid: str, seeks: Any, now: float) -> List[Tuple[str, dict]]:
        """Přetočení mimo okno (Kodi `onPlayBackSeek` → služba `seeks`): živé vysílání posun nemá (plán §3.4 (2)) →
        nový tiket téhož kanálu = zpět na živé. Pozice přehrávače se NEhlídá: ISA na Androidu ji při každém posunu okna
        vysílání sníží o délku úseku (Chromecast Petry 08.11.2026 — přeladění každých ~13 s, „pořád ladím HBO“)."""
        n = _seek_count(seeks)
        seen = self._seek_seen[1] if self._seek_seen[0] == csid else 0
        if n <= seen:
            return []
        self._seek_seen = (csid, n)
        if not (self._playing and self._playing[1] == csid):
            return []
        if now - self._seek_retune_at < SEEK_RETUNE_GAP_S:
            _log("LIVE_POLICY action=none reason=seek_guard seeks=%d since_s=%.1f" % (n, now - self._seek_retune_at),
                 warning=True)
            return []
        fx = self.state.time_jump(now)
        if fx:
            self._seek_retune_at = now
        _log("LIVE_POLICY action=time_jump reason=seek seeks=%d retune=%d" % (n, int(bool(fx))))
        return fx

    def _stop_player(self) -> None:
        try:
            if self._player_present():
                self._player_stop()
        except Exception as exc:
            _log("TV_WINDOW stop failed: %r" % (exc,), warning=True)

    def _end_session_async(self, csid: str, reason: str) -> None:
        """Konec relace na NASu (best effort, `END_TIMEOUT_S`) mimo vlákno, které obsluhuje okno."""
        def _end() -> None:
            ok = _tv.end_session(reason, client_session_id=csid)
            _log("TV_WINDOW end_session reason=%s csid=%s ok=%s" % (reason, csid[:8], ok))
        self._end_threads = [t for t in self._end_threads if t.is_alive()]
        self._end_threads.append(self._spawn("RMTvEnd", _end))

    # ── karty ───────────────────────────────────────────────────────────────────────────────────────────────────────
    def _fx_error_card(self, kw: dict) -> None:
        ch, code = kw.get("ch"), str(kw.get("code") or "livetv_error")
        lines = _tv.offer_lines(self._card_offer) if code == "slots_full" else []
        playing_ch = self._playing[0] if self._playing else None
        text = _tv.LiveError(code).message
        if lines:
            text = "Sledujete jinde: " + " · ".join(line for _c, _n, line in lines)
        title = ("%s teď nejde" % self._name(ch)) if ch else "Televize teď nejde"
        buttons = card_buttons(code, ch, lines, playing_ch, self._name)
        _log("TV_WINDOW error_card ch=%s code=%s buttons=%s" % (ch, code, ",".join(a for _l, a in buttons)))
        if self._get("tv_panel") == "1":
            self._fx_panel_close({})                  # automat je už ve vrstvě CARD (chyba přišla během listování)
        self._show_msg_card(ch, title, text, buttons, window_only=False)

    def _fx_idle_ask(self, _kw: dict) -> None:
        """„Díváš se ještě?“ po 4 h bez vstupu — nemodálně v okně (žádný dialog Kodi přes obraz); `IDLE_ANSWER_S` bez
        odpovědi = konec Televize (místo na NASu se uvolní)."""
        self._show_msg_card(self.state.current, "Díváš se ještě?", "",
                            [("▶  Dívám se", "idle_yes"), ("Vypnout Televizi", "leave")], window_only=True)
        self._idle_deadline = self._now() + IDLE_ANSWER_S

    def _presence(self, now: float) -> None:
        """Odpověď na „Díváš se ještě?“: dotaz zmizí a automat dostane vstup (`info` = lišta s tím, co běží — zároveň
        vynuluje odpočet nečinnosti, jinak by se za další 4 h už nezeptal)."""
        self._idle_deadline = None
        if self._card_kind == "msg" and self._card_window_only:
            self._hide_card()
        self._run(self.state.key("info", now))

    def _show_msg_card(self, ch: Optional[str], title: str, text: str, buttons: Sequence[Tuple[str, str]], *,
                       window_only: bool) -> None:
        self._card_kind, self._card_ch, self._card_window_only = "msg", ch, window_only
        self._set_logo_props("tv_m", ch, 256)
        self._set("tv_m_title", title)
        self._set("tv_m_text", text)
        buttons = list(buttons)[:len(CARD_BUTTONS)]
        self._card_acts = [act for _label, act in buttons]
        for i in range(len(CARD_BUTTONS)):
            self._set("tv_m_b%d" % (i + 1), buttons[i][0] if i < len(buttons) else "")
        self._set("tv_bar", "")
        self._set("tv_card", "msg")
        if self.state.layer != _st.PANEL:
            self._focus(CARD_BUTTONS[0])

    def _hide_card(self) -> None:
        was = self._card_kind
        self._card_kind, self._card_window_only, self._card_offer, self._card_acts = "", False, None, []
        self._idle_deadline = None
        self._set("tv_card", "")
        if was == "msg" and self._focused() in CARD_BUTTONS:
            self._focus(FOCUS_SCREEN)

    def _click_card(self, index: int, now: float) -> None:
        act = self._card_acts[index] if 0 <= index < len(self._card_acts) else ""
        ch = self._card_ch
        _log("TV_WINDOW card act=%s ch=%s" % (act, ch))
        if act.startswith("join:"):
            self._hide_card()
            self._run(self.state.start(act[len("join:"):], now))      # přidat se = tiket na běžící kanál skupiny
        elif act == "retry":
            self._hide_card()
            self._run(self.state.start(ch, now))
        elif act == "live":
            self._hide_card()
            self._run(self.state.key("select", now))                  # uvolněné místo → OK = nový tiket (R-2)
        elif act == "idle_yes":
            self._presence(now)
        elif act == "close":
            if self.state.layer == _st.CARD:
                self._run(self.state.key("back", now))
            else:
                self._hide_card()
        elif act == "other":
            self._hide_card()
            self._run(self.state.key("left", now))                    # panel = jiný kanál
        elif act == "reload":
            self._hide_card()
            self._spawn("RMTvData", self._initial_refresh)
        elif act == "leave":
            self._leave("card")

    def _show_tune_card(self, ch: str, retune: bool) -> None:
        """Karta ladění (logo 512 + pořad) se prolne přes obraz, zmizí, jakmile naskočí nový obraz (§3.12)."""
        self._card_kind, self._card_ch, self._card_window_only = "tune", ch, False
        self._idle_deadline = None
        self._tune_card_at = self._now()
        cur = _epg.now_of(self._now_rec, ch).get("current") or {}
        self._set_logo_props("tv_t", ch, 512)
        self._set("tv_t_text", TEXT_RETUNE if retune else "Ladím %s…" % self._name(ch))
        times = ("%s–%s" % (_clock(cur.get("start")), _clock(cur.get("end")))) if cur.get("start") else ""
        self._set("tv_t_sub", " · ".join(p for p in (cur.get("title") or "", times) if p))
        self._set("tv_card", "tune")
        if self.state.layer != _st.PANEL and self._focused() in CARD_BUTTONS:
            self._focus(FOCUS_SCREEN)

    def _tune_card_progress(self, now: float) -> None:
        """Karta ladění: po `TUNE_SLOW_S` „Pořád ladím…“. Vypršení otevírání řeší AUTOMAT (`tune_rejected(open_timeout)`
        → karta chyby s volbami, bez obrazu panel — audit Fable W-2); okno o něm samo nerozhoduje (jedna pravda)."""
        if self._card_kind != "tune":
            return
        if now - self._tune_card_at >= TUNE_SLOW_S and self._get("tv_t_text") != TEXT_RETUNE:
            self._set("tv_t_text", "Pořád ladím…")

    # ── přesun kanálu ───────────────────────────────────────────────────────────────────────────────────────────────
    def _fx_reorder_start(self, kw: dict) -> None:
        self._enter_reorder(kw.get("ch"))

    def _fx_reorder_move(self, kw: dict) -> None:
        """Automat prohodil kanál se sousedem → přepis DVOU řádků dvojčete na místě + výběr (pevná pozice drženého
        řádku = ostatní plynule projíždějí `scrolltime`)."""
        ch = kw.get("ch")
        chans = self.state.channels
        if ch not in chans:
            return
        j = chans.index(ch)
        i = j - int(kw.get("delta") or 0)
        for idx in (i, j):
            if 0 <= idx < len(chans) and idx < len(self._reorder_ids):
                self._reorder_ids[idx] = chans[idx]
                self._apply_row(LIST_REORDER, idx, self._row_fields(chans[idx], number=idx + 1))
        lst = self._ctl(LIST_REORDER)
        if lst is not None:
            try:
                lst.selectItem(j)
            except Exception:
                pass

    def _fx_reorder_commit(self, kw: dict) -> None:
        ch = kw.get("ch")
        origin = self._reorder_origin
        new = self.state.channels.index(ch) if ch in self.state.channels else origin
        self._leave_reorder()
        if origin is None or new is None or new == origin:
            return
        view = _prefs.move(ch, new - origin, self._provider, view_ids=None)
        if view is None:
            _log("TV_WINDOW reorder save failed ch=%s" % ch, warning=True)
            self._hint("Pořadí se nepodařilo uložit — zkus to znovu.")
            if self._view is not None:
                self.state.set_channels(self._view.visible)
            return
        self._view = view
        self._snapshot_rev()
        self.state.set_channels(view.visible)
        if self._list_ids != self._ids_for(self._filter or F_ALL):
            self._refill_filtered(animate=False)
        else:
            self._apply_now()
        self._select_row(ch)
        self._hint("%s je teď na %s. místě" % (self._name(ch), view.number_of(ch) or new + 1))

    def _fx_reorder_cancel(self, kw: dict) -> None:
        for idx, cid in enumerate(self.state.channels):
            if idx < len(self._reorder_ids) and self._reorder_ids[idx] != cid:
                self._reorder_ids[idx] = cid
                self._apply_row(LIST_REORDER, idx, self._row_fields(cid, number=idx + 1))
        self._leave_reorder()
        self._select_row(kw.get("ch"))

    def _leave_reorder(self) -> None:
        self._reorder_origin = None
        self._set("tv_reorder", "")
        self._focus(LIST)

    # ── odchod ──────────────────────────────────────────────────────────────────────────────────────────────────────
    def _fx_leave(self, _kw: dict) -> None:
        self._leave("back")

    def _leave(self, reason: str, fast: bool = False) -> None:
        """Odchod z Televize: černá vrstva přes video (`window` odchod 270 ms) → stop → konec relace → ztlumení zpět →
        zavřít okno. Nikdy dvakrát; nic dalšího se už neladí (`_leaving`)."""
        if self._leaving:
            return
        self._leaving = True
        _log("TV_WINDOW leave reason=%s ch=%s" % (reason, self._playing[0] if self._playing else "-"))
        self._set("tv_leaving", "1")
        csids = [c for c in ((self._playing or ("", ""))[1], (self._opening or ("", "", 0.0))[1]) if c]
        delay = 0.0 if fast else _motion.ms("window", "out") / 1000.0
        self._leave_thread = self._spawn("RMTvLeave", lambda: self._leave_finish(csids, reason, delay))

    def _leave_finish(self, csids: List[str], reason: str, delay: float) -> None:
        if delay > 0:
            self._wait(delay)
        with self._lock:
            self._expected_stops.update(csids)
            self._stop_player()
            for csid in dict.fromkeys(csids):
                self._end_session_async(csid, "tv_leave_" + reason)
            if self._mute is not None:
                try:
                    self._mute.leave()
                except Exception as exc:
                    _log("TV_WINDOW mute leave: %r" % (exc,), warning=True)
            self._stop.set()
        try:
            self.close()
        except Exception as exc:
            _log("TV_WINDOW close failed: %r" % (exc,), warning=True)

    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    #  Data: kanály, program, osobní pořadí — vše NA MÍSTĚ
    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    def _adopt_channels(self, rec: Optional[dict]) -> None:
        data = (rec or {}).get("data") or {}
        chans = [c for c in (data.get("channels") or []) if isinstance(c, dict) and _prefs.is_channel_id(c.get("id"))]
        self._provider = chans
        self._rows = {c["id"]: c for c in chans}
        self._bases = [b for b in (data.get("bases") or []) if isinstance(b, str)]
        self._categories = [c for c in (data.get("categories") or []) if isinstance(c, str)]
        if self._img_base not in self._bases:
            self._img_base = None
        self._view = _prefs.view(chans)

    def _probe_image_base(self) -> None:
        with self._lock:
            bases = list(self._bases)
        for base in bases:
            ok = _tv.health_probe(_tv.base_of(base))
            if ok:
                with self._lock:
                    self._img_base = base
                    self._probed[_tv.base_of(base)] = True
                    self._apply_now()                 # monogramy → loga, na místě
                return
        _log("TV_WINDOW image base unreachable bases=%d → monogramy" % len(bases))

    def _refresh_data(self, kind: str) -> None:
        """Obnova z Gate s ETagem (`richmovie_livetv_epg.refresh`); příští pokus podle `NOW_REFRESH_S` /
        `CHANNELS_REFRESH_S` i po selhání (výpadek nesmí vyrobit smyčku dotazů)."""
        status, rec = _epg.refresh(kind)
        with self._lock:
            self._data_running[kind] = False
            gap = _epg.NOW_REFRESH_S if kind == "now" else _epg.CHANNELS_REFRESH_S
            self._data_next[kind] = time.time() + gap
            if self._rm_closed:
                return
            if kind == "now":
                if rec is not None:
                    self._now_rec = rec
                if status == "updated":
                    self._apply_now()
                self._epg_wake_at = _epg.ends_soon(self._now_rec, self._list_ids or self._state_channels(), time.time())
            elif status == "updated" and rec is not None:
                self._ch_rec = rec
                self._adopt_channels(rec)
                self._reload_view(reason="channels")
            elif status == "failed" and not self._provider and self.state is not None:
                self._run(self.state.data_failed())   # prázdný panel ustoupí kartě s volbami — nikdy tichý odchod (W-1)
                self._show_msg_card(None, "Kanály se nepodařilo načíst",
                                    "Televize teď neodpovídá. Zkus to za chvilku.",
                                    [("Zkusit znovu", "reload"), ("Odejít z Televize", "leave")], window_only=True)
            self._set("tv_stale", self._stale_text())

    def _state_channels(self) -> List[str]:
        return list(self.state.channels) if self.state is not None else []

    def _stale_text(self) -> str:
        if not self._provider:
            return TEXT_LOADING
        return _epg.stale_label(self._now_rec, time.time())

    def _data_tick(self, now: float) -> None:
        wall = time.time()
        for kind in ("now", "channels"):
            wake = kind == "now" and self._epg_wake_at is not None and wall >= self._epg_wake_at
            if self._data_running[kind] or (wall < self._data_next[kind] and not wake):
                continue
            self._data_running[kind] = True
            if wake:
                self._epg_wake_at = None
            self._spawn("RMTv_" + kind, lambda k=kind: self._refresh_data(k))
        if now - self._progress_at >= PROGRESS_REFRESH_S:
            self._progress_at = now
            self._apply_now()

    def _reload_view(self, *, reason: str, refill: bool = True) -> None:
        """Nový pohled na kanály (osobní pořadí, ★, skryté, nové kanály poskytovatele). Automat dostane viditelný
        seznam; řádky se přepíší na místě, nebo — změnilo-li se SLOŽENÍ pohledu — znovu naplní (`_refill_filtered`).
        Během přesunu nic (pořadí drží automat) — změna se projeví při dalším otevření panelu."""
        if not self._provider:
            return
        if self.state is not None and self.state.layer == _st.REORDER:
            self._pending_flags = True
            return
        self._view = _prefs.view(self._provider)
        self._snapshot_rev()
        if self.state is not None:
            self.state.set_channels(self._view.visible)
        if refill and self._list_ids != self._ids_for(self._filter or F_ALL):
            self._refill_filtered(animate=self.state is not None and self.state.layer == _st.PANEL)
            if self.state is not None and self.state.layer == _st.PANEL:
                self._select_row(self._focus_cid or self.state.current or self.state.panel_focus)
        else:
            self._apply_now()
        _log("TV_WINDOW view reason=%s visible=%d fav=%d hidden=%d" % (
            reason, len(self._view.visible), len(self._view.favorites), len(self._view.hidden)))

    def _snapshot_rev(self) -> None:
        """Vlastní změna osobního seznamu zvedla revizi domény `tv` → nepřestavovat znovu po vlastním zápisu."""
        try:
            self._rm_rev_snap = _uc.data_rev_snapshot()
        except Exception:
            pass

    def _name(self, cid: Optional[str]) -> str:
        if not cid:
            return ""
        return str((self._rows.get(cid) or {}).get("name") or cid)

    def _number(self, cid: Optional[str]) -> str:
        n = self._view.number_of(cid) if (self._view and cid) else None
        return str(n) if n else ""

    def _image(self, path: Optional[str]) -> str:
        return _tv.image_url(self._bases, path, self._img_base) if (path and self._img_base) else ""

    def _logo(self, cid: Optional[str], size: int) -> str:
        if not cid or not self._img_base:
            return ""
        return _tv.image_url(self._bases, (self._rows.get(cid) or {}).get("logo_path"), self._img_base, size=size)

    def _set_logo_props(self, prefix: str, cid: Optional[str], size: int) -> None:
        letters, color = _tv.monogram(self._name(cid), cid or "")
        self._set(prefix + "_logo", self._logo(cid, size))
        self._set(prefix + "_mono", letters if cid else "")
        self._set(prefix + "_mono_bg", MONO_COLORS[color % len(MONO_COLORS)])

    def _row_fields(self, cid: str, number: Optional[int] = None) -> dict:
        """Vše, co řádek kanálu ukazuje — porovnává se s tím, co v řádku je (mění se jen rozdíly)."""
        now_dt = _epg.server_now(self._now_rec, time.time())
        cur = _epg.now_of(self._now_rec, cid).get("current")
        letters, color = _tv.monogram(self._name(cid), cid)
        hidden = self._is_hidden(cid)
        playing = bool(self._playing and self._playing[0] == cid)
        num = number if number is not None else (self._view.number_of(cid) if self._view else None)
        frac = _tv.progress(cur, now_dt)
        return {
            "label": self._name(cid),
            "props": {"cid": cid, "num": str(num or ""), "mono": letters,
                      "mono_bg": MONO_COLORS[color % len(MONO_COLORS)], "fav": "1" if self._is_fav(cid) else "",
                      "hidden": "1" if hidden else "",
                      "badge": "Skrytý · OK = vrátit" if hidden else ("● hraje" if playing else ""),
                      "title": (cur or {}).get("title") or "", "end": _clock((cur or {}).get("end"))},
            "thumb": self._logo(cid, 256),
            "card": self._card_image(cid),                     # Kodi ho přednačte (`preloaditems`), karta hned
            "pct": int(round(frac * 1000)) if frac is not None else 0,
        }

    def _apply_row(self, list_id: int, index: int, fields: dict) -> None:
        """Přepis JEDNOHO řádku na místě — jen hodnoty, které se změnily (`getListItem(i).setLabel/setProperty`,
        průběh `InfoTagVideo.setResumePoint` → `ListItem.PercentPlayed`)."""
        lst = self._ctl(list_id)
        if lst is None:
            return
        cache = self._row_cache.setdefault(list_id, {})
        old = cache.get(index) or {"props": {}}
        try:
            li = lst.getListItem(index)
        except Exception:
            return
        if fields["label"] != old.get("label"):
            li.setLabel(fields["label"])
        for k, v in fields["props"].items():
            if old["props"].get(k) != v:
                li.setProperty(k, v)
        if fields["thumb"] != old.get("thumb") or fields["card"] != old.get("card"):
            li.setArt(_row_art(fields))
        if fields["pct"] != old.get("pct"):
            li.getVideoInfoTag().setResumePoint(float(fields["pct"]), 1000.0)
        cache[index] = fields

    def _apply_now(self) -> None:
        """Nový program / plynutí času / loga: dotčené řádky, lišta, náhled a karta čísla NA MÍSTĚ (lint L8)."""
        for i, cid in enumerate(self._list_ids):
            self._apply_row(LIST, i, self._row_fields(cid))
        if self.state is not None and self.state.layer == _st.REORDER:
            for i, cid in enumerate(self._reorder_ids):
                self._apply_row(LIST_REORDER, i, self._row_fields(cid, number=i + 1))
        if self.state is not None and self._get("tv_bar") == "1":
            self._fill_bar(self.state.preselect or self.state.current)
        if self._preview_cid and self._get("tv_preview") == "1":
            cid, self._preview_cid = self._preview_cid, ""        # obsah na místě (bez nového rozložení karty)
            self._show_preview(cid)

    def _refresh_row(self, cid: str) -> None:
        if cid in self._list_ids:
            i = self._list_ids.index(cid)
            self._apply_row(LIST, i, self._row_fields(cid))

    def _mark_playing_rows(self) -> None:
        """„● hraje“ se přesune na nový kanál — přepíší se jen dotčené řádky."""
        cache = self._row_cache.get(LIST) or {}
        for i, cid in enumerate(self._list_ids):
            fields = self._row_fields(cid)
            if (cache.get(i) or {"props": {}})["props"].get("badge") != fields["props"]["badge"]:
                self._apply_row(LIST, i, fields)

    def _note_watched(self, now: float) -> None:
        """Poslední / předchozí kanál profilu až po `LAST_MIN_WATCH_S` sledování (listování frontu nezaplaví)."""
        if self._playing is None or self._watched_noted == self._playing[0]:
            return
        watched = now - self._playing_since
        if watched >= _prefs.LAST_MIN_WATCH_S:
            self._watched_noted = self._playing[0]
            if _prefs.note_watched(self._playing[0], watched):
                self._snapshot_rev()

    def _show_first_hint(self, now: float) -> None:
        """Jednou na ZAŘÍZENÍ (ne per profil): jak se Televize ovládá — značka `addon_data/live/tv_hint_seen.json`."""
        try:
            import richmovie_atomic as _atomic
            import richmovie_paths as _paths
            path = os.path.join(str(_paths.addon_data_dir()), "live", "tv_hint_seen.json")
            seen, _state = _atomic.read_json(path, None, name="tv_hint_seen", expected_type=dict)
            if seen:
                return
            os.makedirs(os.path.dirname(path), exist_ok=True)
            if not _atomic.write_json(path, {"v": 1, "at": time.time()}):
                return
        except Exception as exc:
            _log("TV_WINDOW first hint marker: %r" % (exc,), warning=True)
            return
        self._set("tv_hint", FIRST_HINT_TEXT)
        self._hint_until = now + FIRST_HINT_S

    def _hint(self, text: str) -> None:
        self._set("tv_hint", text)
        self._hint_until = self._now() + HINT_S

    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    #  JEDINÁ místa, která seznamy okna plní znovu (lint L8): složení pohledu a vstup do přesunu
    # ════════════════════════════════════════════════════════════════════════════════════════════════════════════════
    def _refill_filtered(self, animate: bool = False) -> None:
        """Čipy, abeceda a seznam kanálů pro aktuální filtr — změna SLOŽENÍ pohledu (filtr, hledání, nové pořadí,
        ★ / skryté při dalším otevření, nové kanály), ne obnova dat. V otevřeném panelu se obsah mění prolnutím
        (`tv_list_swap` → podmíněné prolnutí v XML), ne skokem."""
        if animate:
            self._set("tv_list_swap", "1")
            self._wait(_motion.ms("fade") / 1000.0)
        chips = self._chips()
        flt = self._filter or F_ALL
        if not flt.startswith(F_SEARCH) and flt not in [k for k, _l in chips]:
            flt = self._filter = F_ALL
        chip_ctl = self._ctl(CHIPS)
        if chip_ctl is not None:
            chip_ctl.reset()
            items = []
            for key, label in chips:
                li = xbmcgui.ListItem(label, offscreen=True)
                li.setProperty("key", key)
                li.setProperty("active", "1" if key == flt else "")
                items.append(li)
            chip_ctl.addItems(items)
        ids = self._ids_for(flt)
        lst = self._ctl(LIST)
        cache: Dict[int, dict] = {}
        if lst is not None:
            lst.reset()
            items = []
            for cid in ids:
                fields = self._row_fields(cid)
                li = xbmcgui.ListItem(fields["label"], offscreen=True)   # mimo GUI zámek, pak addItems
                for k, v in fields["props"].items():
                    li.setProperty(k, v)
                li.setArt(_row_art(fields))
                li.getVideoInfoTag().setResumePoint(float(fields["pct"]), 1000.0)
                cache[len(items)] = fields
                items.append(li)
            lst.addItems(items)
        self._row_cache[LIST] = cache
        self._list_ids = ids
        alpha = self._ctl(ALPHA)
        if alpha is not None:
            alpha.reset()
            letters: List[str] = []
            for cid in ids:
                letter = initial_of(self._name(cid))
                if letter and letter not in letters:
                    letters.append(letter)
            alpha.addItems([xbmcgui.ListItem(c, offscreen=True) for c in letters])
        if animate:
            self._set("tv_list_swap", "")
        _log("TV_WINDOW list filter=%s rows=%d" % (flt, len(ids)))
        self._ensure_panel_focus()                    # prázdný / nový seznam v panelu: fokus má cestu (4.2.1)

    def _enter_reorder(self, ch: Optional[str]) -> None:
        """Vstup do přesunu: dvojče seznamu = celý viditelný seznam (čísla = pořadí, R-3), držený řádek vybraný,
        fokus na držáku (▲▼ jdou automatu, seznam jen ukazuje — pevná pozice fokusu, plynulý `scrolltime`)."""
        chans = list(self.state.channels)
        if ch not in chans:
            return
        lst = self._ctl(LIST_REORDER)
        cache: Dict[int, dict] = {}
        if lst is not None:
            lst.reset()
            items = []
            for i, cid in enumerate(chans):
                fields = self._row_fields(cid, number=i + 1)
                li = xbmcgui.ListItem(fields["label"], offscreen=True)   # mimo GUI zámek, pak addItems
                for k, v in fields["props"].items():
                    li.setProperty(k, v)
                li.setArt(_row_art(fields))
                li.getVideoInfoTag().setResumePoint(float(fields["pct"]), 1000.0)
                cache[i] = fields
                items.append(li)
            lst.addItems(items)
            try:
                lst.selectItem(chans.index(ch))
            except Exception:
                pass
        self._row_cache[LIST_REORDER] = cache
        self._reorder_ids = chans
        self._reorder_origin = chans.index(ch)
        self._set("tv_preview", "")
        self._preview_cid = None
        self._set("tv_reorder", "1")
        self._focus(FOCUS_REORDER)


# ════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
#  Vstup z routeru
# ════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
def open_window(channel: Optional[str] = None) -> None:
    """Router: `live_home` → okno (poslední kanál profilu / panel), `live_play&ch=` → okno naladěné na kanál.
    Oprávnění jen přes SSOT `richmovie_gate.is_live_tv_allowed` (fail-closed, lint L4). Blokuje do zavření okna."""
    import richmovie_gate as _gate
    if not _gate.is_live_tv_allowed():
        _log("TV_WINDOW not allowed", warning=True)
        import richmovie_feedback as _fb
        _fb.warn(_tv.MESSAGES["feature_not_allowed"][0], heading="Televize")
        return
    win = TvWindow(XML_FILE, xbmcaddon.Addon().getAddonInfo("path"), "default", "1080i")
    win.start_channel = channel if (channel and _prefs.is_channel_id(channel)) else None
    try:
        win.doModal()
    finally:
        win.shutdown()
        del win
