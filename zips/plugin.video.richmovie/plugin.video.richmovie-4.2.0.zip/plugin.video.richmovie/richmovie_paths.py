# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – SSOT cest k datům doplňku (3.5.134, profily „Kdo se dívá?")
───────────────────────────────────────────────────────────────────────────────
Do 3.5.133 si každý modul skládal `special://profile/addon_data/<id>` sám
(20+ kopií, některé cachované per proces). Profily vyžadují, aby OSOBNÍ soubory
(historie, Pokračovat, zhlédnuté, Moje listy, …) ležely per profil, zatímco
ÚČTOVÉ (cache TMDb, Gate cache, nastavení, telemetrický buffer) zůstaly společné.

Dvě funkce, jeden zdroj pravdy:
  • `addon_data_dir()`  – kořen dat účtu (dnešní adresář; ÚČTOVÉ soubory)
  • `personal_dir()`    – adresář aktuálního profilu:
        single / bez profilů  → kořen (identické se 3.5.133 → 15 uživatelů beze změny)
        multi, profil <id>    → `<kořen>/profiles/<id>/`
        multi, Host           → `<kořen>/profiles/guest/` (maže se při každém výběru Hosta)
  • `personal_path(name)` – `personal_dir()/name`; `name` MUSÍ být v `PERSONAL_FILES`
    (lint v harnessu hlídá, že se osobní soubory neotvírají jinudy).

Proces služby (`service_nextup`) NESMÍ cachovat výsledek — aktuální profil se čte
při každém volání z Window property (SSOT `richmovie_profile`), takže přepnutí
v pluginu se projeví okamžitě.
═══════════════════════════════════════════════════════════════════════════════
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import xbmcaddon
import xbmcvfs

ADDON_ID = "plugin.video.richmovie"

# Osobní (per profil) soubory — jediný seznam v celém doplňku.
PERSONAL_FILES = frozenset({
    "history.json",             # historie hledání
    "watch_history.json",       # historie sledování (zdroj Naposledy sledované seriály)
    "continue_watching.json",   # Pokračovat
    "watched_movies.json",      # zelené ✔ filmy
    "watched_episodes.json",    # zelené ✔ díly
    "my_list.json",             # Moje listy
    "title_prefs.json",         # preference audia/titulků per titul
    "youtube_profile.json",     # YouTube doporučení podle historie
    "nextup_cache.json",        # Next-Up stav
    "ai_dismissed.json",        # „nezajímá mě" v custom UI
    "title_ratings.json",       # hodnocení 1–5★ v RichMovie (3.5.152, kolekce `ratings`)
    "tip_state.json",           # stav osobních hlášek
    "rail_series_posters.json", # rail Naposledy sledované (custom UI)
    "rail_ai_cache.json",       # rail AI doporučení (custom UI)
    "pending_searches.json",    # rozpracované hledání (telemetrie klik/opuštění)
    "pending_state.json",       # fronta stavu profilu pro Gate (Pokračovat/✔ napříč zařízeními, Φ3b)
    "state_sync.json",          # kurzor deltového pullu stavu profilu (Φ3b)
    "pending_items.json",       # fronta osobních kolekcí pro Gate (3.5.144, mig 0027)
    "items_sync.json",          # kurzor deltového pullu kolekcí + značka seedu (3.5.144)
    "stream_profiles.json",     # verze streamu per seriál pro výběr dalšího dílu (3.5.151, lokální — D5)
    "tv_channels.json",         # osobní seznam kanálů Televize: pořadí, ★, skryté, poslední (F4, kolekce `tv_channels`)
})

PROFILES_SUBDIR = "profiles"
GUEST_DIRNAME = "guest"

_ROOT_CACHE: Optional[Path] = None   # kořen účtu je stabilní per proces


def addon_data_dir() -> Path:
    """Kořen dat účtu (`special://profile/addon_data/plugin.video.richmovie`)."""
    global _ROOT_CACHE
    if _ROOT_CACHE is None:
        try:
            addon_id = xbmcaddon.Addon().getAddonInfo("id") or ADDON_ID
        except Exception:
            addon_id = ADDON_ID
        root = Path(xbmcvfs.translatePath("special://profile/addon_data/%s" % addon_id))
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        _ROOT_CACHE = root
    return _ROOT_CACHE


def profile_subdir(profile_key: str) -> Path:
    """`<kořen>/profiles/<key>` — key = id profilu nebo `guest`."""
    return addon_data_dir() / PROFILES_SUBDIR / str(profile_key)


def personal_dir(*, create: bool = True) -> Path:
    """Adresář osobních dat AKTUÁLNÍHO profilu (viz hlavička). Bez cache."""
    try:
        import richmovie_profile
        key = richmovie_profile.personal_dir_key()
    except Exception:
        key = None
    if not key:
        return addon_data_dir()
    d = profile_subdir(key)
    if create:
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return d


def personal_path(name: str) -> Path:
    """Cesta osobního souboru aktuálního profilu. `name` musí být v PERSONAL_FILES —
    cizí jméno je programátorská chyba (nikoli runtime stav), proto ValueError."""
    if name not in PERSONAL_FILES:
        raise ValueError("richmovie_paths.personal_path: %r není v PERSONAL_FILES" % name)
    return personal_dir() / name


def account_path(name: str) -> Path:
    """Cesta ÚČTOVÉHO souboru (cache, stav účtu, buffer telemetrie) — vždy kořen."""
    return addon_data_dir() / name


def personal_files_present(directory: Path) -> list:
    """Které osobní soubory v adresáři existují (migrace single → multi)."""
    out = []
    for name in sorted(PERSONAL_FILES):
        p = Path(directory) / name
        if p.is_file():
            out.append(name)
    return out


def is_personal_name(name: str) -> bool:
    return os.path.basename(name) in PERSONAL_FILES


LOCK_STALE_S = 10.0   # krádež zámku po 10 s (pomalé TV boxy)


def personal_lock(name: str, *, wait_s: Optional[float] = None):
    """CROSS-PROCESS zámek nad osobním souborem (`<soubor>.lock`, `richmovie_atomic.FileLock`).
    Read-modify-write téhož souboru dělá plugin (nový interpret na každou invokaci) i služba
    (sloučení z Gate v `richmovie_profile_items.apply_remote`, CW ve `_save_cw_position`) →
    bez zámku lost update. Jeden zámek per soubor, není reentrantní — mutátory se navzájem
    nevolají. Best-effort (po timeoutu pokračuje bez zámku; zápis sám je atomický).
    `wait_s` = delší čekání pro zapisovatele, jehož RMW trvá dlouho (dávka ✔, 3.5.151); výchozí 1 s."""
    import richmovie_atomic as _atomic
    return _atomic.FileLock(str(personal_path(name)) + ".lock", stale_s=LOCK_STALE_S, wait_s=wait_s)
