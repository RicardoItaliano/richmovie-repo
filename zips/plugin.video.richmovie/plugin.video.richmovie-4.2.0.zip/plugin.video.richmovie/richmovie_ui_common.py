# -*- coding: utf-8 -*-
"""RichMovie 4.0 — UI SSOT (richmovie_ui_common).

DRY/SSOT pro VŠECHNA custom WindowXMLDialog okna (Home/Streams/Detail/Grid/Hub/Episodes).
Sdílené: TMDb image URL, Estoril barvy, OVĚŘENÉ názvy fontů (Estuary Default fontset),
plugin-URL builder. Nová okna importují tohle → žádná duplikace, žádný font-bug.

⚠ FONTY: Estuary NEMÁ font16/18/20! Používej JEN názvy z RM_FONT_* (ověřeno proti
skin.estuary/xml/Font.xml: font10/12/13/14/23_narrow/25_narrow/27/32/37/45/60 +
font20_title/25_title/30_title/32_title/36_title/40_title/45_title).
"""
from __future__ import annotations

import urllib.parse
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)

# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.83): chyby UI helperů (notify_error,
# fetch_async, play_picker_first) přepnuty na ROUTOVANÝ logger → tečou na NAS.
# Dynamický {tag} volajícího zůstává v textu zprávy (kodi.log greppable).
# Fallback = přímý xbmc.log (import lokálně — modul xbmc na top-levelu nemá).
try:
    from richmovie_logging import make_legacy_logger as _uic_make_legacy_logger
    _log = _uic_make_legacy_logger("richmovie.ui.common", "RichMovie/UI")
except Exception:
    def _log(msg, level=None, *, context=None):
        try:
            import xbmc as _x
            _x.log("[RichMovie/UI] " + str(msg),
                   _x.LOGWARNING if level is None else level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"
_BASE = f"plugin://{_ADDON_ID}/"
_TMDB = "https://image.tmdb.org/t/p/"

# ── Estoril Blau paleta (ARGB hex) ──────────────────────────────────────────
RM_CARBON = "FF0A0C10"      # base pozadí
RM_PANEL = "FF0B1018"       # tmavý panel
RM_BLUE = "FF0E63C8"        # accent (Estoril base)
RM_BLUE_BRIGHT = "FF2E8BF5"  # jasná (selected fill)
RM_HIGHLIGHT = "FF3E9BF0"   # highlight / focus accent
RM_WHITE = "FFF2F5FA"       # text primární
RM_GREY = "FF9AA4B2"        # text sekundární
RM_TEXT_DIM = "FFCBD3DF"    # text na kartách
RM_GREEN = "FF2E7D32"       # CZ DAB pill

# ── OVĚŘENÉ fonty (Estuary Default fontset) — JEN tyto! ─────────────────────
RM_FONT_TITLE = "font37"    # velký nadpis (hero/detail/grid)
RM_FONT_TITLE_BOLD = "font36_title"  # tučný velký nadpis
RM_FONT_HEAD = "font27"     # sekce / rail header / focus emphasis
RM_FONT_BODY = "font14"     # běžný text (33px)
RM_FONT_SMALL = "font13"    # menší (30px)
RM_FONT_TINY = "font12"     # nejmenší (25px)


def img(path, size="w342") -> str:
    """SSOT TMDb image URL. Prázdné → ''; plné http URL beze změny."""
    if not path:
        return ""
    p = str(path)
    if p.startswith("http"):
        return p
    if p.startswith("/"):
        return f"{_TMDB}{size}{p}"
    return p


def url(**qs) -> str:
    """Plugin URL: ?action=...&... (URL-encoded)."""
    return _BASE + "?" + urllib.parse.urlencode({k: v for k, v in qs.items() if v not in (None, "")})


def cw_key_of(item) -> str:
    """Stabilní klíč položky Pokračovat (SSOT `richmovie_state_sync.cw_key`; '' = položka bez TMDb)."""
    try:
        import richmovie_state_sync as _ss
        return _ss.cw_key(item) or ""
    except Exception:
        return ""


def cw_link(index, key: str = "", restart: bool = False) -> str:
    """Odkaz na položku Pokračovat (4.0.3, cross-check Codex C3): klíč je pravda, index jen pro položky bez klíče
    a staré odkazy — pohled se mezi vykreslením a klikem může přeřadit (stažení z Gate)."""
    return url(action="continue_watching", cw_index=str(index), cw_key=key or "", restart="1" if restart else "")


def profile_dir() -> str:
    import xbmcvfs
    return xbmcvfs.translatePath(f"special://profile/addon_data/{_ADDON_ID}/")


def personal_dir() -> str:
    """Adresář OSOBNÍCH dat aktuálního profilu (3.5.134) — SSOT richmovie_paths."""
    import richmovie_paths
    return str(richmovie_paths.personal_dir())


def data_path(name: str) -> str:
    """Cesta k souboru podle jeho typu: osobní (PERSONAL_FILES) → profil, jinak účet."""
    import os
    import richmovie_paths
    if richmovie_paths.is_personal_name(name):
        return str(richmovie_paths.personal_path(name))
    return os.path.join(profile_dir(), name)


def load_json(name):
    import json
    try:
        with open(data_path(name), encoding="utf-8") as fh:
            return json.load(fh) or {}
    except Exception:
        return {}


# ═════════════════════════════════════════════════════════════════════════════
# Φ-R1 (2026-06-12) — SSOT responzivita: focus fallback, async fetch, busy
# feedback, viditelné chyby, Stream-picker token/ping lifecycle.
# ═════════════════════════════════════════════════════════════════════════════

def dedup_media(items):
    """SSOT dedup mediálních položek (AI tipy, feedy) — Netflix nikdy neukáže
    stejný titul 2× v jednom railu.

    Klíč: (tmdb_id, kind) pokud tmdb_id existuje, jinak (title lowercase, year).
    Zachovává pořadí (první výskyt = nejvyšší ranking vyhrává).
    """
    seen = set()
    out = []
    for it in (items or []):
        tid = str(it.get("tmdb_id") or it.get("id") or "").strip()
        kind = str(it.get("kind") or it.get("media_type") or "").strip().lower()
        if tid:
            key = ("id", tid, kind)
        else:
            title = str(it.get("title_cs") or it.get("title") or it.get("name") or "").strip().lower()
            key = ("t", title, str(it.get("year") or ""))
            if not title:
                out.append(it)  # bez identity nedokážeme dedupovat — ponech
                continue
        if key in seen:
            continue
        seen.add(key)
        out.append(it)
    return out


DEVICE_LATCH_PROP = "richmovie.device_latch"


def device_observe_action(action_id):
    """Runtime latch typu vstupu dle reálné akce (P1-e vrstvená detekce).

    Okna volají z onAction. Myš (ACTION_MOUSE_* 100-109) → latch 'pc';
    dotyk (ACTION_TOUCH_* 401-411) → 'touch'. Latch přežívá v Window(10000),
    `device_mode()` ho čte. Heuristika reaguje na to, jak uživatel REÁLNĚ ovládá,
    ne na nespolehlivý statický odhad. Best-effort."""
    import xbmcgui
    try:
        aid = int(action_id)
    except Exception:
        return
    latch = None
    if 100 <= aid <= 109:        # ACTION_MOUSE_*
        latch = "pc"
    elif 401 <= aid <= 411:      # ACTION_TOUCH_* / gesture
        latch = "touch"
    if latch:
        try:
            xbmcgui.Window(10000).setProperty(DEVICE_LATCH_PROP, latch)
        except Exception:
            pass


def device_mode():
    """SSOT detekce zařízení: 'tv' (ovladač) | 'pc' (myš/klávesnice) | 'touch'.

    Priorita: (1) manuální override setting rm_device_mode (tv/pc/touch);
    (2) runtime latch z reálného vstupu (device_observe_action); (3) platform
    heuristika; (4) default 'tv' (bezpečné pro čitelnost z gauče)."""
    try:
        import richmovie_settings as _rm_settings   # SSOT (3.5.124)
        sel = (_rm_settings.get_str("rm_device_mode") or "auto").lower()
        if sel in ("tv", "pc", "touch"):
            return sel
    except Exception:
        pass
    try:
        import xbmcgui
        latch = (xbmcgui.Window(10000).getProperty(DEVICE_LATCH_PROP) or "").strip().lower()
        if latch in ("tv", "pc", "touch"):
            return latch
    except Exception:
        pass
    try:
        import xbmc
        # iOS/dotykové platformy → touch; jinak (vč. Android TV, desktop HTPC,
        # set-top boxy) ponech tv-first — latch upraví po prvním vstupu myší.
        if xbmc.getCondVisibility("System.Platform.IOS"):
            return "touch"
    except Exception:
        pass
    return "tv"


def focus_first(window, control_ids):
    """Zaměř první použitelný control z kandidátů (v pořadí priority).

    Prázdný container (list/panel se size()==0) se přeskočí — focus na prázdném
    listu je pro uživatele neviditelný = "mrtvá tlačítka". Buttony (bez .size())
    se zkouší rovnou. Ověřuje se přes getFocusId(); skryté controly selžou tiše.
    Vrací id, které se povedlo zaměřit, jinak None.
    """
    for cid in control_ids:
        try:
            ctl = window.getControl(cid)
        except Exception:
            continue
        try:
            size_fn = getattr(ctl, "size", None)
            if callable(size_fn) and int(size_fn()) <= 0:
                continue
        except Exception:
            pass
        try:
            window.setFocusId(cid)
            if window.getFocusId() == cid:
                return cid
        except Exception:
            continue
    return None


def notify_error(message, log_tag="UI"):
    """Chyba akce MUSÍ být pro uživatele viditelná (žádné tiché spolknutí).

    Best-effort: notifikace + WARNING log; sama nikdy nevyhodí.
    """
    import xbmc
    try:
        _log(f"[{log_tag}] {message}", xbmc.LOGWARNING)
    except Exception:
        pass
    try:
        import xbmcgui
        _rm_notif(str(message), xbmcgui.NOTIFICATION_WARNING, 4000, "RichMovie", sound=False)
    except Exception:
        pass






def goto_container(plugin_url, parent_action="", parent_params=None):
    """Přechod na klasickou Kodi directory destinaci z custom okna.

    Custom okna se stackují (Home zůstává pod Grid/Detail/Hub) — Container.Update
    by aktualizoval directory NEVIDITELNĚ pod dialogy. Kanonický vzor: zavřít
    celý dialog stack a otevřít Videos window s cílovou directory (funguje
    z libovolného kontextu, i z Kodi home screen).

    Φ1 (2026-07-06, audit A04/A05): `parent_action`/`parent_params` = routa okna,
    ze kterého se odchází. Breadcrumb „‹ Zpět do RichMovie" pak vede PŘESNĚ tam
    (např. zpět do Hubu Zdroje), ne paušálně na home_window — dřív i „správná"
    cesta zpět přeskočila úroveň.
    """
    import xbmc
    import xbmcgui
    try:
        # marker pro plugin.py: directory list dostane breadcrumb „‹ Zpět do
        # RichMovie" (P0-1: stack se složí, tohle je cesta zpět do custom UI).
        # Hodnota = plugin URL rodičovské routy; legacy hodnota "1" = home_window
        # (zpětná kompatibilita — plugin.py obě varianty umí).
        back_url = url(action=parent_action, **(parent_params or {})) if parent_action else "1"
        xbmcgui.Window(10000).setProperty("richmovie.rm_from_hub", back_url)
    except Exception:
        pass
    nav_event("legacy_leaf", target=str(plugin_url)[:160],
              parent=parent_action)  # Φ6: úniky do legacy světa = klíčová metrika
    try:
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin(f"ActivateWindow(Videos,{plugin_url},return)")
    except Exception:
        pass


def fetch_async(window, fetch_fn, apply_fn, *, tag, on_error=None):
    """SSOT background fetch pro WindowXMLDialog (žádný sync HTTP v onInit).

    fetch_fn() běží v non-daemon vlákně (Kodi pravidlo — daemon HTTP vlákna
    zakázána, viz feedback_daemon_threads_kodi). apply_fn(result) se zavolá po
    doběhnutí, jen pokud okno stále žije (window._rm_closed nastavuje close()).
    Loading stav: window property "rm_loading_<tag>" = "1" po dobu fetche.
    on_error(exc): volitelný handler (default: property rm_error_<tag>=1).
    """
    import threading
    import xbmc

    try:
        window.setProperty(f"rm_loading_{tag}", "1")
    except Exception:
        pass

    def _worker():
        result = None
        err = None
        try:
            result = fetch_fn()
        except Exception as exc:
            err = exc
        if getattr(window, "_rm_closed", False):
            return  # okno už je pryč — nedotýkat se controls
        try:
            window.clearProperty(f"rm_loading_{tag}")
        except Exception:
            pass
        if err is not None:
            try:
                if on_error is not None:
                    on_error(err)
                else:
                    window.setProperty(f"rm_error_{tag}", "1")
                _log(f"[{tag}] fetch_async: {err}", xbmc.LOGWARNING)
            except Exception:
                pass
            return
        try:
            apply_fn(result)
        except Exception as exc:
            _log(f"[{tag}] fetch_async apply: {exc}", xbmc.LOGWARNING)

    threading.Thread(target=_worker, name=f"RMFetch-{tag}", daemon=False).start()


# ── Stream-picker lifecycle (token + heartbeat ping) ─────────────────────────
# Nahrazuje křehký boolean guard `richmovie.rm_streams_open` (incident: výjimka
# v doModal → property visela celou session → picker se už nikdy neotevřel).
# Liveness = čerstvost pingu, který picker obnovuje při každém poll ticku.

STREAMS_TOKEN_PROP = "richmovie.rm_streams_token"
STREAMS_PING_PROP = "richmovie.rm_streams_ping"
STREAMS_SEEN_PROP = "richmovie.rm_streams_seen_token"
STREAMS_PING_TTL_S = 10.0


def streams_new_token():
    """Vygeneruje token pro pár klik→search→picker a uloží ho do Window(10000)."""
    import uuid
    import xbmcgui
    token = uuid.uuid4().hex
    try:
        xbmcgui.Window(10000).setProperty(STREAMS_TOKEN_PROP, token)
    except Exception:
        pass
    return token


def streams_ping():
    """Heartbeat otevřeného pickeru (volá poll loop okna)."""
    import time
    import xbmcgui
    try:
        xbmcgui.Window(10000).setProperty(STREAMS_PING_PROP, str(time.time()))
    except Exception:
        pass


def streams_picker_alive(ttl_s=STREAMS_PING_TTL_S):
    """True, pokud picker okno žije (ping je čerstvý). Stale ping = mrtvý picker."""
    import time
    import xbmcgui
    try:
        raw = (xbmcgui.Window(10000).getProperty(STREAMS_PING_PROP) or "").strip()
        return bool(raw) and (time.time() - float(raw)) < float(ttl_s)
    except Exception:
        return False


def streams_mark_seen(token):
    """Picker si poznamená, že pro tento token UŽ byl otevřen. Když ho uživatel
    zavře dřív, než search doběhne, fallback v _list_releases ho NEvnucuje znovu."""
    import xbmcgui
    if not token:
        return
    try:
        xbmcgui.Window(10000).setProperty(STREAMS_SEEN_PROP, str(token))
    except Exception:
        pass


def streams_token_seen(token):
    """True, pokud pro daný token už picker existoval (uživatel ho zavřel sám)."""
    import xbmcgui
    if not token:
        return False
    try:
        return (xbmcgui.Window(10000).getProperty(STREAMS_SEEN_PROP) or "") == str(token)
    except Exception:
        return False


def play_picker_first(addon, *, action, poster="", title="", kind="", still="",
                      overview="", debounce=True, **params):
    """SSOT picker-first spuštění: otevři Stream-picker HNED + search na pozadí.

    Jedno místo pro vzor klik→token→RunPlugin(search)→open_streams. Click-sites
    (Detail/Episodes/Grid/Home/Continue-Watching) ho volají MÍSTO kopírování
    (dřív 4× duplikováno → TV varianta divergovala = root cause seriálového bugu).

    `poster`/`title` se předají pickeru → plakát/titulek se zobrazí OKAMŽITĚ
    (jinak svítí modrý glow fallback, dokud search nedoběhne). `params` = query
    parametry search akce (tmdb / tv_id+season+episode+ep_title …); `rm_token`
    se doplní automaticky a páruje klik s pickerem.

    `debounce=False` použij, když volající už `play_debounce()` provedl (např. CW
    klik na Home) — jinak by druhý debounce v okně 2 s klik spolkl. Vrací False
    při rychlém dvojkliku, jinak True.
    """
    import xbmc
    if debounce and not play_debounce():
        return False
    token = streams_new_token()
    try:
        xbmc.executebuiltin(f"RunPlugin({url(action=action, rm_token=token, **params)})")
    except Exception as exc:
        _log(f"play_picker_first RunPlugin: {exc}", xbmc.LOGWARNING)
    try:
        import richmovie_streams_window
        richmovie_streams_window.open_streams(
            addon, token=token, poster=poster, title=title,
            kind=kind, still=still, overview=overview)
    except Exception as exc:
        _log(f"play_picker_first open: {exc}", xbmc.LOGWARNING)
    return True


PLAY_DEBOUNCE_PROP = "richmovie.rm_play_ts"
RETURN_HOME_PROP = "richmovie.rm_return_home"      # legacy boolean (3.5.53–3.5.86)
RETURN_ROUTE_PROP = "richmovie.rm_return_route"    # Φ2 origin descriptor (JSON)
RETURN_DESC_TTL_S = 6 * 3600   # backstop: stale descriptor (>6 h) se zahodí
RETURN_FRESH_S = 15.0          # okno, ve kterém overwrite=False drží bohatší popis


def mark_play_from_ui(overwrite=True):
    """Označí, že přehrávání startuje z RM 4.0 custom UI (P0-3, rozšířeno Φ2).

    Φ2 (2026-07-06, audit A01/A06): místo booleanu se ukládá ORIGIN DESCRIPTOR
    {ts, routes=nav_snapshot()} — service_nextup po skončení/zastavení/chybě
    přehrávání replayne CELOU cestu (Home → Detail → Episodes…), ne paušálně
    jen Home. MUSÍ se volat PŘED Dialog.Close(all)/self.close() — zavírání
    oken NavStack vyprázdní (finally v open_* funkcích).

    `overwrite=False` použij v play akci plugin.py (continue_watching/play):
    click-site (okno) už mohl zapsat bohatší descriptor s plným stackem —
    čerstvý (<15 s) se nechává, jinak se zapíše aktuální (prázdný = Home).

    Legacy flag rm_return_home se setuje dál — starý service proces (do
    restartu Kodi) čte jen ten. Best-effort."""
    import json
    import time
    import xbmcgui
    try:
        win = xbmcgui.Window(10000)
        if not overwrite:
            raw = win.getProperty(RETURN_ROUTE_PROP) or ""
            if raw:
                try:
                    prev = json.loads(raw)
                    if (time.time() - float(prev.get("ts") or 0)) < RETURN_FRESH_S:
                        return  # čerstvý descriptor z click-site má přednost
                except Exception:
                    pass
        desc = {"ts": time.time(), "routes": nav_snapshot()}
        win.setProperty(RETURN_ROUTE_PROP, json.dumps(desc, ensure_ascii=False))
        win.setProperty(RETURN_HOME_PROP, "1")
        nav_event("play_start", depth=len(desc["routes"]))  # Φ6 telemetrie
    except Exception:
        pass


def consume_return_route():
    """Vrátí origin descriptor (dict) a smaže OBA flagy; None = nic k návratu.

    TTL backstop (Φ2): descriptor starší než RETURN_DESC_TTL_S se zahodí —
    kryje pád/kill, po kterém by stale flag vystřelil reopen u příštího videa
    (defekt nalezený auditem A01). Legacy boolean bez descriptoru → prázdné
    routes = návrat na Home (chování 3.5.86)."""
    import json
    import time
    import xbmcgui
    try:
        win = xbmcgui.Window(10000)
        raw = win.getProperty(RETURN_ROUTE_PROP) or ""
        legacy = (win.getProperty(RETURN_HOME_PROP) or "") == "1"
        if not raw and not legacy:
            return None
        win.clearProperty(RETURN_ROUTE_PROP)
        win.clearProperty(RETURN_HOME_PROP)
        desc = None
        if raw:
            try:
                desc = json.loads(raw)
            except Exception:
                desc = None
        if not isinstance(desc, dict):
            desc = {"ts": time.time(), "routes": []}
        if (time.time() - float(desc.get("ts") or 0)) > RETURN_DESC_TTL_S:
            return None
        return desc
    except Exception:
        return None


def return_route_pending():
    """True = přehrávání startovalo z RM UI a návrat ještě neproběhl.
    NEkonzumuje — pro fullscreen-exit watcher (Φ2, service_nextup)."""
    import xbmcgui
    try:
        win = xbmcgui.Window(10000)
        return bool((win.getProperty(RETURN_ROUTE_PROP) or "")
                    or (win.getProperty(RETURN_HOME_PROP) or "") == "1")
    except Exception:
        return False


def consume_return_home():
    """DEPRECATED (Φ2) — kompatibilita pro starý service proces do restartu
    Kodi. Nový kód používá consume_return_route(). Konzumuje oba flagy."""
    return consume_return_route() is not None


def replay_return_routes(desc, abort_check=None):
    """Φ2 SSOT replay: otevře okna z origin descriptoru (zdola nahoru).

    Home je VŽDY základ návratu — když snapshot Home neobsahuje (hero/CW klik
    zavřel Home před markem), doplní se. Sériově s pauzou: RunPlugin invokery
    jsou async a z-order určuje pořadí doModal — pauza drží deterministické
    vrstvení. Cap 4 okna (reálná hloubka ~3). Vrací počet otevřených oken."""
    import time
    import xbmc

    def _route_in_stack(route_url, since_len):
        """R2-P1-3: handshake — okno po otevření pushne svou routu do NavStacku
        (open_* před doModal), takže stack je přirozený ack kanál. Čekáme, až
        stack povyroste a obsahuje akci routy — teprve pak další RunPlugin
        (async invokery jinak závodí a z-order se na pomalém HW invertuje)."""
        try:
            stack = _nav_read()
            if len(stack) <= since_len:
                return False
            marker = route_url.split("action=", 1)[-1].split("&", 1)[0] if "action=" in route_url else ""
            if not marker:
                return True  # url_override routa (list okno) — stačí růst stacku
            return any(e.get("action") == marker for e in stack)
        except Exception:
            return True

    try:
        routes = list((desc or {}).get("routes") or [])
        urls = [u for u in (nav_route_url(r) for r in routes) if u]
        # R2-P2-8: dedup Home v CELÉM seznamu (ghost mohl nechat home hlouběji)
        # + Home vždy jako základ + cap AŽ PO insertu (slib „max 4" musí platit)
        urls = [u for u in urls if "action=home_window" not in u]
        urls.insert(0, url(action="home_window"))
        urls = urls[:4]
        for i, u in enumerate(urls):
            if abort_check is not None and abort_check():
                return i
            base_len = len(_nav_read())
            xbmc.executebuiltin(f"RunPlugin({u})")
            if i < len(urls) - 1:
                # handshake s timeoutem 2,5 s (fallback: pokračuj — lepší
                # potenciálně přehozené okno než žádné); NavStack vypnutý
                # killswitchem → deterministický fallback fixní pauzou
                if not nav_enabled():
                    xbmc.sleep(700)
                    continue
                deadline = time.time() + 2.5
                while time.time() < deadline:
                    if abort_check is not None and abort_check():
                        return i + 1
                    if _route_in_stack(u, base_len):
                        break
                    xbmc.sleep(100)
                xbmc.sleep(150)  # krátký dosed doModal po pushi
        nav_event("playback_return", depth=len(urls))  # Φ6 telemetrie
        return len(urls)
    except Exception as exc:
        _log(f"replay_return_routes: {exc}")
        return 0


def play_debounce(window_s=2.0):
    """SSOT anti-dvojklik pro spuštění přehrávání/pickeru (P0-2).

    Vrací True = klik PROJDE (a zapíše časové razítko); False = je to rychlý
    druhý klik (do window_s od minulého) → IGNORUJ. Brání tomu, aby netrpělivý
    dvojklik na ▶ Přehrát spustil dva paralelní searche + dva pickery.
    """
    import time
    import xbmcgui
    try:
        win = xbmcgui.Window(10000)
        last = (win.getProperty(PLAY_DEBOUNCE_PROP) or "").strip()
        now = time.time()
        if last and (now - float(last)) < float(window_s):
            return False
        win.setProperty(PLAY_DEBOUNCE_PROP, str(now))
        return True
    except Exception:
        return True  # při chybě raději pusť (best-effort, neblokovat uživatele)


# ═════════════════════════════════════════════════════════════════════════════
# Φ1 NavStack SSOT (2026-07-06, UX audit A01/A04/A05/A06)
#
# RM 4.0 dřív nemělo ŽÁDNÝ řízený navigační stack — „stack" byl emergentní
# vlastnost Kodi dialog z-orderu a trhal se na 4 místech (goto_container, play
# cesty, Home self-close, busy). Důsledek: po přehrávání/Back uživatel končil
# v holém Kodi místo tam, odkud přišel.
#
# NavStack = JSON seznam rout v Window(10000). Okna jsou plně route-addressable
# (RunPlugin ?action=rm_*&…), takže stack nedrží Python objekty, jen routy.
# Údržba je AUTOMATICKÁ v open_* funkcích oken: nav_push() před doModal(),
# nav_remove() ve finally — integrita zaručená i při výjimce, žádná disciplína
# per-okno není potřeba. Souběh: invokace jsou user-driven sériové; zápisy jsou
# best-effort (ztracený zápis = degradace na dnešní chování, nikdy crash).
#
# Killswitch: setting rm_navstack=false → všechny nav_* funkce jsou no-op
# (nav_debounce propouští) = přesně chování 3.5.86.
# ═════════════════════════════════════════════════════════════════════════════

NAV_STACK_PROP = "richmovie.nav_stack"
NAV_DEBOUNCE_PROP = "richmovie.rm_nav_ts"
NAV_STACK_MAX = 16   # hloubka reálné navigace je ~4; cap jen proti runaway


def nav_enabled():
    """Killswitch Φ1 — setting rm_navstack (default zapnuto, i když chybí)."""
    try:
        import richmovie_settings as _rm_settings   # SSOT (3.5.124)
        return _rm_settings.get_str("rm_navstack").lower() != "false"
    except Exception:
        return True


def _nav_read():
    import json
    import xbmcgui
    try:
        raw = xbmcgui.Window(10000).getProperty(NAV_STACK_PROP) or ""
        stack = json.loads(raw) if raw else []
        return stack if isinstance(stack, list) else []
    except Exception:
        return []


def _nav_write(stack):
    import json
    import xbmcgui
    try:
        xbmcgui.Window(10000).setProperty(
            NAV_STACK_PROP, json.dumps(stack[-NAV_STACK_MAX:], ensure_ascii=False))
    except Exception:
        pass


def nav_push(action="", params=None, url_override="", replay=True):
    """Zapíše routu otevíraného okna na vrchol stacku. Vrací id záznamu.

    `action`+`params` = rekonstruovatelná plugin routa (rm_grid&feed=…);
    `url_override` = hotové plugin URL pro okna bez akce (RmDir → open_list).
    `replay=False` = okno se do playback-replay snapshotu nezahrnuje
    (transientní okna — Stream-picker). Volá VÝHRADNĚ open_* funkce oken."""
    if not nav_enabled():
        return ""
    import uuid
    nav_id = uuid.uuid4().hex[:12]
    entry = {
        "id": nav_id,
        "action": str(action or ""),
        "params": {str(k): str(v) for k, v in (params or {}).items()
                   if v not in (None, "")},
        "url": str(url_override or ""),
        "replay": bool(replay),
    }
    # R2-P1-1 (re-audit 2026-07-06): Home je DEFINIČNĚ základ stacku — push
    # Home resetuje stack. Self-healing proti ghostům z read-modify-write race
    # při Dialog.Close(all,true) (všechny doModal finally běží paralelně a
    # souběžné nav_remove si vrací smazané záznamy; ghosty by se kumulovaly
    # a Φ2 replay by otevíral duplicitní okna).
    stack = [] if entry["action"] == "home_window" else _nav_read()
    stack.append(entry)
    _nav_write(stack)
    # Φ6 telemetrie — R2-P2-9: param klíče s prefixem p_ (kolize s pojmenovanými
    # kwargs action/depth by byla TypeError u VOLAJÍCÍHO = okno by se neotevřelo)
    nav_event("window_open", action=entry["action"] or entry["url"][:120],
              depth=len(stack),
              **{f"p_{k}": v for k, v in entry["params"].items()})
    return nav_id


def nav_update(nav_id, params):
    """Φ8 (R2-P2-6/7): okno s IN-PLACE stavem (Grid taby, Search dotaz) přepíše
    params své routy — playback replay pak vrátí AKTUÁLNÍ stav, ne stale kopii
    z okamžiku otevření. Best-effort (ztracený update = replay starého stavu)."""
    if not nav_id or not nav_enabled():
        return
    try:
        stack = _nav_read()
        changed = False
        for e in stack:
            if e.get("id") == nav_id:
                e["params"] = {str(k): str(v) for k, v in (params or {}).items()
                               if v not in (None, "")}
                changed = True
                break
        if changed:
            _nav_write(stack)
    except Exception:
        pass


def nav_remove(nav_id):
    """Odebere záznam podle id (kdekoli ve stacku — kryje out-of-order zánik
    při replace vzoru „RunPlugin(nové okno) + close starého")."""
    if not nav_id:
        return
    stack = _nav_read()
    pruned = [e for e in stack if e.get("id") != nav_id]
    if len(pruned) != len(stack):
        _nav_write(pruned)


def nav_snapshot():
    """Kopie replay-schopných rout (zdola nahoru) — pro playback return (Φ2).
    Snapshot se MUSÍ vzít PŘED Dialog.Close(all): zavírání oken stack vyprázdní
    (finally v open_* funkcích)."""
    out = []
    for e in _nav_read():
        if not e.get("replay"):
            continue
        if e.get("url") or e.get("action"):
            out.append({"action": e.get("action") or "",
                        "params": e.get("params") or {},
                        "url": e.get("url") or ""})
    return out


def nav_route_url(route):
    """Plugin URL routy ze snapshotu (url_override má přednost)."""
    if route.get("url"):
        return route["url"]
    if route.get("action"):
        return url(action=route["action"], **(route.get("params") or {}))
    return ""


def nav_clear():
    import xbmcgui
    try:
        xbmcgui.Window(10000).clearProperty(NAV_STACK_PROP)
    except Exception:
        pass


def nav_debounce(key, window_s=1.2):
    """SSOT anti-dvojklik pro NAVIGAČNÍ invokace (Φ1; parita s play_debounce).

    Dvojklik na dlaždici = dva RunPlugin invokery = dvě identická okna nad
    sebou (z-order pak mate Back). Klíč = akce+parametry: stejný cíl do
    window_s = duplikát → False (ignorovat); JINÝ cíl projde vždy. Trade-off:
    „otevři → Back → znovu otevři totéž" do 1,2 s se spolkne (vzácné, neškodné).
    """
    if not nav_enabled():
        return True
    import time
    import xbmcgui
    try:
        win = xbmcgui.Window(10000)
        raw = win.getProperty(NAV_DEBOUNCE_PROP) or ""
        now = time.time()
        if raw:
            last_key, _, last_ts = raw.rpartition("|")
            if last_key == str(key) and last_ts and (now - float(last_ts)) < float(window_s):
                return False
        win.setProperty(NAV_DEBOUNCE_PROP, f"{key}|{now}")
        return True
    except Exception:
        return True  # při chybě raději pusť (best-effort, neblokovat uživatele)


# ─── Φ5 (2026-07-06, audit A09): data revisions — invalidation kontrakt ─────
# RM 4.0 okna žila vzorem „naplň v onInit a nikdy nerefreshuj" — mutace
# z child oken (✔, Můj seznam, ai_seen, CW) se do otevřeného rodiče nikdy
# nepropsaly. Kontrakt: SSOT mutátory (richmovie_history, feed AI writer)
# bumpnou revision counter své domény ve Window(10000); RMNavMixin při
# uživatelském vstupu (throttle 1 s) porovná snapshot a zavolá
# window.on_data_changed(changed_domains) — okno refreshne JEN dirty raily.
# Žádné plošné reloady, žádný polling na pozadí.

# ─── Φ6 (2026-07-06, audit A07): nav-telemetrie SSOT ────────────────────────
# Breadcrumb TRACE loguje každou plugin invokaci (cíle kliků, per device_hash)
# — ale okna sama nelogovala NIC (Back/close, otevření, návraty). nav_event
# doplňuje strukturovaný event přes ROUTOVANÝ logger (INFO → Gate user_logs,
# context = JSONB) → heatmapa „kde uživatelé jsou a kudy odcházejí" jde
# postavit SQL dotazem bez Gate migrace (viz Temp\ux_audit_2026-07-06\A07).


def nav_event(event, **fields):
    """Strukturovaný navigační event (best-effort, nikdy neshodí UI).

    event: window_open | back | stop | legacy_leaf | play_start | playback_return
    fields: window, action, target, depth… (prázdné hodnoty se vynechají).
    device_mode se doplní automaticky."""
    try:
        import xbmc
        ctx = {"evt": "nav", "nav_event": str(event)}
        for k, v in fields.items():
            if v not in (None, ""):
                ctx[k] = v
        try:
            ctx.setdefault("device_mode", device_mode())
        except Exception:
            pass
        _log("NAV " + " ".join(
            f"{k}={ctx[k]}" for k in sorted(ctx) if k != "evt"),
            xbmc.LOGINFO, context=ctx)
    except Exception:
        pass


DATA_REV_DOMAINS = ("cw", "watched", "my_list", "ai", "watch", "search",   # 3.5.144: + historie sledování/hledání (sync z Gate)
                    "tv")   # F4: osobní seznam kanálů (`richmovie_livetv_prefs`) → okno Televize se obnoví na místě
_DATA_REV_PROP = "richmovie.rev.{}"


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_ui_common.py
# apply_offline_state  (vytvořeno: 08.08.2026 13:30 CEST, Europe/Prague – Φ5)
# ---------------------------------------------------------------------------- #
def apply_offline_state(window):
    """Nastaví na okně properties pro indikátor offline režimu (RM 4.0).

    Skin je čte jako `Window.Property(rm_offline)` (viditelnost) a
    `rm_offline_label` (text). Jedno místo pro všechna okna — kdyby si to každé
    dělalo po svém, rozešly by se texty i podmínka viditelnosti.

    Vizuál je záměrně tlumený: žádná červená, žádný vykřičník, žádný dialog.
    Výpadek internetu není chyba aplikace, je to stav, se kterým počítáme —
    obsah se mezitím renderuje z uložených dat (Φ4), takže uživatel může dál
    procházet a přehrávat. Pilulka jen vysvětluje, proč nejsou čerstvé novinky.

    Args:
        window: `xbmcgui.WindowXML(Dialog)` instance.

    Returns:
        True, když je addon offline (volající si podle toho může upravit chování).
    """
    offline = False
    try:
        import richmovie_netstate as _ns
        offline = bool(_ns.is_offline())
    except Exception:
        offline = False

    try:
        window.setProperty("rm_offline", "1" if offline else "")
        window.setProperty(
            "rm_offline_label",
            "Offline — uložená nabídka" if offline else "",
        )
    except Exception:
        pass
    return offline


def data_rev_bump(domain):
    """Zavýší revision counter domény (volají VÝHRADNĚ SSOT mutátory)."""
    import xbmcgui
    try:
        win = xbmcgui.Window(10000)
        prop = _DATA_REV_PROP.format(domain)
        cur = int(win.getProperty(prop) or 0)
        win.setProperty(prop, str(cur + 1))
    except Exception:
        pass


def data_rev_snapshot():
    """Aktuální revize všech domén: {domain: int}."""
    import xbmcgui
    out = {}
    try:
        win = xbmcgui.Window(10000)
        for d in DATA_REV_DOMAINS:
            try:
                out[d] = int(win.getProperty(_DATA_REV_PROP.format(d)) or 0)
            except Exception:
                out[d] = 0
    except Exception:
        pass
    return out


class RMNavMixin:
    """Φ1 — sdílený Back/akční kontrakt pro RM 4.0 okna (DRY).

    Dřív mělo všech 8 oken copy-paste onAction (device latch + Back →
    self.close()); odchylky (Episodes dvouúrovňový Back) žily v další kopii.
    Mixin drží společný dispatch, okna implementují jen template metody:

        on_back() -> bool          True = Back zkonzumován interně (okno zůstává)
        on_window_action(action)   okno-specifické akce (context menu, latch…)

    Dědění: ``class X(uc.RMNavMixin, xbmcgui.WindowXMLDialog)`` — mixin PRVNÍ
    (MRO: onAction z mixinu, zbytek z WindowXMLDialog). Kodi importy až za
    běhu — ui_common zůstává importovatelný mimo Kodi runtime.

    ACTION_STOP (13): dřív tichý no-op ve všech oknech. Nově: hraje-li něco,
    zastaví přehrávání (návrat řeší playback kontrakt v service_nextup);
    jinak zavře okno (parita s Back bez interních úrovní).
    """

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        # R3-P1-4 (re-audit 2026-07-06): baseline revizí UŽ při konstrukci okna
        # — dřív se brala až při prvním uživatelském vstupu, takže bump, který
        # doběhl mezi onInit a prvním stiskem (typicky AI SWR refresh), se
        # navždy spolkl a rail zůstal stale celou session.
        try:
            self._rm_rev_snap = data_rev_snapshot()
        except Exception:
            self._rm_rev_snap = None
        self._rm_rev_ts = 0.0

    def on_back(self):
        return False

    def on_window_action(self, action):
        return None

    def on_data_changed(self, domains):
        """Φ5 template: okno refreshne raily zasažených domén (viz data_rev_*).
        Default no-op — okna se přihlašují implementací."""
        return None

    def _rm_data_rev_tick(self):
        """Φ5: throttlovaná (1 s) kontrola revision counterů — první uživatelský
        vstup po změně dat v child okně spustí on_data_changed(dirty domén)."""
        import time
        now = time.time()
        last = getattr(self, "_rm_rev_ts", 0.0)
        if (now - last) < 1.0:
            return
        self._rm_rev_ts = now
        snap = data_rev_snapshot()
        prev = getattr(self, "_rm_rev_snap", None)
        self._rm_rev_snap = snap
        if prev is None:
            return  # první tick = jen baseline (onInit už naplnil čerstvě)
        changed = {d for d in DATA_REV_DOMAINS if snap.get(d, 0) != prev.get(d, 0)}
        if changed:
            self.on_data_changed(changed)

    def onAction(self, action):
        import xbmc
        import xbmcgui
        aid = action.getId()
        device_observe_action(aid)  # P1-e runtime device latch
        try:
            self._rm_data_rev_tick()  # Φ5 invalidation kontrakt
        except Exception:
            pass
        if aid in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            try:
                if self.on_back():
                    nav_event("back", window=type(self).__name__, consumed=1)
                    return
            except Exception as exc:
                _log(f"on_back: {exc}")
            nav_event("back", window=type(self).__name__)  # Φ6 telemetrie
            self.close()
            return
        if aid == xbmcgui.ACTION_STOP:
            nav_event("stop", window=type(self).__name__)  # Φ6 telemetrie
            try:
                # R2-P2 (re-audit): HasVideo, NE HasMedia — Stop v browse okně
                # nesmí zabít hudbu hrající na pozadí (ta není naše playback).
                if xbmc.getCondVisibility("Player.HasVideo"):
                    # R3-P2-11: okno, ve kterém uživatel PRÁVĚ stojí, JE cíl
                    # návratu — pending descriptor zrušit, jinak by service po
                    # stopu replaynul duplicitní stack nad otevřená okna.
                    consume_return_route()
                    xbmc.Player().stop()
                    return
            except Exception:
                pass
            self.close()
            return
        try:
            self.on_window_action(action)
        except Exception as exc:
            _log(f"on_window_action: {exc}")


def streams_clear_lifecycle():
    """Úklid po zavření pickeru (volat ve finally — NIKDY nesmí zůstat viset).

    Token a seen_token se NEmažou — slouží k párování/dedup i po zavření okna;
    přepíše je až další klik. Maže se jen liveness ping (+ legacy guard).
    """
    import xbmcgui
    try:
        win = xbmcgui.Window(10000)
        win.clearProperty(STREAMS_PING_PROP)
        win.clearProperty("richmovie.rm_streams_open")  # legacy guard hygiena
    except Exception:
        pass
