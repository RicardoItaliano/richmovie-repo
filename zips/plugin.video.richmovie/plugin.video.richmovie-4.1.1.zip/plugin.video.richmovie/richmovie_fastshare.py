# -*- coding: utf-8 -*-
# ---------------------------------- MODUL ----------------------------------- #
# richmovie_fastshare.py
# Fastshare.cz integrace pro RichMovie  (upraveno: 22.01.2026 00:15 CET, Europe/Prague)
# 22.01.2026 00:15 CET | rozšíření | důvod: přidán probe_mediainfo(), file_link(), User-Agent
# ---------------------------------------------------------------------------- #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Fastshare.cz integrace
───────────────────────────────────────────────────────────────────────────────
Tento modul poskytuje:

  • **FastshareClient**        – API wrapper (login, search, probe_mediainfo)
  • **FastshareSessionManager** – správa přihlášení (analogie k Webshare SessionManager)
  • **Whitelist kontrola**      – pouze vybraní uživatelé mají přístup

API Fastshare.cz:
  • Login:  https://fastshare.cz/api/api_kodi.php?process=login&login=...&password=...
  • Search: https://fastshare.cz/api/api_kodi.php?process=search&pagination=200&term=...

Autor: Richie (2026)
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

# — Standardní knihovny —
import hashlib
import json
import os
import re
import unicodedata
import urllib.parse
import urllib.request
from typing import List

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import richmovie_settings  # SSOT čtení i ověřeného zápisu nastavení (3.5.124)

# - Phase I1 (2026-04-19): MediaInfo probe delegovano na Gate.
# Addon uz nebundluje libmediainfo; probe logika je na /v1/mediainfo/probe.
from richmovie_gate_transport import (
    probe_mediainfo_via_gate as _gate_mi_probe,
    gate_payload_to_legacy_mi as _gate_mi_to_legacy,
)
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
API_URL = "https://fastshare.cz/api/api_kodi.php"


# Probe konstanty (stejné jako Webshare pro konzistenci)
PROBE_CHUNK_KB = 512       # kolik dat stáhneme v jednom „kusu"
PROBE_MAX_MB = 10          # hard-limit ≈ 10 MB

# User-Agent pro HTTP requesty
USER_AGENT = "Kodi/21.0 (RichMovie Fastshare)"


# ─────────────────────────────────────────────────────────────────────────────
#  POMOCNÉ FUNKCE
# ─────────────────────────────────────────────────────────────────────────────
# 3.4.x Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _fs_log_router = _make_legacy_logger("richmovie.fastshare", "RichMovie/Fastshare")
    def _log(msg: str) -> None:
        """Kratky INFO zaznam do Kodi logu + user_logs telemetry."""
        _fs_log_router(msg, level=1)  # xbmc.LOGINFO
    def _log_debug(msg: str) -> None:
        """DEBUG zaznam do Kodi logu + user_logs telemetry."""
        _fs_log_router(msg, level=0)  # xbmc.LOGDEBUG
    def _probe_log(event: str, *args) -> None:
        """Probe-specific log s structured context (event + args)."""
        parts = [str(a) for a in args]
        _fs_log_router(
            f"{event} {' '.join(parts)}",
            level=1,
            context={"event": event, "args": list(args)} if args else {"event": event},
        )
except Exception:
    def _log(msg: str) -> None:
        xbmc.log(f"[RichMovie/Fastshare] {msg}", xbmc.LOGINFO)
    def _log_debug(msg: str) -> None:
        xbmc.log(f"[RichMovie/Fastshare] {msg}", xbmc.LOGDEBUG)
    def _probe_log(event: str, *args) -> None:
        parts = [str(a) for a in args]
        xbmc.log(f"[RichMovie/Fastshare] {event} {' '.join(parts)}", xbmc.LOGINFO)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_fastshare.py
# is_fastshare_allowed  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def is_fastshare_allowed(ws_username: str) -> bool:
    """
    Vrátí True, pokud má uživatel přístup k Fastshare integraci.

    Přístup je povolen pokud:
      a) Gate povolí (admin zapnul fastshare flag), NEBO
      b) uživatel má vlastní credentials v Kodi settings
    """
    # a) Uživatel má vlastní credentials → vždy povolen
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon()
        if richmovie_settings.get_str("fs_username").strip() and richmovie_settings.get_str("fs_password").strip():
            return True
    except Exception:
        pass

    # b) Gate permissions
    try:
        import richmovie_gate
        return richmovie_gate.get_permissions().get("fastshare", False)
    except ImportError:
        return False


# ─────────────────────────────────────────────────────────────────────────────
#  VÝJIMKY
# ─────────────────────────────────────────────────────────────────────────────
class FastshareError(Exception):
    """Obecná chyba Fastshare API."""
    pass


class FastshareLoginError(FastshareError):
    """Chyba přihlášení k Fastshare.

    Φ2 (29.09.2026): nese `code` a `user_message` jako Webshare `APIError` — rozhoduje KÓD, ne text.
    Autoritativní odmítnutí serveru má větu pro uživatele; síťová příčina (`code` prázdný, `__cause__`)
    ji nemá, takže `richmovie_helpers.net_error_message` přeloží kořenovou chybu podle třídy.
    """

    CODE_REJECTED = "LOGIN_REJECTED"     # server odpověděl bez účtu = špatné jméno/heslo
    CODE_NO_TOKEN = "LOGIN_NO_TOKEN"     # server účet vrátil, ale bez hash tokenu

    _USER_MESSAGES = {
        CODE_REJECTED: "Fastshare odmítl přihlášení – zkontroluj jméno a heslo.",
        CODE_NO_TOKEN: "Fastshare přihlášení nedokončil – zkus to prosím za chvíli.",
    }

    def __init__(self, message: str = "", code: str = "") -> None:
        super().__init__(message)
        self.code = code or ""

    @property
    def user_message(self) -> str:
        return self._USER_MESSAGES.get(self.code, "")


# ─────────────────────────────────────────────────────────────────────────────
#  FASTSHARE CLIENT
# ─────────────────────────────────────────────────────────────────────────────
# ---------------------------------- TŘÍDA ----------------------------------- #
# richmovie_fastshare.py
# FastshareClient  (upraveno: 22.01.2026 00:15 CET, Europe/Prague)
# 22.01.2026 00:15 CET | rozšíření | důvod: přidán probe_mediainfo(), file_link()
# ---------------------------------------------------------------------------- #
class FastshareClient:
    """
    Lehký wrapper nad REST API Fastshare.cz

    Metody:
        • login(user, password) → hash token
        • search(query, limit) → list[dict] ve formátu kompatibilním s Webshare
        • file_link(ident) → URL pro streaming/download (s cookie)
        • probe_mediainfo(ident) → dict s MediaInfo daty (audio/sub tracky, délka)
    """

    def __init__(self, hash_token: str | None = None) -> None:
        """
        Inicializace klienta.

        Args:
            hash_token: Volitelný hash z předchozího přihlášení
        """
        self.hash = hash_token
        # Cache pro ident → (download_url, fs_hash) mapování
        self._url_cache: dict[str, tuple[str, str]] = {}
        # pymediainfo library file (lazy detect)
        self._library_file: str | None = None
        # Disk persistence pro URL cache
        self._url_cache_path: str | None = None
        try:
            import xbmcvfs
            profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
            os.makedirs(profile, exist_ok=True)
            self._url_cache_path = os.path.join(profile, "fs_url_cache.json")
            self._load_url_cache()
        except Exception:
            pass


    def _load_url_cache(self) -> None:
        """Načte URL cache z disku (pokud existuje)."""
        if not self._url_cache_path:
            return
        try:
            with open(self._url_cache_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                for k, v in data.items():
                    if isinstance(v, list) and len(v) == 2:
                        self._url_cache[k] = (v[0], v[1])
        except Exception:
            pass

    def _save_url_cache(self) -> None:
        """Uloží URL cache na disk."""
        if not self._url_cache_path:
            return
        try:
            # Omez cache na posledních 500 záznamů
            items = dict(list(self._url_cache.items())[-500:])
            with open(self._url_cache_path, "w", encoding="utf-8") as fh:
                json.dump(items, fh, ensure_ascii=False)
        except Exception:
            pass

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # _request  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def _request(self, params: dict, timeout: float = 10.0) -> dict:
        """
        Interní helper: HTTP GET request → JSON response.

        Args:
            params: Query parametry
            timeout: Timeout v sekundách

        Returns:
            Parsovaný JSON jako dict

        Raises:
            FastshareError: Při síťové chybě nebo neplatné odpovědi
        """
        try:
            query_string = urllib.parse.urlencode(params)
            url = f"{API_URL}?{query_string}"

            # 3.4.7 (2026-05-17, audit Π1): NEVER log credentials.
            # `_request` is reused for login (params contain `login=USER&password=PLAIN`)
            # and for search (params contain `hash=<MASTER_HASH>`). Logging the raw URL
            # — even truncated to 100 chars — leaks both into the 3.4.0 user_logs
            # SQLite/SSE pipeline. Log only the operation name (`process` param).
            _log_debug(f"Request: process={params.get('process', '?')}")

            # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. Fastshare API
            # se tu používá pro login a vyhledávání — obojí je čtení stavu, takže
            # zopakování po přechodné chybě nemůže nic zdvojit. GET metoda je
            # navíc idempotentní z definice.
            import richmovie_http as _rm_http
            profile = _rm_http.profile_foreground().replace(timeout_s=float(timeout))
            status, raw, _hdrs = _rm_http.request(
                url, headers={"User-Agent": USER_AGENT},
                profile=profile, tag="fastshare",
            )
            if status != 200:
                raise FastshareError(f"HTTP {status}")
            body = raw.decode("utf-8")

            data = json.loads(body)
            return data

        except FastshareError:
            raise
        except urllib.error.URLError as e:
            _log(f"Network error: {e}")
            raise FastshareError(f"Síťová chyba: {e}") from e
        except json.JSONDecodeError as e:
            _log(f"JSON parse error: {e}")
            raise FastshareError(f"Neplatná odpověď serveru") from e
        except Exception as e:
            _log(f"Request error: {e}")
            raise FastshareError(str(e)) from e


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # login  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def login(self, user: str, password: str) -> str:
        """
        Přihlášení k Fastshare.

        Args:
            user: Uživatelské jméno
            password: Heslo

        Returns:
            Hash token pro další requesty

        Raises:
            FastshareLoginError: Při neúspěšném přihlášení
        """
        params = {
            "process": "login",
            "login": user,
            "password": password,
        }

        try:
            data = self._request(params)

            # Kontrola odpovědi
            if not data.get("user"):
                raise FastshareLoginError("Neplatné přihlašovací údaje", FastshareLoginError.CODE_REJECTED)

            user_data = data["user"]
            hash_token = user_data.get("hash", "")

            if not hash_token:
                raise FastshareLoginError("Server nevrátil hash token", FastshareLoginError.CODE_NO_TOKEN)

            self.hash = hash_token
            _log(f"Login OK, user: {user}")

            return hash_token

        except FastshareError:
            raise
        except Exception as e:
            _log(f"Login failed: {e}")
            raise FastshareLoginError(str(e)) from e


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # is_logged_in  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def is_logged_in(self) -> bool:
        """
        Vrátí True pokud je klient přihlášen (má hash).
        """
        return bool(self.hash)


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # search  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    # Year token regex — matches a standalone 4-digit year 1900-2099.
    # Used by year-strip fallback in search() when first call returns 0
    # results. Defense-in-depth complement to Gate-side fix (deployed via
    # services/gate/app/search/sources/fastshare.py).
    _YEAR_TOKEN_RE = re.compile(r"\s*\b(?:19|20)\d{2}\b\s*")

    def _do_search(
        self, term: str, limit: int, show_adult: bool,
    ) -> List[dict]:
        """Single FS API call. Returns transformed items or [] on no match."""
        params = {
            "process": "search",
            "hash": self.hash,
            "pagination": str(limit),
            "term": term,
            "adult": "1" if show_adult else "0",
        }
        data = self._request(params)
        search_data = data.get("search", {})
        files = search_data.get("file", [])
        if not files:
            return []
        results: List[dict] = []
        for f in files:
            try:
                item = self._transform_file(f)
                if item:
                    results.append(item)
                    self._url_cache[item["ident"]] = (
                        item["fs_download_url"], item["fs_hash"],
                    )
            except Exception as e:
                _log_debug(f"Transform error: {e}")
                continue
        return results

    def search(self, query: str, limit: int = 200, show_adult: bool = False) -> List[dict]:
        """
        Vyhledávání na Fastshare.

        Vrací výsledky ve formátu kompatibilním s Webshare (pro snadnou integraci
        do SearchEngine a ReleaseFilter).

        Year-strip fallback (2026-04-30):
            FS API does substring match on filename. When `query` carries a
            year token (e.g. "Metráček 1972") and uploader-tagged year differs
            from TMDb year (CZ premiéra vs original, remake, restoration),
            the primary call returns 0. We retry once with year stripped.
            Engine's downstream `year_whitelist` filter rejects wrong-year
            matches, so safety is preserved. Plan: Handoff/session_2026-04-30_
            fastshare_year_strip_fix.md.

        Args:
            query: Hledaný výraz
            limit: Maximální počet výsledků
            show_adult: Zobrazit adult obsah

        Returns:
            List slovníků s klíči:
                - ident: unikátní ID (fs:<hash_url>)
                - name: název souboru
                - size: velikost v B
                - video_length: délka v sekundách
                - video_width: šířka videa
                - video_height: výška videa
                - source: "fastshare"
                - fs_download_url: přímá URL pro stažení/streaming
                - fs_hash: hash pro cookie

        Raises:
            FastshareError: Při chybě API
        """
        if not self.hash:
            _log("Search called without login")
            return []

        # Fastshare web stripuje diakritiku (Zálesák → zalesak).
        # API ocekava totez – bez toho vraci 0 vysledku pro ceske nazvy.
        term = unicodedata.normalize("NFD", query)
        term = "".join(ch for ch in term if unicodedata.category(ch) != "Mn")

        try:
            results = self._do_search(term, limit, show_adult)

            if not results:
                stripped = self._YEAR_TOKEN_RE.sub(" ", term).strip()
                stripped = re.sub(r"\s+", " ", stripped)
                if stripped and stripped != term:
                    _log(
                        "Search '{}' → 0; year-strip retry as '{}'".format(
                            query, stripped,
                        ),
                    )
                    results = self._do_search(stripped, limit, show_adult)
                    if results:
                        # Tag canonical item shape so downstream code can
                        # audit how the match was found. Non-breaking key.
                        for it in results:
                            it["_fs_match_mode"] = "year_stripped"

            if not results:
                # Φ-A (30.09.2026, E2-F17): nulový výsledek na INFO — dřív jen DEBUG, takže počet volání
                # Fastshare ve flotile šel jen odhadovat
                _log(f"Search '{query}' → 0 results")
                return []

            self._save_url_cache()
            _log(f"Search '{query}' → {len(results)} results")
            return results

        except FastshareError:
            raise
        except Exception as e:
            _log(f"Search error: {e}")
            raise FastshareError(str(e)) from e


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # _transform_file  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def _transform_file(self, f: dict) -> dict | None:
        """
        Transformuje Fastshare file objekt do Webshare-kompatibilního formátu.

        Fastshare API vrací:
            {
                "filename": "...",
                "data": {"value": 1500000000},  # bytes
                "duration": {"value": 7200},    # sekundy
                "resolution": "1920x1080 px",
                "download_url": "https://...",
                "thumbnail": "..."
            }

        Transformujeme na:
            {
                "ident": "fs:<hash>",
                "name": filename,
                "size": bytes,
                "video_length": seconds,
                "video_width": int,
                "video_height": int,
                "source": "fastshare",
                "fs_download_url": url,
                "fs_hash": hash
            }

        Args:
            f: Fastshare file objekt

        Returns:
            Transformovaný slovník nebo None při chybě
        """
        filename = (f.get("filename") or "").strip()
        if not filename:
            return None

        download_url = (f.get("download_url") or "").strip()
        if not download_url:
            return None

        # Velikost (Fastshare vrací v BYTES)
        size_bytes = 0
        try:
            data_obj = f.get("data", {})
            if isinstance(data_obj, dict):
                size_bytes = int(data_obj.get("value", 0) or 0)
            elif isinstance(data_obj, (int, float)):
                size_bytes = int(data_obj)
        except Exception:
            size_bytes = 0

        # Délka (sekundy)
        duration_s = 0
        try:
            dur_obj = f.get("duration", {})
            if isinstance(dur_obj, dict):
                duration_s = int(dur_obj.get("value", 0) or 0)
            elif isinstance(dur_obj, (int, float)):
                duration_s = int(dur_obj)
        except Exception:
            duration_s = 0

        # Rozlišení (parsování "1920x1080 px" nebo "1920x1080")
        width, height = 0, 0
        try:
            resolution = (f.get("resolution") or "").strip()
            if resolution:
                # Odstraníme "px" a další nečíselné znaky na konci
                res_clean = re.sub(r"[^\d]*(px|PX)?[^\d]*$", "", resolution).strip()
                match = re.match(r"(\d+)\s*[xX×]\s*(\d+)", res_clean)
                if match:
                    width = int(match.group(1))
                    height = int(match.group(2))
        except Exception:
            pass

        # Unikátní ident (fs: prefix + hash z URL)
        url_hash = hashlib.md5(download_url.encode()).hexdigest()[:12]
        ident = f"fs:{url_hash}"

        return {
            "ident": ident,
            "name": filename,
            "size": size_bytes,
            "video_length": duration_s,
            "video_width": width,
            "video_height": height,
            "positive_votes": 0,
            "negative_votes": 0,
            "source": "fastshare",
            "fs_download_url": download_url,
            "fs_hash": self.hash,
        }


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # register_url  (vytvořeno: 22.01.2026 00:15 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def register_url(self, ident: str, download_url: str, fs_hash: str) -> None:
        """
        Registruje URL pro daný ident do cache.
        Volá se z plugin.py když máme fs_url a fs_hash z query parametrů.

        Args:
            ident: Fastshare ident (fs:...)
            download_url: Přímá URL pro stažení
            fs_hash: Hash pro cookie
        """
        if ident and download_url and fs_hash:
            self._url_cache[ident] = (download_url, fs_hash)
            self._save_url_cache()


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # file_link  (vytvořeno: 22.01.2026 00:15 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def file_link(self, ident: str, download_type: str | None = None) -> str:
        """
        Vrátí přímou URL pro streaming/download.

        Pro kompatibilitu s Webshare API (které má file_link metodu).
        Fastshare nemá API pro získání URL podle ident, takže používáme cache
        z předchozího search() volání.

        Args:
            ident: Fastshare ident (fs:...)
            download_type: Ignorováno (pro kompatibilitu s Webshare)

        Returns:
            URL string

        Raises:
            FastshareError: Pokud ident není v cache
        """
        if ident not in self._url_cache:
            raise FastshareError(f"Neznámý ident: {ident} (není v cache)")

        url, _ = self._url_cache[ident]
        return url


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # get_cookie_header  (vytvořeno: 22.01.2026 00:15 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def get_cookie_header(self, ident: str) -> str:
        """
        Vrátí cookie header pro daný ident.

        Args:
            ident: Fastshare ident (fs:...)

        Returns:
            Cookie string (FASTSHARE=<hash>)
        """
        if ident in self._url_cache:
            _, fs_hash = self._url_cache[ident]
            return f"FASTSHARE={fs_hash}"
        return f"FASTSHARE={self.hash}"


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareClient
    # probe_mediainfo  (vytvořeno: 22.01.2026 00:15 CET, Europe/Prague)
    # -------------------------------------------------------------- #
    # probe_mediainfo (Phase I1, 2026-04-19) - Gate-only.
    # Addon uz nedrzi libmediainfo, celou probe pipeline dela Gate.
    # -------------------------------------------------------------- #
    def probe_mediainfo(self, ident: str) -> dict | None:
        """Full MediaInfo probe via Gate.

        Fastshare vyzaduje FASTSHARE=hash cookie pro download, ktere
        se forwarduje do Gate probe requestu. file_link URL je scoped
        (1-soubor, kratkodobe), takze Gate nevidi master token.

        Vraci legacy {"duration": sec, "tracks": [pymediainfo-like]}
        shape pro zpetnou kompatibilitu s mi2._extract().
        """
        try:
            if xbmc.Monitor().abortRequested():
                raise SystemExit
        except Exception:
            pass

        if ident not in self._url_cache:
            _probe_log("PROBE_NO_CACHE", ident)
            return None

        url, fs_hash = self._url_cache[ident]
        cookies = {"FASTSHARE": fs_hash} if fs_hash else None

        # Beta.7 (2026-04-25) fix: addon Release.ident má `fs:` prefix
        # (např. "fs:c1ef0d802d02"). Gate `mi_cache` PRIMARY KEY je
        # `(source='fs', source_ident=<hash>)` — ident BEZ prefixu.
        # Bez stripu Gate uloží pod `('fs', 'fs:c1ef0d802d02')` a další
        # bulk_lookup s `('fs', 'c1ef0d802d02')` selže s miss → každý user
        # probí znovu, crowdsource cache nefunguje.
        ident_for_gate = ident[3:] if ident.startswith("fs:") else ident

        payload = _gate_mi_probe("fs", ident_for_gate, url, cookies=cookies)
        if payload is None:
            _probe_log("PROBE_MI_GATE_FAIL", ident)
            return None

        data_out = _gate_mi_to_legacy(payload)
        _probe_log(
            "PROBE_MI_OK_GATE",
            ident, data_out.get("duration"),
            len(data_out.get("tracks", [])),
        )
        return data_out


    # Phase I1 (2026-04-19): lokalni incremental parse helper
    # ODSTRANEN. Gate parsuje v jednom shot.


# ─────────────────────────────────────────────────────────────────────────────
#  FASTSHARE SESSION MANAGER
# ─────────────────────────────────────────────────────────────────────────────
# ---------------------------------- TŘÍDA ----------------------------------- #
# richmovie_fastshare.py
# FastshareSessionManager  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
class FastshareSessionManager:
    """
    Vyšší vrstva nad FastshareClient zajišťující:

    • získání klienta s uloženým hash tokenem
    • login (tichý i interaktivní) s dialogem
    • ukládání credentials do Kodi settings
    """

    def __init__(self, addon: xbmcaddon.Addon) -> None:
        """
        Inicializace session manageru.

        Args:
            addon: Kodi addon instance pro přístup k settings
        """
        self._addon = addon
        self.client = FastshareClient(richmovie_settings.get_str("fs_hash") or None)

    def auto_login_from_gate(self):
        """
        Fallback přihlášení pomocí credentials z Gate serveru (admin-assigned).
        Použije se pouze pokud uživatel nemá vlastní credentials.
        """
        if self.is_logged_in():
            return True

        try:
            import richmovie_gate
            fs_creds = richmovie_gate.get_fastshare_credentials()
        except ImportError:
            fs_creds = None

        if not fs_creds:
            return False

        fs_login = fs_creds.get("username", "")
        fs_pass = fs_creds.get("password", "")
        if not fs_login or not fs_pass:
            return False

        try:
            self.client.hash = None
            self.client.login(fs_login, fs_pass)
            richmovie_settings.write("fs_username", fs_login)
            richmovie_settings.write("fs_password", fs_pass)
            richmovie_settings.write("fs_hash", self.client.hash)
            richmovie_settings.write("_fs_logged", "true")
            richmovie_settings.write("fs_info", "Přihlášeno (přes Gate)")
            _notify("Fastshare: automaticky přihlášeno")
            _log("Auto-login from Gate OK")
            return True
        except Exception as e:
            _log("Auto-login from Gate failed: {}".format(e))
            return False

    def ensure_login(self, *, interactive: bool = False, max_attempts: int = 3) -> bool:
        """
        Zajistí platný hash token – může zobrazit přihlašovací dialog.

        Priorita zdrojů credentials:
          1. Lokální Kodi settings (uživatel zadal sám)
          2. Gate credentials (admin přiřadil) — viz auto_login_from_gate()
          3. Interaktivní dialog (pokud povoleno)

        Args:
            interactive: Povolit interaktivní dialog
            max_attempts: Maximální počet pokusů při interaktivním režimu

        Returns:
            True pokud je přihlášení úspěšné
        """
        user = richmovie_settings.get_str("fs_username").strip()
        pw = richmovie_settings.get_str("fs_password").strip()
        hash_token = richmovie_settings.get_str("fs_hash").strip()

        # 1) Sirotek hash tokenu → zahodit
        if hash_token and (not user or not pw):
            _log("Orphan hash token, clearing")
            hash_token = ""
            richmovie_settings.write("fs_hash", "")

        # 2) Už přihlášen (hash + credentials)
        if hash_token and user and pw:
            self.client.hash = hash_token
            return True

        # 3) Tichý login (máme lokální credentials, ale ne hash)
        if user and pw:
            self.client.hash = None
            try:
                self.client.login(user, pw)
                richmovie_settings.write("fs_hash", self.client.hash)
                richmovie_settings.write("_fs_logged", "true")
                richmovie_settings.write("fs_info", "Přihlášeno ({})".format(user))
                _log("Silent login OK (local credentials)")
                return True
            except FastshareLoginError as e:
                _log(f"Silent login failed: {e}")
                richmovie_settings.write("_fs_logged", "false")
                richmovie_settings.write("fs_info", "Chyba přihlášení")

        # 4) Fallback na Gate credentials (admin-assigned)
        if self.auto_login_from_gate():
            return True

        # 5) Interaktivní dialog
        if not interactive:
            return False

        attempt = 0
        while attempt < max_attempts:
            user, pw = self._prompt_credentials()
            if not user or not pw:
                _log("Login cancelled by user")
                return False

            try:
                self.client.login(user, pw)
            except FastshareLoginError as err:
                attempt += 1
                _log(f"Interactive login failed, attempt {attempt}: {err}")

                msg = f"Chyba: {err}"
                if attempt < max_attempts:
                    msg += "\nZkuste to prosím znovu."
                xbmcgui.Dialog().ok("Fastshare přihlášení", msg)
                continue
            else:
                richmovie_settings.write("fs_username", user)
                richmovie_settings.write("fs_password", pw)
                richmovie_settings.write("fs_hash", self.client.hash)
                richmovie_settings.write("_fs_logged", "true")
                richmovie_settings.write("fs_info", "Přihlášeno ({})".format(user))
                _notify("Úspěšně přihlášeno k Fastshare")
                _log("Interactive login OK")
                return True

        return False


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareSessionManager
    # _prompt_credentials  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def _prompt_credentials(self) -> tuple[str | None, str | None]:
        """
        Zobrazí dialog pro zadání přihlašovacích údajů.

        Returns:
            Tuple (username, password) – může obsahovat None při zrušení
        """
        user = _keyboard_input("Fastshare – uživatelské jméno")
        if not user:
            return None, None

        pw = _keyboard_input("Fastshare – heslo", hidden=True)
        if not pw:
            return None, None

        return user, pw


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareSessionManager
    # is_logged_in  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def is_logged_in(self) -> bool:
        """
        Vrátí True pokud je uživatel přihlášen.
        """
        return self.client.is_logged_in()


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_fastshare.py › třída FastshareSessionManager
    # get_client  (vytvořeno: 21.01.2026 22:30 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def get_client(self) -> FastshareClient | None:
        """
        Vrátí FastshareClient pokud je přihlášen, jinak None.
        """
        if self.client.is_logged_in():
            return self.client
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  POMOCNÉ UI FUNKCE
# ─────────────────────────────────────────────────────────────────────────────
def _keyboard_input(heading: str, hidden: bool = False) -> str | None:
    """
    Zobrazí Kodi klávesnici pro zadání textu.

    Args:
        heading: Nadpis dialogu
        hidden: Skrýt vstup (pro hesla)

    Returns:
        Zadaný text nebo None při zrušení
    """
    kb = xbmc.Keyboard("", heading, hidden)
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else None


def _notify(msg: str, level: int = xbmcgui.NOTIFICATION_INFO, ms: int = 4000) -> None:
    """
    Zobrazí krátkou Kodi notifikaci.

    Args:
        msg: Text zprávy
        level: Úroveň notifikace
        ms: Doba zobrazení v milisekundách
    """
    _rm_notif(msg, level, ms, "RichMovie")
    _log(msg)
