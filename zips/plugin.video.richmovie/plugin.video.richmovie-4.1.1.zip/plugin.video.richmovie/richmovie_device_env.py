# -*- coding: utf-8 -*-
"""
RichMovie — SSOT „prostředí zařízení“: co o zařízení platí mimo RichMovie a mění výklad toho, co vidíme.

PROČ EXISTUJE (03.11.2026, noční balík, plán `Handoff/PLAN_noc_20261103.md` Φ1 + Φ3)
------------------------------------------------------------------------------------
Bětčin MacBook (macOS 14.8.1, Kodi 21.3) rok nepustil jediný stream. Příčina: Čas u obrazovky → „Omezit weby
pro dospělé“ spouští systémový filtr `webfilterproxyd`, který prohání VŠECHNA spojení aplikací přes lokální proxy
(127.0.0.1:10011). Velký stream filtr zadrží → Kodi 30 s nedostane data a mezitím neprojde ani jiné spojení.
RichMovie z toho vyvodil samé nepravdy: „zařízení je offline“ (fail-fast všech požadavků), „stream je přetížený“
(6 h horší kvalita), „zdroj odpovídá pomalu“. Tenhle modul je JEDINÉ místo, které ví, že v cestě stojí systémový
filtr, a jediné, které rozhodne, co to pro výklad chyb znamená (`filtered()`).

DVA NEZÁVISLÉ SIGNÁLY (`os_filter()`):
    • příčina — macOS: konfigurace filtru je pro uživatele čitelná
      (`/Library/Managed Preferences/<uživatel>/com.apple.familycontrols.contentfilter.plist`,
      `restrictWeb` / `useContentFilter` / `whitelistEnabled`). Čte jen služba (`refresh()`), plugin bere props.
    • účinek — každá platforma: `richmovie_http` po `connect()` porovná cíl s peerem socketu. Veřejný cíl a
      loopback peer = provoz zachytává lokální proxy (`note_connection`). Transparentní antiviry (ESET na Windows,
      ověřeno 03.11.) peer nemění → žádný falešný poplach.

D1 (plán): RichMovie filtr NIKDY neobchází — je to rodičovská pojistka. Jen ho rozpozná, nevyvozuje z něj falešné
závěry a srozumitelně řekne, co s tím.

SCHOPNOST DOLBY VISION (Φ3): `dv_supported()` z Kodi `System.SupportedHDRTypes` (zjišťuje služba, sdílí props).
Kodi 21 na macOS/Windows DV nepřehraje (profil 5 = černý obraz, `OutputPicture - timeout waiting for buffer`).

Bez Kodi importů na úrovni modulu (harness). Python 3.8 kompat.
"""
from __future__ import annotations

import getpass
import os
import plistlib
import sys
import threading
import time
from typing import Any, Dict, Optional, Tuple

try:
    import richmovie_winprops as _wp
except Exception:  # pragma: no cover — harness bez cesty k modulu
    _wp = None  # type: ignore

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.device_env", "RichMovie/DeviceEnv")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):  # type: ignore
        pass


# --------------------------------------------------------------------------- #
# Konstanty — SSOT
# --------------------------------------------------------------------------- #
OS_FILTER_NONE = ""
OS_FILTER_MACOS = "macos_screen_time"     # konfigurace macOS Čas u obrazovky (příčina známá)
OS_FILTER_LOOPBACK = "loopback_proxy"     # spojení končí na loopbacku (účinek; příčina neznámá / filtr dobíhá)
OS_FILTER_KINDS = (OS_FILTER_MACOS, OS_FILTER_LOOPBACK)

MAC_MANAGED_PREFS_DIR = "/Library/Managed Preferences"
MAC_CONTENT_FILTER_PLIST = "com.apple.familycontrols.contentfilter.plist"
# klíče, kterými Čas u obrazovky zapíná webový filtr (každý pravdivý = filtr běží)
MAC_FILTER_KEYS = ("useContentFilter", "restrictWeb", "whitelistEnabled")

PROP_FILTER = "richmovie.env.os_filter"            # výsledek `classify` (sdílený výklad pro všechny interprety)
PROP_FILTER_AT = "richmovie.env.os_filter_at"      # epoch prvního zjištění v tomto běhu Kodi
PROP_INTERCEPTED = "richmovie.env.intercepted"     # "1" / "0" — poslední veřejné spojení (účinek)
PROP_INTERCEPT_PEER = "richmovie.env.intercept_peer"
PROP_CONFIG = "richmovie.env.mac_config"           # "1" / "0" / "" — konfigurace macOS (příčina)
PROP_HDR_TYPES = "richmovie.env.hdr_types"         # Kodi System.SupportedHDRTypes, normalizované, čárkou
PROP_REFRESHED_AT = "richmovie.env.refreshed_at"   # epoch posledního `refresh()` služby ("" = v tomto běhu Kodi ještě ne)

REFRESH_INTERVAL_S = 600.0       # služba znovu čte konfiguraci (vypnutí filtru se projeví bez restartu RichMovie)
NOTICE_REPEAT_S = 7 * 24 * 3600  # vysvětlení v hlavním menu nejdřív za týden, dokud filtr trvá

STRESS_SKIP_REASON = "os_filter"

_lock = threading.Lock()
_last_intercept = {"value": None, "peer": ""}   # type: Dict[str, Any]   # jen ZMĚNA jde do props


# --------------------------------------------------------------------------- #
# Čisté funkce (harness)
# --------------------------------------------------------------------------- #
# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_device_env.py
# parse_macos_filter / classify  (vytvořeno: 03.11.2026 21:10 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def parse_macos_filter(data: Any) -> bool:
    """Zapíná konfigurace macOS Času u obrazovky webový filtr? Neznámý tvar = ne (nikdy falešný poplach)."""
    if not isinstance(data, dict):
        return False
    return any(bool(data.get(key)) for key in MAC_FILTER_KEYS)


def classify(config_active: bool, intercepted: bool) -> str:
    """Výklad dvou signálů. Konfigurace (příčina) má přednost — umíme říct přesný postup. Samotný účinek
    (spojení končí na loopbacku) = obecná lokální proxy, nebo filtr, který po vypnutí dobíhá (macOS do restartu)."""
    if config_active:
        return OS_FILTER_MACOS
    if intercepted:
        return OS_FILTER_LOOPBACK
    return OS_FILTER_NONE


def normalize_hdr_types(label: Any) -> Tuple[str, ...]:
    """`System.SupportedHDRTypes` → n-tice malých tokenů (`hdr10`, `hlg`, `dolbyvision`, `hdr10+`)."""
    text = str(label or "").lower().replace(";", ",").replace("/", ",")
    out = []
    for part in text.split(","):
        token = part.strip().replace(" ", "").replace("_", "")
        if not token:
            continue
        if token in ("dolbyvision", "dovi", "dv"):
            token = "dolbyvision"
        if token not in out:
            out.append(token)
    return tuple(out)


def dv_supported_in(hdr_types: Any) -> bool:
    """Umí displej + Kodi Dolby Vision? Jen když to Kodi výslovně hlásí (neznámo = ne)."""
    return "dolbyvision" in normalize_hdr_types(hdr_types if isinstance(hdr_types, str) else ",".join(hdr_types or ()))


def notice_due(kind: str, record: Any, now: float) -> bool:
    """Ukázat jednorázové vysvětlení filtru? Jen když filtr je, a buď se ještě neukázalo, nebo se změnil druh,
    nebo uběhl `NOTICE_REPEAT_S`."""
    if kind not in OS_FILTER_KINDS:
        return False
    if not isinstance(record, dict):
        return True
    if str(record.get("kind") or "") != kind:
        return True
    try:
        shown = float(record.get("shown_at") or 0)
    except (TypeError, ValueError):
        shown = 0.0
    return (now - shown) >= NOTICE_REPEAT_S


# --------------------------------------------------------------------------- #
# Texty — SSOT (UI je bere odsud; §9: věta rodiče, ne technika)
# --------------------------------------------------------------------------- #
def stall_text(kind: str) -> str:
    """Toast hlídače startu místo „Zdroj odpovídá pomalu“, když stream zdržuje filtr."""
    if kind == OS_FILTER_MACOS:
        return "Film brzdí filtr webu v Čase u obrazovky na tomhle Macu."
    return "Film brzdí filtr, přes který tohle zařízení posílá internet."


def notice_heading(kind: str) -> str:
    return "Filtr webu brzdí filmy"


def notice_text(kind: str) -> str:
    """Jednorázové vysvětlení v hlavním menu. Přesný postup, žádné obcházení (D1)."""
    if kind == OS_FILTER_MACOS:
        return ("Na tomhle Macu je v Čase u obrazovky zapnuté „Omezit weby pro dospělé“. Ten filtr pouští "
                "velké soubory jen po kouscích, takže se filmy zasekávají nebo vůbec nespustí.\n\n"
                "Rodič ho vypne takhle: Nastavení systému → Čas u obrazovky → Obsah a soukromí → Omezení obsahu → "
                "Přístup k webovému obsahu → Neomezený přístup. Pak Mac restartujte.")
    return ("Internet na tomhle zařízení prochází přes filtr (rodičovská kontrola, antivir nebo VPN). Ten pouští "
            "velké soubory jen po kouscích, takže se filmy mohou zasekávat.\n\n"
            "Pokud jste filtr právě vypnuli, restartujte zařízení. Jinak ho zkuste pro RichMovie vypnout.")


# --------------------------------------------------------------------------- #
# Stav (props) — čtení odkudkoli, zápis jen tady
# --------------------------------------------------------------------------- #
def _get(name: str) -> str:
    try:
        return str(_wp.get_prop(name, "") or "") if _wp is not None else ""
    except Exception:
        return ""


def _set(name: str, value: str) -> None:
    try:
        if _wp is not None:
            _wp.set_prop(name, value)
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_device_env.py
# os_filter / filtered  (vytvořeno: 03.11.2026 21:10 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def os_filter() -> str:
    """Aktuální výklad (sdílený všemi interprety přes props). "" = žádný filtr."""
    value = _get(PROP_FILTER)
    return value if value in OS_FILTER_KINDS else OS_FILTER_NONE


def filtered() -> bool:
    """JEDINÁ otázka spotřebitelů: stojí v cestě systémový filtr? (netstate, stres, zdraví zdroje, texty)."""
    return os_filter() != OS_FILTER_NONE


def _recompute(reason: str) -> str:
    """Přepočítá výklad z obou signálů a zapíše ZMĚNU (log jen při změně)."""
    config_active = _get(PROP_CONFIG) == "1"
    intercepted = _get(PROP_INTERCEPTED) == "1"
    kind = classify(config_active, intercepted)
    previous = os_filter()
    if kind != previous:
        _set(PROP_FILTER, kind)
        if kind and not _get(PROP_FILTER_AT):
            _set(PROP_FILTER_AT, str(int(time.time())))
        if not kind:
            _set(PROP_FILTER_AT, "")
        _log("%s kind=%s předtím=%s config=%s intercepted=%s peer=%s důvod=%s" % (
            "OS_FILTER_DETECTED" if kind else "OS_FILTER_CLEARED", kind or "-", previous or "-",
            int(config_active), int(intercepted), _get(PROP_INTERCEPT_PEER) or "-", reason),
            2 if kind else 1,
            context={"kind": kind, "previous": previous, "config": config_active,
                     "intercepted": intercepted, "reason": reason})
    return kind


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_device_env.py
# note_connection  (vytvořeno: 03.11.2026 21:10 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def note_connection(host: str = "", intercepted: bool = False, peer: str = "") -> None:
    """Účinek z `richmovie_http` (po každém `connect()` na veřejnou adresu). Levné: zapisuje jen ZMĚNU.
    Nikdy nehází (volá se z transportní vrstvy)."""
    try:
        value = bool(intercepted)
        # Paměť i props pod JEDNÍM zámkem (cross-check Flash F9: zápis props mimo zámek mohl ve dvou vláknech nechat
        # props „0“ a paměť „zachyceno“ → další zachycení by se zahodilo jako beze změny)
        with _lock:
            if _last_intercept["value"] is value and (not value or _last_intercept["peer"] == peer):
                return
            _last_intercept["value"] = value
            _last_intercept["peer"] = peer if value else ""
            _set(PROP_INTERCEPTED, "1" if value else "0")
            _set(PROP_INTERCEPT_PEER, peer if value else "")
            _recompute("spojeni %s" % (host or "?"))
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_device_env.py
# macos_filter_config / refresh  (vytvořeno: 03.11.2026 21:10 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _current_user() -> str:
    for getter in (lambda: os.environ.get("USER") or "", getpass.getuser,
                   lambda: os.path.basename(os.path.expanduser("~"))):
        try:
            name = str(getter() or "").strip()
            if name and "/" not in name and name not in (".", ".."):
                return name
        except Exception:
            continue
    return ""


def macos_filter_config(user: Optional[str] = None, base_dir: str = MAC_MANAGED_PREFS_DIR) -> Optional[bool]:
    """macOS: zapíná Čas u obrazovky webový filtr? None = nelze zjistit (jiná platforma, chybí uživatel,
    nečitelný soubor). Chybějící soubor = False (filtr vypnutý — po vypnutí ho macOS smaže, ověřeno 03.11.)."""
    name = user if user is not None else _current_user()
    if not name:
        return None
    path = os.path.join(base_dir, name, MAC_CONTENT_FILTER_PLIST)
    try:
        if not os.path.exists(path):
            return False
        with open(path, "rb") as fh:
            return parse_macos_filter(plistlib.load(fh))
    except Exception:
        return None


def refresh(platform_name: Optional[str] = None) -> str:
    """Služba: znovu přečte konfiguraci (příčinu) a schopnosti HDR, přepočítá výklad. Volat při startu služby
    a pak à `REFRESH_INTERVAL_S`. Plugin to nevolá (čte jen props)."""
    plat = (platform_name or sys.platform or "").lower()
    # Čtení (soubor, Kodi) mimo zámek; zápis props + přepočet pod TÝMŽ zámkem jako `note_connection`
    # (audit Fable V3 03.11.2026: souběh služba × HTTP vlákno jinak mohl dát krátce nesprávný výklad a dvojí log).
    # Mezi procesy (plugin × služba) zámek nepůsobí — přepočet čte jen props, takže poslední zápis vyhraje správně.
    cfg = macos_filter_config() if plat.startswith("darwin") else None
    refresh_hdr_types()
    with _lock:
        if plat.startswith("darwin"):
            if cfg is not None:
                _set(PROP_CONFIG, "1" if cfg else "0")
        else:
            _set(PROP_CONFIG, "")
        kind = _recompute("refresh")
        _set(PROP_REFRESHED_AT, str(int(time.time())))
    return kind


def evaluated() -> bool:
    """Proběhlo v tomto běhu Kodi `refresh()` služby? Do té doby je výklad jen z účinku (spojení), ne úplný."""
    return bool(_get(PROP_REFRESHED_AT))


# --------------------------------------------------------------------------- #
# Dolby Vision / HDR (Φ3)
# --------------------------------------------------------------------------- #
def refresh_hdr_types() -> Tuple[str, ...]:
    """Přečte Kodi `System.SupportedHDRTypes` (jen v Kodi) a uloží do props pro všechny interprety."""
    try:
        import xbmc  # type: ignore
        label = xbmc.getInfoLabel("System.SupportedHDRTypes")
    except Exception:
        return hdr_types()
    types = normalize_hdr_types(label)
    value = ",".join(types)
    if value != _get(PROP_HDR_TYPES):
        _set(PROP_HDR_TYPES, value)
        _log("HDR_TYPES %s (Kodi: %r)" % (value or "-", str(label or "")[:80]), 1,
             context={"hdr_types": value})
    return types


def hdr_types() -> Tuple[str, ...]:
    return normalize_hdr_types(_get(PROP_HDR_TYPES))


def dv_supported() -> bool:
    """Přehraje tohle zařízení Dolby Vision? Neznámo = ne (jen mírné odsunutí ve výpisu, nikdy skrytí — D3)."""
    return dv_supported_in(_get(PROP_HDR_TYPES))


# --------------------------------------------------------------------------- #
# Jednorázové vysvětlení (krok uvítací sekvence `os_filter`)
# --------------------------------------------------------------------------- #
NOTICE_FILE = "os_filter_notice.json"   # kořen dat doplňku = per zařízení (ne profil)


def _notice_path() -> str:
    import richmovie_paths as _paths
    return str(_paths.addon_data_dir() / NOTICE_FILE)


def notice_pending(now: Optional[float] = None) -> str:
    """Druh filtru, ke kterému se má teď ukázat vysvětlení, jinak "" (čte stav props + záznam o zobrazení)."""
    kind = os_filter()
    if not kind:
        return ""
    try:
        import richmovie_atomic as _atomic
        # `read_json` vrací DVOJICI `(hodnota, stav)` (audit Fable V1 03.11.2026: bez rozbalení `notice_due`
        # záznam nikdy neuznal a vysvětlení se ukazovalo při každém startu místo 1× za 7 dní).
        record, _state = _atomic.read_json(_notice_path(), None, name=NOTICE_FILE, expected_type=dict)
    except Exception:
        record = None
    return kind if notice_due(kind, record, time.time() if now is None else now) else ""


def show_notice_if_due() -> bool:
    """Krok uvítací sekvence `os_filter` (plugin, hlavní menu): ukáže vysvětlení, když je čas. True = ukázáno.
    Záznam o zobrazení se zapíše až PO dialogu (spadlý dialog = ukázat příště)."""
    kind = notice_pending()
    if not kind:
        return False
    try:
        import xbmcgui  # type: ignore
        xbmcgui.Dialog().ok(notice_heading(kind), notice_text(kind))
    except Exception as exc:
        _log("OS_FILTER_NOTICE dialog selhal: %r" % (exc,), 2)
        return False
    note_notice_shown(kind)
    _log("OS_FILTER_NOTICE shown kind=%s" % kind, 1, context={"kind": kind})
    return True


def note_notice_shown(kind: str, now: Optional[float] = None) -> bool:
    try:
        import richmovie_atomic as _atomic
        return bool(_atomic.write_json(_notice_path(), {"kind": kind,
                                                        "shown_at": int(time.time() if now is None else now)}))
    except Exception:
        return False


def telemetry_fields() -> Dict[str, Any]:
    """Pole pro `/status` a `SESSION_ENV` (Gate mig 0044 `user_devices.os_content_filter`, `hdr_types`).
    Před prvním `refresh()` služby None = „nevím“ → Gate sloupec nemění (plugin hlásí stav dřív, než služba
    prostředí zjistí — prázdná hodnota by na Gate přepsala známý filtr na „žádný“)."""
    if not evaluated():
        return {"os_filter": None, "hdr_types": None}
    return {"os_filter": os_filter(), "hdr_types": ",".join(hdr_types())}


def reset_for_tests() -> None:
    with _lock:
        _last_intercept["value"] = None
        _last_intercept["peer"] = ""
