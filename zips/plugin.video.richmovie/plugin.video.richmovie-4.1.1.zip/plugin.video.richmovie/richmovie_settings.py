# -*- coding: utf-8 -*-
"""RichMovie settings — single source of truth for addon settings reads/writes.

Created 2026-05-02 (sprint: drop Gate /v1/search + Settings SSOT, plan
Handoff/session_2026-05-02_drop_gate_search_settings_ssot.md).

Why this module exists
======================

`xbmcaddon.Addon().getSetting(<key>)` is called 112× in 31 unique keys
across 30+ modules of the addon. Multiple subsystems read the same
underlying value but spell the key differently. Concrete incident:

    Bug B (2026-04-30): `richmovie_search_client.is_available()` checked
    settings keys ``wst`` / ``webshare_token``, but the addon stores the
    Webshare session token under key ``token`` (engine.search_movie_one
    was patched in beta.7 to read this; is_available() never was). Result:
    Gate `/v1/search` path returned silently dead False for 5 days, no
    one noticed because the legacy WS+FS scraping path kept working.

This module centralizes typed accessors so a future Bug C/D/E cannot
recur from a key-name typo. Each accessor:

  - Tries the canonical (current) key first
  - Falls through to legacy aliases for safety (read-only — addon never
    writes the old keys)
  - Returns ``None`` for empty / missing values (callers do not need to
    repeat the ``or None`` strip pattern)

Migration policy
================

New code MUST import from this module. Existing call sites should be
migrated **opportunistically** when the surrounding code is touched for
another reason — no big-bang rewrite. The 7 WS-token reads identified
in the sprint plan §1.3 are migrated in this same commit; the remaining
~105 ``getSetting()`` calls (TMDb proxy hint flags, probe toggles, trace
options, FS shared-account flag, …) stay as-is until naturally touched.

Conventions
===========

  - Lazy ``Addon()`` instantiation per call. Kodi can reload the addon
    object across plugin invocations; module-level cache would race.
  - Strip + empty-string-to-None on every read so callers can use
    ``if get_X():`` idiomatically.
  - No write helpers for keys the addon never writes (e.g.
    ``tmdb_api_key`` is set by Gate auth handshake, addon only reads).
  - Tuple returns when two settings logically belong together
    (``get_fs_credentials`` returns the (user, pass) pair atomically).

Python 3.8 compatible (Kodi runtime constraint — no PEP 604 unions, no
walrus inside annotations, no PEP 612 ParamSpec).
"""
from __future__ import annotations


from __future__ import absolute_import

import os
import re
import threading
import time
from typing import Any, Optional, Tuple

import xbmcaddon
import xbmcvfs

# Explicitní ID addonu — viz `_addon()`. NIKDY nenahrazovat `Addon()` bez argumentu.
ADDON_ID = "plugin.video.richmovie"

# Φ0 (29.09.2026): kolik čerstvých instancí addonu tento proces vytvořil. Každá
# instance = Kodi znovu parsuje `resources/settings.xml` i uživatelský `settings.xml`
# s drženým GIL (audit A08 F3, ~2 ms na PC). TRACE `phase=end` ho hlásí jako
# `settings_reads`, aby šlo změřit dopad snímku nastavení (Φ4) po celé flotile.
_ADDON_INSTANCES = 0


# --------------------------------------------------------------------------- #
# Internal helper
# --------------------------------------------------------------------------- #

def addon_instances():
    # type: () -> int
    """Počet instancí `xbmcaddon.Addon` vytvořených přes tento modul v procesu."""
    return _ADDON_INSTANCES


def _addon():
    # type: () -> xbmcaddon.Addon
    """Čerstvá instance addonu s EXPLICITNÍM ID.

    PROČ explicitní ID (incident bandog, 27.08.2026)
    ------------------------------------------------
    `xbmcaddon.Addon()` bez argumentu určuje addon z kontextu volání. To je
    spolehlivé v hlavním vlákně invokace pluginu, ale ne nutně ve vláknech
    dlouhoběžící služby (`service_nextup` drží drainer i next-up workery).
    Na jednom zařízení začalo čtení vracet **prázdný řetězec bez výjimky** →
    requesty bez identity (Gate 403), umlklý log drainer a průvodce nastavením
    dokola. `Addon(ADDON_ID)` je jednoznačné bez ohledu na volající kontext.

    PROČ se instance NEUCHOVÁVÁ
    ---------------------------
    Kodi objekt addonu napříč invokacemi recykluje; modulová cache by závodila
    se zápisy z jiného procesu (každá invokace pluginu = nový interpret). Vzor
    přebrán z `richmovie_crash.py:292`, který to dělal správně už dřív.
    """
    global _ADDON_INSTANCES
    _ADDON_INSTANCES += 1
    return xbmcaddon.Addon(ADDON_ID)


# --------------------------------------------------------------------------- #
# Snímek čtení per proces (Φ4, 29.09.2026 — audit A08 F3/F4/F8)
# --------------------------------------------------------------------------- #
#
# PROČ: každé čtení = nová instance `Addon(ADDON_ID)` = Kodi znovu parsuje dvě XML s drženým GIL
# (~2 ms na PC, odhad ~9 ms na TV). 380 000 čtení za 44 h ve službě, 2 400–3 700 na jedno hledání
# (`_log_event` čte 3 přepínače na každé rozhodnutí filtru); 99 % debug logu Kodi je jejich šum.
#
# KONTRAKT (proč to není „modulová cache instance“, kterou docstring `_addon()` zakazuje):
#   • kešuje se HODNOTA, ne instance; každé načtení do snímku jde čerstvou instancí jako dřív,
#   • jen z PROKAZATELNĚ zdravé instance: tatáž instance musí vrátit kanárek `_settings_canary`
#     s výchozí „1“ (deklarovaný v resources/settings.xml, nikdo ho nezapisuje). Otrávená instance
#     (`m_loadSettingsFailed`, incident bandog) vrací "" pro všechno → hodnota se použije jednou
#     a NEkešuje (dnešní chování),
#   • platnost = otisk uživatelského `settings.xml` (`st_mtime_ns` + velikost; jeden `os.stat` na
#     čtení). Čerstvá instance čte hodnoty právě z toho souboru — každá změna (dialog nastavení Kodi,
#     zápis z jiného procesu) ho přepíše. Změna souboru během načítání = nekešovat. Bez souboru
#     (čerstvá instalace) se nekešuje vůbec,
#   • vlastní `write()` snímek zahodí; ověřovací čtení po zápisu a `diagnose_read` jdou mimo snímek.
CANARY_KEY = "_settings_canary"
CANARY_VALUE = "1"
# Hrubost časových značek souborových systémů: FAT/exFAT 2 s (karty a USB disky Android boxů), ext4 / NTFS jemnější.
# Soubor změněný před méně než touto dobou se do snímku NEUKLÁDÁ — další zápis stejné velikosti (např. "0" → "1")
# by mohl dostat tentýž mtime a snímek by ho nepoznal (cross-check Pro D4, 29.09.2026; stejný postup jako
# „racy timestamps“ v gitu). Po uplynutí okna každý další zápis mtime nutně změní.
MTIME_RACY_WINDOW_NS = 2 * 1000 * 1000 * 1000
_KIND_STR = "str"
_KIND_BOOL = "bool"
_MISS = object()
_snap_lock = threading.Lock()
_snap = {"stamp": None, "values": {}}   # type: dict


def _file_stamp():
    # type: () -> Optional[Tuple[int, int]]
    """(mtime_ns, velikost) uživatelského settings.xml, nebo None (soubor není / nejde stat)."""
    path = settings_file_path()
    if not path:
        return None
    try:
        st = os.stat(path)
    except OSError:
        return None
    return (int(st.st_mtime_ns), int(st.st_size))


def _stamp_settled(stamp):
    # type: (Tuple[int, int]) -> bool
    """Je poslední změna souboru starší než hrubost časových značek (`MTIME_RACY_WINDOW_NS`)?"""
    return time.time_ns() - int(stamp[0]) >= MTIME_RACY_WINDOW_NS


def invalidate_snapshot():
    # type: () -> None
    """Zahodí snímek čtení (vlastní zápis; testy)."""
    with _snap_lock:
        _snap["stamp"] = None
        _snap["values"] = {}


def _load(kind, key):
    # type: (str, str) -> Tuple[Any, bool]
    """Jedna čerstvá instance: (hodnota, instance_je_zdravá). Hodnota None = čtení vyhodilo."""
    addon = _addon()
    try:
        healthy = addon.getSetting(CANARY_KEY) == CANARY_VALUE
    except Exception:
        healthy = False
    try:
        value = bool(addon.getSettingBool(key)) if kind == _KIND_BOOL else addon.getSetting(key)
    except Exception:
        return None, False
    return value, healthy


def _get(kind, key):
    # type: (str, str) -> Any
    """Hodnota ze snímku, nebo čerstvě přečtená (a uložená, pokud to kontrakt dovolí)."""
    stamp = _file_stamp()
    if stamp is not None:
        with _snap_lock:
            if _snap["stamp"] != stamp:
                _snap["stamp"] = stamp
                _snap["values"] = {}
            hit = _snap["values"].get((kind, key), _MISS)
        if hit is not _MISS:
            return hit
    value, healthy = _load(kind, key)
    if (value is not None and healthy and stamp is not None and _file_stamp() == stamp
            and _stamp_settled(stamp)):
        with _snap_lock:
            if _snap["stamp"] == stamp:
                _snap["values"][(kind, key)] = value
    return value


def _strip_or_none(raw):
    # type: (Any) -> Optional[str]
    if not raw:
        return None
    val = str(raw).strip()
    return val if val else None


def _read(key):
    # type: (str) -> Optional[str]
    """Return stripped non-empty setting value, or None (přes snímek čtení, Φ4)."""
    return _strip_or_none(_get(_KIND_STR, key))


def _read_uncached(key):
    # type: (str) -> Optional[str]
    """Totéž jako `_read`, ale vždy čerstvou instancí — diagnostika cesty API (`diagnose_read`)."""
    try:
        return _strip_or_none(_addon().getSetting(key))
    except Exception:
        return None


def _read_first(*keys):
    # type: (*str) -> Optional[str]
    """Return first non-empty value from candidate keys (in priority order)."""
    for k in keys:
        v = _read(k)
        if v:
            return v
    return None


# --------------------------------------------------------------------------- #
# Webshare
# --------------------------------------------------------------------------- #

def get_ws_token():
    # type: () -> Optional[str]
    """Webshare session token (``wst`` cookie).

    Primary key: ``token`` (set by plugin.py after _ensure_login).
    Legacy fallback: ``wst`` / ``webshare_token`` / ``webshare_cookie``
    — none of these are written by current addon code, but a user with
    a hand-patched settings.xml from an old branch could still have them.
    """
    return _read_first("token", "wst", "webshare_token", "webshare_cookie")


def set_ws_token(value):
    # type: (str) -> None
    """Persist Webshare session token under canonical key ``token``.

    Empty / None value clears the setting (Kodi treats empty string as
    'unset' in most contexts).
    """
    # 3.5.124: přes ověřený zápis — ztráta tokenu se hlásí (SETTINGS_WRITE_LOST),
    # ne tiše spolkne. Návratová hodnota se záměrně nevrací (API zůstává None),
    # volající, kterým na výsledku záleží, používají `write_identity()`.
    write("token", value or "")


def get_ws_username():
    # type: () -> Optional[str]
    """Webshare account username (login)."""
    return _read("username")


def get_ws_password():
    # type: () -> Optional[str]
    """Webshare account password. Rotates on user re-login; never persisted
    server-side. The only consumer is WebshareClient.login() flow."""
    return _read("password")


def get_identity_pair():
    # type: () -> Tuple[Optional[str], Optional[str]]
    """(username, password) jedním čtením — SSOT pro identitu vůči Gate.

    Vrací dvojici atomicky, aby volající nemohl použít jedno bez druhého
    (stejný důvod jako u `get_fs_credentials`). Prázdné hodnoty → None.
    Konzument: `richmovie_gate_transport.get_identity()`.
    """
    return (_read("username"), _read("password"))


# --------------------------------------------------------------------------- #
# Fastshare
# --------------------------------------------------------------------------- #

def get_fs_credentials():
    # type: () -> Optional[Tuple[str, str]]
    """Return (fs_username, fs_password) if both present, else None.

    Returning a single Optional tuple instead of two separate calls
    enforces the invariant that callers cannot use one without the
    other (login requires both).
    """
    user = _read("fs_username")
    pwd = _read("fs_password")
    if user and pwd:
        return (user, pwd)
    return None


# --------------------------------------------------------------------------- #
# TMDb
# --------------------------------------------------------------------------- #

def get_tmdb_api_key():
    # type: () -> str
    """TMDb API key — SSOT. Gate je zdroj pravdy (drží klíč; TMDb jede přes Gate
    proxy / SkyHook, lokální klíč fakticky netřeba). Vrací lokální cache setting,
    JINAK fallback na klíč z Gate lease cache. VŽDY str ("" když není nikde).

    PROČ fallback (incident bandog 2026-06-26): lokální setting se plní jen při
    úspěšném Webshare loginu (sync v plugin.py coupled na WS-login flow); když WS
    login selhával, klíč zůstal prázdný a 12 guardů hlásilo „Chybí API klíč TMDb"
    — přestože Gate klíč má. Uživatel klíč NIKDY nezadává. Lazy import gate (bez cyklu)."""
    local = _read("tmdb_api_key")
    if local:
        return local
    try:
        import richmovie_gate
        return (richmovie_gate.get_tmdb_api_key() or "").strip()
    except Exception:
        return ""


# --------------------------------------------------------------------------- #
# Run-once / stavové flagy (3.5.118, 2026-08-21)
# --------------------------------------------------------------------------- #
# Typovaný přístup k textovým flagům typu "done:<ts>:<n>" (cw_backfill_v1,
# backfill_v1_done…). Dřív každý modul volal `SETTINGS.setSetting` přímo —
# a `service_nextup._cw_backfill_lost_series` flag zapsal i po 100% selhání
# (Fire-and-Forget místo All-or-Nothing). Accessor sám o sobě selhání nehlídá,
# ale je to jediné místo, kde se flag píše, takže audit „kdo a kdy označil
# hotovo" je jeden grep.

def get_flag(key):
    # type: (str) -> Optional[str]
    """Hodnota flagu, nebo None když není nastaven (prázdný = nenastaven)."""
    return _read(key)


def get_bool(key):
    # type: (str) -> bool
    """Bool setting. POZOR (feedback_kodi_settings_xml_types): setting, který
    v resources/settings.xml CHYBÍ, vrací False bez chyby — každý nový klíč
    musí být v XML deklarovaný s defaultem (incident nextup_dialog)."""
    return bool(_get(_KIND_BOOL, key))


def set_flag(key, value):
    # type: (str, str) -> bool
    """Zapíše flag. Vrací True při úspěchu — volající, který značí run-once
    „hotovo", MUSÍ mít před voláním ověřeno, že práce skutečně proběhla bez
    selhání (R3 plánu 3.5.118: marker až po absolutním úspěchu)."""
    return write(key, value or "")  # 3.5.124: ověřený zápis (SETTINGS_WRITE_LOST při ztrátě)


# --------------------------------------------------------------------------- #
# Diagnostika čtení nastavení (3.5.120, incident bandog 27.08.2026)
# --------------------------------------------------------------------------- #
#
# PROČ TAHLE SEKCE EXISTUJE
# -------------------------
# `getSetting()` umí vrátit prázdný řetězec BEZ vyhození výjimky. Volající pak
# nemá jak odlišit „uživatel to nemá nastavené" od „nepřečetl jsem to". Obojí
# vypadá stejně — a obojí vede k úplně jinému správnému chování:
#   • nenastaveno  → ukázat průvodce / přihlášení (dnešní chování je správné),
#   • nepřečteno   → NEDĚLAT NIC destruktivního (nemazat token, neposílat request
#                    bez identity, neptát se na heslo) a nahlásit poruchu.
#
# Rozlišení NESMÍ být heuristika (stáří lease apod. — selhává v obou směrech,
# viz plán 3.5.120 §2/A1). Používá se **porovnání dvou nezávislých cest ke
# stejné hodnotě**: Python API vs. přímé čtení `settings.xml`. Rozpor = důkaz.
#
# Soubor je DŮKAZ, ne zdroj hodnoty. Kodi drží nastavení v paměti a na disk je
# zapisuje se zpožděním, takže čerstvě zapsaná hodnota v souboru být nemusí —
# hodnoty se odsud NIKDY nečtou pro běžné použití.

# Stavy souboru settings.xml
FILE_HAS_VALUE = "has_value"      # klíč v souboru je a má neprázdnou hodnotu
FILE_EMPTY = "empty"              # klíč v souboru je, ale prázdný
FILE_KEY_MISSING = "key_missing"  # soubor přečten, klíč tam není
FILE_NO_FILE = "no_file"          # soubor neexistuje (čerstvá instalace)
FILE_UNREADABLE = "unreadable"    # soubor existuje, ale nejde přečíst/rozparsovat

# Verdikty `diagnose_read()`
VERDICT_OK = "ok"                        # API vrátilo hodnotu — vše v pořádku
VERDICT_NOT_CONFIGURED = "not_configured"  # prokazatelně nenastaveno
VERDICT_READ_FAILURE = "read_failure"      # PROKÁZANÁ porucha čtení (API prázdné, soubor plný)
VERDICT_INCONCLUSIVE = "inconclusive"      # nelze rozhodnout → fail-safe jako nenastaveno

_SETTINGS_FILENAME = "settings.xml"


_settings_path = {"value": ""}   # Φ4: cesta je po dobu procesu konstantní (profil Kodi se za běhu nemění)


def settings_file_path():
    # type: () -> str
    """Absolutní cesta k `settings.xml` addonu (addon_data profilu). Zapamatuje se po prvním úspěchu —
    snímek čtení ji potřebuje u každého čtení (`os.stat`)."""
    if _settings_path["value"]:
        return _settings_path["value"]
    try:
        base = xbmcvfs.translatePath(
            "special://profile/addon_data/{}/".format(ADDON_ID)
        )
        path = os.path.join(base, _SETTINGS_FILENAME)
    except Exception:
        return ""
    _settings_path["value"] = path
    return path


def read_key_from_file(key):
    # type: (str) -> Tuple[str, Optional[str]]
    """Přečte klíč přímo ze `settings.xml`. Vrací (stav, hodnota|None).

    Záměrně regulárním výrazem, ne XML parserem: soubor může být poškozený
    (což je jedna z vyšetřovaných hypotéz) a parser by na tom spadl dřív, než
    stihne najít klíč. Hledá se `<setting id="key">hodnota</setting>` i
    self-closing varianta.
    """
    path = settings_file_path()
    if not path:
        return FILE_UNREADABLE, None
    try:
        if not os.path.isfile(path):
            return FILE_NO_FILE, None
    except Exception:
        return FILE_UNREADABLE, None
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    except Exception:
        return FILE_UNREADABLE, None

    # Kontrola celistvosti PŘED hledáním klíče.
    #
    # Bez ní by useknutý soubor (přerušený zápis, plný disk) vypadal jako
    # „klíč tam prostě není", tedy jako legitimní „nenastaveno" — a to je přesně
    # ten stav, kdy se nejvíc potřebujeme mýlit na bezpečnou stranu. Uzavírací
    # značka je nejlevnější důkaz, že soubor byl dopsán celý.
    # (Odhaleno harness scénářem 30 při implementaci 3.5.120.)
    if "</settings>" not in text:
        return FILE_UNREADABLE, None

    # Otevírací značka se hledá ZVLÁŠŤ a to, zda je self-closing, se rozhoduje
    # z jejího konce — ne jedním výrazem přes celý element.
    #
    # 3.5.122 (incident bandog 28.08.2026, čerstvá instalace): původní výraz
    # `[^>]*(?:/>|>(.*?)</setting>)` měl vadu, kterou reálný výstup Kodi spolehlivě
    # trefí. Kodi (TinyXML) zapisuje prázdný setting jako
    #     <setting id="username" default="true" />
    # — s MEZEROU před lomítkem. `[^>]*` hltavě spolkl i to lomítko, větev `/>`
    # už neměla co chytit, a tak vyhrála větev `>(.*?)</setting>`, která
    # doběhla až k uzavírací značce NÁSLEDUJÍCÍHO settingu. „Hodnotou" prázdného
    # klíče se stal cizí XML text → FILE_HAS_VALUE → VERDICT_READ_FAILURE →
    # přihlašovací dialog potlačen a uživatel se nikdy nepřihlásí. Harness to
    # nechytil, protože ve fixture byl prázdný klíč POSLEDNÍ v souboru
    # (za ním žádný `</setting>`, výraz couvl a `/>` prošlo). Fixture teď
    # kopíruje skutečný zápis Kodi (scénář 30, případ I).
    #
    # `[^<>]` v atributech: značka nemůže přetéct do sousedního elementu ani
    # přeskočit `>`; lomítko smí stát jen bezprostředně před `>`. Hodnota je
    # `[^<]*`: Kodi zapisuje jen text (značky escapuje), takže první `<` musí být
    # uzavírací `</setting>` — cokoli jiného znamená neúplný element.
    open_tag = re.search(
        r'<setting\b(?P<attrs>[^<>]*?\bid="{}"[^<>]*?)(?P<selfclose>/?)>'.format(
            re.escape(key)
        ),
        text, re.IGNORECASE | re.DOTALL,
    )
    if open_tag is None:
        return FILE_KEY_MISSING, None
    if open_tag.group("selfclose"):
        return FILE_EMPTY, None
    body = re.match(
        r'([^<]*)</setting\s*>', text[open_tag.end():], re.IGNORECASE
    )
    if body is None:
        # Otevřená značka bez uzavření = element není celý → nelze rozhodnout.
        return FILE_UNREADABLE, None
    raw = body.group(1).strip()
    if not raw:
        return FILE_EMPTY, None
    return FILE_HAS_VALUE, raw


def diagnose_read(key):
    # type: (str) -> dict
    """Rozhodne, zda prázdné čtení znamená poruchu, nebo legitimní stav.

    Vrací slovník vhodný rovnou do `context` logu:
        {"key", "api_empty", "file_state", "verdict", "file_bytes", "file_mtime"}

    Rozhodovací tabulka (plán 3.5.120 §2/A1):
        API má hodnotu                      → VERDICT_OK
        API prázdné + soubor má hodnotu     → VERDICT_READ_FAILURE  (důkaz poruchy)
        API prázdné + soubor prázdný/bez klíče/bez souboru → VERDICT_NOT_CONFIGURED
        API prázdné + soubor nečitelný      → VERDICT_INCONCLUSIVE (fail-safe)

    NIKDY nevyhazuje — diagnostika nesmí být dalším zdrojem pádů.
    """
    result = {
        "key": key,
        "api_empty": True,
        "file_state": FILE_UNREADABLE,
        "verdict": VERDICT_INCONCLUSIVE,
        "file_bytes": None,
        "file_mtime": None,
    }
    try:
        api_value = _read_uncached(key)   # diagnostika cesty API — nikdy ze snímku (Φ4)
        result["api_empty"] = not bool(api_value)
        if api_value:
            result["verdict"] = VERDICT_OK

        state, _file_value = read_key_from_file(key)
        result["file_state"] = state

        try:
            path = settings_file_path()
            if path and os.path.isfile(path):
                stat = os.stat(path)
                result["file_bytes"] = int(stat.st_size)
                result["file_mtime"] = int(stat.st_mtime)
        except Exception:
            pass

        if api_value:
            return result

        if state == FILE_HAS_VALUE:
            result["verdict"] = VERDICT_READ_FAILURE
        elif state in (FILE_EMPTY, FILE_KEY_MISSING, FILE_NO_FILE):
            result["verdict"] = VERDICT_NOT_CONFIGURED
        else:
            result["verdict"] = VERDICT_INCONCLUSIVE
        return result
    except Exception:
        return result


def free_space_mb():
    # type: () -> Optional[int]
    """Volné místo (MB) na oddílu s profilem addonu, nebo None.

    Součást diagnostického bloku draineru — ověří/vyvrátí hypotézu „plný disk"
    bez toho, aby musel Richie shánět údaj po telefonu.
    """
    try:
        import shutil
        path = settings_file_path()
        target = os.path.dirname(path) if path else ""
        if not target or not os.path.isdir(target):
            return None
        return int(shutil.disk_usage(target).free / (1024 * 1024))
    except Exception:
        return None


# --------------------------------------------------------------------------- #
# Obecné čtení a OVĚŘENÝ zápis (3.5.124, Fáze B plánu 29.08.2026)
# --------------------------------------------------------------------------- #
#
# PROČ EXISTUJE ZÁPIS S OVĚŘENÍM
# ------------------------------
# Kodi umí zápis nastavení TIŠE ZTRATIT. Ověřeno ve zdroji Omega (`Addon.cpp`):
#   • `CAddon::SaveSettings` při selhání serializace soubor nepřepíše a přesto
#     vrátí `success = true` — Python `setSetting()` nic nehlásí (29.08.2026,
#     4× „failed to save addon settings" na Richieho PC),
#   • `CAddon::LoadSettings` si při jakémkoli selhání načtení definice nastaví
#     `m_loadSettingsFailed` a instance pak NAVŽDY vrací `""` pro každý
#     `getSetting` a `setSetting` je no-op — bez logu (profil incidentu bandog
#     26.08.2026: dlouhoběžící instance ve službě).
# Do 3.5.123 šlo 143 čtení/zápisů přes tři sdílené instance (`ADDON`,
# `self._addon`, `_nu_addon`) — každý zápis mohl zmizet a nikdo se to nedozvěděl.
#
# KONTRAKT
# --------
#   • Každé volání = NOVÁ instance `Addon(ADDON_ID)` (otrávená instance se
#     nedědí; viz `_addon()`).
#   • `write()` po zápisu PŘEČTE hodnotu DALŠÍ novou instancí. Neshoda =
#     `SETTINGS_WRITE_LOST` ERROR (routovaný na NAS) s diagnostikou souboru,
#     volným místem, délkou hodnoty a příznakem `has_non_bmp` (hypotéza F3:
#     4-bajtové UTF-8 v hodnotě) — a návrat False. Volající rozhodne, co to
#     pro něj znamená; identitní zápisy to hlásí uživateli.
#   • `write_identity()` je All-or-Nothing: když se kterýkoli ze tří klíčů
#     neuloží, předchozí hodnoty se kompenzačně vrátí.
#   • Čtení: `get_str()` vrací VŽDY str (drop-in za `getSetting`), `get_int()`
#     s defaultem. `get_bool()` existuje výše.
# Lint (harness scénář 41) nedovolí `get/setSetting` mimo tento modul.

_WRITE_VERIFY_ATTEMPTS = 1   # jedno zpětné čtení; Kodi drží hodnotu v paměti okamžitě


def get_str(key):
    # type: (str) -> str
    """Hodnota nastavení jako str (stripnutá), prázdná když není. Drop-in
    náhrada za `Addon().getSetting(key)` — nikdy None, nikdy výjimka."""
    return _read(key) or ""


def get_int(key, default=0):
    # type: (str, int) -> int
    raw = _read(key)
    if raw is None:
        return default
    try:
        return int(raw)
    except (TypeError, ValueError):
        return default


def _has_non_bmp(value):
    # type: (str) -> bool
    try:
        return any(ord(ch) > 0xFFFF for ch in value)
    except Exception:
        return False


def write(key, value):
    # type: (str, str) -> bool
    """Zapíše nastavení a OVĚŘÍ zpětným čtením novou instancí. True = hodnota
    je v Kodi; False = ztraceno (zalogováno ERROR `SETTINGS_WRITE_LOST`)."""
    if not key:
        return False
    text = "" if value is None else str(value)
    invalidate_snapshot()   # Φ4: po vlastním zápisu se snímek čte znovu (i kdyby otisk souboru nestihl)
    try:
        _addon().setSetting(key, text)
    except Exception as exc:
        _report_write_lost(key, text, "exception:%s" % type(exc).__name__)
        return False
    try:
        actual = _addon().getSetting(key)
    except Exception as exc:
        _report_write_lost(key, text, "verify_exception:%s" % type(exc).__name__)
        return False
    if (actual or "") == text:
        return True
    _report_write_lost(key, text, "mismatch", actual=actual)
    return False


def write_bool(key, value):
    # type: (str, bool) -> bool
    return write(key, "true" if value else "false")


def write_identity(username, password, token):
    # type: (str, str, str) -> bool
    """Webshare identita All-or-Nothing: buď se uloží všechny tři, nebo se
    vrátí předchozí stav. Polovičatá identita (jméno bez hesla) by při příštím
    startu vypadala jako „nenastaveno" a spustila přihlašovací dialog."""
    previous = {k: get_str(k) for k in ("username", "password", "token")}
    values = {"username": username or "", "password": password or "", "token": token or ""}
    written = []
    for k in ("username", "password", "token"):
        if write(k, values[k]):
            written.append(k)
            continue
        for done in reversed(written):
            write(done, previous[done])
        _log("SETTINGS_IDENTITY_WRITE_FAILED key=%s restored=%s" % (k, written),
             _LOGERROR, context={"failed_key": k, "restored": written})
        return False
    return True


def _report_write_lost(key, text, reason, actual=None):
    # type: (str, str, str, Optional[str]) -> None
    file_state, _val = read_key_from_file(key)
    ctx = {
        "key": key, "reason": reason, "value_len": len(text),
        "has_non_bmp": _has_non_bmp(text),
        "actual_len": len(actual or "") if actual is not None else None,
        "file_state": file_state, "free_mb": free_space_mb(),
    }
    _log("SETTINGS_WRITE_LOST key=%s reason=%s len=%d non_bmp=%s file=%s" % (
        key, reason, len(text), ctx["has_non_bmp"], file_state), _LOGERROR, context=ctx)


# Routovaný logger — až tady dole, aby modul zůstal importovatelný i když
# `richmovie_logging` (které samo čte nastavení) ještě není k dispozici.
try:
    import xbmc as _xbmc
    _LOGINFO, _LOGERROR = _xbmc.LOGINFO, _xbmc.LOGERROR
except Exception:  # pragma: no cover
    _xbmc = None  # type: ignore
    _LOGINFO, _LOGERROR = 1, 3

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.settings", "RichMovie/Settings")
except Exception:  # pragma: no cover
    def _log(msg, level=_LOGINFO, *, context=None):
        try:
            if _xbmc is not None:
                _xbmc.log("[RichMovie/Settings] %s" % msg, level)
        except Exception:
            pass
