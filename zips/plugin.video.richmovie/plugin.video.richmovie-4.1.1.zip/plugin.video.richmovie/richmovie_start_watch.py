# -*- coding: utf-8 -*-
"""RichMovie — hlídač startu přehrávání a stavové texty startu (Φ6, 29.09.2026, audit A05 R1/R7/F8–F12).

PROČ EXISTUJE
-------------
Mezi `onPlayBackStarted` (Kodi otevírá soubor) a `onAVStarted` (obraz a zvuk tečou) Kodi ukazuje jen
kolečko. U vadného souboru (Fastshare se skokem na pozici) tak divák 72–91 s nevidí nic a nemá cestu ven:
Zpět zavře kolečko, přehrávač ale otevírá dál a video pak „vyskočí“ uprostřed menu — Chromecast 27.09.
skončil pádem Kodi (A05 F8/F9). Detekce vadného souboru (3.5.158) přitom rozhodla až po DRUHÉM konci na
stejném místě, takže divák celé čekání prožil aspoň jednou navíc.

KONTRAKT
--------
Služba po `onPlayBackStarted` pustí vlákno, které po `TICK_S` volá čisté rozhodnutí
`next_action(elapsed_s, busy=…, done=…)` a provede vrácenou akci:
  • `slow`  — po `SLOW_NOTICE_S` tichý toast `SLOW_TEXT` (jednou),
  • `stall` — po `STALL_OFFER_S` započítat zaseknutí do `richmovie_source_health` (jen navázání na pozici),
  • `hint`  — kolečko Kodi ještě běží → jen toast `STALL_HINT_TEXT` („stiskni Zpět“); modální dialog nad
              kolečkem se neotevírá (souběh dvou busy dialogů = pád Kodi 21.2, A01),
  • `ask`   — kolečko už neběží → nabídka „Zkusit jiný stream / Čekat“ (jednou za otevření),
  • `wait` / `done`.
Vlákno končí, jakmile naskočí obraz, přehrávání skončí nebo začne jiné otevírání. Nikdy nic nezastaví
samo — T2 je nabídka, ne Stop (pomalé, ale funkční CDN jsou na Windows 16–17 s).

Stavové texty startu (autoplay, navázání, neotevřený stream) žijí tady, ať je jeden zdroj pravdy (R7).
Čisté funkce bez Kodi → harness scénář 78. Python 3.8 (Kodi runtime).
"""
from __future__ import annotations

import urllib.parse
from typing import AbstractSet, Optional

from richmovie_resume import format_time   # SSOT formátu času v toastech navazování

# T1: nejvyšší p90 doby otevření streamu mezi platformami za 60 dní (Android TV box 4,34 s, n=41;
# flotila p90 3,47 s, n=946 — `Temp/ux_latency_20260929/data/A05/07_open_split.txt`, `11_end_to_av_tail.txt`).
# Na žádné platformě tak text neuvidí víc než ~10 % zdravých startů.
SLOW_NOTICE_S = 4.3
# T2: nejpomalejší ÚSPĚŠNÝ start za 60 dní trval 28,65 s (Webshare, Chromecast); všech 7 startů nad 30 s
# byly vadné soubory (Fastshare se skokem na pozici, 72–91 s). Nad 30 s už čekání nic nepřineslo.
STALL_OFFER_S = 30.0
# Krok hlídače: text i nabídka se ukážou nejvýš 0,5 s po prahu (pod rozlišovací schopností diváka u 4,3 s / 30 s)
# a smyčka je jen porovnání čísel + 1–2 dotazy `getCondVisibility` — 2× za sekundu je pro Kodi zanedbatelné.
TICK_S = 0.5

ACTION_WAIT = "wait"
ACTION_SLOW = "slow"
ACTION_STALL = "stall"
ACTION_HINT = "hint"
ACTION_ASK = "ask"
ACTION_DONE = "done"

SLOW_TEXT = "Zdroj odpovídá pomalu – načítám…"
STALL_HINT_TEXT = "Tenhle zdroj se neotevírá. Stiskni Zpět – nabídnu jiný stream."
STALL_YES = "Zkusit jiný stream"
STALL_NO = "Čekat"
# Nabídka se po této době sama zavře jako „Čekat“: zaseknuté otevření Kodi vzdá ~75–90 s od startu (3× curl
# low-speed 20 s, A05 F8), tj. 45–60 s po T2 — potom už otázka nemá smysl a dialog by visel nad videem nebo menu.
STALL_ASK_AUTOCLOSE_MS = 60_000
OPEN_FAILED_TEXT = "Stream se nespustil – zkus jinou verzi."
AUTOPLAY_CANCELLED_TEXT = "Automatické přehrávání zrušeno."



def next_action(elapsed_s: float, *, busy: bool, done: AbstractSet[str]) -> str:
    """Co má hlídač udělat teď. `done` = akce, které už v tomto otevření proběhly."""
    try:
        elapsed = float(elapsed_s)
    except (TypeError, ValueError):
        return ACTION_WAIT
    if elapsed < SLOW_NOTICE_S:
        return ACTION_WAIT
    if ACTION_SLOW not in done:
        return ACTION_SLOW
    if elapsed < STALL_OFFER_S:
        return ACTION_WAIT
    if ACTION_STALL not in done:
        return ACTION_STALL
    if ACTION_ASK in done:
        return ACTION_DONE
    if busy:
        return ACTION_WAIT if ACTION_HINT in done else ACTION_HINT
    return ACTION_ASK


def stopped_by_user(open_elapsed_s: float, idle_s: float) -> bool:
    """Stop bez obrazu přišel od diváka? Ano, když se od začátku otevírání dotkl ovladače (Kodi
    `getGlobalIdleTime` = celé sekundy od posledního vstupu, proto +1). Rychlé selhání Kodi (stovky ms po
    otevření) i selhání v noci bez diváka tak zůstanou „Stream se nespustil“ (cross-check Pro A8)."""
    try:
        return float(idle_s) + 1.0 < float(open_elapsed_s)
    except (TypeError, ValueError):
        return False


def busy_visible() -> bool:
    """Běží kolečko Kodi (otevírání souboru, resolve pluginu)? Chyba čtení = ano (opatrnost: raději jen toast).
    Definice je jedna v celém doplňku: `richmovie_playback_dispatch.busy_dialog_active` (audit Fable F-5)."""
    import richmovie_playback_dispatch as _dispatch
    return _dispatch.busy_dialog_active(on_error=True)


def slow_text(os_filter: str = "") -> str:
    """Toast T1. Noc 03.11.2026 (Φ1): když start zdržuje systémový filtr obsahu (`richmovie_device_env`),
    zdroj za nic nemůže — divák dostane pravdivou větu (SSOT textu je `richmovie_device_env.stall_text`)."""
    if os_filter:
        import richmovie_device_env as _denv
        return _denv.stall_text(os_filter)
    return SLOW_TEXT


def stall_hint_text(os_filter: str = "") -> str:
    """Toast T2 nad kolečkem Kodi. Při filtru tatáž pravdivá věta + cesta ven (Zpět → jiný stream)."""
    if os_filter:
        import richmovie_device_env as _denv
        return "%s Stiskni Zpět – nabídnu jiný stream." % _denv.stall_text(os_filter)
    return STALL_HINT_TEXT


def stall_question(broken_at: Optional[float]) -> str:
    """Text nabídky po T2. Když zaseknutí rozhodlo o vadném souboru, řekne od kdy (pozice je v Pokračovat)."""
    if broken_at is not None:
        return ("Tenhle soubor se od %s neotevírá – je poškozený.\n"
                "Zkusit jiný stream, nebo ještě počkat?" % format_time(broken_at))
    return ("Tenhle zdroj se neotevírá ani po %d s.\n"
            "Zkusit jiný stream, nebo ještě počkat?" % int(STALL_OFFER_S))


def autoplay_start_text(play_url: str) -> Optional[str]:
    """„▶ Další díl S06E10 · Lék – spouštím…“ z URL, kterou autoplay spouští (A05 F12: dřív divák 2,5–8,5 s
    koukal na seznam minulého dílu a kolečko, toast s verzí přišel až s obrazem). None = URL nenese díl."""
    try:
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(play_url or "").query)
        season = int((qs.get("season") or ["0"])[0] or 0)
        episode = int((qs.get("episode") or ["0"])[0] or 0)
    except (TypeError, ValueError):
        return None
    if season <= 0 or episode <= 0:
        return None
    code = "S%02dE%02d" % (season, episode)
    title = ((qs.get("ep_title") or [""])[0] or "").strip()
    return "▶ Další díl %s%s – spouštím…" % (code, (" · " + title) if title else "")


def autoplay_heading(play_url: str) -> str:
    try:
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(play_url or "").query)
        return ((qs.get("tv_name") or [""])[0] or "").strip() or "RichMovie"
    except (TypeError, ValueError):
        return "RichMovie"


def auto_resume_text(position_s: object, attempt: int, max_attempts: int) -> str:
    """Toast navázání po utnutí streamu — kam a kolikátý pokus (R7)."""
    return "Zdroj přerušil stream – navazuji od %s (%d/%d)" % (
        format_time(position_s), int(attempt or 0), int(max_attempts or 0))
