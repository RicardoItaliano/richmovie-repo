# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_helpers.py
# Pomocné třídy a funkce – SearchCache + UI utility  (upraveno: 24.01.2026 19:30 CET, Europe/Prague)
# ⚠️ KODI PLUGIN: Proces-based architektura, lazy init pro session!
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Pomocné třídy a funkce
───────────────────────────────────────────────────────────────────────────────
Tento modul obsahuje:

  • **SearchCache**     – Perzistentní JSON cache s TTL (30 dní)
  • **UI utility**      – keyboard_input, modal, notif, progress, format_*

Centralizované utility pro použití napříč celým doplňkem.

API:
    SEARCH_CACHE.get(key)  -> Optional[Any]
    SEARCH_CACHE.put(key, value)
    build_key(prefix, *parts)  -> str

    keyboard_input(heading, hidden) -> str | None
    modal(msg, heading, block) -> None
    notif(msg, icon, ms, heading) -> None
    progress(total) -> xbmcgui.DialogProgress
    format_int_spaced(n) -> str
    format_mediainfo(mi) -> str

Autor: Richie – vytvořeno 28-07-2025, rozšířeno 24-01-2026
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY  (abecedně dle skupin)
# ─────────────────────────────────────────────────────────────────────────────
# — Standardní knihovna —
from __future__ import annotations

import datetime
import hashlib
import json
import os
import threading
from pathlib import Path
from typing import Any, Optional

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
_TTL_SECS: int = 30 * 24 * 60 * 60          # 30 dní
_ADDON      = xbmcaddon.Addon()
_PROFILE    = Path(
    xbmcvfs.translatePath(f"special://profile/addon_data/{_ADDON.getAddonInfo('id')}")
)
_PROFILE.mkdir(parents=True, exist_ok=True)
_CACHE_PATH = _PROFILE / "search_cache.json"


# ─────────────────────────────────────────────────────────────────────────────
#  TŘÍDA  SearchCache
# ─────────────────────────────────────────────────────────────────────────────
class SearchCache:
    """
    Perzistentní JSON cache s TTL (30 dní).

    Klíčem je libovolný hash‑friendly string, hodnota může být jakýkoliv
    JSON‑serializovatelný objekt (typicky list slovníků → Release).
    """

    # 2025‑07‑28 08:42 CEST  – __init__
    def __init__(self, path: Path = _CACHE_PATH, ttl: int = _TTL_SECS) -> None:
        self._path = path
        self._ttl  = ttl
        self._data: dict[str, dict[str, Any]] = {}
        self._loaded = False
        self._lock   = threading.Lock()
        self._stamp: Optional[tuple] = None     # otisk souboru (mtime_ns, velikost), ze kterého je `_data`


    # – interní – -------------------------------------------------------------
    def _now(self) -> int:
        return int(datetime.datetime.now().timestamp())


    # Φ-C (30.09.2026, E4-F04): cache sdílí VÍC procesů — každá invokace pluginu je nový interpret a služba
    # žije dny. Dřív si každý proces načetl soubor jednou a při zápisu ho CELÝ přepsal svou kopií (neatomicky,
    # s odsazením = 88 ms na Kodi 3.8): služba tak mazala záznamy, které mezitím zapsal plugin, a plugin
    # neviděl, co zapsala služba. Teď: čtení si hlídá otisk souboru, zápis nejdřív sloučí čerstvý stav disku
    # a píše atomicky a kompaktně (`richmovie_atomic.write_json`).
    def _file_stamp(self) -> Optional[tuple]:
        try:
            st = os.stat(str(self._path))
            return (int(st.st_mtime_ns), int(st.st_size))
        except OSError:
            return None

    _UNREADABLE = ("unreadable",)      # otisk „soubor se nepodařilo přečíst“ → příští čtení to zkusí znovu

    def _read_disk(self) -> Optional[dict]:
        """Obsah souboru cache. {} = soubor není nebo není JSON slovník (začíná se načisto);
        **None = soubor existuje, ale teď nejde přečíst** (zámek jiného procesu, antivirus). None se NESMÍ
        brát jako prázdná cache — zápis by pak přepsal záznamy všech procesů (cross-check Pro C2-P1)."""
        try:
            with open(self._path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
        except FileNotFoundError:
            return {}
        except ValueError as exc:
            self._warn("search cache is not valid JSON, starting fresh: %r" % (exc,))
            return {}
        except OSError as exc:
            self._warn("search cache unreadable now: %r" % (exc,))
            return None

    @staticmethod
    def _warn(text: str) -> None:
        try:
            xbmc.log("[RichMovie] %s" % text, xbmc.LOGWARNING)
        except Exception:
            pass

    def _load(self) -> None:
        """Načte soubor při prvním použití a znovu pokaždé, když ho mezitím změnil jiný proces."""
        stamp = self._file_stamp()
        if self._loaded and (self._stamp_current(stamp) or (stamp is None and self._stamp is None)):
            return
        with self._lock:
            stamp = self._file_stamp()
            if self._loaded and (self._stamp_current(stamp) or (stamp is None and self._stamp is None)):
                return
            disk = self._read_disk()
            if disk is None:
                # nečitelný soubor: pracuje se s tím, co je v paměti (poprvé s ničím), otisk zůstává
                # „nepřečteno“ → příští čtení i zápis si disk vyžádají znovu
                self._stamp = self._UNREADABLE
                self._loaded = True
                return
            self._data = disk
            self._stamp = stamp
            self._loaded = True
            self._purge_locked()


    def _flush_locked(self, changed: Optional[dict] = None) -> None:
        """Zapíše cache. `changed` = {klíč: záznam | None (smazat)} — změny TOHOTO procesu; aplikují se
        na ČERSTVÝ stav disku, takže se neztratí nic, co mezitím zapsal jiný proces."""
        import richmovie_atomic as _atomic
        # Φ-E (30.09.2026, cross-check Flash F16): „přečti disk → slouč → zapiš“ pod MEZIPROCESOVÝM zámkem —
        # bez něj mohl druhý proces zapsat mezi čtením a zápisem a jeho záznam se ztratil. Zámek je
        # best-effort (krátké čekání, UI nesmí stát); bez něj se zapíše jako dřív.
        with _atomic.FileLock(str(self._path) + ".lock", wait_s=self.LOCK_WAIT_S):
            self._flush_under_lock(changed, _atomic)

    def _flush_under_lock(self, changed: Optional[dict], _atomic: Any) -> None:
        try:
            if changed is not None and not self._stamp_current(self._file_stamp()):
                disk = self._read_disk()
                if disk is None:
                    self._warn("search cache write skipped (file unreadable, nothing overwritten)")
                    return
                for k, rec in changed.items():
                    if rec is None:
                        disk.pop(k, None)
                    else:
                        disk[k] = rec
                self._data = disk
                self._purge_locked()
            if _atomic.write_json(str(self._path), self._data, separators=(",", ":")):
                self._stamp = self._file_stamp()
        except Exception as exc:
            # zápis cache nesmí shodit doplněk — ale nesmí ani zmizet beze stopy
            self._warn("search cache write failed: %r" % (exc,))


    LOCK_WAIT_S = 0.5
    # Souborové systémy s hrubým časem (FAT / exFAT na TV boxech: 2 s): zápis jiného procesu se stejnou
    # velikostí by otisk nezměnil. Otisk mladší než tohle okno se proto nebere jako důkaz „beze změny“
    # (stejné pravidlo jako snímek nastavení, 3.5.163; audit Fable F1-V10).
    STAMP_TRUST_AFTER_S = 2.0

    def _stamp_current(self, stamp: Optional[tuple]) -> bool:
        """Je `self._data` jistě totéž co soubor s otiskem `stamp`?"""
        if stamp != self._stamp or not stamp or len(stamp) != 2:
            return False
        import time as _time
        return (_time.time() - stamp[0] / 1e9) >= self.STAMP_TRUST_AFTER_S

    def _expired(self, rec: Any, now: int) -> bool:
        """Záznam je po platnosti: obecné TTL cache, nebo vlastní kratší `ttl` záznamu (neúplný výsledek)."""
        if not isinstance(rec, dict):
            return True
        try:
            ttl = min(self._ttl, int(rec["ttl"])) if rec.get("ttl") else self._ttl
            return (now - int(rec.get("ts", 0) or 0)) > ttl
        except (TypeError, ValueError):
            return True

    def _purge_locked(self) -> None:
        """Odstraní všechny položky po platnosti."""
        now = self._now()
        stale = [k for k, v in self._data.items() if self._expired(v, now)]
        for k in stale:
            del self._data[k]


    # – veřejné API – ---------------------------------------------------------
    # 2025‑07‑28 08:42 CEST  – get()
    def get(self, key: str) -> Optional[Any]:
        """
        Vrátí hodnotu z cache nebo ``None`` (nenalezeno či expirované).
        """
        self._load()
        with self._lock:
            rec = self._data.get(key)
            if not rec:
                return None
            if self._expired(rec, self._now()):
                # Expirace → smazat a vrátit None
                del self._data[key]
                self._flush_locked({key: None})
                return None
            return rec.get("val")


    # 2025‑07‑28 08:42 CEST  – put()
    def is_partial(self, key: str) -> bool:
        """Záznam byl uložen s vlastní (kratší) platností = výsledek, který nebyl úplný."""
        self._load()
        with self._lock:
            rec = self._data.get(key)
            return bool(isinstance(rec, dict) and rec.get("ttl"))

    def put(self, key: str, value: Any, ttl_s: Optional[int] = None) -> None:
        """
        Zapíše (key, value) do cache a automaticky provede očistu starých
        záznamů. `ttl_s` = vlastní (kratší) platnost záznamu — pro výsledek, který není úplný.
        """
        self._load()
        with self._lock:
            rec = {"ts": self._now(), "val": value}
            if ttl_s:
                rec["ttl"] = int(ttl_s)
            self._data[key] = rec
            self._purge_locked()
            self._flush_locked({key: rec})


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_helpers.py › class SearchCache # clear (vytvořeno: 13.12.2025 11:39 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def clear(self) -> None:
        """
        Vymaže celou cache (RAM i disk).

        Důvod:
            Pro ruční „Reset cache vyhledávání" potřebujeme cache opravdu vyčistit
            hned v běžícím procesu (nečekat až do restartu Kodi).

        Bezpečnost:
            Mazání nesmí shodit doplněk – případné chyby disk I/O ignorujeme.
        """
        self._load()
        with self._lock:
            self._data = {}
            try:
                self._flush_locked()
            except Exception:
                # best effort – diskový zápis může selhat, ale RAM je vyčištěná
                pass


    # 2025-08-19 14:04 CEST (Europe/Prague) – build_key(): verze‑aware „cache bust"
    @staticmethod
    def build_key(prefix: str, *parts: str) -> str:
        """
        Vytvoří deterministický klíč pro perzistentní hledací cache.

        🔁 Verze v klíči:
            - Klíč nově zahrnuje i *verzi doplňku* získanou z addon.xml.
            - Po aktualizaci doplňku (nová verze) se změní i klíče → žádný
              „cache hit" a následuje plné nové vyhledání s uložením čerstvých
              výsledků.  Tím se obejde dlouhé TTL (30 dní) bez nutnosti ručně
              mazat cache.

        Formát:
            "{prefix}:v<addon_version>:<sha1(prefix|version|parts...)>"

        Pozn.:
            - Zbylé části klíče (roky apod.) se mohou vně ještě doplnit
              (viz engine: movie/allowed_years přidává sufix), to zůstává.
            - Staré položky s jinou verzí klíče jsou nedosažitelné a
              `SearchCache` je odstraní běžným TTL úklidem.
        """
        try:
            # _ADDON je definováno na úrovni modulu; načtení verze je levné
            ver = (_ADDON.getAddonInfo("version") or "").strip()
        except Exception:
            ver = ""  # bezpečný fallback (nezpůsobí výjimku)

        gen = f"v{ver}" if ver else "v0"
        # zahrňte prefix i generaci do hashovaného „blobu", aby změna verze
        # jednoznačně vedla na odlišný digest klíče
        blob = "||".join([prefix, gen] + [str(p) for p in parts])
        digest = hashlib.sha1(blob.encode("utf-8")).hexdigest()
        return f"{prefix}:{gen}:{digest}"


# — veřejná singleton instance —
SEARCH_CACHE = SearchCache()




# ═══════════════════════════════════════════════════════════════════════════════
#  UI UTILITY FUNKCE  (přidáno: 24.01.2026 19:30 CET, Europe/Prague)
# ═══════════════════════════════════════════════════════════════════════════════


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# keyboard_input  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def keyboard_input(heading: str, hidden: bool = False) -> str | None:
    """
    Zobrazí Kodi klávesnici a vrátí zadaný text nebo None při zrušení.

    Args:
        heading: Nadpis klávesnice
        hidden: True pro skryté zadávání (hesla)

    Returns:
        Zadaný text (stripped) nebo None pokud uživatel zrušil
    """
    kb = xbmc.Keyboard("", heading, hidden)
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else None




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# modal  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def modal(msg: str, heading: str = "RichMovie", block: bool = True) -> None:
    """
    Zobrazí modální dialog nebo toast notifikaci.

    Args:
        msg: Text zprávy
        heading: Nadpis dialogu
        block: True = blokující OK dialog, False = toast notifikace
    """
    if block:
        xbmcgui.Dialog().ok(heading, msg)
    else:
        notif(msg, xbmcgui.NOTIFICATION_INFO, None, heading)   # Φ2: jediné volání toastu je `notif`




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# notif  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague – bezpečná toast notifikace)
# ---------------------------------------------------------------------------- #
# Φ2 (29.09.2026, plán ux_latency D7, audit A10 F7): JEDNA řeč toastů. Dřív 58 přímých volání
# s 10 různými délkami a 115 z nich cinkalo i u běžné informace. Délka se odvozuje z textu:
# Kodi toast drží nejméně 1,5 s (`GUIDialogKaiToast.cpp:89`), čtení z TV ~60 ms na znak
# (≈ 17 znaků/s — běžné tempo čtení titulků); strop, aby dlouhá věta nevisela věčně.
TOAST_BASE_MS = 1500
TOAST_MS_PER_CHAR = 60
TOAST_MIN_MS = 2500
TOAST_MAX_MS = 8000


def toast_ms(msg: str) -> int:
    """Doba zobrazení toastu podle délky textu (SSOT, viz konstanty výše)."""
    n = len(str(msg or ""))
    return max(TOAST_MIN_MS, min(TOAST_MAX_MS, TOAST_BASE_MS + TOAST_MS_PER_CHAR * n))


def toast_sound(icon: int, sound: Optional[bool] = None) -> bool:
    """Cinknout? Výslovná volba volajícího platí; jinak jen varování a chyba (něco je špatně
    a chce to pozornost). Informace a průběh jsou tiché (D7: „žádné otravné cinkání“)."""
    if sound is not None:
        return bool(sound)
    return icon in (xbmcgui.NOTIFICATION_WARNING, xbmcgui.NOTIFICATION_ERROR)


def notif(
    msg: str,
    icon: int = xbmcgui.NOTIFICATION_INFO,
    ms: Optional[int] = None,
    heading: str = "RichMovie",
    sound: Optional[bool] = None,
) -> None:
    """
    Jednotný helper pro toast notifikace — JEDINÉ místo, které volá `Dialog().notification`
    (harness scénář 73 hlídá, že jinde přímé volání nepřibude).

    • Primárně: xbmcgui.Dialog().notification(...)
    • Fallback: zapíše hlášku do kodi.log (aby se nic neztratilo)

    Args:
        msg: Text notifikace
        icon: Ikona (NOTIFICATION_INFO, NOTIFICATION_WARNING, NOTIFICATION_ERROR)
        ms: Doba zobrazení v milisekundách; None = podle délky textu (`toast_ms`)
        heading: Nadpis notifikace
        sound: None = politika `toast_sound` (tiše info, zvuk u varování a chyb)
    """
    try:
        xbmcgui.Dialog().notification(heading, msg, icon,
                                      int(ms) if ms else toast_ms(msg), toast_sound(icon, sound))
    except Exception as exc:
        try:
            lvl = xbmc.LOGERROR if icon == xbmcgui.NOTIFICATION_ERROR else xbmc.LOGINFO
            try:
                from richmovie_logging import make_legacy_logger as _mll
                _mll("richmovie.notif", "RichMovie/NOTIF")(
                    f"{msg} (toast failed: {exc})", lvl,
                )
            except Exception:
                xbmc.log(f"[RichMovie/NOTIF] {msg} (toast failed: {exc})", lvl)
        except Exception:
            pass




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# net_error_message  (vytvořeno: 08.08.2026 13:05 CEST, Europe/Prague – Φ5)
# ---------------------------------------------------------------------------- #
def net_error_message(exc: BaseException) -> tuple[str, bool]:
    """Přeloží síťovou výjimku na lidskou českou hlášku.

    PROČ: 08.08.2026 dostal uživatel na obrazovku doslova
    ``Chyba TMDb: <urlopen error [Errno 101] Network is unreachable>``. To není
    chybová hláška, to je výpis pro vývojáře. Technický detail patří do logu
    (kde ho od Φ0 skutečně máme), na obrazovku patří věta, ze které je jasné,
    co se stalo a co s tím.

    Hláška se odvozuje z TŘÍDY chyby, ne z jejího textu — text se mění mezi
    platformami i verzemi Pythonu, třída ne.

    Args:
        exc: Zachycená výjimka. Rozbaluje se `__cause__` řetěz, protože moduly
             chybu obvykle přebalují (`TMDbError(str(e)) from e`) a původní typ
             je jediné, co nese použitelnou informaci.

    Returns:
        (hláška, je_přechodná). `je_přechodná=True` znamená „samo se to nejspíš
        spraví" → volající má použít nenápadnou notifikaci, ne blokující dialog.
    """
    # Rozbal na kořenovou příčinu (max 4 úrovně — hlouběji se reálná hierarchie
    # urllib/http.client/ssl nedostane a cyklická vazba by tu zacyklila smyčku).
    root: BaseException = exc
    for _ in range(4):
        cause = getattr(root, "__cause__", None)
        if not isinstance(cause, BaseException):
            break
        root = cause

    err_class = "permanent"
    is_local = False
    is_offline = False
    try:
        import richmovie_http as _http
        err_class = _http.classify(root)
        is_local = _http.is_local_network_error(root)
        is_offline = isinstance(root, _http.OfflineError) or isinstance(exc, _http.OfflineError)
    except Exception:
        pass

    # Breaker ví o výpadku i tehdy, když konkrétní chyba vypadá nevinně
    # (např. timeout na jednom volání uprostřed dlouhého výpadku).
    try:
        import richmovie_netstate as _ns
        if _ns.is_offline():
            is_offline = True
    except Exception:
        pass

    if is_offline or is_local:
        return ("Zařízení nemá připojení k internetu.", True)

    # 3.5.120: nepřečtené nastavení má přednost přede vším ostatním — je to
    # porucha zařízení, ne serveru, a rada „zkus to znovu" by byla k ničemu.
    # Hláška musí říct jediné, co uživateli reálně pomůže (a co u bandoga
    # 27.08.2026 nikdo nevěděl): restartovat Kodi.
    try:
        from richmovie_gate_transport import IdentityUnavailableError \
            as _IdentityUnavailable
        if isinstance(exc, _IdentityUnavailable) or isinstance(root, _IdentityUnavailable):
            return ("Nepodařilo se načíst přihlášení. Restartuj prosím Kodi.", True)
    except Exception:
        pass

    # 3.5.118: zamítnutá identita má přednost před obecným „data se nepodařilo
    # načíst" — uživatel potřebuje vědět, že má jít změnit heslo, ne zkoušet
    # to znovu. Až ZA offline větví: bez sítě je skutečná příčina výpadek.
    try:
        import richmovie_identity_state as _ident
        if _ident.is_rejected():
            return _ident.user_message()
    except Exception:
        pass

    # Φ2 (29.09.2026): výjimka, která už nese hotovou českou větu pro uživatele (Webshare
    # `APIError.user_message`, CLAUDE.md „texty do UI jen z … APIError.user_message“), ji dostane
    # beze změny — obecné „Data se nepodařilo načíst“ by zahodilo jediný užitečný údaj.
    for _cand in (exc, root):
        _um = getattr(_cand, "user_message", None)
        if isinstance(_um, str) and _um.strip():
            return (_um.strip(), False)

    if err_class == "ratelimit":
        # Není to výpadek — server nás jen brzdí. Opakovat hned nemá smysl.
        return ("Server je právě vytížený. Zkus to prosím za chvíli.", False)

    if err_class == "transient":
        text = ""
        try:
            text = ("%s %s" % (root, exc)).lower()
        except Exception:
            text = ""
        if "timed out" in text or "timeout" in text:
            return ("Server neodpovídá. Zkus to prosím znovu.", True)
        return ("Spojení se serverem se nepovedlo. Zkus to prosím znovu.", True)

    return ("Data se nepodařilo načíst.", False)




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# progress  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def progress(total: int) -> xbmcgui.DialogProgress:
    """
    Vytvoří a vrátí progress dialog pro vyhledávání.

    Args:
        total: Celkový počet kroků (pro procenta)

    Returns:
        Inicializovaný DialogProgress
    """
    dlg = xbmcgui.DialogProgress()
    dlg.create("RichMovie", "Probíhá vyhledávání…")
    dlg.update(0)
    return dlg




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# format_int_spaced  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# parse_server_datetime / format_local_datetime / format_local_date
# (vytvořeno: 05.09.2026 08:15 CEST, Europe/Prague – 3.5.133, Richie: „last: 2026-09-05T05:00 je neintuitivní")
# ---------------------------------------------------------------------------- #
_CZ_MONTHS_GEN = ("ledna", "února", "března", "dubna", "května", "června", "července",
                  "srpna", "září", "října", "listopadu", "prosince")


def parse_server_datetime(value: Any) -> Optional[datetime.datetime]:
    """ISO 8601 z Gate/Postgresu (`2026-09-05T05:00:11.9+00:00`, `…Z`, s mezerou
    místo `T`, i bez zóny = UTC) → aware datetime v LOKÁLNÍM čase zařízení.
    None = prázdné/neparsovatelné (volající rozhodne o fallbacku)."""
    if value is None:
        return None
    if isinstance(value, datetime.datetime):
        dt = value
    else:
        raw = str(value).strip()
        if not raw:
            return None
        raw = raw.replace("Z", "+00:00")
        if "T" not in raw and " " in raw[:11]:
            raw = raw.replace(" ", "T", 1)
        try:
            dt = datetime.datetime.fromisoformat(raw)
        except ValueError:
            try:
                dt = datetime.datetime.fromisoformat(raw[:19])
            except ValueError:
                return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone.utc)
    try:
        return dt.astimezone()
    except (ValueError, OverflowError):
        return None


def format_local_datetime(value: Any, default: str = "nikdy", *,
                          now: Optional[datetime.datetime] = None) -> str:
    """SSOT lidského zápisu času pro UI: `dnes 07:00`, `včera 21:14`,
    `5. září 07:00` (letos), `5. 9. 2025 07:00` (jiný rok). Lokální čas."""
    dt = parse_server_datetime(value)
    if dt is None:
        return default
    ref = (now or datetime.datetime.now(datetime.timezone.utc)).astimezone(dt.tzinfo)
    hm = "{:02d}:{:02d}".format(dt.hour, dt.minute)
    delta_days = (ref.date() - dt.date()).days
    if delta_days == 0:
        return "dnes " + hm
    if delta_days == 1:
        return "včera " + hm
    if dt.year == ref.year:
        return "{}. {} {}".format(dt.day, _CZ_MONTHS_GEN[dt.month - 1], hm)
    return "{}. {}. {} {}".format(dt.day, dt.month, dt.year, hm)


def format_local_date(value: Any, default: str = "?") -> str:
    """Jen datum, lokální čas: `5. 9. 2026`."""
    dt = parse_server_datetime(value)
    if dt is None:
        return default
    return "{}. {}. {}".format(dt.day, dt.month, dt.year)


def format_int_spaced(n: int) -> str:
    """
    Formátuje celé číslo s mezerami jako oddělovači tisíců.

    Příklad:
        10000 → '10 000'

    Args:
        n: Celé číslo k formátování

    Returns:
        Formátovaný řetězec
    """
    return f"{n:,}".replace(",", " ")




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# format_mediainfo  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def format_mediainfo(mi: dict) -> str:
    """
    Převod MediaInfo slovníku na čitelný blok textu.
    Zobrazujeme jen to podstatné – container, video, audio, titulky.

    Args:
        mi: Slovník s MediaInfo daty (duration, tracks)

    Returns:
        Formátovaný textový blok nebo fallback zpráva
    """
    if not mi:
        return "MediaInfo nebyla k dispozici."

    out = []

    # – container / délka –
    dur = mi.get("duration", 0)
    if dur:
        out.append(f"CONTAINER  …  {dur//60} min {dur%60:02d} s")

    # – tracky –
    for t in mi.get("tracks", []):
        tt = t.get("track_type", "")
        if tt == "Video":
            out.append(
                "VIDEO      …  "
                f"{t.get('format', '')} {t.get('bit_depth', '')}‑bit  "
                f"{t.get('width', '')}×{t.get('height', '')}@{t.get('frame_rate', '')}fps  "
                f"{t.get('hdr_format', '')}".strip()
            )
        elif tt == "Audio":
            lang = t.get("language", "").upper() or "und"
            out.append(
                "AUDIO      …  "
                f"{t.get('format', '')} {t.get('channel_s', '')}  "
                f"{lang}"
            )
        elif tt == "Text":
            lang = t.get("language", "").upper() or "und"
            out.append(f"SUBTITLES …  {lang}  ({t.get('format', '')})")

    return "\n".join(out) or "Žádná MediaInfo data."




# ═══════════════════════════════════════════════════════════════════════════════
#  ALIASY PRO ZPĚTNOU KOMPATIBILITU
# ═══════════════════════════════════════════════════════════════════════════════
# Tyto aliasy umožňují použít funkce s prefixem _ jako dříve v plugin.py
# Po dokončení refaktoringu (Fáze 2) je můžeme odstranit.

_keyboard_input = keyboard_input
_modal = modal
_notif = notif
_progress = progress
_format_int_spaced = format_int_spaced
_format_mediainfo = format_mediainfo
