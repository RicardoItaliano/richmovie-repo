# -*- coding: utf-8 -*-
"""RichMovie — JEDNO spuštění přehrávání napříč procesy (Φ1, 29.09.2026).

PROČ EXISTUJE (pád Kodi 29.09.2026 12:59, Richie-Home; 27.09. Chromecast; TESLA box; Philips TV)
-------------------------------------------------------------------------------------------------
Kodi 21.2 převádí `plugin://` adresu na stream (resolve) na HLAVNÍM vlákně a po 20 + 200 ms ukáže
busy dialog (`ScriptRunner.cpp:131–146`). Smyčka toho dialogu vyřizuje frontu zpráv — tedy i další
`PlayMedia`, který mezitím poslal jiný proces. Druhý resolve otevře druhý busy dialog a Kodi 21.2
schválně skončí: `GUIDialogBusy.cpp:83–87` „Logic error due to two concurrent busydialogs … The
application will exit.“ (Kodi 21.3 throw odstranil, ale dvojí přehrání zůstává.)

Do 3.5.159 tohle nikdo nehlídal: položka „Pokračovat“ byla tichá akce (handle −1, 1–7 s bez odezvy),
lidé klikli znovu, dvě invokace poslaly dva `PlayMedia` → pád. Totéž hrozí u klik × autoplay služby.
Časová okna (`play_debounce` 2 s, `nav_debounce` 1,2 s) platila jen v novém vzhledu (2 z 353 sessions)
a nebyla svázaná s tím, jestli první přehrání už běží (audity A01, A02, A10).

KONTRAKT (jediné místo, odkud smí jít programové přehrání `plugin://` adresy)
------------------------------------------------------------------------------
    request(url, source="cw")            # PlayMedia z invokace bez handle / služby / vlastního okna
    token = begin_resolve(ident, "click")# `_play` na vstupu (převezme odeslání, nebo claimne sám)
    note_resolved(token)                 # hned po `setResolvedUrl(True)` → stav „otevírání“
    end_resolve(token)                   # `_play` ve `finally` — uvolní, když resolve neskončil úspěchem
    finish(reason)                       # služba: AVStarted / Stopped / Ended / Error → uvolnit
    refresh_container(reason)            # 4.0.1: JEDINÉ programové `Container.Refresh` — ne během startu
                                         # přehrávání ani při busy dialogu (pád Kodi 09.10.2026, viz konec souboru);
                                         # 4.0.2: ani když existuje přehrávač (i pozastavený) — akce na klik se odloží
    request_refresh(path, reason, why)   # S18 (4.0.4): JEDNA fronta odložených obnov výpisu (akce na klik i D11)
    flush_refresh_queue()                # služba (tik, D11 po zápisu) dožene obnovu výpisu na obrazovce, až to půjde

Stav jednoho startu: ODESLÁNO → RESOLVE → OTEVÍRÁNÍ → (AVStarted | chyba) = konec. Po celou dobu drží
meziprocesový claim `richmovie_guard` „playback_start“. Druhý požadavek v tu dobu = krátký tichý toast
„Už to spouštím…“ a NIC dalšího (žádné druhé `PlayMedia`). TTL každého stavu je pojistka proti
sirotkovi (nativní pád procesu), ne odhad délky: stav se prodlužuje při každém přechodu a uvolňuje se
explicitně na všech známých koncích.

Známá mez (vědomě): mezi odesláním `PlayMedia` a jeho zpracováním Kodi je okno jednotek ms — ruční
klik na přehratelnou položku přesně v tu chvíli by se na Kodi 21.2 mohl stále vnořit. Úplně ho zavře
jen Kodi 21.3 (plán D8). Pojistka proti tomu, co se reálně dělo (dvojklik, klik × autoplay), je úplná.

Python 3.8 (Kodi runtime).
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import threading
import time
import uuid
from typing import Any, Dict, Iterator, Optional, Tuple

import richmovie_guard as _guard
from richmovie_winprops import clear_prop as _clear_prop
from richmovie_winprops import get_prop as _get_prop
from richmovie_winprops import set_prop as _set_prop
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)

try:  # pragma: no cover - mimo Kodi (harness má stuby)
    import xbmc
    import xbmcgui
except ImportError:  # pragma: no cover
    xbmc = None  # type: ignore
    xbmcgui = None  # type: ignore

GUARD_NAME = "playback_start"
PROP_STATE = "richmovie.play.dispatch"

STAGE_DISPATCHED = "dispatched"   # PlayMedia / Player.play odeslán, `_play` ještě neběží
STAGE_RESOLVING = "resolving"     # `_play` běží (resolve streamu pod busy dialogem Kodi)
STAGE_OPENING = "opening"         # `setResolvedUrl(True)` → Kodi otevírá stream, čeká se na obraz

# TTL stavů — pojistka proti sirotkovi, odvozená z naměřených dob (audity 29.09.2026):
#: Odesláno → první řádek `_play`: flotila p90 5,2 s (Android TV, A03 T3b), Chromecast p90 4,2 s;
#: čtyřnásobek kryje nejpomalejší boxy. Když Kodi `PlayMedia` zahodí, claim po tomhle vyprší.
TTL_DISPATCHED_S = 20.0
#: Resolve v `_play`: nejdelší síťová cesta je rozpočet `richmovie_http.profile_background` (60 s).
#: `_play` claim VŽDY uvolní ve `finally`; TTL platí jen po nativním pádu procesu.
TTL_RESOLVING_S = 60.0
#: Otevírání streamu: nejdelší legitimní otevření ve flotile 91 s (vadný zdroj, Kodi curl retry,
#: A05 F8). Služba uvolní na AVStarted / Stopped / Ended / Error dřív.
TTL_OPENING_S = 120.0
#: Jak dlouho počkat, než zmizí CIZÍ busy dialog (načítání adresáře), než pošleme `PlayMedia`
#: (na Kodi 21.2 by se jinak resolve vnořil do jeho smyčky = pád). Nejdelší běžné načítání:
#: znovunačtení seznamu po Stopu p90 11 s (A03 F7).
BUSY_WAIT_MAX_S = 15.0
_BUSY_POLL_S = 0.1

BUSY_TEXT = "Už to spouštím…"
KODI_BUSY_TEXT = "Kodi ještě něco načítá – zkus to prosím za chvilku."


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › stav
# (vytvořeno: 29.09.2026 14:59 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _log(msg: str, warning: bool = False) -> None:
    """Do user_logs (routovaný logger), fallback kodi.log. Nikdy nevyhazuje."""
    try:
        import richmovie_logging as _rl
        lg = _rl.get_logger("richmovie.dispatch")
        (lg.warning if warning else lg.info)(msg)
    except Exception:
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/Dispatch] %s" % msg, xbmc.LOGWARNING if warning else xbmc.LOGINFO)
        except Exception:
            pass


def read_state() -> Dict[str, Any]:
    """Aktuální start přehrávání (prázdný slovník = nic neběží nebo je stav nečitelný)."""
    try:
        raw = _get_prop(PROP_STATE, "")
        data = json.loads(raw) if raw else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_state(state: Dict[str, Any]) -> None:
    try:
        _set_prop(PROP_STATE, json.dumps(state, ensure_ascii=False, sort_keys=True))
    except Exception as exc:
        # bez zapsaného stavu pojistka jednoho startu neplatí → musí to být vidět (cross-check Flash Q12)
        _log("PLAY_DISPATCH_STATE_WRITE_FAILED err=%r" % (exc,), warning=True)


def _clear_state(token: str) -> None:
    """Smaže stav jen když patří tomuto tokenu (cizí novější start se nesmí smazat)."""
    st = read_state()
    if not st or st.get("token") == token:
        try:
            _clear_prop(PROP_STATE)
        except Exception as exc:
            _log("PLAY_DISPATCH_STATE_CLEAR_FAILED err=%r" % (exc,), warning=True)


def is_starting() -> bool:
    """Probíhá právě spouštění přehrávání (claim drží živý start)?"""
    return _guard.is_claimed(GUARD_NAME)


def _notify(text: str) -> None:
    """Krátký TICHÝ toast (žádné cinknutí — druhý klik není chyba, jen „mám to“)."""
    try:
        if xbmcgui is not None:
            _rm_notif(text, xbmcgui.NOTIFICATION_INFO, 2500, "RichMovie", sound=False)
    except Exception:
        pass


def notify_busy() -> None:
    """Tichý toast „Už to spouštím…“ (druhý klik během startu) — pro `_play`, které start odmítne."""
    _notify(BUSY_TEXT)


def busy_dialog_active(on_error: bool = False) -> bool:
    """Běží v Kodi busy dialog (resolve / načítání adresáře)? Na 21.2 do něj nesmí vletět další resolve ani
    modální dialog. JEDINÁ definice v doplňku (audit Fable F-5, 29.09.2026) — `on_error` = odpověď, když se
    stav nedá přečíst: odesílání startu chce spíš poslat (False), hlídač startu spíš mlčet (True)."""
    if xbmc is None:
        return False
    try:
        return bool(xbmc.getCondVisibility("Window.IsActive(busydialog)")
                    or xbmc.getCondVisibility("Window.IsActive(busydialognocancel)"))
    except Exception:
        return bool(on_error)


def _url_ident(url: str) -> str:
    """Ident streamu z `plugin://…?ident=…` (autoplay / navázání ho nesou v URL); "" = není."""
    try:
        import urllib.parse as _up
        return ((_up.parse_qs(_up.urlparse(url or "").query).get("ident") or [""])[0] or "").strip()
    except Exception:
        return ""


def _wait_busy_clear(max_s: float) -> bool:
    """Počká, až zmizí cizí busy dialog (max `max_s`); True = volno. Nikdy `time.sleep` (abort okno)."""
    if not busy_dialog_active():
        return True
    if xbmc is None:
        return False
    mon = xbmc.Monitor()
    deadline = time.monotonic() + float(max_s)
    while time.monotonic() < deadline:
        if mon.waitForAbort(_BUSY_POLL_S):
            return False
        if not busy_dialog_active():
            return True
    return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › request
# (vytvořeno: 29.09.2026 14:59 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def request(url: str, *, source: str, key: str = "", ident: str = "", noresume: bool = True,
            via_player: bool = False, listitem: Any = None, notify_busy: bool = True,
            wait_busy: bool = True) -> bool:
    """Programové spuštění přehrávání `plugin://` adresy — JEDINÁ povolená cesta.

    Vrací True = požadavek odeslán; False = neodesláno (už se spouští jiné přehrání, nebo Kodi
    stále načítá). Volající v tom případě NIC dalšího nespouští.

    `via_player=True` = `xbmc.Player().play(url, listitem)` (obnova spojení za běhu: nový soubor bez
    opuštění fullscreenu, viz CLAUDE.md „NAVÁZÁNÍ NA POZICI“); jinak builtin `PlayMedia(url[,noresume])`.
    `notify_busy=False` pro práci bez uživatele (autoplay): odmítnutí jen do logu.
    """
    token = _guard.claim(GUARD_NAME, TTL_DISPATCHED_S)
    if token is None:
        st = read_state()
        _log("PLAY_DISPATCH_BUSY source=%s key=%s held_by=%s/%s" % (
            source, key or "-", st.get("source") or "?", st.get("stage") or "?"))
        if notify_busy:
            _notify(BUSY_TEXT)
        return False
    state = {"token": token, "stage": STAGE_DISPATCHED, "source": source, "key": key or "",
             "ident": ident or _url_ident(url), "since": time.time(), "id": uuid.uuid4().hex[:12]}
    _write_state(state)
    if wait_busy and not _wait_busy_clear(BUSY_WAIT_MAX_S):
        _log("PLAY_DISPATCH_KODI_BUSY source=%s key=%s (busy dialog nezmizel do %.0f s)"
             % (source, key or "-", BUSY_WAIT_MAX_S), warning=True)
        _clear_state(token)
        _guard.release(GUARD_NAME, token)
        if notify_busy:
            _notify(KODI_BUSY_TEXT)
        return False
    # Trvalá stopa PŘED odesláním: když Kodi spadne mezi odesláním a `_play`, telemetrie to uvidí
    # (dřív 4 z 5 pádů po dvojkliku v PRIOR_SESSION_UNCLEAN_EXIT chyběly — audit A01 F7).
    try:
        import richmovie_breadcrumb as _rbc
        _rbc.checkpoint("play_dispatch", source=source, key=key or "-", dispatch_id=state["id"])
    except Exception:
        pass
    _log("PLAY_DISPATCH source=%s key=%s ident=%s id=%s" % (source, key or "-", ident or "-", state["id"]))
    try:
        if via_player:
            if listitem is not None:
                xbmc.Player().play(url, listitem)
            else:
                xbmc.Player().play(url)
        else:
            xbmc.executebuiltin("PlayMedia(%s%s)" % (url, ",noresume" if noresume else ""))
        return True
    except Exception as exc:
        _log("PLAY_DISPATCH_FAILED source=%s err=%r" % (source, exc), warning=True)
        _clear_state(token)
        _guard.release(GUARD_NAME, token)
        return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › begin_resolve / note_resolved / end_resolve
# (vytvořeno: 29.09.2026 14:59 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def begin_resolve(ident: str, source: str = "click") -> Optional[str]:
    """`_play` na vstupu: převezmi odeslaný start (stav ODESLÁNO), nebo claimni vlastní (ruční klik
    na přehratelnou položku). Vrací token, nebo None = jiné spouštění už běží → `_play` musí skončit
    `setResolvedUrl(False)` bez práce (druhé přehrání by se jinak rozjelo souběžně)."""
    st = read_state()
    token = st.get("token") if st.get("stage") == STAGE_DISPATCHED else None
    sent_ident = str(st.get("ident") or "")
    if token and sent_ident and ident and sent_ident != ident:
        # Audit Fable F-3: odeslaný start patří JINÉMU streamu (autoplay X, divák mezitím klikl na Y) — převzetím by
        # přehrání Y běželo pod cizím tokenem a zdrojem; Y ustoupí („Už to spouštím…“), X doběhne.
        _log("PLAY_RESOLVE_IDENT_MISMATCH ident=%s sent=%s source=%s" % (ident, sent_ident, st.get("source") or "?"))
        token = None
    if token and _guard.renew(GUARD_NAME, token, TTL_RESOLVING_S):
        st.update({"stage": STAGE_RESOLVING, "ident": ident or st.get("ident") or ""})
        _write_state(st)
        return token
    token = _guard.claim(GUARD_NAME, TTL_RESOLVING_S)
    if token is None:
        held = read_state()
        _log("PLAY_RESOLVE_BUSY ident=%s held_by=%s/%s" % (ident or "-", held.get("source") or "?",
                                                           held.get("stage") or "?"))
        return None
    _write_state({"token": token, "stage": STAGE_RESOLVING, "source": source, "key": "",
                  "ident": ident or "", "since": time.time(), "id": uuid.uuid4().hex[:12]})
    return token


def note_resolved(token: Optional[str], ident: str = "") -> None:
    """TĚSNĚ PŘED `setResolvedUrl(True)`: stav OTEVÍRÁNÍ, delší TTL, `ident` = stream, který se skutečně předává
    (fallback ident); uvolní ho služba na AVStarted/chybě téhož streamu. Před předáním, ne po něm (audit Fable F-2):
    AVStarted rychlého streamu jinak mohl přijít ještě ve stavu RESOLVE, zahodit se a claim by držel až TTL."""
    if not token:
        return
    if _guard.renew(GUARD_NAME, token, TTL_OPENING_S):
        st = read_state()
        if st.get("token") == token:
            st["stage"] = STAGE_OPENING
            st["resolved_at"] = time.time()
            if ident:
                st["ident"] = ident
            _write_state(st)


def end_resolve(token: Optional[str]) -> None:
    """`_play` ve `finally`: resolve neskončil úspěchem (stav není OTEVÍRÁNÍ) → uvolnit hned, jinak by
    se další klik do vypršení TTL odmítal („Už to spouštím…“ bez přehrávání)."""
    if not token:
        return
    st = read_state()
    if st.get("token") == token and st.get("stage") == STAGE_OPENING:
        return
    _clear_state(token)
    _guard.release(GUARD_NAME, token)


def finish(reason: str, ident: str = "") -> Optional[int]:
    """Služba: přehrávač ohlásil konec otevírání — `av_started` (obraz) nebo selhání (`open_failed`,
    `error`). Uvolní claim startu a zaloguje dobu od odeslání. Vrací ms od odeslání, None = nic.
    `ident` = stream, kterému událost patří (služba ho zná z `onPlayBackStarted`; "" = neznámý).

    Událost CIZÍHO streamu (konec předchozího souboru, když Kodi přepíná na nový) start neuvolní — pustilo by to
    druhý resolve do běžícího otevírání (pád na Kodi 21.2). Ve stavu RESOLVE (živá invokace `_play`, ta stav
    sama posune nebo uvolní) se uvolní jen prokazatelně vlastní událost (audit Fable F-2)."""
    st = read_state()
    token = st.get("token")
    if not token:
        return None
    own = str(st.get("ident") or "")
    if ident and own and ident != own:
        _log("PLAY_DISPATCH_FOREIGN_EVENT reason=%s ident=%s own=%s → start drží dál" % (reason, ident, own))
        return None
    if st.get("stage") == STAGE_RESOLVING and not (ident and own and ident == own):
        return None
    ms = None
    try:
        ms = int((time.time() - float(st.get("since") or 0)) * 1000)
    except Exception:
        ms = None
    _clear_state(token)
    _guard.release(GUARD_NAME, token)
    _log("PLAY_DISPATCH_DONE reason=%s source=%s key=%s id=%s stage=%s ms=%s" % (
        reason, st.get("source") or "?", st.get("key") or "-", st.get("id") or "-",
        st.get("stage") or "?", ms if ms is not None else "-"))
    return ms


# ═════════════════════════════════════════════════════════════════════════════
#  BRÁNA PROGRAMOVÉHO `Container.Refresh` (4.0.1, pád Kodi na Sony BRAVIA 09.10.2026)
# ═════════════════════════════════════════════════════════════════════════════
#
# PROČ ŽIJE TADY: dispatcher je jediné místo programového přehrání (lint 72) a jediná definice „Kodi něco
# načítá“ (`busy_dialog_active`). Programová obnova kontejneru a start přehrávání jsou dvě strany téhož
# závodu — o obou proto rozhoduje jedna autorita (plán `Handoff/PLAN_crash_refresh_forced_subs_20261009.md` D1).
#
# INCIDENT (tombstone Androidu, Sony BRAVIA 4K UR3, Kodi 21.2): MI2 v 20:16:40,78 zavolal `Container.Refresh`
# 1,3 s po `VideoPlayer::OpenFile` (start ve stavu OTEVÍRÁNÍ). Kodi znovu spustilo výpis `tv_play`, pak kvůli
# celé obrazovce opouštělo okno Videa a na rozběhlé načítání čekalo jen 5 s (`CGUIMediaWindow::CancelUpdateItems`).
# Plugin se za tu dobu dokončit nemohl (jeho volání Kodi API stála na GUI zámku čekajícího hlavního vlákna),
# Kodi zahodilo objekt načítání (`CGetDirectoryItems` na zásobníku + `ReleaseDirImpl`) a job worker čekající ve
# `CScriptRunner::WaitOnScriptResult` sáhl do uvolněné paměti → SIGSEGV, pád celé aplikace
# (Kodi 21.2-Omega `xbmc/windows/GUIMediaWindow.cpp:2208–2302`, `xbmc/interfaces/generic/ScriptRunner.cpp:122–163`).
#
# Akce z kontextového menu (`RunPlugin`, `RunScriptWithParams`) Kodi spouští asynchronně BEZ busy dialogu
# (`ScriptRunner::ExecuteScript`), takže pravidlo „busy dialog“ legitimní obnovu po kliknutí neblokuje.

#
# OKNO PŘED CLAIMEM (D2b): po kliku na přehratelnou položku Kodi plugin nejdřív 20 + 200 ms resolvuje BEZ busy
# dialogu (`ScriptRunner.cpp:131–146`) a claim `playback_start` přijde až v `_play` po importu pluginu (Sony
# 09.10.: `import_ms=815`). V tom okně start nevidí claim ani busy dialog. Refresh Z POZADÍ (MI2, D11) proto navíc
# ustoupí, když divák „pracuje“ — SSOT `richmovie_activity.should_yield()` (běží invokace pluginu, nebo vstup
# z ovladače v posledních `USER_ACTIVE_IDLE_S`; klik nastaví obojí dřív než claim). Akce na klik (refresh je reakce
# na tentýž vstup, Kodi je spouští asynchronně bez busy dialogu) tohle pravidlo nemají.
#
# PŘEHRÁVAČ EXISTUJE (4.0.2, BACKLOG S11, plán `Handoff/PLAN_paused_player_refresh_20261010.md` E1–E7): stejný pád
# hrozí i bez startu. Video je pozastavené (nebo hraje) za menu, doplněk spustí obnovu výpisu a divák mezitím zmáčkne
# „zpět na video“. Kodi tu akci vyřizuje DŘÍV než modální busy dialog obnovy (`CApplication::OnAction` → `ACTION_SHOW_GUI`
# → `CGUIWindowManager::SwitchToFullScreen`, Kodi 21.2 `Application.cpp` začátek `OnAction`, `GUIWindowManager.cpp:932–977`),
# opustí okno Videa a na rozběhlé načítání čeká zase jen 5 s. Hlavní menu po obnově se na pomalých boxech staví 5–11 s
# (user_logs 30 dní: Nokia Streaming Box 5 010 a 10 586 ms + import 2–5 s, TCL 3,6 s). Proto: dokud existuje přehrávač
# (`Player.HasMedia` = `CApplicationPlayer::IsPlaying()`, pravda i v pauze), programová obnova NEPROBĚHNE. Pozadí čeká
# (D11) nebo zahodí (MI2); akce na klik se ODLOŽÍ — Kodi po zastavení videa výpis znovu nenačte, jen překreslí
# (`GUI_MSG_PLAYBACK_STOPPED` → `GUI_MSG_REFRESH_LIST`, `GUIMediaWindow.cpp:470–480`), takže by změna po kliknutí
# (třeba odebraný titul z Pokračovat) zůstala vidět až do dalšího otevření.

#: Důvody odmítnutí (hodnota `why=` v logu `CONTAINER_REFRESH_SKIP`; D11 je propisuje do „menu refresh čeká: …“).
REFRESH_BLOCK_ABORT = "abort"
REFRESH_BLOCK_STARTING = "playback_starting"
REFRESH_BLOCK_PLAYER = "player_active"
REFRESH_BLOCK_FOLLOWUP = "playback_followup"
REFRESH_BLOCK_BUSY = "kodi_busy"
REFRESH_BLOCK_USER_ACTIVE = "user_active"

# RELACE PŘEHRÁVÁNÍ (4.0.2, plán E9): mezi koncem dílu a navazující akcí služby (autoplay dalšího dílu, navázání po
# utnutí, navigace na seznam streamů, dialog po konci, návrat do RichMovie) přehrávač neexistuje a claim startu ještě
# nevznikl (`service_nextup._autoplay_safely`: čekání na zavření celé obrazovky ≤ 5 s + 0,5 s + „Díváš se ještě?“). Obnova
# výpisu v té mezeře by spustila načítání a `PlayMedia` dalšího dílu by Kodi zpracovalo UVNITŘ smyčky jeho busy dialogu
# (prvních ~100 ms dialog ještě není vidět, takže `request` → `_wait_busy_clear` projde) = start během načítání,
# mechanismus pádu 4.0.1. Relaci drží JEN služba: `session_note` z tiku a z `onAVStarted`, `followup_begin` /
# `followup_end` kolem každé navazující akce (`service_nextup._spawn_followup` — započítá ji už v místě spuštění)
# a `session_end_seen` na konci callbacků Stopped / Ended / Error. Brána ji čte přes Window(10000) — vidí ji i plugin
# (MI2, akce na klik).

#: Claim relace. TTL = SIGNÁL ŽIVOSTI, ne časové okno: služba ho obnovuje každý tik (`service_nextup._CHECK_EVERY` 5 s)
#: a během každé navazující akce; 30 s = šest zmeškaných tiků → vlastník je mrtvý (nativní pád, restart služby).
SESSION_GUARD = "playback_session"
TTL_SESSION_S = 30.0
#: Konec relace: tik bez přehrávače a bez navazující akce ji ukončí, když už doběhl callback konce přehrávání
#: (`session_end_seen` — navazující akce jsou v tu chvíli spuštěné a započítané). Jinak až DRUHÝ takový tik — a to je
#: deterministické, ne odhad: Kodi 21.2 doručuje callbacky přehrávače JEN ve vlákně, které objekt přehrávače vytvořilo
#: (`PythonCallbackHandler::isStateOk`, `CallbackHandler.cpp:15–19, 33–45`), a to ve `waitForAbort` / `sleep` (každých
#: ≤ 100 ms, `Monitor.cpp:48–58`). `_NextUpPlayer()` vzniká v hlavním vlákně služby, tedy tam, kde běží tik relace
#: (lint 89). Tik, v němž přehrávač zmizel, callback ještě mít nemusel; před dalším tikem ho `waitForAbort` doručí.
SESSION_END_TICKS = 2

#: Důvody, při kterých čekající obnova (D11 i odložená po kliknutí) NESTÁRNE: přehrávání je stav, který skončí, a po něm
#: má obnova proběhnout (cross-check Codex #8 — PC pozastavené přes noc jako 21.09.2026: po 6 h by požadavek propadl
#: a menu po zastavení ukázalo stav z večera).
REFRESH_HOLD_REASONS = (REFRESH_BLOCK_STARTING, REFRESH_BLOCK_PLAYER, REFRESH_BLOCK_FOLLOWUP)

#: V9 (audit Fable 4.0.2, Richie 10.10.2026 „určitě b“): claim relace obnovuje i HLÍDACÍ VLÁKNO, ne jen tik hlavní smyčky
#: služby. Callback konce přehrávání běží v hlavním vlákně a může čekat (TMDb pro další díl přes pomalou síť) déle než
#: TTL claimu — dřív by claim vypršel a akce na klik by v mezeře mezi díly obnovila výpis (mechanismus pádu 09.10.).
#: O KONCI relace dál rozhoduje jen hlavní vlákno (`session_note`); hlídač jen drží claim živý, dokud relace trvá.
SESSION_KEEPALIVE_S = 5.0
#: Hlavní vlákno služby mlčí déle (žádný `session_note` ani navazující akce) = služba je opravdu zaseknutá → hlídač
#: přestane a claim po TTL vyprší. Zaseknutá služba nesmí držet bránu refreshe navždy (výpisy by se nikdy neobnovily).
SESSION_STALL_MAX_S = 300.0

_session_lock = threading.Lock()
_session: Dict[str, Any] = {"token": None, "followups": 0, "idle_ticks": 0, "end_seen": False, "note_at": 0.0}
_keepalive: Dict[str, Any] = {"thread": None}

#: Okno Videa Kodi (`WINDOW_VIDEOS`) — jediné okno, ve kterém doplněk programově obnovuje výpis (D11 i odložená obnova).
WINDOW_VIDEOS = 10025
#: Strop stáří čekající obnovy (D11 i akce na klik; plán E7) — JEDNA konstanta. Dohnat má smysl, dokud divák může koukat
#: na tentýž výpis; po 6 h ukáže čerstvá data každé nové otevření (úvaha D11 z 21.09.2026). Během přehrávání nestárne.
REFRESH_PENDING_MAX_S = 6 * 3600.0
#: S18 (10.10.2026, Richie „centralizovat“): FRONTA ODLOŽENÝCH OBNOV — jedna pro akce na klik i D11 (dřív slot dispatcheru
#: + požadavek v paměti služby: dvě dohánění, dvě kontroly nečinnosti, cross-check Pro P5/P6b). Záznam `{"path", "reason",
#: "since" (time.time()), "token"}` PER VÝPIS ve vlastní Window property (`REFRESH_QUEUE_PREFIX` + otisk identity výpisu):
#: plugin i služba píší jen svůj výpis jedním `setProperty` — žádná sdílená mapa, tedy žádné meziprocesové
#: čtení-změna-zápis. Dohání se jen výpis, který je právě na obrazovce, takže konzument čte jediný záznam a výčet nepotřebuje.
REFRESH_QUEUE_PREFIX = "richmovie.refresh.q."
#: Kdy naposledy dohánění fronty viselo na PŘEHRÁVÁNÍ (`REFRESH_HOLD_REASONS`) — time.time(), píše jen služba
#: (`flush_refresh_queue`, jediný zapisovatel). Stáří záznamu se měří od pozdějšího z (požadavek, držení), takže
#: během přehrávání záznam opravdu NESTÁRNE (cross-check Codex #8: PC pozastavené přes noc 21.09.2026 — ráno po
#: zastavení se má obnovit). Do S18 to uměla jen D11 (příznak v paměti služby); verdikt akcí na klik po zastavení
#: přehrávání záznam starší než strop hned zahodil. Globální, ne per výpis: přehrávání drží všechny výpisy stejně
#: a za celou obrazovkou dohánění žádný výpis nevidí (cesta kontejneru tam nemusí být čitelná).
PROP_REFRESH_HELD_AT = "richmovie.refresh.held_at"
#: Prefix výpisů tohoto doplňku — odkládá se jen obnova NAŠEHO výpisu (vlastní okna nového vzhledu nemají cestu).
_PLUGIN_PATH_PREFIX = "plugin://plugin.video.richmovie"
#: Hlavní menu (cíl D11). Kodi ho hlásí ve tvarech `…richmovie/`, `…richmovie`, `…richmovie/?` → jedna identita (`listing_id`).
ROOT_LISTING = _PLUGIN_PATH_PREFIX + "/"
#: Výpis, který plugin ZAČAL stavět: `{"path", "since"}` PER VÝPIS (`LISTING_BUILD_PREFIX` + otisk; zapisuje `plugin.main`
#: u adresářové akce). Výpis postavený PO požadavku už změnu obsahuje → obnova je vyřízená. Kodi 21.2 staví výpis znovu při
#: vstupu do složky a při `Container.Refresh`, ale při návratu ZPĚT pomalý výpis (stavba > 1 s, `CACHE_IF_SLOW`) načte
#: z diskové cache BEZ pluginu (`GUIMediaWindow.cpp:739–742, 762–763, 1102–1105`) — proto „divák odešel jinam“ ≠ „zahodit“.
#: Per výpis (S18): stavba JINÉHO výpisu mezi požadavkem a návratem nesmí zakrýt, že tenhle postavený nebyl.
LISTING_BUILD_PREFIX = "richmovie.listing.build."
#: Značka „vyřízeno do“ PER VÝPIS (`REFRESH_SETTLED_PREFIX` + otisk; time.time()): čekající obnova se vyřizuje POSUNEM
#: značky, NE smazáním záznamu (cross-check Codex #2 / Pro A2 10.10.2026). Mazání bylo čtení-porovnání-smazání bez zámku
#: nad Window properties — požadavek, který plugin zapsal mezi čtením a smazáním, by zmizel. Producent (`request_refresh`)
#: píše jen záznam, vyřízení jen značku; záznam s `since` nad značkou čeká dál. Značka jen roste (`_mark_settled`);
#: souběžné posunutí dvou procesů může nechat nižší hodnotu = nanejvýš jedna obnova navíc, nikdy ztracená.
REFRESH_SETTLED_PREFIX = "richmovie.refresh.settled."
#: Tichý toast, když se změna po kliknutí kvůli přehrávání neukáže hned (intuitivní: divák ví, že se nic neztratilo).
#: Jeden text pro pozastavené video i pro mezeru mezi díly / navázání (audit Fable V1 — mezera může trvat minuty).
REFRESH_DEFERRED_TEXT = "Seznam se obnoví, jakmile skončí přehrávání."
#: Výsledky čistého `refresh_verdict`.
DEFERRED_GO = "go"
DEFERRED_WAIT = "wait"
DEFERRED_DROP = "drop"


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › player_present
# (vytvořeno: 10.10.2026 01:07 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def player_present(on_error: bool = True) -> bool:
    """Existuje přehrávač — hraje NEBO je pozastavený? JEDINÁ definice v doplňku (4.0.2, S11) pro bránu obnovy i relaci.
    `Player.HasMedia` = `CApplicationPlayer::IsPlaying()` (Kodi 21.2 `PlayerGUIInfo.cpp:418–420`, `ApplicationPlayer.cpp:248–257`:
    pauza = `IsPlaying() && rychlost 0`), video i hudba (vizualizace hudby opouští okno Videa stejně jako celá obrazovka
    videa). Bez vytváření `xbmc.Player()`. `on_error` = odpověď, když se stav nedá přečíst (brána: True = neobnovovat)."""
    if xbmc is None:
        return False
    try:
        return bool(xbmc.getCondVisibility("Player.HasMedia"))
    except Exception:
        return bool(on_error)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › session_active
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def session_active() -> bool:
    """Běží relace přehrávání (claim služby živý)? Nečitelný claim = ano (fail-closed jako ostatní vstupy brány)."""
    try:
        return bool(_guard.is_claimed(SESSION_GUARD))
    except Exception:
        return True


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › _session_keep_locked
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _session_keep_locked() -> None:
    """(pod `_session_lock`) Prodloužit vlastní claim relace, nebo ho PŘEVZÍT. Relaci drží jen služba (jediná instance),
    takže cizí držitel = sirotek minulé instance (aktualizace doplňku za běhu) — `take_over` místo čekání na jeho TTL:
    po vypršení by claim do dalšího tiku nikdo nedržel a plugin by obnovil výpis uprostřed navazující akce (Codex #3)."""
    _session["note_at"] = time.monotonic()
    tok = _session["token"]
    if tok and _guard.renew(SESSION_GUARD, tok, TTL_SESSION_S):
        _keepalive_ensure_locked()
        return
    _session["token"] = _guard.take_over(SESSION_GUARD, TTL_SESSION_S)
    if _session["token"]:
        _log("PLAYBACK_SESSION begin followups=%d" % _session["followups"])
        _keepalive_ensure_locked()


def keepalive_step(now: float) -> bool:
    """Jeden krok hlídače (volá se pod `_session_lock`): obnovit claim relace. False = hlídač končí (relace skončila,
    claim mezitím převzal někdo jiný, nebo hlavní vlákno mlčí déle než `SESSION_STALL_MAX_S`). Čisté vůči času (test)."""
    tok = _session["token"]
    if not tok:
        return False
    if now - float(_session["note_at"] or 0.0) > SESSION_STALL_MAX_S:
        _log("PLAYBACK_SESSION keepalive stop: hlavní vlákno služby mlčí %.0f s" % (now - float(_session["note_at"])),
             warning=True)
        return False
    return bool(_guard.renew(SESSION_GUARD, tok, TTL_SESSION_S))


def _keepalive_loop() -> None:
    me = threading.current_thread()
    try:
        mon = xbmc.Monitor() if xbmc is not None else None
        while True:
            if mon is not None:
                if mon.waitForAbort(SESSION_KEEPALIVE_S):
                    return                       # Kodi končí: claim nech vypršet (5s okno, nic nového)
            else:  # pragma: no cover - mimo Kodi bez stubů
                time.sleep(SESSION_KEEPALIVE_S)
            with _session_lock:
                if _keepalive["thread"] is not me:
                    return
                if not keepalive_step(time.monotonic()):
                    # rozhodnutí o konci a uvolnění ukazatele v TÉMŽE zámku: nová relace, která začne hned potom,
                    # spustí vlastní hlídač (dřív mezi `return` a `finally` viděla „živé“ končící vlákno a žádný nevznikl)
                    _keepalive["thread"] = None
                    return
    except Exception as exc:
        _log("PLAYBACK_SESSION keepalive failed err=%r" % (exc,), warning=True)
    finally:
        with _session_lock:
            if _keepalive["thread"] is me:
                _keepalive["thread"] = None


def _keepalive_ensure_locked() -> None:
    """(pod `_session_lock`) Hlídač běží, dokud relace trvá; spustí se znovu, když minulý skončil (zaseknutí / převzetí).
    Ne-daemon vlákno s `waitForAbort` (pravidlo projektu: Kodi ukončí jen vlákna, která čekají na abort)."""
    th = _keepalive["thread"]
    if th is not None and th.is_alive():
        return
    th = threading.Thread(target=_keepalive_loop, name="RMPlaybackSessionKeepalive")
    _keepalive["thread"] = th
    th.start()


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › _session_end_locked
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _session_end_locked() -> None:
    tok = _session["token"]
    if tok:
        _guard.release(SESSION_GUARD, tok)
        _session["token"] = None                # hlídač při příštím kroku skončí sám (bez tokenu nemá co držet);
        _log("PLAYBACK_SESSION end")            # nová relace do té doby převezme JEHO vlákno — nikdy dvě najednou


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › session_note
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def session_note(player: bool) -> None:
    """Služba pozorovala stav přehrávače (každý tik hlavní smyčky, `onAVStarted`). Relace trvá, dokud existuje přehrávač
    nebo běží navazující akce (`followup_begin` … `followup_end`). Bez obojího skončí hned, když už doběhl callback konce
    přehrávání (`session_end_seen`), jinak po `SESSION_END_TICKS` takových pozorováních. Nikdy nevyhazuje."""
    try:
        with _session_lock:
            _session["note_at"] = time.monotonic()    # hlavní vlákno žije (hlídač V9 se řídí tímhle)
            if player:
                _session["end_seen"] = False          # nové / pokračující přehrávání — konec ještě nenastal
            if player or _session["followups"] > 0:
                _session["idle_ticks"] = 0
                _session_keep_locked()
                return
            _session["idle_ticks"] += 1
            if _session["end_seen"] or _session["idle_ticks"] >= SESSION_END_TICKS:
                _session_end_locked()
    except Exception as exc:
        _log("PLAYBACK_SESSION_NOTE_FAILED err=%r" % (exc,), warning=True)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › session_stop
# (vytvořeno: 10.10.2026, Europe/Prague — V9 / cross-check Pro A5)
# ---------------------------------------------------------------------------- #
def session_stop() -> None:
    """Služba končí (abort Kodi i výjimka z hlavní smyčky — `service_nextup` volá ve `finally`): relace přehrávání končí
    s ní. Uvolní claim a vynuluje navazující akce; hlídací vlákno pak skončí při nejbližším kroku (bez tokenu nemá co
    držet). Bez toho by po pádu hlavní smyčky hlídač držel bránu obnovy až `SESSION_STALL_MAX_S`. Nikdy nevyhazuje."""
    try:
        with _session_lock:
            _session["followups"] = 0
            _session_end_locked()
    except Exception as exc:
        _log("PLAYBACK_SESSION_STOP_FAILED err=%r" % (exc,), warning=True)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › session_end_seen
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def session_end_seen() -> None:
    """Služba: callback konce přehrávání (Stopped / Ended / Error) DOBĚHL — navazující akce, které měl spustit, jsou
    spuštěné a započítané (`followup_begin` se volá před startem vlákna). Další tik bez přehrávače a bez akce smí
    relaci ukončit hned. Volat na KONCI callbacku (`finally`). Nikdy nevyhazuje."""
    try:
        with _session_lock:
            _session["end_seen"] = True
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › followup_begin
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def followup_begin(name: str) -> None:
    """Služba: začíná navazující akce po konci přehrávání (autoplay, navázání, navigace, dialog po konci, návrat do
    RichMovie). Volat V MÍSTĚ SPUŠTĚNÍ (ne až ve vlákně) — mezi callbackem a startem vlákna nesmí relace skončit.
    Každé `followup_begin` MUSÍ mít své `followup_end` (pomocník `service_nextup._spawn_followup`, kontext `followup`)."""
    try:
        with _session_lock:
            _session["followups"] += 1
            _session["idle_ticks"] = 0
            _session_keep_locked()
    except Exception as exc:
        _log("PLAYBACK_FOLLOWUP_BEGIN_FAILED name=%s err=%r" % (name, exc), warning=True)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › followup_end
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def followup_end(name: str) -> None:
    """Navazující akce skončila (i výjimkou). O konci relace pak rozhodne další `session_note` (E9)."""
    try:
        with _session_lock:
            _session["followups"] = max(0, int(_session["followups"]) - 1)
    except Exception as exc:
        _log("PLAYBACK_FOLLOWUP_END_FAILED name=%s err=%r" % (name, exc), warning=True)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › followup
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
@contextlib.contextmanager
def followup(name: str) -> Iterator[None]:
    """`followup_begin` … `followup_end` jako kontext (navazující akce běžící v témže vlákně; počítadlo se vrátí i při
    výjimce). Vlákna spouští služba přes `_spawn_followup` (begin před startem vlákna)."""
    followup_begin(name)
    try:
        yield
    finally:
        followup_end(name)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › refresh_block_reason
# (vytvořeno: 09.10.2026 20:53 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def refresh_block_reason(probe: Dict[str, Any]) -> str:
    """ČISTÁ: smí doplněk TEĎ programově obnovit kontejner? "" = smí, jinak důvod odmítnutí.

    Odmítá (pořadí = priorita důvodu v logu):
      • `abort` — Kodi končí (5s okno vypnutí, žádná nová práce GUI),
      • `playback_starting` — claim `playback_start` (ODESLÁNO / RESOLVE / OTEVÍRÁNÍ): přesně okno incidentu,
        celá obrazovka přijde až s obrazem a s ní opuštění okna Videa,
      • `player_active` — existuje přehrávač, hrající NEBO pozastavený (4.0.2, S11): „zpět na video“ opustí okno
        Videa uprostřed obnovy, která na pomalém boxu trvá déle než 5 s,
      • `playback_followup` — přehrávač už není, ale služba dořešuje konec (relace přehrávání, E9): autoplay /
        navázání by poslalo `PlayMedia` do běžícího načítání,
      • `kodi_busy` — běží busy dialog Kodi (resolve nebo načítání adresáře): refresh by spustil další
        načítání uvnitř běžícího,
      • `user_active` — JEN refresh z pozadí (`probe["user_active"]` plní `probe_refresh(background=True)`):
        divák právě pracuje → okno mezi klikem na stream a claimem `_play` (D2b).
    Rozhoduje STAV, ne časové okno. Pravidla volajících (D11 „jen hlavní menu“, MI2 „jen můj výpis“) zůstávají
    u volajících (plán D4).
    """
    if probe.get("abort"):
        return REFRESH_BLOCK_ABORT
    if probe.get("starting"):
        return REFRESH_BLOCK_STARTING
    if probe.get("player"):
        return REFRESH_BLOCK_PLAYER
    if probe.get("followup"):
        return REFRESH_BLOCK_FOLLOWUP
    if probe.get("busy"):
        return REFRESH_BLOCK_BUSY
    if probe.get("user_active"):
        return REFRESH_BLOCK_USER_ACTIVE
    return ""


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › probe_refresh
# (vytvořeno: 09.10.2026 20:53 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def probe_refresh(*, background: bool = False) -> Dict[str, Any]:
    """Vstup `refresh_block_reason` z živého Kodi. Nečitelný stav = NEOBNOVOVAT (fail-closed): neobnovený výpis
    je kosmetika, obnova ve špatnou chvíli shodí celé Kodi. `background=True` (MI2, D11) přidá „divák pracuje“
    z `richmovie_activity.should_yield()` (D2b); akce na klik ho nevyhodnocují (`user_active` = False)."""
    try:
        starting = bool(is_starting())
    except Exception:
        starting = True
    abort = False
    if xbmc is not None:
        try:
            abort = bool(xbmc.Monitor().abortRequested())
        except Exception:
            abort = True     # nečitelný stav ukončování = neobnovovat (cross-check Codex 09.10.2026: dřív fail-open)
    user_active = False
    if background:
        try:
            import richmovie_activity as _rm_activity
            user_active = bool(_rm_activity.should_yield()[0])
        except Exception:
            user_active = True
    return {"abort": abort, "starting": starting, "player": player_present(on_error=True),
            "followup": session_active(), "busy": busy_dialog_active(on_error=True), "user_active": user_active}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › refresh_container
# (vytvořeno: 09.10.2026 20:53 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def refresh_container(reason: str, *, background: bool = False, expect_path: str = "") -> bool:
    """JEDINÉ místo, odkud doplněk volá `Container.Refresh` (lint scénáře 87). `reason` = kdo a proč (do logu).
    `background=True` = refresh, který NENÍ reakcí na vstup diváka (MI2, D11) → navíc ustoupí aktivnímu divákovi.

    Vrací True = obnova odeslána, False = brána odmítla nebo odeslání selhalo. Při odmítnutí: MI2 obnovu zahodí
    (štítky doskočí při dalším otevření), AKCE NA KLIK (`background=False`) se tady zapíše do fronty obnov (4.0.2 E3,
    S18 `request_refresh`) — kromě konce Kodi; D11 do fronty zapisuje sama. Dožene je `flush_refresh_queue`.
    Úspěšná obnova vyřídí i čekající obnovu téhož výpisu (`_settle_queued`): druhý refresh by jen stavěl totéž.
    `expect_path` (dohnání odložené obnovy): obnovit JEN když je na obrazovce pořád tento výpis (Codex #5).
    """
    why = refresh_block_reason(probe_refresh(background=background))
    if why:
        _log("CONTAINER_REFRESH_SKIP reason=%s why=%s" % (reason or "-", why))
        if not background and why != REFRESH_BLOCK_ABORT:
            request_refresh(_current_path(), reason, why)
        return False
    if xbmc is None:
        return False
    path = _current_path()          # cesta PŘED odesláním = výpis, který se obnovuje
    if expect_path and listing_id(path) != listing_id(expect_path):
        _log("CONTAINER_REFRESH_SKIP reason=%s why=path_changed" % (reason or "-"))
        return False
    sent_at = time.time()
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        _log("CONTAINER_REFRESH_FAILED reason=%s err=%r" % (reason or "-", exc), warning=True)
        # jeden pokus na odloženou obnovu: rozbité API Kodi nesmí roztočit opakování každý tik (cross-check Flash F4)
        _settle_queued(path, sent_at, reason, outcome="send_failed")
        return False
    _log("CONTAINER_REFRESH reason=%s" % (reason or "-"))
    _settle_queued(path, sent_at, reason)
    return True


# ═════════════════════════════════════════════════════════════════════════════
# FRONTA ODLOŽENÝCH OBNOV VÝPISU (4.0.2 plán E3–E7; S18 4.0.4: jedna fronta pro akce na klik i D11)
# ═════════════════════════════════════════════════════════════════════════════
# Producenti: `refresh_container(background=False)` při odmítnutí (akce na klik, plugin) a D11
# (`richmovie_state_sync.maybe_refresh_menu` → `request_refresh(ROOT_LISTING, …, silent=True)`, služba po sloučení změn
# z jiného zařízení). Konzument JEDEN: `flush_refresh_queue()` — hlavní smyčka služby každý tik (nezávisle na Gate: změny
# jsou už lokálně) a D11 hned po zápisu. Obnovuje se jen výpis, na který divák zrovna kouká; odešel-li jinam, záznam
# počká na jeho návrat (Kodi pomalý výpis při návratu zpět vezme z diskové cache, viz `LISTING_BUILD_PREFIX`). Zahodí se,
# když plugin ten výpis po požadavku postavil znovu (`note_listing_build`), po odeslání (jeden pokus — žádná smyčka obnov,
# kdyby Kodi výpis nepostavilo) a po `REFRESH_PENDING_MAX_S` (během přehrávání nestárne). Dohnání jde stejnou branou jako
# pozadí (`background=True`): ne s přehrávačem, ne v relaci, ne během startu, ne při busy dialogu, ne když divák pracuje
# (`should_yield` — JEDINÁ kontrola nečinnosti; D11 měla dřív vlastní, P6b). Hlavní menu navíc počká, dokud se staví
# (`richmovie_onboarding.root_building`: obnova uprostřed stavby spustila druhý root, audit A07 F1).

# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › screen_state
# (vytvořeno: 10.10.2026 01:06 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def screen_state() -> Dict[str, Any]:
    """Co je teď na obrazovce — JEDINÁ definice pro frontu obnov výpisu (`flush_refresh_queue`, akce na klik i D11):
    `modal` (modální dialog, klávesnice, busy dialog), `window_id`, `folder_path` (`Container.FolderPath`).
    Nečitelné = `modal` True, okno 0, cesta "" (fail-closed: obnova počká / nenajde svůj výpis)."""
    if xbmc is None or xbmcgui is None:
        return {"modal": True, "window_id": 0, "folder_path": ""}
    try:
        modal = bool(xbmc.getCondVisibility("System.HasActiveModalDialog")
                     or xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)")
                     or busy_dialog_active(on_error=True)   # SSOT „kolečko Kodi“ (audit Fable V2)
                     or xbmcgui.getCurrentWindowDialogId() not in (9999, 0))
    except Exception:
        modal = True
    try:
        window_id = int(xbmcgui.getCurrentWindowId())
    except Exception:
        window_id = 0
    return {"modal": modal, "window_id": window_id, "folder_path": _folder_path()}


def _folder_path() -> str:
    """`Container.FolderPath` (jediné čtení cesty obrazovky pro `screen_state` i levný tik fronty); "" = nečitelná."""
    if xbmc is None:
        return ""
    try:
        return xbmc.getInfoLabel("Container.FolderPath") or ""
    except Exception:
        return ""


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › _current_path
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _current_path() -> str:
    """Kanonická cesta výpisu na obrazovce (SSOT kanonizace `richmovie_listing.canon_key`); "" = nečitelná."""
    try:
        import richmovie_listing as _rm_listing
        key = _rm_listing.listing_key_from_kodi()
        return "" if key == _rm_listing.UNKNOWN_KEY else key
    except Exception:
        return ""


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › listing_id
# (vytvořeno: 10.10.2026, Europe/Prague — S18)
# ---------------------------------------------------------------------------- #
def listing_id(path: Any) -> str:
    """Identita výpisu pro frontu obnov: kanonická cesta (`richmovie_listing.canon_key`) a prázdná cesta URL = „/“, takže
    `…richmovie`, `…richmovie/` i `…richmovie/?` jsou totéž hlavní menu (`ROOT_LISTING`) a `…richmovie?action=x` je
    `…richmovie/?action=x`. "" = nečitelná cesta nebo výpis jiného doplňku / Kodi (nic k obnovení). Nikdy nevyhazuje."""
    try:
        import urllib.parse as _up
        import richmovie_listing as _rm_listing
        key = _rm_listing.canon_key(path or "")
        if not key.startswith(_PLUGIN_PATH_PREFIX):
            return ""
        u = _up.urlparse(key)
        if u.netloc != _PLUGIN_PATH_PREFIX.split("://", 1)[1]:
            return ""                      # jiný doplněk se stejným začátkem jména
        return _up.urlunparse(u._replace(path=u.path or "/"))
    except Exception:
        return ""


def _prop_name(prefix: str, lid: str) -> str:
    return prefix + hashlib.sha1(lid.encode("utf-8")).hexdigest()[:16]


def _read_json_prop(name: str) -> Dict[str, Any]:
    """{} = nic; nečitelný obsah = {"_invalid": True} (konzument ho zahodí)."""
    try:
        raw = _get_prop(name, "")
    except Exception:
        return {}
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        return {"_invalid": True}
    return data if isinstance(data, dict) else {"_invalid": True}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › note_listing_build
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague; S18 per výpis 10.10.2026)
# ---------------------------------------------------------------------------- #
def note_listing_build(path: str) -> None:
    """Plugin: Kodi právě nechává postavit výpis `path` (adresářová akce v `plugin.main`, PŘED čtením dat). Nikdy nevyhazuje."""
    try:
        lid = listing_id(path)
        if lid:
            _set_prop(_prop_name(LISTING_BUILD_PREFIX, lid),
                      json.dumps({"path": lid, "since": time.time()}, sort_keys=True))
    except Exception:
        pass


def _read_listing_build(lid: str) -> Dict[str, Any]:
    data = _read_json_prop(_prop_name(LISTING_BUILD_PREFIX, lid)) if lid else {}
    return {} if data.get("_invalid") else data


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › read_queued
# (vytvořeno: 10.10.2026, Europe/Prague — S18)
# ---------------------------------------------------------------------------- #
def read_queued(path: Any) -> Dict[str, Any]:
    """Čekající obnova výpisu `path` z fronty; {} = žádná, {"_invalid": True} = nečitelná."""
    lid = listing_id(path)
    return _read_json_prop(_prop_name(REFRESH_QUEUE_PREFIX, lid)) if lid else {}


def _settled_upto(lid: str) -> float:
    """Značka „vyřízeno do“ výpisu (0 = nic). Nečitelná = 0 (záznam se vyhodnotí znovu — nanejvýš obnova navíc)."""
    try:
        return float(_get_prop(_prop_name(REFRESH_SETTLED_PREFIX, lid), "") or 0.0) if lid else 0.0
    except (TypeError, ValueError):
        return 0.0


def _mark_settled(lid: str, upto: float) -> None:
    """Posune značku „vyřízeno do“ (nikdy zpět). Záznam fronty se nemaže — viz `REFRESH_SETTLED_PREFIX`."""
    try:
        if lid and float(upto) > _settled_upto(lid):
            _set_prop(_prop_name(REFRESH_SETTLED_PREFIX, lid), repr(float(upto)))
    except Exception as exc:
        _log("CONTAINER_REFRESH_DEFERRED_SETTLE_FAILED err=%r" % (exc,), warning=True)


def _drop_invalid(lid: str) -> None:
    """Nečitelný záznam (náš kód takový nezapisuje) se smaže — jediné mazání fronty."""
    try:
        _clear_prop(_prop_name(REFRESH_QUEUE_PREFIX, lid))
    except Exception as exc:
        _log("CONTAINER_REFRESH_DEFERRED_CLEAR_FAILED err=%r" % (exc,), warning=True)


def pending_queued(path: Any) -> Dict[str, Any]:
    """Čekající (nevyřízený) záznam výpisu: {} = nic nečeká; nečitelný záznam = {"_invalid": True}."""
    lid = listing_id(path)
    rec = read_queued(lid) if lid else {}
    if not rec or rec.get("_invalid"):
        return rec
    try:
        since = float(rec.get("since") or 0.0)
    except (TypeError, ValueError):
        return {"_invalid": True}
    return rec if since > _settled_upto(lid) else {}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › request_refresh
# (vytvořeno: 10.10.2026, Europe/Prague — S18; nahrazuje `_defer_refresh` z 4.0.2)
# ---------------------------------------------------------------------------- #
def request_refresh(path: Any, reason: str, why: str = "", *, silent: bool = False) -> bool:
    """Zapsat do fronty: výpis `path` se má obnovit, jakmile to půjde (dožene `flush_refresh_queue`). Jen výpis tohoto
    doplňku (vlastní okna nového vzhledu cestu nemají — nic k obnovení). Novější požadavek téhož výpisu záznam přepíše
    (čas = NEJNOVĚJŠÍ požadavek: stavba výpisu až po něm ukazuje všechny změny). `why` = proč to teď nešlo (log; ""
    = neznámo, D11 zapisuje dřív, než se brány ptá). Tichý toast jen u akce na klik (`silent=False`), když brání
    PŘEHRÁVÁNÍ (`REFRESH_HOLD_REASONS`: start, přehrávač, relace — může trvat minuty, audit Fable V1); busy dialog se dožene
    do pár sekund a vysvětlení by bylo šum. Vrací True = zapsáno. Nikdy nevyhazuje (volají ji akce na klik po zápisu dat
    — výjimka by divákovi ukázala chybu skriptu u akce, která se povedla; cross-check Flash F5)."""
    lid = listing_id(path)
    if not lid:
        _log("CONTAINER_REFRESH_NOT_DEFERRED reason=%s why=%s (nejde o výpis RichMovie)" % (reason or "-", why or "-"))
        return False
    try:
        rec = {"path": lid, "reason": reason or "-", "since": time.time(), "token": uuid.uuid4().hex}
        _set_prop(_prop_name(REFRESH_QUEUE_PREFIX, lid), json.dumps(rec, ensure_ascii=False, sort_keys=True))
    except Exception as exc:
        _log("CONTAINER_REFRESH_DEFER_FAILED reason=%s err=%r" % (reason or "-", exc), warning=True)
        return False
    _log("CONTAINER_REFRESH_DEFERRED reason=%s why=%s path=%s" % (reason or "-", why or "-", lid[:200]))
    if not silent and why in REFRESH_HOLD_REASONS:
        try:
            import richmovie_feedback as _rm_feedback
            _rm_feedback.info(REFRESH_DEFERRED_TEXT)
        except Exception:
            pass
    return True


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › _settle_queued
# (vytvořeno: 10.10.2026 02:09 CEST, Europe/Prague; S18 per výpis 10.10.2026)
# ---------------------------------------------------------------------------- #
def _settle_queued(path: str, sent_at: float, reason: str, outcome: str = "sent") -> None:
    """Právě odeslaná obnova výpisu `path` vyřídila i čekající obnovu téhož výpisu — pokud vznikla PŘED odesláním
    (novější požadavek po odeslání má vlastní data, ten se dohání dál). `outcome="send_failed"`: odeslání selhalo a
    čekající obnova se taky vyřizuje (jeden pokus — žádná smyčka nad rozbitým API Kodi)."""
    lid = listing_id(path)
    cur = pending_queued(lid) if lid else {}
    if not cur or cur.get("_invalid"):
        return
    try:
        since = float(cur.get("since") or 0.0)
    except (TypeError, ValueError):
        return
    if str(cur.get("path") or "") == lid and 0.0 < since <= sent_at:
        # vyřízeno vše do okamžiku odeslání (novější požadavek má `since` > `sent_at` a čeká dál)
        _mark_settled(lid, sent_at)
        _log("CONTAINER_REFRESH_DEFERRED_SETTLED by=%s deferred=%s outcome=%s"
             % (reason or "-", cur.get("reason") or "-", outcome))


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › refresh_verdict
# (vytvořeno: 10.10.2026 01:06 CEST jako `deferred_refresh_verdict`; S18 10.10.2026 — i pro D11)
# ---------------------------------------------------------------------------- #
def refresh_verdict(rec: Dict[str, Any], screen: Dict[str, Any], block_why: str,
                    now: float, built: Optional[Dict[str, Any]] = None, held_at: float = 0.0) -> Tuple[str, str]:
    """ČISTÁ: co s čekající obnovou teď → (`DEFERRED_GO` | `DEFERRED_WAIT` | `DEFERRED_DROP`, důvod). JEDINÝ verdikt pro
    akce na klik i D11 (S18).

    Pořadí: vadný / prošlý záznam = zahodit (stáří od pozdějšího z požadavku a `held_at` — posledního držení
    přehráváním; během přehrávání `REFRESH_HOLD_REASONS` nestárne vůbec) · plugin týž výpis po
    požadavku znovu postavil (`built`, značka `note_listing_build`) = zahodit · modální dialog / jiné okno než Videa
    (celá obrazovka, Home) / jiný výpis = čekat (divák se může vrátit na tentýž výpis — po zastavení videa ho Kodi jen
    překreslí, při návratu zpět pomalý výpis vezme z diskové cache) · výpis se právě staví (`screen["building"]`, hlavní
    menu) = čekat · brána odmítá = čekat · jinak obnovit.
    Cestu `screen["folder_path"]` převádí volající na identitu výpisu (`listing_id`)."""
    try:
        path = str(rec.get("path") or "")
        since = float(rec.get("since") or 0.0)
    except (TypeError, ValueError, AttributeError):
        return DEFERRED_DROP, "invalid"
    if rec.get("_invalid") or not path.startswith(_PLUGIN_PATH_PREFIX) or since <= 0.0:
        return DEFERRED_DROP, "invalid"
    if now - since < 0.0:
        return DEFERRED_DROP, "expired"          # čas pozpátku = záznam nepatří tomuhle běhu
    try:
        held = float(held_at or 0.0)
    except (TypeError, ValueError):
        held = 0.0
    age = now - max(since, held if held <= now else 0.0)
    if age >= REFRESH_PENDING_MAX_S and block_why not in REFRESH_HOLD_REASONS:
        return DEFERRED_DROP, "expired"
    try:
        built_since = float((built or {}).get("since") or 0.0)
    except (TypeError, ValueError):
        built_since = 0.0
    if str((built or {}).get("path") or "") == path and built_since >= since:
        return DEFERRED_DROP, "superseded"
    if screen.get("modal"):
        return DEFERRED_WAIT, "dialog"
    if int(screen.get("window_id") or 0) != WINDOW_VIDEOS:
        return DEFERRED_WAIT, "not_videos_window"
    if str(screen.get("folder_path") or "") != path:
        return DEFERRED_WAIT, "navigated"
    if screen.get("building"):
        return DEFERRED_WAIT, "listing_building"
    if block_why:
        return DEFERRED_WAIT, block_why
    return DEFERRED_GO, ""


_queue_logged = {"token": "", "why": ""}    # „čeká: …“ logovat jen při změně (ne každých 5 s)


def playback_hold_reason(player: Optional[bool] = None) -> str:
    """Drží TEĎ obnovu přehrávání? → důvod z `REFRESH_HOLD_REASONS` (start, přehrávač, relace), jinak "". Levná část
    brány pro KAŽDÝ tik služby (stárnutí čekajících obnov, `PROP_REFRESH_HELD_AT`); pořadí důvodů dává tatáž čistá
    `refresh_block_reason`. `player` = přehrávač, který tik služby už zjistil pro relaci (audit Fable F-7: dřív se v tiku
    četl dvakrát a s ním celá brána i obrazovka i bez čekajícího záznamu); bez něj se zjistí tady."""
    try:
        starting = bool(is_starting())
    except Exception:
        starting = True     # nečitelné = držet (záznam nezestárne; jako `probe_refresh`)
    if player is None:
        player = player_present(on_error=True)
    why = refresh_block_reason({"starting": starting, "player": bool(player), "followup": session_active()})
    return why if why in REFRESH_HOLD_REASONS else ""


def _note_held(block_why: str, now: float) -> float:
    """(služba, pod `_flush_lock`) Zapíše čas držení přehráváním a vrátí platný `held_at` pro verdikt."""
    try:
        held = float(_get_prop(PROP_REFRESH_HELD_AT, "") or 0.0)
    except (TypeError, ValueError):
        held = 0.0
    if block_why in REFRESH_HOLD_REASONS:
        try:
            _set_prop(PROP_REFRESH_HELD_AT, repr(float(now)))
            held = now
        except Exception:
            pass
    return held
_flush_lock = threading.Lock()              # D11 z vlákna služby + tik hlavní smyčky: dohání nejvýš jeden


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_playback_dispatch.py › flush_refresh_queue
# (vytvořeno: 10.10.2026 01:06 CEST jako `flush_deferred_refresh`; S18 10.10.2026 — jediné dohánění i pro D11;
#  audit Fable F-7 10.10.2026 — celá brána jen při čekajícím záznamu)
# ---------------------------------------------------------------------------- #
def flush_refresh_queue(player: Optional[bool] = None) -> bool:
    """Služba: dožene čekající obnovu výpisu, který je právě na obrazovce, jakmile to jde (True = obnova odeslána).
    Volá ji hlavní smyčka služby každý tik (`player` = přehrávač zjištěný tikem) a D11 hned po zápisu požadavku.
    Souběžné volání se nečeká, jen vrátí False (dohnání stejně proběhne v příštím tiku). Nikdy nevyhazuje."""
    if not _flush_lock.acquire(False):
        return False
    try:
        now = time.time()
        # KAŽDÝ tik jen levná část: držení přehráváním (stárnutí záznamů i jiných výpisů) a cesta obrazovky. Celá brána
        # a obrazovka až když na obrazovce čeká záznam (audit Fable F-7; do 4.0.2 prázdná fronta = konec hned).
        held_at = _note_held(playback_hold_reason(player), now)
        lid = listing_id(_folder_path())
        rec = pending_queued(lid) if lid else {}
        if not rec:
            return False
        block_why = refresh_block_reason(probe_refresh(background=True))
        screen = screen_state()
        screen["folder_path"] = listing_id(screen.get("folder_path") or "")   # jiný výpis mezi čteními = verdikt čeká
        if lid == ROOT_LISTING:
            try:
                import richmovie_onboarding as _ob
                screen["building"] = bool(_ob.root_building())
            except Exception:
                screen["building"] = True     # nečitelné = počkat (fail-closed jako zbytek brány)
        verdict, why = refresh_verdict(rec, screen, block_why, now, _read_listing_build(lid), held_at)
        token = rec.get("token") or ""
        if verdict == DEFERRED_DROP:
            if rec.get("_invalid"):
                _drop_invalid(lid)
            else:
                _mark_settled(lid, float(rec.get("since") or 0.0))   # vyřízeno bez obnovy (prošlé / postavené znovu)
            _log("CONTAINER_REFRESH_DEFERRED_DROP reason=%s why=%s" % (rec.get("reason") or "-", why))
            return False
        if verdict == DEFERRED_WAIT:
            if (_queue_logged["token"], _queue_logged["why"]) != (token, why):
                _queue_logged["token"], _queue_logged["why"] = token, why
                _log("CONTAINER_REFRESH_DEFERRED_WAIT reason=%s why=%s" % (rec.get("reason") or "-", why))
            return False
        # Odeslání znovu projde branou (TOCTOU) a při úspěchu záznam vyřídí `_settle_queued` (týž výpis, since ≤ teď).
        return refresh_container("deferred:%s" % (rec.get("reason") or "-"), background=True, expect_path=lid)
    except Exception as exc:
        _log("CONTAINER_REFRESH_DEFERRED_FLUSH_FAILED err=%r" % (exc,), warning=True)
        return False
    finally:
        _flush_lock.release()
