# -*- coding: utf-8 -*-
"""
RichMovie Gate Transport — shared HTTP/identity helpers for all Gate clients.

Single Source of Truth (SSOT) for talking to https://gate.svcnode.org:

    richmovie_gate.py          — /auth + /status (lease lifecycle)
    richmovie_ai_client.py     — /v1/ai/*
    richmovie_mediainfo_client — /v1/mediainfo/*
    richmovie_csfd_client.py   — /v1/csfd/* (CSFD profile sync)

    (richmovie_search_client + /v1/search byly dropped 2026-05-02 —
    half-year-tuned ReleaseFilter zůstává SSOT v addon, Gate fan-out
    nedosáhl filter parity. Detail: Handoff/session_2026-05-02_drop_
    gate_search_settings_ssot.md.)

All of them share the same three concerns:
    1. Compute `ws_proof` = SHA256(ws_username_lower : ws_password) for identity
       verification with Gate.
    2. Pull ws_username + ws_password from Kodi addon settings and derive proof.
    3. POST JSON to Gate and map `HTTPError` into (status, parsed_body) tuples
       without raising on HTTP 4xx/5xx (callers translate codes per endpoint).

Previously these lived duplicated in richmovie_gate.py and richmovie_ai_client.py.
Phase 3b.5 consolidates into this module before phase 3c adds yet another client.
Enterprise grade: DRY + SSOT are mandatory (CLAUDE.md root rule).

Python 3.8 compat (Kodi bundled): typing.Optional/Tuple/Dict/Any, no PEP 604.
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import time
import uuid
from typing import Any, Dict, Optional, Tuple

import xbmc
import xbmcaddon
import xbmcvfs

# ──────────────  RICHMOVIE  ──────────────
# Φ3 (2026-08-08): SSOT retry vrstva. Import je best-effort, aby poškozená
# instalace neshodila celý modul při importu — chybějící modul se pozná až
# v `post_json()`, kde vyhodí srozumitelnou chybu místo tichého downgradu.
try:
    import richmovie_http as _rm_http
except Exception:  # pragma: no cover
    _rm_http = None  # type: ignore

# 3.5.118 (2026-08-21): SSOT stavu identity (REJECTED → fail-fast, viz post_json).
# Best-effort: bez modulu se transport chová jako do 3.5.117.
try:
    import richmovie_identity_state as _identity
except Exception:  # pragma: no cover
    _identity = None  # type: ignore

# 3.5.120 (2026-08-27): SSOT čtení nastavení. Cyklus nehrozí — `richmovie_settings`
# má na úrovni modulu jen stdlib + xbmc* a `richmovie_gate` importuje až uvnitř
# funkce (ověřeno při implementaci A3). Best-effort import kvůli poškozené
# instalaci; bez modulu spadne identita na dřívější chování.
try:
    import richmovie_settings as _rm_settings
except Exception:  # pragma: no cover
    _rm_settings = None  # type: ignore


# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
GATE_URL = "https://gate.svcnode.org"
SCHEMA_VERSION = "v1"

# Explicitní ID addonu pro `xbmcaddon.Addon(...)`. Bez argumentu se addon určuje
# z kontextu volání, což ve vláknech služby selhalo tichým prázdným čtením
# (incident bandog 27.08.2026) — proto se tady i všude jinde uvádí natvrdo.
_ADDON_ID = "plugin.video.richmovie"


# --------------------------------------------------------------------------- #
# Typované chyby Gate volání (3.5.118, 2026-08-21)
# --------------------------------------------------------------------------- #
class GateProbeError(Exception):
    """Gate odpověděl, ale probe se nepovedl z důvodu INFRASTRUKTURY (5xx, 429,
    nečekaný tvar). Není to vlastnost souboru → volající NESMÍ perzistovat
    negativní marker (R2 plánu 3.5.118). Do 3.5.117 se tohle vracelo jako `None`
    a MI2 to zapsal jako `empty` = „soubor nemá metadata" na 1–3 dny → permanent."""

    def __init__(self, status, code=""):
        # type: (int, str) -> None
        super().__init__("gate probe failed: HTTP %s %s" % (status, code))
        self.status = int(status or 0)
        self.code = str(code or "")


class GateAuthError(GateProbeError):
    """Gate identitu autoritativně odmítl (401/403 s Gate JSON kódem), nebo je
    identita už zamítnutá a volání selhalo lokálně (fail-fast v `post_json`)."""


class GateNotMediaError(GateProbeError):
    """Gate AUTORITATIVNĚ řekl, že odkaz nevydal médium (3.5.129, incident
    PeterFM 02.09.2026): HTTP 422 s kódem `not_media` (HTML stránka Free účtu,
    CDN 4xx, tělo bez tracků) — nebo 200 s payloadem, který není médium
    (starší Gate před 02.09.2026; brání se `is_media_payload`).

    Na rozdíl od `GateProbeError` je to vlastnost ODKAZU (účet/IP/soubor), ne
    infrastruktury: MI2 si smí uložit LOKÁLNÍ negativní marker s krátkým TTL
    (`fail_reason="not_media"`), aby HTML stránku neprobovalo při každém
    otevření. Do sdílené cache nejde nic — Gate ji od 02.09.2026 nepřijme."""

    CODE = "not_media"


# Sdílená MediaInfo cache: co je „médium" rozhoduje na Gate
# `app.mediainfo.schemas.is_media_payload`; tohle je zrcadlo téže definice na
# straně klienta (Kodi Python nemůže Gate kód importovat). Jedno pravidlo, dvě
# kopie z nutnosti — změna se dělá na obou místech, harness scénář 48 to hlídá.
def is_media_payload(payload):
    # type: (Any) -> bool
    """Aspoň jeden video NEBO audio track, NEBO známá délka > 0. Prázdný obal
    (`container` bez tracků a bez délky) je otisk HTML stránky, ne filmu."""
    if not isinstance(payload, dict):
        return False
    video = payload.get("video")
    if isinstance(video, dict) and video:
        return True
    audio = payload.get("audio")
    if isinstance(audio, list) and len(audio) > 0:
        return True
    try:
        return int(payload.get("duration_sec") or 0) > 0
    except (TypeError, ValueError):
        return False


class IdentityUnavailableError(Exception):
    """Identitu se nepodařilo PŘEČÍST — a je to prokázané, ne odhadnuté.

    Zásadní rozdíl proti prázdné identitě (3.5.120, incident bandog 27.08.2026):
      • „uživatel není nastavený" → legitimní stav, addon má nabídnout přihlášení,
      • „nepřečetl jsem nastavení" → PORUCHA. Poslat request bez identity znamená
        jistý 403 z Gate a modální dialog „Data se nepodařilo načíst", ze kterého
        se člověk nedozví nic.

    Rozlišuje se porovnáním dvou nezávislých cest ke stejné hodnotě
    (`richmovie_settings.diagnose_read`), ne heuristikou ze stáří lease.
    """

    def __init__(self, detail=""):
        # type: (str) -> None
        super().__init__("identity unavailable: %s" % (detail or "read failure"))
        self.detail = str(detail or "")

# Default request timeout for typical Gate calls (/v1/mediainfo, /v1/search).
# AI calls override with a higher value (180s) because Opus/high-quality RCAI
# jobs can legitimately run 60-120s before the 100s Cloudflare hard limit.
DEFAULT_TIMEOUT_SECONDS = 30.0

# Observability program 2026-07-02 (3.5.84, Fáze 3 perf signál): request na
# Gate delší než tento práh se centrálně hlásí jako WARNING SLOW_REQUEST
# (JEDNO SSOT místo = post_json; žádný per-callsite kód). Práh 5 s = řádově
# nad normálem (auth/telemetrie ~0,1–1 s), ale hluboko pod timeoutem 30 s —
# zachytí degradaci (pomalé Wi-Fi, přetížený NAS, Cloudflare) DŘÍV, než se
# projeví timeouty. Opakované pomalé requesty dedupuje RateLimitingFilter.
SLOW_REQUEST_THRESHOLD_S = 5.0


# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
# 3.4.0 Phase 9: Migrated to richmovie_logging pipeline. Prefix slightly
# changed [RichMovie/GateT] -> [RichMovie/Gate/Transport] (clearer hierarchy).
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.gate_transport", "RichMovie/Gate/Transport")
except Exception:
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        # type: (str, int, dict | None) -> None
        try:
            xbmc.log("[RichMovie/GateT] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Identity — SHA256(ws_username_lower : ws_password)
# --------------------------------------------------------------------------- #
_identity_lock = threading.Lock()


def compute_ws_proof(ws_username, ws_password):
    # type: (str, str) -> str
    """SHA256(username_lower:password). Matches Gate's _derive_proof_hash()."""
    if not ws_username or not ws_password:
        return ""
    payload = ("%s:%s" % (ws_username.lower(), ws_password)).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def get_identity():
    # type: () -> Tuple[str, str]
    """Pull (ws_username, ws_proof) from addon settings.

    Returns ('', '') if either credential is missing — callers must surface a
    'setup required' path in that case rather than sending an empty proof to
    Gate (Gate would reject with proof_missing / proof_mismatch anyway).

    3.5.120: čtení jde přes `richmovie_settings` (SSOT) — ten používá
    `Addon(ADDON_ID)` s explicitním ID. Do 3.5.119 se tu volalo `Addon()` bez
    argumentu, což ve vláknech dlouhoběžící služby vracelo prázdné hodnoty bez
    chyby → requesty bez identity a Gate 403 (incident bandog 27.08.2026).
    Kdo potřebuje odlišit „nenastaveno" od „nepřečteno", volá
    `get_identity_strict()`, ne tuhle funkci.
    """
    with _identity_lock:
        if _rm_settings is not None:
            username, password = _rm_settings.get_identity_pair()
            username = (username or "").strip()
            password = (password or "").strip()
        else:  # pragma: no cover — poškozená instalace
            addon = xbmcaddon.Addon(_ADDON_ID)
            username = (addon.getSetting("username") or "").strip()  # lint:allow-settings fallback bez richmovie_settings (poškozená instalace)
            password = (addon.getSetting("password") or "").strip()  # lint:allow-settings fallback bez richmovie_settings (poškozená instalace)
    if not username or not password:
        return "", ""
    return username, compute_ws_proof(username, password)


def identity_read_failed():
    # type: () -> bool
    """Je PROKÁZÁNO, že se identita nepřečetla (na rozdíl od „není nastavená")?

    Vrací True jen při `VERDICT_READ_FAILURE`, tedy když Kodi API vrátilo prázdno,
    ale `settings.xml` hodnotu má. Cokoli nejistého → False: z nejistoty se nesmí
    stát cihla s nápisem „restartuj Kodi".
    """
    if _rm_settings is None:
        return False
    try:
        for key in ("username", "password"):
            if _rm_settings.diagnose_read(key).get("verdict") == \
                    _rm_settings.VERDICT_READ_FAILURE:
                return True
    except Exception:
        return False
    return False


def get_identity_strict():
    # type: () -> Tuple[str, str]
    """Jako `get_identity()`, ale prokázanou poruchu čtení hlásí výjimkou.

    Volá se odtud, kde má prázdná identita fatální důsledek (request bez hlaviček
    → 403). Legitimní „ještě nenastaveno" dál vrací ("", "") — v tom případě má
    volající nabídnout přihlášení, ne křičet o poruše.
    """
    username, proof = get_identity()
    if username and proof:
        return username, proof
    if identity_read_failed():
        raise IdentityUnavailableError("settings read returned empty")
    return "", ""


def get_device_hash():
    # type: () -> str
    """SSOT stabilní device identity (uuid4 per-install) pro per-device logging
    + custom_ui override. Uložen v addon_data/device_id (read-or-create, atomický
    zápis). Stejná hodnota jde do AuthRequest.device_hash, hlavičky X-Device-Hash
    (/v1/* GET), pole device_hash (/v1/* POST body) i telemetrického batche → každý
    log/auth záznam je přiřaditelný konkrétnímu zařízení (mig 0016, incident bandog
    2026-06-27). Best-effort → "" on error. Konsolidováno z richmovie_gate._get_device_hash."""
    try:
        prof = xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.richmovie/"
        )
        path = os.path.join(prof, "device_id")
        try:
            with open(path, encoding="utf-8") as fh:
                val = (fh.read() or "").strip()
            if val:
                return val
        except Exception:
            pass
        val = uuid.uuid4().hex
        # 3.5.123: trvanlivě přes SSOT. `device_id` je identita zařízení pro
        # celý Gate (mig 0016) — prázdný soubor po výpadku napájení by vyrobil
        # NOVÉ zařízení, sirotka v registru a ztrátu per-device nastavení.
        try:
            import richmovie_atomic as _atomic
            _atomic.write_text(path, val)
        except Exception:
            pass
        return val
    except Exception:
        return ""


def detect_platform():
    # type: () -> str
    """SSOT detekce platformy zařízení pro VŠECHNY Gate payloady (auth, telemetrie,
    user_logs, mediainfo, csfd, recommendations, crash).

    PROČ tady: tento modul je SSOT identity. Driv mela detekce 4 nezavisle
    (a nekonzistentni) implementace — auth pres `platform.system()` (spravne),
    ale `build_common_fields` pres `System.BuildLabel` a oba LogDrainery pres
    `System.OSVersionInfo`. Ani jeden z tech InfoLabelu neni validni OS label,
    takze Kodi vracel placeholder ("Zaneprazdneno") a `user_logs.platform` byl
    nepouzitelny pro admin diagnostiku per-zarizeni. Jeden zdroj pravdy = konec driftu.

    Format: "Android | <manufacturer> <model>" na Androidu (getprop), jinak
    "<System> | <node>" (napr. "Windows | RICHIE-LENOVO", "Darwin | Barbora-Air").
    Best-effort — jakakoli chyba → "Unknown" (nikdy nevyhodi).
    """
    try:
        import platform as _pf
        system = _pf.system()

        # Android: getprop je spolehlivejsi nez platform.system() (vraci "Linux")
        try:
            import subprocess
            result = subprocess.run(
                ["getprop", "ro.product.manufacturer"],
                capture_output=True, text=True, timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip():
                model_r = subprocess.run(
                    ["getprop", "ro.product.model"],
                    capture_output=True, text=True, timeout=3,
                )
                model = model_r.stdout.strip() if model_r.returncode == 0 else "Unknown"
                return "Android | %s %s" % (result.stdout.strip(), model)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        node = _pf.node() or "Unknown"
        return "%s | %s" % (system, node)
    except Exception:
        return "Unknown"


def build_common_fields():
    # type: () -> Dict[str, Any]
    """Request body fields every /v1/* endpoint expects.

    Each endpoint layers its own fields on top (quality/prompt/keys/...).

    POZOR (3.5.120): tahle funkce plní `ws_username`/`ws_proof` do těla VŠECH
    POST `/v1/*` requestů (telemetrie, mediainfo, csfd, doporučení, user_logs).
    Když se identita nepřečte, odešle se sem prázdná — a Gate takový request
    odmítne. Guard proti tomu je v `post_json()`, ne tady: tahle funkce jen
    skládá tělo a nesmí rozhodovat, jestli se pošle.
    """
    addon = xbmcaddon.Addon(_ADDON_ID)
    username, proof = get_identity()
    return {
        "schema_version": SCHEMA_VERSION,
        "ws_username": username,
        "ws_proof": proof,
        "addon_version": addon.getAddonInfo("version") or "",
        "kodi_version": xbmc.getInfoLabel("System.BuildVersion") or "",
        "platform": detect_platform(),  # SSOT — viz detect_platform() vyse
        "device_hash": get_device_hash(),  # per-device atribuce (mig 0016)
    }


def has_identity():
    # type: () -> bool
    """Cheap check: does addon have Webshare credentials configured?

    No network call — safe to call before every Gate-dependent UI render.
    """
    username, proof = get_identity()
    return bool(username and proof)


# --------------------------------------------------------------------------- #
# HTTP transport — přes richmovie_http (SSOT retry vrstva, Φ3 2026-08-08)
# --------------------------------------------------------------------------- #

# POST endpointy, které SNESOU zopakování. Whitelist je tady schválně a ne
# v `richmovie_http` — znalost endpointů patří transportní vrstvě Gate, ne obecné
# HTTP vrstvě (ta nemá tušit, co je `/v1/mediainfo/publish`).
#
# Kritérium zařazení: request buď nic nemění (lookup, auth), nebo je na straně
# Gate idempotentní přes deduplikaci. Cokoli, co ZAPISUJE nový záznam bez
# deduplikačního klíče, sem NESMÍ — duplicitní řádek v databázi je horší než
# chybějící, a telemetrie/logy mají vlastní buffer, který ztrátu dožene sám.
_IDEMPOTENT_POST_PATHS = (
    "/auth",                        # čtení lease, opakování je bezpečné
    "/status",                      # hlášení stavu, poslední zápis vyhrává
    "/v1/mediainfo/bulk_lookup",    # čistý lookup, nic nemění
    "/v1/tmdb/",                    # TMDb proxy — read-only
    "/v1/csfd/status",              # čtení stavu profilu
    "/health",                      # zdravotní sonda
)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_gate_transport.py
# _is_idempotent_post  (vytvořeno: 08.08.2026 12:10 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _is_idempotent_post(path):
    # type: (str) -> bool
    """Smí se tenhle POST endpoint zopakovat po přechodné chybě?

    Default je **NE**. Zápisové cesty (`/v1/user_logs/batch`, `watch_events`,
    `/v1/mediainfo/publish`, crash reporty, CSFD sync) se neopakují: buď mají
    vlastní buffer s backoffem, nebo by druhý pokus vyrobil duplicitní řádek.
    """
    try:
        target = str(path or "")
        return any(target.startswith(prefix) for prefix in _IDEMPOTENT_POST_PATHS)
    except Exception:
        return False
def gate_headers(accept="application/json", content_type=None):
    """SSOT hlaviček pro KAŽDÝ požadavek na Gate přes Cloudflare (GET, POST, PATCH,
    DELETE, binární GET). User-Agent je povinný — bez něj Cloudflare Bot Fight Mode /
    Browser Integrity Check vrací 403 („blocked access based on your browser's
    signature", error 1010; incident 2026-04-19 a znovu 05.09.2026 u GET /v1/profiles/,
    který hlavičku nestavěl přes tuhle funkci)."""
    try:
        version = xbmcaddon.Addon(_ADDON_ID).getAddonInfo("version") or "unknown"
    except Exception:   # harness / nástroje mimo Kodi: UA musí existovat vždy (Cloudflare)
        version = "unknown"
    import uuid as _uuid
    headers = {
        "Accept": accept,
        "User-Agent": "RichMovie/%s (+plugin.video.richmovie)" % version,
        # korelace klient ↔ Gate log (asgi-correlation-id přebírá X-Request-ID)
        "X-Request-ID": _uuid.uuid4().hex,
    }
    if content_type:
        headers["Content-Type"] = content_type
    return headers


AUTH_SCHEME = "RM-Proof"


def auth_header(username, proof):
    # type: (str, str) -> Dict[str, str]
    """Identita pro GET/DELETE `/v1/profiles/*` v hlavičce (3.5.147, D6): proof nepatří do
    URL (logy proxy a Cloudflare, historie). Gate od 10.09.2026 přijímá
    `Authorization: RM-Proof <ws_username>:<ws_proof>`; query parametry zůstávají jen
    pro starší addony. SSOT tvaru hlavičky = tahle funkce."""
    return {"Authorization": "%s %s:%s" % (AUTH_SCHEME, username, proof)}


def post_json(path, body, timeout=DEFAULT_TIMEOUT_SECONDS, idempotent=None, profile=None):
    # type: (str, Dict[str, Any], float, Optional[bool]) -> Tuple[int, Dict[str, Any]]
    """POST JSON to Gate, return (http_status, parsed_body).

    Does NOT raise on HTTP 4xx/5xx — returns the Gate error envelope so each
    client can translate error codes per its own endpoint contract.

    Raises only for transport failures (DNS, connection refused, socket
    timeout, TLS error) — caller catches `Exception` around this function.

    `Retry-After` response header (from 429s) is surfaced via the returned
    body under `error.retry_after` so clients can honor server-driven pacing.

    Φ3 network resilience (2026-08-08)
    -----------------------------------
    Transport nově teče přes `richmovie_http` (SSOT retry vrstva). Chování se
    pro volající NEMĚNÍ — 4xx/5xx se dál vrací jako `(status, parsed)` a jen
    transportní chyby propagují jako výjimka. Přibylo:

        • opakování přechodných chyb (síť, DNS, 502/503/504) v rámci rozpočtu,
        • fail-fast, když je zařízení prokazatelně offline (`OfflineError`,
          podtřída `Exception` — volající ji odbaví stávající větví),
        • `idempotent` — kdo smí retry a kdo ne (viz `_IDEMPOTENT_POST_PATHS`).

    Args:
        idempotent: None = rozhodne whitelist podle `path`. Explicitní True/False
                    přebíjí (např. jednorázová migrace, která se nesmí opakovat).
        profile:    `richmovie_http.RetryProfile` pro volání na UI cestě (Φ7, 29.09.2026: hromadné obohacení
                    výpisu `bulk_fetch` = `profile_foreground()`); None = `background` s `timeout` (beze změny).
    """
    headers = gate_headers(content_type="application/json")

    if idempotent is None:
        idempotent = _is_idempotent_post(path)

    # 3.5.118 (2026-08-21): fail-fast na zamítnutou identitu. Když dostupný Gate
    # identitu autoritativně odmítl, každý další identitu nesoucí POST dopadne
    # stejně — vracíme syntetický 403 LOKÁLNĚ (bez sítě), ve stejném tvaru
    # obálky, jaký by poslal Gate, takže volající ho odbaví stávající 403 větví.
    # `/auth` je VÝJIMKA: je to jediná cesta zotavení (nové heslo → nový proof).
    _identity_sent = bool(isinstance(body, dict) and body.get("ws_proof"))
    if (_identity_sent and path != "/auth" and _identity is not None
            and _identity.is_rejected()):
        _reason = _identity.rejection_reason()
        _log("IDENTITY_FAILFAST path=%s reason=%s" % (path, _reason),
             xbmc.LOGWARNING, context={"path": path, "reason": _reason})
        return 403, {"status": "error",
                     "error": {"code": _reason or "not_authorized",
                               "message": "identity rejected (local fail-fast)"}}

    # 3.5.120: request s PRÁZDNOU identitou se neposílá, když je prokázané, že
    # se identita jen nepřečetla. `build_common_fields()` plní `ws_username`/
    # `ws_proof` do těla VŠECH POST /v1/*, takže porucha čtení jinak rozešle
    # anonymní requesty, které Gate odmítne — a uživatel dostane modál
    # „Data se nepodařilo načíst" (incident bandog 27.08.2026).
    # `/auth` je VÝJIMKA ze stejného důvodu jako výše: je to cesta zotavení.
    if (path != "/auth" and isinstance(body, dict) and "ws_proof" in body
            and not body.get("ws_proof") and identity_read_failed()):
        _log("IDENTITY_UNAVAILABLE path=%s — request se neodesílá" % (path,),
             xbmc.LOGWARNING,
             context={"path": path, "err_class": "identity_unavailable"})
        raise IdentityUnavailableError("post_json %s" % path)

    # Perf signál (Fáze 3): měř trvání KAŽDÉ cesty (OK / HTTPError / transport
    # výjimka) — finally běží i při propagaci, takže pomalý timeout je vidět.
    _t0 = time.monotonic()
    _status = None  # type: Optional[int]
    try:
        if _rm_http is None:
            raise RuntimeError("richmovie_http neni k dispozici (poskozena instalace)")

        # Profil `background`: Gate klienty běží mimo UI vlákno (auth při startu,
        # MediaInfo workery, telemetrie). Timeout ponechán na hodnotě, kterou
        # volající předal — AI joby legitimně běží 60–120 s (Cloudflare limit 100 s),
        # takže plošný profilový timeout by je uřízl.
        if profile is None:
            profile = _rm_http.profile_background().replace(timeout_s=float(timeout))
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")

        # Vědomě `request()` a ne `request_json()`: ten hlásí nevalidní JSON jako
        # PermanentError, což je správné pro čisté API, ale Gate je za Cloudflare —
        # při 502/504 přijde HTML chybovka, ne JSON. Původní implementace v takovém
        # případě vracela `(status, {"error": {"code": "http_502"}})` a klienti na
        # tom staví; výjimka místo návratu by byla regrese.
        _status, raw, resp_headers = _rm_http.request(
            "%s%s" % (GATE_URL, path),
            method="POST", headers=headers, data=payload,
            profile=profile, idempotent=idempotent, tag="gate",
        )

        try:
            text = raw.decode("utf-8") if raw else ""
            parsed = json.loads(text) if text else {}
        except Exception:
            parsed = {"error": {"code": "http_%s" % _status, "message": ""}}
        if not isinstance(parsed, dict):
            parsed = {}

        # 3.5.118: jediný hook stavu identity pro POST cestu (včetně `/auth`,
        # kde 403 s `not_authorized`/`proof_required` = autoritativní zamítnutí).
        if _identity is not None:
            _identity.observe_gate_response(_status, parsed, identity_sent=_identity_sent)

        # Retry-After z 429 předáváme volajícímu ve stejném tvaru jako dřív —
        # klienti (TMDb cooldown, AI router) na tom staví svoje pacing.
        if _status == 429:
            retry_after = None
            try:
                retry_after = resp_headers.get("Retry-After") if resp_headers else None
            except Exception:
                retry_after = None
            if retry_after:
                try:
                    parsed.setdefault("error", {})["retry_after"] = int(retry_after)
                except (ValueError, TypeError):
                    pass

        return _status, parsed
    finally:
        try:
            _elapsed = time.monotonic() - _t0
            if _elapsed >= SLOW_REQUEST_THRESHOLD_S:
                _log(
                    "SLOW_REQUEST path=%s elapsed=%.1fs status=%s timeout=%s"
                    % (path, _elapsed, _status, timeout),
                    xbmc.LOGWARNING,
                    context={"path": path, "elapsed_s": round(_elapsed, 2),
                             "status": _status, "timeout_s": timeout,
                             "idempotent": bool(idempotent)},
                )
        except Exception:
            pass
    # Transport errors (URLError, socket.timeout, ConnectionError, ssl.SSLError)
    # propagate — callers wrap with try/except and translate to their error taxonomy.


# --------------------------------------------------------------------------- #
# MediaInfo probe helpers — Phase I1 (2026-04-19). Shared between
# richmovie_webshare a richmovie_fastshare (DRY + SSOT rule).
# --------------------------------------------------------------------------- #

def probe_mediainfo_via_gate(source, source_ident, file_link_url,
                              probe_max_mb=None, cookies=None, timeout=30):
    # type: (str, str, str, Optional[int], Optional[Dict[str, str]], int) -> Optional[Dict[str, Any]]
    """Gate-side MediaInfo probe. Returns canonical MI payload dict or None.

    Addon sends file_link URL (short-lived CDN download token), Gate
    ranged-downloads + runs libmediainfo + upserts to mi_cache. No local
    libmediainfo binary needed on the client.

    `cookies` — optional dict of cookies to forward (Fastshare potřebuje
    FASTSHARE=hash cookie pro download; Webshare URL-self-auth má None).
    """
    username, proof = get_identity()
    if not username or not proof:
        return None
    body = {
        "schema_version": "v1",
        "ws_username": username,
        "ws_proof": proof,
        "source": source,
        "source_ident": source_ident,
        "file_link_url": file_link_url,
    }
    if probe_max_mb:
        body["probe_max_mb"] = int(probe_max_mb)
    if cookies:
        body["cookies"] = dict(cookies)
    # probe může trvat 10-15s (ranged download + parse); 30s timeout je
    # konzervativní horní limit. Addon volá ze samostatného threadu
    # (MediaInfoSecondEdition), takže UI nezablokuje.
    #
    # 3.5.118: KONTRAKT NÁVRATU (R2 plánu — selhání infrastruktury se neperzistuje):
    #   dict  → probe proběhl, payload
    #   None  → Gate AUTORITATIVNĚ řekl „nemám" (200 se status != ok / bez payloadu)
    #   raise GateAuthError   → identita zamítnuta (403 s Gate kódem / lokální fail-fast)
    #   raise GateProbeError  → 5xx / 429 / jiný non-200 (infrastruktura)
    #   raise (transport)     → propaguje z post_json (TransientError/OfflineError…)
    # Do 3.5.117 se VŠECHNO vracelo jako None a MI2 to zapsal jako `empty` marker.
    status, resp = post_json("/v1/mediainfo/probe", body, timeout=timeout)
    if not isinstance(resp, dict):
        resp = {}
    if status in (401, 403):
        code = ""
        if _identity is not None:
            code = _identity.extract_gate_error_code(resp)
        raise GateAuthError(status, code)
    if status != 200:
        code = ""
        if _identity is not None:
            code = _identity.extract_gate_error_code(resp)
        # 3.5.129: 422 `not_media` = autoritativní odmítnutí ODKAZU (Gate Φ3),
        # ne infrastruktury. Rozhoduje KÓD v těle, nikdy samotný stav 422
        # (422 bez kódu je chyba kontraktu → GateProbeError, neperzistovat).
        if status == 422 and code == GateNotMediaError.CODE:
            raise GateNotMediaError(status, code)
        raise GateProbeError(status, code)
    if resp.get("status") != "ok":
        return None
    payload = resp.get("payload")
    if not isinstance(payload, dict):
        return None
    # Obrana proti staršímu Gate (před 02.09.2026), který HTML stránku vracel
    # jako 200 + `container=unknown` bez tracků: tvar payloadu rozhoduje stejně
    # jako na serveru. Bez toho by `_extract` zapsal „titulky prokazatelně
    # nejsou" (sub_present=False) z prázdného obalu. Je to chyba KONTRAKTU
    # (starý server), ne autoritativní odmítnutí → `GateProbeError` bez markeru
    # (cross-check Pro 02.09.2026, PA9): starý Gate takhle vracel i dočasné
    # restrikce CDN, marker by je zafixoval.
    if not is_media_payload(payload):
        raise GateProbeError(status, "not_media_shape")
    return payload


def gate_payload_to_legacy_mi(payload):
    # type: (Dict[str, Any]) -> Dict[str, Any]
    """Convert Gate canonical MediaInfoPayload → legacy pymediainfo shape.

    Legacy callers (mi2._extract) expect:
        {"duration": int_sec,
         "tracks": [{"track_type": ..., "language": ..., "codec_id": ...}, ...]}
    """
    tracks = []
    # General track
    tracks.append({
        "track_type": "General",
        "format": payload.get("container") or "",
        "duration": (payload.get("duration_sec") or 0) * 1000,  # ms
    })
    vid = payload.get("video") or {}
    if vid:
        tracks.append({
            "track_type": "Video",
            "codec_id": vid.get("codec") or "",
            "width": vid.get("width"),
            "height": vid.get("height"),
            "bit_rate": (vid.get("bitrate_kbps") or 0) * 1000,
            "frame_rate": vid.get("fps"),
            # Noc 03.11.2026 (Φ3): Dolby Vision projde až do nápověd MI2 (`mi2._extract`)
            "hdr": vid.get("hdr"),
            "dv_profile": vid.get("dv_profile"),
            "dv_compat": vid.get("dv_compat"),
        })
    for a in (payload.get("audio") or []):
        tracks.append({
            "track_type": "Audio",
            "codec_id": a.get("codec") or "",
            "language": a.get("lang"),
            "channel_s": a.get("channels"),
            "bit_rate": (a.get("bitrate_kbps") or 0) * 1000,
            "title": a.get("title"),
            "default": a.get("default"),
            "forced": a.get("forced"),
        })
    for s in (payload.get("subtitles") or []):
        tracks.append({
            "track_type": "Text",
            "codec_id": s.get("codec") or "",
            "language": s.get("lang"),
            "title": s.get("title"),
            "forced": s.get("forced"),
        })
    return {
        "duration": int(payload.get("duration_sec") or 0),
        "tracks": tracks,
    }


# --------------------------------------------------------------------------- #
# Introspection / diagnostics
# --------------------------------------------------------------------------- #
def get_gate_url():
    # type: () -> str
    """Expose Gate base URL for modules that need it (e.g. crash reporter)."""
    return GATE_URL
