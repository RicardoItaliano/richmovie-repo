# -*- coding: utf-8 -*-
"""
richmovie_attention — SSOT bdělosti diváka u řetězu dílů (3.5.149, 14.09.2026)
==============================================================================

Plán `Handoff/PLAN_binge_attention_20260914.md`. Incident 12.→14.09.2026: telefon
před spaním, autoplay řetězil Červený trpaslík S08E04 → S09E02 (8 dílů, 0 pauz,
0 seeků), až došla baterie; všechno dostalo zelené ✔ a „Pokračovat" ukazoval díl,
který nikdo neviděl.

Jedna pravda o tom, jestli u dílu někdo BYL:
  • **vstup** = jakýkoli signál člověka: Kodi `getGlobalIdleTime()` klesne (dálkové
    ovládání, dotyk, myš, klávesa), pauza/resume/seek z přehrávače, RUČNÍ spuštění
    titulu (uživatel klikl = je tam). Autoplay ručním spuštěním NENÍ.
  • **díl bez vstupu** (`unattended`) = od začátku do konce dílu nepřišel žádný vstup.
    Jeden takový díl je normální (tichý divák). Řetěz je podezřelý.
  • **dotaz „Díváš se ještě?"** (`should_ask`) před dalším autoplayem, když řetěz dílů
    bez vstupu dosáhl `ask_after` NEBO od posledního vstupu uplynulo `idle_min` minut.
  • **4.0.3 (D1–D3 10.10.2026, incident 06.10.)**: tichý divák JE divák. Dokoukaný díl dostane ✔
    `attended` hned; „⏾ usnul jsi?“ (`unattended`) jen při PROKÁZANÉM spánku = dotaz vypršel bez odpovědi
    (`richmovie_still_watching.RESULT_TIMEOUT`) — tehdy verdikt spánku sníží díly řetězu (`chain`) a
    Pokračovat se vrátí na první z nich s volbou „od začátku / viděl jsem ho“. Odpověď KTERÝMKOLI tlačítkem
    = člověk je tu: „Pokračovat“ jede dál, „Dnes už končím“ skončí bez trestu (Pokračovat = další díl).
    Dřív dostal ⏾ (= v seznamu neviděno) každý autoplay díl bez doteku ovladače a „Skončit“ i vypršení
    vrátily Pokračovat zpět — divačka pak druhý den hledala, kde skončila.
  • **stav ✔ je typovaný**: `attended` (dokoukáno) / `unattended` (prokázaný spánek, „⏾") / `manual`
    (ručně „Viděl jsem to"). Lokálně `watched_episodes.json[].kind`, na Gate osa zhlédnutí (mig 0030/0038).
  • `current_kind()` dál měří PŘÍTOMNOST u dílu (vstup ano/ne) pro telemetrii doporučení (kulisa).

Modul je čistý (žádné Kodi importy) — tracker dostává čas a idle zvenčí, takže ho
kryje harness (scénář 58). Služba `service_nextup` ho krmí: `begin()` v onAVStarted,
`sample_idle()` v každém tiku, `note_input()` z pauzy/seeku, `finish()` při NATURAL
konci; telemetrický hook čte `current_kind()` pro vlastní zápis ✔.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, List, Optional

KIND_ATTENDED = "attended"
KIND_UNATTENDED = "unattended"
KIND_MANUAL = "manual"
KINDS = (KIND_ATTENDED, KIND_UNATTENDED, KIND_MANUAL)

DEFAULT_ASK_AFTER = 3          # D2 (10.10.2026, jako Netflix): dotaz po 3 dílech bez vstupu (0 = vypnutý)
DEFAULT_IDLE_MIN = 90          # D2: …nebo po 90 min bez jakéhokoli vstupu (dřív 2 / 60 = dotaz uprostřed večera)
DEFAULT_ASK_TIMEOUT_S = 60     # odpočet dialogu; bez odpovědi = konec řetězu
IDLE_TOLERANCE_S = 5.0         # Kodi idle vs. čas od startu dílu: menší rozdíl = šum tiku

STATE_FILE = "attention_state.json"
STATE_MAX_AGE_S = 6 * 3600     # obnovený řetěz starší než 6 h už není „tahle noc"

SETTING_ASK_AFTER = "nextup_ask_after_unattended"
SETTING_IDLE_MIN = "nextup_ask_idle_min"
SETTING_ASK_TIMEOUT = "nextup_ask_timeout_s"


def normalize_kind(value: Any) -> str:
    return value if value in KINDS else KIND_ATTENDED


def should_ask(streak: int, idle_s: float, *, ask_after: int = DEFAULT_ASK_AFTER,
               idle_min: float = DEFAULT_IDLE_MIN) -> bool:
    """Před dalším autoplayem: ptát se? `ask_after <= 0` = funkce vypnutá (nikdy).
    Řetěz `streak` dílů bez vstupu dosáhl prahu, NEBO od posledního vstupu uplynulo
    `idle_min` minut (dlouhé díly: 1 film o 2 h bez vstupu = taky spí)."""
    ask_after = int(ask_after or 0)
    if ask_after <= 0:
        return False
    if int(streak) >= ask_after:
        return True
    return float(idle_min) > 0 and float(idle_s) >= float(idle_min) * 60.0


# Výsledek dotazu „Díváš se ještě?" (4.0.3, `richmovie_still_watching`) — jedna sada hodnot pro okno i zálohu.
ANSWER_CONTINUE = "continue"   # „Pokračovat"
ANSWER_STOP = "stop"           # „Dnes už končím" / Zpět — člověk je tu, další díl nechce
ANSWER_TIMEOUT = "timeout"     # odpočet doběhl bez stisku = prokázaný spánek (verdikt spánku)
ANSWER_ABORT = "abort"         # Kodi se vypíná — řetěz dořeší start služby
FALLBACK_EARLY_CLOSE_S = 1.0   # záloha: dialog zavřený dřív než `timeout − 1 s` = zavřel ho člověk


def classify_dialog_fallback(confirmed: bool, open_s: float, timeout_s: float, idle_s: float) -> str:
    """Záložní `yesno` (bez vlastního okna) vrací při vypršení totéž co „Ne" → odpověď se pozná jinak (čisté,
    harness 90): potvrzeno = pokračovat; zavřeno dřív než odpočet = tlačítko „Dnes už končím" (i dotykem, který
    nečinnost Kodi NEnuluje — `InputManager.cpp`); nečinnost kratší než doba otevření = během dialogu přišel
    vstup (klávesa prodlužuje odpočet) → člověk je tu. Jinak vypršení = spánek."""
    if confirmed:
        return ANSWER_CONTINUE
    if float(open_s) < float(timeout_s) - FALLBACK_EARLY_CLOSE_S:
        return ANSWER_STOP
    if float(idle_s) < float(open_s) - FALLBACK_EARLY_CLOSE_S:
        return ANSWER_STOP
    return ANSWER_TIMEOUT


class AttentionTracker:
    """Stav bdělosti přes VÍCE dílů jednoho řetězu (jedna instance na proces služby).
    Vlákna: callbacky Kodi, watch_loop i hook píší souběžně → jeden zámek."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.key = ""                      # klíč právě hraného titulu (`player_ctx_key`)
        self.autoplay = False              # tenhle díl spustil autoplay (ne člověk)
        self.input_seen = False            # během TOHOTO dílu přišel vstup
        self.started_ts = 0.0
        self.last_input_ts = 0.0           # napříč díly (idle_s)
        self.streak = 0                    # po sobě jdoucí díly bez vstupu
        self.first_unattended: Optional[Dict[str, Any]] = None   # snímek prvního dílu řetězu bez vstupu
        self.chain: List[List[Any]] = []   # [tv_id, season, episode] dílů řetězu bez vstupu (verdikt spánku)
        self.last_kind = KIND_ATTENDED
        self.last_finished = ("", KIND_ATTENDED)   # (klíč, verdikt) posledního uzavřeného dílu
        self._last_idle: Optional[float] = None
        # kdy se zobrazil dotaz „Díváš se ještě?“ k tomuto řetězu (0 = nezobrazil). Verdikt spánku při startu
        # služby JEN s ním: Kodi na Androidu zabíjí aplikaci i v titulcích (M8) — řetěz bez zobrazeného dotazu
        # není důkaz spánku (D1, audit Fable A-V9 10.10.2026)
        self.ask_shown_at = 0.0

    # ── životní cyklus dílu ───────────────────────────────────────────────────
    def begin(self, key: str, *, autoplay: bool, now: Optional[float] = None) -> None:
        now = time.time() if now is None else float(now)
        with self._lock:
            self.key = key or ""
            self.autoplay = bool(autoplay)
            self.started_ts = now
            self._last_idle = None
            self.last_kind = KIND_ATTENDED
            if autoplay:
                self.input_seen = False
            else:
                # ruční spuštění = člověk je u toho; řetěz začíná od nuly
                self.input_seen = True
                self.last_input_ts = now
                self.streak = 0
                self.first_unattended = None
                self.chain = []
                self.ask_shown_at = 0.0
            if self.last_input_ts <= 0:
                self.last_input_ts = now

    def note_input(self, now: Optional[float] = None) -> None:
        """Pauza/resume/seek/klávesa: člověk je tu. Řetěz se nuluje."""
        now = time.time() if now is None else float(now)
        with self._lock:
            self.input_seen = True
            self.last_input_ts = now
            self.streak = 0
            self.first_unattended = None
            self.chain = []
            self.ask_shown_at = 0.0

    def note_ask_shown(self, now: Optional[float] = None) -> None:
        """Dotaz „Díváš se ještě?“ je na obrazovce (volat PŘED zobrazením a uložit stav na disk)."""
        with self._lock:
            self.ask_shown_at = time.time() if now is None else float(now)

    def sample_idle(self, idle_s: float, now: Optional[float] = None) -> bool:
        """Vzorek Kodi `getGlobalIdleTime()` (sekundy od posledního vstupu do Kodi).
        True = od minulého vzorku přišel vstup.

        PRVNÍ vzorek dílu: vstup poznáme podle toho, že je idle KRATŠÍ než doba od startu dílu
        (někdo sáhl na ovladač po startu, ale dřív, než jsme stihli vzorkovat).
        DALŠÍ vzorky: rozhoduje výhradně POKLES idle. Cross-check Flash 14.09.2026 (P0): dřív se
        porovnání s dobou od startu dělalo při každém vzorku — jenže po jediném vstupu na začátku
        dílu platí `idle < elapsed` až do konce, takže tracker hlásil bdělost i u spícího diváka
        a dotaz „Díváš se ještě?" nepřišel nikdy."""
        now = time.time() if now is None else float(now)
        idle_s = float(idle_s)
        seen = False
        with self._lock:
            if self._last_idle is not None:
                seen = idle_s < self._last_idle
            elif self.started_ts and not self.input_seen:
                seen = idle_s + IDLE_TOLERANCE_S < max(0.0, now - self.started_ts)
            self._last_idle = idle_s
        if seen:
            self.note_input(now)
        return seen

    def finish(self, now: Optional[float] = None, snapshot: Optional[Dict[str, Any]] = None,
               key: str = "") -> str:
        """Konec dílu (NATURAL). Vrátí kind a posune řetěz. `snapshot` = CW metadata dílu
        (tv_id, tv_name, season, episode, ep_title, poster_path, backdrop_path, duration)
        — u prvního dílu bez vstupu se uloží pro návrat „Pokračovat" (D2)."""
        now = time.time() if now is None else float(now)
        with self._lock:
            if key and self.key and key != self.key:
                # mezitím už začal další díl — verdikt tohohle dílu je hotový, řetěz se neposouvá
                return self.last_finished[1] if self.last_finished[0] == key else KIND_ATTENDED
            kind = KIND_ATTENDED if self.input_seen else KIND_UNATTENDED
            if kind == KIND_UNATTENDED:
                self.streak += 1
                if self.first_unattended is None and snapshot:
                    self.first_unattended = dict(snapshot)
                if snapshot:
                    try:
                        self.chain.append([str(snapshot.get("tv_id") or ""), int(snapshot.get("season") or 0),
                                           int(snapshot.get("episode") or 0)])
                    except (TypeError, ValueError):
                        pass
            self.last_kind = kind
            self.last_finished = (self.key, kind)
            return kind

    def current_kind(self, key: str = "") -> str:
        """Verdikt pro končící díl BEZ mutace (telemetrický hook píše ✔ nezávisle na službě).

        `key` = klíč dílu, o který volajícímu jde. Autoplay spustí další díl během několika
        sekund a hook předchozího dílu může doběhnout až potom — bez klíče by pak převzal
        verdikt NOVÉHO dílu a označil viděný díl jako `unattended`. Když klíč nesedí na
        právě běžící díl, vrací se uložený verdikt z `finish()`, jinak `attended`
        (bezpečná strana: ✔ se nikdy neruší kvůli souběhu)."""
        with self._lock:
            if key and key != self.key:
                return self.last_finished[1] if self.last_finished[0] == key else KIND_ATTENDED
            return KIND_ATTENDED if self.input_seen else KIND_UNATTENDED

    def idle_s(self, now: Optional[float] = None) -> float:
        now = time.time() if now is None else float(now)
        with self._lock:
            return max(0.0, now - self.last_input_ts) if self.last_input_ts else 0.0

    def reset_streak(self) -> None:
        with self._lock:
            self.streak = 0
            self.first_unattended = None
            self.chain = []
            self.ask_shown_at = 0.0

    def chain_episodes(self) -> List[List[Any]]:
        """[tv_id, season, episode] dílů řetězu bez vstupu (kopie) — vstup verdiktu spánku."""
        with self._lock:
            return [list(x) for x in self.chain]

    def state(self) -> Dict[str, Any]:
        with self._lock:
            return {"key": self.key, "autoplay": self.autoplay, "input_seen": self.input_seen,
                    "streak": self.streak, "last_kind": self.last_kind, "last_finished": self.last_finished,
                    "first_unattended": dict(self.first_unattended) if self.first_unattended else None,
                    "chain": [list(x) for x in self.chain]}


    # ── perzistence (cross-check Flash/Pro A): telefon umře uprostřed řetězu ────────────
    def dump(self) -> Dict[str, Any]:
        with self._lock:
            return {"streak": self.streak, "last_input_ts": self.last_input_ts,
                    "first_unattended": dict(self.first_unattended) if self.first_unattended else None,
                    "chain": [list(x) for x in self.chain], "ask_shown_at": self.ask_shown_at,
                    "saved_at": time.time()}

    def load(self, data: Dict[str, Any], *, max_age_s: float = STATE_MAX_AGE_S,
             now: Optional[float] = None) -> bool:
        """Obnoví řetěz po startu služby. Starší stav než `max_age_s` se ignoruje (včerejší
        noc dnes večer nikoho zajímat nemá). True = obnoveno."""
        now = time.time() if now is None else float(now)
        try:
            if not isinstance(data, dict) or (now - float(data.get("saved_at") or 0)) > float(max_age_s):
                return False
            snap = data.get("first_unattended")
            chain = [list(x) for x in (data.get("chain") or []) if isinstance(x, (list, tuple)) and len(x) == 3]
            with self._lock:
                self.streak = max(0, int(data.get("streak") or 0))
                self.last_input_ts = float(data.get("last_input_ts") or 0) or now
                self.first_unattended = dict(snap) if isinstance(snap, dict) else None
                self.chain = chain
                self.ask_shown_at = float(data.get("ask_shown_at") or 0)
            return True
        except (TypeError, ValueError):
            return False


TRACKER = AttentionTracker()


def save_state() -> None:
    """Zapíše řetěz na disk (osobní soubor profilu). Volá se po každém uzavřeném dílu bez diváka —
    jinak by vybitá baterie uprostřed řetězu vzala informaci, KDE divák usnul (Flash/Pro A)."""
    try:
        import richmovie_atomic as _at
        import richmovie_paths as _rp
        _at.write_json(str(_rp.personal_dir() / STATE_FILE), TRACKER.dump())
    except Exception:
        pass


def clear_state() -> None:
    """Řetěz je uzavřený (odpověď, rewind, ruční start) → soubor pryč, jinak by po pádu vrátil
    Pokračovat zpět na díl, který uživatel mezitím vědomě přeskočil."""
    try:
        import os
        import richmovie_paths as _rp
        path = str(_rp.personal_dir() / STATE_FILE)
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass


def load_state() -> bool:
    try:
        import richmovie_atomic as _at
        import richmovie_paths as _rp
        data, _state = _at.read_json(str(_rp.personal_dir() / STATE_FILE), {}, expected_type=dict)
        return TRACKER.load(data or {})
    except Exception:
        return False


def boot_sleep_proven(streak: int, ask_shown_at: float, *, ask_after: int) -> bool:
    """Verdikt spánku po startu služby (Kodi zemřelo uprostřed řetězu). Čisté (harness 90).
    JEN když dotaz „Díváš se ještě?“ opravdu padl a zůstal bez odpovědi (`ask_shown_at`) — ne pouhá délka řetězu:
    tichý divák je divák (D1) a Kodi na Androidu zabíjí aplikaci i v titulcích (M8). Vybitý telefon uprostřed
    dotazu dál dá ⏾ (incident 14.09.2026)."""
    return bool(ask_after > 0 and streak >= ask_after and float(ask_shown_at or 0) > 0)


THRESHOLDS_MIGRATION_FILE = "attention_thresholds_v2.json"   # značka: stará výchozí 2 / 60 už převedena na 3 / 90
_OLD_DEFAULT_ASK_AFTER, _OLD_DEFAULT_IDLE_MIN = 2, 60


def migrate_threshold_defaults() -> bool:
    """Jednorázově (služba při startu): uložená STARÁ výchozí hodnota 2 / 60 → nová výchozí 3 / 90 (D2). Kodi po uložení
    dialogu nastavení drží v `addon_data/settings.xml` všechny hodnoty, takže změna výchozí hodnoty by se u části flotily
    neprojevila (audit Fable A-V5). Mění JEN dvojici rovnou staré výchozí (vlastní volbu nechá — vzor
    `richmovie_cache_tuning`); značka v datech doplňku = jednou za zařízení. True = převedeno."""
    try:
        import os
        import richmovie_atomic as _at
        import richmovie_paths as _rp
        import richmovie_settings as _st
        marker = str(_rp.addon_data_dir() / THRESHOLDS_MIGRATION_FILE)
        if os.path.isfile(marker):
            return False
        old = (_st.get_int(SETTING_ASK_AFTER, DEFAULT_ASK_AFTER), _st.get_int(SETTING_IDLE_MIN, DEFAULT_IDLE_MIN))
        changed = old == (_OLD_DEFAULT_ASK_AFTER, _OLD_DEFAULT_IDLE_MIN)
        if changed:
            _st.write(SETTING_ASK_AFTER, str(DEFAULT_ASK_AFTER))
            _st.write(SETTING_IDLE_MIN, str(DEFAULT_IDLE_MIN))
        _at.write_json(marker, {"done_at": time.time(), "old": list(old), "changed": changed})
        return changed
    except Exception:
        return False


def settings_thresholds() -> Dict[str, int]:
    """Prahy z nastavení (SSOT `richmovie_settings`); mimo Kodi výchozí."""
    out = {"ask_after": DEFAULT_ASK_AFTER, "idle_min": DEFAULT_IDLE_MIN, "timeout_s": DEFAULT_ASK_TIMEOUT_S}
    try:
        import richmovie_settings as _st
        out["ask_after"] = max(0, _st.get_int(SETTING_ASK_AFTER, DEFAULT_ASK_AFTER))
        out["idle_min"] = max(0, _st.get_int(SETTING_IDLE_MIN, DEFAULT_IDLE_MIN))
        out["timeout_s"] = max(10, _st.get_int(SETTING_ASK_TIMEOUT, DEFAULT_ASK_TIMEOUT_S))
    except Exception:
        pass
    return out
