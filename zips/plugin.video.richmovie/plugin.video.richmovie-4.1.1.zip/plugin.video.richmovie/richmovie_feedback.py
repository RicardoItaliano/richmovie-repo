# -*- coding: utf-8 -*-
"""RichMovie — okamžitá odezva na kliknutí (Φ2, 29.09.2026).

PROČ EXISTUJE (audity A02, A07, A10 — `Temp/ux_latency_20260929/`)
------------------------------------------------------------------
Kodi dává vlastní odezvu jen dvěma druhům kliknutí: složce (kolečko po 100 ms) a přehratelné položce
(modální kolečko resolve). Akce bez handle (`RunPlugin`, kontextové menu, handle −1) nedostanou od Kodi
NIC — a přesně ty dělaly síť dřív, než cokoli ukázaly: „Kdo se dívá?“ čekal na Gate až 12 s, ČSFD profil
na `/v1/csfd/status`, „Už jsem to viděl“ na `/dismiss`, Stáhnout na `file_link`. Lidé klikali znovu
(25,8 % kliknutí na výběr profilu byl dvojklik) a „Pokračovat“ tak dokonce shazovalo Kodi (Φ1).

Druhá polovina problému byla řeč: 58 přímých toastů s deseti různými délkami, 115 z nich cinkalo i u
běžné informace a část ukazovala technický výpis výjimky („Transport unavailable: …“).

KONTRAKT (jediné místo, které rozhoduje, JAK addon odpoví)
----------------------------------------------------------
    info("Viděno ✔ · Dune")                 # tichý toast: potvrzení nebo výsledek
    warn("Uložit se nepodařilo.")           # toast se zvukem: něco se nepovedlo, chce to pozornost
    error(exc, heading="ČSFD")              # výjimka → česká věta (přechodná = toast, trvalá = dialog)
    with working("Načítám stav ČSFD…") as w:  # práce přes síť: nenápadný průběh v rohu
        w.update("Ukládám…")

`working` se ukáže až po `SHOW_DELAY_S` — stejná prodleva, po které Kodi ukáže kolečko u složky
(`CGUIDialogBusy::WaitOnEvent`, 100 ms). Rychlá akce tak nic neblikne, pomalá hned řekne, co dělá.
Nemodální (`DialogProgressBG`): nikdy se nevnoří do busy dialogu Kodi (pád 21.2, Φ1) a neblokuje Zpět.

Primitivum toastu (délka podle textu, zvuková politika D7) zůstává `richmovie_helpers.notif`; tady je
politika nad ním. Třídu odezvy každé akce nese registr `richmovie_routes` (`feedback_class`), harness
scénář 73 hlídá, že přímé `Dialog().notification(` jinde nepřibude.

Python 3.8 (Kodi runtime).
"""
from __future__ import annotations

import threading
from typing import Optional

from richmovie_helpers import net_error_message as _net_error_message
from richmovie_helpers import notif as _notif

try:  # pragma: no cover - mimo Kodi (harness má stuby)
    import xbmc
    import xbmcgui
except ImportError:  # pragma: no cover
    xbmc = None  # type: ignore
    xbmcgui = None  # type: ignore

HEADING = "RichMovie"

# Prodleva, po které se ukáže průběh práce: tatáž, po které Kodi ukazuje kolečko u složky
# (`CGUIDialogBusy::WaitOnEvent(event, 100)`). Kratší = bliknutí u rychlé akce, delší = ticho.
SHOW_DELAY_S = 0.1

# Věta pro chybu, kterou nejde přeložit (selhal i sám překlad) — nikdy technický text.
FALLBACK_ERROR_TEXT = "Něco se nepovedlo. Zkus to prosím znovu."


def _log(msg: str, warning: bool = False) -> None:
    """Do user_logs (routovaný logger), fallback kodi.log. Nikdy nevyhazuje."""
    try:
        import richmovie_logging as _rl
        lg = _rl.get_logger("richmovie.feedback")
        (lg.warning if warning else lg.info)(msg)
    except Exception:
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/Feedback] %s" % msg, xbmc.LOGWARNING if warning else xbmc.LOGINFO)
        except Exception:
            pass


# S31 (08.11.2026): výpadek Webshare během hledání — pravdivá věta místo „nic nenalezeno“ (SSOT textů; KDY která
# věta zazní, rozhoduje JEDINÁ funkce `richmovie_search_telemetry.source_down_code`)
SOURCE_DOWN_TEXTS = {
    "with_results": "Webshare teď neodpovídá — ukazuji výsledky z Fastshare.",
    "empty": "Webshare teď neodpovídá a na Fastshare jsem nic nenašel. Zkus to za chvilku.",
    "ws_only": "Webshare teď neodpovídá. Zkus to za chvilku.",
}


def info(msg: str, heading: str = HEADING) -> None:
    """Tichý toast: potvrzení kliknutí nebo úspěšný výsledek (D7 — informace necinká)."""
    _notif(msg, xbmcgui.NOTIFICATION_INFO, None, heading, False)


def warn(msg: str, heading: str = HEADING) -> None:
    """Toast se zvukem: akce se nepovedla nebo je potřeba pozornost. Text musí být lidská věta."""
    _notif(msg, xbmcgui.NOTIFICATION_WARNING, None, heading, True)


def error(exc: BaseException, heading: str = HEADING) -> bool:
    """Výjimka → česká věta podle TŘÍDY chyby (`net_error_message`). Technický detail jde jen do logu.

    Přechodná chyba (síť, timeout, 5xx) = nenápadný toast, nic se neblokuje. Trvalá (chybí oprávnění,
    neexistuje) = dialog OK, protože ta si pozornost zaslouží. Vrací, jestli byla chyba přechodná.
    """
    try:
        message, transient = _net_error_message(exc)
    except Exception:
        message, transient = FALLBACK_ERROR_TEXT, False
    _log("UI_ERROR heading=%r: %r" % (heading, exc), warning=True)
    if transient:
        _notif(message, xbmcgui.NOTIFICATION_WARNING, None, heading, True)
    else:
        try:
            xbmcgui.Dialog().ok(heading, message)
        except Exception as exc2:
            _log("UI_ERROR dialog failed: %r" % (exc2,), warning=True)
    return transient


class Working(object):
    """Průběh práce v rohu obrazovky (nemodální). Používej přes `working()`.

    Dialog vzniká až po `SHOW_DELAY_S` v časovači; zavření časovač zruší a počká na něj, takže
    po `close()` už žádný dialog nevznikne (ani když časovač běží právě v tu chvíli)."""

    def __init__(self, message: str, heading: str = HEADING) -> None:
        self._heading = heading
        self._message = message
        self._percent = 0
        self._lock = threading.Lock()
        self._dialog = None  # type: Optional[object]
        self._closed = False
        self._timer = threading.Timer(SHOW_DELAY_S, self._show)
        self._timer.name = "RMFeedbackShow"

    def start(self) -> "Working":
        self._timer.start()
        return self

    def _show(self) -> None:
        with self._lock:
            if self._closed:
                return
            try:
                dlg = xbmcgui.DialogProgressBG()
                dlg.create(self._heading, self._message)
                if self._percent:
                    dlg.update(self._percent, message=self._message)
                self._dialog = dlg
            except Exception as exc:
                _log("working: dialog failed: %r" % (exc,), warning=True)

    def update(self, message: Optional[str] = None, percent: Optional[int] = None) -> None:
        """Nový text a/nebo procento (0–100). Před zobrazením se jen zapamatuje."""
        with self._lock:
            if message:
                self._message = message
            if percent is not None:
                self._percent = max(0, min(100, int(percent)))
            if self._dialog is not None:
                try:
                    self._dialog.update(self._percent, message=self._message)
                except Exception:
                    pass

    def close(self) -> None:
        self._timer.cancel()
        with self._lock:
            self._closed = True
            dlg, self._dialog = self._dialog, None
        if self._timer.is_alive():
            self._timer.join()
        if dlg is not None:
            try:
                dlg.close()
            except Exception:
                pass

    def __enter__(self) -> "Working":
        return self

    def __exit__(self, *_exc) -> bool:
        self.close()
        return False


def working(message: str, heading: str = HEADING) -> Working:
    """Průběh práce, která jde přes síť nebo trvá déle než mrknutí. `with working("…") as w:`."""
    return Working(message, heading).start()
