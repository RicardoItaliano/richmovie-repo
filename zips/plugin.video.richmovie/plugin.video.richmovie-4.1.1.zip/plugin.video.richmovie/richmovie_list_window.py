# -*- coding: utf-8 -*-
"""RichMovie 4.0 — generické list okno (WindowXMLDialog) — Φ0 long-tail.

Payload-driven vertikální seznam, který nahrazuje Kodi directory listingy pro
long-tail obrazovky (Historie, Kolekce, NAS browser, ČSFD tipy, Zdroje…). Dostane
hotové ListItemy (postavené původní funkcí přes richmovie_rmdir.RmDir) — žádná
duplikace datové/obohacovací logiky. Stackuje se nad Home/Hub (doModal), Back vrací.

Klik routuje podle property na položce (nastavuje RmDir.add):
  • rm_playable=1  → přehrát: Dialog.Close(all) + mark_play_from_ui + PlayMedia(url)
                     (smb:// i plugin://action=*_play → setResolvedUrl — bez flashe).
  • rm_isFolder=1  → navigace: RunPlugin(url) → cílová akce přes RmDir
                     otevře DALŠÍ list okno (stack roste, Back zavře).
  • jinak          → RunPlugin(url) (custom detail apod.).

Context menu (ACTION_CONTEXT_MENU): čte rm_ctx_json z položky → Dialog().contextmenu.
SSOT helpery: richmovie_ui_common. XML: resources/skins/default/1080i/RichMovieList.xml.
Best-effort (chyby logovat, nikdy neshodit).
"""
from __future__ import annotations

import json

import xbmc
import xbmcgui

import richmovie_ui_common as uc


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/List] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.list", "RichMovie/List")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "List] " + str(msg), level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"
_XML = "RichMovieList.xml"
_RES = "1080i"
_BASE = f"plugin://{_ADDON_ID}/"
_LIST = 7000
_BACK = 9000


class RichMovieListWindow(uc.RMNavMixin, xbmcgui.WindowXMLDialog):

    def __init__(self, *a, title="", items=None, **kw):
        super().__init__(*a, **kw)
        self._title = title or "RichMovie"
        self._items = list(items or [])
        self._rm_closed = False

    def onInit(self) -> None:
        self.setProperty("rm_l_title", self._title)
        try:
            lst = self.getControl(_LIST)
            lst.reset()
            for li in self._items:
                lst.addItem(li)
            self.setProperty("rm_l_empty", "" if self._items else "1")
            self.setProperty("rm_l_count", str(len(self._items)))
            uc.focus_first(self, [_LIST, _BACK])
        except Exception as exc:
            _log(f"onInit: {exc}", xbmc.LOGWARNING)

    # ------------------------------------------------------------------ input
    def onClick(self, controlId: int) -> None:
        if controlId == _BACK:
            self.close()
            return
        if controlId != _LIST:
            return
        try:
            li = self.getControl(_LIST).getSelectedItem()
            if not li:
                return
            url = li.getProperty("rm_target_url")
            if not url:
                return
            playable = li.getProperty("rm_playable") == "1"
            is_folder = li.getProperty("rm_isFolder") == "1"

            if playable and not is_folder:
                # přehrávání nesmí běžet pod dialogy → složit celý stack
                if not uc.play_debounce():
                    return  # rychlý dvojklik
                try:
                    # Φ2: descriptor PŘED Dialog.Close — zavírání oken NavStack
                    # vyprázdní, snapshot by byl prázdný (návrat jen na Home)
                    uc.mark_play_from_ui()
                except Exception:
                    pass
                xbmc.executebuiltin("Dialog.Close(all,true)")
                # Φ1 (29.09.2026): přes pojistku jednoho startu (druhý požadavek = „Už to spouštím…“)
                import richmovie_playback_dispatch as _rm_dispatch
                _rm_dispatch.request(url, source="rm_list", noresume=False)
                return

            # folder / další custom okno → otevři NAD tímto (Back vrací)
            xbmc.executebuiltin(f"RunPlugin({url})")
        except Exception as exc:
            uc.notify_error("Položku se nepodařilo otevřít.", log_tag="List")
            _log(f"onClick: {exc}", xbmc.LOGWARNING)

    def on_window_action(self, action) -> None:
        # Back/Stop/device latch řeší uc.RMNavMixin.onAction (Φ1 DRY)
        if action.getId() == xbmcgui.ACTION_CONTEXT_MENU:
            self._context_menu()

    def _context_menu(self) -> None:
        """Context menu z položky (rm_ctx_json = [[label, plugin_url], …])."""
        try:
            if self.getFocusId() != _LIST:
                return
            li = self.getControl(_LIST).getSelectedItem()
            if not li:
                return
            raw = li.getProperty("rm_ctx_json") or ""
            if not raw:
                return
            ctx = json.loads(raw)
            if not ctx:
                return
            labels = [str(c[0]) for c in ctx]
            sel = xbmcgui.Dialog().contextmenu(labels)
            if sel < 0:
                return
            target = str(ctx[sel][1] or "")
            if target:
                xbmc.executebuiltin(f"RunPlugin({target})")
        except Exception as exc:
            _log(f"context: {exc}", xbmc.LOGWARNING)

    def close(self):  # noqa: A003 — Kodi API jméno
        self._rm_closed = True
        super().close()


def open_list(addon, title="", items=None, route_url="") -> None:
    """Otevře generické list okno s hotovými ListItemy. Best-effort.

    `route_url` (Φ1): plugin URL, ze kterého ListItemy vznikly (předává RmDir) —
    jediná cesta, jak je list okno rekonstruovatelné pro NavStack replay
    (items se stavějí v invokeru, z okna samotného je nelze obnovit).
    Bez route_url se okno do replay snapshotu nezahrnuje."""
    try:
        w = RichMovieListWindow(_XML, addon.getAddonInfo("path"), "default", _RES,
                                title=title, items=items)
        _nav_id = uc.nav_push(url_override=route_url, replay=bool(route_url))  # Φ1
        try:
            w.doModal()
        finally:
            uc.nav_remove(_nav_id)
        w._rm_closed = True
        del w
    except Exception as exc:
        _log(f"open_list: {exc}", xbmc.LOGWARNING)
