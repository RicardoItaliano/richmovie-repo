# -*- coding: utf-8 -*-
"""
richmovie_state_sync — stav profilu napříč zařízeními (profily Φ3b, 3.5.134).

„Rozkoukám v práci, doma jen kliknu Pokračovat." Gate (`profile_state_items`,
mig 0026) je ZDROJ PRAVDY stavu profilu — Pokračovat, zhlédnuto, odebráno.
Každé zařízení má lokální cache (soubory `richmovie_history`) + odchozí frontu.

Tok
    zápis lokálně (cw_upsert / cw_remove / watched_*)  →  `note_local_change()`
        → položka do fronty `pending_state.json` (osobní soubor profilu, dedupe
          podle klíče, novější vyhrává)
    služba (`service_nextup`) každý tik:
        push  = `flush()`   — nejdřív po 60 s během přehrávání (D13), po stopu
                              hned v dalším tiku; jeden POST /v1/profiles/state
        pull  = `pull_and_apply()` — každých 30 s, JEN když nic nehraje;
                              delta podle kurzoru `version` (GET ?since=)
        menu  = `maybe_refresh_menu()` — D11: TICHÝ požadavek do jedné fronty obnov výpisu
                              (`richmovie_playback_dispatch.request_refresh`, S18); kdy a kde rozhoduje
                              verdikt dispatcheru (hlavní menu na obrazovce, žádný dialog, přehrávač ani
                              relace, divák nepracuje, menu se nestaví)

Pravidla (plán PLAN_profiles_multi_user_20260905 §8, D11/D13)
  • LWW podle času klienta: lokální položka novější než vzdálená se NIKDY
    nepřepíše (pozice se nevrací zpět kvůli staršímu checkpointu z telefonu).
  • Vlastní změny se z pullu ignorují PO OSÁCH (`own_axes`: zapisovatel osy postupu / zhlédnutí, Gate mig 0042;
    starší Gate = `updated_device == device_hash` pro celý řádek).
  • R2: transport/5xx/429 = fronta ZŮSTÁVÁ. Autoritativní odmítnutí položky
    (`errors[]` s indexem, 422 s `loc` na index) = karanténa, ne věčná fronta,
    ne koš. 422 bez tvaru / 2xx bez klíče `accepted` = kontrakt → fronta zůstává
    + ERROR. `profile_not_found` (profil smazán v Gate) = fronta se zahodí.
  • Zápisový POST se NEOPAKUJE (richmovie_http default) — opakování řeší fronta.
  • Host / multi bez zvoleného profilu = žádný sync (nic se neukládá, D7).
  • D11: samovolný `Container.Refresh` JEN v hlavním menu RichMovie, nic nehraje,
    žádný dialog, nečinnost ≥ 10 s; NIKDY `Container.Update`. Custom UI (RM 4.0)
    se překresluje samo přes `data_rev_bump` (cw_save) — tady se nic nevolá.
  • Čisté funkce (`item_from_cw`, `plan_merge`, `own_axes`, `ago_text`)
    nemají Kodi závislosti — kryje je harness scénář 54.

13.09.2026 — realtime + handoff (3.5.148, plán PLAN_cw_realtime_handoff_20260913, mig 0029)
  • ČAS POLOŽKY = ČAS ZMĚNY POSTUPU. Nález N1: 30s checkpoint dával `ts=now` i při
    nezměněné pozici → pozastavené zařízení pushovalo každou minutu „novější" stav
    a LWW jím přepisovalo postup zařízení, které díl reálně hrálo. Rozhoduje čistá
    `checkpoint_changed()` (služba ji volá před každým zápisem CW): nezměněný
    (titul, pozice, activity) = žádný zápis, žádná položka fronty.
  • `activity` (playing/paused/stopped) je typovaná součást stavu: pauza, resume a
    seek jsou UDÁLOSTI (okamžitý zápis + `request_push`), hraní posílá heartbeat
    60 s (pozice se mění), zavření = stopped.
  • Realtime kanál: služba drží long-poll `GET /v1/profiles/state/wait` (≤ 25 s),
    když nic nehraje NEBO je přehrávač pozastavený (`ServiceTicker._wait_work`);
    `changed` = běžný `pull_and_apply` (jedna cesta sloučení). 429/4xx = kanál se
    na `WAIT_BLOCK_S` vypne a jede 30s polling (429 se NIKDY neopakuje).
  • Handoff: pozastavený přehrávač po změně z JINÉHO zařízení přeskočí na jeho
    pozici (`plan_handoff` → executor ve službě: seek + CW zápis pod
    `applying_remote`, žádný push — ping-pong nemožný). Rozdíl < HANDOFF_MIN_DELTA_S
    = nic. Aktivně hrající zařízení se nedotýká (D2).
  • Řádek UI: `origin_text()` = „⏸ Telefon Richie · před 2 min" / „▶ právě hraje ·
    TV obývák" / „toto zařízení · před 5 min" (jeden formát pro root, list i rail).
  • Jméno zařízení: nastavení `rm_device_name` > lidský `System.FriendlyName` >
    `human_device_label(platform)`; správce ho může přebít v Gate (`user_devices.label`).
"""

from __future__ import annotations

import datetime as _dt
import json
import threading

import richmovie_sync_queue as _sq   # DP4: sdílená fronta/kurzor/klasifikace odpovědi (oba kanály)
import richmovie_playback_dispatch as _rm_dispatch   # 4.0.1: brána obnovy; S18: jedna fronta odložených obnov výpisu
import time
from typing import Any, Dict, List, Optional, Tuple

try:
    import xbmc  # type: ignore
    _HAVE_KODI = True
except ImportError:  # harness / nástroje mimo Kodi
    xbmc = None  # type: ignore
    _HAVE_KODI = False

PUSH_INTERVAL_S = 60.0          # D13: push během přehrávání každých 60 s
PUSH_RETRY_MIN_S = 15.0         # po neúspěchu nejdřív za 15 s (ne každý 5s tik)
PULL_INTERVAL_S = 30.0          # D13: pull služby při nečinnosti (záloha realtime kanálu)
LIST_FRESH_MAX_AGE_S = 300.0    # 4.0.3 (A9): výpis s ✔/◐ si stav stáhne, když služba nepullovala 5 min (probuzené zařízení)
ACTIVITIES = ("playing", "paused", "stopped")
ACTIVITY_DEFAULT = "stopped"
WATCHED_KINDS = ("attended", "unattended", "manual")   # mig 0030: druh ✔ (SSOT richmovie_attention)
WATCHED_KIND_DEFAULT = "attended"
VERDICT_SLEEP = "sleep"         # mig 0038: `watched/unattended` s verdiktem = jediné snížení druhu (Gate compare-and-set)
# Ořez postupu (10.10.2026, nález M3): pozice > délka dávala `completion > 1` → Gate 422 → ✔ v karanténě.
# Pozice delší než POSITION_MAX_RATIO × délka + POSITION_SLACK_S je nesmysl přehrávače (rozbité časové
# značky streamu; produkce 06.10.: 47 547 s u dílu o 2 638 s) — takový checkpoint se nezapíše vůbec.
POSITION_MAX_RATIO = 1.05
POSITION_SLACK_S = 60.0
ACTIVITY_STALE_S = 180.0        # `playing` starší než 3 min = zařízení zmizelo → v UI jako pauza
HANDOFF_MIN_DELTA_S = 5.0       # D1: menší rozdíl pozic = tentýž bod, pozastavený přehrávač se nehýbe
CHECKPOINT_MIN_DELTA_S = 2.0    # pozice se „změnila", až když se posune o víc než 2 s (šum getTime)
WAIT_S = 25                     # long-poll drží Gate nejvýš 25 s (Cloudflare 100 s, rezerva)
WAIT_TIMEOUT_S = 32.0           # HTTP timeout čekání = WAIT_S + rezerva na síť
WAIT_BLOCK_S = 300.0            # 429 / kontrakt / autoritativní chyba → kanál 5 min vypnutý, jede polling
WAIT_TRANSIENT_BLOCK_S = 30.0   # transport → 30 s pauza (netstate má vlastní breaker)
WAIT_HEALTHY_S = 60.0           # poslední úspěšné čekání mladší než 60 s = polling není třeba
PULL_SAFETY_S = 300.0           # …ale nejvýš 5 min bez pullu s překryvem (verze ze sekvence ≠ pořadí commitů)
SETTING_DEVICE_NAME = "rm_device_name"
SETTING_WAIT_ENABLED = "state_wait_enabled"
QUEUE_FILE = "pending_state.json"
CURSOR_FILE = "state_sync.json"
QUEUE_MAX_ITEMS = 6000          # ≥ WATCHED_MAX_ITEMS 5000 + CW: import archivu ✔ nesmí tiše zahodit nejstarší (Fable P1-2)
QUARANTINE_MAX_ITEMS = 200
PUSH_BATCH_MAX = 200            # = Gate PUSH_MAX_ITEMS
PULL_PAGES_MAX = _sq.PULL_PAGES_MAX
FULL_RECONCILE_S = _sq.FULL_RECONCILE_S
PULL_OVERLAP = _sq.PULL_OVERLAP
CONTRACT_BACKOFF_S = 1800.0     # 2xx/422 bez kontraktního tvaru = chyba NAŠE → stejný POST neopakovat dřív než za 30 min
_SCOPE_UNSEEN = object()        # S24 R7: `ServiceTicker` ještě rozsah neviděl (první tik služby)
_SCOPE_NONE = object()          # rozsah = nic se nesynchronizuje (Host / multi bez profilu / unset)
_SCOPE_ANY = object()           # worker volaný mimo tik (bez známého rozsahu) → odklad bez kontroly rozsahu
LOCK_STALE_S = _sq.LOCK_STALE_S  # krádež zámku fronty/CW až po 10 s (SSOT richmovie_sync_queue)
STATE_PATH = "/v1/profiles/state"
WAIT_PATH = STATE_PATH + "/wait"
# Metadata CW záznamu, která cestují v `extra` (Gate je netypuje — jen je vrací)
EXTRA_KEYS = ("tv_name", "ep_title", "poster_path", "backdrop_path", "year",
              "fs_url", "fs_hash", "path", "title",
              "asleep_eps")   # 4.0.3 (D3): díly s verdiktem spánku → klik v Pokračovat nabídne „už ho mám za sebou“

OUTCOME_SENT = _sq.OUTCOME_SENT
OUTCOME_EMPTY = _sq.OUTCOME_EMPTY
OUTCOME_SKIPPED = _sq.OUTCOME_SKIPPED
OUTCOME_FAILED = _sq.OUTCOME_FAILED          # transport / 5xx / 429 — fronta zůstává
OUTCOME_CONTRACT = _sq.OUTCOME_CONTRACT      # odpověď bez kontraktního tvaru — fronta zůstává
OUTCOME_DROPPED = _sq.OUTCOME_DROPPED        # profil v Gate neexistuje — fronta zahozena
OUTCOME_APPLIED = _sq.OUTCOME_APPLIED
OUTCOME_UNCHANGED = _sq.OUTCOME_UNCHANGED

_tls = threading.local()
_flush_lock = threading.Lock()


try:
    from richmovie_logging import make_legacy_logger as _mk_logger
    _log = _mk_logger("richmovie.state_sync", "[RichMovie/StateSync]")   # → user_logs na NASu (Fable P2-5)
except Exception:  # harness / nástroje mimo Kodi
    def _log(msg: str, level: int = 1) -> None:
        if _HAVE_KODI:
            xbmc.log("[RichMovie/StateSync] %s" % msg, level)


# ── potlačení echa při aplikaci vzdáleného stavu ─────────────────────────────

def is_applying_remote() -> bool:
    return bool(getattr(_tls, "applying", False))


class applying_remote:
    """Uvnitř bloku zápisy `richmovie_history` NEgenerují položky fronty —
    jinak by se stav z Gate poslal zpátky jako naše změna (echo smyčka)."""

    def __enter__(self):
        _tls.applying = True
        return self

    def __exit__(self, *exc):
        _tls.applying = False
        return False


# ── rozsah synchronizace ─────────────────────────────────────────────────────

def sync_scope() -> Optional[Dict[str, Any]]:
    """`{"profile_id": int|None}` když se synchronizuje, None = Host / multi bez
    zvoleného profilu (D7: bez aktivního profilu se nic neukládá)."""
    try:
        import richmovie_profile as _p
        if _p.mode() == _p.MODE_UNSET:
            return None   # Fable P1-3: dokud účet nerozhodl, nic se nemíchá pod klíč 0
        if not _p.has_active_profile():
            return None
        return {"profile_id": _p.telemetry_profile_id()}
    except Exception:
        return None


def _preconditions() -> Tuple[bool, str]:
    """Smí se teď mluvit s Gate? Identita potvrzená (403 = fail-fast), síť ONLINE
    (netstate breaker), aktivní profil. Stav, ne počítadlo (R2)."""
    if sync_scope() is None:
        return False, "no_active_profile"
    try:
        import richmovie_identity_state as _ident
        if not _ident.allow_gate_request():
            return False, "identity"
    except Exception:
        return False, "identity_unavailable"
    try:
        import richmovie_netstate as _net
        if not _net.allow_request():
            return False, "offline"
    except Exception:
        pass
    return True, ""


# ── čas ──────────────────────────────────────────────────────────────────────

to_iso = _sq.to_iso
to_epoch = _sq.to_epoch


def ago_text(ts: float, now: Optional[float] = None) -> str:
    """„před chvílí" / „před 12 min" / „před 2 h" / „před 3 dny" — SSOT pro řádek
    Pokračovat i chooser."""
    now = time.time() if now is None else now
    delta = max(0.0, now - float(ts or 0))
    if delta < 60:
        return "před chvílí"
    if delta < 3600:
        return "před %d min" % int(delta // 60)
    if delta < 86400:
        return "před %d h" % int(delta // 3600)
    days = int(delta // 86400)
    if days == 1:
        return "včera"
    return "před %d dny" % days


# ── sestavení položek (čisté) ────────────────────────────────────────────────

def item_key(item: Dict[str, Any]) -> str:
    return "%s:%d:%d:%d" % (item.get("kind"), int(item.get("tmdb_id") or 0),
                            int(item.get("season") or 0), int(item.get("episode") or 0))


def cw_key(cw: Dict[str, Any]) -> Optional[str]:
    """Klíč CW záznamu ve stejném prostoru jako `item_key` (None = nesynchronizovatelný)."""
    if not isinstance(cw, dict):
        return None
    if cw.get("type") == "episode":
        tmdb = _int(cw.get("tv_id")) or _int(cw.get("tmdb_id"))
        if tmdb <= 0:
            return None
        return "tv:%d:%d:%d" % (tmdb, _int(cw.get("season")), _int(cw.get("episode")))
    tmdb = _int(cw.get("tmdb_id"))
    if tmdb <= 0:
        return None
    return "movie:%d:0:0" % tmdb


def _int(v: Any) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def progress_fraction(position_s: Any, runtime_s: Any) -> float:
    """JEDINÝ výpočet podílu zhlédnutí pro Gate (ořez 0–1, 3 desetinná místa). Gate validuje `completion ≤ 1`
    — dřív pozice těsně za koncem (`getTime` > `getTotalTime`) poslala 1,001 a ✔ skončilo v karanténě."""
    try:
        pos, dur = float(position_s or 0), float(runtime_s or 0)
    except (TypeError, ValueError):
        return 0.0
    if dur <= 0 or pos <= 0:
        return 0.0
    return round(min(1.0, pos / dur), 3)


def sane_checkpoint(position_s: Any, runtime_s: Any) -> bool:
    """Je pozice z přehrávače použitelná? False = nesmysl (rozbité časové značky streamu) → checkpoint se
    NEZAPÍŠE (volající loguje `CHECKPOINT_INVALID`). Neznámá délka = rozhoduje jen nezápornost."""
    try:
        pos, dur = float(position_s or 0), float(runtime_s or 0)
    except (TypeError, ValueError):
        return False
    if pos < 0:
        return False
    if dur <= 0:
        return True
    return pos <= dur * POSITION_MAX_RATIO + POSITION_SLACK_S


def queue_key(item: Dict[str, Any]) -> str:
    """Klíč ODCHOZÍ fronty = titul + osa (mig 0038). Zhlédnutí, verdikt spánku a postup téhož dílu jsou různé
    změny a nesmí se ve frontě navzájem přepsat (dřív `watching` po ✔ téhož dílu ✔ z fronty vytlačil)."""
    state = item.get("state")
    scope = ((item.get("extra") or {}).get("scope") or "") if isinstance(item.get("extra"), dict) else ""
    if state == "watched":
        axis = "v" if (item.get("extra") or {}).get("verdict") == VERDICT_SLEEP else "w"
    elif state == "removed" and scope == SCOPE_WATCHED:
        axis = "w"
    else:
        axis = "p"
    return "%s#%s" % (item_key(item), axis)


def _base(kind: str, tmdb_id: int, season: int, episode: int, state: str, ts: float) -> Dict[str, Any]:
    return {
        "kind": kind, "tmdb_id": int(tmdb_id), "season": int(season), "episode": int(episode),
        "title": "", "state": state, "position_s": 0, "runtime_s": 0, "completion": 0.0,
        "source": None, "ident": None, "extra": {}, "client_updated_at": to_iso(ts),
        "activity": ACTIVITY_DEFAULT, "watched_kind": None,   # mig 0038: druh nese jen `watched` (Flash A2)
    }


def normalize_activity(value: Any) -> str:
    return value if value in ACTIVITIES else ACTIVITY_DEFAULT


def normalize_watched_kind(value: Any) -> str:
    """Druh ✔ (3.5.149, mig 0030): attended / unattended (přehráno bez diváka) / manual."""
    return value if value in WATCHED_KINDS else WATCHED_KIND_DEFAULT


def item_from_cw(cw: Dict[str, Any], state: str = "watching", now: Optional[float] = None,
                 *, client_time: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """CW záznam (`richmovie_history`) → položka pro Gate. None = bez TMDb id
    (lokální soubor NASu bez matche se nesynchronizuje — není co navázat).
    `client_time` = čas TÉTO lokální změny (float); CW `ts` je celé sekundy a
    následná změna ve stejné sekundě by ve frontě prohrála (cross-check PB2)."""
    key = cw_key(cw)
    if key is None:
        return None
    kind, tmdb, s, e = key.split(":")
    ts = float(client_time if client_time is not None else (cw.get("ts") or (now if now is not None else time.time())))
    it = _base(kind, int(tmdb), int(s), int(e), state, ts)
    position = max(0, _int(cw.get("position")))
    runtime = max(0, _int(cw.get("duration")))
    if runtime > 0:
        position = min(position, runtime)   # obrana v hloubce: nesmyslnou pozici služba nezapíše (`sane_checkpoint`)
    it.update({
        "title": (cw.get("tv_name") or cw.get("title") or "")[:200],
        "position_s": position, "runtime_s": runtime,
        "completion": progress_fraction(position, runtime),
        "source": (cw.get("source") or None), "ident": (cw.get("ident") or None),
        "extra": {k: cw[k] for k in EXTRA_KEYS if cw.get(k) not in (None, "", 0)},
        "activity": normalize_activity(cw.get("activity")),
    })
    return it


def item_watched_episode(tv_id: Any, season: int, episode: int, completion: Optional[float] = None,
                         now: Optional[float] = None, kind: str = "attended") -> Optional[Dict[str, Any]]:
    tmdb = _int(tv_id)
    if tmdb <= 0 or int(season) <= 0 or int(episode) <= 0:
        return None
    it = _base("tv", tmdb, int(season), int(episode), "watched", now if now is not None else time.time())
    try:
        it["completion"] = round(min(1.0, max(0.0, float(completion))), 3) if completion is not None else 1.0
    except (TypeError, ValueError):
        it["completion"] = 1.0
    it["watched_kind"] = normalize_watched_kind(kind)   # 3.5.149 (mig 0030)
    return it


def item_sleep_verdict(tv_id: Any, season: int, episode: int, now: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """Verdikt spánku (mig 0038): dotaz „Díváš se ještě?“ vypršel → díl, který TOTO zařízení označilo ✔ `attended`,
    se sníží na `unattended`. Gate ho přijme jen jako compare-and-set (totéž zařízení, ✔ pořád attended,
    verdikt není starší); vlastní slot fronty (`queue_key` osa v) → ✔ i verdikt dorazí oba a ve správném pořadí."""
    it = item_watched_episode(tv_id, season, episode, None, now, kind="unattended")
    if it is None:
        return None
    it["extra"] = {"verdict": VERDICT_SLEEP}
    return it


def item_watched_movie(tmdb_id: Any, now: Optional[float] = None) -> Optional[Dict[str, Any]]:
    tmdb = _int(tmdb_id)
    if tmdb <= 0:
        return None
    it = _base("movie", tmdb, 0, 0, "watched", now if now is not None else time.time())
    it["completion"] = 1.0
    return it


SCOPE_CW = "cw"            # odebráno z Pokračovat (✔ zůstává)
SCOPE_WATCHED = "watched"  # odznačeno ✔ (Pokračovat se netýká)
SCOPE_CW_SERIES = "cw_series"  # mig 0038: seriál skrytý v Pokračovat (řádek season=0, episode=0) do novějšího postupu


def item_removed(kind: str, tmdb_id: Any, season: int = 0, episode: int = 0,
                 now: Optional[float] = None, *, scope: str = SCOPE_CW) -> Optional[Dict[str, Any]]:
    """`removed` nese v `extra.scope`, CO bylo odebráno (Fable P2-2): rewatch filmu nebo
    ruční odebrání z Pokračovat nesmí na ostatních zařízeních smazat zelené ✔."""
    tmdb = _int(tmdb_id)
    if tmdb <= 0 or kind not in ("movie", "tv"):
        return None
    it = _base(kind, tmdb, int(season or 0), int(episode or 0), "removed",
               now if now is not None else time.time())
    it["extra"] = {"scope": scope}
    return it


def to_cw_item(r: Dict[str, Any]) -> Dict[str, Any]:
    """Položka z Gate → CW záznam `richmovie_history` (přehratelný: díl má tv_id,
    film tmdb_id). `ts` = čas klienta, který stav vytvořil (LWW při dalším sloučení);
    `remote_*` = odkud přišel (řádek „z TV obývák před 2 h")."""
    extra = r.get("extra") or {}
    # mig 0040: čas záznamu Pokračovat = čas osy POSTUPU (client_updated_at je poslední událost řádku i na ose ✔)
    ts = to_epoch(r.get("progress_at") or r.get("client_updated_at"))
    common = {
        "tmdb_id": int(r.get("tmdb_id") or 0),
        "poster_path": extra.get("poster_path") or "",
        "backdrop_path": extra.get("backdrop_path") or "",
        "position": float(r.get("position_s") or 0),
        "duration": float(r.get("runtime_s") or 0),
        "ts": int(ts),
        "ident": r.get("ident") or "",
        "source": r.get("source") or "webshare",
        "fs_url": extra.get("fs_url") or "",
        "fs_hash": extra.get("fs_hash") or "",
        "remote_device_label": r.get("updated_device_label") or "",
        "remote_updated_at": r.get("updated_at") or "",
        "activity": normalize_activity(r.get("activity")),
    }
    if extra.get("path"):
        common["path"] = extra["path"]
    if isinstance(extra.get("asleep_eps"), list) and extra.get("asleep_eps"):
        common["asleep_eps"] = [list(x) for x in extra["asleep_eps"] if isinstance(x, (list, tuple)) and len(x) == 2]
    if r.get("kind") == "tv":
        common.update({
            "type": "episode", "tv_id": int(r.get("tmdb_id") or 0),
            "tv_name": extra.get("tv_name") or r.get("title") or "",
            "title": extra.get("tv_name") or r.get("title") or "",
            "season": int(r.get("season") or 0), "episode": int(r.get("episode") or 0),
            "ep_title": extra.get("ep_title") or "",
        })
    else:
        common.update({
            "type": "movie",
            "title": extra.get("title") or r.get("title") or "Neznámý titul",
            "year": _int(extra.get("year")),
        })
    return common


# ── sloučení (čisté) ─────────────────────────────────────────────────────────

def playing_key() -> Optional[str]:
    """Klíč právě přehrávaného titulu z PlayerCtx (Window props z `plugin._play`), nebo None.
    Sloučení z Gate ho přeskočí: lokální pozice ještě není na disku (30s checkpoint) a
    vzdálený `watched` by titul odstranil z Pokračovat uprostřed sledování (T1 Pro P7)."""
    if not _HAVE_KODI:
        return None
    try:
        if not xbmc.Player().isPlaying():
            return None
        from richmovie_playback_end import player_ctx_key   # jeden formát klíče (Fable P3-5)
        return player_ctx_key() or None
    except Exception:
        return None


def remote_axes(r: Dict[str, Any]) -> Tuple[Optional[bool], float, float, float, str]:
    """Osy řádku z Gate (mig 0038/0040): (in_progress, čas postupu, watched_at, unwatched_at, druh ✔); časy jako
    epochy (0 = není). `in_progress` None = o postupu řádek nic neříká. Řádek bez nových polí (Gate před 0038,
    fixtury starších testů) se odvodí z `state` stejně, jak ho Gate odvozuje (čisté, harness 90)."""
    state = r.get("state")
    r_ts = to_epoch(r.get("client_updated_at")) or 0.0
    legacy_scope = (r.get("extra") or {}).get("scope") or ""
    if "in_progress" in r:
        in_prog: Optional[bool] = bool(r["in_progress"])
    elif state == "removed" and legacy_scope == SCOPE_WATCHED:
        in_prog = None   # starý řádek: odznačení ✔ o Pokračovat nic neříká
    else:
        in_prog = state == "watching"
    if "progress_at" in r:
        p_ts = (to_epoch(r.get("progress_at")) or 0.0) if r.get("progress_at") else 0.0
    else:
        p_ts = r_ts
    if "watched_at" in r:
        w_at = (to_epoch(r.get("watched_at")) or 0.0) if r.get("watched_at") else 0.0
    else:
        w_at = r_ts if state == "watched" else 0.0
    if "unwatched_at" in r:
        un_at = (to_epoch(r.get("unwatched_at")) or 0.0) if r.get("unwatched_at") else 0.0
    else:
        # starší položky bez scope = obojí
        un_at = r_ts if (state == "removed" and legacy_scope in ("", SCOPE_WATCHED)) else 0.0
    return in_prog, p_ts, w_at, un_at, normalize_watched_kind(r.get("watched_kind"))


def own_axes(r: Dict[str, Any], device_hash: str) -> Tuple[bool, bool]:
    """Které osy řádku z Gate zapsalo TOTO zařízení: (postup, zhlédnutí) — ty se při slučování přeskočí, lokální stav
    je u nich pravda. S21 (10.10.2026, Gate mig 0042): Gate posílá zapisovatele obou os (`progress_device`,
    `watched_device`); dřív se filtrovalo podle `updated_device` (poslední událost řádku) a ✔ z TOHOTO zařízení
    schoval postup, který jiné zařízení mezitím zapsalo (rewatch) — do jeho dalšího checkpointu ho tu nikdo neviděl.
    Gate bez pole `progress_device` (před 0042) = zapisovatel celého řádku pro obě osy (dřívější chování). Odznačení
    ✔ zapisovatele nenese (`watched_device` je pak prázdné) — vlastní odznačení lokálně ✔ už nemá, takže nic neudělá.
    `device_hash=""` = převzít i vlastní (odpověď pushe `newer`). Čisté (harness 90)."""
    if not device_hash:
        return False, False
    if "progress_device" not in r:
        own = r.get("updated_device") == device_hash
        return own, own
    return r.get("progress_device") == device_hash, r.get("watched_device") == device_hash


def plan_merge(remote: List[Dict[str, Any]], cw_items: List[Dict[str, Any]],
               watched_episodes: List[Dict[str, Any]], watched_movie_ids: Any,
               device_hash: str, skip_keys: Optional[Any] = None,
               hidden_series: Optional[Dict[str, float]] = None) -> List[Tuple[str, Any]]:
    """Plán akcí nad lokálními soubory PO OSÁCH (mig 0038). Vrací seznam
    `("cw_upsert", cw_item) | ("cw_remove", key) | ("cw_hide_series", (tmdb, ts))
     | ("watched_episode", (tv,s,e,completion,kind,watched_at,device)) | ("watched_movie", tmdb)
     | ("unwatched_episode", (tv,s,e)) | ("unwatched_movie", tmdb)`.
      • POSTUP (Pokračovat): novější čas osy vyhrává; rozkoukaný díl se přidá, uzavřený/odebraný odebere.
        Každý díl má vlastní řádek — „jeden bod per seriál“ je jen POHLED (`richmovie_history.cw_view`).
      • ZHLÉDNUTÍ (✔): převezme se, když je na Gate aspoň tak nové jako lokálně — včetně druhu (Gate je
        sloučená pravda: monotónní druh + verdikt spánku); lokálně novější ✔ čeká ve frontě. Rozkoukání dílu
        ✔ NIKDY neodebere (incident 10.10.2026).
    Vlastní změny se přeskočí PO OSÁCH (`own_axes`, S21); `device_hash=""` = převzít i vlastní (odpověď pushe `newer`)."""
    local_cw = {}
    for it in cw_items or []:
        k = cw_key(it)
        if k:
            local_cw[k] = it
    local_eps = {}
    for rec in watched_episodes or []:
        local_eps["tv:%d:%d:%d" % (_int(rec.get("tv_id")), _int(rec.get("season")), _int(rec.get("episode")))] = rec
    hidden = hidden_series or {}
    movies = {str(m) for m in (watched_movie_ids or [])}
    actions: List[Tuple[str, Any]] = []
    skip = set(skip_keys or ())
    for r in remote or []:
        own_progress, own_watched = own_axes(r, device_hash)
        if own_progress and own_watched:
            continue
        key = item_key(r)
        if key in skip:
            continue   # právě se přehrává na tomto zařízení
        kind = r.get("kind")
        tmdb = int(r.get("tmdb_id") or 0)
        s, e = int(r.get("season") or 0), int(r.get("episode") or 0)
        r_ts = to_epoch(r.get("client_updated_at")) or 0.0
        in_prog, p_ts, w_at, un_at, r_kind = remote_axes(r)

        # ── osa postupu ──────────────────────────────────────────────────────
        if kind == "tv" and s == 0 and e == 0:
            scope = (r.get("extra") or {}).get("scope") or ""
            if (not own_progress and r.get("state") == "removed" and scope == SCOPE_CW_SERIES
                    and r_ts > float(hidden.get(str(tmdb), 0) or 0)):
                actions.append(("cw_hide_series", (tmdb, r_ts)))
            continue   # řádek seriálu nese jen značku skrytí
        if not own_progress:
            cw = local_cw.get(key)
            # Záznam Pokračovat drží čas v CELÝCH sekundách (`to_cw_item`: `ts = int(...)`) → porovnávat celé sekundy
            # (jinak překryv pullu tentýž postup nikdy nepozná jako „totéž“ a přepisoval by ho dokola).
            cw_ts = int(float(cw.get("ts") or 0)) if cw else 0
            p_sec = int(p_ts)
            if in_prog:
                same = (cw is not None and cw_ts == p_sec
                        and int(float(cw.get("position") or 0)) == int(r.get("position_s") or 0)
                        and normalize_activity(cw.get("activity")) == normalize_activity(r.get("activity")))
                if (cw is None or p_sec >= cw_ts) and not same:
                    actions.append(("cw_upsert", to_cw_item(r)))
            elif in_prog is False and cw is not None and p_sec > 0 and p_sec >= cw_ts:
                actions.append(("cw_remove", key))   # dokoukáno / odebráno jinde a novější než náš postup

        # ── osa zhlédnutí ────────────────────────────────────────────────────
        if own_watched:
            continue
        if kind == "tv":
            ep = local_eps.get(key)
            # Lokální ✔ drží čas v CELÝCH sekundách (`watched_at = int(...)`), Gate s mikrosekundami → porovnávat
            # celé sekundy, jinak by tentýž ✔ vypadal po každém pullu „novější“ a překreslovalo by se navěky.
            ep_ts = int(float(ep.get("watched_at") or 0)) if ep else 0
            w_sec = int(w_at)
            if w_at > 0:
                newer = ep is None or w_sec > ep_ts
                kind_change = ep is not None and w_sec >= ep_ts and normalize_watched_kind(ep.get("kind")) != r_kind
                # tentýž ✔ s opraveným jménem zařízení (správce opravil „odkud“ — smoke 4.0.3 10.10.2026); jen
                # `watched_device_label` (záložní `updated_device_label` patří postupu, ne zhlédnutí), jen neprázdný
                r_wlabel = str(r.get("watched_device_label") or "")
                label_change = (ep is not None and w_sec == ep_ts and bool(r_wlabel)
                                and str(ep.get("device") or "") != r_wlabel)
                if newer or kind_change or label_change:
                    # 3.5.156: ✔ z jiného zařízení nese, KDY (čas klienta) a ODKUD (jméno zařízení z Gate)
                    actions.append(("watched_episode", (tmdb, s, e, float(r.get("completion") or 1.0), r_kind,
                                                        int(w_at), str(r.get("watched_device_label")
                                                                       or r.get("updated_device_label") or ""))))
            elif un_at > 0 and ep is not None and un_at > ep_ts:
                actions.append(("unwatched_episode", (tmdb, s, e)))
        elif kind == "movie":
            if w_at > 0 and str(tmdb) not in movies:
                actions.append(("watched_movie", tmdb))
            elif w_at <= 0 and un_at > 0 and str(tmdb) in movies:
                actions.append(("unwatched_movie", tmdb))
    return actions


def _execute(actions: List[Tuple[str, Any]]) -> Tuple[int, bool]:
    """Provede plán sloučení. Vrací (počet akcí, ok). `ok=False` = něco se nezapsalo →
    `pull_queue` NEposune kurzor a dávka přijde znovu (R2).

    3.5.151 (plán PLAN_resume_native_start_sync_integrity_20260916, Φ3): ✔ dílů a filmů se
    zapisují DÁVKOU (jeden read-modify-write souboru pod meziprocesovým zámkem místo stovek),
    CW akce zůstávají po jedné (≤ 10 položek). Selhání zápisu, které mutátory historicky jen
    logují, sbírá `richmovie_atomic.failure_scope` — dřív se kurzor posunul i po WRITE_FAILED.

    Fable F4: výjimka nad JEDNOU položkou kurzor nezastaví, pokud nejde o chybu prostředí
    (`richmovie_sync_queue.apply_error_blocks_cursor`) — položka se přeskočí s ERROR logem (R2b)."""
    import richmovie_atomic as _atomic
    import richmovie_history as _h
    import time as _time
    done = 0
    skipped = 0
    ok = True
    ep_marks: List[Dict[str, Any]] = []
    ep_unmarks: List[Tuple[Any, int, int]] = []
    movie_add: List[Any] = []
    movie_remove: List[Any] = []
    now = int(_time.time())
    with applying_remote(), _atomic.failure_scope() as writes:
        for op, arg in actions:
            try:
                if op == "cw_upsert":
                    if _h.cw_upsert(arg, strict=True) is False:
                        ok = False
                        _log("apply cw_upsert: nezapsáno → kurzor zůstává", 3)
                        continue   # nezapsaná akce se nepočítá do sloučených (cross-check Flash 4c)
                elif op == "cw_remove":
                    kind, tmdb, s, e = arg.split(":")
                    if kind == "tv":
                        removed_ok = _h.cw_remove(tv_id=int(tmdb), season=int(s), episode=int(e), strict=True)
                    else:
                        removed_ok = _h.cw_remove(tmdb_id=int(tmdb), strict=True)
                    if removed_ok is False:
                        ok = False
                        _log("apply cw_remove: nezapsáno → kurzor zůstává", 3)
                        continue
                elif op == "watched_episode":
                    tv, s, e, comp, w_kind, w_at, w_dev = (tuple(arg) + (0, ""))[:7]
                    if not tv or int(s) <= 0 or int(e) <= 0:
                        continue
                    # mig 0038: druh z Gate je SLOUČENÁ pravda (monotónní spojení + verdikt spánku) → převzít
                    # i snížení; `plan_merge` ho posílá jen když Gate není starší než lokální ✔
                    ep_marks.append({"tv_id": tv, "season": int(s), "episode": int(e),
                                     "completion": round(float(comp), 3) if comp is not None else None,
                                     "watched_at": int(w_at) or now, "kind": normalize_watched_kind(w_kind),
                                     "device": str(w_dev or ""), "authoritative": True})
                elif op == "cw_hide_series":
                    tv, ts = arg
                    if _h.cw_hide_series(tv_id=tv, ts=float(ts), strict=True) is False:
                        ok = False
                        _log("apply cw_hide_series: nezapsáno → kurzor zůstává", 3)
                        continue
                elif op == "watched_movie":
                    movie_add.append(arg)
                elif op == "unwatched_episode":
                    tv, s, e = arg
                    ep_unmarks.append((tv, int(s), int(e)))
                elif op == "unwatched_movie":
                    movie_remove.append(arg)
                else:
                    continue
                done += 1
            except Exception as exc:
                if _sq.apply_error_blocks_cursor(exc):
                    ok = False
                    _log("apply %s failed: %r → kurzor zůstává" % (op, exc), 3)
                else:
                    skipped += 1
                    _log("apply %s: vadná položka přeskočena (%r) — zůstává na Gate, nabídne ji plná rekonciliace"
                         % (op, exc), 3)
        if skipped:
            _log("apply: %d vadných položek přeskočeno, kurzor pokračuje (R2b)" % skipped, 3)
        if not _h.watched_episodes_apply(ep_marks, ep_unmarks):
            ok = False
            _log("apply: zápis ✔ dílů selhal (%d/%d) → kurzor zůstává" % (len(ep_marks), len(ep_unmarks)), 3)
        if not _h.watched_movies_apply(movie_add, movie_remove):
            ok = False
            _log("apply: zápis ✔ filmů selhal (%d/%d) → kurzor zůstává" % (len(movie_add), len(movie_remove)), 3)
        if writes.failed:
            ok = False
            _log("apply: %d zápisů selhalo (%s) → kurzor zůstává" % (
                writes.failed, ",".join(sorted(set(writes.paths)))), 3)
    return done, ok


def checkpoint_changed(last: Optional[Tuple[str, int, str]], key: str, position_s: float, activity: str,
                       final: bool, *, min_delta_s: float = CHECKPOINT_MIN_DELTA_S) -> bool:
    """Má se checkpoint CW vůbec zapsat? (čisté, harness 57). `last` = (klíč, pozice, activity)
    posledního ZAPSANÉHO checkpointu tohoto přehrávání. Finální volání (Stop/Ended) se zapisují
    vždy; průběžný checkpoint jen když se změnil titul, activity nebo pozice o víc než
    `min_delta_s`. Nezměněný stav = žádný zápis = žádný nový čas = žádný push (nález N1)."""
    if final or last is None:
        return True
    last_key, last_pos, last_act = last
    if last_key != key or normalize_activity(last_act) != normalize_activity(activity):
        return True
    return abs(float(position_s) - float(last_pos)) >= float(min_delta_s)


def plan_handoff(items: List[Dict[str, Any]], key: str, device_hash: str, local_position: float,
                 *, min_delta_s: float = HANDOFF_MIN_DELTA_S) -> Optional[Dict[str, Any]]:
    """Co má POZASTAVENÝ přehrávač udělat po změně z jiného zařízení (čisté, harness 57).
    `{"action": "seek", "position": s, "item": r}` = přeskočit na cizí pozici (rozdíl ≥ min_delta_s,
    dopředu i zpět — pozastavený přehrávač nic nehraje, takže skok zpět je stejně legitimní jako
    dopředu; z více kandidátů vyhrává nejvyšší `version`); `{"action": "watched", "item": r}` =
    jiné zařízení díl dokoukalo (jen oznámit); None = nic. Vlastní zařízení se ignoruje (echo)."""
    if not key:
        return None
    best = None
    watched = None
    for r in items or []:
        if item_key(r) != key:
            continue
        own_progress, own_watched = own_axes(r, device_hash)   # S21: echo vlastního zápisu se ignoruje po osách
        if r.get("state") == "watched":
            if not own_watched and (watched is None or int(r.get("version") or 0) > int(watched.get("version") or 0)):
                watched = r
            continue
        if r.get("state") != "watching" or own_progress:
            continue
        if best is None or int(r.get("version") or 0) > int(best.get("version") or 0):
            best = r
    if best is not None:
        pos = float(best.get("position_s") or 0)
        if abs(pos - float(local_position)) >= float(min_delta_s):
            return {"action": "seek", "key": key, "position": pos, "item": best}
        return None
    if watched is not None:
        return {"action": "watched", "key": key, "item": watched}
    return None


_handoff = {"provider": None, "executor": None}


def register_handoff(provider, executor) -> None:
    """Služba (`service_nextup`) zaregistruje: `provider()` → `{"key", "position"}` když je přehrávač
    POZASTAVENÝ (jinak None); `executor(plan)` provede seek + oznámení. State sync o Kodi přehrávači
    nic neví — jen rozhoduje (`plan_handoff`)."""
    _handoff["provider"] = provider
    _handoff["executor"] = executor


def apply_item_unskipped(r: Dict[str, Any]) -> int:
    """Sloučí JEDNU položku z Gate i pro právě hraný klíč (handoff `watched`: jiné zařízení díl
    dokoukalo → ✔ + odebrat z Pokračovat; bez toho by pozastavený přehrávač při Stopu poslal
    `watching` a LWW by ✔ přepsal — Flash A P1 13.09.). Běží pod `applying_remote` (`_execute`)."""
    import richmovie_history as _h
    try:
        from richmovie_gate_transport import get_device_hash
        dev = get_device_hash() or ""
    except Exception:
        dev = ""
    cw_data = _h.cw_load() or {}
    eps = (_h.watched_load() or {}).get("episodes") or []
    movies = _h.watched_movie_ids()
    done, _ok = _execute(plan_merge([r], cw_data.get("items") or [], eps, movies, dev,
                                    hidden_series=cw_data.get("hidden_series") or {}))
    return done


def apply_handoff_item(r: Dict[str, Any]) -> None:
    """CW zápis převzaté pozice pod `applying_remote` (žádná položka fronty — pozice patří
    cizímu zařízení; ts = jeho čas, popisek = jeho jméno)."""
    _execute([("cw_upsert", to_cw_item(r))])   # `_execute` běží pod `applying_remote`; výsledek jen do logu


def _maybe_handoff(items: List[Dict[str, Any]], device_hash: str) -> bool:
    provider, executor = _handoff["provider"], _handoff["executor"]
    if provider is None or executor is None:
        return False
    try:
        ctx = provider()
    except Exception as exc:
        _log("handoff provider failed: %r" % (exc,), 2)
        return False
    if not ctx or not ctx.get("key"):
        return False
    plan = plan_handoff(items, str(ctx["key"]), device_hash, float(ctx.get("position") or 0))
    if plan is None:
        return False
    try:
        executor(plan)
        return True
    except Exception as exc:
        _log("handoff executor failed: %r" % (exc,), 3)
        return False


def apply_items(items: List[Dict[str, Any]]) -> int:
    """Sloučí položky z Gate (odpověď pushe `newer`). Vrací počet provedených akcí.
    mig 0038: `newer` je sloučená pravda o položkách, které jsme právě poslali (částečně uplatněné, odmítnutý
    verdikt) — převezme se i řádek se jménem TOHOTO zařízení (bez filtru echa)."""
    done, _ok = apply_items_ex(items, own_rows=True)
    return done


def apply_items_ex(items: List[Dict[str, Any]], *, own_rows: bool = False) -> Tuple[int, bool]:
    """Sloučí položky z Gate do lokálních souborů. Vrací (počet akcí, ok) — `ok=False`
    = něco se nezapsalo a pull NEposune kurzor (3.5.151, R2).
    Právě přehrávaný titul se do souborů neslučuje (30s checkpoint by ho přepsal) —
    pozastavený přehrávač ale dostane handoff (`_maybe_handoff`, Φ3 13.09.2026)."""
    if not items:
        return 0, True
    import richmovie_history as _h
    try:
        from richmovie_gate_transport import get_device_hash
        dev = get_device_hash() or ""
    except Exception:
        dev = ""
    cw_data = _h.cw_load() or {}
    eps = (_h.watched_load() or {}).get("episodes") or []
    movies = _h.watched_movie_ids()
    pk = playing_key()
    done, ok = _execute(plan_merge(items, cw_data.get("items") or [], eps, movies, "" if own_rows else dev,
                                   skip_keys=[pk] if pk else None, hidden_series=cw_data.get("hidden_series") or {}))
    if pk and _maybe_handoff(items, dev):
        done += 1
    return done, ok


# ── fronta ───────────────────────────────────────────────────────────────────

_QUEUE = _sq.SyncQueue(QUEUE_FILE, queue_key, lambda it: to_epoch(it.get("client_updated_at")),
                       max_items=QUEUE_MAX_ITEMS, quarantine_max=QUARANTINE_MAX_ITEMS, name="pending_state",
                       log=lambda m, l=1: _log(m, l))
_CURSOR = _sq.SyncCursor(CURSOR_FILE, name="state_sync")


def _queue_path() -> str:
    return _QUEUE.path()


def _cursor_path() -> str:
    return _CURSOR.path()


def _empty_queue() -> Dict[str, Any]:
    return _sq.SyncQueue.empty()


def _load_queue(path: str) -> Dict[str, Any]:
    return _QUEUE.load(path)


def _save_queue(path: str, data: Dict[str, Any]) -> bool:
    return _QUEUE.save(data, path)


def _lock(path: str):
    return _QUEUE.lock(path)


def enqueue(item: Optional[Dict[str, Any]]) -> bool:
    """Zařadí položku (dedupe podle klíče, novější vyhrává). False = nic
    (Host / bez profilu / echo z pullu / bez TMDb id)."""
    if not item or is_applying_remote() or sync_scope() is None:
        return False
    return _QUEUE.enqueue(item)


def note_local_change(op: str, payload: Any = None, **kw: Any) -> bool:
    """Jediný vstup z `richmovie_history` (SSOT mapování lokální operace → položka):
    cw_upsert(item) | cw_remove(item) | watched_episode(tv_id,season,episode,completion)
    | watched_movie(tmdb_id) | unwatched_episode(tv_id,season,episode) | unwatched_movie(tmdb_id)
    | sleep_verdict(tv_id,season,episode) | cw_hide_series(tv_id)  (mig 0038)."""
    try:
        if op == "cw_upsert":
            # `client_time` v záznamu = čas poslední ZMĚNY postupu (služba ho nese u finálního Stopu po
            # dlouhé pauze; Flash C P0 13.09.): Stop bez posunu pozice nesmí dostat nový čas a v LWW
            # přepsat postup jiného zařízení. Bez pole = teď (běžný zápis).
            ct = payload.get("client_time") if isinstance(payload, dict) else None
            return enqueue(item_from_cw(payload, client_time=float(ct) if ct else time.time()))
        if op == "cw_remove":
            key = cw_key(payload)
            if not key:
                return False
            kind, tmdb, s, e = key.split(":")
            return enqueue(item_removed(kind, int(tmdb), int(s), int(e)))
        if op == "watched_episode":
            return enqueue(item_watched_episode(kw.get("tv_id"), kw.get("season", 0), kw.get("episode", 0),
                                                kw.get("completion"), now=kw.get("at"), kind=kw.get("kind", "attended")))
        if op == "watched_movie":
            return enqueue(item_watched_movie(payload, now=kw.get("at")))
        if op == "unwatched_episode":
            return enqueue(item_removed("tv", kw.get("tv_id"), kw.get("season", 0), kw.get("episode", 0),
                                        scope=SCOPE_WATCHED))
        if op == "unwatched_movie":
            return enqueue(item_removed("movie", payload, scope=SCOPE_WATCHED))
        if op == "sleep_verdict":
            return enqueue(item_sleep_verdict(kw.get("tv_id"), kw.get("season", 0), kw.get("episode", 0)))
        if op == "cw_hide_series":
            return enqueue(item_removed("tv", kw.get("tv_id"), 0, 0, scope=SCOPE_CW_SERIES))
    except Exception as exc:
        _log("note_local_change(%s) failed: %r" % (op, exc), 3)
    return False


def sanitize_for_requeue(item: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Položka karantény, kterou Gate odmítl kvůli NAŠÍ vadě odstraněné v 4.0.3 (pozice/podíl mimo meze —
    nález M3), opravená k novému odeslání; jiné vady = None (zůstávají v karanténě). Nesmyslná pozice
    (`sane_checkpoint` False) se opraví na 0 jen u ✔ — postup s nesmyslnou pozicí se znovu NEPOSÍLÁ (None =
    zůstane v karanténě jako stopa).
    Čisté (harness 90)."""
    if not isinstance(item, dict) or item.get("state") not in ("watched", "watching"):
        return None
    try:
        comp = float(item.get("completion") or 0)
        pos, rt = float(item.get("position_s") or 0), float(item.get("runtime_s") or 0)
    except (TypeError, ValueError):
        return None
    if comp <= 1.0 and (rt <= 0 or pos <= rt):
        return None   # tahle položka v karanténě není kvůli mezím — nechat
    fixed = dict(item)
    if item.get("state") == "watched":
        fixed.update({"completion": round(min(1.0, max(0.0, comp)), 3), "position_s": 0})
        return fixed
    if not sane_checkpoint(pos, rt):
        return None
    fixed["position_s"] = int(min(pos, rt)) if rt > 0 else int(pos)
    fixed["completion"] = progress_fraction(fixed["position_s"], rt)
    return fixed


def requeue_clamped_quarantine() -> int:
    """Jednorázově po aktualizaci (služba při startu; idempotentní): ✔ a postup odmítnuté kvůli mezím
    zpět do fronty — ✔ ztracené v karanténě (Lanterns 10.10.) tak dorazí na Gate a na ostatní zařízení."""
    n = _QUEUE.requeue_quarantined(sanitize_for_requeue)
    if n:
        _log("karanténa: %d položek s pozicí/podílem mimo meze opraveno a vráceno do fronty" % n, 2)
    return n


def pending_count() -> int:
    """Počet položek ve frontě (parsuje JSON jen když se soubor změnil)."""
    return _QUEUE.pending_count()


def _transport_post(path: str, body: Dict[str, Any], timeout: float) -> Tuple[int, Any]:
    from richmovie_gate_transport import post_json
    return post_json(path, body, timeout=timeout)


def _transport_get(path: str, params: Dict[str, Any], timeout: float, *, quick: bool = False) -> Dict[str, Any]:
    import richmovie_profile as _p
    # quick (render hlavního menu): jeden pokus, celý rozpočet = timeout (Fable P2-10);
    # jinak služba → background profil s běžným rozpočtem
    return _p.gate_get(path, params=params, timeout=timeout, quick=quick, background=not quick)


def safe_label(text: Any, limit: int = 64) -> str:
    """Popisek zařízení do Kodi labelu: bez `[`/`]` (BBCode injekce `[COLOR]`),
    bez řídicích znaků, ořez. Používá se při odesílání i při vykreslení (obrana
    v hloubce — cizí zařízení může poslat cokoli)."""
    out = "".join(ch for ch in str(text or "") if ch not in "[]" and (ch >= " " or ch == "\t"))
    return " ".join(out.split())[:limit]


_HOST_SUFFIXES = (".localdomain", ".local", ".lan", ".home")


def humanize_friendly(label: str) -> str:
    """`System.FriendlyName` → lidský popisek, nebo "" (= vzít platformu). IP („192.168.2.134"),
    tovární „Kodi"/„localhost" → ""; doménová přípona se jen odřízne („Galaxy-S24-Ultra.localdomain"
    → „Galaxy-S24-Ultra", cross-check Pro A 13.09.); „Kodi (OBYVAK)" → „OBYVAK"."""
    text = (label or "").strip()
    if text.lower().startswith("kodi (") and text.endswith(")"):
        text = text[6:-1].strip()
    low = text.lower()
    for suf in _HOST_SUFFIXES:
        if low.endswith(suf):
            text = text[:-len(suf)]
            low = text.lower()
            break
    if not text or low in ("kodi", "localhost"):
        return ""
    if all(ch.isdigit() or ch == "." for ch in text):
        return ""
    return text


def _looks_human(label: str) -> bool:
    return bool(humanize_friendly(label))


def human_device_label(platform: str) -> str:
    """Lidský fallback z `detect_platform()` (čisté, harness 57): „Android | samsung SM-S928B" →
    „Android · samsung SM-S928B", „Windows | RICHIE-LENOVO" → „PC Windows", „Darwin | x" → „Mac"."""
    text = (platform or "").strip()
    system, _, node = text.partition("|")
    system, node = system.strip(), node.strip()
    if not system or system.lower() == "unknown":
        return "Zařízení"
    if system.lower() == "android":
        return "Android · %s" % node if node else "Android"
    if system.lower() == "windows":
        return "PC Windows"
    if system.lower() == "darwin":
        return "Mac"
    if system.lower() == "linux":
        return "Linux"
    return system


def device_label() -> str:
    """Lidský popisek zařízení pro ostatní zařízení („TV obývák", „Telefon Richie").
    Pořadí: nastavení `rm_device_name` (SSOT `richmovie_settings`) > lidský Kodi
    `System.FriendlyName` > `human_device_label(platforma)`. Správce ho může přebít v Gate."""
    label = ""
    try:
        import richmovie_settings as _st
        label = (_st.get_str(SETTING_DEVICE_NAME) or "").strip()
    except Exception:
        label = ""
    if not label and _HAVE_KODI:
        try:
            label = humanize_friendly(xbmc.getInfoLabel("System.FriendlyName") or "")
        except Exception:
            label = ""
    if not label:
        try:
            from richmovie_gate_transport import detect_platform
            label = human_device_label(detect_platform() or "")
        except Exception:
            label = "Zařízení"
    return safe_label(label)


ACTIVITY_ICON = {"playing": "\u25b6", "paused": "\u23f8"}   # ▶ ⏸ (Kodi fonty obojí mají)


def origin_text(cw: Dict[str, Any], now: Optional[float] = None) -> str:
    """Jeden formát řádku „odkud stav je" pro root, list Pokračovat i rail (čisté, harness 57):
      „▶ právě hraje · Telefon Richie"      (playing, čerstvé)
      „⏸ Telefon Richie · před 2 min"       (paused; nebo playing starší než ACTIVITY_STALE_S)
      „Telefon Richie · před 2 h"           (stopped)
      „toto zařízení · před 5 min"          (lokální záznam bez cizího popisku)
    Čas: u cizího stavu čas Gate (`remote_updated_at`, cross-check PC8), jinak lokální `ts`."""
    if not isinstance(cw, dict):
        return ""
    now = time.time() if now is None else now
    label = safe_label(cw.get("remote_device_label")) or "toto zařízení"
    ts = to_epoch(cw.get("remote_updated_at")) if cw.get("remote_device_label") else 0.0
    if not ts:
        ts = float(cw.get("ts") or 0)
    activity = normalize_activity(cw.get("activity"))
    if activity == "playing" and now - ts > ACTIVITY_STALE_S:
        activity = "paused"   # heartbeat zmizel = zařízení už nehraje (vypnuté / offline)
    ago = ago_text(ts, now) if ts else ""
    if activity == "playing":
        return "%s právě hraje \xb7 %s" % (ACTIVITY_ICON["playing"], label)
    head = ("%s " % ACTIVITY_ICON["paused"]) if activity == "paused" else ""
    return "%s%s%s" % (head, label, (" \xb7 %s" % ago) if ago else "")


# ── push ─────────────────────────────────────────────────────────────────────

_rejected_indexes = _sq.rejected_indexes
_error_code = _sq.error_code


def push_body(scope: Dict[str, Any], batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Tělo POST /v1/profiles/state. Identita (`ws_username`, `ws_proof`, `device_hash`)
    jde z SSOT `gate_transport.build_common_fields()` — stejně jako všechny ostatní POST
    `/v1/*` (3.5.143: do té doby tělo identitu NEMĚLO, Gate vracel 422 `ws_username missing`
    a žádný push stavu nikdy neprošel; harness i tři audity to minuly, protože stubují
    `_transport_post` — proto je teď tělo samostatná funkce s asercí na identitu)."""
    return _sq.identity_body({"profile_id": scope.get("profile_id"), "device_label": device_label(),
                              "items": batch, "client_now": to_iso(time.time())})   # client_now → korekce hodin (PA1)


def flush(reason: str = "tick", timeout: float = 20.0) -> str:
    """Jeden push stavu (Pokračovat/✔) — SSOT klasifikace odpovědi = `richmovie_sync_queue.flush_queue`."""
    ok, why = _preconditions()
    if not ok:
        return OUTCOME_SKIPPED
    scope = sync_scope() or {}
    return _sq.flush_queue(_QUEUE, endpoint=STATE_PATH, body_builder=lambda batch: push_body(scope, batch),
                           transport_post=_transport_post, timeout=timeout, reason=reason,
                           batch_max=PUSH_BATCH_MAX, on_newer=apply_items, log=_log, flush_lock=_flush_lock)


# ── pull ─────────────────────────────────────────────────────────────────────

def _load_cursor() -> Dict[str, Any]:
    return _CURSOR.load()


def _save_cursor(version: int, profile_id: Optional[int], *, full_at: Optional[float] = None) -> None:
    _CURSOR.save(version, profile_id, full_at=full_at)


pull_since = _sq.pull_since


def last_pull_age_s() -> float:
    return _CURSOR.last_pull_age_s()


_pull_lock = threading.Lock()
# 3.5.151 (Φ3): `threading.Lock` chrání jen JEDEN proces. Kodi spouští hlavní menu 2× a služba
# pulluje zároveň — první sloučení na čerstvém zařízení běželo třikrát naráz (notebook 16.09.2026).
# Meziprocesový claim (`richmovie_guard`) pustí jeden pull; ostatní přeskočí (služba to dotáhne).
PULL_CLAIM = "state_pull"


def pull_and_apply(reason: str = "tick", timeout: float = 8.0, max_pages: int = PULL_PAGES_MAX) -> Tuple[int, str]:
    """Deltový pull + sloučení. Vrací (počet provedených akcí, výsledek).
    Všechny stránky se nejdřív stáhnou a sloučí NAJEDNOU (dokoukaný díl a
    „watching" dalšího dílu nesmí dorazit každý zvlášť — cross-check PC2);
    kurzor se posune až po sloučení."""
    ok, why = _preconditions()
    if not ok:
        return 0, OUTCOME_SKIPPED
    scope = sync_scope() or {}
    return _sq.pull_queue(endpoint=STATE_PATH, cursor=_CURSOR, profile_id=scope.get("profile_id"),
                          transport_get=_transport_get, on_apply=apply_items_ex,
                          log=_log, pull_lock=_pull_lock, reason=reason, timeout=timeout, max_pages=max_pages,
                          include_param="include_removed", quick=(reason == "menu"), claim_name=PULL_CLAIM)


# ── Auto-resume po utnutí streamu: nejdřív se zeptat Gate (3.5.147, Φ2 / D3; cross-check T3-P4 05.09.) ──
# Bez toho by navázání pushlo NAŠI pozici a přepsalo `watching` z jiného zařízení, které tentýž
# titul právě sleduje (LWW ping-pong). Rozhoduje čistá funkce nad staženými položkami.
RESUME_REMOTE_MIN_DELTA_S = 120.0   # menší rozdíl pozic = tentýž bod, není co měnit


def newer_remote_watching(items: List[Dict[str, Any]], key: str, device_hash: str,
                          local_position: float) -> Optional[Dict[str, Any]]:
    """Z položek stažených z Gate (jen NOVĚJŠÍ než náš kurzor — okno verzí, viz
    `remote_resume_position`) vybere `watching` téhož titulu z JINÉHO zařízení, které je
    DÁL než naše pozice o víc než `RESUME_REMOTE_MIN_DELTA_S`. Jen dopředu — skok zpět
    není navázání (cross-check Pro P1 10.09.: dvě TV by si jinak skákaly po sobě). Bez
    porovnávání časů klientů (F6: hodiny zařízení vs. čas korigovaný Gate) — „novější"
    zaručuje `since` z kurzoru. Z více kandidátů vyhrává nejvyšší `version`. Čistá funkce (harness 54)."""
    best = None
    for r in items or []:
        if item_key(r) != key or r.get("state") != "watching":
            continue
        if own_axes(r, device_hash)[0]:
            continue   # postup zapsalo toto zařízení (S21: zapisovatel osy postupu, ne poslední událost řádku)
        pos = float(r.get("position_s") or 0)
        if pos - float(local_position) < RESUME_REMOTE_MIN_DELTA_S:
            continue
        if best is None or int(r.get("version") or 0) > int(best.get("version") or 0):
            best = r
    return best


def remote_resume_position(key: str, local_position: float, timeout: float = 3.0,
                           max_pages: int = 2) -> Optional[Dict[str, Any]]:
    """Read-only dotaz na Gate před navázáním (nic se neaplikuje, kurzor se nehýbe): stáhne
    stav profilu NOVĚJŠÍ než náš kurzor (`since` = uložená verze − překryv; při přehrávání se
    nepulluje, takže sem spadne vše, co jiné zařízení poslalo během našeho sledování — F4:
    `since=0` bere nejstarší stránky a čerstvý stav velkých profilů by minulo), nejvýš 2 stránky,
    a vrátí `newer_remote_watching`. Transport/offline/bez profilu → None = navázat lokálně."""
    ok, _why = _preconditions()
    if not ok:
        return None
    scope = sync_scope() or {}
    profile_id = scope.get("profile_id")
    try:
        cur = _CURSOR.load(_CURSOR.path())
        since = 0 if cur.get("profile_id") != profile_id else max(0, int(cur.get("version") or 0) - _sq.PULL_OVERLAP)
        items, _version = _sq.pull_pages(STATE_PATH, since, profile_id, _transport_get,
                                         timeout=timeout, quick=True, max_pages=max(1, int(max_pages)))
    except Exception as exc:
        _log("remote_resume_position: pull selhal → lokální pozice (%r)" % (exc,), 1)
        return None
    try:
        from richmovie_gate_transport import get_device_hash
        dev = get_device_hash() or ""
    except Exception:
        dev = ""
    return newer_remote_watching(items, key, dev, local_position)


def pull_if_stale(max_age_s: float = PULL_INTERVAL_S, timeout: float = 1.5, step: str = "pull_menu") -> int:
    """Pro plugin (otevření hlavního menu; od 4.0.3 i výpisy s ✔/◐ — seznam dílů, sezón, „Další díl"):
    JEDNA stránka s krátkým timeoutem, jen když služba nepullovala v posledních `max_age_s` (typicky jen po
    startu Kodi nebo probuzení zařízení — služba pulluje každých 30 s při nečinnosti). Offline / bez profilu =
    návrat hned. Vědomý kompromis (cross-check PC7): strop 1,5 s v cestě renderu výměnou za čerstvý stav
    (incident 10.10.2026: notebook po 95 h spánku ukázal díl z Chromecastu jako neviděný)."""
    if last_pull_age_s() < max_age_s:
        return 0
    import richmovie_breadcrumb as _rbc
    with _rbc.step(step) as _st:   # Φ0: blokuje vykreslení (strop `timeout`)
        applied, _outcome = pull_and_apply(reason="menu", timeout=timeout, max_pages=1)
        _st["applied"] = applied
    return applied


_push_request = {"state": False, "items": False}   # vynucení pushe PER KANÁL (Fable P2-1)


def _items_pending() -> int:
    """Fronta kanálu kolekcí (lazy import; os.stat cache uvnitř)."""
    try:
        import richmovie_profile_items as _pi
        return _pi.pending_count()
    except Exception:
        return 0


def wait_enabled() -> bool:
    """Killswitch realtime kanálu (nastavení `state_wait_enabled`, default zapnuto)."""
    try:
        import richmovie_settings as _st
        raw = (_st.get_str(SETTING_WAIT_ENABLED) or "").strip().lower()
        return raw != "false"
    except Exception:
        return True


def request_push(channel: str = "state") -> None:
    """Zdroj změny žádá o push SVÉHO kanálu v nejbližším tiku bez ohledu na 60s/15s kadenci
    (cross-check PC6: „push při stopu"). Kontraktní backoff kanálu se NIKDY neobchází (R2b);
    kanál kolekcí (`richmovie_profile_items`) nesmí vynutit POST stavu (Fable P2-1)."""
    _push_request["items" if channel == "items" else "state"] = True


# ── D11: samovolná obnova menu ───────────────────────────────────────────────

def maybe_refresh_menu() -> bool:
    """Po sloučení změn z jiného zařízení se má hlavní menu překreslit (D11). Zapíše TICHÝ požadavek do jedné fronty
    obnov výpisu (`richmovie_playback_dispatch.request_refresh`) a hned ho zkusí dohnat; když to teď nejde (jiné okno nebo
    výpis, dialog, přehrávač, relace přehrávání, divák pracuje, menu se staví), dožene ho hlavní smyčka služby každý tik.
    S18 (10.10.2026): KDY a KDE rozhoduje jeden verdikt dispatcheru pro D11 i akce na klik — dřív vlastní politika
    (`refresh_allowed`), vlastní čekání v paměti služby, vlastní kontrola nečinnosti a vlastní dohánění. Incident
    21.09.2026 (odmítnuté obnovení se zahodilo) platí dál: požadavek čeká, během přehrávání nestárne. Vždy
    `Container.Refresh` na místě, nikdy `Container.Update`. Vrací True = obnova odeslána hned."""
    if not _HAVE_KODI:
        return False
    if not _rm_dispatch.request_refresh(_rm_dispatch.ROOT_LISTING, "d11_menu", silent=True):
        return False
    return _rm_dispatch.flush_refresh_queue()


# ── tik služby ───────────────────────────────────────────────────────────────

class ServiceTicker:
    """Stav pro `service_nextup` (jeden objekt; od 3.5.147 DVA pracovní workery — kanál stav
    a kanál kolekcí, každý daemon vlákno, viz `_spawn`: fronta je trvanlivá a Gate dedupuje,
    takže useknutý push nic neztratí; non-daemon by blokoval 5s okno vypnutí Kodi, cross-check
    T1 Pro P8). `tick(playing)` se volá každých ~5 s; sám rozhodne, zda je čas na push/pull."""

    def __init__(self) -> None:
        self.last_push_attempt = 0.0
        self.last_state_ok = 0.0    # poslední úspěšný push kanálu stav (per kanál, Pro P3 10.09.)
        self.last_items_ok = 0.0    # dtto kanál kolekcí — každý worker píše jen svou proměnnou
        self.last_pull = 0.0
        self.push_blocked_until = 0.0   # kontraktní chyba → stejný POST neopakovat (R2b)
        self.items_blocked_until = 0.0  # totéž pro kanál kolekcí (richmovie_profile_items)
        self.thread: Optional[threading.Thread] = None         # kanál stav (Pokračovat/✔) + pull + refresh
        self.items_thread: Optional[threading.Thread] = None   # kanál kolekcí (3.5.147, Φ7 / D11)
        # realtime kanál (13.09.2026, Φ2): jedno čekání `GET /state/wait` v nečinnosti nebo pauze
        self.wait_thread: Optional[threading.Thread] = None
        self.last_wait_ok = 0.0         # poslední čekání, které Gate korektně ukončil (changed True/False)
        self.wait_blocked_until = 0.0   # 429 / kontrakt / transport → dočasně jen polling
        self._scope_key: Any = _SCOPE_UNSEEN   # S24 R7: profil, pro který platí odklady výše
        self._stopped = False                  # S23: `stop()` — žádné nové workery

    def stop(self) -> None:
        """S23 (03.11.2026): služba končí. Nové workery se už nespouští; ty běžící (push/pull/long-poll) ukončí
        `richmovie_http.cancel_all()` — zavře jejich sockety a blokující čtení se vrátí hned. Pořadí volá
        `service_nextup` ve `finally` hlavní smyčky: nejdřív `stop()`, pak `cancel_all()`. Fronty jsou trvanlivé
        na disku a Gate je idempotentní (LWW) → useknutý push nic neztratí, položka odejde při příštím startu."""
        self._stopped = True

    @property
    def last_push_ok(self) -> float:
        """Kadence při přehrávání (`PUSH_INTERVAL_S`) bere poslední úspěch KTERÉHOKOLI kanálu."""
        return max(self.last_state_ok, self.last_items_ok)

    @last_push_ok.setter
    def last_push_ok(self, value: float) -> None:   # testy / kompatibilita: nastaví oba kanály
        self.last_state_ok = self.last_items_ok = float(value)

    def wait_healthy(self, now: Optional[float] = None) -> bool:
        """Realtime kanál funguje (poslední korektní čekání < WAIT_HEALTHY_S) → 30s polling je zbytečný."""
        now = time.time() if now is None else now
        return (now - self.last_wait_ok) < WAIT_HEALTHY_S

    def due(self, playing: bool, now: Optional[float] = None, paused: bool = False) -> Tuple[bool, bool]:
        now = time.time() if now is None else now
        # Kontraktní backoff i vynucení jsou PER KANÁL (Flash NAVÍC 2 + Fable P2-1): kanál v backoffu se
        # nepushne ani vynuceně; vynucení jednoho kanálu neposílá druhý mimo kadenci.
        forced_state, forced_items = bool(_push_request["state"]), bool(_push_request["items"])
        state_ready = (forced_state or pending_count() > 0) and now >= self.push_blocked_until
        items_ready = (forced_items or _items_pending() > 0) and now >= self.items_blocked_until
        forced = (forced_state and state_ready) or (forced_items and items_ready)
        pending = state_ready or items_ready
        want_push = pending and (forced or (now - self.last_push_attempt >= PUSH_RETRY_MIN_S
                                            and (not playing or now - self.last_push_ok >= PUSH_INTERVAL_S)))
        # Pull: v nečinnosti NEBO v pauze (Φ3 handoff — pozastavený přehrávač se musí dozvědět, že jiné
        # zařízení pokračovalo). Když realtime kanál žije, 30s polling odpadá (pull spustí `_wait_work`).
        idle_or_paused = (not playing) or paused
        want_pull = idle_or_paused and (now - self.last_pull >= PULL_INTERVAL_S)             and (not self.wait_healthy(now) or now - self.last_pull >= PULL_SAFETY_S)
        return want_push, want_pull

    def wait_due(self, playing: bool, paused: bool, now: Optional[float] = None) -> bool:
        """Má se otevřít (další) long-poll? Jen v nečinnosti / pauze, mimo blokaci, jedno naráz."""
        now = time.time() if now is None else now
        if playing and not paused:
            return False
        if now < self.wait_blocked_until:
            return False
        if self.wait_thread is not None and self.wait_thread.is_alive():
            return False
        return wait_enabled()

    def note_scope(self, scope: Optional[Dict[str, Any]]) -> bool:
        """S24 R7 (audit Fable N5, 15.10.2026): změnil se rozsah synchronizace (profil)? Pak se ruší KONTRAKTNÍ odklady
        pushe stavu a kolekcí — odklad (`CONTRACT_BACKOFF_S` 30 min) chrání před opakováním TÉHOŽ POSTu, ale s jiným
        profilem je to jiný požadavek. Bez toho po přepnutí účtu na více profilů (single → majitel) visel Pokračovat
        z tohoto zařízení na Gate až 30 min kvůli 400 `profile_required` z doby, kdy zařízení ještě posílalo push
        „za účet“. Oba odklady vznikají JEN z kontraktní odpovědi (`OUTCOME_CONTRACT`; 429 je `OUTCOME_FAILED` bez
        odkladu). Odklad čekání (`wait_blocked_until`) se NEruší: nese i 429 (`too_many_waiters`, limit ÚČTU, ne profilu)
        — pravidlo „429 se nikdy neopakuje“ (cross-check Gemini B7, 15.10.2026); kanál mezitím jede pollingem.
        True = rozsah se změnil (a kontraktní odklady jsou zrušené)."""
        key = (scope or {}).get("profile_id") if scope is not None else _SCOPE_NONE
        if key == self._scope_key:
            return False
        blocked = self.push_blocked_until or self.items_blocked_until
        if self._scope_key is not _SCOPE_UNSEEN and blocked:
            _log("scope %r → %r: kontraktní odklady zrušeny (jiný profil = jiný požadavek)" % (self._scope_key, key), 2)
        self.push_blocked_until = self.items_blocked_until = 0.0
        self._scope_key = key
        return True

    def tick(self, playing: bool, paused: bool = False) -> None:
        """Každých ~5 s. Dva kanály = dva workery (3.5.147, Φ7 / D11, cross-check Pro C P14):
        kanál STAV (push fronty stavu + pull obou kanálů + obnova seznamu profilů) a kanál
        KOLEKCE (push `richmovie_profile_items`). Dřív jeden worker sériově: transportní
        selhání jednoho kanálu (až 28 s) zdržovalo druhý. Sdílená je jen kadence
        (`due()`); backoff i „běží nejvýš jednou" jsou per kanál.
        13.09.2026: třetí worker = long-poll čekání (`_wait_work`) v nečinnosti / pauze."""
        # Obnovu menu, která minule nešla, dohání hlavní smyčka služby (`richmovie_playback_dispatch.flush_refresh_queue`,
        # S18) — nezávisle na spojení s Gate (data jsou už sloučená lokálně).
        if self._stopped:
            return      # S23: služba končí — žádný nový worker (jinak by na něj Kodi při vypínání čekalo)
        ok, _why = _preconditions()   # čistě paměťové kontroly PŘED čtením fronty z disku
        if not ok:
            return
        self.note_scope(sync_scope())   # S24 R7: jiný profil = odklady z minulého rozsahu neplatí
        if self.wait_due(playing, paused):
            self.wait_thread = self._spawn("RMStateWait", self._wait_work, self._scope_key)
        want_push, want_pull = self.due(playing, paused=paused)
        if not (want_push or want_pull):
            return
        now = time.time()
        state_busy = self.thread is not None and self.thread.is_alive()
        items_busy = self.items_thread is not None and self.items_thread.is_alive()
        forced_state, forced_items = bool(_push_request["state"]), bool(_push_request["items"])
        run_state_push = want_push and (forced_state or pending_count() > 0) and now >= self.push_blocked_until
        run_items_push = want_push and (forced_items or _items_pending() > 0) and now >= self.items_blocked_until
        spawn_state = (run_state_push or want_pull) and not state_busy
        spawn_items = run_items_push and not items_busy
        # Vynucení (`request_push`) se maže až když worker OPRAVDU startuje — běžící worker
        # ho jinak spolkne a stop-signál po přehrávání by se ztratil (Fable audit 10.09.).
        if spawn_state and run_state_push:
            _push_request["state"] = False
        if spawn_items:
            _push_request["items"] = False
        if want_push and ((spawn_state and run_state_push) or spawn_items):
            self.last_push_attempt = now
        if spawn_state and want_pull:
            self.last_pull = now
        if spawn_state:
            self.thread = self._spawn("RMStateSync", self._state_work, run_state_push, want_pull, self._scope_key)
        if spawn_items:
            self.items_thread = self._spawn("RMItemsSync", self._items_work, self._scope_key)

    def _block(self, attr: str, seconds: float, scope_key: Any) -> bool:
        """Nastaví odklad kanálu (`push_blocked_until` / `items_blocked_until` / `wait_blocked_until`) JEN když rozsah
        synchronizace je pořád ten, se kterým worker začal (S24, cross-check Codex #3): odpověď na push profilu A, která
        dorazí po přepnutí na B, nesmí zablokovat B na 30 min. `scope_key` = `_SCOPE_ANY` (přímé volání mimo tik) =
        bez kontroly. True = odklad nastaven."""
        if scope_key is not _SCOPE_ANY and scope_key != self._scope_key:
            _log("%s: odpověď starého rozsahu %r (teď %r) → odklad se nenastavuje" % (attr, scope_key, self._scope_key), 1)
            return False
        setattr(self, attr, time.time() + float(seconds))
        return True

    def _spawn(self, name: str, target, *args) -> threading.Thread:
        # daemon=True: fronta je DURABLE na disku a Gate je LWW/idempotentní — zabití vlákna uprostřed POSTu
        # nic neztratí (položka zůstane, příště se pošle znovu). POZOR (S23, ověřeno ve zdroji Kodi 21.2
        # `PythonInvoker.cpp:384–406`): `daemon` vypnutí Kodi NEUSPÍŠÍ — Kodi čeká na VŠECHNA vlákna
        # interpretu. Rychlé vypnutí zajišťuje `stop()` + `richmovie_http.cancel_all()` (zrušitelné I/O).
        th = threading.Thread(target=target, args=args, name=name, daemon=True)
        th.start()
        return th

    def _state_work(self, do_push: bool, do_pull: bool, scope_key: Any = _SCOPE_ANY) -> None:
        """Kanál stav: push fronty Pokračovat/✔, pak pull obou kanálů + D14 obnova seznamu profilů.
        `scope_key` = rozsah při spuštění workeru (tik; `None` = „Jen já“ je platný rozsah); bez něj (přímé
        volání) `_SCOPE_ANY` = odklad bez kontroly rozsahu."""
        try:
            if do_push:
                outcome = flush("service")
                if outcome == OUTCOME_SENT:
                    self.last_state_ok = time.time()
                elif outcome == OUTCOME_CONTRACT:
                    if self._block("push_blocked_until", CONTRACT_BACKOFF_S, scope_key):
                        _log("push: kontraktní chyba → další pokus za %d min" % int(CONTRACT_BACKOFF_S // 60), 2)
            if do_pull:
                applied, _o = pull_and_apply("service")
                changed = applied > 0
                try:
                    import richmovie_profile_items as _pi
                    applied2, _o2 = _pi.pull_and_apply("service")
                    changed = changed or applied2 > 0
                except Exception as _pi_exc:
                    _log("items pull failed: %r" % _pi_exc, 3)
                # D14 (Φ4): jména/pořadí/fotky profilů z Gate bez restartu Kodi —
                # stejný 30s tik při nečinnosti, jen u multi účtu.
                try:
                    import richmovie_profile as _p
                    if _p.is_multi() and _p.refresh_list_if_changed(timeout=8.0):
                        changed = True
                except Exception as _pl_exc:
                    _log("profile list refresh: %r" % _pl_exc, 0)
                if changed:
                    maybe_refresh_menu()
        except Exception as exc:
            _log("service tick failed: %r" % exc, 3)

    def _wait_since(self) -> int:
        scope = sync_scope() or {}
        cur = _CURSOR.load(_CURSOR.path())
        if cur.get("profile_id") != scope.get("profile_id"):
            return 0
        return max(0, int(cur.get("version") or 0))

    def _wait_work(self, scope_key: Any = _SCOPE_ANY) -> None:
        """Realtime kanál: jedno čekání `GET /state/wait?since=<kurzor>` (≤ WAIT_S). `changed` → běžný
        `pull_and_apply` (jediná cesta sloučení + handoff) a překreslení podle D11. Chyby:
        transport → WAIT_TRANSIENT_BLOCK_S; 429 / autoritativní / kontrakt → WAIT_BLOCK_S (jede polling).
        Vlákno končí po každém čekání; další otevře `tick()` (≥ 5 s rozestup je přirozený).
        Odklad jen pro rozsah, se kterým čekání začalo (`_block`, S24)."""
        try:
            scope = sync_scope() or {}
            params = {"since": self._wait_since(), "wait_s": int(WAIT_S)}
            if scope.get("profile_id"):
                params["profile_id"] = scope["profile_id"]
            try:
                data = _transport_get(WAIT_PATH, params, WAIT_TIMEOUT_S)
            except Exception as exc:
                # `ProfileGateError` řadí 429 mezi přechodné (transport třída) — pro čekání je 429 limit účtu
                # (`too_many_waiters` / `http_429`) → dlouhá blokace, polling; 429 se NIKDY neopakuje (Flash B P2)
                code = str(getattr(exc, "code", "") or "")
                is_429 = code in ("too_many_waiters", "http_429")
                transient = bool(getattr(exc, "transient", False)) and not is_429
                # 429 = limit ÚČTU, ne profilu → odklad VŽDY (i po změně rozsahu), jinak by další tik poslal 2. požadavek
                # po 429 (pravidlo „429 se nikdy neopakuje“, audit Fable N3)
                if self._block("wait_blocked_until", WAIT_TRANSIENT_BLOCK_S if transient else WAIT_BLOCK_S,
                               _SCOPE_ANY if is_429 else scope_key):
                    _log("wait: %s → polling %d s (%r)" % ("transport" if transient else "odmítnuto",
                                                           int(self.wait_blocked_until - time.time()), exc),
                         2 if transient else 3)
                return
            if not isinstance(data, dict) or "changed" not in data:
                if self._block("wait_blocked_until", WAIT_BLOCK_S, scope_key):
                    _log("wait: odpověď bez klíče `changed` (kontrakt) → polling %d s" % int(WAIT_BLOCK_S), 4)
                return
            self.last_wait_ok = time.time()
            if not data.get("changed"):
                return
            applied, outcome = pull_and_apply("wait")
            self.last_pull = time.time()
            if outcome == OUTCOME_FAILED:
                # pull po probuzení selhal (transport/5xx): další čekání by se vrátilo hned (verze > kurzor)
                # a smyčka wait→pull by jela každých 5 s — krátká pauza, netstate breaker řeší delší výpadek
                self._block("wait_blocked_until", WAIT_TRANSIENT_BLOCK_S, scope_key)
                return
            if applied:
                maybe_refresh_menu()
        except Exception as exc:
            _log("wait worker failed: %r" % exc, 3)

    def _items_work(self, scope_key: Any = _SCOPE_ANY) -> None:
        """Kanál kolekcí: push fronty `richmovie_profile_items` (vlastní backoff, vlastní vlákno).
        Odklad jen pro rozsah, se kterým push začal (`_block`, S24)."""
        try:
            import richmovie_profile_items as _pi
            o2 = _pi.flush("service")
            if o2 == OUTCOME_SENT:
                self.last_items_ok = time.time()
            elif o2 == OUTCOME_CONTRACT:
                if self._block("items_blocked_until", CONTRACT_BACKOFF_S, scope_key):
                    _log("items push: kontraktní chyba → další pokus za %d min" % int(CONTRACT_BACKOFF_S // 60), 2)
        except Exception as _pi_exc:
            _log("items push failed: %r" % _pi_exc, 3)

