# -*- coding: utf-8 -*-
"""LogDrainer — background thread persistuje SQLite buffer rows do Gate.

Architektura (per Handoff plan + Agent A research):
- Non-daemon thread (per memory feedback_daemon_threads_kodi)
- Owned by service_nextup.py (od 3.4.14; service_warm Kodi nikdy nespustilo — per Agent B: Monitor.abortRequested reliable
  jen v xbmc.service extension points)
- Polls SQLite buffer for unsent rows
- Batches up to 100 events / 256 KiB body
- NDJSON + gzip POST /v1/user_logs/batch
- Exponential backoff on failure (30s -> 5min)
- Mark sent on success
- Increment retry_count on failure (cap watch in stats)
- Periodic prune (every 6 hours)

Shutdown safety:
- Honors monitor.abortRequested via short polling
- stop(timeout=3.0) — leaves 2s margin under Kodi 5s force-kill
- Existing unsent rows survive process death (SQLite WAL fsync)
- Next-startup drainer picks them up

Plan: RichMovie-nas/Handoff/session_2026-04-27_user_logs_audit.md (Phase 4)
"""
from __future__ import annotations

import gzip
import json
import os
import threading
import time
import urllib.error
import urllib.request
import uuid
from typing import Any, Optional

# Kodi API (modul musi prezit i mimo Kodi pro testovani)
try:
    import xbmc
    import xbmcaddon
except ImportError:
    xbmc = None  # type: ignore
    xbmcaddon = None  # type: ignore

from richmovie_log_buffer import LogBuffer


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_ADDON_ID = "plugin.video.richmovie"
_DEFAULT_BATCH_SIZE = 100
_DEFAULT_BATCH_BYTES = 200_000          # ~200 KB pre-gzip — 256 KB after compression
_DEFAULT_FLUSH_INTERVAL = 30            # seconds — periodic flush even if batch not full
_INITIAL_BACKOFF = 30                   # seconds
_MAX_BACKOFF = 300                      # 5 minutes
_PRUNE_INTERVAL = 6 * 3600              # 6 hours
_HTTP_CONNECT_TIMEOUT = 5
_HTTP_READ_TIMEOUT = 30                 # well under Cloudflare 100s limit

# 3.5.120 — hlasitost při nedostupné identitě (incident bandog 27.08.2026).
# Po tolika po sobě jdoucích marných pokusech se z WARNINGu stane ERROR
# s plným diagnostickým blokem.
_IDENTITY_ESCALATE_AFTER = 3
# Hlavní smyčka tiká po ~2 s; bez tlumení by trvalý výpadek zaplavil kodi.log.
# Po eskalaci se opakuje jen jednou za tolik marných kol (~10 minut).
_IDENTITY_REPEAT_EVERY = 300


def _log(msg: str, level: int = 1) -> None:
    """Internal logger — uses xbmc.log directly to avoid recursion."""
    try:
        if xbmc is not None:
            xbmc.log("[RichMovie/LogDrain] " + msg, level)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# LogDrainer
# ---------------------------------------------------------------------------
class LogDrainer:
    """Background drainer — SQLite -> Gate.

    Lifecycle:
        drainer = LogDrainer(buffer, gate_url, ws_username, ...)
        drainer.start()
        ... addon runs ...
        # On shutdown:
        drainer.stop(timeout=3.0)

    Thread-safety: operations on _stop_event use threading.Event semantics.
    SQLite ops are thread-safe via LogBuffer's internal lock.
    """

    def __init__(
        self,
        buffer: LogBuffer,
        gate_url_provider,                  # callable -> str (lazy, lease may change)
        ws_username_provider,               # callable -> str (may be empty if not logged in)
        addon_version: str,
        platform: str,
        kodi_version: str,
        device_hash: str = "",             # stabilní device id (per-device logging, mig 0016)
        monitor: Any | None = None,        # xbmc.Monitor instance
        batch_size: int = _DEFAULT_BATCH_SIZE,
        batch_bytes: int = _DEFAULT_BATCH_BYTES,
        flush_interval: float = _DEFAULT_FLUSH_INTERVAL,
    ) -> None:
        self._buffer = buffer
        self._get_gate_url = gate_url_provider
        self._get_ws_username = ws_username_provider
        self._addon_version = addon_version
        self._platform = platform
        self._kodi_version = kodi_version
        self._device_hash = device_hash
        self._monitor = monitor
        self._batch_size = batch_size
        self._batch_bytes = batch_bytes
        self._flush_interval = flush_interval

        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._backoff_seconds = _INITIAL_BACKOFF
        self._last_identity_block_log = 0.0
        self._last_retry_after: Optional[float] = None
        self._next_attempt_unix = 0.0
        self._last_prune_unix = time.time()
        self._lock = threading.Lock()
        # 3.5.120: kolik kol po sobě se nepodařilo přečíst identitu + kdy naposledy
        # něco doopravdy odešlo (vstup do diagnostického bloku).
        self._identity_miss_streak = 0
        self._last_success_unix: Optional[float] = None
        self._started_unix = time.time()

    # ---- identity (3.5.120) ----

    def _identity_or_report(self, pending_count: int) -> Optional[str]:
        """Vrátí ws_username, nebo None — a v tom případě NAHLAS řekne proč.

        PROČ TAHLE METODA EXISTUJE
        --------------------------
        Do 3.5.119 se na třech místech dělalo `if not ws_username: return/continue`
        bez jediného slova. Když na zařízení začalo čtení nastavení vracet prázdno
        (incident bandog 27.08.2026), drainer se tvářil živě a 15 hodin neodeslal
        nic — ani do `kodi.log` nenapsal, že mlčí. Ticho je legitimní JEN když
        není co posílat.

        Rozlišuje:
          • prázdný buffer            → ticho (nikdo není přihlášen, nic nečeká),
          • neprázdný buffer + selhání → WARNING, po `_IDENTITY_ESCALATE_AFTER`
            kolech ERROR s diagnostickým blokem.

        Druhý pokus o čtení je vědomě levný „hádej znovu" — po A3 bere SSOT
        čerstvou instanci s explicitním ID, takže přechodný stav může zmizet.
        Zázraky se od něj nečekají; hodnota téhle metody je v tom, co ZMĚŘÍ.
        """
        ws_username = self._get_ws_username()
        if not ws_username:
            ws_username = self._get_ws_username()  # jeden levný retry
            if ws_username:
                _log("username read recovered on retry (transient)", 2)

        if ws_username:
            if self._identity_miss_streak:
                _log("username available again after %d failed rounds"
                     % self._identity_miss_streak, 2)
            self._identity_miss_streak = 0
            return ws_username

        if pending_count <= 0:
            # Není co odeslat → mlčet je správně (čerstvá instalace, odhlášený uživatel).
            return None

        # ČERSTVÁ INSTALACE NENÍ PORUCHA (cross-check 27.08.2026, P7).
        # Nový uživatel má v bufferu startovní události, ale ještě se nepřihlásil.
        # Bez tohohle rozlišení by drainer po třech kolech vyhlásil ERROR
        # a každá první instalace by se do kodi.logu zapsala jako havárie.
        if self._identity_not_configured():
            if not self._identity_miss_streak:
                _log("username není nastaven, %d událostí čeká na přihlášení"
                     % pending_count, 1)
            self._identity_miss_streak += 1
            return None

        self._identity_miss_streak += 1
        self._report_identity_failure(pending_count)
        return None

    def _identity_not_configured(self) -> bool:
        """Je prokazatelné, že uživatel prostě NENÍ přihlášen (a nejde o poruchu)?

        Rozlišuje se stejným způsobem jako jinde v 3.5.120 — porovnáním Kodi API
        s obsahem `settings.xml`. Při jakékoli nejistotě vrací False, aby se
        skutečná porucha neschovala za „vždyť se jen nikdo nepřihlásil".
        """
        try:
            import richmovie_settings as _rm_set
            return (_rm_set.diagnose_read("username").get("verdict")
                    == _rm_set.VERDICT_NOT_CONFIGURED)
        except Exception:
            return False

    def _report_identity_failure(self, pending_count: int) -> None:
        """Zapíše do kodi.log, že drainer nemůže odesílat — a proč.

        Záměrně přes `_log()` (tedy `xbmc.log`) a NE přes vlastní logovací
        pipeline: ta jde do téhož SQLite bufferu, který se právě nedaří odeslat.
        Diagnostický kanál nesmí viset na tom, co diagnostikuje.
        """
        streak = self._identity_miss_streak
        if streak < _IDENTITY_ESCALATE_AFTER:
            _log("username unavailable, %d events pending (round %d)"
                 % (pending_count, streak), 2)
            return
        # Po eskalaci už jen občas, jinak by trvalý výpadek zaplavil kodi.log.
        if streak > _IDENTITY_ESCALATE_AFTER and (streak % _IDENTITY_REPEAT_EVERY) != 0:
            return
        _log("username unavailable %d rounds in a row — %d events stuck. Diagnostics:"
             % (streak, pending_count), 3)
        for line in self._identity_diagnostics():
            _log("  " + line, 3)

    def _identity_diagnostics(self) -> list:
        """Řádky diagnostického bloku. Nikdy nevyhazuje.

        Bez těchhle údajů by v logu stálo jen „nejde to" a příčina by zůstala
        neznámá — přesně stav, kvůli kterému vznikla Fáze B plánu 3.5.120.
        """
        lines = []
        try:
            import richmovie_settings as _rm_set
            for key in ("username", "password"):
                diag = _rm_set.diagnose_read(key)
                lines.append(
                    "settings[%s]: verdict=%s api_empty=%s file_state=%s "
                    "file_bytes=%s file_mtime=%s"
                    % (key, diag.get("verdict"), diag.get("api_empty"),
                       diag.get("file_state"), diag.get("file_bytes"),
                       diag.get("file_mtime"))
                )
            lines.append("settings_path: %s" % (_rm_set.settings_file_path() or "?"))
            lines.append("free_space_mb: %s" % _rm_set.free_space_mb())
        except Exception as exc:
            lines.append("settings diagnostics unavailable: %r" % (exc,))
        try:
            last_ok = ("never" if self._last_success_unix is None
                       else "%.0fs ago" % (time.time() - self._last_success_unix))
            lines.append(
                "drainer: pid=%s uptime=%.0fs last_success=%s backoff=%.0fs"
                % (os.getpid(), time.time() - self._started_unix,
                   last_ok, self._backoff_seconds)
            )
        except Exception:
            pass
        return lines

    # ---- lifecycle ----

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return  # idempotent
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="rm-log-drain",
            daemon=False,                     # never daemon (per memory)
        )
        self._thread.start()
        _log("Drainer started")

    def stop(self, timeout: float = 3.0) -> None:
        """Signal stop + join with timeout. Honoring Kodi 5s force-kill window."""
        self._stop_event.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=timeout)
            if self._thread.is_alive():
                _log("Drainer didn't stop within %.1fs — abandoning" % timeout, 2)
            else:
                _log("Drainer stopped cleanly")

    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ---- shutdown sentinel hook (called by service_warm.py on abort) ----

    def shutdown_flush(self, timeout: float = 1.5) -> None:
        """Called from service_warm shutdown sentinel BEFORE drainer.stop().

        Per Agent B: 5s budget between abortRequested + force-kill. Spend
        max 1.5s on single best-effort POST. On failure, leave rows for
        next-startup flush.
        """
        try:
            rows = self._buffer.fetch_unsent(limit=_DEFAULT_BATCH_SIZE)
            if not rows:
                return
            # 3.5.120: dřív zde bylo tiché `return` — při nedostupné identitě
            # zmizel i poslední flush před vypnutím, aniž by to kdokoli poznal.
            if not self._identity_or_report(len(rows)):
                return
            ok, _ = self._upload_batch(rows, timeout_override=timeout)
            if ok:
                self._buffer.mark_sent([r["id"] for r in rows])
                _log("Shutdown flush: %d events delivered" % len(rows))
            else:
                _log("Shutdown flush failed — rows persist for next startup")
        except Exception as exc:
            _log("Shutdown flush error: %s" % exc, 3)

    # ---- main loop ----

    def _run(self) -> None:
        """Main drainer loop. Polls SQLite + uploads batches with backoff."""
        last_flush = time.time()
        try:
            while not self._should_stop():
                # Wait briefly between checks (poll-based to honor abort)
                if self._wait(2.0):
                    break

                # Backoff after failure
                now = time.time()
                if now < self._next_attempt_unix:
                    continue

                # Periodic prune (nightly maintenance)
                if now - self._last_prune_unix > _PRUNE_INTERVAL:
                    try:
                        deleted = self._buffer.prune()
                        if deleted:
                            _log("Prune: %d old rows removed" % deleted)
                    except Exception as exc:
                        _log("Prune error: %s" % exc, 3)
                    self._last_prune_unix = now

                # Fetch + upload
                # 3.5.120 POŘADÍ JE ZÁMĚRNÉ: nejdřív zjisti, jestli vůbec něco čeká,
                # a teprve pak řeš identitu. Do 3.5.119 se ptalo obráceně a `continue`
                # při prázdném jménu znamenalo, že se smyčka věčně točí naprázdno,
                # tváří se živá a NIKDY nikomu neřekne, že nic neodesílá
                # (incident bandog: 15 h ticha při běžícím addonu).
                rows = self._buffer.fetch_unsent(limit=self._batch_size)
                if not rows:
                    last_flush = now
                    continue

                if not self._identity_or_report(len(rows)):
                    continue
                # 3.5.140 (cross-check T2): po autoritativním zamítnutí identity (403 s Gate
                # kódem) se neposílá nic — stav, ne počítadlo; zotavení = `/auth` z pluginu.
                if not self._identity_allowed():
                    continue

                # Apply periodic flush logic — if not enough rows + recent flush,
                # wait for accumulation (saves bandwidth + roundtrips)
                if len(rows) < 10 and (now - last_flush) < self._flush_interval:
                    continue

                ok, status = self._upload_batch(rows)
                if ok:
                    self._buffer.mark_sent([r["id"] for r in rows])
                    last_flush = now
                    self._last_success_unix = time.time()  # vstup do diagnostiky
                    self._reset_backoff()
                else:
                    self._buffer.increment_retry([r["id"] for r in rows])
                    self._apply_backoff(status, self._last_retry_after)
        except Exception as exc:
            # 4 = LOGERROR. Pád smyčky znamená, že drainer je od téhle chvíle mrtvý
            # a nikdo už logy neodešle — musí to být v kodi.log vidět jako ERROR.
            _log("Drainer loop crashed: %s" % exc, 4)

    # ---- helpers ----

    def _should_stop(self) -> bool:
        if self._stop_event.is_set():
            return True
        if self._monitor is not None:
            try:
                if self._monitor.abortRequested():
                    return True
            except Exception:
                pass
        return False

    def _wait(self, seconds: float) -> bool:
        """Sleep cooperatively (interruptible by stop). Returns True if stop signaled."""
        if self._monitor is not None:
            try:
                return bool(self._monitor.waitForAbort(seconds))
            except Exception:
                pass
        return self._stop_event.wait(seconds)

    def _reset_backoff(self) -> None:
        with self._lock:
            self._backoff_seconds = _INITIAL_BACKOFF
            self._next_attempt_unix = 0.0

    def _identity_allowed(self) -> bool:
        try:
            import richmovie_identity_state as _ident
            allowed = bool(_ident.allow_gate_request())
        except Exception:
            return True
        if not allowed:
            now = time.time()
            if now - self._last_identity_block_log > 600:
                self._last_identity_block_log = now
                _log("identity REJECTED/missing → upload paused until /auth recovers (buffer kept)", 2)
        return allowed

    def _apply_backoff(self, status_code: int, retry_after_s: Optional[float] = None) -> None:
        with self._lock:
            # Exponential backoff capped at _MAX_BACKOFF
            delay = self._backoff_seconds
            if status_code == 429:
                # 429 = JEDEN odklad podle `Retry-After` (min 30 s), žádné zdvojení dávky —
                # pravidlo „429 nikdy neopakovat" míří na amplifikaci, ne na odložené
                # doručení durable logů; Retry-After se dřív jen slibovalo v komentáři.
                delay = max(delay, 30.0, float(retry_after_s or 0))
            self._next_attempt_unix = time.time() + delay
            self._backoff_seconds = min(self._backoff_seconds * 2, _MAX_BACKOFF)
            _log("Backoff %ds (next attempt at %s)" % (
                delay, time.strftime("%H:%M:%S",
                                     time.localtime(self._next_attempt_unix))), 2)

    # ---- HTTP upload ----

    def _upload_batch(
        self,
        rows: list[dict[str, Any]],
        timeout_override: float | None = None,
    ) -> tuple[bool, int]:
        """POST batch to Gate. Returns (success, http_status).

        Failure modes treated as retryable: connection error, timeout, 5xx,
        429 (jeden odklad podle Retry-After). 401/403 s Gate JSON kódem = autoritativní
        zamítnutí identity → `identity_state` (jediný klasifikátor) přepne REJECTED a
        smyčka se zastaví na stavu (`_identity_allowed`), ne na počítadle. Ostatní 4xx
        (HTML od Cloudflare, dočasný routing) = retryable s backoffem; cap přes retry_count.
        Success: 2xx (typically 202 Accepted from server).
        """
        gate_url = self._get_gate_url()
        if not gate_url:
            _log("gate url unavailable, %d events pending" % len(rows), 2)
            return False, 0

        # 3.5.120: poslední ze tří míst, kde se dřív mlčky odcházelo.
        # Volající (`_run`, `shutdown_flush`) už identitu ověřil, takže sem se
        # normálně nedojde — ale kdyby ano, musí to být slyšet, ne tiché False.
        ws_username = self._identity_or_report(len(rows))
        if not ws_username:
            return False, 0

        # Pick session_id from first row (all rows in a batch share one ideally,
        # but defensive: use first row's session_id, plain UUID fallback)
        session_id = rows[0].get("session_id") or str(uuid.uuid4())

        # Build payload
        events = []
        for r in rows:
            ctx = {}
            ctx_json = r.get("context_json")
            if ctx_json:
                try:
                    ctx = json.loads(ctx_json)
                    if not isinstance(ctx, dict):
                        ctx = {"_raw": ctx}
                except Exception:
                    ctx = {"_parse_error": True, "raw": ctx_json[:200]}
            ev = {
                "client_event_id": r["client_event_id"],
                "ts_client": _format_iso_utc(r["ts_unix"]),
                "level": r["level"],
                "source": r["source"],
                "message": r["message"],
                "context": ctx,
            }
            # Φ0 (29.09.2026): session_id KAŽDÉ události = id invokace (sub-interpretu),
            # který ji zapsal. Dávka míchá řádky víc invokací a služby; hlavička dávky
            # nese jen id prvního řádku, takže `user_logs.session_id` dřív neidentifikoval
            # invokaci (audity A03 F9, A08 F12: falešné „ocasy“ 20–97 s). Gate od 29.09.
            # bere id z události, starší Gate klíč ignoruje (extra pole Pydantic).
            _ev_sid = r.get("session_id") or ""
            if len(_ev_sid) >= 8:
                ev["session_id"] = _ev_sid
            events.append(ev)

        body = {
            "ws_username": ws_username,
            "session_id": session_id,
            "addon_version": self._addon_version,
            "platform": self._platform,
            "kodi_version": self._kodi_version,
            "device_hash": self._device_hash,
            "events": events,
        }

        # 3.5.121: doložení identity. Server přijme i bez něj (uzná zařízení
        # podle `device_hash`), ale s proof je zápis plně důvěryhodný — a až
        # bude proof posílat celý fleet, dá se vynucení utáhnout.
        # Chybějící proof se ZÁMĚRNĚ nevkládá jako prázdný řetězec: server
        # rozlišuje „neposláno" od „posláno špatně".
        try:
            import richmovie_gate_transport as _gt
            _ws_user, _ws_proof = _gt.get_identity()
            if _ws_proof:
                body["ws_proof"] = _ws_proof
        except Exception as exc:
            _log("proof pro batch nedostupný (posílám bez něj): %r" % (exc,), 2)

        try:
            payload = json.dumps(body, ensure_ascii=False, default=str).encode("utf-8")
            gz_payload = gzip.compress(payload, compresslevel=6)
        except Exception as exc:
            _log("Payload encode error: %s" % exc, 4)
            return False, 0

        # Body size enforcement (defense before network)
        if len(gz_payload) > 256 * 1024:
            _log("Batch oversize after gzip: %d bytes — splitting" % len(gz_payload), 2)
            # Drainer doesn't auto-split; treat as failure so retry will halve
            # via smaller batch_size next iter. For now mark as fail.
            return False, 0

        url = gate_url.rstrip("/") + "/v1/user_logs/batch"
        timeout = timeout_override if timeout_override is not None else _HTTP_READ_TIMEOUT
        connect_timeout = min(timeout, _HTTP_CONNECT_TIMEOUT)

        try:
            req = urllib.request.Request(
                url,
                data=gz_payload,
                headers={
                    "Content-Type": "application/json",
                    "Content-Encoding": "gzip",
                    "User-Agent": f"RichMovie/{self._addon_version} (LogDrain)",
                    "X-Idempotency-Batch": str(uuid.uuid4()),
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                status = resp.getcode()
                if 200 <= status < 300:
                    return True, status
                return False, status
        except urllib.error.HTTPError as http_err:
            self._last_retry_after = None
            try:
                ra = http_err.headers.get("Retry-After") if http_err.headers else None
                if ra and str(ra).strip().isdigit():
                    self._last_retry_after = float(ra)
            except Exception:
                pass
            if http_err.code in (401, 403):
                # autoritativní zamítnutí identity → jediný SSOT klasifikátor (stejný hook
                # jako gate_transport / tmdb_client / bundle fetch)
                try:
                    import richmovie_identity_state as _ident
                    raw_body = b""
                    try:
                        raw_body = http_err.read(4096)
                    except Exception:
                        pass
                    parsed = None
                    try:
                        parsed = json.loads(raw_body.decode("utf-8")) if raw_body else None
                    except Exception:
                        parsed = None
                    _ident.observe_gate_response(http_err.code, parsed, bool(body.get("ws_proof")))
                except Exception:
                    pass
            return False, http_err.code
        except (urllib.error.URLError, OSError) as net_err:
            _log("Network error: %s" % net_err, 2)
            return False, 0
        except Exception as exc:
            _log("Upload exception: %s" % exc, 3)
            return False, 0


def _format_iso_utc(ts_unix: float) -> str:
    """ISO 8601 UTC string with microseconds — matches Pydantic datetime parser."""
    import datetime as _dt
    return _dt.datetime.utcfromtimestamp(ts_unix).isoformat() + "Z"
