# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_still_watching — dialog „Díváš se ještě?" (4.0.3, plán PLAN_watched_progress_integrity §3.3)
───────────────────────────────────────────────────────────────────────────────
Jediné místo, kde se služba ptá diváka u řetězu autoplaye (`service_nextup._attention_gate`).

PROČ VLASTNÍ OKNO (incident 06.10.2026, divačka u Ledové archy): Kodi `Dialog().yesno` vrací při vypršení
odpočtu totéž co „Ne“ (`GUIDialog.cpp` autoclose nastaví jen `m_bAutoClosed`, `GUIDialogYesNo::GetResult`
ho nečte) — služba proto nerozeznala člověka, který řekl „Skončit“, od spícího diváka a oba potrestala:
díl „⏾ neviděno“ + Pokračovat zpět. Tohle okno má výsledek deterministický:
    RESULT_CONTINUE  „▶ Pokračovat“ (výchozí fokus — stačí jednou OK)
    RESULT_STOP      „Dnes už končím“ nebo Zpět (člověk je tu, jen nechce další díl)
    RESULT_TIMEOUT   odpočet doběhl bez jediného stisku = prokázaný spánek (verdikt spánku)
    RESULT_ABORT     Kodi se vypíná (řetěz dořeší start služby)
Když okno/skin chybí, záložní `yesno` + `richmovie_attention.classify_dialog_fallback` (doba otevření
+ nečinnost — dotyk na telefonu nečinnost Kodi nenuluje, proto rozhoduje i čas zavření).

Vzhled: fotka seriálu přes celou obrazovku pod tmavým závojem, plakát, velká otázka, co se pustí dál,
pravdivá věta o tom, co se stane bez odpovědi, dvě velká tlačítka a ubývající proužek odpočtu.
Python 3.8 (Kodi).
"""

from __future__ import annotations

import threading
import time
from typing import Dict

import xbmc
import xbmcaddon
import xbmcgui

import richmovie_attention as _att

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.still_watching", "RichMovie/StillWatching")
except Exception:  # pragma: no cover
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        xbmc.log("[RichMovie/StillWatching] %s" % msg, level)

_XML = "RichMovieStillWatching.xml"
_RES = "1080i"
_BTN_CONTINUE = 9501
_BTN_STOP = 9502
_PROGRESS = 9510
_TICK_S = 0.5

RESULT_CONTINUE = _att.ANSWER_CONTINUE
RESULT_STOP = _att.ANSWER_STOP
RESULT_TIMEOUT = _att.ANSWER_TIMEOUT
RESULT_ABORT = _att.ANSWER_ABORT
CHOICE_PRIMARY = "primary"       # levé (výchozí) tlačítko volby
CHOICE_SECONDARY = "secondary"   # pravé tlačítko volby
CHOICE_CANCEL = "cancel"         # Zpět = nic


class StillWatchingWindow(xbmcgui.WindowXMLDialog):
    """Výsledek `result`: RESULT_*; dokud nikdo nic nezmáčkl, platí RESULT_TIMEOUT."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.result = RESULT_TIMEOUT
        self.texts: Dict[str, str] = {}
        self._closed = threading.Event()

    def onInit(self) -> None:
        for key, value in self.texts.items():
            self.setProperty(key, value)
        self.set_remaining(1.0, self.texts.get("rm_sw_countdown", ""))

    def set_remaining(self, fraction: float, label: str) -> None:
        self.setProperty("rm_sw_countdown", label)
        try:
            self.getControl(_PROGRESS).setPercent(max(0.0, min(100.0, float(fraction) * 100.0)))
        except Exception:
            pass   # skin bez proužku: odpočet nese text

    def onClick(self, control_id: int) -> None:
        if control_id == _BTN_CONTINUE:
            self._finish(RESULT_CONTINUE)
        elif control_id == _BTN_STOP:
            self._finish(RESULT_STOP)

    def onAction(self, action) -> None:
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self._finish(RESULT_STOP)   # Zpět zmáčkl člověk = je tu, jen nechce další díl

    def _finish(self, result: str) -> None:
        if self._closed.is_set():
            return
        self.result = result
        self._closed.set()
        self.close()

    def close_with(self, result: str) -> None:
        self._finish(result)


class ChoiceWindow(StillWatchingWindow):
    """Stejné okno jako dotaz, ale volba bez odpočtu (proužek se skryje): levé / pravé tlačítko / Zpět = nic.
    Volba po spánku v Pokračovat (D3, audit Fable A-V8 — dřív holý systémový seznam uprostřed příběhu)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.result = CHOICE_CANCEL

    def onInit(self) -> None:
        for key, value in self.texts.items():
            self.setProperty(key, value)
        self.setProperty("rm_sw_countdown", "")

    def onClick(self, control_id: int) -> None:
        if control_id == _BTN_CONTINUE:
            self._finish(CHOICE_PRIMARY)
        elif control_id == _BTN_STOP:
            self._finish(CHOICE_SECONDARY)

    def onAction(self, action) -> None:
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self._finish(CHOICE_CANCEL)


def ask_choice(*, question: str, series: str, detail: str, why: str, promise: str, primary: str, secondary: str,
               poster: str = "", fanart: str = "") -> str:
    """Volba dvou cest ve vzhledu dotazu „Díváš se ještě?“. Vrací CHOICE_*. Bez okna/skinu = systémový seznam."""
    try:
        win = ChoiceWindow(_XML, xbmcaddon.Addon().getAddonInfo("path"), "default", _RES)
    except Exception as exc:
        _log("choice window failed (%r) → fallback select" % (exc,), xbmc.LOGWARNING)
        idx = xbmcgui.Dialog().select("%s · %s" % (question, series), [primary, secondary])
        return {0: CHOICE_PRIMARY, 1: CHOICE_SECONDARY}.get(idx, CHOICE_CANCEL)
    win.texts = {"rm_sw_question": question, "rm_sw_series": series or "", "rm_sw_next": detail or "",
                 "rm_sw_why": why or "", "rm_sw_promise": promise or "", "rm_sw_continue": primary,
                 "rm_sw_stop": secondary, "rm_sw_countdown": "", "rm_sw_poster": poster or "",
                 "rm_sw_fanart": fanart or ""}
    win.doModal()
    result = str(win.result)
    del win
    return result


def _countdown_text(left_s: float) -> str:
    return "Bez odpovědi za %d s přehrávání zastavím" % max(0, int(round(left_s)))


def _texts(*, series: str, next_label: str, streak: int, idle_min: int, poster: str, fanart: str,
           timeout_s: float) -> Dict[str, str]:
    why = (("Přehrály se %d díly, aniž by někdo sáhl na ovladač." % streak) if streak >= 2 else
           ("Už %d minut nikdo nesáhl na ovladač." % idle_min if idle_min > 0 else "Dlouho nikdo nesáhl na ovladač."))
    return {
        "rm_sw_question": "Díváš se ještě?",
        "rm_sw_series": series or "",
        "rm_sw_next": ("Další díl · %s" % next_label) if next_label else "Další díl",
        "rm_sw_why": why,
        "rm_sw_promise": "Když neodpovíš, díly, které běžely bez tebe, označím ⏾ a v Pokračovat na tebe počkají.",
        "rm_sw_continue": "▶  Pokračovat",
        "rm_sw_stop": "Dnes už končím",
        "rm_sw_countdown": _countdown_text(timeout_s),
        "rm_sw_poster": poster or "",
        "rm_sw_fanart": fanart or "",
    }


def ask(*, series: str, next_label: str, streak: int, idle_min: int, poster: str = "", fanart: str = "",
        timeout_s: float = _att.DEFAULT_ASK_TIMEOUT_S) -> str:
    """Zobrazí dialog modálně (volat z vlákna mimo callbacky Kodi). Vrací RESULT_*."""
    timeout_s = max(1.0, float(timeout_s))
    try:
        win = StillWatchingWindow(_XML, xbmcaddon.Addon().getAddonInfo("path"), "default", _RES)
    except Exception as exc:
        _log("still watching window failed (%r) → fallback yesno" % (exc,), xbmc.LOGWARNING)
        return _ask_fallback(series=series, next_label=next_label, streak=streak, idle_min=idle_min,
                             timeout_s=timeout_s)
    win.texts = _texts(series=series, next_label=next_label, streak=streak, idle_min=idle_min,
                       poster=poster, fanart=fanart, timeout_s=timeout_s)
    closed = threading.Event()

    def _timer() -> None:
        mon = xbmc.Monitor()
        deadline = time.monotonic() + timeout_s
        while not closed.is_set():
            if mon.waitForAbort(_TICK_S):
                win.close_with(RESULT_ABORT)   # modál nesmí držet Kodi do force-kill (5s okno)
                return
            left = deadline - time.monotonic()
            if left <= 0:
                win.close_with(RESULT_TIMEOUT)
                return
            win.set_remaining(left / timeout_s, _countdown_text(left))

    threading.Thread(target=_timer, name="RMStillWatchingTimer", daemon=True).start()
    try:
        win.doModal()
    finally:
        closed.set()
    return str(win.result)


def _ask_fallback(*, series: str, next_label: str, streak: int, idle_min: int, timeout_s: float) -> str:
    texts = _texts(series=series, next_label=next_label, streak=streak, idle_min=idle_min, poster="", fanart="",
                   timeout_s=timeout_s)
    started = time.monotonic()
    try:
        confirmed = bool(xbmcgui.Dialog().yesno(
            texts["rm_sw_question"], "%s\n%s\n%s" % (texts["rm_sw_next"], texts["rm_sw_why"], texts["rm_sw_promise"]),
            nolabel=texts["rm_sw_stop"], yeslabel="Pokračovat", autoclose=int(timeout_s * 1000)))
    except TypeError:
        # dotaz se vůbec nezobrazil → žádný důkaz spánku: konec řetězu BEZ ⏾ (cross-check Codex C7 10.10.2026;
        # dřív RESULT_TIMEOUT = verdikt spánku bez jediné otázky)
        _log("fallback yesno bez autoclose → konec řetězu bez dotazu (bez ⏾)", xbmc.LOGWARNING)
        return RESULT_STOP
    if xbmc.Monitor().abortRequested():
        return RESULT_ABORT
    try:
        idle_s = float(xbmc.getGlobalIdleTime())
    except Exception:
        idle_s = float("inf")
    return _att.classify_dialog_fallback(confirmed, time.monotonic() - started, timeout_s, idle_s)
