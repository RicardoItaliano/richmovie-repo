# -*- coding: utf-8 -*-
"""
RichMovie – MediaInfo Second Edition (lazy doplňování CZ dabing / titulky)

Poznámka:
  Tento modul běží asynchronně (thread) a publikuje výsledky do richmovie_engine
  přes `_eng.mi2_publish()`.
"""

from __future__ import annotations

# ──────────────  STANDARD LIBRARY  ──────────────
from collections import deque

import hashlib
import threading
import time
import urllib.parse
from typing import Callable, Deque, Sequence, TYPE_CHECKING

# ──────────────  KODI API  ──────────────
import xbmc
import xbmcgui

# ──────────────  LOCAL MODULES  ──────────────
import richmovie_engine as _eng
from richmovie_webshare import WebshareClient

# 2026-04-19 – Phase 3b.5: crowdsourced MediaInfo cache via Gate
# (bulk pre-fetch before probing, publish canonical payload after probing).
# Best-effort — legacy local-only behavior is the fallback on any failure.
import richmovie_mediainfo_client as _mi_gate

# 3.5.118 (2026-08-21): typované selhání probe. Gate 403/5xx/offline NENÍ
# vlastnost souboru → žádný fail marker (R2 plánu). Viz `_classify_probe_failure`.
from richmovie_gate_transport import (GateAuthError, GateNotMediaError, GateProbeError,
                                      is_media_payload as _is_media_payload)
import richmovie_netstate as _netstate
import richmovie_listing as _listing
# 4.0.1: závěrečný refresh jen přes bránu dispatcheru (ne během startu přehrávání — pád Kodi 09.10.2026)
import richmovie_playback_dispatch as _rm_dispatch
import richmovie_activity as _rm_activity   # 4.0.1 (audit Fable F-1): aktivní divák → počkat na klid, ne zahodit
try:
    import richmovie_http as _rm_http
except Exception:  # pragma: no cover
    _rm_http = None  # type: ignore

# 22.01.2026 – TYPE_CHECKING import pro Fastshare (aby se vyhnulo cirkulární závislosti)
if TYPE_CHECKING:
    from richmovie_fastshare import FastshareClient



# 2026-07-01 (observability program): MI2 logování přepnuto z local-only
# xbmc.log na ROUTOVANÝ logger přes richmovie_logging pipeline → MI2 logy (včetně
# PROBE_ERR / PUBLISH_ERR / GATE_*_WARN) nově tečou na NAS (Gate), dřív byly jen
# v lokálním kodi.log. Signatura zpětně kompatibilní: `_log(msg)` = INFO (default),
# error/warn call sites nově předávají level (xbmc.LOGWARNING/LOGERROR).
try:
    from richmovie_logging import make_legacy_logger as _mi2_make_legacy_logger
    _log = _mi2_make_legacy_logger("richmovie.mi2", "RichMovie/MI2")
except Exception:
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        """Fallback (pipeline nedostupná): přímý zápis do kodi.log."""
        try:
            xbmc.log(f"[RichMovie/MI2] {msg}", level)
        except Exception:
            pass


# =========================================================================== #
# Gate MI-cache adapters (Phase 3b.5 — 2026-04-19)
# ---------------------------------------------------------------------------
# Two-way mapping between:
#   (a) `mi` dict returned by WebshareClient/FastshareClient.probe_mediainfo()
#       — shape: {"duration": sec, "tracks": [<pymediainfo t.to_data() dict>]}
#   (b) Gate's canonical MediaInfoPayload schema
#       — shape: {"container", "duration_sec", "size_bytes",
#                 "video":{codec,width,height,…},
#                 "audio":[{codec,lang,channels,…}],
#                 "subtitles":[{codec,lang,forced,…}]}
#   (c) flags dict consumed by _eng.mi2_publish()
#       — shape: aud_langs, sub_langs, sub_present, video_w/h, duration_s
#
# Keeping the adapters at module level (not nested inside _worker) makes them
# unit-testable and shareable with a future dashboard / repair tooling.
# =========================================================================== #

# Důvod negativního markeru pro odkaz, který autoritativně nevydal médium
# (3.5.129). Politika retry: `richmovie_engine._MI2_RETRY_POLICY["not_media"]`.
FAIL_REASON_NOT_MEDIA = "not_media"


def _classify_probe_failure(exc: BaseException) -> str | None:
    """3.5.118: rozhodne podle TYPU výjimky (ne textu), zda selhání probe patří
    do negativní cache. Vrací `fail_reason` pro `mi2_publish`, nebo None =
    NEPERZISTOVAT (stav infrastruktury, ne vlastnost souboru).

        GateAuthError          → None  (identita zamítnuta; další probe fail-fastne)
        GateNotMediaError      → "not_media" (3.5.129: odkaz autoritativně nevydal
                                  médium — HTML stránka Free účtu / CDN 4xx; vlastnost
                                  ODKAZU, krátké TTL, nikdy sdílená cache)
        GateProbeError         → None  (Gate 5xx / 429)
        OfflineError / offline → None  (síť je pryč; žádný soubor za to nemůže)
        TransientError online  → "timeout" (existující policy 1h→2h→4h…; pomalé
                                  CDN bývá per-soubor, backoff má smysl)
        cokoli jiného          → "error" (existující policy)

    Do 3.5.117: `"timeout" if "timeout" in str(e).lower() else "error"` + 403 z
    Gate přišel jako `None` → marker `empty` (1 d → 3 d → permanent). Auth chyba
    byla zaměněna za „soubor nemá metadata" (K4 auditu plánu 3.5.118).
    """
    if isinstance(exc, GateAuthError):
        return None
    if isinstance(exc, GateNotMediaError):
        # Podtřída GateProbeError — MUSÍ být před obecnou větví.
        return FAIL_REASON_NOT_MEDIA
    if isinstance(exc, GateProbeError):
        return None
    try:
        if _netstate.is_offline():
            return None
    except Exception:
        pass
    if _rm_http is not None:
        if isinstance(exc, _rm_http.OfflineError):
            return None
        if isinstance(exc, _rm_http.TransientError):
            return "timeout"
    return "error"


def _mi_norm_lang(code) -> str:
    """Normalize ISO lang code — same rules as the inner _worker helper."""
    c = str(code or "").strip().lower()
    if len(c) > 3:
        c = c[:3]
    if c in ("cz", "cs", "ces", "cze"):
        return "cs"
    if c in ("en", "eng"):
        return "en"
    if c in ("sk", "slo", "slk"):
        return "sk"
    return c or ""


def _mi_to_int(v):
    """Best-effort int coercion; returns None for zero/neg/garbage."""
    try:
        if v is None:
            return None
        if isinstance(v, bool):
            return None
        if isinstance(v, (int, float)):
            iv = int(v)
            return iv if iv > 0 else None
        s = str(v).strip()
        if not s:
            return None
        digits = "".join(ch for ch in s if ch.isdigit())
        if not digits:
            return None
        iv = int(digits)
        return iv if iv > 0 else None
    except Exception:
        return None


def _mi_to_float(v):
    """Best-effort float coercion; returns None for non-positive/garbage."""
    try:
        if v is None:
            return None
        if isinstance(v, bool):
            return None
        f = float(v)
        return f if f > 0 else None
    except Exception:
        try:
            s = str(v).strip().replace(",", ".")
            f = float(s)
            return f if f > 0 else None
        except Exception:
            return None


# Container-format normalization (pymediainfo General.format → canonical tag).
_CONTAINER_MAP = {
    "matroska": "mkv",
    "mpeg-4": "mp4",
    "mpeg4": "mp4",
    "avi": "avi",
    "webm": "webm",
    "quicktime": "mov",
    "flash video": "flv",
    "mpeg-ts": "ts",
    "mpeg-ps": "ps",
    "windows media": "wmv",
    "asf": "wmv",
    "ogg": "ogg",
}

# Video codec normalization.
_VIDEO_CODEC_MAP = {
    "avc": "h264",
    "mpeg-4 visual": "xvid",
    "hevc": "h265",
    "vp9": "vp9",
    "av1": "av1",
    "vc-1": "vc1",
}

# Audio codec normalization.
_AUDIO_CODEC_MAP = {
    "ac-3": "ac3",
    "e-ac-3": "eac3",
    "dts": "dts",
    "aac": "aac",
    "mpeg audio": "mp3",
    "flac": "flac",
    "opus": "opus",
    "pcm": "pcm",
    "truehd": "truehd",
}


def _norm_codec(raw, mapping: dict) -> str:
    s = str(raw or "").strip().lower()
    if not s:
        return ""
    if s in mapping:
        return mapping[s]
    # Generic cleanup: drop dashes/spaces ("E-AC-3" already handled above;
    # fallthrough catches any vendor-specific strings we haven't mapped).
    return s.replace("-", "").replace(" ", "")


def _norm_container(raw) -> str:
    s = str(raw or "").strip().lower()
    if not s:
        return ""
    if s in _CONTAINER_MAP:
        return _CONTAINER_MAP[s]
    # Pass through short, alphanumeric tags as-is (e.g. 'mp4').
    compact = s.replace(" ", "")
    if compact.isalnum() and 2 <= len(compact) <= 8:
        return compact
    return ""


def _yes_no(raw) -> bool:
    """pymediainfo booleans come back as 'Yes'/'No'/bool/int."""
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, (int, float)):
        return bool(raw)
    s = str(raw or "").strip().lower()
    return s in ("yes", "true", "1", "y")


def _mi_to_canonical(mi: dict) -> dict:
    """Raw probe dict → Gate canonical MediaInfoPayload shape.

    Returns {} if the raw MI has no General/Video track — in that case we
    don't POST (the server would reject due to `container` being mandatory).
    """
    if not isinstance(mi, dict):
        return {}

    tracks = mi.get("tracks") or []
    if not isinstance(tracks, list) or not tracks:
        return {}

    container = ""
    size_bytes = None
    duration_sec = _mi_to_int(mi.get("duration"))

    video_out = None
    audio_out = []  # type: list
    subs_out = []   # type: list

    for t in tracks:
        if not isinstance(t, dict):
            continue
        t_type = str(t.get("track_type") or t.get("@type") or "").strip().lower()

        if t_type == "general":
            if not container:
                container = _norm_container(t.get("format"))
            if size_bytes is None:
                size_bytes = _mi_to_int(
                    t.get("file_size") or t.get("file_size_in_bytes")
                )
            if duration_sec is None:
                # General.duration is usually in ms via pymediainfo.
                dur_ms = _mi_to_int(t.get("duration"))
                if dur_ms:
                    duration_sec = int(dur_ms // 1000) if dur_ms > 10_000 else dur_ms

        elif t_type == "video":
            if video_out is None:
                codec = _norm_codec(
                    t.get("format") or t.get("codec_id") or "", _VIDEO_CODEC_MAP,
                )
                if codec:
                    vi = {"codec": codec}
                    w = _mi_to_int(t.get("width") or t.get("Width"))
                    h = _mi_to_int(t.get("height") or t.get("Height"))
                    if w:
                        vi["width"] = w
                    if h:
                        vi["height"] = h
                    br = _mi_to_int(t.get("bit_rate"))
                    if br:
                        vi["bitrate_kbps"] = int(br // 1000) if br > 1000 else br
                    fps = _mi_to_float(t.get("frame_rate"))
                    if fps:
                        vi["fps"] = round(fps, 3)
                    hdr = (t.get("hdr_format") or t.get("hdr_format_string")
                           or t.get("color_primaries") or "")
                    hdr_s = str(hdr or "").strip()
                    if hdr_s:
                        low = hdr_s.lower()
                        if "dolby" in low or "dovi" in low:
                            vi["hdr"] = "DOVI"
                        elif "hdr10+" in low:
                            vi["hdr"] = "HDR10+"
                        elif "hdr10" in low:
                            vi["hdr"] = "HDR10"
                        elif "hlg" in low:
                            vi["hdr"] = "HLG"
                    # Noc 03.11.2026 (Φ3): kanonické klíče z Gate (legacy tvar `gate_payload_to_legacy_mi`) projdou beze ztráty
                    if not vi.get("hdr") and t.get("hdr"):
                        vi["hdr"] = str(t.get("hdr"))[:30]
                    if t.get("dv_profile") is not None:
                        _dvp = _mi_to_int(t.get("dv_profile"))
                        if _dvp is not None:
                            vi["dv_profile"] = _dvp
                    if t.get("dv_compat"):
                        vi["dv_compat"] = str(t.get("dv_compat"))[:12]
                    video_out = vi

        elif t_type == "audio":
            codec = _norm_codec(
                t.get("format") or t.get("codec_id") or "", _AUDIO_CODEC_MAP,
            )
            if not codec:
                continue
            a = {"codec": codec}
            lang = _mi_norm_lang(t.get("language") or t.get("Language"))
            if lang:
                a["lang"] = lang
            ch = _mi_to_int(t.get("channel_s") or t.get("channel(s)")
                            or t.get("channels"))
            if ch:
                a["channels"] = ch
            br = _mi_to_int(t.get("bit_rate"))
            if br:
                a["bitrate_kbps"] = int(br // 1000) if br > 1000 else br
            title = str(t.get("title") or "").strip()
            if title:
                a["title"] = title[:200]
            if t.get("default") is not None:
                a["default"] = _yes_no(t.get("default"))
            if t.get("forced") is not None:
                a["forced"] = _yes_no(t.get("forced"))
            audio_out.append(a)

        elif t_type in ("text", "subtitle"):
            codec = _norm_codec(
                t.get("format") or t.get("codec_id") or "", {},
            )
            # SRT often shows as 'UTF-8' etc.; keep even if unmappable.
            if not codec:
                codec = (str(t.get("format") or "").strip().lower()
                         .replace("-", "").replace(" ", "")) or "sub"
            s = {"codec": codec}
            lang = _mi_norm_lang(t.get("language") or t.get("Language"))
            if lang:
                s["lang"] = lang
            title = str(t.get("title") or "").strip()
            if title:
                s["title"] = title[:200]
            if t.get("forced") is not None:
                s["forced"] = _yes_no(t.get("forced"))
            subs_out.append(s)

    # Default container if General didn't declare one: infer from video codec
    # presence (most Webshare uploads are .mkv if they have multi-audio).
    if not container and video_out:
        container = "mkv" if len(audio_out) > 1 else "mp4"
    if not container:
        return {}

    out = {"container": container}  # type: dict
    if duration_sec:
        out["duration_sec"] = int(duration_sec)
    if size_bytes:
        out["size_bytes"] = int(size_bytes)
    if video_out:
        out["video"] = video_out
    if audio_out:
        out["audio"] = audio_out
    if subs_out:
        out["subtitles"] = subs_out
    return out


def _canonical_to_engine_hints(payload: dict) -> dict | None:
    """Gate canonical MediaInfoPayload → kwargs for _eng.mi2_publish().

    Returned dict has keys: aud_langs, sub_langs, sub_present, video_w,
    video_h, duration_s. Safe to **unpack into mi2_publish.

    3.5.129: vrací None, když payload NENÍ médium (`gate_transport.is_media_payload`
    — prázdný obal `container=unknown` bez tracků a bez délky = otisk HTML stránky,
    incident PeterFM 02.09.2026). Takový HIT se NEAPLIKUJE: dřív z něj vzniklo
    `sub_present=False` („titulky prokazatelně nejsou") a ident se už neprobovala.
    Gate takové řádky od 02.09.2026 neukládá a uklidil je; tohle je obrana pro
    starší hity v lokální disk cache i pro jakýkoli budoucí regres na serveru.
    """
    if not _is_media_payload(payload):
        return None
    aud = []  # type: list
    for a in (payload.get("audio") or []):
        if not isinstance(a, dict):
            continue
        lang = _mi_norm_lang(a.get("lang"))
        if lang and lang not in aud:
            aud.append(lang)

    subs_list = payload.get("subtitles") or []
    sub = []  # type: list
    for s in subs_list:
        if not isinstance(s, dict):
            continue
        lang = _mi_norm_lang(s.get("lang"))
        if lang and lang not in sub:
            sub.append(lang)

    # Presence semantics: Gate only stores verified probe results, so an
    # empty subtitles list is an authoritative "no subs here". Match the
    # original probe's `saw_any_text_track` contract.
    sub_present_val = True if subs_list else False

    video = payload.get("video") if isinstance(payload.get("video"), dict) else None
    vw = _mi_to_int(video.get("width")) if video else None
    vh = _mi_to_int(video.get("height")) if video else None

    return {
        "aud_langs": aud,
        "sub_langs": sub,
        "sub_present": sub_present_val,
        "video_w": vw,
        "video_h": vh,
        "duration_s": _mi_to_int(payload.get("duration_sec")),
        # Noc 03.11.2026 (Φ3): Dolby Vision — Gate `VideoInfo.hdr` (+ `dv_profile`/`dv_compat` od mig-less schématu 4.0.6)
        "hdr": (video.get("hdr") if video else None) or None,
        "dv_profile": _mi_to_int(video.get("dv_profile")) if video and video.get("dv_profile") is not None else None,
        "dv_compat": (video.get("dv_compat") if video else None) or None,
    }


def _gate_prefetch_into_engine(idents: Sequence[str]) -> int:
    """Bulk-lookup idents on Gate and publish each hit into the engine cache.

    Returns count of hits (idents that were prepopulated). Called from
    _worker() before the probe loop starts; a hit means the probe loop's
    cache-first gate (_eng.mi2_get_flags) will short-circuit that ident
    naturally — no extra bookkeeping needed in the pending queue.

    Never raises — on any failure returns 0 so the worker continues probing
    as if Gate were absent (pre-3.0.0-beta.2 behavior).
    """
    try:
        if not idents:
            return 0

        # Build (source, source_ident) pairs, skipping empties / garbage.
        keys = []  # type: list
        ident_by_key = {}  # type: dict
        for ident in idents:
            pair = _mi_gate.ident_to_key(ident)
            if pair is None:
                continue
            composite = "%s:%s" % pair
            keys.append(pair)
            ident_by_key[composite] = str(ident)

        if not keys:
            return 0

        hits = _mi_gate.bulk_lookup(keys)
        if not hits:
            return 0

        applied = 0
        for composite, payload in hits.items():
            ident = ident_by_key.get(composite)
            if not ident or not isinstance(payload, dict):
                continue
            try:
                hints = _canonical_to_engine_hints(payload)
                if hints is None:
                    # 3.5.129: HIT bez tracků a délky = otisk HTML stránky
                    # (incident PeterFM). Neaplikovat → ident zůstává
                    # „neprobováno" a proba proběhne normálně.
                    _log(f"GATE_HIT_REJECT ident={ident} reason=not_media "
                         f"container={payload.get('container')!r}", xbmc.LOGWARNING)
                    continue
                _eng.mi2_publish(ident, **hints)
                applied += 1
            except Exception as exc:
                _log(f"GATE_APPLY_WARN ident={ident} err={exc}", xbmc.LOGWARNING)

        # Persist the batch so a concurrent Container.Refresh sees the hints.
        if applied > 0:
            try:
                _eng.mi2_flush_disk(force=True)
            except Exception as _fl_e:
                # Dřív tiché: gate hinty se nepersistly → refresh je ztratí.
                _log(f"GATE_FLUSH_WARN: {_fl_e}", xbmc.LOGWARNING)

        return applied
    except Exception as exc:
        _log(f"GATE_PREFETCH_WARN: {exc}", xbmc.LOGWARNING)
        return 0


def _gate_publish_probe(ident: str, mi: dict) -> None:
    """Fire-and-forget: publish a successful local probe result to Gate.

    Called inside _worker() after _eng.mi2_publish succeeds. Silently
    swallows every error — the local cache already has the data, sharing is
    a bonus. Never re-raises; never logs at ERROR level (would spam on
    offline devices).
    """
    try:
        pair = _mi_gate.ident_to_key(ident)
        if pair is None:
            return
        payload = _mi_to_canonical(mi or {})
        if not payload:
            return
        _mi_gate.publish(pair[0], pair[1], payload)
    except Exception as exc:
        _log(f"GATE_PUBLISH_WARN ident={ident} err={exc}", xbmc.LOGWARNING)




class MediaInfoSecondEdition:
    """
    2025-09-07 16:07 CEST (Europe/Prague)

    Koordinátor “druhé vlny” MediaInfo:
      • postupně zjišťuje stopy (Audio/Text) přes Webshare → MediaInfo
      • publikuje hinty do engine (_eng.mi2_publish)
      • šetrně refreshne obsah kontejneru, aby se doplnily štítky v UI

    Refresh je koaleskovaný:
      – první po ~N hotových položkách (rychlá vizuální odezva)
      – závěrečný po dokončení dávky (pokud něco přibylo)

    DŮLEŽITÉ (UX / stabilita):
      • MI2 NIKDY nesmí volat Container.Refresh() dřív, než je listing “hotový”.
        Jinak hrozí přerender kontejneru uprostřed běhu pluginu.
      • Stav listingu signalizuje plugin přes:
          Window(10000).Property("richmovie.listing.ready") = "1"
        (a kvůli legacy i "richmovie.mi2.listing_ready").
      • start() umí “extendovat” běžící dávku pro stejný container:
        W1 spustí MI2, W2/W3/WX jen doplní další identy do fronty (bez nové thread).
    """

    # — běžící dávka —
    _RUNNING_KEY = None          # klíč běžící dávky (Container.FolderPath)
    _RUNNING_THR: threading.Thread | None = None

    # — fronta pro “extend” (per-batch) —
    _LOCK = threading.Lock()
    _PENDING: Deque[str] = deque()
    _PENDING_SET: set[str] = set()
    _DONE_SET: set[str] = set()

    # — konfigurace běžící dávky —
    _CLIENT_FACTORY: Callable[[], WebshareClient] | None = None
    _FS_CLIENT_FACTORY: Callable[[], "FastshareClient"] | None = None  # 22.01.2026 – Fastshare podpora
    _FS_URL_MAP: dict[str, tuple[str, str]] = {}  # 20.02.2026 – ident → (download_url, fs_hash)
    _REFRESH_REQUESTED: bool = False
    _FIRST_BATCH: int = 8
    _MAX_ITEMS: int = 32
    _START_TS: float = 0.0



    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_mi2.py › class MediaInfoSecondEdition # start
    # (upraveno: 22.01.2026 00:30 CET (Europe/Prague) – přidána podpora Fastshare client factory)
    # ---------------------------------------------------------------------------- #
    @staticmethod
    def start(
        releases: Sequence[object],
        client_factory: Callable[[], WebshareClient],
        *,
        fs_client_factory: Callable[[], "FastshareClient"] | None = None,  # 22.01.2026 – Fastshare
        first_batch: int = 8,
        max_items: int = 32,
        refresh: bool = True,
        key: str | None = None,
    ) -> None:
        """
        21.12.2025 17:58 CET (Europe/Prague)

        Spustí (nebo rozšíří) MI2 dávku nad poskytnutými releasy.

        Parametry:
          releases       – seznam Release objektů (nebo dict-like se "ident")
          client_factory – callback vracející přihlášeného WebshareClienta
          first_batch    – po kolika úspěšných publish se má poprvé refreshnout GUI
          max_items      – maximum identů na 1 dávku (ochrana proti přetížení)
          refresh        – pokud True, MI2 se pokusí dělat Container.Refresh (AŽ po listing.ready)
          key            – kanonický klíč listingu, pro který dávka běží. POVINNÉ z renderovací
                           cesty: `richmovie_listing.current_listing_key()` (URL invokace).
                           None = legacy fallback na `Container.FolderPath`, který je UVNITŘ
                           stavby adresáře cesta, ze které odcházíme (incident 19.09.2026,
                           `key=…?action=show_recommendations` u výpisu 127 streamů).

        FÁZE 1 (stabilita / “blikání”):
          • kanonizujeme Container.FolderPath → stejný listing má vždy stejný klíč
          • hlídáme globální marker “MI2 běží” (napříč invokery) → pro stejný listing nebudeme startovat duplicitně
          • inflight lock per ident (Window property) → i při více invokerech se stejný ident neprobuje dvakrát
          • cache-first: pokud už máme flags (RAM/disk), daný ident se přeskočí

        FÁZE 2 (výkon / I/O):
          • engine (`mi2_publish`) už zapisuje mi2_cache.json debouncovaně
          • před každým `Container.Refresh` děláme `mi2_flush_disk(force=True)`, aby nová instance listingu
            hned viděla výsledky (a nebylo to “problikávání” bez badge)
        """

        # 0) klíč listingu — autorita je parametr `key` (URL invokace volajícího).
        #    Fallback na Container.FolderPath je JEN pro volání mimo renderovací cestu;
        #    uvnitř stavby adresáře ukazuje na předchozí obrazovku (viz docstring).
        if key:
            raw_key = str(key)
        else:
            try:
                raw_key = xbmc.getInfoLabel("Container.FolderPath") or "unknown"
            except Exception:
                raw_key = "unknown"
            try:
                _log("KEY_FALLBACK: start() bez key= → Container.FolderPath=%s" % raw_key)
            except Exception:
                pass

        # 0b) kanonizace klíče — SSOT `richmovie_listing.canon_key`
        #     (dřív vlastní kopie; DRY, ať se pořadí query paramů řeší na jednom místě)
        def _canon_key(fp: str) -> str:
            return _listing.canon_key(fp)

        key = _canon_key(raw_key)

        # Window(10000) – kvůli globálním markerům a inflight lockům
        try:
            w10000 = xbmcgui.Window(10000)
        except Exception:
            w10000 = None

        # 0c) globální “MI2 běží” marker (napříč invokery) – pokud je aktivní, nespouštěj novou dávku
        #     (při refreshi se často spustí nový invoker, ale MI2 už běží na pozadí)
        try:
            if w10000:
                running = (w10000.getProperty("richmovie.mi2.running") or "").strip()
                running_key = (w10000.getProperty("richmovie.mi2.running_key") or "").strip()
                running_ping = (w10000.getProperty("richmovie.mi2.running_ping") or "").strip()

                rk = _canon_key(running_key)
                is_running = running in ("1", "true", "True", "yes", "on")

                # TTL: pokud ping “zamrzl” moc dlouho, marker ignorujeme
                ping_ok = False
                try:
                    ping_ts = float(running_ping) if running_ping else 0.0
                    if ping_ts and (time.time() - ping_ts) < 180.0:
                        ping_ok = True
                except Exception:
                    ping_ok = False

                if is_running and ping_ok:
                    if rk == key:
                        _log(f"SKIP_GLOBAL: MI2 already running for same key={key}")
                        return
                    else:
                        _log(f"SKIP_GLOBAL: MI2 running for other key={rk} (this_key={key})")
                        return
        except Exception:
            pass

        # 1) vytáhni identy (dedupe, zachovej pořadí, omez max_items)
        idents_all: list[str] = []
        seen: set[str] = set()

        # FÁZE A: .mp4 soubory záměrně neprobujeme přes MI2 (prakticky nikdy to nic nevytáhne).
        #         Označíme je jako negativní cache (fail marker) a tím zabráníme re-try po refreshi.
        mp4_idents: set[str] = set()

        for r in releases or []:
            ident = None
            name = None
            try:
                ident = getattr(r, "ident", None)
            except Exception:
                ident = None

            # název je best-effort (Release.name / dict['name']); stačí nám jen detekce '.mp4'
            try:
                name = getattr(r, "name", None) or getattr(r, "filename", None) or getattr(r, "file_name", None)
            except Exception:
                name = None

            if (not ident) and isinstance(r, dict):
                try:
                    ident = r.get("ident")
                except Exception:
                    ident = None
                try:
                    name = name or r.get("name") or r.get("filename") or r.get("file_name") or r.get("title")
                except Exception:
                    pass

            ident_s = str(ident or "").strip()
            if not ident_s or ident_s in seen:
                continue

            # detekce mp4 podle názvu (pokud ho máme)
            try:
                nm = str(name or "").strip().lower()
                if nm and ".mp4" in nm:
                    mp4_idents.add(ident_s)
            except Exception:
                pass

            # 20.02.2026 – extrakce Fastshare URL info z Release pro MI2 probe
            if ident_s.startswith("fs:"):
                try:
                    fs_url = getattr(r, "fs_download_url", None) or (r.get("fs_download_url") if isinstance(r, dict) else None)
                    fs_h = getattr(r, "fs_hash", None) or (r.get("fs_hash") if isinstance(r, dict) else None)
                    if fs_url and fs_h:
                        MediaInfoSecondEdition._FS_URL_MAP[ident_s] = (str(fs_url), str(fs_h))
                except Exception:
                    pass

            seen.add(ident_s)
            idents_all.append(ident_s)

            if len(idents_all) >= int(max_items or 0 or 32):
                break

        if not idents_all:
            return

        # 1b) cache-first filtr (RAM + disk) – co už víme, neprobuje se
        idents: list[str] = []
        cached = 0
        mp4_marked = 0

        for ident_s in idents_all:
            # 1) už je v cache (RAM/disk) → skip
            try:
                flags = _eng.mi2_get_flags(ident_s)
                if isinstance(flags, dict) and flags:
                    cached += 1
                    continue
            except Exception:
                pass

            # 2) FÁZE A: .mp4 neprobujeme → fail marker (negativní cache) a bereme jako cache-hit
            if ident_s in mp4_idents:
                try:
                    _eng.mi2_publish(ident_s, fail_reason="skip_mp4", fail_detail="skip: .mp4")
                    mp4_marked += 1
                except Exception as _fm_e:
                    # Dřív tiché: fail-marker se nezapsal → zbytečné re-proby.
                    _log(f"FAILMARK_WARN ident={ident_s} err={_fm_e}", xbmc.LOGWARNING)
                cached += 1
                continue

            idents.append(ident_s)

        if not idents:
            # Pokud jsme jen označili mp4 jako fail, force flush (ať to drží i bez běhu threadu).
            try:
                if mp4_marked > 0:
                    _eng.mi2_flush_disk(force=True)
            except Exception as _fl_e:
                _log(f"FAILMARK_FLUSH_WARN: {_fl_e}", xbmc.LOGWARNING)

            _log(f"SKIP: all cached ({cached}/{len(idents_all)}) key={key}")
            return


        # 2) pokud už běží thread pro stejný container → jen extendni frontu
        with MediaInfoSecondEdition._LOCK:
            thr = MediaInfoSecondEdition._RUNNING_THR
            if thr and thr.is_alive():
                if MediaInfoSecondEdition._RUNNING_KEY == key:
                    added = 0

                    # aktualizuj “max_items” a refresh flag (OR)
                    try:
                        MediaInfoSecondEdition._MAX_ITEMS = max(
                            int(MediaInfoSecondEdition._MAX_ITEMS or 0),
                            int(max_items or 0),
                        ) or 32
                    except Exception:
                        MediaInfoSecondEdition._MAX_ITEMS = 32

                    if refresh:
                        MediaInfoSecondEdition._REFRESH_REQUESTED = True

                    # 21.02.2026 – aktualizuj FS client factory pokud nový volající předá hodnotu
                    #   (engine volá MI2.start() bez fs_client_factory, plugin.py ho pak dodá přes EXTEND)
                    if fs_client_factory and not MediaInfoSecondEdition._FS_CLIENT_FACTORY:
                        MediaInfoSecondEdition._FS_CLIENT_FACTORY = fs_client_factory

                    # doplň identy do fronty (bez duplicit a bez překročení max_items)
                    for ident_s in idents:
                        if ident_s in MediaInfoSecondEdition._DONE_SET:
                            continue
                        if ident_s in MediaInfoSecondEdition._PENDING_SET:
                            continue
                        if (len(MediaInfoSecondEdition._DONE_SET) + len(MediaInfoSecondEdition._PENDING_SET)) >= int(MediaInfoSecondEdition._MAX_ITEMS or 32):
                            break
                        MediaInfoSecondEdition._PENDING.append(ident_s)
                        MediaInfoSecondEdition._PENDING_SET.add(ident_s)
                        added += 1

                    _log(f"EXTEND key={key} +{added} (pending={len(MediaInfoSecondEdition._PENDING_SET)} done={len(MediaInfoSecondEdition._DONE_SET)})")
                    return

                # Běží MI2 pro jiný container: nespouštěj další thread (ochrana před závody)
                _log(f"SKIP: running for other container (running_key={MediaInfoSecondEdition._RUNNING_KEY}, this_key={key})")
                return

            # 3) nová dávka – inicializace
            MediaInfoSecondEdition._RUNNING_KEY = key
            MediaInfoSecondEdition._CLIENT_FACTORY = client_factory
            MediaInfoSecondEdition._FS_CLIENT_FACTORY = fs_client_factory  # 22.01.2026 – Fastshare
            MediaInfoSecondEdition._REFRESH_REQUESTED = bool(refresh)
            MediaInfoSecondEdition._FIRST_BATCH = int(first_batch or 8)
            MediaInfoSecondEdition._MAX_ITEMS = int(max_items or 32) or 32
            MediaInfoSecondEdition._START_TS = time.time()

            MediaInfoSecondEdition._PENDING.clear()
            MediaInfoSecondEdition._PENDING_SET.clear()
            MediaInfoSecondEdition._DONE_SET.clear()

            # naplň frontu (už dedupované + cache-first)
            for ident_s in idents:
                if len(MediaInfoSecondEdition._PENDING_SET) >= MediaInfoSecondEdition._MAX_ITEMS:
                    break
                MediaInfoSecondEdition._PENDING.append(ident_s)
                MediaInfoSecondEdition._PENDING_SET.add(ident_s)

        # ------------------------------------------------------------------ #
        def _refresh_target_visible(run_key: str) -> bool:
            """
            Je na obrazovce PRAVE TEN listing, pro ktery tahle davka bezi?

            Φ5A (29.09.2026): `run_key` je PARAMETR. Dřív funkce četla `run_key` jako volnou proměnnou,
            jenže ta je lokální v sousedním `_worker` → v pluginu (známá cesta kontejneru) `NameError`,
            který volající tiše spolkl → závěrečný refresh MI2 od 3.5.153 v pluginu NIKDY neproběhl
            (data A06 F15: 0 refreshů po výpisu; ve službě prázdná cesta proměnnou přeskočila).

            Cross-check Pro Q7 (19.09.2026): `_listing_ready()` je GLOBALNI priznak —
            rekne jen „nejaky listing je hotovy", ne „ten muj". Kdyz uzivatel mezitim
            odesel jinam, MI2 refreshlo cizi obrazovku a vyrusilo ho. Az od 3.5.153 ma
            MI2 spravny klic listingu, takze se da porovnat.

            Pri pochybnostech vraci True (neznamy kontejner = radeji refresh nez
            zamrzly badge) — negativni rozhodnuti musi byt jiste.
            """
            try:
                cur = _listing.canon_key(xbmc.getInfoLabel("Container.FolderPath") or "")
            except Exception:
                return True
            if cur == _listing.UNKNOWN_KEY or not run_key:
                return True
            return bool(cur == _listing.canon_key(run_key) or _listing.targets_match(cur, run_key))

        def _listing_ready() -> bool:
            """
            Vrací True, pokud plugin signalizoval, že listing je vykreslený
            (teprve pak je bezpečné dělat Container.Refresh).
            """
            try:
                # nový klíč + legacy klíč
                v = (xbmc.getInfoLabel("Window(10000).Property(richmovie.listing.ready)") or "").strip()
                if v in ("1", "true", "True", "yes", "on"):
                    return True
                v2 = (xbmc.getInfoLabel("Window(10000).Property(richmovie.mi2.listing_ready)") or "").strip()
                return v2 in ("1", "true", "True", "yes", "on")
            except Exception:
                return False

        # ------------------------------------------------------------------ #
        def _worker() -> None:
            """
            Worker thread:
              • bere identy z fronty (extendable)
              • sondí MediaInfo (audio/sub + video dims + duration)
              • publikuje do MI2 cache
              • případně refreshne listing (až po listing.ready)

            FÁZE 1:
              • inflight lock per ident (Window property) – aby stejný ident neběžel paralelně v jiné instanci
              • cache-first i uvnitř workeru (pro jistotu)

            FÁZE 2:
              • před každým Container.Refresh force-flush mi2_cache.json (mi2_flush_disk(force=True))
            """
            WAIT_BEFORE_REFRESH = 1.2  # ochrana proti “Refresh stormu”
            start_ts = time.time()
            updated = 0
            fail_marked = 0  # FÁZE A: počet zapsaných fail markerů (negativní MI2 cache)

            first_done = False

            # vytvoř klienta (Webshare)
            try:
                cli_factory = MediaInfoSecondEdition._CLIENT_FACTORY
                if not cli_factory:
                    _log("ERR: missing client_factory", xbmc.LOGERROR)
                    return
                cli = cli_factory()
            except Exception as e:
                _log(f"ERR: client_factory failed: {e}", xbmc.LOGERROR)
                return

            # 22.01.2026 – vytvoř Fastshare klienta (pokud je factory k dispozici)
            fs_cli = None
            try:
                fs_cli_factory = MediaInfoSecondEdition._FS_CLIENT_FACTORY
                if fs_cli_factory:
                    fs_cli = fs_cli_factory()
                    _log("FS_CLIENT_OK")
            except Exception as e:
                _log(f"FS_CLIENT_WARN: {e}", xbmc.LOGWARNING)
                fs_cli = None

            # ---- lokální helpery ----
            def _norm_lang(code: str) -> str:
                c = (code or "").strip().lower()
                if len(c) > 3:
                    c = c[:3]
                if c in ("cz", "cs", "ces", "cze"):
                    return "cs"
                if c in ("en", "eng"):
                    return "en"
                if c in ("sk", "slo", "slk"):
                    return "sk"
                return c or ""

            def _to_int(v: object) -> int | None:
                try:
                    if v is None:
                        return None
                    if isinstance(v, (int, float)):
                        iv = int(v)
                        return iv if iv > 0 else None
                    s = str(v).strip()
                    if not s:
                        return None
                    digits = "".join(ch for ch in s if ch.isdigit())
                    if not digits:
                        return None
                    iv = int(digits)
                    return iv if iv > 0 else None
                except Exception:
                    return None

            def _extract(mi: dict) -> dict:
                """
                Z MediaInfo dictu vytáhne:
                  aud        : list[str]  (jazyky audia)
                  sub        : list[str]  (jazyky titulků)
                  sub_present: bool|None  (jistota “titulky existují?”)
                  video_w/h  : int|None
                  duration_s : int|None   (stopáž v sekundách)
                """
                out: dict = {
                    "aud": [],
                    "sub": [],
                    "sub_present": None,
                    "video_w": None,
                    "video_h": None,
                    "duration_s": None,
                }

                try:
                    out["duration_s"] = _to_int((mi or {}).get("duration"))
                except Exception:
                    out["duration_s"] = None

                try:
                    tracks = (mi or {}).get("tracks") or []
                except Exception:
                    tracks = []

                auds: list[str] = []
                subs: list[str] = []
                saw_any_text_track = False

                for t in tracks:
                    try:
                        t_type = (t.get("track_type") or t.get("@type") or "").strip().lower()
                    except Exception:
                        t_type = ""

                    if t_type == "audio":
                        lang = _norm_lang(t.get("language") or t.get("Language") or "")
                        if lang and lang not in auds:
                            auds.append(lang)

                    elif t_type in ("text", "subtitle"):
                        saw_any_text_track = True
                        lang = _norm_lang(t.get("language") or t.get("Language") or "")
                        if lang and lang not in subs:
                            subs.append(lang)

                    elif t_type == "video":
                        w = _to_int(t.get("width") or t.get("Width"))
                        h = _to_int(t.get("height") or t.get("Height"))
                        if w and not out.get("video_w"):
                            out["video_w"] = w
                        if h and not out.get("video_h"):
                            out["video_h"] = h
                        # Noc 03.11.2026 (Φ3): Dolby Vision z kanonického tvaru Gate (`gate_payload_to_legacy_mi`
                        # nese `hdr` / `dv_profile` / `dv_compat` ve video stopě)
                        if t.get("hdr") and not out.get("hdr"):
                            out["hdr"] = str(t.get("hdr"))
                        if t.get("dv_profile") is not None and out.get("dv_profile") is None:
                            out["dv_profile"] = _to_int(t.get("dv_profile"))
                        if t.get("dv_compat") and not out.get("dv_compat"):
                            out["dv_compat"] = str(t.get("dv_compat"))

                out["aud"] = auds
                out["sub"] = subs

                try:
                    if isinstance(tracks, list) and tracks:
                        out["sub_present"] = True if saw_any_text_track else False
                    else:
                        out["sub_present"] = None
                except Exception:
                    out["sub_present"] = None

                return out

            monitor = xbmc.Monitor()

            # refresh marker + globální “running” marker (napříč Kodi invokery)
            try:
                w = xbmcgui.Window(10000)
            except Exception:
                w = None

            run_token = f"{int(time.time() * 1000)}.{threading.get_ident()}"
            run_key = str(MediaInfoSecondEdition._RUNNING_KEY or key or "")

            try:
                if w:
                    w.setProperty("richmovie.mi2.refresh_key", run_key)
                    w.clearProperty("richmovie.mi2.refresh_reason")

                    now_s = str(time.time())
                    w.setProperty("richmovie.mi2.running", "1")
                    w.setProperty("richmovie.mi2.running_key", run_key)
                    w.setProperty("richmovie.mi2.running_token", run_token)
                    w.setProperty("richmovie.mi2.running_ts", now_s)
                    w.setProperty("richmovie.mi2.running_ping", now_s)
            except Exception:
                pass

            # inflight lock (Window property) – ident → token
            INF_TTL = 30 * 60  # 30 minut

            def _inflight_prop(ident: str) -> str:
                h = hashlib.md5(str(ident or "").encode("utf-8")).hexdigest()
                return f"richmovie.mi2.inflight.{h}"

            def _acquire_inflight(ident: str) -> bool:
                """Vrátí True pokud můžeme probe; False pokud už běží jinde."""
                try:
                    if not w:
                        return True
                    prop = _inflight_prop(ident)
                    cur = (w.getProperty(prop) or "").strip()
                    now = time.time()

                    if cur:
                        parts = cur.split("|")
                        if parts:
                            try:
                                ts0 = float(parts[0])
                            except Exception:
                                ts0 = 0.0
                            if ts0 and (now - ts0) < INF_TTL:
                                return False

                    w.setProperty(prop, f"{now}|{run_token}|{ident}")
                    return True
                except Exception:
                    return True

            def _release_inflight(ident: str) -> None:
                try:
                    if not w:
                        return
                    prop = _inflight_prop(ident)
                    cur = (w.getProperty(prop) or "").strip()
                    if not cur:
                        return
                    parts = cur.split("|")
                    if len(parts) >= 2 and parts[1] == run_token:
                        w.clearProperty(prop)
                except Exception:
                    pass

            # ── Phase 3b.5: Gate MI cache pre-fetch ────────────────────── #
            # One bulk call to /v1/mediainfo/bulk_lookup before the probe
            # loop starts. Each hit is pushed into the engine cache via
            # _eng.mi2_publish so the cache-first gate below (mi2_get_flags)
            # short-circuits those idents without probing them locally.
            #
            # Best-effort: on any Gate failure (transport, 5xx, 429) this
            # returns 0 and the worker probes every ident as before. This
            # preserves the pre-3.0.0-beta.2 baseline when Gate is down.
            try:
                with MediaInfoSecondEdition._LOCK:
                    pending_snapshot = list(MediaInfoSecondEdition._PENDING)
                if pending_snapshot:
                    gate_hits = _gate_prefetch_into_engine(pending_snapshot)
                    if gate_hits:
                        _log(
                            f"GATE_PREFETCH applied={gate_hits}/"
                            f"{len(pending_snapshot)} pending"
                        )
            except Exception as e:
                _log(f"GATE_PREFETCH_ERR: {e}", xbmc.LOGERROR)

            # Phase I1.1 (2026-04-19): Parallel probe batch.
            # Gate probe s early-exit = ~1-2s per ident. Legacy local
            # libmediainfo early-exit bylo ~0.5-1s. Abychom dorovnali
            # vnímanou rychlost ("5-10 najednou") → 5 paralelních workers
            # = efektivně ~2.5 probes/s. Bezpečně pod CDN rate-limit
            # (Gate = jedna IP, víc než 5 paralel by mohlo trigger throttle).
            import concurrent.futures as _cf
            _MI2_PROBE_WORKERS = 5

            def _probe_one(ident: str):
                """Returns (ident, mi_or_exception, skipped_reason). Runs
                inside worker thread — must not touch Kodi window props."""
                # cache-first re-check
                try:
                    flags = _eng.mi2_get_flags(ident)
                    if isinstance(flags, dict) and flags:
                        return (ident, None, "cached")
                except Exception:
                    pass
                if not _acquire_inflight(ident):
                    return (ident, None, "inflight")
                try:
                    if ident.startswith("fs:") and fs_cli:
                        url_info = MediaInfoSecondEdition._FS_URL_MAP.get(ident)
                        if url_info:
                            try:
                                fs_cli.register_url(ident, url_info[0], url_info[1])
                            except Exception as _rg_e:
                                # Dřív tiché: probe pak selže s PROBE_ERR —
                                # tady je vidět prekurzor (register fail).
                                _log(f"FS_REGISTER_WARN ident={ident} err={_rg_e}",
                                     xbmc.LOGDEBUG)
                        mi = fs_cli.probe_mediainfo(ident)
                    else:
                        mi = cli.probe_mediainfo(ident)
                    return (ident, mi, None)
                except Exception as e:
                    return (ident, e, None)

            def _handle(ident: str, mi_or_exc, skip_reason) -> None:
                """Zpracuje výsledek jedné sondy (publikace, fail marker, Gate). Φ5A: vyčleněno ze
                smyčky dávek, aby ho mohla volat průběžná fronta; logika beze změny."""
                nonlocal updated, fail_marked
                if skip_reason == "cached":
                    _log(f"SKIP_CACHED ident={ident}")
                    return
                if skip_reason == "inflight":
                    _log(f"SKIP_INFLIGHT ident={ident}")
                    return

                # mi_or_exc je bud dict (úspěch) nebo Exception
                fail_written = False
                mi = None
                if isinstance(mi_or_exc, Exception):
                    e = mi_or_exc
                    # 3.5.118: typ rozhoduje, zda se selhání perzistuje.
                    reason = _classify_probe_failure(e)
                    if reason is None:
                        # Infrastruktura (identita / Gate 5xx / offline):
                        # žádný marker → ident zůstává „neprobováno" a zkusí
                        # se znovu, až bude síť/identita v pořádku. Storm
                        # nehrozí: transport i identita fail-fastují v ms.
                        _log(f"PROBE_INFRA ident={ident} err={type(e).__name__}: {e}",
                             xbmc.LOGWARNING)
                        _release_inflight(ident)
                        return
                    if reason == FAIL_REASON_NOT_MEDIA:
                        # Vlastnost odkazu (Free účet / CDN 4xx), ne porucha:
                        # WARNING, ať ERROR filtr na NASu nezaplaví Free účet.
                        _log(f"PROBE_NOT_MEDIA ident={ident} err={e}", xbmc.LOGWARNING)
                    else:
                        _log(f"PROBE_ERR ident={ident} err={e}", xbmc.LOGERROR)
                    try:
                        _eng.mi2_publish(ident, fail_reason=reason, fail_detail=str(e))
                        fail_marked += 1
                        fail_written = True
                    except Exception:
                        pass
                else:
                    mi = mi_or_exc

                if not mi:
                    if not fail_written:
                        try:
                            _eng.mi2_publish(
                                ident, fail_reason="empty",
                                fail_detail="probe returned empty/false",
                            )
                            fail_marked += 1
                        except Exception:
                            pass
                    _release_inflight(ident)
                    return

                gate_publishable = False
                try:
                    info = _extract(mi)
                    _eng.mi2_publish(
                        ident,
                        info.get("aud") or (),
                        info.get("sub") or (),
                        sub_present=info.get("sub_present"),
                        video_w=info.get("video_w"),
                        video_h=info.get("video_h"),
                        duration_s=info.get("duration_s"),
                        hdr=info.get("hdr"),
                        dv_profile=info.get("dv_profile"),
                        dv_compat=info.get("dv_compat"),
                    )
                    updated += 1
                    gate_publishable = True
                    _log(
                        f"PROBE_OK ident={ident} aud={len(info.get('aud') or [])} "
                        f"sub={len(info.get('sub') or [])} vh={info.get('video_h')} dur_s={info.get('duration_s')}"
                    )
                except Exception as e:
                    _log(f"PUBLISH_ERR ident={ident} err={e}", xbmc.LOGERROR)
                finally:
                    _release_inflight(ident)

                if gate_publishable:
                    _gate_publish_probe(ident, mi)

            with _cf.ThreadPoolExecutor(
                max_workers=_MI2_PROBE_WORKERS,
                thread_name_prefix="RM-MI2-probe",
            ) as _pool:
                # Φ5A (29.09.2026, audit A06 F13): PRŮBĚŽNÁ fronta — jakmile sonda doběhne, na její
                # místo hned jde další ident (nejvýš `_MI2_PROBE_WORKERS` současně, beze změny). Dřív
                # dávky po pěti čekaly na nejpomalejší prvek, takže čekání na první obrazovku častěji
                # narazilo na strop 12 s.
                in_flight = {}
                while not monitor.abortRequested():
                    with MediaInfoSecondEdition._LOCK:
                        while len(in_flight) < _MI2_PROBE_WORKERS and MediaInfoSecondEdition._PENDING:
                            _id = MediaInfoSecondEdition._PENDING.popleft()
                            MediaInfoSecondEdition._PENDING_SET.discard(_id)
                            MediaInfoSecondEdition._DONE_SET.add(_id)
                            in_flight[_pool.submit(_probe_one, _id)] = _id
                    if not in_flight:
                        break

                    try:
                        if w:
                            w.setProperty(
                                "richmovie.mi2.running_ping", str(time.time()),
                            )
                    except Exception:
                        pass

                    # Krátký timeout: abort Kodi (5s okno) i nově přidané identy se dostanou ke slovu.
                    done_futs, _still = _cf.wait(list(in_flight), timeout=0.5,
                                                 return_when=_cf.FIRST_COMPLETED)
                    for _fut in done_futs:
                        in_flight.pop(_fut, None)
                        if monitor.abortRequested():
                            break
                        try:
                            ident, mi_or_exc, skip_reason = _fut.result()
                        except Exception as _fe:
                            _log(f"WORKER_EXC: {_fe}", xbmc.LOGERROR)
                            continue
                        _handle(ident, mi_or_exc, skip_reason)

            # závěrečný flush (aby se i malé batche zapsaly na disk)
            try:
                if (updated > 0) or (fail_marked > 0):
                    _eng.mi2_flush_disk(force=True)
            except Exception:
                pass

            # závěrečný refresh (pokud je co refreshnout)
            try:
                refresh_req = bool(MediaInfoSecondEdition._REFRESH_REQUESTED)
                first_batch_local = int(MediaInfoSecondEdition._FIRST_BATCH or 8)
            except Exception:
                refresh_req = True
                first_batch_local = 8

            def _release_running_marker() -> None:
                """Zruší globální značku „MI2 běží“ — JEN vlastní (token sedí; idempotentní). Jedno místo pro konec
                workeru i pro čekání na klid před závěrečným refreshem (ověřovací audit Fable N-1, 09.10.2026):
                sondy jsou hotové, takže značka by při čekání (až YIELD_MAX_S) jen blokovala MediaInfo jiného
                výpisu (`SKIP_GLOBAL` v `start`)."""
                try:
                    if w:
                        tok = (w.getProperty("richmovie.mi2.running_token") or "").strip()
                        if tok == run_token:
                            w.clearProperty("richmovie.mi2.running")
                            w.clearProperty("richmovie.mi2.running_key")
                            w.clearProperty("richmovie.mi2.running_token")
                            w.clearProperty("richmovie.mi2.running_ts")
                            w.clearProperty("richmovie.mi2.running_ping")
                except Exception:
                    pass

            def _final_refresh(tag: str, _waited: bool = False) -> None:
                """Závěrečný `Container.Refresh` (tag final|deferred) — JEDNO místo pro obě větve.
                Marker se zapisuje AŽ KDYŽ se opravdu refreshuje (audit Fable P1 #2): při
                `REFRESH_SKIP` by jinak visel a otrávil další listing. Φ5A (D3): když byla první
                obrazovka při vykreslení celá vyřízená, výpis se nepřekresluje — jen by se
                přeskládal pod rukama; zbytek řádků doplní další otevření. 4.0.1: brána dispatcheru
                (start přehrávání / busy dialog / konec Kodi = zahodit; aktivní divák = počkat na klid
                a zkusit jednou znovu, `_waited`). 4.0.2: přehrávač (i pozastavený) a relace přehrávání
                = taky zahodit (plán E6 — přehrávač by tu byl i po klidu)."""
                if not _refresh_target_visible(run_key):
                    _log(f"REFRESH_SKIP ({tag}) cizi kontejner, run_key={run_key}")
                    return
                try:
                    top_raw = w.getProperty(_listing.PROP_TOP_UNSETTLED) if w else ""
                except Exception:
                    top_raw = ""
                if not _listing.final_refresh_needed(top_raw, run_key):
                    _log(f"REFRESH_SKIP ({tag}) prvni obrazovka vyrizena, run_key={run_key}")
                    return
                # 4.0.1 (pád Kodi, Sony BRAVIA 09.10.2026 20:16:47): divák mezitím klikl na stream → refresh by
                # Kodi znovu spustil výpis přesně ve chvíli, kdy kvůli celé obrazovce opouští okno (5s čekání
                # `CancelUpdateItems` → use-after-free v Kodi). Verdikt brány PŘED značkami (plán D6): visící
                # značka by otrávila další výpis (audit Fable P1 #2). Refresh MI2 je Z POZADÍ (ne reakce na vstup)
                # → ustoupí i aktivnímu divákovi (D2b: okno mezi klikem na stream a claimem `_play`; zároveň
                # se výpis nepřeskládá pod rukama — Φ5A D3).
                why = _rm_dispatch.refresh_block_reason(_rm_dispatch.probe_refresh(background=True))
                if why == _rm_dispatch.REFRESH_BLOCK_USER_ACTIVE and not _waited:
                    # Audit Fable F-1 (09.10.2026): divák právě pracuje (ovladač < USER_ACTIVE_IDLE_S, běží invokace —
                    # i vlastní výpis v „landed“ čekání) → NEZAHAZOVAT: první obrazovka je nevyřízená (jinak by sem
                    # kód nedošel) a štítky/řazení by nedoskočily. Počkat na klid (SSOT `wait_while_busy`, strop
                    # YIELD_MAX_S, abort = konec) a pak VŠECHNY kontroly znovu — divák mohl odejít nebo kliknout na stream.
                    _log(f"REFRESH_WAIT ({tag}) divak pracuje, run_key={run_key}")
                    _release_running_marker()   # sondy hotové — jiný výpis nesmí čekat na náš klid (Fable N-1)
                    if _rm_activity.wait_while_busy(monitor):
                        _final_refresh(tag, _waited=True)
                    return
                if why:
                    _log(f"REFRESH_SKIP ({tag}) {why}, run_key={run_key}")
                    return
                try:
                    if w:
                        w.setProperty("richmovie.mi2.refresh_reason", tag)
                        w.setProperty("richmovie.mi2.refresh_key", run_key)
                except Exception:
                    pass
                try:
                    _eng.mi2_flush_disk(force=True)
                except Exception:
                    pass
                if _rm_dispatch.refresh_container("mi2_%s" % tag, background=True):
                    _log(f"REFRESH ({tag}) updated={updated}")
                    return
                # Brána mezi verdiktem a odesláním odmítla (start přehrávání / busy dialog / konec Kodi) →
                # značky pryč, jinak by je další výpis vzal za „tohle je můj MI2 refresh“. Jen VLASTNÍ značky
                # (cross-check Pro P3 09.10.2026): souběžné MI2 jiného výpisu je mohlo mezitím přepsat svými.
                try:
                    if w and w.getProperty("richmovie.mi2.refresh_key") == run_key \
                            and w.getProperty("richmovie.mi2.refresh_reason") == tag:
                        w.clearProperty("richmovie.mi2.refresh_reason")
                        w.clearProperty("richmovie.mi2.refresh_key")
                except Exception:
                    pass
                _log(f"REFRESH_SKIP ({tag}) brana odmitla pri odeslani, run_key={run_key}")

            if refresh_req and updated > (first_batch_local if first_done else 0) and not monitor.abortRequested():
                if _listing_ready():
                    try:
                        _final_refresh("final")
                    except Exception:
                        pass
                else:
                    # listing ještě není ready → počkej krátce a zkus jednou
                    try:
                        t_wait = time.time()
                        while (time.time() - t_wait) < 3.0 and (not monitor.abortRequested()):
                            if _listing_ready():
                                try:
                                    _final_refresh("deferred")
                                except Exception:
                                    pass
                                break
                            monitor.waitForAbort(0.1)
                    except Exception:
                        pass

            # --- ukončení: zruš globální “running” marker (jen pokud token sedí) ---
            _release_running_marker()

            # cleanup – pouze pokud jsme stále “registrované” running vlákno
            with MediaInfoSecondEdition._LOCK:
                try:
                    if MediaInfoSecondEdition._RUNNING_THR and (MediaInfoSecondEdition._RUNNING_THR == threading.current_thread()):
                        MediaInfoSecondEdition._RUNNING_THR = None
                        MediaInfoSecondEdition._RUNNING_KEY = None
                        MediaInfoSecondEdition._CLIENT_FACTORY = None
                        MediaInfoSecondEdition._FS_URL_MAP.clear()  # 20.02.2026
                        MediaInfoSecondEdition._REFRESH_REQUESTED = False
                        MediaInfoSecondEdition._START_TS = 0.0
                        MediaInfoSecondEdition._PENDING.clear()
                        MediaInfoSecondEdition._PENDING_SET.clear()
                        MediaInfoSecondEdition._DONE_SET.clear()
                except Exception:
                    MediaInfoSecondEdition._RUNNING_THR = None
                    MediaInfoSecondEdition._RUNNING_KEY = None
                    MediaInfoSecondEdition._CLIENT_FACTORY = None
                    MediaInfoSecondEdition._FS_URL_MAP.clear()  # 20.02.2026
                    MediaInfoSecondEdition._REFRESH_REQUESTED = False
                    MediaInfoSecondEdition._START_TS = 0.0
                    MediaInfoSecondEdition._PENDING.clear()
                    MediaInfoSecondEdition._PENDING_SET.clear()
                    MediaInfoSecondEdition._DONE_SET.clear()

        # 4) start thread
        thr = threading.Thread(target=_worker, name="RichMovie-MI2", daemon=True)
        with MediaInfoSecondEdition._LOCK:
            MediaInfoSecondEdition._RUNNING_THR = thr
        thr.start()
