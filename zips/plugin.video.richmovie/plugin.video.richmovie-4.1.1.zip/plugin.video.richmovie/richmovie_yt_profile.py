# -*- coding: utf-8 -*-
"""
richmovie_yt_profile.py  -- YouTube taste profile

Lokalni doporucovaci system pro YouTube.
Sleduje kanaly a klicova slova z nazvu sledovanych videi,
umoznuje "Pro tebe" sekci s personalizovanymi doporucenimi.

Datovy soubor: youtube_profile.json (v PROFILE_DIR)
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import xbmcaddon
import xbmcvfs


# ---------------------------------------------------------------------------
#  LAZY INIT
# ---------------------------------------------------------------------------
_ADDON: xbmcaddon.Addon | None = None
_PROFILE_DIR: Path | None = None

# Stop slova (ceska + anglicka) - prilis kratka/bezna slova ignorujeme
_STOP_WORDS = frozenset({
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "for",
    "from", "has", "have", "he", "her", "his", "how", "if", "in",
    "is", "it", "its", "my", "no", "not", "of", "on", "or", "our",
    "she", "so", "than", "that", "the", "their", "them", "then",
    "there", "these", "they", "this", "to", "was", "we", "were",
    "what", "when", "which", "who", "will", "with", "you", "your",
    # cestina
    "je", "na", "se", "za", "do", "to", "pro", "po", "ve", "ze",
    "od", "ke", "si", "ale", "jak", "tak", "ten", "aby", "kde",
    "jsou", "byl", "jen", "co", "az", "pri", "nebo", "ani",
    "vse", "jeho", "jej", "jiz", "pod", "nad", "bez", "pred",
    # youtube specificke
    "video", "official", "music", "live", "full", "hd", "4k",
    "new", "best", "top", "episode", "ep", "part", "dil",
})

_MAX_WATCHED_IDS = 500
_MAX_KEYWORDS = 200


def _get_addon() -> xbmcaddon.Addon:
    global _ADDON
    if _ADDON is None:
        _ADDON = xbmcaddon.Addon()
    return _ADDON


def _get_profile_dir() -> Path:
    """Osobní data aktuálního profilu — SSOT `richmovie_paths.personal_dir()` (3.5.134), bez cache."""
    import richmovie_paths
    return richmovie_paths.personal_dir()


def _get_path() -> Path:
    return _get_profile_dir() / "youtube_profile.json"


# ---------------------------------------------------------------------------
#  LOAD / SAVE
# ---------------------------------------------------------------------------
_DEFAULT = {
    "channels": {},
    "keywords": {},
    "watched_ids": [],
    "updated": 0,
}


def load_profile() -> dict:
    """Nacte profil z JSON (nebo vrati prazdny default)."""
    try:
        path = _get_path()
        if not path.exists():
            return dict(_DEFAULT)
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        if not isinstance(data, dict):
            return dict(_DEFAULT)
        # doplnit chybejici klice
        for k, v in _DEFAULT.items():
            if k not in data:
                data[k] = type(v)()
        return data
    except Exception:
        return dict(_DEFAULT)


def save_profile(data: dict) -> None:
    """Trvanlivý atomický zápis přes SSOT `richmovie_atomic` (3.5.123)."""
    try:
        import richmovie_atomic as _atomic
        data["updated"] = int(time.time())
        _atomic.write_json(str(_get_path()), data, indent=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
#  RECORD WATCH
# ---------------------------------------------------------------------------
def _extract_keywords(title: str) -> list[str]:
    """Extrahuje klicova slova z titulku videa."""
    import re
    # odstranit specialni znaky, nechat pismena a cislice
    clean = re.sub(r"[^\w\s]", " ", title.lower())
    words = clean.split()
    result = []
    for w in words:
        if len(w) < 3:
            continue
        if w in _STOP_WORDS:
            continue
        if w.isdigit():
            continue
        result.append(w)
    return result


def record_watch(
    video_id: str,
    channel_id: str,
    channel_name: str,
    title: str,
) -> None:
    """Zaznamena sledovani videa do profilu."""
    if not video_id:
        return
    try:
        data = load_profile()
        now = int(time.time())

        # 1) Kanal
        if channel_id:
            ch = data["channels"].get(channel_id, {"name": "", "count": 0, "last_ts": 0})
            ch["name"] = channel_name or ch.get("name", "")
            ch["count"] = ch.get("count", 0) + 1
            ch["last_ts"] = now
            data["channels"][channel_id] = ch

        # 2) Klicova slova
        keywords = _extract_keywords(title)
        kw_data = data["keywords"]
        for kw in keywords:
            entry = kw_data.get(kw, {"count": 0, "last_ts": 0})
            entry["count"] = entry.get("count", 0) + 1
            entry["last_ts"] = now
            kw_data[kw] = entry
        # omezit pocet klicovych slov
        if len(kw_data) > _MAX_KEYWORDS:
            sorted_kw = sorted(kw_data.items(), key=lambda x: x[1].get("count", 0), reverse=True)
            data["keywords"] = dict(sorted_kw[:_MAX_KEYWORDS])

        # 3) Watched IDs
        watched = data["watched_ids"]
        if video_id not in watched:
            watched.append(video_id)
        if len(watched) > _MAX_WATCHED_IDS:
            data["watched_ids"] = watched[-_MAX_WATCHED_IDS:]

        save_profile(data)
    except Exception:
        pass


# ---------------------------------------------------------------------------
#  QUERIES
# ---------------------------------------------------------------------------
def get_top_channels(n: int = 5) -> list[dict]:
    """
    Top N kanalu vazenych: count * recency_factor.
    Vraci [{"channel_id": ..., "name": ..., "count": ..., "score": ...}, ...]
    """
    try:
        data = load_profile()
        channels = data.get("channels", {})
        if not channels:
            return []

        now = time.time()
        scored = []
        for ch_id, info in channels.items():
            count = info.get("count", 0)
            last_ts = info.get("last_ts", 0)
            # recency: cim novejsi, tim vyssi bonus (max 2x, min 0.5x)
            age_days = (now - last_ts) / 86400 if last_ts else 365
            recency = max(0.5, 2.0 - age_days / 30)
            score = count * recency
            scored.append({
                "channel_id": ch_id,
                "name": info.get("name", ""),
                "count": count,
                "score": round(score, 2),
            })

        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:n]
    except Exception:
        return []


def is_watched(video_id: str) -> bool:
    """Kontrola, zda video bylo sledovano."""
    try:
        data = load_profile()
        return video_id in data.get("watched_ids", [])
    except Exception:
        return False
