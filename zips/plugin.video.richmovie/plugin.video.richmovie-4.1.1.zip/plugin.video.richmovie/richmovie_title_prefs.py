# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_title_prefs.py
# Per-title audio/subtitle preference persistence  (vytvořeno: 21.02.2026 CET)
# ⚠️ KODI PLUGIN: Proces-based architektura, lazy init!
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Per-title audio/subtitle preferences
───────────────────────────────────────────────────────────────────────────────
Ukládá individuální preference audia a titulků pro konkrétní filmy/seriály.
Uživatel ručně změní audio/titulky → RichMovie si to zapamatuje a příště
aplikuje (nadřazené globálnímu nastavení).

Klíče:
  • movie:<tmdb_id>            – film s TMDb ID
  • movie:<title_lower>:<year> – film bez TMDb ID (fallback)
  • tv:<tv_id>                 – seriál (platí pro všechny epizody)

API:
    make_title_key(m_tmdb, m_title, m_year, tv_id) -> str | None
    get_pref(key) -> dict | None
    set_pref(key, audio_lang, sub_lang, sub_enabled) -> None
    clear_all_prefs() -> None

Autor: Richie
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

import json
import time
from pathlib import Path

import xbmcaddon
import xbmcvfs


# ─────────────────────────────────────────────────────────────────────────────
#  MODUL-LEVEL PROMĚNNÉ – LAZY INIT
# ─────────────────────────────────────────────────────────────────────────────
_ADDON: xbmcaddon.Addon | None = None
_PROFILE_DIR: Path | None = None


def _get_addon() -> xbmcaddon.Addon:
    global _ADDON
    if _ADDON is None:
        _ADDON = xbmcaddon.Addon()
    return _ADDON


def _get_profile_dir() -> Path:
    """Osobní data aktuálního profilu — SSOT `richmovie_paths.personal_dir()` (3.5.134), bez cache."""
    import richmovie_paths
    return richmovie_paths.personal_dir()


def _get_prefs_path() -> Path:
    return _get_profile_dir() / "title_prefs.json"


# ─────────────────────────────────────────────────────────────────────────────
#  KLÍČ PRO TITLE PREFS
# ─────────────────────────────────────────────────────────────────────────────

def make_title_key(
    *,
    m_tmdb: int | None = None,
    m_title: str | None = None,
    m_year: int | None = None,
    tv_id: int | str | None = None,
) -> str | None:
    """
    Sestaví lookup klíč pro title_prefs.json.

    Priorita:
      1. TV seriál: "tv:<tv_id>"
      2. Film s TMDb ID: "movie:<tmdb_id>"
      3. Film bez TMDb (fallback): "movie:<title_lower>:<year>"
      4. Žádné info → None
    """
    # TV seriál
    if tv_id and str(tv_id).strip():
        return f"tv:{str(tv_id).strip()}"

    # Film s TMDb ID
    if m_tmdb and int(m_tmdb) > 0:
        return f"movie:{int(m_tmdb)}"

    # Fallback: film bez TMDb ID
    title = (m_title or "").strip().lower()
    year = int(m_year) if m_year else 0
    if title and year > 0:
        return f"movie:{title}:{year}"

    return None


# ─────────────────────────────────────────────────────────────────────────────
#  LOAD / SAVE
# ─────────────────────────────────────────────────────────────────────────────

def _load() -> dict:
    """Načte title_prefs.json. Vrací {"version": 1, "titles": {}} při chybě."""
    try:
        path = _get_prefs_path()
        if not path.exists():
            return {"version": 1, "titles": {}}
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
        if not isinstance(data, dict) or "titles" not in data:
            return {"version": 1, "titles": {}}
        return data
    except Exception:
        return {"version": 1, "titles": {}}


def _locked_prefs(fn):
    """Read-modify-write `title_prefs.json` pod `richmovie_paths.personal_lock` (3.5.144: služba do
    souboru zapisuje i při sloučení z Gate; plugin = jiný proces)."""
    import functools

    @functools.wraps(fn)
    def _inner(*args, **kwargs):
        import richmovie_paths as _rp
        with _rp.personal_lock("title_prefs.json"):
            return fn(*args, **kwargs)
    return _inner


def _save(data: dict) -> None:
    """Trvanlivý atomický zápis title_prefs.json přes SSOT `richmovie_atomic` (3.5.123)."""
    try:
        import richmovie_atomic as _atomic
        _atomic.write_json(str(_get_prefs_path()), data, indent=2)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  VEŘEJNÉ API
# ─────────────────────────────────────────────────────────────────────────────

def get_pref(key: str) -> dict | None:
    """
    Vrátí uloženou preferenci pro daný klíč, nebo None.

    Výstup (pokud existuje):
        {"audio_lang": "cs", "sub_lang": "en", "sub_enabled": True, "ts": ...}
    """
    if not key:
        return None
    try:
        data = _load()
        return data.get("titles", {}).get(key) or None
    except Exception:
        return None


@_locked_prefs
def set_pref(
    key: str,
    audio_lang: str,
    sub_lang: str | None,
    sub_enabled: bool,
) -> None:
    """Uloží nebo přepíše per-title preferenci (MANUÁLNÍ volba uživatele —
    nejvyšší priorita, observed vrstva ji nikdy nepřepíše)."""
    if not key:
        return
    try:
        data = _load()
        titles = data.setdefault("titles", {})
        titles[key] = {
            "audio_lang": audio_lang or "",
            "sub_lang": sub_lang or "",
            "sub_enabled": bool(sub_enabled),
            "source": "manual",
            "ts": int(time.time()),
        }
        data["version"] = 1
        _save(data)
        _items_note("note_title_pref", key, titles[key])
    except Exception:
        pass


@_locked_prefs
def set_observed_pref(
    key: str,
    audio_lang: str,
    sub_lang: str | None,
    sub_enabled: bool,
) -> None:
    """Φ4 (2026-07-06, UX audit A03): OBSERVED vrstva — reálně použitá stopa
    z dokoukaného přehrávání (zapisuje service_nextup při konci playbacku).

    Root cause bugu „next-up nehraje stejnou stopou": set_pref měl jediný
    call-site (manuální přepnutí stopy) → typický divák, kterému lokalizace
    stopu vybrala sama, žádnou preferenci NEMĚL a pref-aware výběr streamu
    (3.4.12) neměl vstup.

    Pravidla vrstvení:
      • MANUAL (set_pref) má VŽDY přednost — observed ji NIKDY nepřepíše
        (záznam bez pole "source" = historický manual, chráněn taky).
      • Observed se průběžně obnovuje posledním reálným poslechem.
    get_pref() zůstává beze změny — vrací uloženou preferenci bez ohledu na
    vrstvu (priorita je vynucená zápisovou disciplínou, ne čtením)."""
    if not key:
        return
    try:
        data = _load()
        titles = data.setdefault("titles", {})
        existing = titles.get(key) or {}
        if existing and existing.get("source", "manual") == "manual":
            return  # manuální volba je svatá
        titles[key] = {
            "audio_lang": audio_lang or "",
            "sub_lang": sub_lang or "",
            "sub_enabled": bool(sub_enabled),
            "source": "observed",
            "ts": int(time.time()),
        }
        data["version"] = 1
        _save(data)
        _items_note("note_title_pref", key, titles[key])
    except Exception:
        pass


@_locked_prefs
def clear_all_prefs() -> None:
    """Smaže všechny per-title preference (a pošle tombstony na Gate)."""
    try:
        before = (_load() or {}).get("titles") or {}
        path = _get_prefs_path()
        if path.exists():
            path.unlink()
        _items_note("note_title_prefs_clear", before)
    except Exception:
        pass


def _items_note(fn: str, *args) -> None:
    """3.5.144: preference titulů → Gate per profil (`richmovie_profile_items` = SSOT mapování);
    lazy import, best-effort, echo guard uvnitř."""
    try:
        import richmovie_profile_items as _pi
        getattr(_pi, fn)(*args)
    except Exception:
        pass
