# -*- coding: utf-8 -*-
"""
richmovie_sosac.py
──────────────────
Gate-only klient pro Sosac.tv search + BYOC Streamuj.tv URL composer.

• SosacClient.search_movies(term) → list[SosacItem]           (via Gate)
• SosacClient.search_tv(term)     → list[SosacItem]           (via Gate)
• SosacClient.resolve(video_id)   → prémiová Streamuj.tv URL  (BYOC addon-side)

Search jde výhradně přes Gate (`/v1/sources/sosac/search`). Na selhání
Gate vyhodí `SosacError` — plugin.py to chytá a zobrazí modal. Žádný
legacy direct-JSON fallback.

`resolve()` zůstává addon-side — Streamuj.tv premium URL obsahuje
user credentials (BYOC pattern, stejně jako Webshare file_link).
"""
from __future__ import annotations

# ──────────────────────────────  IMPORTS  ──────────────────────────────────
import hashlib
import json
from dataclasses import dataclass
from typing import Dict, List
import urllib.error
import urllib.parse
import urllib.request

import xbmcaddon
import richmovie_settings  # SSOT čtení i ověřeného zápisu nastavení (3.5.124)
try:
    import xbmc
    _HAS_XBMC = True
except ImportError:
    _HAS_XBMC = False

from richmovie_gate_transport import GATE_URL as _GATE_URL
from richmovie_gate_transport import get_identity as _gate_get_identity


# ─────────────────────────────  KONSTANTY  ─────────────────────────────────
_STREAMUJ: str = "https://www.streamuj.tv/video/"
_ADDON         = xbmcaddon.Addon()
_TIMEOUT       = 8


# 3.4.x Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log_router = _make_legacy_logger("richmovie.sosac", "RichMovie/Sosac")
    def _log(msg: str) -> None:
        _log_router(msg)
except Exception:
    def _log(msg: str) -> None:
        if _HAS_XBMC:
            xbmc.log(f"[RichMovie/Sosac] {msg}", xbmc.LOGINFO)


# ─────────────────────────────  EXCEPTION  ─────────────────────────────────

class SosacError(Exception):
    """Gate-side Sosac operace selhala. Fail-fast, žádný fallback."""


# ────────────────────────  DATOVÉ TŘÍDY  ───────────────────────────────────
@dataclass
class SosacItem:
    """Jedna položka výsledků vyhledávání."""
    title:    str
    year:     int
    img:      str
    video_id: str


# ────────────────────────  GATE PROXY  ─────────────────────────────────────
def _gate_search(query: str, kind: str) -> List[Dict]:
    """Gate proxy pro Sosac search. Raises SosacError na jakékoliv selhání."""
    try:
        ws_username, ws_proof = _gate_get_identity()
    except Exception as exc:
        raise SosacError(f"Chybí RichMovie Gate identita: {exc}") from exc
    if not ws_username or not ws_proof:
        raise SosacError(
            "RichMovie Gate identita není nakonfigurovaná "
            "(chybí Webshare login v nastavení)."
        )

    qs = urllib.parse.urlencode({"q": query, "kind": kind})
    url = f"{_GATE_URL}/v1/sources/sosac/search?{qs}"
    try:
        av = _ADDON.getAddonInfo("version") or "dev"
    except Exception:
        av = "dev"
    headers = {
        "User-Agent":    f"RichMovie/{av} (+plugin.video.richmovie)",
        "Accept":        "application/json",
        "X-WS-Username": ws_username,
        "X-WS-Proof":    ws_proof,
    }
    # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. Vyhledávání je čtení,
    # takže je bezpečně opakovatelné. Timeout zůstává na `_TIMEOUT`.
    try:
        import richmovie_http as _rm_http
    except Exception as _imp_exc:  # pragma: no cover
        raise SosacError("richmovie_http neni k dispozici") from _imp_exc

    try:
        profile = _rm_http.profile_foreground().replace(timeout_s=float(_TIMEOUT))
        status, body, _hdrs = _rm_http.request(
            url, headers=headers, profile=profile, tag="sosac",
        )
        if status != 200:
            raise SosacError(f"Gate sosac/search vrátil HTTP {status}.")
    except SosacError:
        raise
    except _rm_http.TransientError as exc:
        raise SosacError(f"Nelze se připojit k RichMovie Gate: {exc}") from exc
    except Exception as exc:
        raise SosacError(f"Gate sosac/search error: {exc}") from exc

    try:
        data = json.loads(body.decode("utf-8", errors="replace"))
    except Exception as exc:
        raise SosacError(
            f"Gate sosac/search vrátil nevalidní JSON: {exc}"
        ) from exc
    if not isinstance(data, dict):
        raise SosacError(
            f"Gate sosac/search nečekaný typ: {type(data).__name__}"
        )
    if data.get("status") != "ok":
        err = data.get("error") or {}
        msg = err.get("message") if isinstance(err, dict) else str(err)
        raise SosacError(msg or f"Gate sosac/search status={data.get('status')!r}")

    items = data.get("items") or []
    if not isinstance(items, list):
        raise SosacError("Gate sosac/search: 'items' není list.")
    return items


def _gate_items_to_sosac(gate_items: List[Dict]) -> List[SosacItem]:
    """Gate response shape → SosacItem list. Drop-in addon kompatibilita."""
    out: List[SosacItem] = []
    for it in gate_items:
        if not isinstance(it, dict):
            continue
        try:
            out.append(SosacItem(
                title=str(it.get("title") or "Neznámý"),
                year=int(it.get("year") or 0),
                img=str(it.get("img") or ""),
                video_id=str(it.get("video_id") or ""),
            ))
        except Exception:
            continue
    return out


# ──────────────────────────  HLAVNÍ KLIENT  ────────────────────────────────
class SosacClient:
    """Mini-klient k Sosac.tv search (Gate-only) + BYOC resolve."""

    def __init__(self) -> None:
        self.user:     str = richmovie_settings.get_str("sosac_user").strip()
        self.password: str = richmovie_settings.get_str("sosac_pass").strip()
        self.location: str = richmovie_settings.get_str("sosac_location").strip()

    # ───── BYOC helpers (zůstávají addon-side — premium URL s credentials) ─
    def _double_md5(self, data: str) -> str:
        """Dvojité MD5 — vyžaduje server Streamuj.tv."""
        return hashlib.md5(
            hashlib.md5(data.encode()).hexdigest().encode()
        ).hexdigest()

    def _premium_url(self, video_id: str) -> str:
        """Sestaví Streamuj.tv premium URL s user credentials.

        Formát: https://www.streamuj.tv/video/<ID>?pass=USER:::HASH&location=N
        """
        params: list[str] = []
        if self.user and self.password:
            params.append(f"pass={self.user}:::{self._double_md5(self.password)}")
        if self.location in {"1", "2"}:
            params.append(f"location={self.location}")
        query = ("?" + "&".join(params)) if params else ""
        return f"{_STREAMUJ}{video_id}{query}"

    # ───── VEŘEJNÉ API ─────
    def search_movies(self, term: str) -> List[SosacItem]:
        """Hledá filmy přes Gate. Raises SosacError na selhání."""
        gate_items = _gate_search(term, "movie")
        items = _gate_items_to_sosac(gate_items)
        _log(f"search_movies: {term!r} → {len(items)} items")
        return items

    def search_tv(self, term: str) -> List[SosacItem]:
        """Hledá seriály přes Gate. Raises SosacError na selhání."""
        gate_items = _gate_search(term, "tv")
        items = _gate_items_to_sosac(gate_items)
        _log(f"search_tv: {term!r} → {len(items)} items")
        return items

    def resolve(self, video_id: str) -> str:
        """Vrátí Streamuj.tv URL s prémiovým tokenem (BYOC addon-side)."""
        return self._premium_url(video_id)
