# -*- coding: utf-8 -*-
"""
richmovie_cache_tuning.py — adaptivní Kodi filecache podle RAM zařízení (3.5.119, Φ4)
=====================================================================================

Proč
----
Kodi má default 20 MB vyrovnávací paměti streamu (`filecache.memorysize`). U 1080p
BluRay ripu (~8,6 MB/s) je to ~2 s videa — každé škytnutí CDN je vidět okamžitě.
Incident Zelňačka 23.08.2026 (`Handoff/INCIDENT_zelnacka_cdn_stall_20260823.md`).

Fakta (ověřeno ze zdrojů Kodi Omega 23.08.2026, viz plán 3.5.119 sekce FAKTA)
-----------------------------------------------------------------------------
• Od Kodi 20 je cache BĚŽNÉ nastavení (`filecache.memorysize` v MB,
  `filecache.readfactor` ×100), měnitelné za běhu přes JSON-RPC
  `Settings.SetSettingValue` — bez `advancedsettings.xml`, bez restartu.
• Povolené hodnoty memorysize (MB): 16 20 24 32 48 64 96 128 192 256 384 512 768
  1024; 0 = disk. Jiná hodnota → Kodi ji odmítne (`SettingOptionsMemorySizesFiller`).
• readfactor: 0 = adaptivní (Kodi vlastní algoritmus 4,0× → 1,5× podle naplnění),
  default 400 (= 4×). Adaptivní režim je vhodný pro nárazovou CDN.
• CFileCache alokuje ≈ 1× memorysize (front ¾ + back ¼); dvojitý buffer jen u
  READ_MULTI_STREAM (každý polovina). Wiki tvrzení „3× memorysize" pro Omega neplatí.

Politika (dokumentované konstanty, ne magie)
--------------------------------------------
cíl = RAM_SHARE × celková RAM, zaokrouhleno DOLŮ na povolenou hodnotu, clamp
[MIN_TARGET_MB, MAX_TARGET_MB]; zařízení pod LOW_RAM_THRESHOLD_MB dostanou
LOW_RAM_TARGET_MB (Android boxy / Fire stick s 1–2 GB).

Respekt k uživateli (SSOT = `cache_tuning_state.json` v addon_data)
------------------------------------------------------------------
Hodnota se mění JEN když aktuální hodnota v Kodi je (a) Kodi default, nebo
(b) přesně to, co jsme zapsali minule. Cokoli jiného = uživatel si nastavil sám
→ nesahat, zapsat `user_custom` a zalogovat. Opt-out: setting `cache_tuning_enabled`.

Bez Kodi závislostí v čisté logice (`choose_memory_size_mb`, `parse_memory_label`,
`decide`) — testováno v `_tools/net_resilience_sim` (scénář 29).
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from typing import Any, Dict, Optional

import xbmc
import xbmcaddon
import xbmcvfs

try:
    from richmovie_logging import make_legacy_logger as _ct_make_legacy_logger
    _log = _ct_make_legacy_logger("richmovie.cache_tuning", "RichMovie/CacheTuning")
except Exception:  # pragma: no cover — fallback mimo pipeline
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log("[RichMovie/CacheTuning] " + str(msg), level)
        except Exception:
            pass

# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY (zdroj: Kodi Omega, system/settings/settings.xml + ServicesSettings.cpp)
# ─────────────────────────────────────────────────────────────────────────────

SETTING_MEMORYSIZE = "filecache.memorysize"
SETTING_READFACTOR = "filecache.readfactor"

KODI_DEFAULT_MEMORYSIZE_MB = 20
KODI_DEFAULT_READFACTOR = 400          # ×100 → 4.0×
READFACTOR_ADAPTIVE = 0                # Kodi: readFactor < 1.0 → adaptivní režim

ALLOWED_MEMORY_SIZES_MB = (16, 20, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768, 1024)

RAM_SHARE = 0.02                       # 2 % celkové RAM
MIN_TARGET_MB = 64                     # i slabší PC/TV box snese ~3× Kodi default
# RAM cap = HORNÍ mez (≈60 s 1080p BluRay ripu). Incident gunžík 25.08.2026: RAM
# je špatná proxy pro kapacitu linky — 32 GB RAM + nejslabší linka ve flotile
# dostalo 512 MB buffer, jehož plnění (4×→1,5× bitrate) saturovalo linku většinu
# epizody. Plán Φ0b počítal s přechodným stropem 256 pro okno MEZI release —
# Φ1/Φ2 (3.5.127) se ale nasazují spolu s ním, a network cap chrání lépe: start
# 128 MB, růst jen na důkaz rezervy linky (`richmovie_cache_meter`), RAM cap
# zůstává stropem, ke kterému se roste. Cíl = min(RAM cap, network cap, Gate strop).
MAX_TARGET_MB = 512
LOW_RAM_THRESHOLD_MB = 1536            # pod 1,5 GB = levný Android box / stick
LOW_RAM_TARGET_MB = 48

STATE_FILE = "cache_tuning_state.json"
# v1 (3.5.119): applied / user_custom / ram_mb / addon_version / applied_at
# v2 (3.5.127, Φ1+Φ2): + samples (rolling okno měření plnění), network_cap
#    (řízení podle linky), last_change_ts (hystereze, až po VERIFIKOVANÉM apply),
#    last_decision. Migrace v1→v2 zachová applied/user_custom; poškozený state
#    = čistý start (richmovie_atomic karanténa + ERROR).
STATE_SCHEMA_VERSION = 2

# Výsledné akce `apply()` — jediné místo, kde jsou vyjmenované (log + harness).
ACTION_APPLIED = "applied"
ACTION_UNCHANGED = "unchanged"
ACTION_SKIPPED_DISABLED = "skipped_disabled"
ACTION_SKIPPED_USER_CUSTOM = "skipped_user_custom"
ACTION_SKIPPED_RAM_UNKNOWN = "skipped_ram_unknown"
ACTION_ERROR = "error"


# ─────────────────────────────────────────────────────────────────────────────
#  ČISTÁ LOGIKA (bez Kodi)
# ─────────────────────────────────────────────────────────────────────────────

_MEM_LABEL_RE = re.compile(r"(\d[\d\s.,]*)\s*([KMG]?B)?", re.IGNORECASE)


def parse_memory_label(label: str) -> Optional[int]:
    """„7876MB" / „15 880 MB" / „7.7GB" → MB. None = nerozpoznáno."""
    if not label:
        return None
    m = _MEM_LABEL_RE.search(str(label))
    if not m:
        return None
    digits = re.sub(r"[\s,]", "", m.group(1))
    try:
        value = float(digits)
    except ValueError:
        return None
    unit = (m.group(2) or "MB").upper()
    if unit == "GB":
        value *= 1024.0
    elif unit == "KB":
        value /= 1024.0
    elif unit == "B":
        value /= 1024.0 * 1024.0
    mb = int(value)
    return mb if mb > 0 else None


def choose_memory_size_mb(total_ram_mb: int) -> int:
    """Politika výběru velikosti cache (viz docstring modulu)."""
    if total_ram_mb < LOW_RAM_THRESHOLD_MB:
        return LOW_RAM_TARGET_MB
    target = total_ram_mb * RAM_SHARE
    target = max(MIN_TARGET_MB, min(MAX_TARGET_MB, target))
    # dolů na nejbližší povolenou hodnotu Kodi
    best = ALLOWED_MEMORY_SIZES_MB[0]
    for size in ALLOWED_MEMORY_SIZES_MB:
        if size <= target:
            best = size
    return best


def decide(*, current_memorysize: int, current_readfactor: int,
           previously_applied: Optional[Dict[str, int]],
           target_memorysize: int) -> Dict[str, Any]:
    """Rozhodne, co zapsat. Čistá funkce → testovatelná.

    Vrací {"action": …, "memorysize": int|None, "readfactor": int|None} —
    None = nesahat na tuto hodnotu.
    """
    prev_mem = (previously_applied or {}).get("memorysize")
    prev_rf = (previously_applied or {}).get("readfactor")

    mem_ours = current_memorysize in (KODI_DEFAULT_MEMORYSIZE_MB, prev_mem)
    rf_ours = current_readfactor in (KODI_DEFAULT_READFACTOR, prev_rf)

    if not mem_ours and not rf_ours:
        return {"action": ACTION_SKIPPED_USER_CUSTOM, "memorysize": None, "readfactor": None}

    new_mem = target_memorysize if (mem_ours and current_memorysize != target_memorysize) else None
    new_rf = READFACTOR_ADAPTIVE if (rf_ours and current_readfactor != READFACTOR_ADAPTIVE) else None

    if new_mem is None and new_rf is None:
        action = ACTION_UNCHANGED if (mem_ours and rf_ours) else ACTION_SKIPPED_USER_CUSTOM
        return {"action": action, "memorysize": None, "readfactor": None}
    return {"action": ACTION_APPLIED, "memorysize": new_mem, "readfactor": new_rf}


# ─────────────────────────────────────────────────────────────────────────────
#  KODI VRSTVA
# ─────────────────────────────────────────────────────────────────────────────

def _state_path() -> str:
    addon_id = xbmcaddon.Addon().getAddonInfo("id")
    profile = xbmcvfs.translatePath("special://profile/addon_data/{}".format(addon_id))
    return os.path.join(profile, STATE_FILE)


def _load_state() -> Dict[str, Any]:
    """Stav přes SSOT `richmovie_atomic` (3.5.123). Poškozený state = karanténa
    + ERROR + čistý start (plán v2 §1b: „poškozený state → čistý start").
    v1 → v2 migrace (3.5.127): zachová `applied`/`user_custom`, doplní prázdné
    okno vzorků a `network_cap=None` (= Φ2 se seeduje z evidence při dalším bootu)."""
    import richmovie_atomic as _atomic
    data, _state = _atomic.read_json(_state_path(), {}, name=STATE_FILE,
                                     expected_type=dict)
    if not isinstance(data, dict):
        return {}
    return migrate_state(data)


def migrate_state(data: Dict[str, Any]) -> Dict[str, Any]:
    """Čistá funkce (harness): libovolná verze → aktuální schéma."""
    try:
        version = int(data.get("schema_version") or 1)
    except (TypeError, ValueError):
        version = 1
    out = dict(data)
    if version < 2:
        out.setdefault("samples", [])
        out.setdefault("network_cap", None)
        out.setdefault("last_change_ts", None)
        out.setdefault("last_decision", "")
    if not isinstance(out.get("samples"), list):
        out["samples"] = []
    out["schema_version"] = STATE_SCHEMA_VERSION
    return out


def _save_state(state: Dict[str, Any]) -> bool:
    import richmovie_atomic as _atomic
    ok = _atomic.write_json(_state_path(), state, indent=1)
    if not ok:
        _log("state write failed", xbmc.LOGWARNING)
    return ok


def _rpc(method: str, params: Dict[str, Any]) -> Any:
    """JSON-RPC volání Kodi. Vrací `result`, nebo vyhodí RuntimeError s kódem."""
    payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        data = json.loads(raw or "{}")
    except ValueError as exc:
        raise RuntimeError("{}: invalid JSON-RPC response".format(method)) from exc
    if "error" in data:
        raise RuntimeError("{}: {}".format(method, data["error"]))
    return data.get("result")


def get_setting_value(setting_id: str) -> Optional[int]:
    result = _rpc("Settings.GetSettingValue", {"setting": setting_id})
    value = (result or {}).get("value") if isinstance(result, dict) else None
    try:
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def set_setting_value(setting_id: str, value: int) -> bool:
    result = _rpc("Settings.SetSettingValue", {"setting": setting_id, "value": int(value)})
    return result is True


def read_total_ram_mb() -> Optional[int]:
    try:
        return parse_memory_label(xbmc.getInfoLabel("System.Memory(total)"))
    except Exception:
        return None


def _enabled() -> bool:
    from richmovie_settings import get_bool
    return get_bool("cache_tuning_enabled")


def apply(addon_version: str = "") -> Dict[str, Any]:
    """Jednorázově při startu služby. Idempotentní, best-effort, nikdy nevyhazuje.

    Vrací slovník s `action` (viz ACTION_*) a detaily — loguje se na NAS.
    """
    result: Dict[str, Any] = {"action": ACTION_ERROR}
    try:
        if not _enabled():
            result["action"] = ACTION_SKIPPED_DISABLED
            _log("skipped: cache_tuning_enabled=false", xbmc.LOGINFO)
            return result

        ram_mb = read_total_ram_mb()
        if not ram_mb:
            result["action"] = ACTION_SKIPPED_RAM_UNKNOWN
            _log("skipped: System.Memory(total) unreadable", xbmc.LOGWARNING)
            return result

        ram_cap = choose_memory_size_mb(ram_mb)
        cur_mem = get_setting_value(SETTING_MEMORYSIZE)
        cur_rf = get_setting_value(SETTING_READFACTOR)
        if cur_mem is None or cur_rf is None:
            _log("skipped: filecache settings unreadable (Kodi < 20?)", xbmc.LOGWARNING)
            result["action"] = ACTION_ERROR
            return result

        state = _load_state()

        # Φ2 (3.5.127): cíl = min(RAM cap, network cap, serverový strop).
        # network_cap se rozhoduje JEN tady, při bootu služby, z rolling okna
        # vzorků naměřených na aktuálně aplikované velikosti (richmovie_cache_meter).
        # Bez evidence se seeduje (žádný plošný downgrade zdravých zařízení).
        import richmovie_cache_meter as _meter
        prev_applied = dict(state.get("applied") or {})
        # 0 = nic jsme ještě neaplikovali (čerstvé zařízení) → seed na výchozí
        # start; Kodi default 20 MB NENÍ „naše aplikovaná velikost".
        applied_mb = int(prev_applied.get("memorysize") or 0)
        gate_max = _gate_max_mb()
        network_cap, cap_reason = _meter.decide_network_cap(
            samples=list(state.get("samples") or []),
            applied_mb=applied_mb,
            network_cap=state.get("network_cap"),
            ram_cap=ram_cap,
            last_change_ts=state.get("last_change_ts"),
            now=time.time(),
            gate_max=gate_max,
        )
        target = min(ram_cap, int(network_cap))
        state["network_cap"] = int(network_cap)
        state["last_decision"] = cap_reason

        decision = decide(current_memorysize=cur_mem, current_readfactor=cur_rf,
                          previously_applied=state.get("applied"),
                          target_memorysize=target)
        result.update(decision)
        result.update({"ram_mb": ram_mb, "target_mb": target, "ram_cap_mb": ram_cap,
                       "network_cap_mb": int(network_cap), "gate_max_mb": gate_max,
                       "cap_reason": cap_reason,
                       "samples": len(state.get("samples") or []),
                       "current": {"memorysize": cur_mem, "readfactor": cur_rf}})

        if decision["action"] != ACTION_APPLIED:
            if decision["action"] == ACTION_SKIPPED_USER_CUSTOM and not state.get("user_custom"):
                # zalogovat jednou, ne při každém startu
                state["user_custom"] = {"memorysize": cur_mem, "readfactor": cur_rf,
                                        "noted_at": int(time.time())}
                _log("user-defined filecache values left untouched: memorysize={} readfactor={}"
                     .format(cur_mem, cur_rf), xbmc.LOGINFO,
                     context={"memorysize": cur_mem, "readfactor": cur_rf})
            # Rozhodnutí o network capu (seed/hold) se persistuje i bez zápisu do
            # Kodi — jinak by se seeding opakoval při každém bootu a `last_decision`
            # by nebylo v diagnostice vidět. `last_change_ts` se tu NEMĚNÍ.
            state["schema_version"] = STATE_SCHEMA_VERSION
            _save_state(state)
            return result

        applied = dict(state.get("applied") or {})
        # All-or-Nothing i pro EFEKT, ne jen marker (audit 23.08.2026 #3): když
        # druhý zápis selže, první se kompenzačně vrátí — jinak by naše hodnota
        # bez state souboru vypadala příště jako „user_custom" navždy.
        written = []   # (setting_id, previous_value)
        try:
            if decision["memorysize"] is not None:
                if not set_setting_value(SETTING_MEMORYSIZE, decision["memorysize"]):
                    raise RuntimeError("SetSettingValue({}) returned false".format(SETTING_MEMORYSIZE))
                written.append((SETTING_MEMORYSIZE, cur_mem))
                applied["memorysize"] = decision["memorysize"]
            if decision["readfactor"] is not None:
                if not set_setting_value(SETTING_READFACTOR, decision["readfactor"]):
                    raise RuntimeError("SetSettingValue({}) returned false".format(SETTING_READFACTOR))
                written.append((SETTING_READFACTOR, cur_rf))
                applied["readfactor"] = decision["readfactor"]

            # Marker až po ověřeném zápisu.
            verify_mem = get_setting_value(SETTING_MEMORYSIZE)
            verify_rf = get_setting_value(SETTING_READFACTOR)
            if (applied.get("memorysize", verify_mem) != verify_mem
                    or applied.get("readfactor", verify_rf) != verify_rf):
                raise RuntimeError("verification mismatch: memorysize={} readfactor={}"
                                   .format(verify_mem, verify_rf))
        except Exception:
            for setting_id, previous in reversed(written):
                try:
                    set_setting_value(setting_id, previous)
                except Exception as rollback_exc:
                    _log("rollback of {} failed: {!r}".format(setting_id, rollback_exc),
                         xbmc.LOGWARNING)
            raise

        # `last_change_ts` VÝHRADNĚ po verifikovaném apply se změnou velikosti
        # (v2, audit P6.2 — All-or-Nothing platí i pro marker hystereze). Vzorky
        # zůstávají v okně (jsou klíčované velikostí, pro novou se okno plní znovu).
        size_changed = decision["memorysize"] is not None and decision["memorysize"] != cur_mem
        state.update({
            "schema_version": STATE_SCHEMA_VERSION,
            "applied": applied,
            "ram_mb": ram_mb,
            "addon_version": addon_version,
            "applied_at": int(time.time()),
        })
        if size_changed:
            state["last_change_ts"] = int(time.time())
        _save_state(state)
        _log("applied filecache tuning: memorysize={}MB readfactor={} (ram={}MB, was {}/{}, "
             "network_cap={} reason={})"
             .format(applied.get("memorysize"), applied.get("readfactor"), ram_mb, cur_mem, cur_rf,
                     state.get("network_cap"), cap_reason),
             xbmc.LOGINFO,
             context={"ram_mb": ram_mb, "memorysize": applied.get("memorysize"),
                      "readfactor": applied.get("readfactor"),
                      "network_cap": state.get("network_cap"), "cap_reason": cap_reason,
                      "gate_max": gate_max,
                      "previous": {"memorysize": cur_mem, "readfactor": cur_rf}})
        return result
    except Exception as exc:
        result["action"] = ACTION_ERROR
        result["detail"] = repr(exc)[:200]
        _log("apply failed: {!r}".format(exc), xbmc.LOGWARNING)
        return result


def _gate_max_mb() -> Optional[int]:
    """Serverový strop z Gate cache (`config.cache_tuning_max_mb`) — POUZE BRZDA.
    Best-effort: bez Gate cache / starý Gate → None = bez clampu."""
    try:
        import richmovie_gate
        return richmovie_gate.get_cache_tuning_max_mb()
    except Exception:
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  Φ1 — MĚŘENÍ PLNĚNÍ CACHE (běží ve službě, čistá logika v richmovie_cache_meter)
# ─────────────────────────────────────────────────────────────────────────────

# Zámek read-modify-write nad state souborem. Cross-check Pro 31.08. (P1):
# atomický zápis chrání před roztrženým souborem, ne před ztracenou AKTUALIZACÍ
# dvou souběžných čtení-úprav-zápisů. Stav mění JEN proces služby (apply při
# bootu, record_sample z player callbacků) — zámek vláken v tomto procesu stačí;
# plugin proces state nezapisuje.
_STATE_LOCK = threading.Lock()


def record_sample(sample: Dict[str, Any]) -> bool:
    """Přidá vzorek do rolling okna state souboru (atomicky) a pošle ho jako
    telemetrii do `user_logs` (source richmovie.cache_tuning, strukturovaný
    context). Žádná nová Gate tabulka, žádná změna wire schématu (plán §1b)."""
    import richmovie_cache_meter as _meter
    try:
        with _STATE_LOCK:
            state = _load_state()
            state["samples"] = _meter.append_sample(state.get("samples") or [], sample)
            state["schema_version"] = STATE_SCHEMA_VERSION
            ok = _save_state(state)
        _log("fill sample kind={} ratio={} fill_s={} level_max={} M={} B={}".format(
            sample.get("kind"), sample.get("fill_ratio"), sample.get("fill_s"),
            sample.get("level_max"), sample.get("memorysize_applied"),
            sample.get("bitrate_bps")), xbmc.LOGINFO, context=dict(sample))
        return ok
    except Exception as exc:
        _log("record_sample failed: {!r}".format(exc), xbmc.LOGWARNING)
        return False


def current_applied_memorysize_mb() -> int:
    """Velikost cache, na které se měří: naše aplikovaná (state), jinak aktuální
    hodnota Kodi (uživatelova / default). 0 = neznámá → měření se přeskočí."""
    try:
        state = _load_state()
        applied = int((state.get("applied") or {}).get("memorysize") or 0)
        if applied > 0:
            return applied
        return int(get_setting_value(SETTING_MEMORYSIZE) or 0)
    except Exception:
        return 0


def start_fill_meter(player: Any, monitor: Any, *, source: str,
                     size_bytes: int, duration_s: float, start_pos_s: float,
                     generation_alive: Any, on_finished: Any = None) -> Optional[Any]:
    """Spustí dedikovaný 2s sampler `Player.CacheLevel` pro jedno přehrávání.

    Vlákno je daemon (NEposílá HTTP — jen čte InfoLabel; viz
    feedback_daemon_threads_kodi) a v každém tiku kontroluje abort i generaci
    (`generation_alive()` → False = jiné přehrávání převzalo player). Smyčka
    skončí naplněním, zneplatněním (pauza/seek) nebo koncem přehrávání; VZOREK
    uzavírá VOLAJÍCÍ (`tracker.finish(...)` v player callbacku), protože jen on
    ví, JAK přehrávání skončilo (Stop / Ended / UNEXPECTED_EOF). `on_finished`
    je volitelný hook pro diagnostiku.
    Vrací `FillTracker` (i neeligible — kvůli diagnostice), nebo None při chybě.
    """
    import threading
    import richmovie_cache_meter as _meter
    try:
        if not _enabled():
            return None
        mem = current_applied_memorysize_mb()
        tracker = _meter.FillTracker(
            memorysize_mb=mem,
            bitrate=_meter.bitrate_bps(size_bytes, duration_s),
            duration_s=duration_s, start_pos_s=start_pos_s,
            source=source, started_at=time.time(),
        )
        if not tracker.eligible:
            _log("fill meter skipped: {}".format(tracker.ineligible_reason), xbmc.LOGDEBUG,
                 context={"reason": tracker.ineligible_reason, "source": source,
                          "size_bytes": size_bytes, "duration_s": duration_s})
            return tracker

        def _loop() -> None:
            try:
                while not monitor.abortRequested() and generation_alive():
                    if monitor.waitForAbort(_meter.TICK_S):
                        break
                    if not generation_alive():
                        break
                    try:
                        raw = xbmc.getInfoLabel("Player.CacheLevel")
                        level = float(str(raw).strip().rstrip("%")) if str(raw).strip() else None
                    except Exception:
                        level = None
                    try:
                        paused = bool(xbmc.getCondVisibility("Player.Paused"))
                    except Exception:
                        paused = False
                    try:
                        pos = float(player.getTime())
                    except Exception:
                        pos = None
                    tracker.feed(now=time.time(), level_pct=level, paused=paused,
                                 playing_time_s=pos)
                    if tracker.fill_s is not None or tracker.invalidated:
                        break
            finally:
                if on_finished is not None:
                    try:
                        on_finished(tracker)
                    except Exception as exc:
                        _log("fill meter on_finished failed: {!r}".format(exc), xbmc.LOGWARNING)

        threading.Thread(target=_loop, name="RMCacheMeter", daemon=True).start()
        return tracker
    except Exception as exc:
        _log("start_fill_meter failed: {!r}".format(exc), xbmc.LOGWARNING)
        return None
