# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_recommendations.py
# Addon-side client for /v1/ai/recommendations/* endpoints + Kodi UI helpers.
# Phase E (RichMovie 3.1.0) — AI Personalized Recommendations feature.
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie 3.1.0 — Addon-side recommendations module

API:
    fetch_recommendations(limit=10, offset=0) -> dict
        GET /v1/ai/recommendations/list

    record_click(recommendation_id, search_query=None) -> bool
        POST /v1/ai/recommendations/click

    request_regenerate() -> dict
        POST /v1/ai/recommendations/regenerate (1×/24h gate enforced server-side)

    delete_all(confirm=True) -> dict
        POST /v1/ai/recommendations/delete (GDPR)

    build_listitem(rec) -> tuple[str, xbmcgui.ListItem, bool]
        Convert recommendation dict to a Kodi listing entry. Plot+poster+
        rating populated from rec data; click handler routes back into
        plugin.py via plugin:// URL with action=open_recommendation.

UI integration:
    plugin.py registers a top-level menu entry "Doporučení přesně pro Vás"
    under "Hledat seriál". When activated, plugin.py calls show_listing()
    which fetches → builds listitems → addDirectoryItem on each.

Design notes:
    - Reasoning text shown in Kodi info panel (full plot field) — per
      Section 9 decision B. List label = title only + diversity_role badge.
    - Click on a recommendation triggers a regular movie/tv search in plugin
      so user gets the existing stream-selection flow. record_click() is
      called as a side effect for closed-loop telemetry.
    - GDPR delete confirmation = double-confirm dialog per Section 9 #C.

Author: Richie (autonomous Phase E implementation 2026-04-25)
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import urllib.parse
from typing import Any

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import richmovie_routes as _routes
import richmovie_feedback as _fb  # Φ2 (29.09.2026): SSOT okamžité odezvy
import richmovie_playback_dispatch as _rm_dispatch  # 4.0.1: Container.Refresh jen přes bránu (pád Kodi 09.10.2026)

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

_LOG_PREFIX = "[RichMovie.recommendations]"

# 2026-07-01 (observability program): logy AI doporučení (chyby list/click/regenerate
# z Gate) přepnuty z přímého xbmc.log na ROUTOVANÝ logger → tečou na NAS (Gate).
try:
    from richmovie_logging import make_legacy_logger as _rec_make_legacy_logger
    _log = _rec_make_legacy_logger("richmovie.recommendations", "RichMovie/Recommendations")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log(_LOG_PREFIX + " " + str(msg), level)
        except Exception:
            pass

# Diversity role → UI badge text. Kodi label colour markup (BBCode-style)
# kept compact so listing rows don't bloat. Color codes match Estuary skin.
# 3.5.132 (Richie 05.09.2026: „nevím co je cz pick, co je discovery, před cz pick
# random znaky"): česky, srozumitelně, a jen glyfy, které font Kodi (Estuary)
# umí — regional-indicator vlajka a ✨ se kreslily jako prázdné čtverce.
# R3 (3.5.156, Gate mig 0036): sekce seznamu. SSOT pořadí + popisků; položka bez `section`
# (starší dávka / starší Gate) patří do „Pro tebe". Hlavičky se kreslí jen při ≥ 2 sekcích.
SECTION_ORDER = ("for_you", "discover", "background")
SECTION_LABELS = {
    "for_you": "[COLOR FF66BB66]▶ Pro tebe[/COLOR]",
    "discover": "[COLOR FFFFAA33]🧭 Objev[/COLOR]",
    "background": "[COLOR FF9FA8DA]🌙 Na usnutí[/COLOR]",
}
SECTION_PLOTS = {
    "for_you": "Tituly, které sedí na tvůj vkus podle toho, co sleduješ se zájmem.",
    "discover": "Záměrně něco mimo tvé obvyklé žánry a české tipy.",
    "background": "Něco na usnutí — podobné seriálům, které ti běží v noci jako kulisa. Neovlivňuje profil vkusu.",
}


def group_by_section(items):
    """Čistá: [(section, [rec, …]), …] v pořadí SECTION_ORDER, jen neprázdné; neznámá/chybějící
    sekce = for_you. Pořadí položek uvnitř sekce zůstává (rank)."""
    buckets = {sec: [] for sec in SECTION_ORDER}
    for rec in items or []:
        if not isinstance(rec, dict):
            continue
        sec = rec.get("section") if rec.get("section") in SECTION_ORDER else "for_you"
        buckets[sec].append(rec)
    return [(sec, buckets[sec]) for sec in SECTION_ORDER if buckets[sec]]


_DIVERSITY_BADGES = {
    "primary":      "[COLOR FF66BB66]Pro tebe[/COLOR]",
    "discovery":    "[COLOR FFFFAA33]Objev mimo tvé žánry[/COLOR]",
    "czech_boost":  "[COLOR FFD42A2A]Český tip[/COLOR]",
    "pool_fill":    "[COLOR FF8899AA]Výběr podle tvého vkusu[/COLOR]",   # doplněno z poolu (Gate Φ5a, mig 0028)
}

# Token bucket for click-rate limiting (avoid double-fire on Kodi re-render)
_CLICK_DEDUP_SECONDS = 90


# ─────────────────────────────────────────────────────────────────────────────
#  GATE CLIENT
# ─────────────────────────────────────────────────────────────────────────────

def _gate_call(method: str, path: str, *,
                body: dict[str, Any] | None = None,
                params: dict[str, Any] | None = None,
                timeout: float = 30.0) -> tuple[int, dict[str, Any]]:
    """Wrapper around richmovie_gate_transport.post_json / urllib GET."""
    try:
        from richmovie_gate_transport import (
            post_json, get_identity, build_common_fields, GATE_URL,
        )
    except ImportError as exc:
        _log(f"gate transport import failed: {exc!r}",
                 xbmc.LOGERROR)
        return 503, {"error": {"code": "transport_unavailable"}}

    if method == "POST":
        username, _ = get_identity()
        if not username:
            return 401, {"error": {"code": "no_identity"}}
        full_body = dict(body or {})
        full_body.update(build_common_fields())  # ws_username, ws_proof
        try:
            return post_json(path, full_body, timeout=timeout)
        except Exception as exc:
            return 599, {"error": {"code": "transport_fail", "detail": repr(exc)}}

    if method == "GET":
        username, proof = get_identity()
        if not username:
            return 401, {"error": {"code": "no_identity"}}
        # Φ7 (29.09.2026): identita v hlavičce `Authorization: RM-Proof` (SSOT `gate_transport.auth_header`),
        # ne v URL — proof by jinak ležel v logu Cloudflare i proxy (Gate query přijímá jen kvůli starým addonům)
        qp = dict(params or {})
        # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. GET větev je čtení
        # seznamu doporučení — bezpečně opakovatelné. POST větev výše (zpětná
        # vazba / regenerace) zůstává bez retry, protože zapisuje.
        # Kontrakt návratu `(status, dict)` zůstává beze změny.
        try:
            import richmovie_http as _rm_http
            url = "{}{}?{}".format(GATE_URL, path, urllib.parse.urlencode(qp))
            profile = _rm_http.profile_foreground().replace(timeout_s=float(timeout))
            from richmovie_gate_transport import auth_header as _auth_header, gate_headers as _gate_headers
            _hdrs_out = _gate_headers()
            _hdrs_out.update(_auth_header(username, proof))
            status, raw, _hdrs = _rm_http.request(
                url, headers=_hdrs_out, profile=profile, tag="recs",
            )
            try:
                text = raw.decode("utf-8") if raw else ""
                parsed = json.loads(text) if text else {}
            except Exception:
                parsed = {"error": {"code": "http_%s" % status}}
            return status, parsed
        except Exception as exc:
            return 599, {"error": {"code": "transport_fail", "detail": repr(exc)}}

    return 405, {"error": {"code": "method_not_allowed"}}


# ─────────────────────────────────────────────────────────────────────────────
#  PUBLIC API
# ─────────────────────────────────────────────────────────────────────────────

def fetch_recommendations(limit: int = 10, offset: int = 0) -> dict[str, Any]:
    """GET /v1/ai/recommendations/list. Returns raw response dict.

    On error returns {"error": {...}, "items": []} to allow caller to
    render an empty listing with a friendly error message.
    """
    params: dict[str, Any] = {"limit": limit, "offset": offset}
    _pid = _profile_id()
    if _pid:
        params["profile_id"] = _pid
    else:
        try:
            import richmovie_profile as _rp
            if _rp.is_multi():   # Host / nevybráno: žádná doporučení účtu (D12, Fable P2-8)
                return {"error": {"code": "no_profile"}, "items": []}
        except Exception:
            pass
    status, body = _gate_call("GET", "/v1/ai/recommendations/list", params=params)
    if status == 200 and isinstance(body, dict):
        return body
    _log(f"list fetch failed: {status} {body}", xbmc.LOGWARNING)
    return {"error": body.get("error") or {"code": f"http_{status}"}, "items": []}


REASON_NOT_INTERESTED = "not_interested"   # „Nezajímá mě" — 180 dní mimo doporučení
REASON_ALREADY_SEEN = "already_seen"       # „Už jsem to viděl" — navždy mimo (3.5.152, Gate mig 0032)


def dismiss_recommendation(recommendation_id: int, *, reason: str = REASON_NOT_INTERESTED) -> dict[str, Any]:
    """POST /v1/ai/recommendations/dismiss — „Nezajímá mě" (3.5.131, plán R6) / „Už jsem to viděl"
    (3.5.152, `reason`). Vrací raw odpověď Gate; `{"ok": False, "error": ...}` při selhání."""
    status, body = _gate_call("POST", "/v1/ai/recommendations/dismiss", body={
        "recommendation_id": int(recommendation_id),
        "reason": reason,
    })
    if status == 200 and isinstance(body, dict):
        return body
    _log(f"dismiss failed: {status} {body}", xbmc.LOGWARNING)
    return {"ok": False, "error": (body or {}).get("error") or {"code": f"http_{status}"}}


def should_record_click(recommendation_id: int, *, is_mi2_refresh: bool, is_reentry: bool) -> bool:
    """Je tohle SKUTEČNÝ klik uživatele? (čistá funkce, harness scénář 64)

    Akce `open_recommendation` se spouští i bez kliku: `Container.Refresh` od MI2
    a návrat do seznamu (Zpět z přehrávání) ji zavolají znovu se stejným URL.
    Do 3.5.152 se tím jeden klik započítal až třikrát.
    """
    try:
        rid = int(recommendation_id)
    except (TypeError, ValueError):
        return False
    return rid > 0 and not is_mi2_refresh and not is_reentry


def _opened_prop(recommendation_id: int) -> str:
    return "richmovie.rec.opened.%d" % int(recommendation_id)


def note_opened(recommendation_id: int) -> bool:
    """Zapíše „doporučení je otevřené" a vrátí, jestli UŽ otevřené bylo (= návrat, ne klik).

    Marker žije, dokud uživatel neuvidí znovu SEZNAM doporučení (`forget_opened` ve
    `show_listing`): návrat z přehrávání do výpisu streamů seznamem neprochází, nový
    klik ano. Marker „do restartu Kodi" by druhý záměrný klik po hodinách zahodil
    (cross-check Pro Q5, noc 19.→20.09.2026).
    """
    try:
        rid = int(recommendation_id)
        if rid <= 0:
            return False
        win = xbmcgui.Window(10000)
        if win.getProperty(_opened_prop(rid)):
            return True
        win.setProperty(_opened_prop(rid), "1")
    except Exception as exc:
        _log("note_opened failed: %r" % (exc,), xbmc.LOGWARNING)
    return False


def forget_opened(recommendation_ids) -> None:
    """Uživatel je zpátky v seznamu → další otevření kteréhokoli řádku je skutečný klik."""
    try:
        win = xbmcgui.Window(10000)
        for rid in recommendation_ids:
            try:
                win.clearProperty(_opened_prop(int(rid)))
            except (TypeError, ValueError):
                continue
    except Exception as exc:
        _log("forget_opened failed: %r" % (exc,), xbmc.LOGWARNING)


def record_click(recommendation_id: int, search_query: str | None = None) -> bool:
    """POST /v1/ai/recommendations/click. Best-effort — failure is non-fatal.

    Dedup je MEZIPROCESOVY (`richmovie_guard.note_once`). Modulovy dict, ktery
    tu byl do 3.5.152, v Kodi nikdy nefungoval: kazda invokace pluginu je novy
    interpret, takze `_recent_click_window` bylo vzdycky prazdne a kazdy
    `Container.Refresh` od MI2 poslal tentyz klik na Gate znovu
    (incident Sony 19.09.2026 - 3 invokace `open_recommendation` na jeden klik).
    """
    _dedup_token = None
    try:
        import richmovie_guard as _guard
        _dedup_token = _guard.note_once("rec_click.%d" % int(recommendation_id),
                                        _CLICK_DEDUP_SECONDS)
        if _dedup_token is None:
            return True  # uz odeslano v tomhle okne
    except Exception as _dedup_err:
        # Guard nesmi zablokovat telemetrii kliku; horsi pripad = duplicitni klik.
        _log("click dedup unavailable: %s" % (_dedup_err,), xbmc.LOGDEBUG)

    status, body = _gate_call("POST", "/v1/ai/recommendations/click", body={
        "recommendation_id": int(recommendation_id),
        "triggered_search_query": search_query,
    })
    if status != 200:
        _log(f"click record failed: {status} {body}",
                 xbmc.LOGWARNING)
        # Dedup okno se otevřelo PŘED POSTem (jinak by souběžné invokace poslaly
        # klik dvakrát). Když POST selhal, okno se zase zavírá, ať se klik neztratí
        # až do vypršení TTL (audit Fable).
        try:
            if _dedup_token:
                import richmovie_guard as _guard
                _guard.forget("rec_click.%d" % int(recommendation_id), _dedup_token)
        except Exception:
            pass
        return False
    return True


def _profile_id():
    """Profily (3.5.134): doporučení jsou per profil; None u single/unset/Host."""
    try:
        import richmovie_profile
        return richmovie_profile.telemetry_profile_id()
    except Exception:
        return None


def request_regenerate() -> dict[str, Any]:
    """POST /v1/ai/recommendations/regenerate. Server enforces 24h gate (per profil)."""
    _pid = _profile_id()
    status, body = _gate_call("POST", "/v1/ai/recommendations/regenerate",
                              body=({"profile_id": _pid} if _pid else {}))
    if status == 200 and isinstance(body, dict):
        return body
    _log(f"regenerate failed: {status} {body}", xbmc.LOGWARNING)
    return {"ok": False, "queued": False, "reason": f"http_{status}"}


def delete_all(confirm: bool = True) -> dict[str, Any]:
    """POST /v1/ai/recommendations/delete. GDPR right-to-be-forgotten.

    `confirm=True` matches server requirement (server schema enforces
    confirm == "YES_DELETE_ALL"). Caller MUST present a double-confirm
    dialog before invoking.
    """
    if not confirm:
        return {"ok": False, "reason": "not_confirmed"}
    status, body = _gate_call("POST", "/v1/ai/recommendations/delete", body={
        "confirm": "YES_DELETE_ALL",
    })
    if status == 200 and isinstance(body, dict):
        return body
    return {"ok": False, "reason": f"http_{status}"}


# ─────────────────────────────────────────────────────────────────────────────
#  Kodi listing rendering — show_listing() invoked from plugin.py router
# ─────────────────────────────────────────────────────────────────────────────

_TMDB_IMG_BASE = "https://image.tmdb.org/t/p"


def _build_listitem(rec: dict[str, Any], handle: int, addon_id: str) -> tuple[str, xbmcgui.ListItem, bool]:
    """Build (url, listitem, isFolder) for one recommendation.

    Click target: plugin://<id>/?action=open_recommendation&recommendation_id=<id>&...
    """
    title = rec.get("title_cs") or "(bez názvu)"
    year = rec.get("year")
    label_main = f"{title} ({year})" if year else title
    if rec.get("kind") == "tv":
        label_main += " [I][seriál][/I]"
    # ★ hodnocení (TMDb) vpředu — stejný vzor jako TV tipy, TOP 1000 a Chci vidět.
    rating = rec.get("rating")
    rating_txt = (
        "[B][COLOR gold]★ {:.1f}[/COLOR][/B]  ".format(float(rating))
        if isinstance(rating, (int, float)) and rating > 0 else ""
    )
    badge = _DIVERSITY_BADGES.get(rec.get("diversity_role", "primary"), "")
    label = f"{rating_txt}{label_main}    {badge}".strip() if badge else f"{rating_txt}{label_main}"
    # 3.5.152: film mezitím dokoukaný / označený ✔ (lokální stav profilu) — Gate ho příště vyloučí,
    # do té doby ať je vidět, že je viděný; vlastní hodnocení ★ se ukáže také.
    seen_locally = False
    own_rating = None
    try:
        import richmovie_history as _rh
        import richmovie_ratings as _rt
        if rec.get("kind") != "tv" and rec.get("tmdb_id"):
            seen_locally = _rh.watched_movie_contains(rec.get("tmdb_id"))
        own = _rt.get(rec.get("kind") or "movie", rec.get("tmdb_id"))
        own_rating = own["rating"] if own else None
    except Exception:
        pass
    if own_rating:
        label = _rt.decorate_label(label, rec.get("kind") or "movie", rec.get("tmdb_id"))
    elif seen_locally:
        label = "[COLOR lime]✔[/COLOR] " + label

    li = xbmcgui.ListItem(label=label)

    # Build full plot from reasoning + AI metadata + TMDb overview
    plot_lines = []
    reason = rec.get("reason_cs") or ""
    if reason:
        plot_lines.append("[B]✨ Proč právě toto:[/B]")
        plot_lines.append(reason)
        plot_lines.append("")
    overview = rec.get("overview_cs") or ""
    if overview:
        plot_lines.append("[B]Děj:[/B]")
        plot_lines.append(overview)
        plot_lines.append("")
    extras = []
    score = rec.get("score")
    if isinstance(score, (int, float)):
        extras.append(f"AI skóre: [B]{score:.2f}[/B]")
    rating = rec.get("rating")
    if isinstance(rating, (int, float)) and rating > 0:
        extras.append(f"TMDb: [B]{rating:.1f}[/B]")
    runtime = rec.get("runtime")
    if isinstance(runtime, int) and runtime > 0:
        extras.append(f"{runtime} min")
    # Persona label (3.1.0 polish A3, 2026-04-26): server-side enriched
    # human-readable label like "Pracovní večer — Drama" instead of internal
    # "persona_0" ID. Fallback to raw persona_target if label missing.
    persona_label = rec.get("persona_label") or rec.get("persona_target")
    if persona_label:
        extras.append(f"Pro: {persona_label}")
    if extras:
        plot_lines.append(" · ".join(extras))
    plot = "\n".join(plot_lines).strip() or "Doporučení přesně pro Vás."

    info: dict[str, Any] = {
        "title": title,
        "originaltitle": title,
        "year": year,
        "plot": plot,
        "plotoutline": reason[:200] if reason else "",
        "mediatype": "tvshow" if rec.get("kind") == "tv" else "movie",
    }
    if isinstance(rating, (int, float)) and rating > 0:
        info["rating"] = float(rating)
    if isinstance(runtime, int) and runtime > 0:
        info["duration"] = runtime * 60
    try:
        li.setInfo("video", info)
    except Exception:
        pass

    # TMDb art (poster + backdrop) — server-enriched in /list response.
    poster_path = rec.get("poster_path")
    backdrop_path = rec.get("backdrop_path")
    art = {}
    if poster_path:
        art["poster"] = f"{_TMDB_IMG_BASE}/w500{poster_path}"
        art["thumb"]  = f"{_TMDB_IMG_BASE}/w342{poster_path}"
        art["icon"]   = f"{_TMDB_IMG_BASE}/w185{poster_path}"
    if backdrop_path:
        art["fanart"]    = f"{_TMDB_IMG_BASE}/original{backdrop_path}"
        art["landscape"] = f"{_TMDB_IMG_BASE}/w780{backdrop_path}"
    if art:
        try:
            li.setArt(art)
        except Exception:
            pass

    # 3.5.131: Gate /list vrací `id` řádku (dřív se posílal `rank` jako
    # recommendation_id → /click hledal id 1..10 → 404 → klik se nikdy nezapsal).
    rec_id = rec.get("id") or 0
    base = f"plugin://{addon_id}/"
    qp = {
        "action": "open_recommendation",
        "recommendation_id": str(rec_id),
        "tmdb_id": str(rec.get("tmdb_id", "")),
        "kind": rec.get("kind", "movie"),
        "title": title,
    }
    url = base + "?" + urllib.parse.urlencode(qp)

    # Kontextové menu (3.5.152, Petra 16.09.: „v doporučení spoustu filmů už viděla"):
    #   „Už jsem to viděl ✔" PRVNÍ — film dostane ✔ napříč zařízeními a z doporučení zmizí navždy,
    #   „Ohodnotit ★" — hodnocení pro AI (i bez ČSFD), „Nezajímá mě" — 180 dní mimo.
    if rec_id:
        common = {"recommendation_id": str(rec_id), "title": title,
                  "tmdb_id": str(rec.get("tmdb_id") or ""), "kind": rec.get("kind") or "movie"}
        seen_url = base + "?" + urllib.parse.urlencode(dict(common, action="seen_recommendation"))
        rate_url = base + "?" + urllib.parse.urlencode(dict(common, action="rate_title"))
        dismiss_url = base + "?" + urllib.parse.urlencode(dict(common, action="dismiss_recommendation"))
        try:
            li.addContextMenuItems([
                ("Už jsem to viděl ✔", f"RunPlugin({seen_url})"),
                ("Ohodnotit ★", f"RunPlugin({rate_url})"),
                ("Nezajímá mě", f"RunPlugin({dismiss_url})"),
            ])
        except Exception:
            pass

    # isFolder=True — KLÍČOVÉ. Cíl (`action=open_recommendation`) staví ADRESÁŘ
    # nalezených streamů (`_auto_search_movie` → `_list_releases`), ne přehrávatelný
    # soubor. Do 3.5.153 tu bylo `isFolder=False` + `IsPlayable=false`, což je pro
    # Kodi „ani složka, ani k přehrání": klik proto NEOTEVŘEL navigaci do adresáře
    # (`CGUIMediaWindow::GetDirectory` se vůbec nezavolalo), plugin postavil seznam
    # a poslal `endOfDirectory` do handle, který žádné okno nekonzumuje.
    #
    # Následek: seznam streamů se po kliknutí na doporučení NIKDY nezobrazil.
    # Nikomu, od zavedení doporučení v 3.1.0. Prokázáno 19.09.2026 třemi cestami:
    #   1) Kodi debug log — `GetDirectory` je pro `?action=show_recommendations`,
    #      ale pro `?action=open_recommendation` chybí;
    #   2) plugin hlásil `phase=end ok=True` s 34 položkami, a kontejner se jím
    #      ani po 2 s nestal (`LISTING_NOT_LANDED`);
    #   3) Gate: 7 kliků od JEDNOHO člověka za 5 měsíců napříč celou flotilou.
    #
    # `IsPlayable` se u složky nenastavuje — Kodi si u `isFolder=True` řídí chování samo.
    # Hodnota jde z REGISTRU ROUT, ne z literálu — literál tu pět měsíců lhal.
    return url, li, _routes.is_folder("open_recommendation")


def show_listing(handle: int, addon: xbmcaddon.Addon) -> None:
    """Render the "Doporučení přesně pro Vás" directory listing.

    Called from plugin.py router on action=show_recommendations. Fetches
    list from Gate, builds Kodi list items, populates the directory.
    """
    addon_id = addon.getAddonInfo("id")
    with _fb.working("Načítám doporučení…"):   # Φ2: SSOT průběhu (bez bliknutí u rychlé odpovědi)
        data = fetch_recommendations(limit=10, offset=0)

    items = data.get("items") or []

    if not items:
        # Empty state — show single "no items" entry + regenerate option
        err_code = (data.get("error") or {}).get("code") if data.get("error") else None
        if err_code == "no_identity":
            msg = "Pro AI doporučení je nutné se přihlásit a propojit Webshare účet."
        elif err_code == "no_profile":
            msg = "Host nemá doporučení — vyber svůj profil (Dívá se: … v hlavním menu)."
        elif err_code:
            msg = f"Doporučení dočasně nedostupná ({err_code})."
        else:
            msg = ("Doporučení se připravují. První batch se generuje "
                   "po ~24 hodinách aktivity. Můžeš zkusit ručně "
                   "vygenerovat (max 1× za 24h).")

        empty_li = xbmcgui.ListItem(label="[COLOR FFAAAAAA]" + msg + "[/COLOR]")
        empty_li.setInfo("video", {"plot": msg})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=f"plugin://{addon_id}/?action=regenerate_recommendations",
            listitem=empty_li,
            isFolder=_routes.is_folder("regenerate_recommendations"),
        )
    else:
        # 3.5.131: hlavička = jediný (poslední) batch — uživatel vidí, z kdy
        # doporučení jsou a že se každou noc/týden obměňují (dřív se zobrazovaly
        # všechny batche za 14 dní naráz → „5× Silo").
        header = _batch_header_label(data)
        if header:
            head_li = xbmcgui.ListItem(label=header)
            head_li.setInfo("video", {"plot": (
                "Doporučení se generují v noci z tvé historie sledování, hodnocení a "
                "„Chci vidět“ na ČSFD. Každá dávka obsahuje jen NOVÉ tituly — nic, co jsi "
                "viděl, hodnotil, dostal doporučeno v posledních 45 dnech nebo označil "
                "„Nezajímá mě“ (kontextové menu).\n\n"
                "Sekce: „Pro tebe“ = sedí na tvůj vkus · „Objev“ = záměrně mimo tvé žánry a české tipy · "
                "„Na usnutí“ = podobné seriálům, které ti běží v noci jako kulisa (neovlivňuje profil vkusu). "
                "★ = hodnocení TMDb, proč právě tento titul najdeš v popisu položky."
            )})
            head_li.setArt({"icon": "DefaultAddonService.png", "thumb": "DefaultAddonService.png"})
            # isFolder=True: klik = znovu otevřít výpis (refresh), ne přehrávání.
            xbmcplugin.addDirectoryItem(
                handle=handle,
                url=f"plugin://{addon_id}/?action=show_recommendations",
                listitem=head_li, isFolder=_routes.is_folder("show_recommendations"),
            )
        forget_opened(rec.get("id") for rec in items if isinstance(rec, dict))
        groups = group_by_section(items)
        for sec, recs in groups:
            # hlavička při více sekcích, a VŽDY u sekce mimo „Pro tebe" (jediná „Na usnutí" bez
            # hlavičky by vypadala jako běžný výběr — cross-check Pro B 4)
            if len(groups) > 1 or sec != "for_you":
                sec_li = xbmcgui.ListItem(label=SECTION_LABELS[sec])
                sec_li.setInfo("video", {"plot": SECTION_PLOTS[sec]})
                sec_li.setArt({"icon": "DefaultAddonService.png", "thumb": "DefaultAddonService.png"})
                xbmcplugin.addDirectoryItem(
                    handle=handle, url=f"plugin://{addon_id}/?action=noop",
                    listitem=sec_li, isFolder=_routes.is_folder("noop"),
                )
            for rec in recs:
                url, li, is_folder = _build_listitem(rec, handle, addon_id)
                xbmcplugin.addDirectoryItem(
                    handle=handle, url=url, listitem=li, isFolder=is_folder,
                )

        # Append manual regenerate footer (rate-limited 1×/24h server-side)
        regen_label = "[COLOR FF888888]↻ Vygenerovat nová doporučení (1×/24h)[/COLOR]"
        regen_li = xbmcgui.ListItem(label=regen_label)
        regen_li.setInfo("video", {
            "plot": "Vygenerovat nová doporučení teď. "
                    "Server omezuje na 1× za 24h. "
                    "Pokud nesplňuješ, výsledek to oznámí.",
        })
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=f"plugin://{addon_id}/?action=regenerate_recommendations",
            listitem=regen_li,
            isFolder=_routes.is_folder("regenerate_recommendations"),
        )

    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def _batch_header_label(data: dict[str, Any]) -> str:
    """„✨ Doporučení z 5.9. 02:03 · 10 tipů" z `last_generated_at` (ISO, UTC) —
    čas se převádí do lokálního času zařízení."""
    iso = data.get("last_generated_at") or ""
    count = len(data.get("items") or [])
    if not iso:
        return ""
    import richmovie_helpers
    when = richmovie_helpers.format_local_datetime(iso, default=str(iso)[:10])
    return "[COLOR FF99CCFF]Doporučení: {} · {} tipů[/COLOR]".format(when, count)


def _save_failed_text(res: dict[str, Any]) -> str:
    """Kód chyby Gate jen do logu; na obrazovku věta (Φ2 — dřív „Nepodařilo se uložit (http_502)“)."""
    err = (res.get("error") or {}).get("code") if isinstance(res.get("error"), dict) else res.get("error")
    _log(f"recommendation feedback save failed: {err}", xbmc.LOGWARNING)
    return "Uložit se nepodařilo — zkus to prosím za chvilku."


def trigger_dismiss(recommendation_id: int, *, title: str = "") -> None:
    """Handle action=dismiss_recommendation — Gate /dismiss + refresh výpisu.
    Φ2 (29.09.2026): kontextové menu nemá kolečko Kodi → průběh do 0,1 s, pak výsledek."""
    if recommendation_id <= 0:
        return
    with _fb.working("Ukládám „Nezajímá mě“…"):
        res = dismiss_recommendation(recommendation_id)
    if res.get("ok"):
        _fb.info("Nezajímá mě · {}".format(title or "doporučení"))
        _rm_dispatch.refresh_container("rec_dismiss")
    else:
        _fb.warn(_save_failed_text(res))


def trigger_seen(recommendation_id: int, *, tmdb_id: int = 0, kind: str = "movie", title: str = "") -> None:
    """Handle action=seen_recommendation (3.5.152): „Už jsem to viděl".
    Film → lokální ✔ (`watched_movie_mark` → stav profilu → Gate → ostatní zařízení) + Gate
    `/dismiss reason=already_seen` (navždy mimo doporučení, typovaný důvod). Seriál → jen Gate
    (nevíme, které díly; ✔ dílů má kontextové menu epizod — D1 plánu). Pořadí: nejdřív Gate
    (autoritativní), ✔ až po úspěchu — jinak by lokální ✔ bez důvodu na Gate za 6 h zmizel.
    Φ2 (29.09.2026): průběh do 0,1 s (dřív 1–30 s ticha), ✔ se hlásí až po skutečném zápisu."""
    if recommendation_id <= 0:
        return
    with _fb.working("Ukládám „Už jsem to viděl“…"):
        res = dismiss_recommendation(recommendation_id, reason=REASON_ALREADY_SEEN)
    if not res.get("ok"):
        _fb.warn(_save_failed_text(res))
        return
    marked = False
    if kind != "tv" and tmdb_id:
        try:
            import richmovie_history as _rh
            marked = bool(_rh.watched_movie_mark(tmdb_id))
        except Exception as exc:
            _log(f"seen: watched_movie_mark failed: {exc!r}", xbmc.LOGWARNING)
    _log(f"SEEN_RECOMMENDATION id={recommendation_id} tmdb={tmdb_id} kind={kind} marked={marked}", xbmc.LOGINFO,
         context={"recommendation_id": recommendation_id, "tmdb_id": tmdb_id, "kind": kind})
    if kind != "tv" and tmdb_id and not marked:
        # Gate už ví (doporučení se nevrátí), ale lokální ✔ selhal → říct pravdu, ne „✔" (cross-check QA2)
        _fb.warn("Uloženo do doporučení · ✔ v historii se nepodařilo zapsat")
    else:
        _fb.info("Viděno ✔ · {}".format(title or "titul") + (" — doporučení upravena" if marked else ""))
    _rm_dispatch.refresh_container("rec_seen")


# Φ2: důvody, které Gate vrací u `/regenerate`, a jejich věta pro člověka (kód jen do logu)
_REGENERATE_FAILED_TEXT = "O nová doporučení teď nejde požádat — zkus to prosím později."


def trigger_regenerate(addon: xbmcaddon.Addon) -> None:
    """Handle action=regenerate_recommendations — show progress + result toast."""
    with _fb.working("Žádám o nová doporučení…"):
        result = request_regenerate()

    if result.get("ok") and result.get("queued"):
        _fb.info("Nová doporučení se generují. Za chvíli tu budou.")
    elif result.get("reason") == "rate_limited_24h":
        next_at = result.get("next_eligible_at")
        when = ""
        if next_at:
            import richmovie_helpers
            when = richmovie_helpers.format_local_datetime(next_at, default="")
        _fb.warn("Doporučení byla vygenerována nedávno. " +
                 ("Nová půjdou {}.".format(when) if when else "Zkus to prosím později."))
    else:
        _log(f"regenerate failed: {result.get('reason')}", xbmc.LOGWARNING)
        _fb.warn(_REGENERATE_FAILED_TEXT)


def trigger_delete_all(addon: xbmcaddon.Addon) -> None:
    """Handle Settings → Privacy → Smazat AI doporučení history.

    Double-confirm dialog before sending. Phase G (GDPR) per Section 9 #C.
    """
    dlg = xbmcgui.Dialog()
    if not dlg.yesno(
        "Smazat AI historii?",
        "Tato akce trvale smaže všechna AI doporučení a anonymizuje "
        "historii sledování a vyhledávání.\n\nPokračovat?",
        nolabel="Zrušit",
        yeslabel="Pokračovat",
    ):
        return
    if not dlg.yesno(
        "POSLEDNÍ POTVRZENÍ",
        "Akce je nevratná. Všechna data budou anonymizována nebo "
        "smazána do 30 dnů.\n\nOpravdu smazat?",
        nolabel="Zrušit",
        yeslabel="ANO, SMAZAT",
    ):
        return

    # B#5 (Fable audit): lokální buffer smazat PŘED anonymizací na Gate —
    # obrácené pořadí nechávalo okno, kdy flush doručil eventy s reálným
    # user_id až PO anonymizaci (append-only tabulka je už nikdo nepřepíše).
    # (In-flight POST ve vteřinách kolem kliknutí je zbytkové riziko — fence
    # je follow-up; viz REPORT.)
    try:
        import richmovie_telemetry as _tel_gdpr
        _tel_gdpr.clear_buffer()
    except Exception:
        pass

    with _fb.working("Mažu AI historii…"):
        result = delete_all(confirm=True)

    if result.get("ok"):
        _fb.info("AI historie smazána. Pro nová doporučení se začne sbírat od nuly.")
        # Druhé smazání po potvrzení Gate — chytá eventy zařazené BĚHEM mazání.
        try:
            import richmovie_telemetry
            richmovie_telemetry.clear_buffer()
        except Exception:
            pass
    else:
        _log(f"delete_all failed: {result.get('reason')}", xbmc.LOGWARNING)
        _fb.warn("Smazat se teď nepodařilo — nic se nezměnilo, zkus to prosím později.")
