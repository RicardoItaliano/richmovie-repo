# -*- coding: utf-8 -*-
"""
richmovie_search_log — zápis diagnostických logů hledání po dávkách (SSOT zapisovače).

Proč (audit E4-F01, 29.09.2026): `plugin._log_event` psal KAŽDÝ řádek zvlášť — `makedirs` + `open/append/
close` + 3× čtení nastavení, na Kodi (Python 3.8, Windows) 0,75 ms na řádek. Jedno hledání má 400–1 230
řádků, takže zápis logu tvořil 87 % CPU hledání filmu a 68 % seriálu.

Pravidlo Richieho (29.09.2026): „levnější logování by nemělo být na úkor detailů logů, jen optimalizované.“
Proto se mění JEN způsob zápisu — obsah řádků (události, pole, pořadí) zůstává bajt po bajtu stejný:

  • mimo „rozsah hledání“ (`scope()`) se píše hned, jako dřív (služba, jednotlivé události);
  • uvnitř rozsahu se řádky drží v paměti (zvlášť pro každý cílový soubor) a zapisují po dávkách: při
    `FLUSH_ROWS` řádcích, při prvním zápisu po `FLUSH_AGE_S` sekundách, při `flush()` a VŽDY při opuštění
    rozsahu (i výjimkou) a při konci procesu (`atexit`);
  • stáří dávky se hlídá JEN při zápisu dalšího řádku — před čekáním bez logování (síť, MediaInfo,
    vykreslení výpisu, sběrač nového vzhledu) proto volající MUSÍ zavolat `flush()`. Při zabití procesu
    se pak ztratí nejvýš řádky zapsané po posledním `flush()`.

Modul je čistý (žádné `xbmc`, žádný import `plugin`) — testuje ho harness scénář 81.
"""
from __future__ import annotations

import atexit
import os
import threading
import time
from typing import Callable, List, Optional

# Strop dávky: řádky × ~200 B ≈ 50 kB v paměti; věk: nejdelší okno ztráty při pádu procesu.
FLUSH_ROWS = 256
FLUSH_AGE_S = 1.0
ROTATE_BYTES = 2_097_152      # rotace globálního logu (2 MiB) — hodnota z původního `_log_event`
# Řádky, které se nepodařilo zapsat (zamčený soubor, plný disk), čekají na další zápis téhož souboru.
# Strop chrání paměť služby při trvalé poruše disku; co se nevejde, jde do `stats["lost"]` a do `on_error`.
RETRY_ROWS_MAX = 4096


class SearchLogWriter(object):
    """Zapisovač řádků do textových logů s volitelným dávkováním. Thread-safe."""

    def __init__(self, rotate_path: str = "", on_error: Optional[Callable[[str], None]] = None,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self._rotate_path = rotate_path
        self._on_error = on_error
        self._clock = clock
        self._lock = threading.RLock()
        self._depth = 0
        self._buf: dict = {}          # cesta → řádky (pořadí řádků V SOUBORU zůstává; soubory se nemíchají)
        self._pending = 0
        self._first_ts = 0.0
        self._dirs_ok: set = set()
        self._failed: dict = {}       # cesta → řádky, které čekají na opakovaný zápis (pořadí zachováno)
        self.stats = {"rows": 0, "writes": 0, "flushes": 0, "errors": 0, "retried": 0, "lost": 0}

    # ------------------------------------------------------------------ rozsah
    def begin(self) -> None:
        with self._lock:
            self._depth += 1

    def end(self) -> None:
        with self._lock:
            if self._depth > 0:
                self._depth -= 1
            if self._depth == 0:
                self._flush_locked()

    def scope(self) -> "_Scope":
        """`with writer.scope():` — uvnitř se dávkuje, při opuštění (i výjimkou) se vše zapíše."""
        return _Scope(self)

    @property
    def buffering(self) -> bool:
        return self._depth > 0

    # ------------------------------------------------------------------ zápis
    def write(self, path: str, row: str) -> None:
        """Přidá řádek (bez koncového \\n) do logu `path`. Nikdy nevyhazuje výjimku."""
        if not path:
            return
        with self._lock:
            self.stats["rows"] += 1
            if self._depth <= 0:
                self._append(path, [row])
                return
            # dávka PER SOUBOR: se zapnutým trace se střídá `.log` a `.ndjson` — společná dávka by se
            # zapisovala po každém řádku (audit Fable F2-V11)
            if not self._pending:
                self._first_ts = self._clock()
            self._buf.setdefault(path, []).append(row)
            self._pending += 1
            if self._pending >= FLUSH_ROWS or (self._clock() - self._first_ts) >= FLUSH_AGE_S:
                self._flush_locked()

    def flush(self) -> None:
        with self._lock:
            self._flush_locked()
            for path in list(self._failed):
                self._append(path, [])          # nový pokus o řádky, které se dřív nezapsaly

    # ------------------------------------------------------------------ vnitřek
    def _flush_locked(self) -> None:
        if not self._pending:
            return
        buf, self._buf, self._pending = self._buf, {}, 0
        self.stats["flushes"] += 1
        for path, rows in buf.items():
            self._append(path, rows)

    def _append(self, path: str, rows: List[str]) -> None:
        # Φ-E (30.09.2026, cross-check Flash F9): nezapsané řádky se nezahazují — jdou PŘED nové řádky
        # téhož souboru při dalším zápisu (log hledání nesmí ztratit detail)
        waiting = self._failed.pop(path, None)
        if waiting:
            rows = waiting + list(rows)
            self.stats["retried"] += len(waiting)
        if not rows:
            return
        try:
            d = os.path.dirname(path)
            if d and d not in self._dirs_ok:
                os.makedirs(d, exist_ok=True)
                self._dirs_ok.add(d)
            if self._rotate_path and path == self._rotate_path:
                self._rotate(path)
            with open(path, "a", encoding="utf-8") as fh:
                fh.write("\n".join(rows) + "\n")
            self.stats["writes"] += 1
        except Exception as exc:     # log nesmí zablokovat běh doplňku
            self.stats["errors"] += 1
            self._dirs_ok.discard(os.path.dirname(path))
            lost = max(0, len(rows) - RETRY_ROWS_MAX)
            self.stats["lost"] += lost
            self._failed[path] = list(rows[-RETRY_ROWS_MAX:])
            if self._on_error is not None:
                try:
                    self._on_error("search log write failed: %r (čeká %d řádků, ztraceno %d)"
                                   % (exc, len(self._failed[path]), lost))
                except Exception:
                    pass

    def _rotate(self, path: str) -> None:
        try:
            if os.path.exists(path) and os.path.getsize(path) > ROTATE_BYTES:
                bak = "%s.1" % path
                if os.path.exists(bak):
                    os.remove(bak)
                os.replace(path, bak)  # lint:allow-replace rotace logu = rename existujícího souboru, ne zápis dat
        except Exception as exc:
            if self._on_error is not None:
                try:
                    self._on_error("log rotation failed: %r" % (exc,))
                except Exception:
                    pass


class _Scope(object):
    def __init__(self, writer: SearchLogWriter) -> None:
        self._w = writer

    def __enter__(self) -> SearchLogWriter:
        self._w.begin()
        return self._w

    def __exit__(self, exc_type, exc, tb) -> bool:
        self._w.end()
        return False


def register_atexit(writer: SearchLogWriter) -> None:
    """Poslední pojistka: konec interpretu (invokace pluginu) zapíše, co zbylo v paměti."""
    atexit.register(writer.flush)
