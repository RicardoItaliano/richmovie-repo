# -*- coding: utf-8 -*-
"""RichMovie — tenký spouštěč pluginu (Φ4, 29.09.2026, audit A08 F1/F7).

Kodi spouští hlavní skript z `addon.xml` (`library=`) přes `PyRun_FileExFlags` — zdroják se parsuje
a kompiluje při KAŽDÉ invokaci a cache `.pyc` se pro hlavní skript nikdy nepoužije. Dokud hlavním
skriptem byl `plugin.py` (633 kB, 15 300 řádků), stálo to ~96 ms na každý klik na PC (odhad ~0,45 s
na TV). Navíc modul `plugin` nebyl v `sys.modules` (běžel jako `__main__`), takže každé vnořené
`import plugin` vykonalo jeho tělo znovu.

Tenhle spouštěč je malý; `import plugin` jde běžným importem (cache `.pyc` v `__pycache__`, stejně
jako už léta ve službě) a modul je v invokaci jen jednou. Čas startu se měří tady — `import_ms`
v TRACE (Φ0) tak zahrnuje i import pluginu.

4.0.1 (audit Fable F-2, 09.10.2026): značka „běží invokace pluginu“ (`richmovie_activity`) se zapisuje TADY,
PŘED importem pluginu — dřív až v `plugin.main` po importu a prologu (Sony: `import_ms=815`, pod zátěží víc).
Klik na stream tak brána programového refreshe (`richmovie_playback_dispatch.refresh_container`,
`background=True`) vidí jako STAV hned od startu interpretu, ne jen přes nečinnost ovladače (časové okno 3 s).
"""
from __future__ import annotations

import time

_T0 = time.monotonic()

try:
    import richmovie_activity as _rm_activity  # importuje jen richmovie_winprops — levné, před pluginem
    _ACTIVITY_TOKEN = _rm_activity.note_invocation_begin()
except Exception:  # značka je ohleduplnost pozadí — nikdy nesmí zabránit spuštění pluginu
    _ACTIVITY_TOKEN = None

import plugin  # noqa: E402  (čas startu musí předcházet importu)

plugin.main(_T0, activity_token=_ACTIVITY_TOKEN)
