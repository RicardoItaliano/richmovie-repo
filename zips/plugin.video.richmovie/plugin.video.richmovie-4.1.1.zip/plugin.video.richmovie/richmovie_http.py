# -*- coding: utf-8 -*-
"""
RichMovie HTTP — SSOT transportní vrstva pro VŠECHNA síťová volání addonu.

PROČ TENHLE MODUL EXISTUJE
--------------------------
Incident 08.08.2026 (Chromecast na dovolené, kolísající hotelová Wi-Fi): uživateli
vyskočil modální dialog ``Chyba TMDb: <urlopen error [Errno 101] Network is
unreachable>``. Analýza (``Handoff\\ANALYZA_tmdb_errno101_network_unreachable_20260808.md``)
ukázala, že spouštěč byl výpadek sítě, ale příčina hlášky je na naší straně:

    • všech 29 ``urlopen()`` call-sites mimo vendor dělalo JEDEN pokus bez retry,
    • jedna přechodná chyba tak propadla až do UI jako blokující dialog,
    • bez backoffu se chyba navíc množila: device ``bcd7e5d14d`` vyprodukoval
      07.08.2026 v 09:20:46–48 dvacet ``getaddrinfo failed`` za dvě sekundy.

Tenhle modul je jediné místo, které rozhoduje, JESTLI je chyba přechodná, a jediné
místo, které umí požadavek zopakovat. Žádný jiný modul nesmí mít vlastní klasifikaci
síťových chyb ani vlastní retry — DRY a SSOT jsou v Rich* projektech povinné.

OBSAH (roste po fázích dle Handoff\\PLAN_richmovie_network_resilience_20260808.md)
---------------------------------------------------------------------------------
    Φ0  klasifikační jádro   — výjimky, ``errno_of()``, ``classify()``, ``describe_error()``
    Φ1  retry vrstva         — profily rozpočtu, ``request()``

JAK RETRY FUNGUJE (a proč zrovna takhle)
----------------------------------------
Retry je **deadline-driven, ne count-driven**. Volající nedostane „zkus 3×", ale
„zkoušej, dokud zbývá rozpočet". Důvod je asymetrie chybových tříd:

    ENETUNREACH / ECONNRESET   přijdou za jednotky milisekund  → 3 pokusy se vejdou
    socket.timeout             spotřebuje CELÝ timeout         → druhý pokus se nevejde

Takže právě ty chyby, které trápí zařízení na kolísající Wi-Fi, se stihnou opravit,
zatímco timeout (kde by opakování jen prodlužovalo čekání uživatele) retry nedostane.
Není v tom žádná magická konstanta — rozhoduje zbývající čas.

**Timeouty jednotlivých pokusů zůstávají na hodnotách, které addon používal před
zavedením této vrstvy** (Android 5 s, ostatní 8 s pro TMDb). Zkrácení timeoutu kvůli
retry by bylo zhoršení pro uživatele na pomalé lince — rozpočet se přidává NAD dnešní
chování, nesnižuje ho.

NEPŘEKROČITELNÁ PRAVIDLA (platí pro celý modul)
-----------------------------------------------
    • HTTP 429 se NIKDY neretryuje — incident 12.07.2026 zesílil jeden dotaz na
      ~1900 requestů proti Gate. Rate-limit se předává volajícímu, který má vlastní
      cooldown breaker (``tmdb_client.TMDb._RL_COOLDOWN_*``).
    • Neznámá chyba = PERMANENT (fail-safe). Radši jeden nezopakovaný request než
      retry smyčka na chybu, které nerozumíme.
    • Modul nesmí NIKDY spadnout kvůli diagnostice. Chybějící ``xbmc`` (offline
      harness ``_tools\\net_resilience_sim\\``) je legitimní stav.

Python 3.8 kompat (Kodi bundled CPython) — žádné PEP 604 uniony, typing.Optional/Dict/Tuple.
"""

from __future__ import annotations

# ──────────────  STANDARD LIBRARY  ──────────────
import errno as _errno_mod
import http.client
import _socket as _socket_mod   # C vrstva socketu — `cancel_all` na Windows (viz S23 níže)
import json
import os
import random
import socket
import ssl
import threading
import time
import urllib.error
import urllib.request
import weakref
from typing import Any, Dict, Optional, Tuple

# ──────────────  KODI API  ──────────────
# Modul musí být importovatelný i mimo Kodi (offline harness Φ6), proto je import
# best-effort a všechna volání xbmc.* jsou dál v kódu podmíněná.
try:
    import xbmc  # type: ignore
except Exception:  # pragma: no cover — mimo Kodi (harness)
    xbmc = None  # type: ignore

# ──────────────  RICHMOVIE  ──────────────
# Routovaný logger (kodi.log + SQLite buffer → Gate /v1/user_logs/batch). Fallback
# je no-op: transportní vrstva se nesmí rozbít kvůli logování.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.http", "RichMovie/Http")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):
        # type: (str, int, Optional[Dict[str, Any]]) -> None
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/Http] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Třídy chyb — návratové hodnoty classify()
# --------------------------------------------------------------------------- #
CLASS_TRANSIENT = "transient"    # přechodné — má smysl zopakovat
CLASS_PERMANENT = "permanent"    # trvalé — opakování nepomůže
CLASS_RATELIMIT = "ratelimit"    # HTTP 429 — opakování ŠKODÍ (viz pravidla výše)


# --------------------------------------------------------------------------- #
# Výjimky
# --------------------------------------------------------------------------- #
class HttpTransportError(Exception):
    """Základ transportních chyb RichMovie.

    Nese původní výjimku (``cause``) a strojově čitelný popis (``detail``), aby
    volající mohl logovat forenzní data, ale uživateli ukázat lidskou hlášku.
    Uživatelský text se NIKDY neodvozuje ze ``str(cause)`` — od toho je Φ5
    ``richmovie_helpers.net_error_message()``.
    """

    def __init__(self, message, cause=None, detail=None, http_status=None):
        # type: (str, Optional[BaseException], Optional[Dict[str, Any]], Optional[int]) -> None
        super().__init__(message)
        self.cause = cause
        self.detail = detail or {}
        self.http_status = http_status


class TransientError(HttpTransportError):
    """Přechodná chyba — síť, DNS, reset spojení, 5xx. Retry má smysl."""


class PermanentError(HttpTransportError):
    """Trvalá chyba — 4xx (mimo 408/429), TLS certifikát, nevalidní JSON."""


class OfflineError(TransientError):
    """Breaker je otevřený — síť se ani nezkoušela (fail-fast, Φ2).

    Podtřída ``TransientError`` schválně: volající, který umí degradovat na cache,
    ji odbaví stejnou větví jako běžný výpadek. Rozdíl je jen v tom, že tahle
    chyba přijde do pár milisekund místo po vypršení timeoutu.
    """


class HostDownError(TransientError):
    """Jistič hostu je otevřený — host teď neodpovídá, síť se ani nezkoušela (08.11.2026, W1).

    Podtřída ``TransientError`` schválně (stejně jako ``OfflineError``): volající ji odbaví větví přechodné
    chyby (R2 — nic se nepersistuje, položka zůstává ve frontě), jen přijde do milisekund místo po vypršení
    spojení. ``host`` = jméno hostu (pro pravdivou větu: „Webshare teď neodpovídá“). NEhlásí se netstate
    (žádný pokus o spojení neproběhl) a NEopakuje se.
    """

    def __init__(self, message, host="", cause=None, detail=None, http_status=None):
        # type: (str, str, Optional[BaseException], Optional[Dict[str, Any]], Optional[int]) -> None
        super().__init__(message, cause=cause, detail=detail, http_status=http_status)
        self.host = str(host or "")


class CancelledError(TransientError):
    """Požadavek zrušilo ukončování interpretu (S23, 03.11.2026) — žádná odpověď nedorazí.

    Podtřída ``TransientError`` schválně (R2): volající s položkou ve frontě ji nechá ve frontě a nic
    nepersistuje (žádná negativní cache, žádný marker „hotovo“). Na rozdíl od běžné přechodné chyby se
    NEOPAKUJE a NEHLÁSÍ se netstate — zrušení není důkaz výpadku sítě.
    """


# --------------------------------------------------------------------------- #
# Klasifikační tabulky — SSOT. Žádné roztroušené `if errno == ...` po modulech.
# --------------------------------------------------------------------------- #

# POSIX errno hodnoty značící „síť/spojení selhalo, ale příště to může vyjít".
# Windows ekvivalenty (WSAE*) jsou uvedené vedle, protože Python je na Windows
# do `OSError.errno` propisuje v původní WSA podobě (10051 apod.), ne přeložené.
_TRANSIENT_ERRNOS = frozenset(
    v for v in (
        getattr(_errno_mod, "ENETUNREACH", None),    # 101  — incident 08.08.2026
        getattr(_errno_mod, "ENETDOWN", None),       # 100
        getattr(_errno_mod, "ENETRESET", None),      # 102
        getattr(_errno_mod, "ECONNABORTED", None),   # 103
        getattr(_errno_mod, "ECONNRESET", None),     # 104  — incident 08.08.2026
        getattr(_errno_mod, "ENOBUFS", None),        # 105
        getattr(_errno_mod, "ETIMEDOUT", None),      # 110
        getattr(_errno_mod, "ECONNREFUSED", None),   # 111
        getattr(_errno_mod, "EHOSTDOWN", None),      # 112
        getattr(_errno_mod, "EHOSTUNREACH", None),   # 113
        getattr(_errno_mod, "EPIPE", None),          # 32
        getattr(_errno_mod, "EAGAIN", None),         # 11
        getattr(_errno_mod, "EINTR", None),          # 4
        10050,  # WSAENETDOWN
        10051,  # WSAENETUNREACH
        10052,  # WSAENETRESET
        10053,  # WSAECONNABORTED
        10054,  # WSAECONNRESET
        10055,  # WSAENOBUFS
        10060,  # WSAETIMEDOUT
        10061,  # WSAECONNREFUSED
        10064,  # WSAEHOSTDOWN
        10065,  # WSAEHOSTUNREACH
    ) if v is not None
)

# HTTP stavy, u kterých má opakování smysl.
# POZOR: 500 tu SCHVÁLNĚ NENÍ — „Internal Server Error" je typicky deterministická
# chyba aplikace; opakování nepomůže a jen přitopí přetíženému Gate.
_TRANSIENT_HTTP_STATUS = frozenset((408, 502, 503, 504))

# HTTP 429 má vlastní třídu — viz nepřekročitelná pravidla v hlavičce modulu.
_RATELIMIT_HTTP_STATUS = frozenset((429,))

# Textové otisky chyb, které nenesou použitelné errno (DNS vrstva napříč platformami).
_TRANSIENT_TEXT_MARKERS = (
    "getaddrinfo failed",
    "temporary failure in name resolution",
    "no address associated with hostname",
    "name or service not known",
    "nodename nor servname provided",
    "network is unreachable",
    "connection reset by peer",
    "software caused connection abort",
    "timed out",
)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# errno_of  (vytvořeno: 08.08.2026 10:35 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def errno_of(exc):
    # type: (Optional[BaseException]) -> Optional[int]
    """Vyloupne číselné ``errno`` z výjimky, včetně obalených.

    Proč to není triviální: ``urllib`` chybu z nižší vrstvy zabalí do
    ``URLError``, jehož ``reason`` teprve nese původní ``OSError``. Bez rozbalení
    bychom u incidentu 08.08.2026 viděli jen ``URLError`` bez errna, tedy bez
    informace, že šlo o ``ENETUNREACH(101)``.

    Rozbaluje se do hloubky 4 (``URLError.reason`` → ``OSError`` → ``__cause__``),
    což na reálné hierarchii urllib/http.client/ssl/socket vždy stačí. Hloubka je
    omezená, aby cyklická vazba ``__cause__`` nezpůsobila nekonečnou smyčku.

    Args:
        exc: Libovolná výjimka (nebo None).

    Returns:
        Číselné errno, nebo None když ho výjimka nenese.
    """
    seen = 0
    node = exc  # type: Any
    while node is not None and seen < 4:
        seen += 1

        # socket.gaierror nese EAI_* kódy (např. EAI_AGAIN = -3) také v `errno`.
        candidate = getattr(node, "errno", None)
        if isinstance(candidate, int):
            return candidate

        # Windows: `winerror` bývá vyplněný i tam, kde `errno` chybí.
        candidate = getattr(node, "winerror", None)
        if isinstance(candidate, int):
            return candidate

        nxt = getattr(node, "reason", None)
        if not isinstance(nxt, BaseException):
            nxt = getattr(node, "__cause__", None)
        node = nxt if isinstance(nxt, BaseException) else None

    return None


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _unwrap_reason  (vytvořeno: 08.08.2026 10:35 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _unwrap_reason(exc):
    # type: (Optional[BaseException]) -> Optional[BaseException]
    """Vrátí nejvnitřnější příčinu výjimky (``URLError.reason`` → ``__cause__``).

    Klasifikace potřebuje typ PŮVODNÍ chyby: ``URLError`` sám o sobě neříká nic,
    ale ``URLError(reason=ConnectionResetError(...))`` je jasně přechodná chyba.
    Stejná omezená hloubka jako u ``errno_of()`` — ze stejného důvodu.
    """
    seen = 0
    node = exc
    while node is not None and seen < 4:
        nxt = getattr(node, "reason", None)
        if not isinstance(nxt, BaseException):
            nxt = getattr(node, "__cause__", None)
        if not isinstance(nxt, BaseException):
            return node
        node = nxt
        seen += 1
    return node


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# classify  (vytvořeno: 08.08.2026 10:35 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def classify(exc, http_status=None):
    # type: (Optional[BaseException], Optional[int]) -> str
    """Zařadí chybu do jedné ze tří tříd: transient / permanent / ratelimit.

    Pořadí vyhodnocení je záměrné — od nejjistějšího signálu k nejméně jistému:

        1) HTTP status (429 → ratelimit, 408/502/503/504 → transient, jinak 4xx/5xx
           → permanent). Status je nejtvrdší informace, kterou máme.
        2) Typ výjimky (``ConnectionError`` a spol. jsou platformně nezávislé,
           narozdíl od errna, které se na Windows liší).
        3) Číselné errno proti ``_TRANSIENT_ERRNOS``.
        4) Textový otisk (DNS chyby, které nenesou použitelné errno).
        5) Fallback = PERMANENT.

    Bod 5 je vědomé fail-safe rozhodnutí: neznámou chybu NEOPAKUJEME. Retry na
    nepochopenou chybu je přesně ten druh „chytrosti", co v produkci vyrobí storm.

    Args:
        exc:         Zachycená výjimka (může být None, pokud klasifikujeme jen status).
        http_status: HTTP stavový kód, pokud je k dispozici.

    Returns:
        CLASS_TRANSIENT | CLASS_PERMANENT | CLASS_RATELIMIT
    """
    # ── 1) HTTP status ──────────────────────────────────────────────────────
    status = http_status
    if status is None and isinstance(exc, urllib.error.HTTPError):
        status = getattr(exc, "code", None)

    if isinstance(status, int):
        if status in _RATELIMIT_HTTP_STATUS:
            return CLASS_RATELIMIT
        if status in _TRANSIENT_HTTP_STATUS:
            return CLASS_TRANSIENT
        if status >= 400:
            return CLASS_PERMANENT

    if exc is None:
        return CLASS_PERMANENT

    # ── 1b) Vlastní výjimky téhle vrstvy ────────────────────────────────────
    # Kdo chytí `TransientError` a zeptá se `classify()`, musí dostat „transient".
    # Bez téhle větve by dopadl na fail-safe konec funkce a dostal „permanent",
    # což by u Φ4 znamenalo, že se stale cache nikdy nepoužije. Pořadí za blokem
    # statusu je záměr — explicitně předaný `http_status` má přednost.
    if isinstance(exc, TransientError):      # včetně OfflineError
        return CLASS_TRANSIENT
    if isinstance(exc, PermanentError):
        return CLASS_PERMANENT

    inner = _unwrap_reason(exc) or exc

    # ── 2) Typ výjimky ──────────────────────────────────────────────────────
    # TLS: ověření certifikátu je trvalá chyba (špatný čas na zařízení, MITM
    # captive portal). Naopak EOF/zero-return v půlce handshaku je utržené
    # spojení, tedy přechodné.
    if isinstance(inner, ssl.SSLCertVerificationError):
        return CLASS_PERMANENT
    if isinstance(inner, (ssl.SSLEOFError, ssl.SSLZeroReturnError)):
        return CLASS_TRANSIENT
    if isinstance(inner, ssl.SSLError):
        # Ostatní TLS chyby jsou nejednoznačné → fail-safe permanent.
        return CLASS_PERMANENT

    if isinstance(inner, (json.JSONDecodeError, UnicodeDecodeError)):
        return CLASS_PERMANENT

    # ConnectionError pokrývá Reset/Aborted/Refused/BrokenPipe napříč platformami.
    if isinstance(inner, (ConnectionError, TimeoutError, socket.timeout)):
        return CLASS_TRANSIENT

    # DNS. Vědomé zjednodušení: gaierror bereme jako přechodnou VŽDY. Naše domény
    # (gate.svcnode.org) existují, takže „host nenalezen" v praxi znamená rozbitý
    # resolver nebo captive portal, ne trvalý stav — přesně případ 07.08.2026,
    # kdy Windows klient dostal 20× [Errno 11001] getaddrinfo failed za 2 sekundy.
    if isinstance(inner, socket.gaierror):
        return CLASS_TRANSIENT

    if isinstance(inner, (http.client.RemoteDisconnected,
                          http.client.IncompleteRead,
                          http.client.BadStatusLine)):
        return CLASS_TRANSIENT

    # ── 3) errno ────────────────────────────────────────────────────────────
    num = errno_of(exc)
    if num is not None and num in _TRANSIENT_ERRNOS:
        return CLASS_TRANSIENT

    # ── 4) textový otisk ────────────────────────────────────────────────────
    try:
        text = ("%s %s" % (inner, exc)).lower()
    except Exception:
        text = ""
    for marker in _TRANSIENT_TEXT_MARKERS:
        if marker in text:
            return CLASS_TRANSIENT

    # ── 5) fail-safe ────────────────────────────────────────────────────────
    return CLASS_PERMANENT


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# describe_error  (vytvořeno: 08.08.2026 10:35 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def describe_error(exc, http_status=None):
    # type: (Optional[BaseException], Optional[int]) -> Dict[str, Any]
    """Sestaví strojově čitelný popis chyby pro ``context`` v routovaném logu.

    Tohle je důvod, proč vůbec něco uvidíme v ``user_logs`` na NASu. Do 08.08.2026
    TMDb transport neposílal do pipeline nic — za 14 dní bylo v tabulce 0 záznamů
    se ``source='richmovie.tmdb'`` a řetězec „Errno 101" se tam nevyskytoval ani
    jednou, přestože uživateli vyskočil dialog.

    Klíče jsou stabilní, protože se na ně dotazuje admin dashboard i verifikační
    SQL v Handoff plánu. Nepřejmenovávat bez migrace dotazů.

    Returns:
        {"err_class": ..., "err_type": ..., "errno": ..., "http_status": ...,
         "err_text": ...}  — ``err_text`` je zkrácený na 200 znaků (log hygiena).
    """
    inner = _unwrap_reason(exc) or exc
    try:
        text = str(exc) if exc is not None else ""
    except Exception:
        text = "<nepřevoditelná výjimka>"

    status = http_status
    if status is None and isinstance(exc, urllib.error.HTTPError):
        status = getattr(exc, "code", None)

    return {
        "err_class": classify(exc, http_status=status),
        "err_type": type(inner).__name__ if inner is not None else None,
        "errno": errno_of(exc),
        "http_status": status,
        "err_text": text[:200],
    }


# Chyby, které NEMŮŽE vyrobit vzdálený server — vznikají na lokálním síťovém
# stacku. „Nemám routu do sítě" nebo „resolver neodpovídá" je výrok o zařízení,
# ne o protistraně. Netstate (Φ2) je proto bere jako mnohem silnější důkaz
# výpadku než obyčejný timeout: dvě takové chyby stačí na přepnutí do OFFLINE,
# zatímco u serverových chyb chceme tři a od dvou různých hostů.
_LOCAL_NETWORK_ERRNOS = frozenset(
    v for v in (
        getattr(_errno_mod, "ENETUNREACH", None),    # 101
        getattr(_errno_mod, "ENETDOWN", None),       # 100
        getattr(_errno_mod, "EHOSTUNREACH", None),   # 113
        10050,  # WSAENETDOWN
        10051,  # WSAENETUNREACH
        10065,  # WSAEHOSTUNREACH
    ) if v is not None
)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# is_local_network_error  (vytvořeno: 08.08.2026 11:45 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def is_local_network_error(exc):
    # type: (Optional[BaseException]) -> bool
    """True, když chyba prokazatelně pochází z lokální sítě zařízení.

    Přesně tahle třída chyb stála za incidentem 08.08.2026 — ``ENETUNREACH``
    znamená, že kernel neměl kam paket poslat, protože Wi-Fi zrovna nebyla.
    Žádný server takovou odpověď poslat neumí.

    DNS selhání (``socket.gaierror``) sem patří taky: náš resolver je vždycky
    lokální (router nebo DHCP-přidělený), takže „nepřeložím jméno" ukazuje na
    linku, ne na cíl.

    Returns:
        True = signál o lokální konektivitě; False = může za to i protistrana.
    """
    if exc is None:
        return False
    inner = _unwrap_reason(exc) or exc
    if isinstance(inner, socket.gaierror):
        return True
    num = errno_of(exc)
    return num is not None and num in _LOCAL_NETWORK_ERRNOS


# Errno selhání NAVÁZÁNÍ spojení na straně protějšku (časový limit connect, odmítnutí). Lokální chyby sítě
# (`_LOCAL_NETWORK_ERRNOS`) sem nepatří — ty řeší OFFLINE, ne jistič hostu.
_CONNECT_FAIL_ERRNOS = frozenset(
    v for v in (
        getattr(_errno_mod, "ETIMEDOUT", None),      # 110
        getattr(_errno_mod, "ECONNREFUSED", None),   # 111
        10060,  # WSAETIMEDOUT
        10061,  # WSAECONNREFUSED
    ) if v is not None
)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# is_connect_failure  (vytvořeno: 08.11.2026 01:40 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def is_connect_failure(exc):
    # type: (Optional[BaseException]) -> bool
    """Selhalo NAVÁZÁNÍ spojení s hostem (TCP connect, TLS handshake) — ne čekání na odpověď?

    Podklad jističe hostu (``richmovie_netstate``, 08.11.2026 W1). Rozhoduje TYP, nikdy text: ``urllib``
    obaluje do ``URLError`` jen chyby z ``HTTPConnection.request`` (spojení, TLS handshake, odeslání —
    ``AbstractHTTPHandler.do_open``); čekání na odpověď (``getresponse``) a čtení těla vyhodí holé
    ``socket.timeout`` / ``TimeoutError``. Incident 08.11.2026: ``<urlopen error timed out>`` a
    ``<urlopen error _ssl.c:989: The handshake operation timed out>`` = selhání spojení; „The read operation
    timed out“ = pomalá odpověď (jistič NEotevírá — Webshare umí být pomalý a přitom fungovat).

    Do jističe NEpatří: lokální chyby sítě (DNS, ENETUNREACH — výrok o zařízení, řeší OFFLINE), přerušené
    spojení (ECONNRESET — výkyv, který opakování spraví; incident 08.08.2026) a HTTP odpovědi.
    """
    if not isinstance(exc, urllib.error.URLError) or isinstance(exc, urllib.error.HTTPError):
        return False
    reason = getattr(exc, "reason", None)
    if not isinstance(reason, BaseException):
        return False
    if is_local_network_error(exc):
        return False
    if isinstance(reason, (socket.timeout, TimeoutError, ConnectionRefusedError)):
        return True
    num = errno_of(reason)
    return num is not None and num in _CONNECT_FAIL_ERRNOS


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# is_transient  (vytvořeno: 08.08.2026 10:35 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def is_transient(exc, http_status=None):
    # type: (Optional[BaseException], Optional[int]) -> bool
    """Zkratka pro ``classify(...) == CLASS_TRANSIENT``.

    Existuje kvůli čitelnosti call-sites ve Φ4 (stale-first degradace), kde se
    tahle otázka pokládá v každém ``except`` bloku.
    """
    return classify(exc, http_status=http_status) == CLASS_TRANSIENT




# =========================================================================== #
#                        Φ1 — RETRY VRSTVA (2026-08-08)                       #
# =========================================================================== #

# Backoff mezi pokusy. Základ 0,4 s je zvolený tak, aby uživatel na UI cestě
# nepocítil prodlevu (typický výpadek Wi-Fi se zotaví do stovek ms), a zároveň
# aby zařízení nebušilo do sítě bez pauzy.
_BACKOFF_BASE_S = 0.4
_BACKOFF_FACTOR = 2.5          # 0,4 → 1,0 → 2,5 s
_BACKOFF_JITTER = 0.25         # ±25 % — POVINNÉ, viz _backoff_delay()

# Kolik dělá `xbmc.LOGINFO` / `LOGWARNING`, když modul běží mimo Kodi (harness).
_LEVEL_INFO = 1
_LEVEL_WARNING = 2

# Sdílený abort monitor. Kodi `Monitor()` je levný objekt, ale vytvářet ho v každé
# retry pauze je zbytečné — držíme jednu instanci pod zámkem (modul volá víc vláken:
# MediaInfo workery, service_nextup, UI invoker).
_monitor_lock = threading.Lock()
_monitor = None  # type: Any


# ---------------------------------- TŘÍDA ----------------------------------- #
# richmovie_http.py
# RetryProfile  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
class RetryProfile:
    """Rozpočet jednoho logického požadavku (ne jednoho pokusu).

    Atributy:
        name:         Jméno pro log (`foreground` / `background` / `bulk`).
        budget_s:     Strop pro CELOU operaci včetně backoffů. Po jeho vyčerpání
                      se další pokus nespustí, i kdyby zbývaly pokusy.
        timeout_s:    Timeout jednoho pokusu. Odpovídá hodnotám, které addon
                      používal před zavedením retry — vědomě se NEZKRACUJE.
        max_attempts: Tvrdý strop počtu pokusů (pojistka proti patologii, kde by
                      chyby chodily tak rychle, že by se do rozpočtu vešly desítky).

    Proč třída a ne namedtuple: profily se vyhodnocují lazy podle platformy
    (`for_platform()`), což by na immutable tuple bylo neohrabané.
    """

    __slots__ = ("name", "budget_s", "timeout_s", "max_attempts")

    def __init__(self, name, budget_s, timeout_s, max_attempts):
        # type: (str, float, float, int) -> None
        self.name = name
        self.budget_s = float(budget_s)
        self.timeout_s = float(timeout_s)
        self.max_attempts = int(max_attempts)


    def replace(self, budget_s=None, timeout_s=None, max_attempts=None):
        # type: (Optional[float], Optional[float], Optional[int]) -> "RetryProfile"
        """Vrátí kopii s přepsanými hodnotami.

        Používá se tam, kde má call-site legitimní důvod se od profilu odchýlit —
        typicky RCAI volání s timeoutem 180 s (Opus job běží klidně 2 minuty, viz
        `richmovie_gate_transport.DEFAULT_TIMEOUT_SECONDS`). Profil se nemodifikuje
        na místě, aby jedno volání nezměnilo chování všech ostatních.
        """
        return RetryProfile(
            self.name,
            self.budget_s if budget_s is None else budget_s,
            self.timeout_s if timeout_s is None else timeout_s,
            self.max_attempts if max_attempts is None else max_attempts,
        )




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _is_android  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _is_android():
    # type: () -> bool
    """Detekce Androidu pro volbu timeoutu.

    Stejný dotaz, jaký `tmdb_client._get_json()` používá od 21.12.2025 — Android
    zařízení (Chromecast, TV boxy) mají přísnější okno na ukončení invokeru, takže
    tam běží kratší timeout. Detekce je best-effort: mimo Kodi (harness) vracíme
    False, což dá delší desktopový rozpočet.
    """
    try:
        if xbmc is not None:
            return bool(xbmc.getCondVisibility("system.platform.android"))
    except Exception:
        pass
    return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# profile_foreground  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def profile_foreground():
    # type: () -> RetryProfile
    """Profil pro volání na UI cestě (uživatel čeká a kouká na obrazovku).

    Timeout kopíruje dnešní chování `tmdb_client._get_json()` — Android 5 s,
    ostatní 8 s. Rozpočet je nastavený tak, aby:

        • rychlá chyba (ENETUNREACH ~1 ms) nechala prostor na 2 další pokusy,
        • timeout na prvním pokusu retry NEDOSTAL (5 + 0,4 + 5 = 10,4 > 9,0),
          protože uživatele nemá smysl nechat čekat 15 s na stejný výsledek.

    Ta nerovnost je celý trik — není nikde zadrátovaná, vyplývá z rozpočtu.
    """
    if _is_android():
        return RetryProfile("foreground", budget_s=9.0, timeout_s=5.0, max_attempts=3)
    return RetryProfile("foreground", budget_s=20.0, timeout_s=8.0, max_attempts=3)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# profile_background  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def profile_background():
    # type: () -> RetryProfile
    """Profil pro volání mimo UI (service_nextup, MediaInfo workery, telemetrie).

    Nikdo tu nečeká na obrazovku, takže si můžeme dovolit delší rozpočet i timeout
    a víc pokusů. Odpovídá dnešnímu `gate_transport.DEFAULT_TIMEOUT_SECONDS` (30 s)
    zaokrouhlenému dolů na 15 s per pokus — čtyři pokusy tak dají větší šanci
    přečkat výpadek než jeden dlouhý.
    """
    return RetryProfile("background", budget_s=60.0, timeout_s=15.0, max_attempts=4)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# profile_bulk  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def profile_bulk():
    # type: () -> RetryProfile
    """Profil pro velké payloady (collection-bundle, prefetch).

    Timeout kopíruje dnešní `get_collection_bundle()` — Android 20 s, ostatní 30 s.
    Bundle je největší přenos, jaký addon dělá, a právě na něm cloudflared
    08.08.2026 v 10:07:12 zaznamenal „Incoming request ended abruptly".
    """
    if _is_android():
        return RetryProfile("bulk", budget_s=50.0, timeout_s=20.0, max_attempts=3)
    return RetryProfile("bulk", budget_s=75.0, timeout_s=30.0, max_attempts=3)




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _netstate  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _netstate():
    # type: () -> Any
    """Vrátí modul `richmovie_netstate` (Φ2), nebo None, pokud ještě neexistuje.

    Import je záměrně uvnitř funkce, ne na začátku souboru: Φ1 se nasazuje před Φ2
    a musí být plně funkční i bez něj (bez netstate se retry chová, jako bychom byli
    trvale ONLINE — tedy přesně jako dnes, jen s opakováním).

    Výsledek se necachuje do modulové proměnné schválně — Kodi spouští každý plugin
    invoker jako nový proces, takže úspora by byla iluzorní, zatímco cache neúspěchu
    by po nasazení Φ2 držela starý stav do restartu služby.
    """
    try:
        import richmovie_netstate  # type: ignore
        return richmovie_netstate
    except Exception:
        return None


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _abort_requested  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _abort_requested():
    # type: () -> bool
    """Ruší Kodi náš invoker? Best-effort, mimo Kodi vždy False."""
    global _monitor
    try:
        if xbmc is None:
            return False
        with _monitor_lock:
            if _monitor is None:
                _monitor = xbmc.Monitor()
        return bool(_monitor.abortRequested())
    except Exception:
        return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _abort_safe_wait  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _abort_safe_wait(seconds):
    # type: (float) -> None
    """Počká, ale nechá se přerušit ukončováním Kodi.

    NIKDY `time.sleep()` v retry cestě. Kodi zabije skript, který se po požadavku
    na ukončení nezastaví do ~5 s („script didn't stop in 5 seconds"), a spící
    vlákno o tom požadavku neví. `waitForAbort()` se probudí okamžitě.

    Raises:
        SystemExit: Kodi ruší invoker — nesmíme pokračovat dalším pokusem.
    """
    global _monitor
    if seconds <= 0:
        return
    try:
        if xbmc is not None:
            with _monitor_lock:
                if _monitor is None:
                    _monitor = xbmc.Monitor()
            if _monitor.waitForAbort(seconds):
                raise SystemExit
            return
    except SystemExit:
        raise
    except Exception:
        # Monitor selhal (např. exotická platforma) — degradujeme na sleep, ale
        # jen na krátký interval, ať se abort pozná při další kontrole.
        pass
    time.sleep(min(seconds, 1.0))


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _backoff_delay  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _backoff_delay(attempt):
    # type: (int) -> float
    """Exponenciální backoff s jitterem pro `attempt`-tý pokus (1-based).

    Jitter není kosmetika, je POVINNÝ: šestnáct zařízení plus service smyčky, které
    ztratí síť ve stejnou chvíli (výpadek routeru), by se bez něj sesynchronizovaly
    do vln a udeřily na Gate naráz ve stejné milisekundě. ±25 % rozprostření to
    rozbije.

    Args:
        attempt: Číslo právě dokončeného pokusu (1 = první).

    Returns:
        Počet sekund k čekání před dalším pokusem (vždy > 0).
    """
    base = _BACKOFF_BASE_S * (_BACKOFF_FACTOR ** max(0, attempt - 1))
    jitter = base * _BACKOFF_JITTER
    return max(0.05, base + random.uniform(-jitter, jitter))


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# request  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def request(url, method="GET", headers=None, data=None, profile=None,
            idempotent=None, tag="", probe=False, opener=None, max_bytes=None,
            report_failures=True):
    # type: (str, str, Optional[Dict[str, str]], Optional[bytes], Optional[RetryProfile], Optional[bool], str, bool, Any, Optional[int], bool) -> Tuple[int, bytes, Any]
    """Provede HTTP požadavek s deadline-driven retry na přechodné chyby.

    `report_failures=False` (3.5.152, Fable N4): selhání se NEHLÁSÍ netstate — pro opakované
    kontroly cesty ke CDN v hlídači mrtvého zdroje (à 15 s). Transportní chyba jednoho CDN
    uzlu nic neříká o lince ke Gate; s hlášením stav flapoval DEGRADED ↔ ONLINE až 40× za
    10 min. Úspěch se hlásí vždy (`probe=True` navíc projde breakerem — F1).

    `max_bytes` (3.5.129): horní mez přečteného těla. Kontrola odkazu před
    přehráním (`richmovie_webshare.validate_stream_link`) posílá `Range: bytes=0-N`,
    ale CDN smí Range ignorovat a poslat HTTP 200 s celým souborem — bez stropu
    by `resp.read()` tahal gigabajty do paměti Kodi. Tělo se čte nejvýš do
    `max_bytes` (+1 B, aby volající poznal oříznutí), zbytek spojení se zahodí.
    None = beze změny chování (celé tělo).

    KONTRAKT NÁVRATU
    ----------------
    Vrací ``(http_status, body_bytes, headers)`` pro **jakoukoli** doručenou
    odpověď — tedy i pro 404, 403 nebo 500. Volající si stav vyhodnotí sám.
    Důvod: `gate_transport.post_json()` staví na tom, že chybový envelope od Gate
    dostane k parsování, a `tmdb_client` zase potřebuje vidět 429 i s hlavičkou
    `Retry-After`. Kdyby tahle funkce na stavu házela, oba by musely výjimku hned
    rozbalovat zpátky.

    Výjimka letí jen tehdy, když **žádná odpověď nedorazila** (transportní chyba)
    nebo když breaker fail-fastuje.

    RETRY POLITIKA
    --------------
    Opakuje se, jen když platí VŠECHNO najednou:
        1. chyba je CLASS_TRANSIENT (transportní nebo HTTP 408/502/503/504),
        2. požadavek je idempotentní,
        3. nevyčerpal se `max_attempts`,
        4. do konce rozpočtu se vejde backoff + plný timeout dalšího pokusu,
        5. Kodi neruší invoker.

    HTTP 429 se neopakuje NIKDY (viz pravidla v hlavičce modulu).

    Args:
        url:                Cílová URL (absolutní).
        method:             HTTP metoda. GET/HEAD jsou implicitně idempotentní.
        headers:            Hlavičky požadavku. Pozor: User-Agent je proti
                            Cloudflare Bot Fight Mode povinný (bez něj HTTP 403
                            error 1010) — doplňuje ho volající, ne tahle vrstva.
        data:               Tělo požadavku (bytes) nebo None.
        profile:            `RetryProfile`; None → `profile_foreground()`.
        idempotent:         Přebije automatiku podle metody. POST na endpoint,
                            který snese zopakování (`/auth`, `/status`,
                            `bulk_lookup`), předá True explicitně.
        tag:                Krátký štítek do logu (např. "tmdb", "gate").
        probe:              True = zdravotní sonda; projde i otevřeným breakerem
                            (jinak by se stav nikdy nemohl vrátit na ONLINE).
        opener:             Injektovatelná náhrada `urllib.request.urlopen`
                            (signatura `(req, timeout=...)`). Slouží offline
                            harnessu Φ6; v produkci zůstává None.

    Returns:
        (status, body, headers)

    Raises:
        OfflineError:   Breaker je otevřený, síť se nezkoušela.
        HostDownError:  Jistič hostu je otevřený (host teď neodpovídá), síť se nezkoušela.
        TransientError: Přechodná chyba přežila všechny povolené pokusy.
        PermanentError: Trvalá chyba (TLS, nevalidní URL, neznámá chyba).
        SystemExit:     Kodi ruší invoker (propaguje se úmyslně).
    """
    prof = profile or profile_foreground()
    if idempotent is None:
        idempotent = str(method).upper() in ("GET", "HEAD")

    # S23 (03.11.2026): interpret se ukončuje → žádné nové spojení (jinak by vlákno, které se mezitím
    # probudilo, otevřelo spojení, na které Kodi při vypínání zase čeká).
    if is_cancelled():
        raise CancelledError("pozadavek zrusen (%s)" % _cancel_reason(),
                             detail={"tag": tag, "cancelled": True})

    ns = _netstate()
    started = time.monotonic()
    deadline = started + prof.budget_s

    # ── Fail-fast breaker (Φ2) ─────────────────────────────────────────────
    # Ve stavu OFFLINE se o síť ani nepokoušíme. Rozdíl pro uživatele je zásadní:
    # místo pěti sekund zmrzlého UI dostane odpověď do jednotek milisekund a addon
    # může okamžitě sáhnout po uložených datech.
    if ns is not None and not probe:
        try:
            if not ns.allow_request():
                _log(
                    "HTTP_FAILFAST tag=%s url=%s" % (tag, _safe_url(url)),
                    _LEVEL_INFO,
                    context={"tag": tag, "url": _safe_url(url),
                             "err_class": CLASS_TRANSIENT, "failfast": True},
                )
                raise OfflineError(
                    "zarizeni je offline (breaker)",
                    detail={"tag": tag, "failfast": True},
                )
        except OfflineError:
            raise
        except Exception:
            # Netstate se rozbil → chováme se, jako by byl ONLINE. Diagnostika
            # nikdy nesmí zabránit reálnému pokusu o spojení.
            pass

    # ── Jistič hostu (08.11.2026, W1) ──────────────────────────────────────
    # Jen na ZAČÁTKU požadavku: jeho vlastní opakování proběhne celé (výkyvy, které opakování spraví —
    # incident 08.08.2026). Sondy (`probe`) a kontroly CDN (`report_failures=False`) jdou vždy do sítě: mají
    # zjistit skutečnost a jejich výsledek se do jističe nepromítá jinak než úspěchem.
    host = _host_of(url)
    trial = _host_admit(ns, host, tag, url, prof, probe, report_failures)
    try:
        attempt = 0

        while True:
            attempt += 1

            if _abort_requested():
                raise SystemExit
            if is_cancelled():     # S23: zrušeno mezi pokusy (během backoffu) → další pokus už ne
                raise CancelledError("pozadavek zrusen (%s)" % _cancel_reason(),
                                     detail={"tag": tag, "cancelled": True})

            remaining = deadline - time.monotonic()
            attempt_timeout = prof.timeout_s if remaining <= 0 else min(prof.timeout_s, remaining)
            t_attempt = time.monotonic()

            try:
                req = urllib.request.Request(url, data=data, headers=(headers or {}),
                                             method=str(method).upper())
                # S23: výchozí otevírání jde přes sledovaný opener (evidence socketů pro `cancel_all`,
                # rozpoznání zachycení na loopback). Kontrakt z Φ6 zůstává: injektovaný `opener` i náhrada
                # globálního `urllib.request.urlopen` (offline harness) mají přednost (`_default_opener`).
                _open = opener or _default_opener()
                with _open(req, timeout=attempt_timeout) as resp:
                    body = resp.read() if max_bytes is None else resp.read(int(max_bytes) + 1)
                    status = int(getattr(resp, "status", None) or resp.getcode())
                    resp_headers = getattr(resp, "headers", None)

                if _class_for_status(status) == CLASS_TRANSIENT:
                    # Doručená, ale přechodně chybová odpověď (502/503/504/408).
                    # Zachází se s ní jako s chybou, ale odpověď si držíme — když
                    # se retry nevejde do rozpočtu, vrátíme ji volajícímu místo výjimky.
                    if report_failures:
                        _report_failure(ns, CLASS_TRANSIENT, url)
                    if _abort_requested():
                        raise SystemExit
                    if is_cancelled():   # S23 (cross-check Flash F1): během vypínání žádný backoff ani další pokus
                        raise CancelledError("pozadavek zrusen (%s)" % _cancel_reason(),
                                             detail={"tag": tag, "cancelled": True})
                    if _should_retry(attempt, prof, idempotent, deadline):
                        _log_retry(tag, url, attempt, prof, status=status,
                                   elapsed_ms=int((time.monotonic() - t_attempt) * 1000))
                        _abort_safe_wait(_backoff_delay(attempt))
                        continue
                    return status, body, resp_headers

                if status in _RATELIMIT_HTTP_STATUS:
                    # 429 NENÍ selhání konektivity — síť funguje, jen nás server brzdí.
                    # Do netstate proto hlásíme úspěch, ať breaker nespadne do OFFLINE
                    # kvůli rate-limitu (jinak by nás jeden 429 odstřihl od všeho).
                    _report_success(ns, url)
                    return status, body, resp_headers

                _report_success(ns, url)
                if attempt > 1:
                    # Klíčová metrika: kolik dialogů retry ušetřil. Verifikační SQL
                    # v Handoff plánu hledá právě řetězec RETRY_OK.
                    _log(
                        "HTTP_RETRY_OK tag=%s attempt=%d/%d status=%s url=%s"
                        % (tag, attempt, prof.max_attempts, status, _safe_url(url)),
                        _LEVEL_INFO,
                        context={"tag": tag, "url": _safe_url(url), "attempt": attempt,
                                 "max_attempts": prof.max_attempts, "http_status": status,
                                 "profile": prof.name,
                                 "total_ms": int((time.monotonic() - started) * 1000)},
                    )
                return status, body, resp_headers

            except SystemExit:
                raise
            except urllib.error.HTTPError as exc:
                # HTTPError je zároveň odpověď — tělo i hlavičky jsou k dispozici.
                status = int(getattr(exc, "code", 0) or 0)
                cls = classify(exc, http_status=status)
                try:
                    body = exc.read() if max_bytes is None else exc.read(int(max_bytes) + 1)
                except Exception as read_exc:
                    # S23 (cross-check Flash F2): čtení těla přerušilo zrušení → nevracet useknutou odpověď
                    if is_cancelled():
                        raise CancelledError("pozadavek zrusen (%s)" % _cancel_reason(), cause=read_exc,
                                             detail={"tag": tag, "cancelled": True}) from read_exc
                    body = b""
                resp_headers = getattr(exc, "headers", None)

                if cls == CLASS_RATELIMIT:
                    _report_success(ns, url)          # viz komentář výše — 429 ≠ výpadek
                    return status, body, resp_headers

                if cls == CLASS_TRANSIENT:
                    if report_failures:
                        _report_failure(ns, cls, url)
                    if _abort_requested():
                        raise SystemExit
                    if is_cancelled():   # S23 (cross-check Flash F1)
                        raise CancelledError("pozadavek zrusen (%s)" % _cancel_reason(),
                                             detail={"tag": tag, "cancelled": True})
                    if _should_retry(attempt, prof, idempotent, deadline):
                        _log_retry(tag, url, attempt, prof, status=status, exc=exc,
                                   elapsed_ms=int((time.monotonic() - t_attempt) * 1000))
                        _abort_safe_wait(_backoff_delay(attempt))
                        continue
                    return status, body, resp_headers

                # Trvalá chyba se stavem (404, 403, 500…) — vracíme ji volajícímu,
                # protože je to plnohodnotná odpověď serveru, ne selhání transportu.
                _report_success(ns, url)              # spojení fungovalo, obsah je věc volajícího
                return status, body, resp_headers

            except CancelledError:
                raise
            except Exception as exc:
                # S23: chyba vznikla tím, že `cancel_all` zavřel socket pod rukama (vypínání) → zrušení, ne
                # výpadek: žádné hlášení netstate, žádný retry, R2 (volající nic nepersistuje).
                if is_cancelled():
                    raise CancelledError("pozadavek zrusen (%s)" % _cancel_reason(), cause=exc,
                                         detail={"tag": tag, "cancelled": True}) from exc
                # Sem padají VÝHRADNĚ transportní chyby — žádná odpověď nedorazila.
                cls = classify(exc)
                if report_failures:
                    _report_failure(ns, cls, url, exc=exc)

                if cls != CLASS_TRANSIENT:
                    _log(
                        "HTTP_PERMANENT tag=%s %s url=%s" % (tag, type(exc).__name__, _safe_url(url)),
                        _LEVEL_WARNING,
                        context=_ctx(exc, tag=tag, url=_safe_url(url), attempt=attempt,
                                     profile=prof.name,
                                     elapsed_ms=int((time.monotonic() - t_attempt) * 1000)),
                    )
                    raise PermanentError(str(exc), cause=exc,
                                         detail=describe_error(exc)) from exc

                # Kodi ruší invoker → skonči HNED. Sestavovat a logovat TransientError
                # by zdrželo ukončení, které má rozpočet ~5 s („script didn't stop in
                # 5 seconds"), a volajícího stejně nikdo neposlouchá.
                if _abort_requested():
                    raise SystemExit

                if _should_retry(attempt, prof, idempotent, deadline):
                    _log_retry(tag, url, attempt, prof, exc=exc,
                               elapsed_ms=int((time.monotonic() - t_attempt) * 1000))
                    _abort_safe_wait(_backoff_delay(attempt))
                    continue

                _log(
                    "HTTP_GIVEUP tag=%s attempts=%d %s url=%s"
                    % (tag, attempt, type(exc).__name__, _safe_url(url)),
                    _LEVEL_WARNING,
                    context=_ctx(exc, tag=tag, url=_safe_url(url), attempt=attempt,
                                 max_attempts=prof.max_attempts, profile=prof.name,
                                 budget_s=prof.budget_s,
                                 total_ms=int((time.monotonic() - started) * 1000)),
                )
                raise TransientError(str(exc), cause=exc,
                                     detail=describe_error(exc)) from exc
    finally:
        if trial and ns is not None:   # zkušební požadavek (half-open) uvolní claim, ať dopadl jakkoli
            try:
                ns.host_trial_done(host, trial)
            except Exception:
                pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _host_admit  (vytvořeno: 08.11.2026 01:40 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _host_admit(ns, host, tag, url, prof, probe, report_failures):
    # type: (Any, str, str, str, RetryProfile, bool, bool) -> Optional[str]
    """Zeptá se jističe hostu (``richmovie_netstate.host_admit``). Otevřený → ``HostDownError`` bez sítě
    (bez řádku logu — rychlá selhání počítá netstate a vypíše je při zavření jističe). Vrací token
    zkušebního požadavku (half-open), nebo None. Porucha netstate = jako zavřený (diagnostika nikdy nesmí
    zabránit reálnému pokusu o spojení)."""
    if ns is None or probe or not report_failures or not host:
        return None
    try:
        verdict, token = ns.host_admit(host, prof.budget_s + 5.0)
    except Exception:
        return None
    if verdict == "fast":
        raise HostDownError("host neodpovida (jistic)", host=host,
                            detail={"tag": tag, "host": host, "failfast": True, "url": _safe_url(url)})
    return token if verdict == "trial" else None




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _class_for_status  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _class_for_status(status):
    # type: (Optional[int]) -> str
    """Klasifikace samotného HTTP stavu (bez výjimky).

    Potřeba proto, že `urlopen` nevyhodí `HTTPError` vždy — vlastní opener
    (harness) nebo přesměrování mohou vrátit chybový stav přímo v odpovědi.
    Stav pod 400 je úspěch, ne chyba.
    """
    if not isinstance(status, int) or status < 400:
        return ""
    if status in _RATELIMIT_HTTP_STATUS:
        return CLASS_RATELIMIT
    if status in _TRANSIENT_HTTP_STATUS:
        return CLASS_TRANSIENT
    return CLASS_PERMANENT


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _should_retry  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _should_retry(attempt, prof, idempotent, deadline):
    # type: (int, RetryProfile, bool, float) -> bool
    """Rozhodne, jestli se smí spustit další pokus.

    Podmínka rozpočtu je to podstatné: další pokus se spustí jen tehdy, když se do
    deadline vejde backoff **i plný timeout**. Nechceme spouštět pokus s uříznutým
    timeoutem — vyrobil by falešné „timed out" tam, kde by delší čekání uspělo,
    a znehodnotil by tím diagnostiku.

    Neidempotentní požadavek (telemetrie, publish, watch events) se neopakuje
    NIKDY — duplicitní zápis do databáze je horší než chybějící.

    POZOR: abort Kodi se tady ZÁMĚRNĚ nekontroluje. Dřív to tahle funkce dělala
    a vracela False, jenže „nezkoušej znovu" a „okamžitě skonči" jsou dvě různé
    věci: volající pak pokračoval sestavením `TransientError` a logováním, místo
    aby se ukončil. Abort proto řeší volající explicitním `raise SystemExit`
    (odhaleno scénářem 8 v `_tools/net_resilience_sim/`).
    """
    if not idempotent:
        return False
    if attempt >= prof.max_attempts:
        return False
    projected = time.monotonic() + _BACKOFF_BASE_S * (_BACKOFF_FACTOR ** max(0, attempt - 1))
    return (projected + prof.timeout_s) <= deadline


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _log_retry  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _log_retry(tag, url, attempt, prof, status=None, exc=None, elapsed_ms=None):
    # type: (str, str, int, RetryProfile, Optional[int], Optional[BaseException], Optional[int]) -> None
    """Zapíše jeden neúspěšný pokus, po kterém následuje další.

    Úroveň je WARNING záměrně — chceme, aby to v `user_logs` bylo filtrovatelné
    stejně jako ostatní provozní anomálie. Opakované stejné zprávy sráží
    `RateLimitingFilter` v `richmovie_logging`, takže flapping Wi-Fi nezaplaví DB.
    """
    _log(
        "HTTP_RETRY tag=%s attempt=%d/%d status=%s url=%s"
        % (tag, attempt, prof.max_attempts, status if status is not None else "-",
           _safe_url(url)),
        _LEVEL_WARNING,
        context=_ctx(exc, tag=tag, url=_safe_url(url), attempt=attempt,
                     max_attempts=prof.max_attempts, http_status=status,
                     profile=prof.name, elapsed_ms=elapsed_ms),
    )


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _ctx  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _ctx(exc, **extra):
    # type: (Optional[BaseException], Any) -> Dict[str, Any]
    """Složí `context` pro log: popis chyby + doplňkové klíče. Nikdy nevyhodí."""
    ctx = {}  # type: Dict[str, Any]
    try:
        if exc is not None:
            ctx.update(describe_error(exc, http_status=extra.get("http_status")))
    except Exception:
        pass
    try:
        ctx.update({k: v for k, v in extra.items() if v is not None})
    except Exception:
        pass
    return ctx


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _safe_url  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _safe_url(url):
    # type: (str) -> str
    """Ořízne query string z URL před zápisem do logu.

    Query u nás nese hledané názvy filmů a u některých endpointů i identifikátory
    souborů. Do `user_logs` na NASu (a tím do GDPR perimetru) patří jen cesta —
    ta stačí k diagnostice „který endpoint zlobí". Zbytek by byl sběr navíc.
    """
    try:
        text = str(url)
        cut = text.find("?")
        return text if cut < 0 else text[:cut]
    except Exception:
        return "?"


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _report_success / _report_failure  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _report_success(ns, url):
    # type: (Any, str) -> None
    """Ohlásí netstate úspěšný kontakt se sítí. Bez Φ2 no-op."""
    if ns is None:
        return
    try:
        ns.report_success(host=_host_of(url))
    except Exception:
        pass


def _report_failure(ns, err_class, url, exc=None):
    # type: (Any, str, str, Optional[BaseException]) -> None
    """Ohlásí netstate neúspěch. Bez Φ2 no-op.

    Předává i příznak „lokální síťová chyba" — netstate podle něj rozliší výpadek
    linky (dvě takové chyby stačí na OFFLINE) od výpadku serveru (tři chyby a dva
    různé hosty). Bez toho rozlišení by jeden mrtvý scraper shodil celý addon.
    """
    if ns is None:
        return
    try:
        ns.report_failure(err_class, host=_host_of(url),
                          local=is_local_network_error(exc),
                          connect=is_connect_failure(exc))
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _host_of  (vytvořeno: 08.08.2026 11:05 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _host_of(url):
    # type: (str) -> str
    """Vytáhne hostname z URL.

    Netstate podle něj rozlišuje „spadl jeden zdroj" od „spadla síť" — tři selhání
    na jednom mrtvém scraperu nesmí shodit celý addon do offline režimu, když Gate
    i TMDb odpovídají.
    """
    try:
        text = str(url)
        start = text.find("://")
        start = 0 if start < 0 else start + 3
        end = len(text)
        for sep in ("/", "?", "#"):
            pos = text.find(sep, start)
            if 0 <= pos < end:
                end = pos
        host = text[start:end]
        at = host.rfind("@")
        if at >= 0:
            host = host[at + 1:]
        colon = host.rfind(":")
        if colon > 0:
            host = host[:colon]
        return host.lower()
    except Exception:
        return ""


# =========================================================================== #
# S23 (03.11.2026) — EVIDENCE ŽIVÝCH SOCKETŮ, ZRUŠENÍ A ROZPOZNÁNÍ ZACHYCENÍ
# =========================================================================== #
# PROČ: Kodi 21 při ukončení skriptu čeká na VŠECHNA vlákna interpretu bez ohledu na `daemon`
# (`PythonInvoker.cpp:384–406`) a po 5 s jim pošle `SystemExit` jako async výjimku — tu ale vlákno
# dostane až po návratu z blokujícího `recv`. Vlákno v long-pollu `/state/wait` (~30 s) nebo v požadavku,
# který zdržuje systémový filtr obsahu (Bětčin Mac 03.11.2026: 24 s vypínání), tak drží vypnutí Kodi.
# Pomůže jen zrušitelné I/O: služba při ukončení zavolá `cancel_all()`, ten z jiného vlákna udělá
# `shutdown(SHUT_RDWR)` všem živým socketům tohohle interpretu a blokující čtení se vrátí hned.
#
# Evidence vzniká bez kopie logiky stdlib: vlastní opener z `build_opener` (zachová výchozí handlery —
# proxy z prostředí, přesměrování, chyby) vymění jen třídy spojení; ty si zaregistrují TCP socket
# (`_create_connection`, pokryje i čekání na connect) a TLS socket (`SSLContext.sslsocket_class`, registrace
# v `do_handshake` — pokryje TLS handshake, při kterém je původní TCP socket už odpojený `detach()`).
#
# Druhý užitek téhož místa (Φ1 noci 03.11.): po `connect()` se porovná cíl s peerem socketu. Když jsme se
# připojovali na veřejnou adresu a socket končí na loopbacku, provoz zachytává lokální proxy — typicky
# systémový filtr obsahu (macOS Čas u obrazovky `webfilterproxyd` na 127.0.0.1:10011). Hlásí se do SSOT
# `richmovie_device_env`, který rozhodne, jak to vyložit (výpadky přes filtr nejsou výpadky sítě).
_IS_WINDOWS = os.name == "nt"
_live_lock = threading.Lock()
_live_socks = weakref.WeakSet()  # type: Any   # sockety (TCP i TLS) právě otevřené tímto interpretem
_cancel_state = {"reason": ""}   # neprázdné = interpret se ukončuje, nová spojení se neotevírají
_tracked_opener_lock = threading.Lock()
_tracked_opener = None  # type: Any


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# is_cancelled / _cancel_reason / cancel_all  (vytvořeno: 03.11.2026 20:55 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def is_cancelled():
    # type: () -> bool
    """Ukončuje se interpret (zavolal se `cancel_all`)? Pak se žádné nové spojení neotevírá."""
    return bool(_cancel_state.get("reason"))


def _cancel_reason():
    # type: () -> str
    return str(_cancel_state.get("reason") or "")


def cancel_all(reason="service_stop"):
    # type: (str) -> int
    """Zruší všechna právě běžící spojení tohoto interpretu a zakáže nová (S23).

    Volá JEN vlastník interpretu při ukončení (služba ve `finally` hlavní smyčky). Je idempotentní a
    nikdy nehází. `socket.socket.shutdown` (ne `SSLSocket.shutdown`) schválně: TLS vrstvu nechává
    vláknu, které socket drží — ukončí jen přenos na úrovni jádra, blokující `recv`/`connect` se vrátí
    s chybou a `request()` ji podle `is_cancelled()` vyloží jako `CancelledError`.

    Returns:
        Počet socketů, kterým se přenos ukončil.
    """
    with _live_lock:
        _cancel_state["reason"] = str(reason or "service_stop")
        socks = list(_live_socks)
    done = 0
    for sock in socks:
        try:
            if sock.fileno() < 0:
                continue
        except Exception:
            continue
        try:
            socket.socket.shutdown(sock, socket.SHUT_RDWR)
        except Exception:
            pass    # nepřipojený socket (čeká na connect) — shutdown neumí, na Windows pomůže close níže
        if _IS_WINDOWS:
            # Windows (ověřeno 03.11.2026): `shutdown` čekající `select`/`recv` v jiném vlákně NEPROBUDÍ (vlákno
            # dojelo až do timeoutu). Probudí ho až `closesocket`. Bezpečné: CPython při `close()` nejdřív zapíše
            # do objektu neplatný socket, čekající vlákno tak další `select` udělá nad neplatným socketem a skončí
            # chybou — nikdy nad cizím spojením. Na POSIX se NEzavírá: zavřené fd by mohl převzít jiný soubor
            # a čekající `poll` by na něm pokračoval; tam stačí `shutdown` (poll se vrátí, recv dá 0).
            # `_socket.socket.close` (= co dělá stdlib `_real_close`), ne `socket.socket.close`: odpověď http.client
            # drží `makefile()` (`_io_refs > 0`) a veřejné `close()` by skutečné zavření jen odložilo.
            try:
                _socket_mod.socket.close(sock)
            except Exception:
                pass
        done += 1
    try:
        _log("HTTP_CANCEL_ALL reason=%s sockets=%d" % (_cancel_reason(), done), _LEVEL_INFO,
             context={"reason": _cancel_reason(), "sockets": done})
    except Exception:
        pass
    return done


def live_socket_count():
    # type: () -> int
    """Počet evidovaných otevřených socketů (diagnostika + harness)."""
    with _live_lock:
        return sum(1 for s in list(_live_socks) if _fileno_safe(s) >= 0)


def _fileno_safe(sock):
    # type: (Any) -> int
    try:
        return int(sock.fileno())
    except Exception:
        return -1


def _track(sock):
    # type: (Any) -> None
    with _live_lock:
        _live_socks.add(sock)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _is_loopback_ip / _note_peer  (vytvořeno: 03.11.2026 20:55 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _is_loopback_ip(ip):
    # type: (str) -> bool
    text = str(ip or "").strip().lower()
    if text.startswith("::ffff:"):
        text = text[7:]
    return text == "::1" or text.startswith("127.")


def _is_private_ip(ip):
    # type: (str) -> bool
    """Soukromá / link-local adresa (LAN, NAS) — `ipaddress` stdlib; neplatná adresa = ne."""
    try:
        import ipaddress as _ipa
        text = str(ip or "").strip()
        if text.lower().startswith("::ffff:"):
            text = text[7:]
        addr = _ipa.ip_address(text.split("%", 1)[0])
        return bool(addr.is_private or addr.is_link_local)
    except Exception:
        return False


def _note_peer(host, target_ip, peer):
    # type: (str, str, Any) -> None
    """Po `connect()`: cíl byl veřejný, socket ale končí na loopbacku → provoz zachytává lokální proxy.

    Do SSOT `richmovie_device_env` (Φ1) se hlásí jen ZMĚNA výkladu; samotné rozhodnutí (co to znamená pro
    netstate, stres, zdraví zdroje) dělá výhradně `richmovie_device_env`. Nikdy nehází.
    """
    try:
        if _is_loopback_ip(target_ip) or _is_private_ip(target_ip):
            # loopback cíl = připojovali jsme se na něj sami (proxy z prostředí, lokální služba); LAN / link-local
            # (NAS Filmoteky) systémové filtry často pouští jinou cestou → nejsou důkaz ani jedním směrem a jen by
            # výklad rozkmitaly (cross-check Flash F9)
            return
        peer_ip = str(peer[0]) if isinstance(peer, (tuple, list)) and peer else ""
        peer_port = int(peer[1]) if isinstance(peer, (tuple, list)) and len(peer) > 1 else 0
        import richmovie_device_env as _denv   # type: ignore
        _denv.note_connection(host=str(host or ""), intercepted=_is_loopback_ip(peer_ip),
                              peer=("%s:%d" % (peer_ip, peer_port)) if peer_ip else "")
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _tracked_create_connection  (vytvořeno: 03.11.2026 20:55 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _tracked_create_connection(address, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None):
    # type: (Tuple[str, int], Any, Any) -> socket.socket
    """`socket.create_connection` se socketem zapsaným do evidence JEŠTĚ PŘED `connect()`.

    Stejná sémantika jako stdlib (všechny adresy z `getaddrinfo` popořadě, poslední chyba se předá dál),
    jen socket vzniká tady, aby šel zrušit i během čekání na TCP spojení. Po spojení se porovná cíl s peerem
    (rozpoznání zachycení, `_note_peer`).
    """
    host, port = address
    err = None  # type: Optional[BaseException]
    for family, socktype, proto, _canon, sockaddr in socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM):
        sock = None
        try:
            sock = socket.socket(family, socktype, proto)
            _track(sock)
            if is_cancelled():
                # OSError (ne CancelledError): smyčka i stdlib nad ní socket korektně zavřou; `request()` chybu podle
                # `is_cancelled()` vyloží jako `CancelledError` (bez retry, bez netstate)
                raise ConnectionAbortedError("pozadavek zrusen (%s)" % _cancel_reason())
            if timeout is not socket._GLOBAL_DEFAULT_TIMEOUT:
                sock.settimeout(timeout)
            if source_address:
                sock.bind(source_address)
            sock.connect(sockaddr)
            try:
                _note_peer(host, str(sockaddr[0]), sock.getpeername())
            except Exception:
                pass
            return sock
        except OSError as exc:
            err = exc
            if sock is not None:
                sock.close()
    if err is not None:
        raise err
    raise OSError("getaddrinfo returns an empty list")


class _TrackedSSLSocket(ssl.SSLSocket):
    """`SSLSocket`, který se zapíše do evidence před TLS handshakem (S23).

    Během `wrap_socket` je původní TCP socket už odpojený (`detach()`), takže zrušit jde jen tenhle objekt.
    """

    def do_handshake(self, block=False):
        _track(self)
        if is_cancelled():
            # OSError: `SSLSocket._create` při OSError/ValueError socket zavře (CancelledError by úklid obešla)
            raise ConnectionAbortedError("pozadavek zrusen (%s)" % _cancel_reason())
        return super().do_handshake(block)


class _TrackedHTTPConnection(http.client.HTTPConnection):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._create_connection = _tracked_create_connection


class _TrackedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, *args, **kwargs):
        own_context = kwargs.get("context") is None
        super().__init__(*args, **kwargs)
        self._create_connection = _tracked_create_connection
        ctx = getattr(self, "_context", None)
        # Kontext měníme JEN když ho stdlib právě vytvořil pro tohle spojení (cizí sdílený kontext nechat být).
        if own_context and ctx is not None and getattr(ctx, "sslsocket_class", None) is ssl.SSLSocket:
            try:
                ctx.sslsocket_class = _TrackedSSLSocket
            except Exception:
                pass


class _TrackedHTTPHandler(urllib.request.HTTPHandler):
    def http_open(self, req):
        return self.do_open(_TrackedHTTPConnection, req)


class _TrackedHTTPSHandler(urllib.request.HTTPSHandler):
    def https_open(self, req):
        kwargs = {"context": getattr(self, "_context", None)}
        check_hostname = getattr(self, "_check_hostname", None)    # Python ≤ 3.11; 3.12+ atribut nemá
        if check_hostname is not None:
            kwargs["check_hostname"] = check_hostname
        return self.do_open(_TrackedHTTPSConnection, req, **kwargs)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _default_opener  (vytvořeno: 03.11.2026 22:05 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _default_opener():
    # type: () -> Any
    """Čím se otevírá požadavek bez injektovaného `opener`. Do 4.0.5 se volalo `urllib.request.urlopen`
    za běhu, takže jeho náhrada (offline harness `_tools/net_resilience_sim`) nahradila síť; ten kontrakt
    zůstává: je-li `urlopen` stdlib funkce, jde se přes sledovaný opener, jinak přes náhradu."""
    current = urllib.request.urlopen
    if getattr(current, "__module__", "") == "urllib.request":
        return _tracked_urlopen
    return current


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_http.py
# _tracked_urlopen  (vytvořeno: 03.11.2026 20:55 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _tracked_urlopen(req, timeout=None):
    # type: (Any, Optional[float]) -> Any
    """Náhrada `urllib.request.urlopen` se sledovanými spojeními. Opener vzniká jednou za interpret
    z `build_opener` — výchozí řetězec handlerů zůstává (stdlib vynechá výchozí HTTP/HTTPS handler, když
    dostane jeho podtřídu)."""
    global _tracked_opener
    with _tracked_opener_lock:
        if _tracked_opener is None:
            _tracked_opener = urllib.request.build_opener(_TrackedHTTPHandler(), _TrackedHTTPSHandler())
    if timeout is None:
        return _tracked_opener.open(req)
    return _tracked_opener.open(req, timeout=timeout)
