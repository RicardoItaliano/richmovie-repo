# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_localization.py
# Lokalizace streamů – automatický výběr audia a titulků  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ⚠️ KODI PLUGIN: Proces-based architektura, lazy init pro session!
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Lokalizace streamů
───────────────────────────────────────────────────────────────────────────────
Tento modul obsahuje:

  • **Onboarding**           – Průvodce nastavením preferencí audia/titulků
  • **Normalizace jazyků**   – Mapování kódů na ISO-639
  • **Výběr streamů**        – Automatické přepnutí audia/titulků po startu přehrávání

API:
    ensure_localization_onboarding() -> None
    apply_stream_localization_async(m_tmdb, tv_id) -> None
    rm_normalize_lang_list(codes) -> Tuple[List[str], List[str]]
    rm_build_label_dubbing_subs(aud_codes, sub_codes) -> str
    rm_apply_av_streams_to_listitem(li, aud_codes, sub_codes) -> None

Autor: Richie – extrahováno 24-01-2026
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

# — Standardní knihovna —
import json
import time
import threading
from typing import Callable, List, Tuple

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import richmovie_settings  # SSOT čtení i ověřeného zápisu nastavení (3.5.124)

# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.83): DEBUG záznamy (addAudio/Subtitle
# stream fail) přepnuty na ROUTOVANÝ logger → tečou na NAS. Fallback = přímý
# xbmc.log (best-effort, nesmí shodit lokalizaci).
try:
    from richmovie_logging import make_legacy_logger as _loc_make_legacy_logger
    _loc_log = _loc_make_legacy_logger("richmovie.localization", "RichMovie/UI")
except Exception:
    def _loc_log(msg, level=xbmc.LOGDEBUG, *, context=None):
        try:
            xbmc.log("[RichMovie/UI] " + str(msg), level)
        except Exception:
            pass

# — Lokální moduly —
from tmdb_client import TMDb
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ─────────────────────────────────────────────────────────────────────────────
#  MODUL-LEVEL PROMĚNNÉ
# ─────────────────────────────────────────────────────────────────────────────
# Lazy init pro ADDON – proces-based architektura Kodi
_ADDON: xbmcaddon.Addon | None = None

# Callback pro logování – nastaví se z plugin.py
_log_event_callback: Callable[..., None] | None = None


def _get_addon() -> xbmcaddon.Addon:
    """Lazy init pro ADDON instanci."""
    global _ADDON
    if _ADDON is None:
        _ADDON = xbmcaddon.Addon()
    return _ADDON


def set_log_callback(callback: Callable[..., None]) -> None:
    """Nastaví callback pro logování (voláno z plugin.py)."""
    global _log_event_callback
    _log_event_callback = callback


def _log_event(event: str, *params: object) -> None:
    """Wrapper pro logování – deleguje na callback nebo tiše ignoruje."""
    if _log_event_callback:
        try:
            _log_event_callback(event, *params)
        except Exception:
            pass




# ─────────────────────────────────────────────────────────────────────────────
#  ONBOARDING
# ─────────────────────────────────────────────────────────────────────────────


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _onboard_version  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _onboard_version() -> str:
    """Interní verze průvodce (změň při úpravách dotazů)."""
    return "2025-09-05-01"


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# ensure_localization_onboarding  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def ensure_localization_onboarding() -> None:
    """
    PRVNÍ SPUŠTĚNÍ / PO AKTUALIZACI:
    • Jednou se dotáže na preferenci audia a titulků a uloží do settings.
    • Φ3 (29.09.2026): volá se jako krok `localization` uvítací sekvence (`richmovie_onboarding.STEPS`)
      — pořadí dialogů a „kreslí jen jeden proces“ hlídá claim sekvence, vlastní semafor
      `richmovie.setup_busy` s čekáním `xbmc.sleep` (až 30 s) už není potřeba.
    • Běží jen pokud ještě není nastaveno 'loc_onboard_done' == _onboard_version().
    """
    try:
        addon = _get_addon()
        win = xbmcgui.Window(10000)
        ver_done = richmovie_settings.get_str("loc_onboard_done") or ""
        if ver_done == _onboard_version():
            return  # už hotovo pro tuto verzi průvodce

        # 3.5.120 — POJISTKA PROTI DIALOGU DOKOLA (incident bandog 27.08.2026)
        #
        # Průvodce se řídí settingem `loc_onboard_done`. Když se zápis nepovede
        # NEBO se hodnota nepřečte, podmínka výše nikdy neplatí a uživateli
        # naskočí dvojice dialogů při každém otevření menu. Robert to zažil celý
        # večer. Window property drží „už jsem se ptal" po dobu běhu Kodi, takže
        # ani při rozbitém zápisu se člověk nedostane do smyčky — nejhůř dostane
        # jeden dotaz po restartu, ne jeden na každé kliknutí.
        # Window(10000) je meziprocesová (každá invokace pluginu = nový interpret),
        # takže to platí i mezi jednotlivými otevřeními menu.
        if win.getProperty("richmovie.loc.onboard_asked") == "1":
            return

        # 1) Audio preference
        idx = xbmcgui.Dialog().select(
            "Preferuješ původní znění nebo český dabing?",
            ["Původní znění (originál)", "Český dabing"]
        )
        if idx < 0:
            # uživatel zrušil → nedělej nic (průvodce se zobrazí znovu příště)
            return
        # Průvodce se v této session už znovu neptá, ať dopadne zápis jakkoli.
        win.setProperty("richmovie.loc.onboard_asked", "1")

        # 3.5.120: zapisuje se INDEX, ne řetězec. Settings jsou v
        # `resources/settings.xml:88-110` deklarované jako `type="enum"`
        # (hodnota = index), kdežto do 3.5.119 se sem posílalo "original" /
        # "cz_dub" / "cs" / "en" — zápis mimo doménu typu, tedy nedefinované
        # chování (feedback_kodi_settings_xml_types).
        # Čtení (`_get_audio_pref` / `_get_sub_pref` níže) zůstává tolerantní
        # k obojímu, takže hodnoty uložené staršími verzemi u 16 uživatelů
        # dál fungují a rollback na 3.5.119 je bezpečný.
        audio_pref = "original" if idx == 0 else "cz_dub"
        richmovie_settings.write("loc_audio_pref", "0" if idx == 0 else "1")

        # 2) Titulky (navazující otázka podle volby)
        if audio_pref == "cz_dub":
            q = "Když CZ dabing nebude, jaké titulky preferuješ?"
        else:
            q = "Preferuješ české, nebo anglické titulky?"

        idx2 = xbmcgui.Dialog().select(q, ["České", "Anglické"])
        if idx2 < 0:
            return
        subs_idx = "0" if idx2 == 0 else "1"
        # uložíme do obou klíčů – stejné chování (líší se fallback)
        richmovie_settings.write("loc_subs_if_no_dub", subs_idx)
        richmovie_settings.write("loc_subs_for_original", subs_idx)

        # 3) Forced titulky – lidsky pojmenované, výchozí ZAPNUTO
        # (u CZ dabingu ponechat jen vložené titulky pro cizojazyčné pasáže)
        richmovie_settings.write_bool("loc_respect_forced", True)

        # 3.5.120 — RAZÍTKO SE OVĚŘUJE ZPĚTNÝM ČTENÍM (All-or-Nothing pro efekt).
        # Do 3.5.119 se razítko zapsalo naslepo a případná výjimka ze zápisů
        # výše ho přeskočila (spadla do `except: pass` na konci funkce) →
        # průvodce se ptal znovu. Teď se zápis ověří; když se neuchytí, ví se
        # o tom a spoléhá se na Window property guard výše.
        richmovie_settings.write("loc_onboard_done", _onboard_version())
        if (richmovie_settings.get_str("loc_onboard_done") or "") != _onboard_version():
            _log_event(
                "LOC_ONBOARD_STAMP_FAILED",
                "razitko se neulozilo – pruvodce potlacen jen do restartu Kodi",
            )

        try:
            _rm_notif("Zvuk a titulky uloženy.", xbmcgui.NOTIFICATION_INFO, None, "RichMovie")
        except Exception:
            pass
    except Exception:
        # nikdy nesmí shodit plugin
        pass




# ─────────────────────────────────────────────────────────────────────────────
#  POMOCNÉ FUNKCE
# ─────────────────────────────────────────────────────────────────────────────


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _jsonrpc  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _jsonrpc(method: str, params: dict) -> dict:
    """Bezpečný JSON-RPC wrapper (Kodi)."""
    try:
        payload = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        raw = xbmc.executeJSONRPC(payload)
        data = json.loads(raw) if isinstance(raw, str) else (raw or {})
        if isinstance(data, dict) and "error" not in data:
            return data.get("result") or {}
    except Exception:
        pass
    return {}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _norm_lang  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _norm_lang(val: str) -> str:
    """
    Normalizace jazykového kódu/labelu na zkrácený kód:
    cs (cze/ces/cz/čeština/czech), en (eng/english/anglicky), sk (slk/slo/slovak),
    pl (pol/polish/polski/polština) …
    """
    s = (val or "").strip().lower()
    if not s:
        return ""
    # základní synonymní slova (CZ/EN/SK/PL)
    s = (s.replace("čeština", "czech")
           .replace("angličtina", "english")
           .replace("anglicky", "english")
           .replace("slovenčina", "slovak")
           .replace("polština", "polish")
           .replace("polsky", "polish"))

    # mapování na 2písmenné kódy
    if s in {"cs","cze","ces","cz","czech"}:   return "cs"
    if s in {"en","eng","english"}:           return "en"
    if s in {"sk","slk","slo","slovak"}:      return "sk"
    if s in {"pl","pol","polish","polski"}:   return "pl"
    # poslední pokus – když je to delší název, vezmeme první 2 znaky
    return s[:2]




# ─────────────────────────────────────────────────────────────────────────────
#  NORMALIZACE JAZYKŮ
# ─────────────────────────────────────────────────────────────────────────────


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# rm_normalize_lang_list  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def rm_normalize_lang_list(codes: List[str]) -> Tuple[List[str], List[str]]:
    """
    Normalizace kódů jazyků z MI2 na ISO‑639 (pro InfoTagVideo) + zobrazení.

    Vstup:  seznam zkratek (typicky MI2 → 'CZ','EN','DE', ...; občas i 'DU','PO','TU', ...)
    Výstup: (iso_langs, disp_langs)
        - iso_langs  … seznam ISO‑639 (3písmenné kódy) pro Kodi flagy (např. 'ces','eng','deu', ...)
        - disp_langs … „uživatelské" zkratky ke zobrazení v labelu (původní 2písmenné kódy v UPPER)

    Pozn.: Neznámé/neurčité 2písmenné kódy do ISO nesypeme (Kodi by je neflagovalo),
           ale ponecháme je v `disp_langs`, aby se objevily v textu.
    """
    iso_map = {
        "AR": "ara", "BA": "bos", "BR": "por", "CA": "cat", "CH": "",    "CR": "",   "CS": "ces", "CZ": "ces",
        "DA": "dan", "DE": "deu", "DU": "nld", "EL": "ell", "EN": "eng", "ES": "spa","EU": "eus", "FI": "fin",
        "FO": "fao", "FR": "fra", "GA": "gle", "GL": "glg", "GR": "ell", "HE": "heb","HR": "hrv", "HU": "hun",
        "ID": "ind", "IN": "ind", "IT": "ita", "JA": "jpn", "JP": "jpn", "KO": "kor","LA": "lat", "MA": "",
        "MS": "msa", "NB": "nob", "NL": "nld", "NO": "nor", "PL": "pol", "PO": "pol","PT": "por", "RO": "ron",
        "RU": "rus", "SD": "snd", "SI": "slv", "SK": "slk", "SV": "swe", "SW": "swa","TH": "tha", "TR": "tur",
        "TU": "tur", "UK": "ukr", "VI": "vie", "ZH": "zho",
    }

    iso_langs: List[str] = []
    disp_langs: List[str] = []

    for raw in codes or []:
        c = (raw or "").strip().upper()
        if not c:
            continue
        # zobrazení (co nejblíž tomu, co MI2 vrací)
        if c not in disp_langs:
            disp_langs.append(c)
        # ISO (jen pro známé kódy)
        iso = iso_map.get(c, "")
        if iso and iso not in iso_langs:
            iso_langs.append(iso)

    return iso_langs, disp_langs


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# rm_build_label_dubbing_subs  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def rm_build_label_dubbing_subs(aud_codes: List[str], sub_codes: List[str]) -> str:
    """
    Vyrobí krátký dovětek do labelu za velikost souboru: např.
        "CZ dabing • titulky: CZ"
        "EN/DE zvuk • titulky: CZ, EN"
        "EN zvuk • bez titulků"

    Vstup: kódy jako je vrací MI2 (např. 'CZ','EN',...). Funkce si je sama znormalizuje pro zobrazení.
    """
    _, aud_disp = rm_normalize_lang_list(aud_codes)
    _, sub_disp = rm_normalize_lang_list(sub_codes)

    audio_txt = ""
    if "CZ" in aud_disp or "CS" in aud_disp:
        # český dabing chceme pojmenovat "dabing" (uživatelsky srozumitelné)
        others = [x for x in aud_disp if x not in ("CZ", "CS")]
        audio_txt = "CZ dabing" + (f" + {'/'.join(others)}" if others else "")
    elif aud_disp:
        audio_txt = "/".join(aud_disp) + " zvuk"

    subs_txt = "bez titulků"
    if sub_disp:
        subs_txt = "titulky: " + ", ".join(sub_disp)

    if audio_txt and subs_txt:
        return f"{audio_txt} • {subs_txt}"
    return audio_txt or subs_txt


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# rm_apply_av_streams_to_listitem  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def rm_apply_av_streams_to_listitem(li: xbmcgui.ListItem, aud_codes: List[str], sub_codes: List[str]) -> None:
    """
    Promítne dabing/titulky do InfoTagVideo tak, aby je Kodi 20/21 korektně zobrazilo
    (vlaječky/ikony jazyků, bez deprecation varování).

    Technicky:
      • Přidáme AudioStreamDetail/SubtitleStreamDetail do InfoTagu.
      • Používáme ISO‑639 kódy (3písmenné), jak doporučuje Kodi pro stream detaily.
      • Záměrně neřešíme "clear" – běžně se ListItem rekonstruuje při refreshi.
    """
    try:
        tag = li.getVideoInfoTag()  # ListItem → InfoTagVideo
    except Exception:
        return

    aud_iso, _ = rm_normalize_lang_list(aud_codes)
    sub_iso, _ = rm_normalize_lang_list(sub_codes)

    # Přidej audio streamy (kanály/codec neznáme → necháme výchozí/blank)
    for lang in aud_iso:
        try:
            tag.addAudioStream(xbmc.AudioStreamDetail(-1, "", lang))
        except Exception as e:
            try:
                from richmovie_logging import make_legacy_logger as _mll
                _mll("richmovie.ui", "RichMovie/UI")(f"addAudioStream failed: {e}", xbmc.LOGDEBUG)
            except Exception:
                _loc_log(f"addAudioStream failed: {e}", xbmc.LOGDEBUG)

    # Přidej titulky
    for lang in sub_iso:
        try:
            tag.addSubtitleStream(xbmc.SubtitleStreamDetail(lang))
        except Exception as e:
            try:
                from richmovie_logging import make_legacy_logger as _mll
                _mll("richmovie.ui", "RichMovie/UI")(f"addSubtitleStream failed: {e}", xbmc.LOGDEBUG)
            except Exception:
                _loc_log(f"addSubtitleStream failed: {e}", xbmc.LOGDEBUG)




# ─────────────────────────────────────────────────────────────────────────────
#  VÝBĚR AUDIO/TITULKŮ
# ─────────────────────────────────────────────────────────────────────────────


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _pick_audio_index  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _pick_audio_index(audiostreams: list, audio_pref: str, orig_lang: str | None) -> int | None:
    """
    Vrátí index audio stopy dle preference.
    • audio_pref == "cz_dub": zkus cs → jinak necháme originál/EN (řeší se v _apply_…).
    • audio_pref == "original": zkus orig_lang (TMDb) → jinak EN → jinak první dostupnou.
    """
    if not isinstance(audiostreams, list) or not audiostreams:
        return None

    def by_lang(want: str) -> int | None:
        if not want:
            return None
        for st in audiostreams:
            try:
                idx = int(st.get("index"))
            except Exception:
                idx = st.get("index")
            lang = _norm_lang(st.get("language") or st.get("name") or "")
            name = (st.get("name") or "").lower()
            # přímá shoda kódu
            if lang == want:
                return idx
            # heuristiky podle jména stopy
            if want == "cs" and (" czech" in name or "češtin" in name):
                return idx
            if want == "en" and (" eng" in name or "english" in name or "angl" in name):
                return idx
        return None

    if audio_pref == "cz_dub":
        i = by_lang("cs")
        if i is not None:
            return i
        # když není CZ, nech konečný výběr na _apply_… (zohlední titulky)
        return None

    # original
    i = by_lang(_norm_lang(orig_lang or ""))
    if i is None:
        i = by_lang("en")
    if i is not None:
        return i

    # fallback: první dostupná
    try:
        return int(audiostreams[0].get("index"))
    except Exception:
        return audiostreams[0].get("index")


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _stream_index  (vytvořeno: 09.10.2026 21:00 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _stream_index(st: dict):
    """Index stopy z JSON-RPC (`Player.GetProperties`) jako int; nečíselný se vrací beze změny (fallback
    `Player.SetSubtitle` podle jména si s ním poradí)."""
    try:
        return int(st.get("index"))
    except Exception:
        return st.get("index")


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _is_forced_sub  (vytvořeno: 09.10.2026 21:00 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _is_forced_sub(st: dict) -> bool:
    """JEDNA definice „vynucená titulková stopa“ (jen nápisy / cizojazyčné pasáže, ne dialogy): příznak Kodi
    `isforced` (JSON-RPC, Kodi 20+), nebo název u releasů bez příznaku — „Forced“, „Only forced“,
    „Czech [ForcedNarrative]“, „vynucené“. Název je záměr (releasy bez příznaku; cross-check Pro P7 zamítnut).
    Položka, která není slovník, vynucená není (zpevnění dle cross-checku Flash F8)."""
    if not isinstance(st, dict):
        return False
    name = str(st.get("name") or "").lower()
    return bool(st.get("isforced")) or "forced" in name or "vynucen" in name


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _sub_matches_lang  (vytvořeno: 09.10.2026 21:00 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _sub_matches_lang(st: dict, want: str) -> bool:
    """Je titulková stopa v jazyce `want` (kód z `_norm_lang`)? Jazyk stopy, jinak název; u češtiny i název
    stopy („… Czech“, „čeština“) — sémantika beze změny proti původnímu `_pick_sub_index.by_lang`."""
    if not want or not isinstance(st, dict):
        return False
    lang = _norm_lang(str(st.get("language") or st.get("name") or ""))
    name = str(st.get("name") or "").lower()
    return lang == want or (want == "cs" and (" czech" in name or "češtin" in name))


#: Vynucené nápisy v „sousedním“ jazyce, když v jazyce zvuku žádné nejsou (cross-check Pro P10, 09.10.2026): čeština
#: a slovenština jsou vzájemně srozumitelné. Jazyk zvuku má VŽDY přednost (= volba Kodi); soused jen zaplní mezeru,
#: kdy by Kodi nezapnulo nic — proti kladné volbě Kodi se tím nikdy nepřepíná.
_FORCED_SUB_LANGS = {"cs": ("cs", "sk"), "sk": ("sk", "cs")}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _find_forced_sub  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague; jazyk zvuku 09.10.2026 21:00 CEST)
# ---------------------------------------------------------------------------- #
def _find_forced_sub(subtitles: list, audio_lang: str, current: dict | None = None) -> int | None:
    """Index vynucené titulkové stopy V JAZYCE ZVUKU, jinak None (= titulky vypnout).

    Zrcadlo pravidla Kodi (`PredicateSubtitlePriority`, Kodi 21.2 `VideoPlayer.cpp:265–268`): při vypnutých
    titulcích / `locale.subtitlelanguage = forced_only` má přednost vynucená stopa v jazyce zvuku. Priming
    (`desired_kodi_settings`) nastaví Kodi přesně tak, worker proto musí chtít totéž — jinak přepíná proti volbě
    Kodi (přepnutí za běhu = zbytečná práce přehrávače).

    4.0.1 (Sony BRAVIA 09.10.2026 20:16:48): dřív se brala PRVNÍ vynucená stopa bez ohledu na jazyk → u českého
    dabingu „Hry na oliheň“ worker přepnul Kodi z „Czech [ForcedNarrative]“ na anglické „Forced“. Jiný jazyk než
    zvuk se nevybírá (anglické nápisy k českému dabingu nedávají smysl — plán D7); výjimkou je jen vzájemně
    srozumitelný soused (`_FORCED_SUB_LANGS`: cs ↔ sk) jako DRUHÁ volba, když v jazyce zvuku vynucená stopa není.

    `current` (Player.GetProperties: `currentsubtitle`, `subtitleenabled`) — audit Fable F-5: když Kodi už UKAZUJE
    vynucenou stopu ve vybraném jazyce, vrátí se ta (Kodi má vlastní prioritu — externí stopa, příznak default);
    worker by jinak při dvou vhodných stopách přepnul na první v seznamu.
    """
    want = _norm_lang(audio_lang or "")
    if not want:
        return None
    candidates = [st for st in (subtitles or []) if _is_forced_sub(st)]
    cur_idx = None
    if isinstance(current, dict) and current.get("subtitleenabled"):
        cur = current.get("currentsubtitle")
        if isinstance(cur, dict):
            cur_idx = _stream_index(cur)
    for lang in _FORCED_SUB_LANGS.get(want, (want,)):
        in_lang = [st for st in candidates if _sub_matches_lang(st, lang)]
        if not in_lang:
            continue
        if cur_idx is not None and any(_stream_index(st) == cur_idx for st in in_lang):
            return cur_idx
        return _stream_index(in_lang[0])
    return None


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _pick_sub_index  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague; plné stopy 09.10.2026 21:00 CEST)
# ---------------------------------------------------------------------------- #
def _pick_sub_index(subtitles: list, prefer: str, *, fallback_chain: list[str]) -> int | None:
    """
    Vybere index PLNÉ titulkové stopy (dialogy) s danou preferencí a fallbackem.
    • prefer == "cs" → řetězce např. ["cs", "sk", "en"]
    • prefer == "en" → řetězce např. ["en", "cs", "sk"]

    4.0.1 (plán D8): PLNÁ stopa v jazycích diváka má přednost před vynucenou — u releasů, kde „Czech forced“ leží
    před plnými českými, by divák originálu neměl titulky k dialogům. Pořadí: plná v řetězci jazyků → vynucená
    v řetězci jazyků (cross-check Pro P9: ripy, kde jediná česká stopa je — často chybně — označená „forced“; dřív
    se vybrala, „nic“ by byl regres) → první plná v jiném jazyce → None (volbu nechat Kodi, nic nepřepínat).
    """
    if not isinstance(subtitles, list) or not subtitles:
        return None
    full = [st for st in subtitles if isinstance(st, dict) and not _is_forced_sub(st)]
    forced = [st for st in subtitles if _is_forced_sub(st)]
    for group in (full, forced):
        for code in fallback_chain or []:
            for st in group:
                if _sub_matches_lang(st, code):
                    return _stream_index(st)
    # nouzový fallback: první PLNÁ stopa v jiném jazyce (vynucená v cizím jazyce by divákovi nepomohla)
    if full:
        return _stream_index(full[0])
    return None


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _current_audio_lang  (vytvořeno: 09.10.2026 21:00 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _current_audio_lang(current: dict) -> str:
    """Jazyk právě hrající zvukové stopy (`currentaudiostream` z `Player.GetProperties`) — pro vynucené titulky,
    když worker zvuk sám nepřepíná (Kodi porovnává s jazykem hrající stopy)."""
    if not isinstance(current, dict):
        return ""
    cur = current.get("currentaudiostream") or {}
    if not isinstance(cur, dict):
        return ""
    return _norm_lang(str(cur.get("language") or cur.get("name") or ""))


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _get_tmdb_original_language  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _get_tmdb_original_language(m_tmdb: int | None, tv_id: int | None) -> str | None:
    """
    Získá 'original_language' z TMDb (film/seriál). Pokud není dostupné, vrátí None.
    """
    try:
        from richmovie_settings import get_tmdb_api_key
        # SSOT 3.5.69 (bandog vzor): lokální setting je jen cache plněná při
        # WS-loginu — accessor padá na klíč z Gate lease cache.
        tmdb_key = get_tmdb_api_key()
        if not tmdb_key:
            return None
        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        if tv_id:
            det = tmdb.tv_details(int(tv_id)) or {}
            lang = (det.get("original_language") or "").strip().lower()
            return lang or None
        if m_tmdb:
            det = tmdb.details(int(m_tmdb)) or {}  # ← filmový detail (SPRÁVNÁ metoda)
            lang = (det.get("original_language") or "").strip().lower()
            return lang or None
        return None
    except Exception:
        return None




# ─────────────────────────────────────────────────────────────────────────────
#  HLAVNÍ FUNKCE – APLIKACE LOKALIZACE
# ─────────────────────────────────────────────────────────────────────────────


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# apply_stream_localization_async  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def apply_stream_localization_async(
    *, m_tmdb: int | None = None, tv_id: int | None = None,
    m_title: str | None = None, m_year: int | None = None,
) -> None:
    """
    Robustní přepínač audio/titulků po startu přehrávání s podrobným logováním (LOC_*).

    Co dělá:
      • Vyčká na aktivní video player (JSON-RPC).
      • Vyčká, až Kodi zveřejní audiostreams/subtitles (řeší „příliš brzy" po startu).
      • Zjistí originální jazyk z TMDb (pokud máme film/TV ID).
      • Rozhodne podle Tvých preferencí (originál vs CZ dabing, titulky + forced).
      • Přepne audio (Player.SetAudioStream) a titulky (Player.SetSubtitle).
      • Vše detailně zaloguje: LOC_START/ACTIVE/PROPS/PICK/SET_* a finální LOC_DECISION.

    Preferenční pravidla:
      • CZ dabing → titulky vypnout; je-li zapnuto „forced", zkusí zapnout jen forced stopu.
      • Původní znění → audio = TMDb original_language (pokud dostupné), jinak EN, jinak první.
      • Titulky pro originál: preferované (CS/EN) s fallback řetězcem:
           – prefer EN: EN → CS → SK → první dostupná
           – prefer CS: CS → SK → EN → první dostupná
      • Když CZ dabing není a uživatel ho chtěl → titulky dle „Když CZ dabing není…" (CS→SK→EN nebo EN→CS→SK).
    """
    addon = _get_addon()

    # — vnitřní helper: shrnutí stop do čitelných struktur pro log —
    def _summarize_streams(auds: list, subs: list) -> dict:
        def _aud():
            out = []
            for st in auds or []:
                try:
                    idx = int(st.get("index"))
                except Exception:
                    idx = st.get("index")
                out.append({
                    "i": idx,
                    "lang": _norm_lang(st.get("language") or st.get("name") or ""),
                    "name": (st.get("name") or "")[:80]
                })
            return out
        def _sub():
            out = []
            for st in subs or []:
                try:
                    idx = int(st.get("index"))
                except Exception:
                    idx = st.get("index")
                nm = (st.get("name") or "")
                out.append({
                    "i": idx,
                    "lang": _norm_lang(st.get("language") or nm),
                    "name": nm[:80],
                    "forced": bool(st.get("isforced"))
                })
            return out
        return {"auds": _aud(), "subs": _sub()}

    # — vnitřní helper: RPC + odlogování —
    def _rpc(method: str, params: dict) -> dict:
        res = _jsonrpc(method, params)
        try:
            _log_event("LOC_RPC", method, json.dumps(params, ensure_ascii=False), json.dumps(res, ensure_ascii=False))
        except Exception:
            pass
        return res

    # — vnitřní helpery: bezpečné čtení nastavení (enum/bool napříč verzemi Kodi) —
    # 3.5.155: preference = PROFIL > zařízení (SSOT `effective_prefs`); nested gettery jen delegují.
    _eff = effective_prefs()

    def _get_audio_pref() -> str:
        return _eff["audio_pref"]

    def _get_sub_pref(id_: str, default_code: str) -> str:
        return _eff["subs_if_no_dub"] if id_ == "loc_subs_if_no_dub" else _eff["subs_for_orig"]
    def _get_bool(id_: str, default: bool) -> bool:
        """Bezpečný bool getter (kompatibilita s různými verzemi Kodi)."""
        try:
            return bool(richmovie_settings.get_bool(id_))  # preferovaný způsob
        except Exception:
            try:
                s = (richmovie_settings.get_str(id_) or "").strip().lower()
                return s in {"true", "1", "yes", "on"}
            except Exception:
                return default

    # — samotný pracovní thread —
    def _worker():
        try:
            # Vycistit predchozi loc stav na zacatku nove lokalizace
            _init_win = xbmcgui.Window(10000)
            _init_win.clearProperty("richmovie.loc.init_done")
            _init_win.clearProperty("richmovie.loc.applied_state")
            _init_win.clearProperty("richmovie.loc.title_key")

            _log_event("LOC_START", {"m_tmdb": m_tmdb, "tv_id": tv_id})

            # 1) Počkej na aktivního video playera (≤ ~10 s)
            player_id = None
            for _ in range(40):
                players = _rpc("Player.GetActivePlayers", {})
                for p in players or []:
                    if p.get("type") == "video":
                        player_id = p.get("playerid")
                        break
                if player_id is not None:
                    break
                xbmc.sleep(250)
            if player_id is None:
                _log_event("LOC_FAIL", "no_active_player")
                return
            _log_event("LOC_ACTIVE", player_id)

            # 2) Počkej na naplnění audiostreams/subtitles (≤ ~20 s) – průběžné logy
            auds, subs = [], []
            for i in range(80):
                props = _rpc("Player.GetProperties", {
                    "playerid": player_id,
                    # ⚠️ Správný klíč je 'subtitleenabled' (singulár), ne 'subtitlesenabled'
                    "properties": ["audiostreams", "currentaudiostream", "subtitles", "currentsubtitle", "subtitleenabled"]
                }) or {}
                auds = props.get("audiostreams") or []
                subs = props.get("subtitles") or []
                current_state = props   # 3.5.155: co Kodi vybralo při otevření (priming)
                _log_event("LOC_PROPS", {"try": i + 1, "summary": _summarize_streams(auds, subs)})
                if auds or subs:
                    # malá rezerva – některé buildy doplní názvy/flagy se zpožděním
                    if i < 6:
                        xbmc.sleep(500)
                    break
                xbmc.sleep(250)

            if not auds and not subs:
                _log_event("LOC_FAIL", "props_empty_after_wait")
                return

            # 3) Uživatelské preference (bezpečně z enum/bool)
            audio_pref     = _get_audio_pref()                       # "cz_dub" | "original"
            subs_if_no_dub = _get_sub_pref("loc_subs_if_no_dub", "cs")   # "cs" | "en"
            subs_for_orig  = _get_sub_pref("loc_subs_for_original", "cs") # "cs" | "en"
            keep_forced    = _get_bool("loc_respect_forced", True)

            # 3.5) Per-title override – individuální paměť audia/titulků
            import richmovie_title_prefs as _tp
            title_key = _tp.make_title_key(
                m_tmdb=m_tmdb, tv_id=tv_id, m_title=m_title, m_year=m_year
            )
            title_pref = _tp.get_pref(title_key) if title_key else None

            audio_idx = None
            want_sub_index = None
            want_sub_enable = False
            _used_title_pref = False
            # Jazyk zvuku, který OPRAVDU hraje (pro vynucené titulky = pravidlo Kodi): výchozí = stopa, kterou otevřelo
            # Kodi; mění se jen po POTVRZENÉM přepnutí, nebo když cílová stopa už hraje (cross-check Codex 09.10.2026:
            # při selhaném `SetAudioStream` se dřív bral jazyk stopy, na kterou se jen chtělo přepnout).
            playing_audio_lang = _current_audio_lang(current_state)

            if title_pref:
                # ── PER-TITLE PREFERENCE PATH ──
                tp_audio = (title_pref.get("audio_lang") or "").strip()
                tp_sub = (title_pref.get("sub_lang") or "").strip()
                tp_sub_on = bool(title_pref.get("sub_enabled"))

                _log_event("LOC_TITLE_PREF_FOUND", {
                    "key": title_key, "pref": title_pref
                })

                # Najdi audio stream odpovídající uloženému jazyku
                tp_audio_idx = None
                if tp_audio and auds:
                    for st in auds:
                        lang = _norm_lang(st.get("language") or st.get("name") or "")
                        if lang == tp_audio:
                            try:
                                tp_audio_idx = int(st.get("index"))
                            except Exception:
                                tp_audio_idx = st.get("index")
                            break

                # Najdi subtitle stream odpovídající uloženému jazyku — 4.0.1 (plán D8): PLNÁ stopa má přednost
                # před vynucenou téhož jazyka (zapnuté titulky = dialogy); vynucená jen když plná v jazyce není.
                tp_sub_idx = None
                if tp_sub_on and tp_sub and subs:
                    in_lang = [st for st in subs if isinstance(st, dict) and _sub_matches_lang(st, _norm_lang(tp_sub))]
                    full_in_lang = [st for st in in_lang if not _is_forced_sub(st)]
                    pick = (full_in_lang or in_lang or [None])[0]
                    if pick is not None:
                        tp_sub_idx = _stream_index(pick)

                if tp_audio_idx is not None or tp_sub_idx is not None or (not tp_sub_on):
                    # Per-title preference je použitelná
                    _used_title_pref = True
                    if tp_audio_idx is not None:
                        audio_idx = tp_audio_idx
                        if plan_switches(current_state, audio_idx=audio_idx)["audio"]:
                            r = _rpc("Player.SetAudioStream", {"playerid": player_id, "stream": audio_idx})
                            _log_event("LOC_SET_AUDIO_OK" if r else "LOC_SET_AUDIO_ERR",
                                       {"idx": audio_idx, "source": "title_pref"})
                            if r:
                                playing_audio_lang = _norm_lang(tp_audio)
                        else:
                            playing_audio_lang = _norm_lang(tp_audio)
                            _log_event("LOC_SET_AUDIO_SKIP", {"idx": audio_idx, "source": "title_pref",
                                                              "why": "already_selected"})

                    if not tp_sub_on:
                        # 4.0.1 (plán D9): titulky vypnuté, ale „respektovat vynucené“ → vynucená stopa v jazyce
                        # zvuku, který hraje, jinak vypnout. Stejně jako priming (`desired_kodi_settings` →
                        # `forced_only`); dřív tady natvrdo „off“ = worker vypínal nápisy, které Kodi správně zapnulo.
                        forced_idx = _find_forced_sub(subs, playing_audio_lang, current_state) \
                            if (keep_forced and subs) else None
                        if forced_idx is not None:
                            want_sub_index = forced_idx
                            want_sub_enable = True
                        else:
                            want_sub_index = "off"
                            want_sub_enable = False
                    elif tp_sub_idx is not None:
                        want_sub_index = tp_sub_idx
                        want_sub_enable = True
                    else:
                        # Uložený jazyk titulků není v tomto streamu
                        _log_event("LOC_TITLE_PREF_SUB_MISS", {
                            "key": title_key, "wanted_sub": tp_sub
                        })
                else:
                    # Ani audio ani sub se nepodařilo najít → fallback na globální
                    _log_event("LOC_TITLE_PREF_MISS", {
                        "key": title_key, "wanted_audio": tp_audio
                    })

            if not _used_title_pref:
                # ── GLOBAL PREFERENCE PATH (původní logika; 4.0.1: vynucené jen v jazyce zvuku, plné bez vynucených) ──

                # 4) Originální jazyk z TMDb (film/seriál) – může být None
                orig_lang = _get_tmdb_original_language(m_tmdb, tv_id)

                # 5) Předběr audio indexu dle preferencí
                audio_idx = _pick_audio_index(auds, audio_pref, orig_lang)

                # 6) Rozhodovací logika
                if audio_pref == "cz_dub":
                    # Hraje český dabing? (stopa existuje A už hraje, nebo přepnutí Kodi potvrdilo). 4.0.1 (cross-check
                    # Codex 09.10.2026): selhané přepnutí = divák zůstal u originálu → stejná cesta jako „dabing není“
                    # (plné titulky), ne české vynucené nápisy přes cizí zvuk.
                    dub_playing = False
                    if audio_idx is not None:
                        if plan_switches(current_state, audio_idx=audio_idx)["audio"]:
                            r = _rpc("Player.SetAudioStream", {"playerid": player_id, "stream": audio_idx})
                            _log_event("LOC_SET_AUDIO_OK" if r else "LOC_SET_AUDIO_ERR", {"idx": audio_idx})
                            dub_playing = bool(r)
                        else:
                            dub_playing = True
                            _log_event("LOC_SET_AUDIO_SKIP", {"idx": audio_idx, "why": "already_selected"})
                    if dub_playing:
                        playing_audio_lang = "cs"
                        # CZ → titulky vypnout (vynucené v jazyce HRAJÍCÍHO zvuku = čeština, pokud chceme a existují;
                        # 4.0.1: dřív první vynucená stopa bez ohledu na jazyk, Sony 09.10.2026 → anglické „Forced“)
                        if keep_forced and subs:
                            forced_idx = _find_forced_sub(subs, playing_audio_lang, current_state)
                            if forced_idx is not None:
                                want_sub_index = forced_idx
                                want_sub_enable = True
                            else:
                                want_sub_index = "off"
                                want_sub_enable = False
                        else:
                            want_sub_index = "off"
                            want_sub_enable = False
                    else:
                        # CZ není (nebo přepnutí na něj selhalo) → nech výchozí/„originální" audio, zapni titulky dle
                        # „Když CZ dabing není…"
                        chain = ["cs", "sk", "en"] if subs_if_no_dub == "cs" else ["en", "cs", "sk"]
                        si = _pick_sub_index(subs, subs_if_no_dub, fallback_chain=chain)
                        if si is not None:
                            want_sub_index = si
                            want_sub_enable = True
                else:
                    # Původní znění: origin_language → EN → první
                    if audio_idx is not None:
                        if plan_switches(current_state, audio_idx=audio_idx)["audio"]:
                            r = _rpc("Player.SetAudioStream", {"playerid": player_id, "stream": audio_idx})
                            _log_event("LOC_SET_AUDIO_OK" if r else "LOC_SET_AUDIO_ERR", {"idx": audio_idx, "orig_lang": orig_lang})
                        else:
                            _log_event("LOC_SET_AUDIO_SKIP", {"idx": audio_idx, "orig_lang": orig_lang, "why": "already_selected"})
                    chain = ["cs", "sk", "en"] if subs_for_orig == "cs" else ["en", "cs", "sk"]
                    si = _pick_sub_index(subs, subs_for_orig, fallback_chain=chain)
                    if si is not None:
                        want_sub_index = si
                        want_sub_enable = True

            _log_event("LOC_PICK", {
                "audio_pref": audio_pref,
                "subs_if_no_dub": subs_if_no_dub,
                "subs_for_orig": subs_for_orig,
                "keep_forced": keep_forced,
                "audio_idx": audio_idx,
                "sub_idx": want_sub_index,
                "enable": want_sub_enable
            })

            # 7) Aplikace titulků (zapnout/vypnout) + fallback podle názvu
            if want_sub_index is None:
                _log_event("LOC_SET_SUBS_SKIP", "no_change")
            elif not plan_switches(current_state, sub_idx=want_sub_index)["subs"]:
                _log_event("LOC_SET_SUBS_SKIP", {"idx": want_sub_index, "why": "already_selected"})
            elif want_sub_index == "off":
                r = _rpc("Player.SetSubtitle", {"playerid": player_id, "subtitle": "off", "enable": False})
                _log_event("LOC_SET_SUBS_OFF_OK" if r else "LOC_SET_SUBS_OFF_ERR", r)
            else:
                r = _rpc("Player.SetSubtitle", {"playerid": player_id, "subtitle": want_sub_index, "enable": True})
                if not r:
                    # Fallback: zkus jméno stopy (některé buildy neumí index)
                    name = None
                    for st in subs or []:
                        try:
                            idx = int(st.get("index"))
                        except Exception:
                            idx = st.get("index")
                        if idx == want_sub_index:
                            name = st.get("name") or st.get("language")
                            break
                    if name:
                        r = _rpc("Player.SetSubtitle", {"playerid": player_id, "subtitle": str(name), "enable": True})
                _log_event("LOC_SET_SUBS_OK" if r else "LOC_SET_SUBS_ERR", r)

            # 8) Finální re‑čtení a shrnutí
            fin = _rpc("Player.GetProperties", {
                "playerid": player_id,
                "properties": ["currentaudiostream", "currentsubtitle", "subtitleenabled"]
            }) or {}
            _log_event("LOC_DECISION", {
                "prefs": {
                    "audio": audio_pref,
                    "subs_if_no_dub": subs_if_no_dub, "subs_for_orig": subs_for_orig,
                    "forced": keep_forced, "title_pref_used": _used_title_pref
                },
                "final": fin
            })

            # 9) Uložení applied state do Window(10000) – pro detekci manuálních změn
            try:
                win = xbmcgui.Window(10000)
                applied_state = {
                    "audio_lang": _norm_lang(
                        (fin.get("currentaudiostream") or {}).get("language") or ""
                    ),
                    "sub_lang": _norm_lang(
                        (fin.get("currentsubtitle") or {}).get("language") or ""
                    ),
                    "sub_enabled": bool(fin.get("subtitleenabled")),
                }
                win.setProperty("richmovie.loc.applied_state",
                                json.dumps(applied_state, ensure_ascii=False))
                if title_key:
                    win.setProperty("richmovie.loc.title_key", title_key)
                else:
                    win.clearProperty("richmovie.loc.title_key")
                win.setProperty("richmovie.loc.init_done", "1")
                win.setProperty("richmovie.loc.init_done_ts", str(time.time()))
                _log_event("LOC_INIT_STATE_STORED", applied_state)
            except Exception:
                pass

        except Exception as e:
            _log_event("LOC_ERROR", str(e))

    threading.Thread(target=_worker, name="RichMovie-Loc", daemon=True).start()




# ═══════════════════════════════════════════════════════════════════════════════
#  ALIASY PRO ZPĚTNOU KOMPATIBILITU
# ═══════════════════════════════════════════════════════════════════════════════
# Tyto aliasy umožňují použít funkce s původními názvy z plugin.py


# =============================================================================
#  3.5.155 — PREFERENCE PER PROFIL + PRIMING STOP PŘED OTEVŘENÍM (Chromecast 26.09.2026)
# =============================================================================
# Incident: přepnutí zvukové/titulkové stopy ZA BĚHU = flush HW dekodéru; amlogic
# (Chromecast, MediaCodec) po flushi přestane vydávat snímky (`OutputPicture - timeout
# waiting for buffer`, `ReleaseOutputBuffer error`) → obraz stojí, zvuk běží. Do 3.5.154
# se přepínalo VŽDY (i když už výchozí stopa seděla) a preference byla per ZAŘÍZENÍ, takže
# Petra pod profilem Sněhurka dostala Richieho „původní znění“ → EN → přepnula → zamrznutí.
#
# Řešení (plán PLAN_kodi_log_archive_stream_switch_freeze_20260926 §B):
#   1. preference = PROFIL > titul > zařízení (`effective_prefs`; profil = `title_prefs`
#      klíč `_global`, synchronizovaný přes profile_items jako každá jiná title pref);
#   2. PŘED `setResolvedUrl` se Kodi řekne, jakou stopu má vybrat už při otevření
#      (`prime_initial_streams`: `locale.audiolanguage` / `locale.subtitlelanguage` přes
#      JSON-RPC, předchozí hodnoty uložené do Window prop a vrácené po konci přehrávání
#      službou — All-or-Nothing, uživatelské nastavení Kodi se trvale nemění);
#   3. worker po startu přepíná JEN když aktuální stopa NESEDÍ (`plan_switches`).

PROFILE_PREF_KEY = "_global"          # title_prefs.json: preference profilu (ne titulu)
PROFILE_AUDIO_ORIGINAL = "orig"       # audio_lang hodnota = „původní znění“ (jinak kód jazyka, typicky "cs")
_PRIME_PROP = "richmovie.loc.primed"  # Window(10000): {"prev": {...}, "set": {...}, "ts": ...}
PRIME_SETTING_AUDIO = "locale.audiolanguage"
PRIME_SETTING_SUBS = "locale.subtitlelanguage"

_LANG_NAMES = {"cs": "Czech", "en": "English", "sk": "Slovak", "de": "German", "fr": "French",
               "es": "Spanish", "it": "Italian", "pl": "Polish", "ru": "Russian", "ja": "Japanese",
               "ko": "Korean", "zh": "Chinese", "pt": "Portuguese", "hu": "Hungarian", "da": "Danish",
               "sv": "Swedish", "no": "Norwegian", "fi": "Finnish", "nl": "Dutch", "tr": "Turkish"}


def device_prefs() -> dict:
    """Preference ZAŘÍZENÍ z nastavení addonu (fallback pro Host / účet bez profilu)."""
    def _audio() -> str:
        try:
            v = (richmovie_settings.get_str("loc_audio_pref") or "").strip().lower()
        except Exception:
            v = ""
        if v in {"1", "český dabing", "cesky dabing", "cz_dub"}:
            return "cz_dub"
        return "original"

    def _sub(id_: str, default_code: str) -> str:
        try:
            v = (richmovie_settings.get_str(id_) or "").strip().lower()
        except Exception:
            v = ""
        if v in {"0", "české", "ceske", "cs"}:
            return "cs"
        if v in {"1", "anglické", "anglicke", "en"}:
            return "en"
        return default_code

    def _forced() -> bool:
        try:
            return bool(richmovie_settings.get_bool("loc_respect_forced"))
        except Exception:
            return True

    return {"audio_pref": _audio(), "subs_if_no_dub": _sub("loc_subs_if_no_dub", "cs"),
            "subs_for_orig": _sub("loc_subs_for_original", "cs"), "keep_forced": _forced(),
            "source": "device"}


def profile_pref_record() -> dict | None:
    """Záznam `_global` z title_prefs aktivního profilu (None = profil nemá vlastní volbu)."""
    try:
        import richmovie_title_prefs as _tp
        rec = _tp.get_pref(PROFILE_PREF_KEY)
        return rec if isinstance(rec, dict) and rec.get("audio_lang") else None
    except Exception:
        return None


def prefs_from_record(rec: dict | None, fallback: dict) -> dict:
    """Čistá: záznam profilu (`audio_lang` = "cs" | "orig", `sub_lang` = "cs" | "en") → prefs."""
    if not rec:
        return dict(fallback)
    audio = str(rec.get("audio_lang") or "").strip().lower()
    sub = str(rec.get("sub_lang") or "").strip().lower()
    sub = sub if sub in ("cs", "en") else fallback.get("subs_for_orig", "cs")
    out = dict(fallback)
    out.update({"audio_pref": "cz_dub" if audio == "cs" else "original",
                "subs_if_no_dub": sub, "subs_for_orig": sub, "source": "profile"})
    return out


def effective_prefs() -> dict:
    """SSOT čtení preference: PROFIL (title_prefs `_global`) > ZAŘÍZENÍ (nastavení)."""
    return prefs_from_record(profile_pref_record(), device_prefs())


def set_profile_prefs(audio_pref: str, sub_lang: str) -> None:
    """Uloží preferenci aktivního profilu (manuální = nejvyšší priorita, synchronizuje se)."""
    import richmovie_title_prefs as _tp
    _tp.set_pref(PROFILE_PREF_KEY, "cs" if audio_pref == "cz_dub" else PROFILE_AUDIO_ORIGINAL,
                 sub_lang, True)


def ask_profile_prefs(*, force: bool = False) -> bool:
    """Dialog „Zvuk pro tento profil“ — 1× po výběru profilu bez vlastní volby (nebo z nastavení).
    Vrací True, když se něco uložilo. Nikdy nevyhazuje; Host/účet bez profilu se neptá."""
    try:
        import richmovie_profile as _prof
        if not _prof.is_multi() or _prof.is_guest() or not _prof.has_active_profile():
            return False
        if not force and profile_pref_record():
            return False
        win = xbmcgui.Window(10000)
        marker = "richmovie.loc.profile_asked.%s" % (_prof.current_id() or "")
        if not force and win.getProperty(marker) == "1":
            return False
        win.setProperty(marker, "1")
        name = str((_prof.current() or {}).get("name") or "")
        idx = xbmcgui.Dialog().select("%s — preferuješ původní znění, nebo český dabing?" % (name or "Profil"),
                                      ["Původní znění (originál)", "Český dabing"])
        if idx < 0:
            return False
        idx2 = xbmcgui.Dialog().select("Titulky: české, nebo anglické?", ["České", "Anglické"])
        sub = "en" if idx2 == 1 else "cs"
        set_profile_prefs("original" if idx == 0 else "cz_dub", sub)
        _log_event("LOC_PROFILE_PREF_SET", {"profile": _prof.current_id(), "audio": idx, "sub": sub})
        return True
    except Exception as exc:
        _log_event("LOC_PROFILE_PREF_ERR", str(exc))
        return False


def lang_name(code: str | None) -> str | None:
    """Kód jazyka → název, jak ho Kodi čeká v `locale.audiolanguage` („Czech“)."""
    c = _norm_lang(code or "")
    if not c:
        return None
    try:
        name = xbmc.convertLanguage(c, xbmc.ENGLISH_NAME)
        if name:
            return str(name)
    except Exception:
        pass
    return _LANG_NAMES.get(c)


def desired_kodi_settings(prefs: dict, orig_lang: str | None, title_pref: dict | None = None) -> dict:
    """Čistá: co má Kodi vybrat už při otevření souboru.

    Vrací {"locale.audiolanguage": <název|"original">, "locale.subtitlelanguage": <název|"none"|"forced_only">}.
    Titul (manuální volba per titul) má přednost před profilem/zařízením.
    """
    if title_pref and title_pref.get("audio_lang"):
        audio = lang_name(title_pref.get("audio_lang")) or "original"
        if title_pref.get("sub_enabled") and title_pref.get("sub_lang"):
            subs = lang_name(title_pref.get("sub_lang")) or "none"
        else:
            subs = "forced_only" if prefs.get("keep_forced", True) else "none"
        return {PRIME_SETTING_AUDIO: audio, PRIME_SETTING_SUBS: subs}
    if prefs.get("audio_pref") == "cz_dub":
        # Kodi: „Czech“ = vybrat českou stopu, když je; jinak výchozí stopu souboru (pak
        # rozhoduje worker — přepne titulky podle „Když CZ dabing není…“).
        return {PRIME_SETTING_AUDIO: lang_name("cs") or "Czech",
                PRIME_SETTING_SUBS: "forced_only" if prefs.get("keep_forced", True) else "none"}
    audio = lang_name(orig_lang) or "original"
    subs = lang_name(prefs.get("subs_for_orig") or "cs") or "Czech"
    return {PRIME_SETTING_AUDIO: audio, PRIME_SETTING_SUBS: subs}


def _peek_tmdb_original_language(m_tmdb: int | None, tv_id: int | None) -> str | None:
    """`original_language` JEN z diskové cache TMDb (0 HTTP). None = není v cache."""
    try:
        from richmovie_settings import get_tmdb_api_key
        tmdb = TMDb(get_tmdb_api_key() or "", lang="cs-CZ")
        det = tmdb.peek_tv_details(int(tv_id)) if tv_id else (tmdb.peek_details(int(m_tmdb)) if m_tmdb else None)
        lang = ((det or {}).get("original_language") or "").strip().lower()
        return lang or None
    except Exception:
        return None


def _rpc_get_setting(setting_id: str):
    res = _jsonrpc("Settings.GetSettingValue", {"setting": setting_id})
    return res.get("value") if isinstance(res, dict) else None


def _rpc_set_setting(setting_id: str, value) -> bool:
    """True JEN když Kodi vrátilo `result: true`; `_jsonrpc` při chybě vrací {} (cross-check 26.09.2026:
    původní tvar bral prázdný dict jako úspěch, takže selhaná změna vypadala jako provedená)."""
    res = _jsonrpc("Settings.SetSettingValue", {"setting": setting_id, "value": value})
    return res is True


def _read_primed() -> dict | None:
    try:
        raw = xbmcgui.Window(10000).getProperty(_PRIME_PROP)
        data = json.loads(raw) if raw else None
        return data if isinstance(data, dict) and isinstance(data.get("prev"), dict) else None
    except Exception:
        return None


def prime_initial_streams(*, m_tmdb: int | None = None, tv_id: int | None = None,
                          m_title: str | None = None, m_year: int | None = None) -> dict:
    """PŘED `setResolvedUrl`: nastaví Kodi jazyk zvuku/titulků pro otevření souboru.

    Předchozí hodnoty se uloží do Window prop (pokud už tam z minula nejsou = osiřelý priming,
    zachová se PŮVODNÍ `prev`, nikdy naše vlastní hodnota) a služba je po konci přehrávání
    vrátí (`restore_primed_settings`). Vrací {"changed": bool, "set": {...}} pro log.
    """
    out = {"changed": False, "set": {}}
    try:
        import richmovie_title_prefs as _tp
        prefs = effective_prefs()
        title_key = _tp.make_title_key(m_tmdb=m_tmdb, tv_id=tv_id, m_title=m_title, m_year=m_year)
        title_pref = _tp.get_pref(title_key) if title_key else None
        orig_lang = None
        if prefs.get("audio_pref") != "cz_dub" and not (title_pref and title_pref.get("audio_lang")):
            # JEN z diskové cache TMDb (`peek_*`): priming leží před `setResolvedUrl`, HTTP by
            # zdržel start přehrávání; detail titulu je z výpisu streamů v cache prakticky vždy.
            # Bez cache → "original" (Kodi vybere stopu s příznakem original / výchozí), worker
            # to po startu dorovná jediným přepnutím jen když stopa nesedí (Fable audit 26.09.2026).
            orig_lang = _peek_tmdb_original_language(m_tmdb, tv_id)
        want = desired_kodi_settings(prefs, orig_lang, title_pref)
        current = {k: _rpc_get_setting(k) for k in want}
        primed = _read_primed() or {}
        prev = dict(primed.get("prev") or {})
        for k, v in current.items():
            if k not in prev:
                prev[k] = v
        # Záloha PŘED první změnou (cross-check Pro B 5 / Flash 2, 26.09.2026): pád mezi
        # SetSettingValue a zápisem prop by jinak nechal uživateli změněné nastavení bez cesty zpět.
        xbmcgui.Window(10000).setProperty(_PRIME_PROP, json.dumps(
            {"prev": prev, "set": want, "ts": time.time()}, ensure_ascii=False))
        changed = {}
        for k, v in want.items():
            if current.get(k) != v:
                if _rpc_set_setting(k, v):
                    changed[k] = v
        out.update({"changed": bool(changed), "set": want, "prev": prev, "source": prefs.get("source")})
        _log_event("LOC_PRIME", {"want": want, "changed": changed, "source": prefs.get("source"),
                                 "title_pref": bool(title_pref), "orig_lang": orig_lang})
    except Exception as exc:
        _log_event("LOC_PRIME_ERR", str(exc))
    return out


def restore_primed_settings(*, reason: str = "") -> bool:
    """Po konci přehrávání (služba) / při startu služby: vrátí Kodi nastavení, která priming změnil.
    Idempotentní — bez prop nic. Vrací True, když se něco vracelo."""
    primed = _read_primed()
    if not primed:
        return False
    restored = {}
    failed = {}
    for k, v in (primed.get("prev") or {}).items():
        if v is None:
            continue
        cur = _rpc_get_setting(k)
        if cur == v:
            continue
        if _rpc_set_setting(k, v):
            restored[k] = v
        else:
            failed[k] = v
    if failed:
        # All-or-Nothing: prop zůstává, aby další pokus (konec dalšího přehrávání, start služby)
        # obnovu dokončil — smazat ji by znamenalo trvale změněné nastavení (cross-check Flash 2).
        _log_event("LOC_PRIME_RESTORE_PARTIAL", {"restored": restored, "failed": failed, "reason": reason})
        return False
    try:
        xbmcgui.Window(10000).clearProperty(_PRIME_PROP)
    except Exception:
        pass
    _log_event("LOC_PRIME_RESTORED", {"restored": restored, "reason": reason})
    return True


def plan_switches(current: dict, *, audio_idx=None, sub_idx=None) -> dict:
    """Čistá: co se má opravdu přepnout. `current` = Player.GetProperties
    (currentaudiostream, currentsubtitle, subtitleenabled). Přepnutí = flush dekodéru,
    takže se dělá JEN když stopa nesedí (Chromecast 26.09.2026). Zapnutí titulků nese `sub_idx` samo
    (`"off"` = vypnout, index = zapnout tuto stopu) — S13 (10.10.2026): zrušen nepoužitý parametr `sub_enable`."""
    out = {"audio": False, "subs": False}
    if audio_idx is not None:
        try:
            cur_a = int((current.get("currentaudiostream") or {}).get("index"))
        except Exception:
            cur_a = None
        out["audio"] = cur_a != int(audio_idx)
    if sub_idx is not None:
        cur_on = bool(current.get("subtitleenabled"))
        if sub_idx == "off":
            out["subs"] = cur_on
        else:
            try:
                cur_s = int((current.get("currentsubtitle") or {}).get("index"))
            except Exception:
                cur_s = None
            out["subs"] = (not cur_on) or cur_s != int(sub_idx)
    return out

_loc__onboard_version = _onboard_version
_ensure_localization_onboarding = ensure_localization_onboarding
_loc__jsonrpc = _jsonrpc
_rm_normalize_lang_list = rm_normalize_lang_list
_rm_build_label_dubbing_subs = rm_build_label_dubbing_subs
_rm_apply_av_streams_to_listitem = rm_apply_av_streams_to_listitem
_loc__norm_lang = _norm_lang
_loc__pick_audio_index = _pick_audio_index
_loc__find_forced_sub = _find_forced_sub
_loc__pick_sub_index = _pick_sub_index
_loc__get_tmdb_original_language = _get_tmdb_original_language
_apply_stream_localization_async = apply_stream_localization_async
