# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_rating_ui — dialog „Jak se ti líbil?" (1–5★), 3.5.152 (plán Petra Φ3)
───────────────────────────────────────────────────────────────────────────────
Jediné místo, kde se hodnocení sbírá od diváka: po dokoukání filmu (služba,
`service_nextup._maybe_ask_rating`) a z kontextového menu („Ohodnotit ★" — doporučení,
historie sledování; plugin `rate_title`). Data drží SSOT `richmovie_ratings`.

Okno = vlastní `RichMovieRating.xml` (plakát, název, pět hvězd, „Teď ne"), autoclose po
`richmovie_ratings.ASK_TIMEOUT_S` (vlákno + `Monitor.waitForAbort`); když skin/XML chybí,
fallback `Dialog().select` se stejnou sémantikou. Python 3.8 (Kodi).
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, Optional

import xbmc
import xbmcaddon
import xbmcgui

import richmovie_ratings as _rt
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)
import richmovie_playback_dispatch as _rm_dispatch  # 4.0.1: Container.Refresh jen přes bránu (pád Kodi 09.10.2026)

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.rating_ui", "RichMovie/RatingUI")
except Exception:  # pragma: no cover
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        xbmc.log("[RichMovie/RatingUI] %s" % msg, level)

_XML = "RichMovieRating.xml"
_RES = "1080i"
_BTN_STARS = {9401: 1, 9402: 2, 9403: 3, 9404: 4, 9405: 5}
_BTN_SKIP = 9410
RESULT_SKIPPED = 0      # „Teď ne" / Back
RESULT_TIMEOUT = -1     # zavřeno po čase (počítá se jako „Teď ne", D4)


class RichMovieRatingWindow(xbmcgui.WindowXMLDialog):
    """Výsledek `rating`: 1–5, RESULT_SKIPPED nebo RESULT_TIMEOUT."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rating = RESULT_SKIPPED
        self.texts: Dict[str, str] = {}
        self._closed = threading.Event()

    def onInit(self) -> None:
        for key, value in self.texts.items():
            self.setProperty(key, value)

    def onFocus(self, control_id: int) -> None:
        n = _BTN_STARS.get(control_id)
        self.setProperty("rm_rt_hint", "%s  %s" % (_rt.stars(n), _rt.LABELS.get(n, "")) if n else "")

    def onClick(self, control_id: int) -> None:
        if control_id in _BTN_STARS:
            self.rating = _BTN_STARS[control_id]
            self._finish()
        elif control_id == _BTN_SKIP:
            self.rating = RESULT_SKIPPED
            self._finish()

    def onAction(self, action) -> None:
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.rating = RESULT_SKIPPED
            self._finish()

    def _finish(self) -> None:
        self._closed.set()
        self.close()

    def timeout_close(self) -> None:
        if not self._closed.is_set():
            self.rating = RESULT_TIMEOUT
            self._finish()


def _texts(title: str, *, kicker: str, poster: str, fanart: str) -> Dict[str, str]:
    return {
        "rm_rt_title": title or "Tenhle film",
        "rm_rt_kicker": kicker,
        "rm_rt_question": "Jak se ti líbil?",
        "rm_rt_hint": "",
        "rm_rt_skip": "Teď ne",
        "rm_rt_footer": "Hodnocení zlepší doporučení pro tento profil. Stačí dvakrát odložit a už se neptám.",
        "rm_rt_poster": poster or "",
        "rm_rt_fanart": fanart or "",
    }


def ask(title: str, *, kicker: str = "Právě dokoukáno", poster: str = "", fanart: str = "",
        timeout_s: float = _rt.ASK_TIMEOUT_S) -> int:
    """Zobrazí dialog (modálně, volat z vlákna mimo callbacky Kodi). Vrací 1–5 / 0 / −1."""
    try:
        win = RichMovieRatingWindow(_XML, xbmcaddon.Addon().getAddonInfo("path"), "default", _RES)
    except Exception as exc:
        _log("rating window failed (%r) → fallback select" % (exc,), xbmc.LOGWARNING)
        return _ask_fallback(title)
    win.texts = _texts(title, kicker=kicker, poster=poster, fanart=fanart)
    closed = threading.Event()
    if timeout_s and timeout_s > 0:
        def _timer() -> None:
            # Φ5A (29.09.2026): časovač končí se zavřením dialogu. Dřív po `del win` sáhl na smazanou
            # proměnnou (pyflakes „undefined name“) a vlákno spadlo s NameError, kdykoli uživatel
            # ohodnotil dřív než za `timeout_s`.
            mon = xbmc.Monitor()
            deadline = time.monotonic() + float(timeout_s)
            while not closed.is_set():
                if mon.waitForAbort(0.5) or time.monotonic() >= deadline:
                    if not closed.is_set():
                        win.timeout_close()   # i při abortu Kodi (Fable P2-3): modál nesmí držet do force-kill
                    return
        threading.Thread(target=_timer, name="RMRatingTimeout", daemon=True).start()
    try:
        win.doModal()
    finally:
        closed.set()
    return int(win.rating)


def _ask_fallback(title: str) -> int:
    options = ["%s  %s" % (_rt.stars(n), _rt.LABELS[n]) for n in (5, 4, 3, 2, 1)] + ["Teď ne"]
    choice = xbmcgui.Dialog().select("Jak se ti líbil %s?" % (title or "film"), options)
    if 0 <= choice < 5:
        return (5, 4, 3, 2, 1)[choice]
    return RESULT_SKIPPED


def collect(kind: str, tmdb_id: int, title: str, *, kicker: str = "Právě dokoukáno",
            poster: str = "", fanart: str = "", timeout_s: float = _rt.ASK_TIMEOUT_S) -> Optional[int]:
    """Dialog + zápis přes SSOT `richmovie_ratings`. Vrací uložené hodnocení, nebo None
    (odloženo/timeout → počítadlo `note_skipped`, D4)."""
    result = ask(title, kicker=kicker, poster=poster, fanart=fanart, timeout_s=timeout_s)
    if result >= 1:
        if _rt.set_rating(kind, tmdb_id, result, title=title):
            try:
                _rm_notif(
                    "%s  %s" % (_rt.stars(result), title or ""),
                    xbmcgui.NOTIFICATION_INFO,
                    3000,
                    "RichMovie",
                    sound=False,
                )
            except Exception:
                pass
            return result
        _log("rating not saved kind=%s tmdb=%s" % (kind, tmdb_id), xbmc.LOGWARNING)
        return None
    if xbmc.Monitor().abortRequested():
        return None   # Kodi končí — zavření dialogu není „Teď ne"
    n = _rt.note_skipped(kind, tmdb_id)
    _log("RATING_SKIPPED kind=%s tmdb=%s why=%s n=%d" % (
        kind, tmdb_id, "timeout" if result == RESULT_TIMEOUT else "later", n), xbmc.LOGINFO,
        context={"kind": kind, "tmdb_id": tmdb_id, "skipped": n})
    return None


def rate_from_menu(*, kind: str, tmdb_id: int, title: str = "") -> None:
    """Kontextové menu „Ohodnotit ★" (plugin `rate_title`): bez timeoutu, Host = hláška."""
    try:
        import richmovie_profile as _rp
        if _rp.is_guest():
            _rm_notif(
                "Host profil hodnocení neukládá — vyber svůj profil",
                xbmcgui.NOTIFICATION_INFO,
                4000,
                "RichMovie",
            )
            return
    except Exception:
        pass
    if not tmdb_id:
        return
    existing = _rt.get(kind, tmdb_id)
    kicker = "Tvoje hodnocení: %s" % _rt.stars(existing["rating"]) if existing else "Ohodnotit"
    poster, fanart = _artwork(kind, tmdb_id)
    if collect(kind, tmdb_id, title, kicker=kicker, poster=poster, fanart=fanart, timeout_s=0) is not None:
        _rm_dispatch.refresh_container("rate_from_menu")


def _artwork(kind: str, tmdb_id: int) -> "tuple[str, str]":
    """Plakát + fanart z diskové cache TMDb (`peek_*` = bez requestu — dialog musí být okamžitý)."""
    try:
        import richmovie_settings as _rs
        from tmdb_client import TMDb as _TMDb
        key = _rs.get_tmdb_api_key()
        if not key:
            return "", ""
        client = _TMDb(key, lang="cs-CZ")
        det = client.peek_tv_details(int(tmdb_id)) if kind == "tv" else client.peek_details(int(tmdb_id))
        if isinstance(det, dict):
            poster = det.get("poster_path") or ""
            fanart = det.get("backdrop_path") or ""
            return (("https://image.tmdb.org/t/p/w342" + poster) if poster else "",
                    ("https://image.tmdb.org/t/p/w1280" + fanart) if fanart else "")
    except Exception:
        pass
    return "", ""
