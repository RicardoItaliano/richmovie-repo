# -*- coding: utf-8 -*-
"""Klient Televize — Gate `/v1/livetv/*` (08.11.2026, plán Televizní kanály F3, kontrakt A4 §6.1).

JEDINÉ místo doplňku, které mluví s televizní částí Gate a datovou rovinou relay na NASu:

- identita jen v hlavičce (`Authorization: RM-Proof …` + `X-Device-Hash`) — nové API nemá staré klienty, proof do URL
  ani těla nepatří; zamítnutí identity hlásí `richmovie_identity_state.observe_gate_response` (jediný hook),
  `feature_not_allowed` identitu NEMĚNÍ (zařízení jen nemá Televizi zapnutou);
- odpověď Gate → `LiveError` s KÓDEM a českou větou (`MESSAGES` = SSOT textů); plno (`409 slots_full`) nese nabídku
  běžících kanálů skupiny; nic z toho není výpadek sítě (netstate se nemění);
- výběr cesty k NASu (`pick_url`): Gate vrací báze datové roviny v pořadí, doplněk vezme první, jejíž `/tv/health`
  odpoví (krátký rozpočet, selhání se NEhlásí netstate — nedosažitelný NAS mimo domov neříká nic o lince ke Gate);
- bajty živého streamu stahuje přehrávač Kodi přímo z relay (vědomá výjimka sítě jako CDN Webshare, plán F3);
  obrázky kanálů jdou TAKÉ přes relay (`/tv/img/…`) — žádný požadavek zařízení nemíří k poskytovateli (Richie:
  „všechno z NASu“).

Bez Kodi importů na úrovni modulu (harness `_tools/net_resilience_sim` scénáře 100, 102, 103).
"""

from __future__ import annotations

import json
import uuid

import richmovie_http as _rm_http
import richmovie_media_kind as _kind

LOG_TAG = "livetv"

#: vlastnosti živé položky (jediné místo literálů; druh média nese `richmovie_media_kind.PROP`)
PROP_CHANNEL = "richmovie.live_channel"
PROP_CHANNEL_NAME = "richmovie.live_channel_name"
#: identita relace (`client_session_id` tiketu) — konec přehrávání ukončí na NASu jen TUHLE relaci, ne novější kanál
#: téhož zařízení (Stop a hned jiný kanál = závod, F3 zpráva služby bod 1)
PROP_SESSION = "richmovie.live_session"

HEALTH_TIMEOUT_S = 1.5      # sonda cesty k NASu: v LAN odpovídá do desítek ms, mimo dosah nesmí zdržet start
# Rezerva přehrávače za živým okrajem (inputstream.adaptive `live_delay`, Kodi 21 ISA 21.5.x). Bez ní ISA startoval ~4 s od
# konce okna při úsecích 10 s → každých ~10 s `SetSpeedAdjust -0.05` + `CVideoPlayerAudio::Process - stream stalled` = výpadek
# zvuku 0,3–0,5 s (ladicí log Richieho PC 08.11.2026 07:30–07:32, HBO / war). 30 s = 3 úseky po 10 s (5 po 6 s).
LIVE_DELAY_S = 30
API_TIMEOUT_S = 8.0
END_TIMEOUT_S = 3.0

# kód → (česká věta, trvalá?) — trvalá = dialog a žádné „zkus znovu“, přechodná = toast (richmovie_feedback)
MESSAGES = {
    "feature_not_allowed": ("Televize na tomhle zařízení není zapnutá.", True),
    "channel_unavailable": ("Tenhle kanál není ve tvém balíčku.", True),
    "slots_full": ("Na téhle skupině kanálů se teď dívá už moc zařízení.", True),
    "livetv_not_ready": ("Televize se na NASu teprve zapíná. Zkus to za chvilku.", False),
    "livetv_busy": ("NAS teď šetří paměť. Zkus to za chvilku.", False),
    "livetv_unavailable": ("Televize na NASu teď neodpovídá. Zkus to za chvilku.", False),
    "livetv_error": ("Tenhle kanál teď nejde spustit. Zkus jiný, nebo za chvilku.", False),
    "rate_limited": ("Přepínáš moc rychle — chvilku počkej.", False),
    "nas_unreachable": ("Televize zatím jde jen doma a v kanceláři — odsud NAS není vidět.", True),
    "identity_rejected": ("RichMovie tě teď nepoznal. Otevři Nastavení a zkontroluj přihlášení k Webshare.", True),
    "no_identity": ("Nejdřív se přihlas k Webshare v Nastavení RichMovie.", True),
    "bad_response": ("Televize odpověděla nesrozumitelně. Zkus to za chvilku.", False),
    "transport": ("Nepodařilo se spojit s RichMovie. Zkontroluj připojení k internetu.", False),
}


class LiveError(Exception):
    """Selhání Televize s kódem z `MESSAGES`. `offer` = nabídka při `slots_full` (Gate `_offer`)."""

    def __init__(self, code: str, *, status: int | None = None, offer: dict | None = None, detail: str = "") -> None:
        super().__init__(code)
        self.code = code if code in MESSAGES else "livetv_error"
        self.status = status
        self.offer = offer if isinstance(offer, dict) else None
        self.detail = detail

    @property
    def message(self) -> str:
        return MESSAGES[self.code][0]

    @property
    def permanent(self) -> bool:
        return MESSAGES[self.code][1]


# ── transport (injektovatelný pro harness) ────────────────────────────────────────────────────────────────────

def _identity():
    import richmovie_gate_transport as _gt
    username, proof = _gt.get_identity()
    return username, proof, _gt.get_device_hash() or ""


def _headers(username: str, proof: str, device_hash: str, with_body: bool) -> dict:
    import richmovie_gate_transport as _gt
    headers = _gt.gate_headers(content_type="application/json" if with_body else None)
    headers.update(_gt.auth_header(username, proof))
    headers["X-Device-Hash"] = device_hash
    return headers


def _gate_url() -> str:
    import richmovie_gate_transport as _gt
    return _gt.GATE_URL


def _observe(status: int | None, body, identity_sent: bool) -> None:
    import richmovie_identity_state as _ids
    _ids.observe_gate_response(status, body, identity_sent)


def _identity_allowed() -> bool:
    import richmovie_identity_state as _ids
    return bool(_ids.allow_gate_request())


def _profile(timeout: float, background: bool):
    base = _rm_http.profile_background() if background else _rm_http.profile_foreground()
    return base.replace(timeout_s=float(timeout))


def call(method: str, path: str, body: dict | None = None, *, timeout: float = API_TIMEOUT_S,
         background: bool = False, idempotent: bool = True, request=None) -> dict:
    """Jedno volání `/v1/livetv/*` → dekódované JSON tělo (200), jinak `LiveError`. Všechna volání Televize jsou
    opakovatelná: čtení, `session` s `client_session_id` (relay vrátí týž tiket — klíč zařízení × relace × kanál)
    a `session/end` (ukončit dvakrát nic nezdvojí) → `idempotent=True`; 429 se neopakuje nikdy (`richmovie_http`)."""
    if not _identity_allowed():
        raise LiveError("identity_rejected")
    username, proof, device_hash = _identity()
    if not username or not proof:
        raise LiveError("no_identity")
    data = json.dumps(body).encode("utf-8") if body is not None else None
    send = request or _rm_http.request
    try:
        status, raw, _hdrs = send(_gate_url() + path, method=method, headers=_headers(username, proof, device_hash,
                                                                                      data is not None),
                                  data=data, profile=_profile(timeout, background), idempotent=idempotent,
                                  tag=LOG_TAG)
    except _rm_http.CancelledError:
        raise
    except Exception as exc:   # transport (TransientError, PermanentError) — technický text jen do logu
        raise LiveError("transport", detail=repr(exc)) from None
    try:
        payload = json.loads((raw or b"{}").decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        payload = None
    _observe(int(status), payload, True)
    if int(status) == 200 and isinstance(payload, dict):
        return payload
    err = payload.get("error") if isinstance(payload, dict) else None
    code = err.get("code") if isinstance(err, dict) else None
    if int(status) in (401, 403) and code not in (None, "feature_not_allowed"):
        raise LiveError("identity_rejected", status=int(status))
    if int(status) == 409 and code == "slots_full":
        raise LiveError("slots_full", status=409, offer=payload.get("offer") if isinstance(payload, dict) else None)
    if int(status) == 429:
        raise LiveError("rate_limited", status=429)
    if code in MESSAGES:
        raise LiveError(code, status=int(status))
    raise LiveError("bad_response" if int(status) == 200 else "livetv_error", status=int(status))


# ── API ───────────────────────────────────────────────────────────────────────────────────────────────────────

def channels(*, request=None) -> dict:
    """Kanály, které tohle zařízení smí (dostupné v balíčku, bez DRM) + báze datové roviny. `{"channels": [...],
    "bases": [...]}`; kanál nese `id`, `name`, `position`, `category`, `logo_path` (relay) a `audio`."""
    data = call("GET", "/v1/livetv/channels", request=request)
    chans = data.get("channels")
    if not isinstance(chans, list):
        raise LiveError("bad_response")
    return {"channels": [c for c in chans if isinstance(c, dict) and c.get("id") and c.get("available", True)],
            "bases": [b for b in (data.get("bases") or []) if isinstance(b, str)]}


def now_playing(*, request=None) -> dict:
    """`{kanál: {"current": {...} | None, "next": {...} | None}}` — co běží teď a co potom."""
    data = call("GET", "/v1/livetv/now", request=request)
    out = {}
    for row in data.get("channels") or []:
        if isinstance(row, dict) and row.get("id"):
            out[row["id"]] = {"current": row.get("current"), "next": row.get("next")}
    return out


def open_session(channel_id: str, *, isa: bool, client_session_id: str | None = None, request=None) -> dict:
    """Tiket pro přehrávač. `{"urls": [...], "expires_at": …}`; plno → `LiveError("slots_full", offer=…)`."""
    data = call("POST", "/v1/livetv/session", {"channel_id": channel_id, "isa": bool(isa),
                                               "client_session_id": client_session_id or str(uuid.uuid4())},
                request=request)
    urls = [u for u in (data.get("urls") or []) if isinstance(u, str) and u.startswith(("http://", "https://"))]
    if not urls:
        raise LiveError("bad_response")
    return {"urls": urls, "expires_at": data.get("expires_at")}


def end_session(reason: str = "player_stopped", *, client_session_id: str | None = None, request=None) -> bool:
    """Přehrávání živého kanálu skončilo → relay uvolní místo hned (jinak po nečinnosti). S `client_session_id`
    ukončí JEN relaci, kterou tenhle přehrávač otevřel (novější kanál téhož zařízení zůstane). Best effort: nikdy
    nehází, běží z vlákna služby s krátkým rozpočtem; výsledek jen pro log."""
    body = {"reason": str(reason)[:40]}
    if client_session_id:
        body["client_session_id"] = str(client_session_id)
    try:
        data = call("POST", "/v1/livetv/session/end", body, timeout=END_TIMEOUT_S, background=True, request=request)
        return bool(data.get("ended"))
    except _rm_http.CancelledError:
        return False
    except LiveError:
        return False


# ── cesta k NASu ──────────────────────────────────────────────────────────────────────────────────────────────

def base_of(url: str) -> str:
    """`http://192.168.1.179:8343/tv/t/…/master.m3u8` → `http://192.168.1.179:8343`."""
    i = url.find("/", url.find("//") + 2) if "//" in url else -1
    return url[:i] if i > 0 else url


def pick_url(urls: list, probe) -> str | None:
    """První URL, jejíž báze odpoví na sondu (`probe(base) -> bool`, injektovaná). Žádná = None (NAS mimo dosah).
    Pořadí určuje Gate (LAN před WAN) — doplněk ho nemění."""
    tried = {}
    for url in urls:
        base = base_of(url)
        if base not in tried:
            tried[base] = bool(probe(base))
        if tried[base]:
            return url
    return None


def health_probe(base: str, *, request=None) -> bool:
    """`GET <báze>/tv/health` s krátkým rozpočtem; selhání se NEhlásí netstate (`report_failures=False`)."""
    send = request or _rm_http.request
    prof = _rm_http.profile_foreground().replace(timeout_s=HEALTH_TIMEOUT_S, budget_s=HEALTH_TIMEOUT_S,
                                                 max_attempts=1)
    try:
        status, raw, _h = send(base + "/tv/health", method="GET", headers={"Accept": "application/json"},
                               profile=prof, tag=LOG_TAG, report_failures=False)
    except _rm_http.CancelledError:
        raise
    except Exception:
        return False
    if int(status) != 200:
        return False
    try:
        return bool(json.loads(raw.decode("utf-8")).get("data_plane"))
    except (ValueError, UnicodeDecodeError, AttributeError):
        return False


def image_url(bases: list, path: str | None, chosen_base: str | None = None) -> str:
    """Obrázek přes relay (`/tv/img/…`) na zvolené nebo první bázi; bez cesty prázdný řetězec (Kodi ukáže ikonu)."""
    if not path or not str(path).startswith("/tv/img/"):
        return ""
    base = chosen_base or (bases[0] if bases else "")
    return (base_of(base) + path) if base else ""


# ── texty (čisté) ─────────────────────────────────────────────────────────────────────────────────────────────

def _parse_iso(value):
    import datetime as _dt
    if not value:
        return None
    try:
        return _dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def progress(current: dict | None, now) -> float | None:
    """Podíl odvysílaného pořadu 0–1 (`now` = aware datetime), None bez času."""
    if not isinstance(current, dict):
        return None
    start, end = _parse_iso(current.get("start")), _parse_iso(current.get("end"))
    if start is None or end is None or end <= start:
        return None
    return max(0.0, min(1.0, (now - start).total_seconds() / (end - start).total_seconds()))


def remaining_text(current: dict | None, now) -> str:
    """„ještě 1 h 39 min“ / „ještě 12 min“ / „končí“ — zbývající čas pořadu."""
    end = _parse_iso(current.get("end")) if isinstance(current, dict) else None
    if end is None:
        return ""
    minutes = int((end - now).total_seconds() // 60)
    if minutes <= 0:
        return "končí"
    if minutes < 60:
        return "ještě %d min" % minutes
    return "ještě %d h %d min" % (minutes // 60, minutes % 60) if minutes % 60 else "ještě %d h" % (minutes // 60)


def clock_text(value) -> str:
    """ISO čas → „20:15“ v místním čase zařízení."""
    dt = _parse_iso(value)
    if dt is None:
        return ""
    return dt.astimezone().strftime("%H:%M")


def offer_lines(offer: dict | None) -> list:
    """Nabídka při plné skupině → [(kanál, jméno kanálu, „Prima COOL — Obývák, jiné zařízení“)] jen pro kanály,
    ke kterým se dá připojit (`join` — běžící kanál skupiny, nové místo nespotřebuje)."""
    if not isinstance(offer, dict):
        return []
    joinable = set(offer.get("join") or [])
    out = []
    for row in offer.get("occupied") or []:
        if not isinstance(row, dict) or row.get("channel") not in joinable:
            continue
        name = str(row.get("channel_name") or row["channel"])
        devices = ", ".join(str(d) for d in (row.get("devices") or []) if d) or "jiné zařízení"
        out.append((row["channel"], name, "%s — %s" % (name, devices)))
    return out


def is_live_item(get_prop) -> bool:
    """Je přehrávaná položka živý kanál RichMovie? (druh média = SSOT `richmovie_media_kind`)."""
    return _kind.of_item(get_prop) == _kind.LIVE
