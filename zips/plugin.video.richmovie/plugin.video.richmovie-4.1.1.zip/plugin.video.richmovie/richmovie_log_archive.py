# -*- coding: utf-8 -*-
"""richmovie_log_archive.py — průběžný archiv kodi.log bez dialogu (3.5.155, Gate mig 0034)

Proč to existuje
----------------
Kodi rotuje `kodi.old.log` při KAŽDÉM startu: dva restarty a log incidentu je pryč
(Chromecast ložnice 26.09.2026 — zamrznutí obrazu po přepnutí stopy se dalo prokázat jen
díky tomu, že reprodukce stihla přijít před druhým restartem). Vyžádaný pull
(`richmovie_diag_upload`) navíc čeká na dialog, který se ukáže až po otevření menu.
Richie 26.09.2026: „Všechny logy ze všech zařízení pod účtem richiefm chci posílat
pravidelně bez dotazování… strukturovaný archiv na NASu.“ Souhlas dává MAJITEL ÚČTU na
Gate (`users.kodi_log_archive_enabled`, auditovaně); tohle zařízení se může odhlásit
nastavením `kodi_log_archive_opt_out` (viditelné, Gate ho eviduje jako `override`).

Co se posílá a jak
------------------
• Jednotka = **Kodi session** (`session_key` = řádek „Starting Kodi“ + PID z hlavičky logu).
  Po restartu Kodi je tatáž session v `kodi.old.log` → doposílá se odtud a na Gate
  navazuje do TÉHOŽ souboru. Pak se začne `kodi.log` nové session od nuly.
• **Kurzor** (`kodi_log_archive_state.json`): `session_key` + `byte_to` posledního
  POTVRZENÉHO segmentu (202/200). Posouvá se AŽ po odpovědi Gate — nikdy dopředu
  (All-or-Nothing). Po ztrátě stavu (reinstalace) se kurzor převezme z `/auth`.
• Segment = souvislý rozsah bajtů zdrojového logu řezaný na hranici řádků, redigovaný
  (`richmovie_diag_upload.redact` — SSOT, první linie; Gate opakuje jako druhou),
  samostatný gzip ≤ `CHUNK_BYTES` (kontrakt Gate, stejný jako vyžádaný pull).
• Kadence: start služby (dokončit starou session z `kodi.old.log` + hlavička nové),
  pak každých `INTERVAL_S`, a `kick()` do `KICK_DELAY_S` po konci přehrávání
  (Stopped/Ended/Error/PLAY_OPEN_FAILED) — incident je na NASu do minuty.
  **Žádný shutdown flush**: Kodi dává službě 5 s (paměť `feedback_kodi_shutdown_window`),
  HTTP by ho nestihl; zbytek dojde z `kodi.old.log` při příštím startu (Kodi ho dopíše).

Nepřekročitelná pravidla (stejná jako u vyžádaného pullu)
---------------------------------------------------------
• identita = `device_hash` ze SOUBORU (`richmovie_gate_transport.get_device_hash`),
  ne z nastavení — diagnostický kanál nesmí viset na tom, co diagnostikuje;
• redakce je povinná; selhání redakce = nic se neposílá (`RedactionFailed`);
• HTTP přes `richmovie_http` (profil background), 429 se neopakuje, `Retry-After` se
  respektuje; 403 `archive_not_enabled` / `diagnostics_disabled` = STAV → spánek do
  příštího `/auth` (ne počítadlo); transport/5xx = segment zůstává, příští kadence;
• `Monitor.waitForAbort`, nikdy `time.sleep`; vlákno non-daemon (HTTP);
• nikdy celý soubor do paměti: čte se po blocích ≤ `READ_BLOCK_BYTES`.
"""

from __future__ import annotations

import gzip
import hashlib
import os
import re
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import xbmc
import richmovie_activity as _activity  # Φ4 (29.09.2026): pozadí ustoupí, když uživatel kliká
import xbmcvfs

import richmovie_settings as _rm_settings

try:
    from richmovie_logging import make_legacy_logger as _mk
    _log = _mk("richmovie.log_archive", "[RichMovie/LogArchive]")
except Exception:  # pragma: no cover - fallback bez routovaného loggeru
    def _log(msg: str, level: int = xbmc.LOGINFO, **_kw: Any) -> None:
        xbmc.log("[RichMovie/LogArchive] %s" % msg, level)

# ── Konstanty ────────────────────────────────────────────────────────────────
STATE_FILE = "kodi_log_archive_state.json"
STATE_SCHEMA_VERSION = 1
SETTING_OPT_OUT = "kodi_log_archive_opt_out"

INTERVAL_S = 120                 # D1: kadence při hraní i nečinnosti
KICK_DELAY_S = 5.0               # po konci přehrávání: nechat Kodi dopsat řádky
FIRST_RUN_TAIL_BYTES = 3 * 1024 * 1024   # první běh = jen konec logu (jako vyžádaný pull)
READ_BLOCK_BYTES = 1024 * 1024   # strop čtení na segment (Chromecast 1,9 GB RAM)
CHUNK_BYTES = 512 * 1024         # gzip ≤ Gate DIAG_MAX_CHUNK_BYTES
MAX_SEGMENTS_PER_RUN = 8         # ohraničený běh (≈ 8 MiB textu), zbytek příští kadence
HEADER_SCAN_BYTES = 8192         # „Starting Kodi“ je v prvních řádcích
LOG_FILENAMES = ("kodi.log", "kodi.old.log")
GUARD_KEY = "log_archive"
GUARD_TTL_S = 180

# odpovědi Gate, které jsou STAV (spánek do příštího /auth), ne chyba přenosu
_STATE_403_CODES = ("archive_not_enabled", "diagnostics_disabled", "not_authorized", "proof_mismatch")
MAX_GAP_CORRECTIONS_PER_RUN = 2   # 409 gap → srovnat kurzor nejvýš 2×, pak konec běhu (žádná smyčka bez prodlevy)

_STARTING_RE = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})\.\d{3} T:(\d+)\s+\w+\s+<general>: Starting Kodi",
    re.MULTILINE)

_kick_event = threading.Event()


# ─────────────────────────────────────────────────────────────────────────────
#  ČISTÁ LOGIKA (testovatelná bez Kodi)
# ─────────────────────────────────────────────────────────────────────────────

def started_at_from_header(head: bytes) -> Optional[float]:
    """Kdy Kodi nastartovalo (epoch) — z řádku „Starting Kodi“ hlavičky `kodi.log` (místní čas, jako ho Kodi píše).
    SSOT pro „běží Kodi teprve chvíli?“ (noc 03.11.2026, `richmovie_autostart`). None = hlavička chybí."""
    text = head.decode("utf-8", errors="replace")
    m = _STARTING_RE.search(text)
    if not m:
        return None
    y, mo, d, h, mi, s, _pid = m.groups()
    try:
        return float(time.mktime((int(y), int(mo), int(d), int(h), int(mi), int(s), 0, 0, -1)))
    except (OverflowError, ValueError):
        return None


def kodi_started_at() -> Optional[float]:
    """Čas startu běžícího Kodi z hlavičky `kodi.log` (Kodi ho založí při každém startu, předchozí přejmenuje na
    `kodi.old.log`). None = log nelze přečíst."""
    try:
        with open(_log_path(LOG_FILENAMES[0]), "rb") as fh:
            return started_at_from_header(fh.read(HEADER_SCAN_BYTES))
    except Exception:
        return None


def session_key_from_header(head: bytes, mtime: float) -> str:
    """Klíč Kodi session z hlavičky logu: `YYYYMMDDTHHMMSS-<pid>`; bez hlavičky `unknown-<mtime>`.

    Hlavička je stabilní po celý život souboru (i po přejmenování na kodi.old.log), takže
    tentýž klíč vyjde před restartem i po něm — právě to drží jednu session v jednom souboru.
    """
    text = head.decode("utf-8", errors="replace")
    m = _STARTING_RE.search(text)
    if not m:
        return "unknown-%d" % int(mtime or 0)
    y, mo, d, h, mi, s, pid = m.groups()
    return "%s%s%sT%s%s%s-%s" % (y, mo, d, h, mi, s, pid)


def cut_at_line_end(data: bytes, *, at_eof: bool) -> bytes:
    """Ořízne blok na poslední úplný řádek. Na konci souboru se poslední řádek bere celý jen
    u UZAVŘENÉHO souboru (kodi.old.log); u živého logu se právě dopisuje → nechá se na příště."""
    if at_eof:
        return data
    idx = data.rfind(b"\n")
    return data[:idx + 1] if idx >= 0 else b""


def plan_segments(state: Dict[str, Any], files: Dict[str, Tuple[str, int]],
                  *, first_run_tail: int = FIRST_RUN_TAIL_BYTES) -> List[Tuple[str, str, int, int]]:
    """Co poslat: seznam (filename, session_key, byte_from, byte_to_max) v pořadí.

    `files` = {filename: (session_key, size)} pro existující soubory. `state` = kurzor
    (`session_key`, `byte_to`) nebo prázdný. Čistá funkce — čtení a řezání dělá volající.
      • stejná session jako kurzor v kodi.log → pokračovat;
      • kurzor ukazuje na session, která je teď v kodi.old.log → doposlat zbytek, pak nová;
      • kurzor na session, která už nikde není (dva restarty) → GAP (zaloguje volající),
        pokračuje se od kodi.old.log (celý, je krátký) a kodi.log od 0;
      • bez kurzoru (první běh / reinstalace bez kurzoru Gate) → jen KONEC (first_run_tail)
        kodi.old.log i kodi.log — historii před zapnutím archivu nikdo nechce celou.
    """
    cur = files.get("kodi.log")
    old = files.get("kodi.old.log")
    key = str(state.get("session_key") or "")
    pos = int(state.get("byte_to") or 0)
    out: List[Tuple[str, str, int, int]] = []

    def tail_from(size: int) -> int:
        return max(0, size - first_run_tail) if first_run_tail and size > first_run_tail else 0

    if not key:
        if old and old[1] > 0:
            out.append(("kodi.old.log", old[0], tail_from(old[1]), old[1]))
        if cur and cur[1] > 0:
            out.append(("kodi.log", cur[0], tail_from(cur[1]), cur[1]))
        return out

    if cur and cur[0] == key:
        if cur[1] > pos:
            out.append(("kodi.log", key, pos, cur[1]))
        return out

    if old and old[0] == key:
        if old[1] > pos:
            out.append(("kodi.old.log", key, pos, old[1]))
        if cur and cur[1] > 0:
            out.append(("kodi.log", cur[0], 0, cur[1]))
        return out

    # session z kurzoru už neexistuje (≥ 2 restarty od posledního běhu) — díra v archivu
    if old and old[1] > 0:
        out.append(("kodi.old.log", old[0], 0, old[1]))
    if cur and cur[1] > 0:
        out.append(("kodi.log", cur[0], 0, cur[1]))
    return out


def classify_response(status: int, body: Any) -> Tuple[str, Optional[int], Optional[int]]:
    """(výsledek, next_from, retry_after_s): 'ok' | 'duplicate' | 'gap' | 'state' | 'cap' | 'retry'.

    'state' = Gate říká stav účtu/zařízení (403 s kódem archivu) → spánek do příštího /auth.
    'retry' = transport/5xx/kontrakt → segment zůstává, příští kadence (bez vlastního backoffu).
    """
    code = ""
    next_from = None
    retry_after = None
    if isinstance(body, dict):
        err = body.get("error") if isinstance(body.get("error"), dict) else {}
        code = str((err or {}).get("code") or body.get("code") or "")
        try:
            next_from = int(body.get("next_from")) if body.get("next_from") is not None else None
        except (TypeError, ValueError):
            next_from = None
        try:
            retry_after = int((err or {}).get("retry_after")) if (err or {}).get("retry_after") else None
        except (TypeError, ValueError):
            retry_after = None
    if status == 202 and isinstance(body, dict) and body.get("accepted") is True:
        return "ok", next_from, None
    if status == 200 and isinstance(body, dict) and body.get("duplicate"):
        return "duplicate", next_from, None
    if status == 409 and code == "gap":
        return "gap", next_from, None
    if status == 403 and code in _STATE_403_CODES:
        return "state", None, None
    if status == 429:
        return "cap", None, retry_after
    return "retry", None, retry_after


def pack_segment(text: str, chunk_bytes: int = CHUNK_BYTES) -> Tuple[bytes, int]:
    """(gzip, počet řádků, které se do něj vešly). Když se komprimát nevejde, půlí se na hranici
    řádků; jediný řádek nad limit se zkrátí se značkou (upload nesmí uvíznout na anomálii)."""
    lines = text.splitlines(keepends=True)
    take = len(lines)
    while take > 0:
        blob = gzip.compress("".join(lines[:take]).encode("utf-8"))
        if len(blob) <= chunk_bytes or take == 1:
            break
        take = max(1, take // 2)
    if take == 1 and len(blob) > chunk_bytes:
        cut_bytes = lines[0].encode("utf-8")[:chunk_bytes // 4]
        blob = gzip.compress((cut_bytes.decode("utf-8", errors="ignore") + " ...[RADEK ZKRACEN]\n").encode("utf-8"))
    return blob, take


# ─────────────────────────────────────────────────────────────────────────────
#  STAV
# ─────────────────────────────────────────────────────────────────────────────

def _state_path() -> str:
    base = xbmcvfs.translatePath("special://profile/addon_data/%s/" % _rm_settings.ADDON_ID)
    return os.path.join(base, STATE_FILE)


def _load_state() -> Dict[str, Any]:
    import richmovie_atomic as _atomic
    data, _st = _atomic.read_json(_state_path(), {}, name="kodi_log_archive_state", expected_type=dict)
    return data if isinstance(data, dict) else {}


def _save_state(state: Dict[str, Any]) -> bool:
    import richmovie_atomic as _atomic
    state["schema_version"] = STATE_SCHEMA_VERSION
    ok = _atomic.write_json(_state_path(), state, indent=1)
    if not ok:
        _log("state write failed", xbmc.LOGWARNING)
    return ok


def _log_path(filename: str) -> str:
    return os.path.join(xbmcvfs.translatePath("special://logpath/"), filename)


def _scan_files() -> Dict[str, Tuple[str, int]]:
    """{filename: (session_key, size)} pro existující logy; hlavička se čte jen z prvních KB."""
    out: Dict[str, Tuple[str, int]] = {}
    for name in LOG_FILENAMES:
        path = _log_path(name)
        try:
            if not os.path.isfile(path):
                continue
            st = os.stat(path)
            with open(path, "rb") as fh:
                head = fh.read(HEADER_SCAN_BYTES)
            out[name] = (session_key_from_header(head, st.st_mtime), int(st.st_size))
        except Exception as exc:
            _log("scan %s failed: %r" % (name, exc), xbmc.LOGWARNING)
    return out


def _read_range(filename: str, byte_from: int, byte_to_max: int,
                expected_session_key: str = "") -> Tuple[bytes, int]:
    """Přečte ≤ READ_BLOCK_BYTES od `byte_from`, ořízne na řádek. Vrací (bajty, byte_to).
    Když soubor mezitím zmizel/rotoval (velikost < byte_from, nebo hlavička už patří JINÉ session —
    Kodi restartovalo mezi `_scan_files` a čtením; cross-check Pro B 26.09.2026), vrací (b"", byte_from)
    a běh se ukončí; příští kadence si soubory přeskenuje znovu."""
    path = _log_path(filename)
    try:
        st = os.stat(path)
        size = st.st_size
        if size < byte_from:
            return b"", byte_from
        end = min(byte_to_max, size, byte_from + READ_BLOCK_BYTES)
        if end <= byte_from:
            return b"", byte_from
        with open(path, "rb") as fh:
            if expected_session_key:
                head = fh.read(HEADER_SCAN_BYTES)
                if session_key_from_header(head, st.st_mtime) != expected_session_key:
                    _log("read %s: soubor uz patri jine session (rotace mezi scanem a ctenim) → preskocit"
                         % filename, xbmc.LOGINFO)
                    return b"", byte_from
            fh.seek(byte_from)
            data = fh.read(end - byte_from)
        closed = filename == "kodi.old.log" and end >= size
        data = cut_at_line_end(data, at_eof=closed)
        return data, byte_from + len(data)
    except Exception as exc:
        _log("read %s failed: %r" % (filename, exc), xbmc.LOGWARNING)
        return b"", byte_from


# ─────────────────────────────────────────────────────────────────────────────
#  PODMÍNKY
# ─────────────────────────────────────────────────────────────────────────────

def opted_out() -> bool:
    """Nastavení zařízení `kodi_log_archive_opt_out` (default false). Přes SSOT settings."""
    try:
        return bool(_rm_settings.get_bool(SETTING_OPT_OUT))
    except Exception:
        return False


def _preconditions() -> Tuple[bool, str]:
    if opted_out():
        return False, "opt_out"
    try:
        import richmovie_gate as _gate
        enabled, _cursor = _gate.get_log_archive()
    except Exception as exc:
        return False, "auth_cache:%r" % (exc,)
    if not enabled:
        return False, "not_enabled"
    try:
        import richmovie_netstate as _ns
        if _ns.is_offline():
            return False, "offline"
    except Exception:
        pass
    try:
        import richmovie_identity_state as _ident
        if not _ident.allow_gate_request():
            return False, "identity"
    except Exception:
        pass
    return True, "ok"


# ─────────────────────────────────────────────────────────────────────────────
#  ODESLÁNÍ
# ─────────────────────────────────────────────────────────────────────────────

def _addon_version() -> str:
    try:
        import xbmcaddon
        return xbmcaddon.Addon(_rm_settings.ADDON_ID).getAddonInfo("version") or "?"
    except Exception:
        return "?"


def _kodi_version() -> str:
    try:
        return xbmc.getInfoLabel("System.BuildVersion") or ""
    except Exception:
        return ""


def _platform() -> str:
    try:
        import richmovie_gate_transport as _gt
        return _gt.detect_platform() or ""
    except Exception:
        return ""


def _send(blob: bytes, *, device_hash: str, session_key: str, filename: str, seq: int,
          byte_from: int, byte_to: int, lines: int) -> Tuple[str, Optional[int], Optional[int]]:
    import richmovie_http as _rm_http
    import richmovie_gate_transport as _gt
    headers = {
        "Content-Type": "application/gzip",
        "User-Agent": "RichMovie/%s (+plugin.video.richmovie)" % _addon_version(),
        "X-Device-Hash": device_hash,
        "X-Session-Key": session_key,
        "X-Filename": filename,
        "X-Seq": str(seq),
        "X-Byte-From": str(byte_from),
        "X-Byte-To": str(byte_to),
        "X-Lines": str(lines),
        "X-Sha256": hashlib.sha256(blob).hexdigest(),
        "X-Client-Ts": datetime.now(timezone.utc).isoformat(),
        "X-Addon-Version": _addon_version(),
        "X-Kodi-Version": _kodi_version(),
        "X-Platform": _platform(),
    }
    try:
        username, proof = _gt.get_identity()
        if username and proof:
            headers["X-WS-Username"] = username
            headers["X-WS-Proof"] = proof
    except Exception:
        pass
    try:
        # `idempotent=True` je DOLOŽENÉ: Gate UNIQUE (device, session, byte_from) + odpověď
        # `duplicate` → opakovaný segment nikdy nevyrobí druhý řádek ani druhý append.
        status, body, _hdrs = _rm_http.request(
            "%s/v1/diag/kodi_log/segment" % _gt.GATE_URL, method="POST", headers=headers,
            data=blob, profile=_rm_http.profile_background(), idempotent=True, tag="log_archive")
    except Exception as exc:
        _log("segment %s[%d:%d] neodeslán: %r" % (filename, byte_from, byte_to, exc), xbmc.LOGWARNING)
        return "retry", None, None
    parsed: Any = None
    try:
        import json as _json
        parsed = _json.loads(body) if isinstance(body, (str, bytes)) and body else body
    except Exception:
        parsed = None
    return classify_response(int(status or 0), parsed)


def run_once(*, max_segments: int = MAX_SEGMENTS_PER_RUN, reason: str = "tick") -> str:
    """Jeden ohraničený běh. Vrací důvod ukončení (pro log/test). Nikdy nevyhazuje."""
    try:
        return _run_once(max_segments=max_segments, reason=reason)
    except Exception as exc:
        _log("run_once(%s) selhalo: %r" % (reason, exc), xbmc.LOGWARNING)
        return "failed"


def _run_once(*, max_segments: int, reason: str) -> str:
    import richmovie_guard as _guard
    import richmovie_gate_transport as _gt
    from richmovie_diag_upload import redact as _redact, RedactionFailed as _RedactionFailed

    ok, why = _preconditions()
    if not ok:
        return why
    state = _load_state()
    now = time.time()
    if float(state.get("not_before_ts") or 0) > now:
        return "not_before"
    if state.get("sleep_until_auth") and state.get("sleep_until_auth") == _auth_fingerprint():
        return "sleeping_until_auth"

    device_hash = ""
    try:
        device_hash = _gt.get_device_hash() or ""
    except Exception:
        device_hash = ""
    if not device_hash:
        return "no_device_id"

    token = _guard.claim(GUARD_KEY, GUARD_TTL_S)
    if not token:
        return "busy"
    try:
        # kurzor Gate má přednost před prázdným lokálním stavem (reinstalace, ztráta souboru)
        if not state.get("session_key"):
            try:
                import richmovie_gate as _gate
                _en, cursor = _gate.get_log_archive()
                if isinstance(cursor, dict) and cursor.get("session_key"):
                    state["session_key"] = str(cursor["session_key"])
                    state["byte_to"] = int(cursor.get("byte_to") or 0)
                    _log("kurzor převzat z Gate: %s@%d" % (state["session_key"], state["byte_to"]))
            except Exception:
                pass

        files = _scan_files()
        if not files:
            return "no_log"
        plan = plan_segments(state, files)
        if state.get("session_key") and plan and plan[0][1] != state.get("session_key") \
                and plan[0][0] == "kodi.old.log" and plan[0][2] == 0 and files.get("kodi.old.log", ("", 0))[0] != state.get("session_key"):
            _log("ARCHIVE_GAP: session %s z kurzoru už na disku není (≥ 2 restarty Kodi) → pokračuji novou"
                 % state.get("session_key"), xbmc.LOGWARNING)
        sent = 0
        gaps = 0
        monitor = xbmc.Monitor()
        for filename, session_key, byte_from, byte_to_max in plan:
            pos = byte_from
            while pos < byte_to_max and sent < max_segments:
                if monitor.abortRequested():
                    return "abort"
                _guard.renew(GUARD_KEY, token, GUARD_TTL_S)
                data, end = _read_range(filename, pos, byte_to_max, session_key)
                if not data:
                    break
                # Redakce PO ŘÁDCÍCH: mapování „řádek komprimátu ↔ bajty zdroje" je pak 1:1 bez
                # ohledu na to, co regexy s textem udělají (cross-check Pro B 3 / Flash D7, 26.09.2026).
                raw_lines = data.splitlines(keepends=True)
                try:
                    red_lines = [_redact(l.decode("utf-8", errors="replace")) for l in raw_lines]
                except _RedactionFailed as exc:
                    _log("REDAKCE SELHALA → neodesílám nic: %s" % (exc,), xbmc.LOGERROR)
                    return "redaction_failed"
                red_lines = [l if l.endswith("\n") else l + "\n" for l in red_lines]
                blob, lines_in = pack_segment("".join(red_lines))
                if lines_in < len(raw_lines):
                    # komprimát se nevešel celý → poslat jen prvních `lines_in` řádků; `end` = konec
                    # posledního z nich ve ZDROJOVÝCH bajtech
                    end = pos + sum(len(l) for l in raw_lines[:lines_in])
                    if end <= pos:
                        break
                seq = int(state.get("seq") or 0) + 1
                result, next_from, retry_after = _send(
                    blob, device_hash=device_hash, session_key=session_key, filename=filename,
                    seq=seq, byte_from=pos, byte_to=end, lines=lines_in)
                if result in ("ok", "duplicate"):
                    new_pos = end if result == "ok" else (next_from if next_from is not None else end)
                    state.update({"session_key": session_key, "byte_to": int(new_pos), "seq": seq,
                                  "last_ok_ts": int(time.time()), "not_before_ts": 0})
                    state.pop("sleep_until_auth", None)
                    _save_state(state)
                    sent += 1
                    pos = int(new_pos)
                    continue
                if result == "gap":
                    gaps += 1
                    if next_from is None or next_from >= byte_to_max or gaps > MAX_GAP_CORRECTIONS_PER_RUN:
                        _log("gap bez použitelného next_from (%r) nebo opakovaný (%d×) → konec běhu"
                             % (next_from, gaps), xbmc.LOGWARNING)
                        return "gap"
                    _log("ARCHIVE_GAP Gate čeká od %d, měl jsem %d → srovnávám kurzor" % (next_from, pos))
                    state.update({"session_key": session_key, "byte_to": int(next_from)})
                    _save_state(state)
                    pos = int(next_from)
                    continue
                if result == "state":
                    state["sleep_until_auth"] = _auth_fingerprint()
                    _save_state(state)
                    _log("Gate: archiv pro toto zařízení není povolen → spím do příštího /auth")
                    return "state"
                if result == "cap":
                    state["not_before_ts"] = int(time.time() + (retry_after or 3600))
                    _save_state(state)
                    _log("Gate: denní strop archivu → další pokus za %d s" % int(retry_after or 3600))
                    return "cap"
                # retry: kurzor se nemění; když Gate poslal Retry-After (503 storage_inconsistent,
                # storage_unavailable), respektuje se — jinak příští kadence (Fable audit 26.09.2026).
                if retry_after:
                    state["not_before_ts"] = int(time.time() + int(retry_after))
                    _save_state(state)
                return "retry"
            if sent >= max_segments:
                return "budget"
        return "done" if sent else "nothing"
    finally:
        try:
            _guard.release(GUARD_KEY, token)
        except Exception:
            pass


def _auth_fingerprint() -> str:
    """Otisk poslední odpovědi /auth (čas) — 'spánek do příštího /auth' se pozná změnou otisku."""
    try:
        import richmovie_gate as _gate
        return str(_gate.get_auth_fingerprint() or "")
    except Exception:
        return ""


# ─────────────────────────────────────────────────────────────────────────────
#  WORKER (service_nextup)
# ─────────────────────────────────────────────────────────────────────────────

def kick() -> None:
    """Po konci přehrávání: běh do KICK_DELAY_S (ne hned — Kodi ještě dopisuje řádky)."""
    _kick_event.set()


def start_worker(monitor: xbmc.Monitor) -> threading.Thread:
    """Non-daemon vlákno: start → kadence INTERVAL_S → kick. Abort-safe (waitForAbort)."""
    def _loop() -> None:
        first = True
        while not monitor.abortRequested():
            if first:
                first = False
                if monitor.waitForAbort(15.0):   # nechat naběhnout /auth + netstate
                    return
                run_once(reason="boot")
            waited = 0.0
            kicked = False
            while waited < INTERVAL_S and not monitor.abortRequested():
                if _kick_event.wait(1.0):
                    _kick_event.clear()
                    kicked = True
                    break
                waited += 1.0
            if monitor.abortRequested():
                return
            if kicked:
                if monitor.waitForAbort(KICK_DELAY_S):
                    return
            # Φ4: čtení + redakce logu po řádcích v Pythonu drží GIL → počkat, až uživatel neklikne
            if not _activity.wait_while_busy(monitor):
                return
            run_once(reason="kick" if kicked else "tick")

    th = threading.Thread(target=_loop, name="RMLogArchive", daemon=False)
    th.start()
    return th
