# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_backfill.py
# Auto-backfill historic watch_history.json + history.json + continue_watching.json
# do Gate user_watch_events / user_search_events tables.
# Phase A1 (RichMovie 3.1.0 polish, 2026-04-26) — replaces manual Python script.
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie 3.1.0 polish — Auto-backfill legacy addon-side history into Gate.

Why: Pre-3.1.0 addons logged watch + search events to local JSON files in
profile_dir. 3.1.0 telemetry pipeline (richmovie_player_hook.py +
richmovie_telemetry.py) only captures NEW events from install onward.
Without backfill, taste_profile compute returns "new user" → AI generates
generic "first 10 top-rated mainstream" recommendations.

This module bridges the gap: at first 3.1.0+ startup, reads legacy files,
sends them as synthetic events to Gate via /v1/ai/recommendations/events_batch
(idempotent via stable client_event_id hash). Marks settings flag so it never
runs twice.

Synthetic event defaults (since legacy JSON lacks rich signals):
  - completion: 0.95 (user historically marked them as watched)
  - duration_watched_s: total_runtime_s × 0.95
  - device_cluster_id: "legacy-backfill-pre-3.1.0"
  - pause/seek/speed/audio counts: 0 / "1.0x" / null
  - session_id: synthesized per event
  - client_event_id: deterministic SHA-256 hash → idempotent (re-runs safe)

API:
    backfill_if_needed() -> None
        Run once at addon startup. Checks settings flag, runs only on first
        3.1.0+ launch with non-empty legacy data. Best-effort — failures
        logged but never crash addon.

Author: Richie (autonomous Phase A1 implementation 2026-04-26)
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

_LOG_PREFIX = "[RichMovie.backfill]"

# 2026-07-01 (observability program): backfill logy (import transportu / spawn threadu
# ERROR + chunk WARNING jednorázové migrace) přepnuty z přímého xbmc.log na ROUTOVANÝ
# logger → tečou na NAS (Gate). `_log(msg, level=INFO)`.
try:
    from richmovie_logging import make_legacy_logger as _bf_make_legacy_logger
    _log = _bf_make_legacy_logger("richmovie.backfill", "RichMovie/Backfill")
except Exception:
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log(_LOG_PREFIX + " " + str(msg), level)
        except Exception:
            pass
_SETTINGS_FLAG = "backfill_v1_done"     # addon setting — set "true" after success
_BACKFILL_BATCH_SIZE = 200              # POST chunk size (server cap 5000, conservative)
_BACKFILL_TIMEOUT_S = 60.0


# ─────────────────────────────────────────────────────────────────────────────
#  ADDON / FS HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _get_addon() -> xbmcaddon.Addon:
    return xbmcaddon.Addon()


def _get_profile_dir() -> Path:
    addon_id = _get_addon().getAddonInfo("id")
    p = Path(xbmcvfs.translatePath(f"special://profile/addon_data/{addon_id}"))
    p.mkdir(parents=True, exist_ok=True)
    return p


def _is_done() -> bool:
    """Has backfill already succeeded? (addon setting flag)"""
    try:
        import richmovie_settings as _rm_settings
        return _rm_settings.get_str(_SETTINGS_FLAG).lower() == "true"
    except Exception:
        return False


def _mark_done() -> None:
    try:
        import richmovie_settings as _rm_settings
        # Ověřený zápis (3.5.124): kdyby Kodi marker tiše ztratilo, backfill by
        # běžel znovu — což je bezpečné (idempotentní), ale má se to vědět.
        if not _rm_settings.write(_SETTINGS_FLAG, "true"):
            _log("backfill done-marker NOT persisted (SETTINGS_WRITE_LOST) — poběží znovu",
                 xbmc.LOGWARNING)
            return
        _log(f"backfill marked done in addon settings", xbmc.LOGINFO)
    except Exception as exc:
        _log(f"mark_done failed: {exc!r}", xbmc.LOGWARNING)


def _read_json_file(path: Path) -> Any:
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        _log(f"read fail {path.name}: {exc!r}", xbmc.LOGWARNING)
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  EVENT BUILDERS — convert legacy JSON to event payloads
# ─────────────────────────────────────────────────────────────────────────────

def _hash_event_id(prefix: str, *parts: Any) -> str:
    """Deterministic client_event_id so re-runs dedup at Gate
    (Gate uses ON CONFLICT (user_id, client_event_id) DO NOTHING)."""
    h = hashlib.sha256("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()
    return f"backfill-{prefix}-{h[:24]}"


def _ts_to_iso(ts: int | float | None) -> str:
    """Unix epoch seconds → RFC 3339 UTC. Defaults to 2025-01-01 if missing."""
    if ts is None or ts <= 0:
        return datetime(2025, 1, 1, tzinfo=timezone.utc).isoformat()
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).isoformat()


def _build_watch_events(profile_dir: Path) -> list[dict[str, Any]]:
    """Read watch_history.json → synthetic watch_event payloads."""
    events: list[dict[str, Any]] = []
    data = _read_json_file(profile_dir / "watch_history.json")
    if not isinstance(data, dict):
        return events

    # Movies
    for m in (data.get("movies") or []):
        if not isinstance(m, dict):
            continue
        tmdb_id = m.get("tmdb")
        title = m.get("title")
        if not tmdb_id or not title:
            continue
        ts = m.get("ts")
        cid = _hash_event_id("movie", tmdb_id, ts)
        started_iso = _ts_to_iso(ts)
        ended_iso = _ts_to_iso((ts or 0) + 110 * 60) if ts else started_iso
        events.append({
            "client_event_id": cid,
            "session_id": cid,
            "tmdb_id": int(tmdb_id),
            "kind": "movie",
            "title": str(title),
            "year": int(m.get("year") or 0) or None,
            "genres": [],
            "origin_country": None,
            "imdb_rating": None,
            "started_at": started_iso,
            "ended_at": ended_iso,
            "duration_watched_s": 6300,        # ~105 min
            "total_runtime_s": 6600,
            "completion": 0.95,
            "drop_point_s": None,
            "rewatch_count": 0,
            "device_cluster_id": "legacy-backfill-pre-3.1.0",
            "platform": "Legacy",
            "addon_version": "pre-3.1.0",
            "audio_used": None,
            "audio_switched_count": 0,
            "subs_used": None,
            "subs_switched_count": 0,
            "pause_count": 0, "resume_count": 0,
            "seek_count": 0, "seek_fwd_count": 0, "seek_back_count": 0,
            "speed_used": "1.0x", "speed_changes_count": 0,
            "source_used": None, "quality_picked": None, "quality_options": [],
            "binge_session_id": None, "is_part_of_binge": False,
            "preceded_by_client_event_id": None,
        })

    # TV episodes (multiple potential keys depending on legacy version)
    for s in ((data.get("series") or []) + (data.get("tv") or [])):
        if not isinstance(s, dict):
            continue
        tv_id = s.get("tv_id") or s.get("tmdb")
        title = s.get("tv_name") or s.get("title")
        season = s.get("season")
        episode = s.get("episode")
        ts = s.get("ts")
        if not tv_id or not title:
            continue
        cid = _hash_event_id("tv", tv_id, season, episode, ts)
        events.append({
            "client_event_id": cid,
            "session_id": cid,
            "tmdb_id": int(tv_id),
            "kind": "tv",
            "season": int(season) if season else None,
            "episode": int(episode) if episode else None,
            "title": str(title),
            "year": None,
            "genres": [],
            "origin_country": None,
            "imdb_rating": None,
            "started_at": _ts_to_iso(ts),
            "ended_at": _ts_to_iso((ts or 0) + 45 * 60) if ts else _ts_to_iso(ts),
            "duration_watched_s": 2550,
            "total_runtime_s": 2700,
            "completion": 0.95,
            "drop_point_s": None,
            "rewatch_count": 0,
            "device_cluster_id": "legacy-backfill-pre-3.1.0",
            "platform": "Legacy",
            "addon_version": "pre-3.1.0",
            "audio_used": None,
            "audio_switched_count": 0,
            "subs_used": None,
            "subs_switched_count": 0,
            "pause_count": 0, "resume_count": 0,
            "seek_count": 0, "seek_fwd_count": 0, "seek_back_count": 0,
            "speed_used": "1.0x", "speed_changes_count": 0,
            "source_used": None, "quality_picked": None, "quality_options": [],
            "binge_session_id": None, "is_part_of_binge": False,
            "preceded_by_client_event_id": None,
        })

    return events


def _build_search_events(profile_dir: Path) -> list[dict[str, Any]]:
    """Read history.json → synthetic search_event payloads."""
    events: list[dict[str, Any]] = []
    data = _read_json_file(profile_dir / "history.json")
    if not isinstance(data, dict):
        return events

    for cat in ("movie", "tv", "ws", "other"):
        items = data.get(cat) or []
        for item in items:
            if isinstance(item, dict):
                query = item.get("query")
                tmdb_id = item.get("tmdb_id")
                ts = item.get("ts")
            else:
                query = str(item) if item else None
                tmdb_id = None
                ts = None
            if not query:
                continue
            cid = _hash_event_id("search", cat, query, ts)
            events.append({
                "client_event_id": cid,
                "query": query,
                "category": cat if cat in ("movie", "tv", "ws", "other") else "other",
                "ts": _ts_to_iso(ts),
                "results_count": 0,
                "clicked_tmdb_id": int(tmdb_id) if tmdb_id else None,
                "clicked_at": _ts_to_iso(ts) if tmdb_id else None,
                "click_latency_s": 0 if tmdb_id else None,
                "result_played": bool(tmdb_id),
                "abandoned": False if tmdb_id else True,
                "device_cluster_id": "legacy-backfill-pre-3.1.0",
            })

    return events


# ─────────────────────────────────────────────────────────────────────────────
#  GATE TRANSPORT
# ─────────────────────────────────────────────────────────────────────────────

def _post_batch(watch_chunk: list[dict], search_chunk: list[dict]) -> tuple[bool, dict]:
    """POST one batch chunk to Gate. Returns (success, response_dict)."""
    try:
        from richmovie_gate_transport import post_json, get_identity, build_common_fields
    except ImportError as exc:
        _log(f"transport import fail: {exc!r}", xbmc.LOGERROR)
        return False, {"error": "transport_import_fail"}

    username, _proof = get_identity()
    if not username:
        return False, {"error": "no_identity"}

    body = {
        "schema_version": 1,
        **build_common_fields(),
        "watch_events": watch_chunk,
        "search_events": search_chunk,
    }
    try:
        status, parsed = post_json(
            "/v1/ai/recommendations/events_batch",
            body,
            timeout=_BACKFILL_TIMEOUT_S,
        )
    except Exception as exc:
        return False, {"error": "transport_fail", "detail": repr(exc)}

    if status < 200 or status >= 300:
        return False, {"error": f"http_{status}", "body": parsed}

    return True, parsed if isinstance(parsed, dict) else {}


def _chunked(lst: list, n: int) -> list[list]:
    return [lst[i:i + n] for i in range(0, len(lst), n)]


# ─────────────────────────────────────────────────────────────────────────────
#  MAIN ENTRYPOINT
# ─────────────────────────────────────────────────────────────────────────────

def _do_backfill() -> None:
    """Full backfill flow. Runs in background thread."""
    if _is_done():
        _log(f"already done (settings flag) — skip", xbmc.LOGDEBUG)
        return

    # 3.5.134 (profily): backfill čte OSOBNÍ soubory aktivního profilu (u single =
    # kořen jako dřív). Marker „hotovo" zůstává účtový — přesun do multi soubory
    # jen přestěhuje, události už na Gate jsou.
    import richmovie_paths
    profile_dir = richmovie_paths.personal_dir()
    _log(f"starting (reading from {profile_dir})", xbmc.LOGINFO)

    watch_events = _build_watch_events(profile_dir)
    search_events = _build_search_events(profile_dir)

    total = len(watch_events) + len(search_events)
    _log(
        f"built {len(watch_events)} watch + {len(search_events)} search "
        f"events from legacy JSON",
        xbmc.LOGINFO,
    )

    if total == 0:
        # Nothing to backfill (fresh install, no legacy data) — mark done
        # so we don't keep checking.
        _log(f"no legacy data — marking done", xbmc.LOGINFO)
        _mark_done()
        return

    # POST in chunks; tolerate partial failures (Gate dedups via client_event_id)
    accepted_total = 0
    duplicates_total = 0
    error_total = 0
    failure_count = 0

    for i, chunk in enumerate(_chunked(watch_events, _BACKFILL_BATCH_SIZE)):
        ok, resp = _post_batch(chunk, [])
        if ok:
            accepted_total += int(resp.get("accepted", 0))
            duplicates_total += int(resp.get("duplicates_skipped", 0))
            error_total += len(resp.get("errors") or [])
            _log(
                f"watch chunk {i+1}: "
                f"accepted={resp.get('accepted')} dup={resp.get('duplicates_skipped')} "
                f"errors={len(resp.get('errors') or [])}",
                xbmc.LOGINFO,
            )
        else:
            failure_count += 1
            _log(f"watch chunk {i+1} failed: {resp}", xbmc.LOGWARNING)

    for i, chunk in enumerate(_chunked(search_events, _BACKFILL_BATCH_SIZE)):
        ok, resp = _post_batch([], chunk)
        if ok:
            accepted_total += int(resp.get("accepted", 0))
            duplicates_total += int(resp.get("duplicates_skipped", 0))
            error_total += len(resp.get("errors") or [])
            _log(
                f"search chunk {i+1}: "
                f"accepted={resp.get('accepted')} dup={resp.get('duplicates_skipped')} "
                f"errors={len(resp.get('errors') or [])}",
                xbmc.LOGINFO,
            )
        else:
            failure_count += 1
            _log(f"search chunk {i+1} failed: {resp}", xbmc.LOGWARNING)

    if failure_count == 0:
        _log(
            f"✓ backfill complete: accepted={accepted_total} "
            f"dup={duplicates_total} errors={error_total}",
            xbmc.LOGINFO,
        )
        _mark_done()
    else:
        _log(
            f"⚠ backfill partial: {failure_count} chunks failed. "
            f"Will retry next addon startup. accepted={accepted_total} dup={duplicates_total}",
            xbmc.LOGWARNING,
        )
        # Do NOT mark done — let next startup retry. Gate dedups via
        # client_event_id so accepted chunks won't double-insert.


def backfill_if_needed() -> None:
    """Public entrypoint. Spawns background thread (non-blocking).

    Called from `service_nextup.py` (3.5.130) 120 s po bootu služby, jen když platí
    `_backfill_preconditions_met()`; do 3.5.129 se volal ze `service_warm.py`, který
    Kodi nikdy nespustilo → nikdy neběžel. Best-effort — never raises.
    """
    if _is_done():
        return
    try:
        # NOT daemon=True — per `feedback_daemon_threads_kodi.md`, HTTP threads
        # must finish before process exit (avoid mid-flight kill).
        t = threading.Thread(
            target=_do_backfill,
            name="RichMovie-backfill",
        )
        t.start()
        _log(f"background thread started", xbmc.LOGINFO)
    except Exception as exc:
        _log(f"thread spawn failed: {exc!r}", xbmc.LOGERROR)


def reset_for_testing() -> None:
    """Clear settings flag to allow re-run. Dev/debug only — call from REPL."""
    try:
        import richmovie_settings as _rm_settings
        _rm_settings.write(_SETTINGS_FLAG, "")
        _log(f"flag cleared — backfill will re-run on next startup",
                 xbmc.LOGINFO)
    except Exception as exc:
        _log(f"reset_for_testing failed: {exc!r}", xbmc.LOGWARNING)
