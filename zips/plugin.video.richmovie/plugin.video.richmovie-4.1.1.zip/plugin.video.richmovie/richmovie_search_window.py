# -*- coding: utf-8 -*-
"""RichMovie 4.0 — custom Search okno s vlastní klávesnicí (WindowXMLDialog).

Φ-S (2026-06-12, Richie request): ŽÁDNÝ Kodi keyboard dialog. Vlastní
vyhledávání ve stylu Netflix:
  • vlastní on-screen klávesnice (panel A-Z + 0-9, TV ovladač i touch klik),
  • na PC funguje i FYZICKÁ klávesnice (onAction getUnicode — píšeš rovnou),
  • LIVE výsledky: search-as-you-type s debounce 600 ms (TMDb film+seriál,
    generation guard — starý výsledek nikdy nepřepíše novější),
  • před psaním „Naposledy hledané" z historie (návykovost: 1 klik k opakování),
  • klik na výsledek → custom Detail NAD vyhledáváním (Back vrací do výsledků).

Device mode: uc.device_mode (tv = velké klávesy/ovladač, pc = + hint psaní;
touch funguje klikem na klávesy v obou režimech).
SSOT: richmovie_ui_common. XML: RichMovieSearch.xml. Best-effort, neshodí addon.
"""
from __future__ import annotations

import threading
import urllib.parse

import xbmc
import xbmcgui

import richmovie_ui_common as uc
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/Search] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.search", "RichMovie/Search")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "Search] " + str(msg), level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"
_XML = "RichMovieSearch.xml"
_RES = "1080i"
_BASE = f"plugin://{_ADDON_ID}/"

_KEYS = 7200      # panel klávesnice
_KEY_SPACE = 7201
_KEY_DEL = 7202
_KEY_CLEAR = 7203
_FIELD = 7205     # klikatelné vyhledávací pole → otevře klávesnici (univerzální
                  # intuice: myš/dotyk/OK na TV; Kodi nepouští raw stisky kláves
                  # do custom oken, jen do nativního text inputu)
_RESULTS = 6200   # panel výsledků

_KEY_ROWS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
_DEBOUNCE_S = 0.6
_MIN_CHARS = 2


class RichMovieSearchWindow(uc.RMNavMixin, xbmcgui.WindowXMLDialog):

    def __init__(self, *a, kind="all", q="", **kw):
        super().__init__(*a, **kw)
        # R2-P2-7: `q` = obnova dotazu při playback replay (routa nese aktuální
        # dotaz přes nav_update) — bez něj se po přehrání otevřelo prázdné hledání
        self._q = (q or "").strip()
        self._kind = (kind or "all").lower()  # all | movie | tv (oddělené hledání)
        self._gen = 0          # generation guard pro debounce + výsledky
        self._focus_results = False  # po potvrzení klávesnice → focus na výsledky AŽ DORAZÍ
        self._rm_closed = False
        self._search_cid = ""  # Φ6: pending search event id (telemetrie)

    _FEED = {"movie": "search_movies", "tv": "search_tv", "all": "search_all"}
    _PLACEHOLDER = {
        "movie": "🔍  Klepni a piš — hledat film…",
        "tv": "🔍  Klepni a piš — hledat seriál…",
        "all": "🔍  Klepni a piš — film nebo seriál…",
    }
    _KB_HEADING = {"movie": "Hledat film", "tv": "Hledat seriál",
                   "all": "Hledat film nebo seriál"}

    # ------------------------------------------------------------------ init
    def onInit(self) -> None:
        try:
            self.setProperty("rm_device", uc.device_mode())
            self.setProperty("rm_s_placeholder",
                             self._PLACEHOLDER.get(self._kind, self._PLACEHOLDER["all"]))
            self._render_query()
            self._build_keys()
            if self._q:
                self._schedule_search()  # R2-P2-7: replay s dotazem → rovnou výsledky
            else:
                self._show_recent()
            # PC/touch: default focus na poli (klik/tap → klávesnice, jak je
            # zvykem); TV: rovnou na on-screen klávesách (šipky + OK)
            if uc.device_mode() in ("pc", "touch"):
                uc.focus_first(self, [_FIELD, _KEYS])
            else:
                uc.focus_first(self, [_KEYS, _FIELD])
        except Exception as exc:
            _log(f"onInit: {exc}", xbmc.LOGWARNING)

    def _build_keys(self) -> None:
        lst = self.getControl(_KEYS)
        for ch in _KEY_ROWS:
            li = xbmcgui.ListItem(ch)
            li.setProperty("rm_key", ch)
            lst.addItem(li)

    # ------------------------------------------------------------------ query
    def _render_query(self) -> None:
        self.setProperty("rm_s_query", self._q)
        self.setProperty("rm_s_empty", "" if self._q else "1")

    def _edit(self, ch=None, *, backspace=False, clear=False) -> None:
        if clear:
            self._q = ""
        elif backspace:
            self._q = self._q[:-1]
        elif ch:
            self._q += ch
        self._render_query()
        self._schedule_search()

    def _schedule_search(self) -> None:
        """Debounce: každá změna zvedne generaci; vyhledá se až po klidu 600 ms."""
        self._gen += 1
        gen = self._gen
        q = self._q.strip()

        if len(q) < _MIN_CHARS:
            self.setProperty("rm_s_state", "")
            self._show_recent()
            return

        def _worker():
            mon = xbmc.Monitor()
            if mon.waitForAbort(_DEBOUNCE_S):
                return
            if gen != self._gen or self._rm_closed:
                return  # mezitím se psalo dál — tahle generace je mrtvá
            try:
                self.setProperty("rm_s_state", "searching")
            except Exception:
                pass
            try:
                import richmovie_feed
                items = richmovie_feed.get_feed(
                    self._FEED.get(self._kind, "search_all"), q=q)
            except Exception as exc:
                _log(f"feed: {exc}", xbmc.LOGWARNING)
                items = []
            if gen != self._gen or self._rm_closed:
                return  # výsledek staré generace zahodit (guard proti přepsání)
            # Φ6 (audit A07): search telemetrie — track_search_* byl mrtvý kód
            # bez call-sites (user_search_events plnil jen backfill). Superseded
            # pending (uživatel dopsal dotaz) se zahazuje, aby nekazil
            # abandonment metriku; finalizace = klik na výsledek / 60s timeout.
            try:
                import richmovie_telemetry as _tel
                if getattr(self, "_search_cid", ""):
                    _tel.search_pending_discard(self._search_cid)
                self._search_cid = _tel.track_search_initiated(
                    q,
                    category=("tv" if self._kind == "tv"
                              else "movie" if self._kind == "movie" else "other"),
                    results_count=len(items))
            except Exception as _te:
                _log(f"search telemetry: {_te}", xbmc.LOGDEBUG)
            # R2-P2-7: routa nese aktuální dotaz → playback replay obnoví výsledky
            uc.nav_update(getattr(self, "_rm_nav_id", ""),
                          {"kind": self._kind, "q": q})
            self._apply_results(uc.dedup_media(items), header=f"Výsledky: {q}")

        threading.Thread(target=_worker, name="RMSearchDebounce", daemon=False).start()

    # ------------------------------------------------------------------ results
    def _show_recent(self) -> None:
        """Před psaním: naposledy hledané tituly z historie (s postery)."""
        items = []
        try:
            import richmovie_history as hist
            h = hist.load_history() or {}
            cats = {"movie": ("movie",), "tv": ("tv",)}.get(self._kind, ("movie", "tv"))
            for cat in cats:
                for rec in (h.get(cat) or []):
                    if not isinstance(rec, dict) or not rec.get("tmdb_id"):
                        continue
                    items.append({"title": rec.get("title") or rec.get("query") or "",
                                  "tmdb_id": rec.get("tmdb_id"),
                                  "kind": "tv" if cat == "tv" else "movie",
                                  "poster_path": rec.get("poster_path") or "",
                                  "year": rec.get("year") or ""})
        except Exception as exc:
            _log(f"recent: {exc}", xbmc.LOGDEBUG)
        items = uc.dedup_media(items)[:18]
        if not items:
            # Žádná historie → neutrální stav (NE „nic nenalezeno" před psaním).
            self.setProperty("rm_s_state", "")
            self.setProperty("rm_s_header", "")
            try:
                self.getControl(_RESULTS).reset()
            except Exception:
                pass
            return
        self._apply_results(items, header="Naposledy hledané")

    def _apply_results(self, items, header="") -> None:
        if self._rm_closed:
            return
        try:
            import richmovie_history as _hist
            watched_movies = _hist.watched_movie_ids()
        except Exception:
            watched_movies = set()
        try:
            self.setProperty("rm_s_state", "ready" if items else "noresults")
            self.setProperty("rm_s_header", header)
            grid = self.getControl(_RESULTS)
            grid.reset()
            for it in (items or []):
                yr = it.get("year") or ""
                label = f"{it.get('title') or ''}{f' ({yr})' if yr else ''}"
                li = xbmcgui.ListItem(label)
                poster = uc.img(it.get("poster_path"))
                if poster:
                    li.setArt({"poster": poster, "thumb": poster, "icon": poster})
                tmdb = str(it.get("tmdb_id") or "")
                mtype = it.get("kind") or "movie"
                li.setProperty("rm_tmdb", tmdb)
                li.setProperty("rm_mtype", mtype)
                li.setProperty("rm_title", it.get("title") or "")
                li.setProperty("rm_year", str(it.get("year") or ""))
                li.setProperty("rm_poster_raw", it.get("poster_path") or "")
                if mtype == "movie" and tmdb in watched_movies:
                    li.setProperty("rm_watched", "1")
                grid.addItem(li)
            # Po POTVRZENÉM hledání (Enter/klávesnice) skoč na výsledky teď, když
            # už panel má items — uživatel chce rovnou vybírat plakát, ne hledat
            # cestu z klávesnice. Live psaní (on-screen) focus nepřebírá.
            if self._focus_results and items:
                self._focus_results = False
                uc.focus_first(self, [_RESULTS])
        except Exception as exc:
            _log(f"apply: {exc}", xbmc.LOGWARNING)

    # ------------------------------------------------------------------ input
    def onClick(self, controlId: int) -> None:
        try:
            if controlId == 9000:  # ‹ Zpět
                self.close()
            elif controlId == _KEYS:
                li = self.getControl(_KEYS).getSelectedItem()
                if li:
                    self._edit(li.getProperty("rm_key"))
            elif controlId == _KEY_SPACE:
                self._edit(" ")
            elif controlId == _KEY_DEL:
                self._edit(backspace=True)
            elif controlId == _KEY_CLEAR:
                self._edit(clear=True)
            elif controlId == _FIELD:
                self._type_with_keyboard()
            elif controlId == _RESULTS:
                self._open_result()
        except Exception as exc:
            uc.notify_error("Akce se nepodařila.", log_tag="Search")
            _log(f"onClick {controlId}: {exc}", xbmc.LOGWARNING)

    def _type_with_keyboard(self) -> None:
        """Fyzická klávesnice: Kodi NEpouští raw stisky kláves do custom Python
        oken (platformní limit — raw text umí přijímat jen nativní text input).
        ⌨ otevře vstup předvyplněný dotazem; po potvrzení jede live search dál."""
        try:
            kb = xbmc.Keyboard(self._q, self._KB_HEADING.get(self._kind, "Hledat film nebo seriál"))
            kb.doModal()
            if kb.isConfirmed():
                self._q = kb.getText() or ""
                self._render_query()
                # focus na výsledky AŽ když reálně dorazí (_apply_results) —
                # tady ještě neexistují (debounce + fetch) a prázdný panel by
                # focus odmítl → uživatel by zůstal trčet na klávesnici
                self._focus_results = True
                self._schedule_search()
        except Exception as exc:
            _log(f"type: {exc}", xbmc.LOGWARNING)

    def _open_result(self) -> None:
        li = self.getControl(_RESULTS).getSelectedItem()
        if not li or not li.getProperty("rm_tmdb"):
            return
        tmdb = li.getProperty("rm_tmdb")
        mtype = li.getProperty("rm_mtype") or "movie"
        title = li.getProperty("rm_title") or ""
        # Zápis do „Naposledy hledané": vybraný titul se rich metadaty (tmdb_id +
        # poster) → _show_recent ho příště ukáže. Bez tohohle zůstávala historie
        # prázdná (nový search dřív nikam nezapisoval). Best-effort.
        try:
            import richmovie_history as hist
            hist.add_to_history(
                title, category=("tv" if mtype == "tv" else "movie"),
                meta={"tmdb_id": tmdb, "title": title,
                      "year": li.getProperty("rm_year"),
                      "poster_path": li.getProperty("rm_poster_raw")})
        except Exception as exc:
            _log(f"history write: {exc}", xbmc.LOGDEBUG)
        # Φ6: finalizace search telemetrie — klik na výsledek (detail, ne přímý play)
        try:
            if getattr(self, "_search_cid", ""):
                import richmovie_telemetry as _tel
                _tel.track_search_clicked(self._search_cid,
                                          int(tmdb) if tmdb else None,
                                          result_played=False)
                self._search_cid = ""
        except Exception:
            pass
        q = urllib.parse.urlencode({
            "action": "rm_detail", "tmdb_id": tmdb,
            "kind": mtype, "title": title,
        })
        # Detail NAD vyhledáváním (Back → zpět do výsledků, dotaz zůstává)
        xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")

    # Back/Stop/device latch řeší uc.RMNavMixin.onAction (Φ1 DRY).
    # POZN. (výzkum 2026-06-12, Temp/keyboard_research_20260612/): raw znaky
    # fyzické klávesnice se do Python oken NEPŘENÁŠÍ (xbmcgui.Action nemá
    # getUnicode, setFromCAction unicode zahazuje — ověřeno v xbmc zdrojácích).
    # Fyzické psaní = tlačítko ⌨ (nativní vstup, restyle přes skin Φ-K).

    def close(self):  # noqa: A003 — Kodi API jméno
        self._rm_closed = True
        super().close()


def open_search(addon, kind="all", q="") -> None:
    """Otevře custom Search okno. `kind` = all | movie | tv (oddělené hledání).
    `q` = pre-fill dotazu (playback replay, R2-P2-7). Best-effort."""
    try:
        w = RichMovieSearchWindow(_XML, addon.getAddonInfo("path"), "default", _RES,
                                  kind=kind, q=q)
        _nav_id = uc.nav_push("rm_search", {"kind": kind, "q": q})  # Φ1 NavStack
        w._rm_nav_id = _nav_id  # R2-P2-7: okno aktualizuje routu o dotaz
        try:
            w.doModal()
        finally:
            uc.nav_remove(_nav_id)
        w._rm_closed = True
        del w
    except Exception as exc:
        _log(f"open_search: {exc}", xbmc.LOGWARNING)
        try:
            _rm_notif("Vyhledávání se nepodařilo otevřít.", xbmcgui.NOTIFICATION_INFO, 5000, "RichMovie")
        except Exception:
            pass
