# -*- coding: utf-8 -*-
"""
richmovie_playback_end.py — SSOT klasifikace KONCE přehrávání (3.5.119)
=======================================================================

Proč modul existuje (incident Zelňačka 23.08.2026):
    Webshare CDN uzel přestal posílat data → Kodi curl timeout → CFileCache
    `EndOfInput()` → VideoPlayer skončil „přirozeně" → `onPlayBackEnded`.
    Addon měl v tu chvíli DVĚ nezávislá místa, která `onPlayBackEnded` brala
    jako „dokoukáno":
      • service_nextup._save_cw_position(completed=True)  → cw_remove + ✔ watched
      • richmovie_player_hook._finalize(natural_end=True) → drop_point_s=None
    Film označený jako dokoukaný při 40 % a watch event s „přirozeným koncem".
    Navíc každé místo mělo vlastní práh (0.93 vs 0.95).

Kontrakt:
    `onPlayBackEnded` z Kodi NENÍ důkaz dokoukání. Důkaz je POZICE vůči délce.
    Tohle je jediné místo, kde se o tom rozhoduje — service i hook se ptají sem.

Modul je záměrně bez závislosti na Kodi (čistá funkce), aby byl testovatelný
v offline harnessu `_tools/net_resilience_sim` (scénář 26).
"""

from __future__ import annotations

import enum

# Jediný práh dokoukání v celém addonu. Hodnota 0.93 = dosavadní práh
# service_nextup (titulky/credits běžně tvoří posledních ~5-7 % stopáže).
# Hook používal 0.95 — sjednoceno sem, viz plán 3.5.119 Φ5.
COMPLETION_THRESHOLD = 0.93
# Hybrid (cross-check T3 Pro P1, 05.09.2026): poměr sám neškáluje. Tříhodinový film má 7 %
# = 12,6 min (utnutí v 95 % by prošlo jako dokoukání), patnáctiminutový díl 7 % = 63 s
# (stop v dlouhých titulcích = „utnutí"). Proto navíc ABSOLUTNÍ zbytek:
#   NATURAL  ⇔ (poměr ≥ 0.93 a zbývá ≤ TAIL_MAX_S) nebo zbývá ≤ TAIL_MIN_S
TAIL_MAX_S = 600.0     # nad 10 min zbytku není „dokoukáno" ani při 93 % (dlouhé filmy)
TAIL_MIN_S = 90.0      # pod 90 s zbytku je dokoukáno (krátké díly, dlouhé titulky) …
TAIL_MIN_RATIO = 0.5   # … ale jen když je za námi aspoň polovina (Fable P2-3: 2min klip v 25 % ≠ dokoukáno)
VERDICT_PROP = "RichMovie.PlayerCtx.end_verdict"   # sdílený verdikt: "kind|key|epoch"
VERDICT_FRESH_S = 20.0

# Pod touto délkou (s) se o dokoukání nerozhoduje — trailery, omylem spuštěná
# videa, stream bez známé délky. Shodné s dosavadní ochranou `duration < 60`
# v service_nextup._save_cw_position.
MIN_DURATION_S = 60.0


class EndKind(enum.Enum):
    """Jak přehrávání skončilo."""
    NATURAL = "natural"               # Kodi ohlásil konec A pozice ≥ práh
    UNEXPECTED_EOF = "unexpected_eof"  # Kodi ohlásil konec, ale pozice < práh (zdroj utnul stream)
    STOPPED = "stopped"               # uživatel / systém zastavil (onPlayBackStopped)
    UNKNOWN = "unknown"               # délka neznámá nebo příliš krátká — nerozhodnuto


def completion_ratio(position_s, duration_s):
    # type: (float, float) -> float
    """Poměr pozice/délka ořezaný do [0, 1]; 0.0 při neznámé délce."""
    try:
        pos = float(position_s or 0.0)
        dur = float(duration_s or 0.0)
    except (TypeError, ValueError):
        return 0.0
    if dur <= 0.0:
        return 0.0
    return max(0.0, min(1.0, pos / dur))


def is_completed_position(position_s, duration_s, position_lag_s=0.0):
    # type: (float, float, float) -> bool
    """JEDINÉ pravidlo „pozice = dokoukáno" (Fable audit 05.09.2026 P1-1): hybrid poměru
    a zbytku. Používá ho `classify_end` (verdikt) i `is_completed` (služba: ✔ / advance /
    cw_remove) — dřív měla služba vlastní čistě poměrový práh a u 3h filmu utnutého v 93,5 %
    (verdikt UNEXPECTED_EOF) přesto označila ✔ a smazala Pokračovat.

      • zbytek ≤ TAIL_MIN_S a poměr ≥ TAIL_MIN_RATIO → dokoukáno (dlouhé titulky krátkých dílů),
      • poměr ≥ COMPLETION_THRESHOLD a zbytek ≤ TAIL_MAX_S → dokoukáno,
      • jinak ne. Délka < MIN_DURATION_S = nerozhodnuto (False).
    `position_lag_s` = stáří checkpointu (horní odhad pozice po `onPlayBackEnded`)."""
    try:
        dur = float(duration_s or 0.0)
    except (TypeError, ValueError):
        return False
    if dur < MIN_DURATION_S:
        return False
    try:
        lag = max(0.0, float(position_lag_s or 0.0))
    except (TypeError, ValueError):
        lag = 0.0
    try:
        pos = float(position_s or 0.0)
    except (TypeError, ValueError):
        pos = 0.0
    remaining = dur - (pos + lag)
    ratio = completion_ratio(pos + lag, dur)
    if remaining <= TAIL_MIN_S and ratio >= TAIL_MIN_RATIO:
        return True
    return ratio >= COMPLETION_THRESHOLD and remaining <= TAIL_MAX_S


def is_completed(position_s, duration_s):
    # type: (float, float) -> bool
    """True = titul se počítá za dokoukaný — deleguje na `is_completed_position` (SSOT)."""
    return is_completed_position(position_s, duration_s, 0.0)


def classify_end(*, kodi_ended, position_s, duration_s, position_lag_s=0.0):
    # type: (bool, float, float, float) -> EndKind
    """Klasifikuje konec přehrávání.

    Args:
        kodi_ended: True = přišel `onPlayBackEnded` (Kodi tvrdí konec souboru),
                    False = `onPlayBackStopped` (stop uživatelem/systémem).
        position_s: poslední známá pozice (s).
        duration_s: celková délka (s); 0/None = neznámá.
        position_lag_s: stáří checkpointu pozice (s). Po `onPlayBackEnded` už
                    přehrávač nežije, pozice je z periodického checkpointu a
                    skutečná pozice utnutí je o ≤ lag VYŠŠÍ. Horní odhad
                    `position + lag` brání tomu, aby EOF těsně nad prahem (film
                    skončil 3 s po 93 %) byl kvůli starému checkpointu brán
                    jako utnutí (cross-check Pro Q3, 23.08.2026). Volající ho
                    počítá z reálného času zápisu checkpointu, ne z intervalu.
    """
    try:
        dur = float(duration_s or 0.0)
    except (TypeError, ValueError):
        dur = 0.0

    if not kodi_ended:
        return EndKind.STOPPED

    if dur < MIN_DURATION_S:
        # Bez věrohodné délky nelze rozlišit dokoukání od utnutí. Nerozhodnuto —
        # volající NESMÍ označit ✔ ani spouštět auto-resume.
        return EndKind.UNKNOWN

    if is_completed_position(position_s, dur, position_lag_s):
        return EndKind.NATURAL
    return EndKind.UNEXPECTED_EOF


def classify_end_shared(key, **kwargs):
    # type: (str, ...) -> EndKind
    """SSOT verdiktu napříč oběma Player subclassy (cross-check T3 Pro P2): kdo klasifikuje
    první, zveřejní verdikt do Window property; druhý (jiný checkpoint, jiný lag) ho pro
    stejný `key` (tmdb:s:e) a čerstvost ≤ VERDICT_FRESH_S převezme místo vlastního výpočtu.
    Bez klíče nebo mimo Kodi = obyčejný `classify_end`."""
    try:
        import richmovie_winprops as _wp
        import time as _time
        raw = _wp.get_prop(VERDICT_PROP, "") if key else ""
        if raw:
            parts = raw.split("|")
            if len(parts) == 3 and parts[1] == key:
                try:
                    if _time.time() - float(parts[2]) <= VERDICT_FRESH_S:
                        return EndKind(parts[0])
                except (TypeError, ValueError):
                    pass
        kind = classify_end(**kwargs)
        if key:
            _wp.set_prop(VERDICT_PROP, "%s|%s|%.3f" % (kind.value, key, _time.time()))
        return kind
    except Exception:
        return classify_end(**kwargs)


def ctx_key(ctx):
    # type: (dict) -> str
    """Klíč titulu z kontextu přehrávání (`_read_player_context`): 'tv:id:s:e' / 'movie:id:0:0' / ''.
    Čisté; 3.5.151 (Fable F2) ho hook potřebuje i pro UZAVŘENÝ segment, jehož props už přepsal další stream."""
    try:
        tmdb = int((ctx or {}).get("tmdb_id") or 0)
        if tmdb <= 0:
            return ""
        if ctx.get("kind") == "tv":
            return "tv:%d:%d:%d" % (tmdb, int(ctx.get("season") or 0), int(ctx.get("episode") or 0))
        return "movie:%d:0:0" % tmdb
    except Exception:
        return ""


def player_ctx_key():
    # type: () -> str
    """Klíč aktuálního titulu z PlayerCtx props (`plugin._play`): 'tv:id:s:e' / 'movie:id:0:0' / ''.
    Stejný formát jako klíče stavu (`richmovie_state_sync`), jedna funkce (Fable P3-5)."""
    try:
        import richmovie_player_hook as _ph
        return ctx_key(_ph._read_player_context())
    except Exception:
        return ""
