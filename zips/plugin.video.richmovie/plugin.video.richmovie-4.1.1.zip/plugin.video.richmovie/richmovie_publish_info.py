# -*- coding: utf-8 -*-
"""RichMovie — „Richie aktualizoval DD.MM.RRRR“ / „DEV (nepublikováno)“ v titulku hlavního menu (Φ3, 29.09.2026).

PROČ EXISTUJE (audit A07 F4, F13 — `Temp/ux_latency_20260929/`)
---------------------------------------------------------------
Do 3.5.161 se datum poslední publikace zjišťovalo v `plugin._root` — na UI cestě menu: GitHub Commits
API + `addons.xml` z raw CDN, `urlopen` bez retry, 0,8–10 s navíc, kdykoli vypršela 6h cache. Cache
žila ve skrytých nastaveních (`_gh_check_ts` …), která zapisovaly SOUBĚŽNÉ rooty (Kodi spouští root při
startu 2×) → `SETTINGS_WRITE_LOST key=_gh_check_ts` a pád Kodi 19.09. 19:41 v témže okně.

KONTRAKT
--------
    cached(local_version)            # root: (datum, vzdálená verze) jen ze souboru, 0 sítě
    next_due_in(local_version)       # služba: za kolik sekund má smysl `refresh_if_due`
    refresh_if_due(local_version)    # služba (vlákno): síť nejvýš 1× za REFRESH_INTERVAL_S

Síť jde přes SSOT `richmovie_http` (profil background — nikdo na obrazovce nečeká). Stav je vlastní
JSON v kořeni dat (`richmovie_atomic`, jeden zapisovatel = služba), nastavení Kodi se nedotýká.
Selhání se neperzistuje (R2): `checked_at` se zapíše jen po úspěšné odpovědi; po chybě si služba
drží v paměti odklad `RETRY_AFTER_FAILURE_S`.

Python 3.8 (Kodi runtime).
"""
from __future__ import annotations

import datetime
import json
import re
import time
from typing import Any, Dict, Optional, Tuple

COMMITS_URL = ("https://api.github.com/repos/ricardoitaliano/richmovie-repo"
               "/commits?path=kodi/addons.xml&per_page=1")
ADDONS_XML_URL = "https://raw.githubusercontent.com/ricardoitaliano/richmovie-repo/main/kodi/addons.xml"
STATE_FILE = "publish_info.json"

# Beze změny oproti dřívějšímu `_GH_CACHE_TTL`: publikace je nejvýš párkrát za den.
REFRESH_INTERVAL_S = 6 * 3600
# GitHub API bez tokenu = 60 požadavků/h na veřejnou IP, sdílí je celá domácnost (až 8 zařízení
# na účet). 1 pokus za hodinu na zařízení po chybě zůstane hluboko pod limitem.
RETRY_AFTER_FAILURE_S = 3600
# Timeout jednoho dotazu = dřívější `urlopen(timeout=5)`; opakování řídí profil background.
REQUEST_TIMEOUT_S = 5.0

_ADDON_RX = re.compile(r'<addon\s+id="plugin\.video\.richmovie"\s+version="([^"]+)"')
_failure = {"at": 0.0}   # jen v paměti služby (R2: selhání se nezapisuje na disk)


def _log(msg: str, warning: bool = False) -> None:
    try:
        import richmovie_logging as _rl
        lg = _rl.get_logger("richmovie.publish_info")
        (lg.warning if warning else lg.info)(msg)
    except Exception:
        pass


def _state_path() -> str:
    import richmovie_paths
    return str(richmovie_paths.account_path(STATE_FILE))


def _load() -> Dict[str, Any]:
    try:
        import richmovie_atomic
        data, _status = richmovie_atomic.read_json(_state_path(), {}, name=STATE_FILE, expected_type=dict)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def parse_remote_version(xml_text: str) -> str:
    """Verze RichMovie z `addons.xml` repozitáře ("" = nenalezeno). Čistá."""
    m = _ADDON_RX.search(xml_text or "")
    return m.group(1) if m else ""


def parse_commit_date(payload: Any) -> str:
    """Datum posledního commitu `addons.xml` z Commits API jako DD.MM.RRRR ("" = neplatná odpověď)."""
    try:
        iso = payload[0]["commit"]["committer"]["date"]
        dt = datetime.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        return dt.strftime("%d.%m.%Y")
    except Exception:
        return ""


def cached(local_version: str) -> Tuple[str, str]:
    """(datum, vzdálená verze) pro titulek menu. Stav z jiné verze addonu se nepoužije (po
    aktualizaci by titulek lhal „DEV“) — služba ho obnoví hned po startu (`next_due_in` = 0)."""
    st = _load()
    if str(st.get("local_version") or "") != str(local_version or ""):
        return "", ""
    return str(st.get("date") or ""), str(st.get("remote_version") or "")


def next_due_in(local_version: str, now: Optional[float] = None) -> float:
    """Za kolik sekund je obnova na řadě (0 = hned). Zohlední odklad po chybě v paměti."""
    now = time.time() if now is None else float(now)
    st = _load()
    if str(st.get("local_version") or "") != str(local_version or ""):
        due_at = 0.0
    else:
        due_at = float(st.get("checked_at") or 0.0) + REFRESH_INTERVAL_S
    if _failure["at"]:
        due_at = max(due_at, float(_failure["at"]) + RETRY_AFTER_FAILURE_S)
    return max(0.0, due_at - now)


def refresh_if_due(local_version: str, now: Optional[float] = None) -> bool:
    """Síťová obnova (služba, vlákno). True = stav zapsán. Nikdy nevyhazuje."""
    now = time.time() if now is None else float(now)
    if next_due_in(local_version, now) > 0:
        return False
    import richmovie_atomic
    import richmovie_http as _http
    st = _load()
    new = dict(st)
    headers = {"User-Agent": "plugin.video.richmovie"}
    profile = _http.profile_background().replace(timeout_s=REQUEST_TIMEOUT_S)
    try:
        if st.get("last_modified") and str(st.get("local_version") or "") == str(local_version or ""):
            headers["If-Modified-Since"] = str(st["last_modified"])
        status, body, resp_headers = _http.request(COMMITS_URL, headers=headers, profile=profile, tag="github")
        if status == 200:
            date = parse_commit_date(json.loads(body.decode("utf-8")))
            if not date:
                raise ValueError("commits: odpověď bez data")
            new["date"] = date
            new["last_modified"] = (resp_headers.get("Last-Modified", "") if resp_headers else "") or ""
        elif status != 304:
            raise ValueError("commits: HTTP %d" % status)
        status2, body2, _h2 = _http.request(ADDONS_XML_URL, headers={"User-Agent": "plugin.video.richmovie"},
                                            profile=profile, tag="github")
        if status2 != 200:
            raise ValueError("addons.xml: HTTP %d" % status2)
        remote = parse_remote_version(body2.decode("utf-8", "replace"))
        if not remote:
            raise ValueError("addons.xml: verze RichMovie nenalezena")
        new["remote_version"] = remote
    except Exception as exc:
        _failure["at"] = now
        _log("publish info: obnova selhala (%r) → další pokus za %d s" % (exc, RETRY_AFTER_FAILURE_S), warning=True)
        return False
    new["checked_at"] = now
    new["local_version"] = str(local_version or "")
    if not richmovie_atomic.write_json(_state_path(), new):
        _failure["at"] = now
        return False
    _failure["at"] = 0.0
    _log("publish info: %s · remote %s" % (new.get("date"), new.get("remote_version")))
    return True
