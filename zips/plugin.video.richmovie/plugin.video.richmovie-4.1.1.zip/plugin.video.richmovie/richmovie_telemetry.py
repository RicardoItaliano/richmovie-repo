# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_telemetry.py
# Addon-side rich event telemetry — local buffer + atomic batch sync to Gate.
# Phase A3 (RichMovie 3.1.0) — AI Personalized Recommendations feature.
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie 3.1.0 — Addon-side telemetry buffer

Captures rich psychology signals from `richmovie_player_hook.RichMoviePlayer`
(watch events) and search history additions, persists them to a local atomic
JSON buffer, and flushes them to the Gate `/v1/ai/recommendations/events_batch`
endpoint at three points:

    1. On addon startup (background thread, fire-and-forget)
    2. Periodic during runtime (every 5 minutes via service_warm)
    3. On Kodi shutdown (final attempt, 10s timeout)

Buffer is DURABLE on disk. If Gate is unreachable, events accumulate locally;
next successful flush drains them. Bounded at 5000 events (oldest dropped to
prevent unbounded growth on long-term offline use).

Per-event idempotency: each event carries a `client_event_id` (UUID4) so that
re-flushing the same event after partial-success Gate response is safe (Gate
INSERT uses ON CONFLICT DO NOTHING on (user_id, client_event_id)).

API:
    enqueue_watch_event(payload: dict) -> None
    enqueue_search_event(payload: dict) -> None
    flush_to_gate(timeout: float = 30.0) -> int       # returns events drained
    pending_count() -> (int, int)
    quarantine_watch_event(payload, reason=...)       # 3.5.119: Gate-rejectable event
    quarantine_count() -> int

Module is process-safe via threading.Lock. The buffer file is written
atomically via os.replace() — never observed in a torn state.

Design rationale:
    - Per-event POST would be lossy if Kodi crashes between event and HTTP.
    - Periodic batch + atomic file gives crash-safety + fewer HTTP roundtrips.
    - 5000 cap with FIFO drop is bounded — avoids unbounded growth + worst-case
      data loss is "oldest 1 events when buffer full and Gate offline >X days".

Author: Richie (autonomous Phase A3 implementation 2026-04-25)
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import os
import richmovie_atomic as _rm_atomic
import threading
import time
import uuid
from pathlib import Path
from typing import Any

import xbmc
import xbmcaddon
import xbmcvfs

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

_MAX_EVENTS = 5000          # FIFO drop oldest beyond this
_BUFFER_FILE = "pending_events.json"
_GATE_TIMEOUT_DEFAULT = 30.0
_LOG_PREFIX = "[RichMovie.telemetry]"

# DVĚ různé verze schématu — NEZAMĚŇOVAT (smoke test 23.08.2026 to chytil):
#   • _WIRE_SCHEMA_VERSION = verze těla požadavku na Gate. Gate `EventsBatchIn`
#     přijímá JEN 1 / "1" / "v1" a cokoli jiného odmítá 422 na celý batch.
#   • _BUFFER_SCHEMA_VERSION = formát lokálního souboru pending_events.json.
#     v2 (3.5.119): přidán klíč `quarantine_events` — eventy, které Gate
#     autoritativně odmítl (validace / insert) nebo které by odmítl (runtime 0).
#     Dřív takový event zůstal na čele fronty a blokoval VŠECHNY další
#     (http_422 na celý batch, 15 dní mrtvá telemetrie na Richie-Home).
_WIRE_SCHEMA_VERSION = 1
_BUFFER_SCHEMA_VERSION = 2

# Karanténa je diagnostický archiv, ne fronta — vlastní menší strop (FIFO).
_MAX_QUARANTINE = 500

# Délka textových detailů v karanténě / logu (user_logs řádek je omezený; víc
# než tohle je šum, celé tělo je v Gate logu).
_DETAIL_MAX_CHARS = 200

# Klíče bufferu (jediné místo, kde jsou vypsané).
_K_WATCH = "watch_events"
_K_SEARCH = "search_events"
_K_QUARANTINE = "quarantine_events"
_K_STUCK = "stuck"                      # {"head": client_event_id, "since": epoch} — hlava fronty, která opakovaně selhává na 5xx
_STUCK_QUARANTINE_AFTER_S = 3 * 86400   # cross-check T2 Pro P6: „poison pill" na 500 → po 3 dnech karanténa hlavy
_STUCK_MIN_ATTEMPTS = 5                 # Fable P2-1: a zároveň ≥ 5 po sobě jdoucích 500 na TÉŽE hlavě (kalendář sám nestačí)

# Důvody karantény, které vznikají na straně addonu (Gate kódy se přebírají
# z odpovědi beze změny: `validation_failed`, `insert_failed`).
REASON_RUNTIME_UNKNOWN = "runtime_unknown"
REASON_BATCH_REJECTED_UNMAPPED = "batch_rejected_unmapped"


# ─────────────────────────────────────────────────────────────────────────────
#  MODULE STATE — LAZY INIT
# ─────────────────────────────────────────────────────────────────────────────

_lock = threading.Lock()
_addon: xbmcaddon.Addon | None = None
_profile_dir: Path | None = None
_buffer_path: Path | None = None


def _get_addon() -> xbmcaddon.Addon:
    global _addon
    if _addon is None:
        _addon = xbmcaddon.Addon()
    return _addon


def _get_profile_dir() -> Path:
    global _profile_dir
    if _profile_dir is None:
        addon_id = _get_addon().getAddonInfo("id")
        _profile_dir = Path(
            xbmcvfs.translatePath(f"special://profile/addon_data/{addon_id}")
        )
        _profile_dir.mkdir(parents=True, exist_ok=True)
    return _profile_dir


def _get_buffer_path() -> Path:
    global _buffer_path
    if _buffer_path is None:
        _buffer_path = _get_profile_dir() / _BUFFER_FILE
    return _buffer_path


# ─────────────────────────────────────────────────────────────────────────────
#  ATOMIC FILE I/O
# ─────────────────────────────────────────────────────────────────────────────

def _load_buffer() -> dict[str, Any]:
    """Read buffer file. Returns empty buffer on corruption (best-effort)."""
    path = _get_buffer_path()
    if not path.exists():
        return _empty_buffer()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict) or _K_WATCH not in data:
            xbmc.log(f"{_LOG_PREFIX} buffer schema invalid, reset", xbmc.LOGWARNING)
            return _empty_buffer()
        return _migrate_buffer(data)
    except (json.JSONDecodeError, OSError) as exc:
        xbmc.log(f"{_LOG_PREFIX} buffer read fail: {exc!r} — reset", xbmc.LOGWARNING)
        return _empty_buffer()


def _migrate_buffer(data: dict[str, Any]) -> dict[str, Any]:
    """Idempotentní migrace v1 → v2: doplní chybějící klíče, nic nezahazuje.

    Starší buffer (bez `quarantine_events`) je plně validní v1; v2 ho jen
    rozšiřuje. Schema version se zvedne až při dalším uložení.
    """
    if not isinstance(data.get(_K_SEARCH), list):
        data[_K_SEARCH] = []
    if not isinstance(data.get(_K_QUARANTINE), list):
        data[_K_QUARANTINE] = []
    data["schema_version"] = _BUFFER_SCHEMA_VERSION
    return data


def _empty_buffer() -> dict[str, Any]:
    return {
        "schema_version": _BUFFER_SCHEMA_VERSION,
        _K_WATCH: [],
        _K_SEARCH: [],
        _K_QUARANTINE: [],
    }


def _save_buffer(data: dict[str, Any]) -> None:
    """Trvanlivý atomický zápis přes SSOT `richmovie_atomic` (3.5.123). Tenhle
    modul měl fsync už od B#8 (feedback_kodi_shutdown_window) — teď je to jedna
    implementace pro celý doplněk místo jediné správné výjimky."""
    import richmovie_atomic as _atomic
    if not _atomic.write_json(str(_get_buffer_path()), data, separators=(",", ":")):
        xbmc.log(f"{_LOG_PREFIX} buffer write fail", xbmc.LOGERROR)


def _trim_to_max(events: list[dict], cap: int = _MAX_EVENTS,
                 label: str = "buffer") -> list[dict]:
    """FIFO drop oldest if over cap."""
    if len(events) <= cap:
        return events
    dropped = len(events) - cap
    xbmc.log(
        f"{_LOG_PREFIX} {label} cap exceeded — dropping oldest {dropped} events",
        xbmc.LOGWARNING,
    )
    return events[-cap:]


# ─────────────────────────────────────────────────────────────────────────────
#  QUARANTINE — eventy, které fronta NESMÍ držet (3.5.119, B1)
# ─────────────────────────────────────────────────────────────────────────────
# Pravidlo: do karantény jde JEN event, který zdroj pravdy (Gate) autoritativně
# odmítl (validation_failed / insert_failed v `errors[]`, Pydantic 422 s `loc`),
# nebo který by odmítl s jistotou (runtime 0 — Gate gt=0 + DB CHECK).
# Transport, 5xx, 429, 401/403 karanténu NIKDY nevytvářejí — buffer se zachová
# a příští flush to zkusí znovu (paralela k R2 pravidlu „selhání se neperzistuje").

def _quarantine_record(event: dict[str, Any], reason: str,
                       detail: str | None = None) -> dict[str, Any]:
    return {
        "reason": reason,
        "detail": (detail or "")[:_DETAIL_MAX_CHARS] or None,
        "quarantined_at": int(time.time()),
        "event": event,
    }


def quarantine_watch_event(payload: dict[str, Any], *, reason: str,
                           detail: str | None = None) -> None:
    """Uloží event do karantény místo fronty (producent ví, že Gate ho odmítne)."""
    payload = _ensure_client_event_id(payload)
    with _lock, _PendingSearchFileLock(_get_buffer_path()):
        buf = _load_buffer()
        buf[_K_QUARANTINE].append(_quarantine_record(payload, reason, detail))
        buf[_K_QUARANTINE] = _trim_to_max(buf[_K_QUARANTINE], _MAX_QUARANTINE, "quarantine")
        _save_buffer(buf)


def _move_to_quarantine(buf: dict[str, Any], key: str, ids: dict[str, tuple[str, str | None]]) -> int:
    """Přesune eventy z fronty `key` do karantény podle client_event_id.

    `ids`: client_event_id → (reason, detail). Volá se POD zámkem. Vrací počet
    přesunutých. Event bez client_event_id přesunout nelze (nemá identitu) —
    takový v bufferu nevzniká (`_ensure_client_event_id`).
    """
    moved = 0
    keep: list[dict] = []
    for ev in buf.get(key, []):
        cid = ev.get("client_event_id")
        if cid and cid in ids:
            reason, detail = ids[cid]
            buf[_K_QUARANTINE].append(_quarantine_record(ev, reason, detail))
            moved += 1
        else:
            keep.append(ev)
    buf[key] = keep
    if moved:
        buf[_K_QUARANTINE] = _trim_to_max(buf[_K_QUARANTINE], _MAX_QUARANTINE, "quarantine")
    return moved


def quarantine_count() -> int:
    with _lock:
        return len(_load_buffer()[_K_QUARANTINE])


# ─────────────────────────────────────────────────────────────────────────────
#  PUBLIC API — ENQUEUE
# ─────────────────────────────────────────────────────────────────────────────

def _ensure_client_event_id(payload: dict[str, Any]) -> dict[str, Any]:
    """Each event must carry a stable UUID for idempotent dedup at Gate."""
    if not payload.get("client_event_id"):
        payload = dict(payload)  # don't mutate caller's dict
        payload["client_event_id"] = uuid.uuid4().hex
    return payload


def enqueue_watch_event(payload: dict[str, Any]) -> None:
    """Add a watch event to the local buffer.

    Payload schema: see Handoff/session_2026-04-25_ai_personalized_recommendations.md
    Section 6.2.1 watch_history_json. `richmovie_player_hook` is the primary
    producer.
    """
    payload = _ensure_client_event_id(payload)
    with _lock, _PendingSearchFileLock(_get_buffer_path()):
        buf = _load_buffer()
        buf[_K_WATCH].append(payload)
        buf[_K_WATCH] = _trim_to_max(buf[_K_WATCH])
        _save_buffer(buf)


def enqueue_search_event(payload: dict[str, Any]) -> None:
    """Add a search event (with click telemetry / abandonment) to buffer."""
    payload = _ensure_client_event_id(payload)
    with _lock, _PendingSearchFileLock(_get_buffer_path()):
        buf = _load_buffer()
        buf[_K_SEARCH].append(payload)
        buf[_K_SEARCH] = _trim_to_max(buf[_K_SEARCH])
        _save_buffer(buf)


def pending_count() -> tuple[int, int]:
    """Return (watch_events_count, search_events_count) currently buffered."""
    with _lock:
        buf = _load_buffer()
        return len(buf[_K_WATCH]), len(buf[_K_SEARCH])


# ─────────────────────────────────────────────────────────────────────────────
#  GATE FLUSH — atomic batch upload
# ─────────────────────────────────────────────────────────────────────────────
# Endpoint: POST /v1/ai/recommendations/events_batch
# Body: {"watch_events": [...], "search_events": [...]}
# Response: {"accepted": N, "duplicates_skipped": M, "errors": [...]}
#
# On 2xx → drain buffer. On non-2xx or transport error → keep buffer, retry
# on next flush. Gate uses ON CONFLICT DO NOTHING on client_event_id, so
# re-flushing the same events is safe (duplicates_skipped reports them).
# ─────────────────────────────────────────────────────────────────────────────

def _gate_post_events(
    watch_events: list[dict],
    search_events: list[dict],
    timeout: float,
) -> tuple[bool, dict[str, Any]]:
    """POST events to Gate. Returns (success, response_or_error_dict).

    Při non-2xx je v error dictu i `status`, aby `flush_to_gate` mohl odlišit
    autoritativní odmítnutí (422 validace) od přechodného selhání (5xx, 429…).
    """
    try:
        # Lazy import — richmovie_gate_transport carries identity + urllib transport.
        # Loading on every plugin invocation would slow entry-point startup.
        from richmovie_gate_transport import post_json, get_identity, build_common_fields
    except ImportError as exc:
        return False, {"error": "transport_import_fail", "detail": repr(exc)}

    username, _proof = get_identity()
    if not username:
        # No WS identity yet (addon still in onboarding) — cannot send.
        # Buffer remains intact for next attempt.
        return False, {"error": "no_identity"}

    body = {
        "schema_version": _WIRE_SCHEMA_VERSION,
        **build_common_fields(),     # ws_username, ws_proof, addon_version, platform
        _K_WATCH: watch_events,
        _K_SEARCH: search_events,
    }
    try:
        status, parsed = post_json(
            "/v1/ai/recommendations/events_batch",
            body,
            timeout=timeout,
        )
    except Exception as exc:
        # Transport error (DNS, refused, TLS, timeout) — caller retries on next flush
        return False, {"error": "gate_transport_fail", "detail": repr(exc)}

    if status < 200 or status >= 300:
        return False, {"error": f"http_{status}", "status": int(status), "body": parsed}

    if not isinstance(parsed, dict):
        return False, {"error": "gate_response_not_dict",
                       "detail": repr(parsed)[:_DETAIL_MAX_CHARS]}

    return True, parsed


# HTTP 422 = FastAPI/Pydantic validace těla. Je to AUTORITATIVNÍ odmítnutí
# (Gate request přečetl a řekl „tohle nikdy nepřijmu"), ne výpadek — opakovat
# stejný batch je zbytečné a blokuje všechny ostatní eventy.
_HTTP_UNPROCESSABLE = 422

def _empty_rejected() -> dict[str, dict[str, tuple[str, str | None]]]:
    """Mapa odmítnutých eventů: {klíč_fronty: {client_event_id: (reason, detail)}}."""
    return {_K_WATCH: {}, _K_SEARCH: {}}


def _map_422_to_event_ids(
    body: Any,
    watch: list[dict],
    search: list[dict],
) -> dict[str, dict[str, tuple[str, str | None]]]:
    """Z Pydantic `detail[].loc` (['body', 'watch_events', i, 'field']) určí
    client_event_id odmítnutých eventů. Prázdný výsledek = nelze namapovat
    (jiný tvar chyby — např. chybí celé pole)."""
    out = _empty_rejected()
    if not isinstance(body, dict):
        return out
    detail = body.get("detail")
    if not isinstance(detail, list):
        return out
    lists = {_K_WATCH: watch, _K_SEARCH: search}
    for item in detail:
        if not isinstance(item, dict):
            continue
        loc = item.get("loc")
        if not isinstance(loc, (list, tuple)) or len(loc) < 3:
            continue
        key = loc[1]
        idx = loc[2]
        if isinstance(idx, str) and idx.isdigit():
            idx = int(idx)   # defenzivně: Pydantic posílá int, jiný validátor může str
        if key not in lists or isinstance(idx, bool) or not isinstance(idx, int):
            continue
        events = lists[key]
        if not 0 <= idx < len(events):
            continue
        cid = events[idx].get("client_event_id")
        if not cid:
            continue
        field = ".".join(str(x) for x in loc[3:]) or "?"
        msg = str(item.get("msg") or item.get("type") or "")
        out[key][cid] = ("validation_failed", f"{field}: {msg}")
    return out


def _map_gate_errors(errors: list[Any]) -> dict[str, dict[str, tuple[str, str | None]]]:
    """Z `errors[]` odpovědi 2xx sestaví mapu odmítnutých eventů per fronta."""
    out = _empty_rejected()
    for err in errors:
        if not isinstance(err, dict):
            continue
        cid = err.get("client_event_id")
        if not cid:
            continue
        key = _K_SEARCH if err.get("kind") == "search" else _K_WATCH
        out[key][cid] = (str(err.get("error") or "gate_error"), err.get("detail"))
    return out


def flush_to_gate(timeout: float = _GATE_TIMEOUT_DEFAULT) -> int:
    """Flush s ohraničeným opakováním po 422 (viz `_flush_once`).

    Každé kolo, které pokračuje, přesunulo ≥ 1 event z odeslaného snapshotu do
    karantény → fronta monotónně klesá; strop kol = velikost prvního snapshotu
    (deterministický z reálných dat, ne magická konstanta). Dřív rekurze —
    cross-check Flash 23.08.2026: 5000 jednotlivě padajících eventů = RecursionError.
    """
    rounds_left = None
    while True:
        outcome = _flush_once(timeout)
        if not isinstance(outcome, _RetryNow):
            # `_RetryNow` kolo nikdy nic nepřijme (422 = Gate neuložil nic),
            # takže součet accepted = výsledek posledního (ne-422) kola.
            # (Pro kolo 2 #5: dřívější akumulátor byl vestigiální — vždy 0.)
            return int(outcome)
        if rounds_left is None:
            rounds_left = outcome.snapshot_size
        rounds_left -= 1
        if rounds_left < 0:
            xbmc.log(f"{_LOG_PREFIX} flush: round cap reached, deferring to next tick",
                     xbmc.LOGWARNING)
            return 0


class _RetryNow:
    """Signál z `_flush_once`: 422 odblokovalo frontu, zbytek poslat hned."""
    __slots__ = ("snapshot_size",)

    def __init__(self, snapshot_size: int) -> None:
        self.snapshot_size = snapshot_size


def _clear_stuck_head() -> None:
    """Jakýkoli výsledek, který NENÍ 500 (úspěch, transport, 429, edge 5xx), přeruší sérii —
    „poison pill" je jen SOUVISLÉ selhávání aplikace Gate na téže hlavě (Fable P2-1)."""
    with _lock, _PendingSearchFileLock(_get_buffer_path()):
        buf = _load_buffer()
        if buf.get(_K_STUCK):
            buf[_K_STUCK] = {}
            _save_buffer(buf)


def _note_stuck_head(watch: list, search: list, status: int) -> None:
    """HTTP 500 (aplikace Gate spadla na tomto těle) na téže hlavě fronty
    ≥ `_STUCK_MIN_ATTEMPTS` po sobě A déle než `_STUCK_QUARANTINE_AFTER_S` = pravděpodobná
    „poison pill" → hlava jde do karantény, fronta se odblokuje (R2b: data se neztrácí).
    Transport (0), 429, 401/403 i edge 502/503/504 (Cloudflare, restart Gate) NEJSOU chyba
    položky — sérii nulují (Fable P2-1: dřív stačila dvě 502 tři dny od sebe).
    Volá se po neúspěšném flushi, pod zámkem."""
    if status != 500:
        _clear_stuck_head()
        return
    head = None
    key = _K_WATCH
    if watch:
        head = watch[0].get("client_event_id")
    elif search:
        head, key = search[0].get("client_event_id"), _K_SEARCH
    if not head:
        return
    with _lock, _PendingSearchFileLock(_get_buffer_path()):
        buf = _load_buffer()
        stuck = buf.get(_K_STUCK) or {}
        now = time.time()
        if stuck.get("head") != head:
            buf[_K_STUCK] = {"head": head, "since": now, "attempts": 1}
            _save_buffer(buf)
            return
        attempts = int(stuck.get("attempts") or 0) + 1
        stuck["attempts"] = attempts
        buf[_K_STUCK] = stuck
        if attempts < _STUCK_MIN_ATTEMPTS or now - float(stuck.get("since") or now) < _STUCK_QUARANTINE_AFTER_S:
            _save_buffer(buf)
            return
        moved = _move_to_quarantine(buf, key, {head: ("stuck_500_%dx_%dd" % (attempts, _STUCK_QUARANTINE_AFTER_S // 86400),
                                                    "status %d" % status)})
        buf[_K_STUCK] = {}
        _save_buffer(buf)
        xbmc.log(f"{_LOG_PREFIX} head event {head} failed on HTTP 500 {attempts}x over 3 days → quarantined ({moved})",
                 xbmc.LOGERROR)


def _flush_once(timeout: float) -> "int | _RetryNow":
    """Atomic flush attempt. Returns count of events successfully accepted by Gate.

    Klasifikace výsledku (3.5.119, B1):
      • transport / 5xx / 429 / 401-403 / neznámé 4xx → buffer beze změny,
        příští flush to zkusí znovu (Gate dedupuje přes client_event_id).
      • 422 (validace těla) → eventy identifikované v `detail[].loc` jdou do
        karantény, zbytek zůstává ve frontě a flushne se HNED v témže volání.
        Když `loc` nelze namapovat, do karantény jde celý odeslaný snapshot
        (reason `batch_rejected_unmapped`) — data se neztrácí, fronta se odblokuje.
      • 2xx → odeslané eventy se z fronty odstraní; ty v `errors[]` (Gate je
        autoritativně odmítl) se místo smazání přesunou do karantény.

    Thread-safe via _lock — only one flush at a time per snapshot.
    """
    # Σ-audit Φ3.16: snapshot POD zámkem, ale HTTP POST běží MIMO zámek. Dříve se
    # _lock držel celých ~30 s POSTu → blokoval enqueue() dalších watch eventů.
    with _lock:
        buf = _load_buffer()
        watch = list(buf.get(_K_WATCH, []))
        search = list(buf.get(_K_SEARCH, []))

    if not watch and not search:
        return 0

    total = len(watch) + len(search)
    xbmc.log(
        f"{_LOG_PREFIX} flushing {len(watch)} watch + {len(search)} search "
        f"events ({total} total)",
        xbmc.LOGINFO,
    )

    # Network POST bez drženého zámku — enqueue() může souběžně přidávat eventy.
    ok, resp = _gate_post_events(watch, search, timeout)
    if not ok:
        if resp.get("status") == _HTTP_UNPROCESSABLE:
            return _handle_unprocessable(resp.get("body"), watch, search)
        xbmc.log(
            f"{_LOG_PREFIX} flush failed: {resp} — buffer preserved",
            xbmc.LOGWARNING,
        )
        _note_stuck_head(watch, search, int(resp.get("status") or 0))
        return 0

    if "accepted" not in resp:
        # B#2 (Fable audit): gate_transport non-JSON tělo převádí na wrapper
        # dict a non-dict na {} → 2xx bez tvaru EventsBatchOut dřív prošlo do
        # mazací fáze a smazalo frontu, ač Gate možná nic neuložil (proxy/edge
        # anomálie). Bez kontraktního potvrzení se NEMAŽE nic.
        xbmc.log(
            f"{_LOG_PREFIX} flush got 2xx without contract body — buffer "
            f"preserved: {repr(resp)[:_DETAIL_MAX_CHARS]}",
            xbmc.LOGWARNING,
        )
        return 0

    accepted = int(resp.get("accepted", 0))
    skipped = int(resp.get("duplicates_skipped", 0))
    errors = resp.get("errors") or []
    _clear_stuck_head()   # úspěšný flush = série 500 přerušena (Fable P2-1)

    rejected = _map_gate_errors(errors) if errors else _empty_rejected()
    if errors:
        xbmc.log(
            f"{_LOG_PREFIX} Gate reported {len(errors)} per-event errors: "
            f"{errors[:3]}{'...' if len(errors) > 3 else ''}",
            xbmc.LOGWARNING,
        )

    # Σ-audit Φ3.16: odstraň POUZE odflushnuté eventy (podle client_event_id),
    # NE _empty_buffer() — ten by zahodil i eventy zařazené BĚHEM POSTu. Žádný
    # event se neztratí; Gate navíc dedupuje přes client_event_id, takže i kdyby
    # se odflushnutý event omylem ponechal, re-flush je bezpečný.
    flushed_w = {e.get("client_event_id") for e in watch if e.get("client_event_id")}
    flushed_s = {e.get("client_event_id") for e in search if e.get("client_event_id")}
    quarantined = 0
    with _lock, _PendingSearchFileLock(_get_buffer_path()):
        cur = _load_buffer()
        # Nejdřív karanténa (odmítnuté eventy musí zůstat dohledatelné)…
        quarantined += _move_to_quarantine(cur, _K_WATCH, rejected[_K_WATCH])
        quarantined += _move_to_quarantine(cur, _K_SEARCH, rejected[_K_SEARCH])
        # …pak smazání úspěšně doručených.
        cur[_K_WATCH] = [
            e for e in cur.get(_K_WATCH, [])
            if e.get("client_event_id") not in flushed_w
        ]
        cur[_K_SEARCH] = [
            e for e in cur.get(_K_SEARCH, [])
            if e.get("client_event_id") not in flushed_s
        ]
        _save_buffer(cur)

    xbmc.log(
        f"{_LOG_PREFIX} flush done: accepted={accepted} skipped={skipped} "
        f"errors={len(errors)} quarantined={quarantined}",
        xbmc.LOGINFO,
    )
    return accepted


def _is_gate_shaped_422(body: Any) -> bool:
    """True = tělo má tvar odpovědi Gate/FastAPI (`{"detail": …}`). Jen takové
    422 je AUTORITATIVNÍ odmítnutí zdroje pravdy. Non-JSON 422 (proxy, HTML)
    převede `gate_transport.post_json` na `{"error": {"code": "http_422"}}` —
    to NENÍ Gate a karanténa z něj vzniknout nesmí (R2; audit 23.08.2026 #1)."""
    return isinstance(body, dict) and "detail" in body


def _is_body_level_422(body: Any) -> bool:
    """True = všechny Pydantic chyby míří MIMO seznamy eventů (schema_version,
    ws_proof, addon_version…). To je chyba kontraktu addon↔Gate, ne eventů —
    karanténa by zahodila validní data. Buffer se zachová a loguje se ERROR."""
    if not isinstance(body, dict) or not isinstance(body.get("detail"), list):
        return False
    items = [d for d in body["detail"] if isinstance(d, dict)]
    if not items:
        return False
    for item in items:
        loc = item.get("loc")
        # Event-level = loc ukazuje NA KONKRÉTNÍ event (má index): délka >= 3.
        # loc == ['body', 'watch_events'] (bez indexu — např. překročený cap
        # batche) je chyba KONTRAKTU, ne eventů → body-level (B#10, Fable
        # audit: karanténa celého 10k snapshotu by přes FIFO 500 ztratila data).
        if isinstance(loc, (list, tuple)) and len(loc) >= 3 and loc[1] in (_K_WATCH, _K_SEARCH):
            return False
    return True


def _handle_unprocessable(body: Any, watch: list[dict],
                          search: list[dict]) -> "int | _RetryNow":
    """422 na celý batch: odblokovat frontu karanténou; vrací `_RetryNow`, když
    má smysl zbytek poslat hned (pokrok = aspoň jeden event přesunut)."""
    rejected = _map_422_to_event_ids(body, watch, search)
    mapped = len(rejected[_K_WATCH]) + len(rejected[_K_SEARCH])
    # VĚDOMÉ ROZHODNUTÍ (Pro kolo 2 #1 zamítnuto): body-level 422 (schema_version,
    # ws_proof…) NECHÁVÁ buffer — je to chyba KONTRAKTU addon↔Gate, ne eventů.
    # Eventy jsou nevinné; karanténa by je vyřadila z pipeline za NAŠI chybu.
    # Fronta se odblokuje opravou kontraktu (update addonu/Gate) a data se pak
    # doručí. ERROR log teče do user_logs → chybu vývoj vidí okamžitě.
    if mapped == 0 and (not _is_gate_shaped_422(body) or _is_body_level_422(body)):
        # (a) 422 bez tvaru Gate (non-JSON → transport wrapper) = není to zdroj
        #     pravdy → žádná karanténa (R2). (b) 422 na úrovni těla (schema_version,
        #     ws_proof…) = chyba kontraktu addon↔Gate, ne eventů. Obojí: buffer
        #     zachován, ERROR do user_logs — musí to vidět vývoj, ne se „vyřešit" ztrátou dat.
        try:
            shown = json.dumps(body, ensure_ascii=False)[:_DETAIL_MAX_CHARS]
        except (TypeError, ValueError):
            shown = repr(body)[:_DETAIL_MAX_CHARS]
        xbmc.log(
            f"{_LOG_PREFIX} flush rejected (422) without per-event cause — "
            f"buffer preserved: {shown}",
            xbmc.LOGERROR,
        )
        return 0
    if mapped == 0:
        # Gate tvar (`detail`), ale indexy nelze namapovat (např. `detail` je
        # string z HTTPException, nebo loc bez indexu) → Gate odmítl tento
        # snapshot autoritativně, jen neřekl který event. Celý snapshot do
        # karantény (data zůstávají); nechat frontu = head-of-line blocking.
        try:
            detail = json.dumps(body, ensure_ascii=False)[:_DETAIL_MAX_CHARS]
        except (TypeError, ValueError):
            detail = repr(body)[:_DETAIL_MAX_CHARS]
        rejected = {
            _K_WATCH: {e["client_event_id"]: (REASON_BATCH_REJECTED_UNMAPPED, detail)
                       for e in watch if e.get("client_event_id")},
            _K_SEARCH: {e["client_event_id"]: (REASON_BATCH_REJECTED_UNMAPPED, detail)
                        for e in search if e.get("client_event_id")},
        }
    with _lock, _PendingSearchFileLock(_get_buffer_path()):
        cur = _load_buffer()
        moved = _move_to_quarantine(cur, _K_WATCH, rejected[_K_WATCH])
        moved += _move_to_quarantine(cur, _K_SEARCH, rejected[_K_SEARCH])
        _save_buffer(cur)
        remaining = len(cur[_K_WATCH]) + len(cur[_K_SEARCH])
    xbmc.log(
        f"{_LOG_PREFIX} flush rejected (422): quarantined={moved} "
        f"mapped={'yes' if mapped else 'no'} remaining={remaining}",
        xbmc.LOGWARNING,
    )
    # Zbytek fronty byl validní a čekal jen kvůli otrávenému prvku — poslat hned,
    # ne za 5 minut. Podmínka POKROKU je `moved > 0` (ne `mapped`): při souběhu
    # (clear_buffer během POSTu) může být mapped>0, ale v bufferu už ty eventy
    # nejsou → bez pokroku se neopakuje (Flash O6, 23.08.2026).
    if mapped and moved and remaining:
        return _RetryNow(snapshot_size=len(watch) + len(search))
    return 0


# ─────────────────────────────────────────────────────────────────────────────
#  BACKGROUND WORKERS (called from service_warm.py)
# ─────────────────────────────────────────────────────────────────────────────

def flush_in_background() -> None:
    """Spawn a flush thread, fire-and-forget. Volá se na startu addonu a NOVĚ
    (2026-05-30) i hned po každém dokončeném přehrávání (player_hook._finalize),
    takže synchronizace na server NEzávisí na zavření/restartu Kodi — kritické,
    protože TV jde do standby a Kodi se prakticky nikdy nezavírá ani nerestartuje.

    daemon=True: ZDE bezpečné (na rozdíl od obecného pravidla
    feedback_daemon_threads_kodi.md). Důvod: watch/search eventy jsou DURABLE na
    disku (pending_events.json) a z bufferu se mažou JEN po potvrzeném 200 z Gate,
    navíc Gate dedupuje podle client_event_id (ON CONFLICT DO NOTHING). Zabití
    daemon vlákna uprostřed HTTP tedy nic neztratí — event zůstane v bufferu a
    příště se znovu odešle (deduplikovaně).
    POZOR (S23, ověřeno ve zdroji Kodi 21.2 `PythonInvoker.cpp:384–406`): `daemon` zavírání Kodi
    NEUSPÍŠÍ — Kodi čeká na všechna vlákna interpretu. Ve službě flush při vypínání ukončí
    `richmovie_http.cancel_all()` (zavře socket → `CancelledError`, event zůstane v bufferu)."""
    t = threading.Thread(target=flush_to_gate, name="RichMovie-telemetry-flush", daemon=True)
    t.start()


def periodic_flush_loop(monitor: xbmc.Monitor, interval_seconds: int = 300) -> None:
    """Run flush every N seconds until Kodi requests abort.

    Designed to be called from `service_warm.py` background loop.
    Each tick: finalize-abandoned-searches → flush events to Gate.
    """
    while not monitor.abortRequested():
        if monitor.waitForAbort(interval_seconds):
            break
        try:
            n_abandoned = finalize_abandoned()
            if n_abandoned:
                xbmc.log(
                    f"{_LOG_PREFIX} periodic: {n_abandoned} abandoned searches finalized",
                    xbmc.LOGINFO,
                )
            flush_to_gate()
        except Exception as exc:  # pragma: no cover — best-effort
            xbmc.log(
                f"{_LOG_PREFIX} periodic flush exception: {exc!r}",
                xbmc.LOGERROR,
            )


def shutdown_flush(timeout: float = 10.0) -> None:
    """Final flush attempt at Kodi shutdown. Bounded so we don't block exit."""
    try:
        finalize_all_abandoned_now()
        flush_to_gate(timeout=timeout)
    except Exception as exc:  # pragma: no cover
        xbmc.log(f"{_LOG_PREFIX} shutdown flush exception: {exc!r}", xbmc.LOGERROR)


# ─────────────────────────────────────────────────────────────────────────────
#  ADMIN UTILITIES
# ─────────────────────────────────────────────────────────────────────────────

def clear_buffer() -> int:
    """Drop all pending events without sending. Returns count dropped.

    Use cases:
        - GDPR "smazat AI history" (Settings → Privacy)
        - User reset / debugging
    """
    with _lock, _PendingSearchFileLock(_get_buffer_path()):
        buf = _load_buffer()
        # GDPR: karanténa obsahuje stejná osobní data jako fronta → maže se také.
        n = len(buf[_K_WATCH]) + len(buf[_K_SEARCH]) + len(buf[_K_QUARANTINE])
        _save_buffer(_empty_buffer())
        xbmc.log(f"{_LOG_PREFIX} buffer cleared: {n} events dropped", xbmc.LOGINFO)
        return n


def buffer_stats() -> dict[str, Any]:
    """Diagnostics for admin/debug UI."""
    w, s = pending_count()
    q = quarantine_count()
    path = _get_buffer_path()
    return {
        "watch_events": w,
        "search_events": s,
        "quarantine_events": q,
        "buffer_path": str(path),
        "buffer_size_bytes": path.stat().st_size if path.exists() else 0,
        "max_events": _MAX_EVENTS,
        "schema_version": _BUFFER_SCHEMA_VERSION,
    }


# ─────────────────────────────────────────────────────────────────────────────
#  SEARCH TRACKING — abandonment + click latency
# ─────────────────────────────────────────────────────────────────────────────
# Pattern (per Section 6.2.1 search_history_json):
#   1. User submits search → track_search_initiated() returns client_event_id
#      and stores pending row in `pending_searches.json`.
#   2a. User clicks a result → track_search_clicked(cid, tmdb_id, played?)
#       finalizes (clicked_at + click_latency_s + abandoned=False) and
#       enqueues to telemetry buffer.
#   2b. User does nothing → finalize_abandoned() (periodic from 5-min loop)
#       finds entries older than 60s, marks abandoned=True, enqueues.
#   3. On addon shutdown / startup: pending searches older than threshold
#      flushed as abandoned (crash-safety).
#
# `pending_searches.json` is independent of `pending_events.json` because
# their lifecycles differ — pending_searches is short-lived ephemeral (60s),
# pending_events is durable (until flush).
# ─────────────────────────────────────────────────────────────────────────────

_PENDING_SEARCH_FILE = "pending_searches.json"
_SEARCH_ABANDON_THRESHOLD_S = 60

_pending_search_lock = threading.Lock()


class _PendingSearchFileLock(_rm_atomic.FileLock):
    """Φ8 (re-audit R3-P2-6): CROSS-PROCESS zámek pro pending_searches.json a
    (B#4, Fable audit) hlavní buffer pending_events.json — zapisují DVA procesy
    (plugin = search eventy a GDPR clear, service = watch eventy a flush);
    per-process `_lock` lost-update mezi procesy nechytí. Implementace = SSOT
    `richmovie_atomic.FileLock` (3.5.134); tady jen výchozí cíl zámku."""

    def __init__(self, lock_target=None):
        super().__init__(str(lock_target or _pending_search_path()) + ".lock")


def _pending_search_path() -> Path:
    # Osobní soubor (profily 3.5.134) — hledání patří tomu, kdo hledal.
    import richmovie_paths
    return richmovie_paths.personal_path(_PENDING_SEARCH_FILE)


def _current_profile_id():
    """profile_id do eventů (None u single/unset/Host). Host se nehlásí vůbec —
    volající kontroluje `richmovie_profile.is_guest()`."""
    try:
        import richmovie_profile
        return richmovie_profile.telemetry_profile_id()
    except Exception:
        return None


def _current_profile_mode():
    """Režim profilů v okamžiku vzniku eventu (S24 D3): Gate přiřadí event bez profilu z doby „Jen já“ majiteli,
    i když z bufferu odejde až po přepnutí účtu na více profilů. None = nečitelné (Gate pak rozhodne podle času)."""
    try:
        import richmovie_profile
        return richmovie_profile.telemetry_profile_mode()
    except Exception:
        return None


def _load_pending_searches() -> list[dict[str, Any]]:
    path = _pending_search_path()
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def _save_pending_searches(items: list[dict[str, Any]]) -> None:
    import richmovie_atomic as _atomic
    if not _atomic.write_json(str(_pending_search_path()), items, separators=(",", ":")):
        xbmc.log(f"{_LOG_PREFIX} pending_searches write fail", xbmc.LOGERROR)


def track_search_initiated(query: str,
                            category: str = "other",
                            results_count: int = 0,
                            device_cluster_id: str | None = None) -> str:
    """User submitted a search. Returns client_event_id used for later
    click linking. The event is NOT yet in the telemetry buffer — it is
    pending; finalized either on click or on abandon-timeout."""
    cid = uuid.uuid4().hex
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    epoch = time.time()

    row = {
        "client_event_id": cid,
        "query": query,
        "category": category,
        "ts": ts,
        "ts_epoch": epoch,
        "results_count": results_count,
        "device_cluster_id": device_cluster_id,
        "profile_id": _current_profile_id(),
        "profile_mode": _current_profile_mode(),   # S24 D3
        "clicked_tmdb_id": None,
        "clicked_at": None,
        "click_latency_s": None,
        "result_played": False,
    }
    with _pending_search_lock, _PendingSearchFileLock():
        items = _load_pending_searches()
        items.append(row)
        # Cap to most recent 100 — older silently dropped (rare path)
        items = items[-100:]
        _save_pending_searches(items)
    return cid


def track_search_clicked(client_event_id: str,
                          tmdb_id: int | None,
                          result_played: bool = True) -> None:
    """User clicked a result. Finalize the pending search and enqueue."""
    if not client_event_id:
        return
    now_iso = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    now_epoch = time.time()
    with _pending_search_lock, _PendingSearchFileLock():
        items = _load_pending_searches()
        match: dict[str, Any] | None = None
        remaining: list[dict[str, Any]] = []
        for row in items:
            if row.get("client_event_id") == client_event_id and match is None:
                match = row
            else:
                remaining.append(row)
        _save_pending_searches(remaining)

    if match is None:
        return
    match["clicked_tmdb_id"] = int(tmdb_id) if tmdb_id else None
    match["clicked_at"] = now_iso
    match["click_latency_s"] = max(0, int(now_epoch - match.get("ts_epoch", now_epoch)))
    match["result_played"] = bool(result_played)
    match["abandoned"] = False
    match.pop("ts_epoch", None)
    enqueue_search_event(match)


def search_pending_discard(client_event_id: str) -> None:
    """Φ6 (2026-07-06, UX audit A07): zahodí pending search BEZ enqueue —
    uživatel dotaz v live-search upřesnil/dopsal (superseded), NENÍ to
    abandonment; starý řádek by kazil abandonment metriku. Search okno volá
    před dalším track_search_initiated."""
    if not client_event_id:
        return
    with _pending_search_lock, _PendingSearchFileLock():
        items = _load_pending_searches()
        remaining = [r for r in items if r.get("client_event_id") != client_event_id]
        if len(remaining) != len(items):
            _save_pending_searches(remaining)


def finalize_abandoned(max_age_s: int = _SEARCH_ABANDON_THRESHOLD_S) -> int:
    """Finalize pending searches older than `max_age_s` as abandoned.

    Called from periodic flush loop (every 5 min) — picks up any search
    that did not result in a click within the abandonment window.

    Returns count finalized.
    """
    now_epoch = time.time()
    finalized = 0
    with _pending_search_lock, _PendingSearchFileLock():
        items = _load_pending_searches()
        keep: list[dict[str, Any]] = []
        for row in items:
            age = now_epoch - row.get("ts_epoch", now_epoch)
            if age >= max_age_s:
                row["abandoned"] = True
                row.pop("ts_epoch", None)
                enqueue_search_event(row)
                finalized += 1
            else:
                keep.append(row)
        _save_pending_searches(keep)
    return finalized


def finalize_all_abandoned_now() -> int:
    """Force-finalize ALL pending searches as abandoned. Called at addon
    shutdown to ensure crash-safety."""
    return finalize_abandoned(max_age_s=0)
