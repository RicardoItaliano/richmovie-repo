# -*- coding: utf-8 -*-
"""
richmovie_cache_meter.py — měření plnění filecache (Φ1) + řízení podle linky (Φ2)
==================================================================================

Plán: `Handoff/PLAN_3_5_120_adaptive_cache_network_aware_20260825.md` (v2 po
cross-checku; čísla verzí v textu neplatí — implementováno 3.5.127/3.5.128).

PROČ
----
RAM je špatná proxy pro kapacitu linky (incident gunžík 25.08.2026: 32 GB RAM →
512 MB buffer na nejslabší lince ve flotile → bufferbloat pro celou domácnost).
Jediné, co o lince víme bez speedtestu, je JAK RYCHLE se plní forward okno
cache při přehrávání. Kodi to hlásí zdarma: InfoLabel `Player.CacheLevel`
(= `cached / maxforward`, naplnění forward okna 0–100 %). Žádný traffic navíc.

VERIFIKOVANÁ FAKTA (zdroje Kodi Omega, plán §2)
-----------------------------------------------
• `readfactor` je RATE-LIMIT plnění: writer čeká, dokud
  `Rate(m_writePos) ≥ m_writeRate × readFactor`; v adaptivním režimu readFactor
  klesá 4,0× (prázdná) → 1,5× (plná). Čistý přítok je `(readfactor − 1) × B`.
• Integrálem: ideální čas naplnění ≈ 0,63 × (M / B) do ~95 % — MINIMUM nezávislé
  na lince. Pro 128 MB @ 8 Mb/s je to ~80 s NA DOKONALÉ LINCE.
• → Absolutní prahy („grow když fill ≤ 60 s") jsou principiálně nefunkční.
  Metrika MUSÍ být poměrová: `fill_ratio = fill_s / ideal_fill_s(M, B)`.
  B = bitrate streamu ze `size / délka` (ListItem `richmovie.size_bytes` + délka
  z přehrávače); bez B se vzorek ZAHAZUJE.

GUARDY MĚŘENÍ (v2, audit P1.x / F7 / F10)
-----------------------------------------
• zdroj JEN `webshare` / `fastshare` (CDN přes CFileCache); chybějící/neznámý zdroj
  → NEMĚŘIT (fail-closed; local/SMB/YouTube jdou mimo CFileCache → level 0 →
  falešný shrink),
• zbývající obsah `(délka − pozice) × B` musí být > 1,5 × M — jinak forward okno
  narazí na EOF a level vyletí na 100 % okamžitě (resume u konce),
• pauza NEBO seek před naplněním → vzorek zahodit (pauza zastaví konzumaci a
  falešně zrychlí fill; seek flushne cache),
• konec okna: level ≥ 95 % ve ≥ 3 po sobě jdoucích 2s vzorcích → `fill_s`,
• `censored` JEN s pozitivním důkazem pomalého plnění: souvislé pozorování
  ≥ 180 s a `level_max` < ½ očekávaného levelu pro `observed_s` (pouhý Stop na
  zdravé lince censored nevyrobí),
• `eof` marker při `UNEXPECTED_EOF` (klasifikace `richmovie_playback_end`) —
  nejhorší síťové stavy nesmí být neviditelné.

ŘÍZENÍ (Φ2, grow-on-evidence)
-----------------------------
Žebříček 64 → 96 → 128 → 192 → 256 → 384 → 512. Rozhoduje se JEN ze vzorků
naměřených na aktuálně APLIKOVANÉ velikosti (žádná spirála ze zastaralých).
Grow o 1 stupeň: medián fill_ratio ≤ GROW_RATIO z ≥ 3 ok vzorků (přeskočí se,
když RAM cap ≤ network cap — růst by neměl efekt). Shrink o 1 stupeň: medián
≥ SHRINK_RATIO z ≥ 3 ok, NEBO ≥ 2 censored, NEBO ≥ 2 eof. Hystereze 1 krok/24 h,
`last_change_ts` až po VERIFIKOVANÉM apply (All-or-Nothing markeru).
Přechod flotily: initial cap se seeduje z evidence Φ1 (žádný plošný downgrade
zdravých zařízení); bez evidence min(applied, 128). Serverový strop z Gate
(`cache_tuning_max_mb`) je POUZE BRZDA (min), nikdy nezvyšuje.

Čistá logika bez Kodi (testovaná v `_tools/net_resilience_sim`, scénáře 45–48).
Python 3.8 (Kodi runtime).
"""

from __future__ import annotations

import statistics
from typing import Any, Dict, List, Optional, Tuple

# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY (jediné místo; harness je hlídá)
# ─────────────────────────────────────────────────────────────────────────────
TICK_S = 2.0                          # kadence samplování (av_monitor jede po 15 s — moc hrubé)
FILL_LEVEL_PCT = 95                   # „plná" = ≥ 95 %
FILL_CONFIRM_SAMPLES = 3              # …ve 3 po sobě jdoucích vzorcích
IDEAL_FILL_FACTOR = 0.63              # ∫ adaptivního readfactoru 4,0→1,5 (plán §2)
REMAINING_CONTENT_FACTOR = 1.5        # zbývající obsah musí být > 1,5 × M
CENSORED_MIN_OBSERVED_S = 180.0       # souvislé pozorování pro censored
CENSORED_LEVEL_FRACTION = 0.5         # level_max < ½ očekávaného → censored
SEEK_JUMP_TOLERANCE_S = 3.0           # skok pozice > tick + tolerance = seek

MEASURABLE_SOURCES = ("webshare", "fastshare")

LADDER = (64, 96, 128, 192, 256, 384, 512)
DEFAULT_NETWORK_CAP_MB = 128          # bez evidence: min(applied, 128)
GROW_RATIO = 1.3
SHRINK_RATIO = 3.0
MIN_DECISION_SAMPLES = 3
MIN_NEGATIVE_MARKERS = 2              # ≥ 2 censored nebo ≥ 2 eof → shrink
HYSTERESIS_S = 24 * 3600
SAMPLE_WINDOW = 10                    # rolling okno posledních vzorků

KIND_OK = "ok"
KIND_CENSORED = "censored"
KIND_EOF = "eof"

# Důvody rozhodnutí — vyjmenované na jednom místě (log + harness).
DECISION_GROW = "grow"
DECISION_SHRINK = "shrink"
DECISION_HOLD = "hold"
DECISION_SEEDED = "seeded"
DECISION_HYSTERESIS = "hysteresis"
DECISION_INSUFFICIENT = "insufficient_evidence"
DECISION_RAM_BOUND = "ram_bound"


# ─────────────────────────────────────────────────────────────────────────────
#  MODEL PLNĚNÍ
# ─────────────────────────────────────────────────────────────────────────────
def bitrate_bps(size_bytes: int, duration_s: float) -> Optional[float]:
    """Průměrný bitrate streamu (bit/s) ze size/délky; None = nelze určit."""
    try:
        size_bytes = int(size_bytes or 0)
        duration_s = float(duration_s or 0.0)
    except (TypeError, ValueError):
        return None
    if size_bytes <= 0 or duration_s <= 0:
        return None
    return size_bytes * 8.0 / duration_s


def ideal_fill_s(memorysize_mb: int, bitrate: float) -> Optional[float]:
    """Ideální čas naplnění forward okna na DOKONALÉ lince (readfactor limit)."""
    if not memorysize_mb or not bitrate or bitrate <= 0:
        return None
    return IDEAL_FILL_FACTOR * (float(memorysize_mb) * 1048576.0 * 8.0) / float(bitrate)


def expected_level_pct(observed_s: float, memorysize_mb: int, bitrate: float) -> Optional[float]:
    """Očekávaný level po `observed_s` na dokonalé lince (lineární aproximace
    ideální křivky, strop 100). Slouží censored testu."""
    ideal = ideal_fill_s(memorysize_mb, bitrate)
    if not ideal:
        return None
    return min(100.0, 100.0 * float(observed_s) / ideal)


# ─────────────────────────────────────────────────────────────────────────────
#  SLEDOVÁNÍ JEDNOHO PŘEHRÁVÁNÍ
# ─────────────────────────────────────────────────────────────────────────────
class FillTracker:
    """Stavový automat jednoho přehrávání. Krmí se 2s vzorky
    (`feed`), uzavírá `finish`. Nikdy nesahá na Kodi — čistá logika."""

    def __init__(self, *, memorysize_mb: int, bitrate: Optional[float],
                 duration_s: float, start_pos_s: float, source: str,
                 started_at: float) -> None:
        self.memorysize_mb = int(memorysize_mb or 0)
        self.bitrate = float(bitrate) if bitrate else None
        self.duration_s = float(duration_s or 0.0)
        self.start_pos_s = float(start_pos_s or 0.0)
        self.source = (source or "").strip().lower()
        self.started_at = float(started_at)
        self.eligible, self.ineligible_reason = self._eligibility()
        self.level_max = 0.0
        self.fill_s: Optional[float] = None
        self.invalidated: str = ""      # "paused" | "seek"
        self.last_playing_time: Optional[float] = None
        self.last_sample_at: Optional[float] = None
        self._confirm = 0
        self.samples_fed = 0

    def _eligibility(self) -> Tuple[bool, str]:
        if self.source not in MEASURABLE_SOURCES:
            return False, "source:%s" % (self.source or "unknown")
        if not self.bitrate:
            return False, "no_bitrate"
        if self.memorysize_mb <= 0:
            return False, "no_memorysize"
        remaining_bits = max(0.0, self.duration_s - self.start_pos_s) * self.bitrate
        if remaining_bits <= REMAINING_CONTENT_FACTOR * self.memorysize_mb * 1048576.0 * 8.0:
            return False, "remaining_content"
        return True, ""

    def feed(self, *, now: float, level_pct: Optional[float], paused: bool,
             playing_time_s: Optional[float]) -> None:
        """Jeden vzorek. `level_pct` None = InfoLabel nečitelný (vzorek se ignoruje,
        měření pokračuje — fail-safe: žádná změna capu z nečitelného senzoru)."""
        if not self.eligible or self.fill_s is not None or self.invalidated:
            return
        self.samples_fed += 1
        if paused:
            self.invalidated = "paused"
            return
        if (playing_time_s is not None and self.last_playing_time is not None
                and self.last_sample_at is not None):
            wall = now - self.last_sample_at
            jump = playing_time_s - self.last_playing_time
            if jump < -SEEK_JUMP_TOLERANCE_S or jump > wall + SEEK_JUMP_TOLERANCE_S:
                self.invalidated = "seek"
                return
        self.last_playing_time = playing_time_s
        self.last_sample_at = now
        if level_pct is None:
            return
        level = max(0.0, min(100.0, float(level_pct)))
        self.level_max = max(self.level_max, level)
        if level >= FILL_LEVEL_PCT:
            self._confirm += 1
            if self._confirm >= FILL_CONFIRM_SAMPLES and self.fill_s is None:
                self.fill_s = max(0.0, now - self.started_at)
        else:
            self._confirm = 0

    def observed_s(self, now: float) -> float:
        end = self.last_sample_at if self.last_sample_at is not None else now
        return max(0.0, end - self.started_at)

    def finish(self, *, now: float, unexpected_eof: bool = False) -> Optional[Dict[str, Any]]:
        """Uzavře měření. Vrací vzorek (ok / censored / eof), nebo None."""
        if not self.eligible:
            return None
        observed = self.observed_s(now)
        base = {
            "memorysize_applied": self.memorysize_mb,
            "bitrate_bps": int(self.bitrate or 0),
            "observed_s": round(observed, 1),
            "level_max": round(self.level_max, 1),
            "source": self.source,
            "ts": int(now),
        }
        if unexpected_eof:
            base.update({"kind": KIND_EOF, "fill_s": None, "fill_ratio": None})
            return base
        if self.invalidated:
            return None
        if self.fill_s is not None:
            ideal = ideal_fill_s(self.memorysize_mb, self.bitrate or 0.0) or 0.0
            ratio = (self.fill_s / ideal) if ideal > 0 else None
            base.update({"kind": KIND_OK, "fill_s": round(self.fill_s, 1),
                         "fill_ratio": round(ratio, 3) if ratio is not None else None})
            return base
        expected = expected_level_pct(observed, self.memorysize_mb, self.bitrate or 0.0)
        if (observed >= CENSORED_MIN_OBSERVED_S and expected is not None
                and self.level_max < CENSORED_LEVEL_FRACTION * expected):
            base.update({"kind": KIND_CENSORED, "fill_s": None, "fill_ratio": None,
                         "expected_level": round(expected, 1)})
            return base
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  ROZHODNUTÍ (Φ2) — čisté funkce nad rolling oknem vzorků
# ─────────────────────────────────────────────────────────────────────────────
def _ladder_step(value_mb: int, direction: int) -> int:
    """Nejbližší stupeň žebříčku o `direction` (+1/−1) dál; na krajích zůstává."""
    if value_mb not in LADDER:
        # neznámá hodnota → nejbližší nižší stupeň jako výchozí bod
        lower = [s for s in LADDER if s <= value_mb]
        value_mb = lower[-1] if lower else LADDER[0]
    idx = LADDER.index(value_mb)
    idx = max(0, min(len(LADDER) - 1, idx + direction))
    return LADDER[idx]


def samples_for(samples: List[Dict[str, Any]], applied_mb: int,
                since_ts: Optional[float] = None) -> List[Dict[str, Any]]:
    """Jen vzorky naměřené na aktuálně aplikované velikosti (v2, audit P2.1) —
    a od POSLEDNÍ změny velikosti (`since_ts` = last_change_ts).

    Cross-check Pro 31.08. (2. kolo, P4): bez časového filtru vznikala oscilace
    128↔256 — po shrinku zpět na 128 zůstaly v okně STARÉ ok vzorky ze 128
    (naměřené před growem) a hned po hysterezi spustily grow znovu, bez jediného
    nového měření. „Okno se po změně velikosti plní znovu" platí i časově.
    """
    out = []
    for s in samples or []:
        if not isinstance(s, dict):
            continue
        if int(s.get("memorysize_applied") or 0) != int(applied_mb):
            continue
        if since_ts and float(s.get("ts") or 0) < float(since_ts):
            continue
        out.append(s)
    return out


def _median_ratio(ok_samples: List[Dict[str, Any]]) -> Optional[float]:
    ratios = [float(s["fill_ratio"]) for s in ok_samples
              if s.get("fill_ratio") is not None]
    if len(ratios) < MIN_DECISION_SAMPLES:
        return None
    return float(statistics.median(ratios))


def seed_network_cap(samples: List[Dict[str, Any]], applied_mb: int) -> Tuple[int, str]:
    """První aktivace Φ2 (v2, audit P3a): ŽÁDNÝ plošný downgrade zdravých zařízení.

    Cross-check Pro 31.08. (2. kolo, P4): plánované „bez evidence → min(applied,
    128)" počítalo s týdnem Φ1 měření PŘED aktivací Φ2 (dvě release). Nasazují se
    ale spolu, takže první boot nemá žádné vzorky — a min() by v tu chvíli srazil
    KAŽDÉ zařízení s naší aplikovanou 512/256 na 128 = přesně ten plošný downgrade,
    který P3a zakazuje. Proto:
      • nic jsme neaplikovali (čerstvé zařízení) → bezpečný start 128, růst z evidence,
      • naše aplikovaná hodnota + ŽÁDNÁ/nerozhodná evidence → STATUS QUO (nechat
        applied; špatná linka vyrobí censored/eof a běžný shrink to stáhne do dne),
      • negativní evidence (≥2 censored/eof) → min(applied, 128) hned,
      • pozitivní evidence (medián ≤ GROW_RATIO) → potvrzený status quo.
    """
    if int(applied_mb or 0) <= 0:
        return DEFAULT_NETWORK_CAP_MB, "%s:fresh" % DECISION_SEEDED
    scoped = samples_for(samples, applied_mb)
    ok = [s for s in scoped if s.get("kind") == KIND_OK]
    negative = [s for s in scoped if s.get("kind") in (KIND_CENSORED, KIND_EOF)]
    if len(negative) >= MIN_NEGATIVE_MARKERS:
        return (min(_ladder_step(applied_mb, 0), DEFAULT_NETWORK_CAP_MB),
                "%s:negative_evidence" % DECISION_SEEDED)
    med = _median_ratio(ok)
    if med is not None and med <= GROW_RATIO:
        return _ladder_step(applied_mb, 0), "%s:evidence(median=%.2f)" % (DECISION_SEEDED, med)
    return _ladder_step(applied_mb, 0), "%s:status_quo" % DECISION_SEEDED


def decide_network_cap(*, samples: List[Dict[str, Any]], applied_mb: int,
                       network_cap: Optional[int], ram_cap: int,
                       last_change_ts: Optional[float], now: float,
                       gate_max: Optional[int] = None) -> Tuple[int, str]:
    """Nový network cap (MB) + důvod. Nikdy nevyhazuje; bez evidence drží."""
    if network_cap is None:
        cap, reason = seed_network_cap(samples, applied_mb)
        return _clamp_gate(cap, gate_max), reason

    cap = int(network_cap)
    # Rozhodují jen vzorky z doby PO poslední změně velikosti (viz samples_for —
    # jinak oscilace ze zastaralé evidence; Pro 2. kolo, P4).
    scoped = samples_for(samples, applied_mb, since_ts=last_change_ts)
    ok = [s for s in scoped if s.get("kind") == KIND_OK]
    censored = [s for s in scoped if s.get("kind") == KIND_CENSORED]
    eof = [s for s in scoped if s.get("kind") == KIND_EOF]
    med = _median_ratio(ok)

    shrink = (len(censored) >= MIN_NEGATIVE_MARKERS or len(eof) >= MIN_NEGATIVE_MARKERS
              or (med is not None and med >= SHRINK_RATIO))
    grow = (not shrink) and med is not None and med <= GROW_RATIO

    if not shrink and not grow:
        reason = DECISION_HOLD if med is not None else DECISION_INSUFFICIENT
        return _clamp_gate(cap, gate_max), reason

    if last_change_ts and (now - float(last_change_ts)) < HYSTERESIS_S:
        return _clamp_gate(cap, gate_max), DECISION_HYSTERESIS

    if shrink:
        new_cap = _ladder_step(cap, -1)
        why = ("censored=%d" % len(censored) if len(censored) >= MIN_NEGATIVE_MARKERS
               else "eof=%d" % len(eof) if len(eof) >= MIN_NEGATIVE_MARKERS
               else "median=%.2f" % (med or 0.0))
        return _clamp_gate(new_cap, gate_max), "%s:%s" % (DECISION_SHRINK, why)

    # grow — jen když má efekt (RAM cap nad network capem; audit P2.2)
    if int(ram_cap) <= cap:
        return _clamp_gate(cap, gate_max), DECISION_RAM_BOUND
    new_cap = min(_ladder_step(cap, +1), int(ram_cap))
    return _clamp_gate(new_cap, gate_max), "%s:median=%.2f" % (DECISION_GROW, med or 0.0)


def _clamp_gate(cap: int, gate_max: Optional[int]) -> int:
    """Serverový strop = pouze brzda (min). None = bez clampu."""
    if gate_max is None:
        return int(cap)
    try:
        g = int(gate_max)
    except (TypeError, ValueError):
        return int(cap)
    return min(int(cap), g) if g > 0 else int(cap)


def append_sample(samples: List[Dict[str, Any]], sample: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Rolling okno posledních SAMPLE_WINDOW vzorků (nejnovější poslední)."""
    out = [s for s in (samples or []) if isinstance(s, dict)]
    out.append(dict(sample))
    return out[-SAMPLE_WINDOW:]
