# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_ai.py
# RichMovie A.I. – logování, progress wrapper, TMDb validace  (vytvořeno: 24.01.2026 21:00 CET, Europe/Prague)
# ⚠️ KODI PLUGIN: Proces-based architektura, lazy init pro session!
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – A.I. Utility modul
───────────────────────────────────────────────────────────────────────────────
Tento modul obsahuje:

  • **Logování**          – Diagnostika AI volání do RichMovie_a.i.log
  • **Progress wrapper**  – Sims-like progress pro AI volání
  • **TMDb validace**     – Ověření shody kandidátů s constraints

UI funkce (_ai_menu, _ai_recommend_show, _ai_identify_show) zůstávají
v plugin.py, protože jsou silně navázané na Kodi GUI (xbmcplugin, routing).

Autor: Richie – extrahováno 24-01-2026
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

# — Standardní knihovna —
import datetime
import hashlib
import json
import os
import random
import re
import threading
import time
import unicodedata
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.84): kodi.log zrcadlo AI eventů
# (AI_QUERY/AI_RESP + WARNING/ERROR) přepnuto na ROUTOVANÝ logger → mirror
# teče i na NAS (primární AI event log do souboru zůstává nedotčen).
try:
    from richmovie_logging import make_legacy_logger as _ai_make_legacy_logger
    _mirror_log = _ai_make_legacy_logger("richmovie.ai", "RichMovie A.I.")
except Exception:
    def _mirror_log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log("[RichMovie A.I.] " + str(msg), level)
        except Exception:
            pass

# — Lokální moduly —
from tmdb_client import TMDb, TMDbError
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ─────────────────────────────────────────────────────────────────────────────
#  MODUL-LEVEL PROMĚNNÉ – LAZY INIT
# ─────────────────────────────────────────────────────────────────────────────
_ADDON: xbmcaddon.Addon | None = None
_PROFILE_DIR: Path | None = None
_AI_LOG_PATH: str | None = None
_LOG_LOCK = threading.Lock()

# Callbacky pro UI funkce – nastaví se z plugin.py
_keyboard_input_callback: Callable[[str, bool], str | None] | None = None
_modal_callback: Callable[..., None] | None = None


def _get_addon() -> xbmcaddon.Addon:
    """Lazy init pro ADDON instanci."""
    global _ADDON
    if _ADDON is None:
        _ADDON = xbmcaddon.Addon()
    return _ADDON


def _get_profile_dir() -> Path:
    """Lazy init pro PROFILE_DIR."""
    global _PROFILE_DIR
    if _PROFILE_DIR is None:
        addon = _get_addon()
        _PROFILE_DIR = Path(
            xbmcvfs.translatePath(f"special://profile/addon_data/{addon.getAddonInfo('id')}")
        )
        _PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    return _PROFILE_DIR


def _get_ai_log_path() -> str:
    """Lazy init pro AI log path."""
    global _AI_LOG_PATH
    if _AI_LOG_PATH is None:
        _AI_LOG_PATH = str(_get_profile_dir() / "RichMovie_a.i.log")
    return _AI_LOG_PATH


def set_keyboard_callback(callback: Callable[[str, bool], str | None]) -> None:
    """Nastaví callback pro keyboard input (voláno z plugin.py)."""
    global _keyboard_input_callback
    _keyboard_input_callback = callback


def set_modal_callback(callback: Callable[..., None]) -> None:
    """Nastaví callback pro modální dialog (voláno z plugin.py)."""
    global _modal_callback
    _modal_callback = callback


def _keyboard_input(heading: str, hidden: bool = False) -> str | None:
    """Wrapper pro keyboard input – deleguje na callback nebo přímé volání."""
    if _keyboard_input_callback:
        try:
            return _keyboard_input_callback(heading, hidden)
        except Exception:
            pass
    # Fallback na přímé volání
    kb = xbmcgui.Dialog()
    val = kb.input(heading, type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT if hidden else 0)
    return val if val else None


def _modal(msg: str, heading: str = "RichMovie A.I.", block: bool = True) -> None:
    """Wrapper pro modální dialog – deleguje na callback nebo přímé volání."""
    if _modal_callback:
        try:
            _modal_callback(msg, heading=heading, block=block)
            return
        except Exception:
            pass
    # Fallback na přímé volání
    if block:
        xbmcgui.Dialog().ok(heading, msg)
    else:
        try:
            _rm_notif(msg, xbmcgui.NOTIFICATION_INFO, 3000, heading)
        except Exception:
            pass




# ═══════════════════════════════════════════════════════════════════════════════
#  AI LOGOVÁNÍ
# ═══════════════════════════════════════════════════════════════════════════════


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_ai.py
# ai_log  (vytvořeno: 24.01.2026 21:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def ai_log(event: str, message: str = "", *, details: dict | None = None, level: str = "ERROR") -> None:
    """
    Zapisuje AI diagnostiku do dedikovaného souboru a zrcadlí první řádky
    i do kodi.log pro snadný debug.

    Formát souboru RichMovie_a.i.log:
        YYYY-MM-DD HH:MM:SS<TAB>LEVEL<TAB>EVENT<TAB>MESSAGE<TAB>{json(details)}

    Bezpečnost a výkon:
      • Rotace logu ~1 MiB (RichMovie_a.i.log → RichMovie_a.i.log.1).
      • Zápis je "fire-and-forget" – jakákoli výjimka se tiše polkne.
      • Zrcadlení do kodi.log je lehké (jen krátká věta), neukládá se `details`.
    """
    try:
        # ---- sestavení řádku -------------------------------------------------
        ts = datetime.datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S")
        row = "\t".join([ts, str(level), str(event), str(message or "")])
        if details:
            try:
                row += "\t" + json.dumps(details, ensure_ascii=False, separators=(",", ":"))
            except Exception:
                pass

        # ---- bezpečné určení cesty -------------------------------------------
        ai_log_path = _get_ai_log_path()

        # ---- rotace ~1 MiB ---------------------------------------------------
        try:
            if os.path.exists(ai_log_path) and os.path.getsize(ai_log_path) > (1 * 1024 * 1024):
                bak = ai_log_path + ".1"
                try:
                    if os.path.exists(bak):
                        os.remove(bak)
                except Exception:
                    pass
                try:
                    os.replace(ai_log_path, bak)  # lint:allow-replace rotace logu = rename, ne zápis dat
                except Exception:
                    pass
        except Exception:
            pass

        # ---- zápis (thread‑safe) --------------------------------------------
        try:
            with _LOG_LOCK:
                with open(ai_log_path, "a", encoding="utf-8") as fh:
                    fh.write(row + "\n")
        except Exception:
            pass

        # ---- zrcadlení do kodi.log (vybrané eventy + WARNING/ERROR) ----------
        level_u = (level or "ERROR").upper()
        # Milníky AI volání (Gate → RCAI) zrcadlené do kodi.log i na INFO úrovni
        # pro snadný debug. ERROR/WARNING se zrcadlí vždy (viz should_mirror níže).
        MIRROR_EVENTS = {
            "AI_QUERY", "AI_RESP",
            "AI_ID_QUERY", "AI_ID_RESP",
        }
        should_mirror = (level_u in ("ERROR", "WARNING")) or (str(event) in MIRROR_EVENTS)
        if should_mirror:
            try:
                lvl_map = {
                    "DEBUG": xbmc.LOGDEBUG,
                    "INFO": xbmc.LOGINFO,
                    "WARNING": xbmc.LOGWARNING,
                    "ERROR": xbmc.LOGERROR,
                }
                _mirror_log(f"{event}" + (f" – {message}" if message else ""), lvl_map.get(level_u, xbmc.LOGINFO))
            except Exception:
                pass

    except Exception:
        # logování nesmí nikdy shodit doplněk
        pass





# ═══════════════════════════════════════════════════════════════════════════════
#  PROGRESS WRAPPER (SIMS-LIKE)
# ═══════════════════════════════════════════════════════════════════════════════


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_ai.py
# run_ai_with_progress  (vytvořeno: 24.01.2026 21:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def run_ai_with_progress(kind: str, user_text: str, *, mode: str, worker: Callable[[], Any]) -> Tuple[Any, Any]:
    """
    Spustí A.I. práci v pozadí a zobrazí „Sims-like" průběh s procenty.

    Parametry:
      kind: "movie" | "tv" | "any" (typ pro doporučení)
      user_text: vstup od uživatele (pro personifikaci hlášek)
      mode: "recommend" | "identify" (volaná A.I. větev)
      worker: nulár, který v jiném vlákně provede A.I. volání a vrátí výsledek

    Návrat:
      (result, progress_obj) – výsledek A.I. volání a handle na progres
      (progress_obj má metody update(percent:int, msg:str), close())

    Pozn.: Emoji používáme jen tehdy, když skin zřejmě podporuje emoji fonty.
    """

    # — vnitřní třída: obsluha progress okna ————————————————
    class _SimsProgress:
        def __init__(self, heading: str, use_emoji: bool) -> None:
            self._dlg = xbmcgui.DialogProgressBG()
            self._heading = heading
            self._use_emoji = use_emoji
            self._pct = 0

        def create(self, msg: str) -> None:
            try:
                self._dlg.create(self._heading, msg)
            except Exception:
                pass

        def update(self, pct: int, msg: str) -> None:
            self._pct = max(0, min(100, int(pct)))
            try:
                self._dlg.update(self._pct, self._heading, msg)
            except Exception:
                pass

        def close(self) -> None:
            try:
                self._dlg.close()
            except Exception:
                pass

    # — pomocníci ——————————————————————————————————————————————
    def _detect_skin_emoji_support() -> bool:
        """
        Heuristika: v `special://skin/fonts/` hledáme fonty obsahující 'emoji',
        'color', 'noto', 'twemoji', 'segoe'. Když si nejsme jisti, vracíme False.
        """
        try:
            fonts_dir = xbmcvfs.translatePath("special://skin/fonts/")
            try:
                dirs, files = xbmcvfs.listdir(fonts_dir)
            except Exception:
                return False
            look = ("emoji", "color", "noto", "twemoji", "segoe")
            for name in files:
                n = (name or "").lower()
                if any(k in n for k in look):
                    return True
            return False
        except Exception:
            return False

    # — volba hlavičky, personalizace a banky textů ——————————
    use_emoji = _detect_skin_emoji_support()
    Q = (user_text or "").strip().strip("'\"")
    base_q = f'\u201E{Q}\u201C' if Q else "tvým chutím"
    is_tv = (kind or "").lower() == "tv"
    is_movie = (kind or "").lower() == "movie" or ((kind or "").lower() == "any" and mode == "recommend")

    if mode == "recommend":
        heading = "RichMovie A.I. – doporučení"
    else:
        heading = "RichMovie A.I. – přesná identifikace"

    # —— SIMS‑like banky hlášek (>= ~120 unikátů napříč režimy) ————————
    # 1) Filmy – textová banka (~45)
    MOVIE_PLAIN = [
        f"Skenuji filmové galaxie pro {base_q}…",
        "Prohledávám archivy invazních blockbusterů…",
        "Měřím dávku popcornu na metr exploze…",
        "Ladím rovnováhu mezi akcí a napětím…",
        "Kontroluji, zda finále nepráskne moc brzo…",
        "Seřazuji UFO podle velikosti talířů…",
        "Zjišťuji, kolik hrdinů světu dnes zachrání krk…",
        "Srovnávám remaky, rebooty a skutečné klasiky…",
        "Testuji, zda mimozemšťani mluví česky (alespoň titulky)…",
        "Mapuji přistávací koridory nad tvou filmotékou…",
        "Seřazuji lasery od 'pšouk' po 'odpař město'…",
        "Zkoumám, jestli je střih víc rychlý než rozumný…",
        "Srovnávám generály, kteří nikomu nic neřeknou…",
        "Počítám, kolik mrakodrapů padne do závěrečných titulků…",
        "Vybírám filmy, co stárnou jako víno, ne jako CGI z roku 2000…",
        "Hledám cameo Jeffa Goldbluma – pro jistotu…",
        "Filtruji 'panika v ulicích' vs. 'tichý první kontakt'…",
        "Krotím drony, aby nespoilerovaly zápletku…",
        "Nabíjím kameru třesem ruky (found‑footage mód)…",
        "Stahuji gravitační vlny z prostoru vyprávění…",
        "Měřím poměr 'wow' k 'cože' v každé scéně…",
        "Přepočítávám šance lidstva bez wi‑fi…",
        "Zvažuju, kolik saxofonů unesou devadesátky…",
        "Odlazuji subwoofer: zemětřesení, ale se vkusem…",
        "Vybírám filmy, které nenapálí trailer…",
        "Lovím inteligentní sci‑fi, co neurazí ani akčňáka…",
        "Kontroluji, zda prezident pronese řeč…",
        "Řadím přistání podle úhlu záběru na Bílý dům…",
        "Zkouším, zda hrdina ví, kde je vypínač…",
        "Prověřuji, kolik fyziky film unese, než přestane bavit…",
        "Odhaduji, kde se ztratí pes a kdy se vrátí…",
        "Vybírám soundtracky, co zvednou chlupy…",
        "Dávám stranou filmy, kde mimozemšťan vysvětluje plán PowerPointem…",
        "Hledám sci‑fi, u kterého se dá i přemýšlet…",
        "Kalibruji míru ironie v heroických proslovech…",
        "Zjišťuji, zda je lepší zůstat doma, nebo běžet do tunelu…",
        "Rozhoduji, jestli má město šanci bez hackerů…",
        "Porovnávám kvalitu modelů vs. CGI…",
        "Dělám audit 'červeného tlačítka'…",
        "Uvažuji, jestli se dá přežít v chladničce…",
        "Ladím tempo: pomalý první kontakt vs. hurá invaze…",
        "Dávám body za chytré zvraty bez podrazů…",
        "Prověřuji, zda je vědec charismatický aspoň jako meteorit…",
        "Vybírám filmy, co fungují i při druhé projekci…",
        "Doháním vesmír, který má zpoždění v dopravě…",
        "Kontroluji, jestli titulky nestihnou ujet ději…",
    ]

    # 2) Seriály – textová banka (~40)
    TV_PLAIN = [
        f"Hledám seriálové nitky pro {base_q}…",
        "Řadím epizody tak, aby recap seděl…",
        "Vybírám piloty, co nejsou jen prototyp…",
        "Zdařím cliffhangery bez krutosti…",
        "Kontroluji konzistenci scénářů mezi sezónami…",
        "Měřím délku binge bez ztráty pozornosti…",
        "Zkoumám, jestli druhá sezóna nebyla jen šťastná náhoda…",
        "Kalibruji titulky pro noční sledování…",
        "Přebírám universa a spin‑offy…",
        "Odstraňuji fillery, co zpomalují…",
        "Hledám soundtrack, co táhne scény dál…",
        "Porovnávám kvalitu finále vs. začátek…",
        "Mapuji oblouky postav, co dávají smysl…",
        "Třídím epizody podle 'ještě jednu a jdu spát'…",
        "Dávám body showrunnerům, co ví, kam jdou…",
        "Hledám série bez zbytečných flashbacků…",
        "Srovnávám evropskou a US stopáž…",
        "Kreslím tabuli se špagetami vztahů…",
        "Eliminuji šok jen pro šok…",
        "Prověřuji, jestli je každá epizoda mini‑film…",
        "Hledám seriály s dobrým 'Previously on'…",
        "Vážu si uzly cliffhangerů…",
        "Hledám skryté perly vedle mainstreamu…",
        "Porovnávám tempo mezi epizodami…",
        "Vybírám díly s pamětihodnými scénami…",
        "Kontroluji, zda filler není tajně character development…",
        "Odstraňuji epizody se spícím kameramanem…",
        "Zkoumám, jestli finále uzavírá, ne rozptyluje…",
        "Vyhazuji recyklované zvraty…",
        "Dohledávám chybějící české titulky…",
        "Ladím poměr procedurála vs. overarching příběhu…",
        "Dávám šanci miniseriím s ostrým koncem…",
        "Odhaluji série, které vydrží maraton…",
        "Hledám epizody, co zvednou obočí…",
        "Kontroluji, jestli pilot neurazí tvůj večer…",
        "Přepočítávám, kolik dílů 'právě ještě jeden' reálně znamená…",
        "Vybírám díly, které příběh posouvají, ne kroutí…",
        "Prověřuji, jestli recenze nelžou…",
        "Hledám seriály s výraznou vizuální identitou…",
        "Zaklepávám na dveře další sezóny…",
    ]

    # 3) Identifikace – textová banka (~40)
    ID_PLAIN = [
        f"Překládám tvůj popis {('pro ' + base_q) if Q else ''} do jazyka vyhledávače…",
        "Porovnávám scény s pamětí filmové knihovny…",
        "Vylučuji tituly, které si to jen 'myslí'…",
        "Dohledávám alternativní názvy a překlady…",
        "Vážu roky vydání s herci…",
        "Sedluji žánry: bylo to víc sci‑fi, nebo thriller?…",
        "Zjišťuji, zda šlo o film či seriál…",
        "Kontroluji stopáž proti více verzím…",
        "Křížím motivy: časová smyčka? kontakt? invaze?…",
        "Odebírám falešné vzpomínky…",
        "Zkoumám plakáty podle ikonických motivů…",
        "Rozmotávám synopsis bez spoilerů…",
        "Kontroluji, zda scéna v dešti nebyla z jiného díla…",
        "Hledám vazbu mezi citátem a titulem…",
        "Připisuji body za výrazné lokace…",
        "Zkoumám, jestli 'to' nebyl díl antologie…",
        "Prověřuji edice: kino vs. director's cut…",
        "Srovnávám soundtrack se scénou, kterou popisuješ…",
        "Procházím cameo, která všechno prozradí…",
        "Zkouším, jestli nebyl dabing zavádějící…",
        "Vytahuji střípky z kritik…",
        "Mapuji triky: praktické vs. digitální…",
        "Hledám scénu s motivem dveří/okna/ticha…",
        "Přepočítávám 'to bylo někdy kolem 2000'…",
        "Přikládám stopy z českých názvů…",
        "Testuji, zda šlo o remake…",
        "Odlišuji pilot od pozdější epizody…",
        "Validuji geolokaci záběru…",
        "Oprašuju povědomé tváře…",
        "Vytahuji staré trailery pro porovnání…",
        "Vynechávám falešné shody podle jmen postav…",
        "Znovu čtu popis: co je klíčový detail?…",
        "Propojuju detaily z tvého textu se scénami…",
        "Kontroluji, jestli to nebyla miniserie…",
        "Vážu citaci dialogu k scénáři…",
        "Dohledávám epizodní názvy…",
        "Ladím skóre pravděpodobnosti…",
        "Zkouším alternativní žánrové klíče…",
        "Prohledávám archivy podle motivu plakátu…",
        "Uzluji poslední dvě varianty…",
    ]

    # Pokud skin umí emoji, doplníme je cyklicky – bez změny textu.
    EMOJI_POOL_MOV = ["🎬", "🛸", "🚀", "🛰️", "💥", "🔭", "🧪", "📡", "🎯", "🧠", "🎞️", "🌌", "🛰", "🧲", "🎛️"]
    EMOJI_POOL_TV  = ["📺", "🧵", "🗂️", "🕰️", "🎭", "🧩", "🧭", "🎚️", "🧪", "📚", "🔁", "🧠", "📡", "🧷", "📝"]
    EMOJI_POOL_ID  = ["🔎", "📚", "🧠", "🧭", "🧩", "🧪", "📼", "🖼️", "🎞️", "🗺️", "🎧", "📝", "🧵", "🧷", "📌"]

    def _with_emoji(lines: List[str], pool: List[str]) -> List[str]:
        if not use_emoji:
            return lines
        out: List[str] = []
        for i, s in enumerate(lines):
            out.append(f"{pool[i % len(pool)]} {s}")
        return out

    # Vyber správnou banku
    if mode == "recommend" and is_tv:
        LINES = _with_emoji(TV_PLAIN, EMOJI_POOL_TV)
    elif mode == "recommend" and is_movie:
        LINES = _with_emoji(MOVIE_PLAIN, EMOJI_POOL_MOV)
    else:
        LINES = _with_emoji(ID_PLAIN, EMOJI_POOL_ID)

    def msg_start() -> str:
        if mode == "recommend":
            return ("Start: hledám tipy na seriály…" if is_tv else "Start: hledám tipy na filmy…")
        else:
            return "Start: přesně identifikuji dílo podle popisu…"

    def msg_finalizing(n: Optional[int] = None) -> str:
        if mode == "recommend":
            return f"Finalizuji doporučení{f' ({n} nalezených)' if n is not None else ''}…"
        else:
            return f"Finalizuji identifikaci{f' ({n} kandidátů)' if n is not None else ''}…"

    # — vytvoření progress okna ——————————————————————————————
    progress = _SimsProgress(heading, use_emoji)
    progress.create(msg_start())
    progress.update(3, msg_start())

    # — spuštění workeru v pozadí ————————————————————————————
    result_holder: Dict[str, Any] = {"res": None, "err": None}
    done = threading.Event()

    def _runner():
        try:
            result_holder["res"] = worker()
        except Exception as e:
            result_holder["err"] = e
        finally:
            done.set()

    th = threading.Thread(target=_runner, name="RichMovie.AIWorker", daemon=True)
    th.start()

    # — živý Sims‑like běh (dokud worker neskončí) ——————————————
    monitor = xbmc.Monitor()

    # deterministické promíchání pro stejný dotaz
    seed = int(hashlib.md5((Q + "|" + mode + "|" + (kind or "")).encode("utf-8", errors="ignore")).hexdigest(), 16)
    rnd = random.Random(seed)
    lines = list(LINES)
    rnd.shuffle(lines)

    # kdyby přesto něco selhalo, máme aspoň jednu větu
    if not lines:
        lines = [msg_start()]

    idx = 0
    pct = 3
    last_switch = time.time()
    switch_every = 2.2  # s – jak často obměnit větu
    step_every = 0.9    # s – krok v procentech
    last_step = time.time()

    while not done.is_set():
        if monitor.waitForAbort(0.2):
            break
        now = time.time()
        # posun procent
        if now - last_step >= step_every:
            last_step = now
            pct = min(85, pct + 2)  # plynule do 85 %, zbytek po návratu A.I.
            try:
                progress.update(pct, lines[idx])
            except Exception:
                pass

        # přepni větu
        if now - last_switch >= switch_every:
            last_switch = now
            idx = (idx + 1) % len(lines)
            try:
                progress.update(pct, lines[idx])
            except Exception:
                pass

    # — worker skončil: přechod do závěrečných fází ——————————————
    if result_holder["err"] is not None:
        # necháme volajícího, ať ukáže dialog s chybou; progres uklidíme tady
        try:
            progress.update(pct, "Chyba – uklízím…")
        except Exception:
            pass
        return None, progress

    # Rezerva pro závěrečnou práci volajícího (TMDb apod.)
    try:
        n = len(result_holder["res"]) if isinstance(result_holder["res"], (list, tuple)) else None
        progress.update(95, msg_finalizing(n))
    except Exception:
        pass

    return result_holder["res"], progress




# ═══════════════════════════════════════════════════════════════════════════════
#  TMDB VALIDACE
# ═══════════════════════════════════════════════════════════════════════════════


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_ai.py
# ai_verify_tmdb_match  (vytvořeno: 24.01.2026 21:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def ai_verify_tmdb_match(kind: str, tmdb: TMDb, item: Dict[str, Any], constraints: Dict[str, Any], tmdb_key: str) -> tuple[bool, Dict[str, Any]]:
    """
    Tvrdá validace kandidáta proti TMDb – projde jen, pokud **všechno podstatné**
    z constraints sedí na datech TMDb.

    Kontroluji:
      • ROK (pokud je přesně zadaný) nebo DEKÁDU (přibližně).
      • OSOBY/HERCE: přesná shoda jména v obsazení (movie: /movie/{id}/credits,
                    tv: /tv/{id}/aggregate_credits).
      • MÍSTA / „PLOT POINTS" / POSTAVY: substring v (overview + alt názvech + titulech + jménech postav).
      • JAZYKY: original_language / spoken_languages.
      • ZEMĚ: production_countries (film) / origin_country (TV).
      • ŽÁNRY: shoda názvů žánrů.
      • FORBIDDEN: žádný z negativních tokenů se nesmí v korpusu vyskytovat.

    Návrat: (True/False, {found: [...], missing: [...], year_ok: bool, detail: {...}})
    """
    # — malý normalizér (bez diakritiky, lower, alnum+space) —
    def _norm_txt(s: str) -> str:
        t = (s or "").strip().lower()
        if not t:
            return ""
        t = unicodedata.normalize("NFKD", t)
        t = "".join(ch for ch in t if not unicodedata.combining(ch))
        # necháme písmena/čísla/mezery
        out = []
        for ch in t:
            if ch.isalnum() or ch.isspace():
                out.append(ch)
            else:
                out.append(" ")
        return " ".join("".join(out).split())

    # — bezpečné tahání polí —
    def _get(d: Dict[str, Any], key: str, default=None):
        v = d.get(key, default)
        return v if v is not None else default

    # — rozbal constraints —
    actors      = [str(x).strip() for x in (constraints.get("actors") or []) if str(x).strip()]
    people      = [str(x).strip() for x in (constraints.get("people") or []) if str(x).strip()]
    characters  = [str(x).strip() for x in (constraints.get("characters") or []) if str(x).strip()]
    places      = [str(x).strip() for x in (constraints.get("places") or []) if str(x).strip()]
    countries   = [str(x).strip() for x in (constraints.get("countries") or []) if str(x).strip()]
    languages   = [str(x).strip() for x in (constraints.get("languages") or []) if str(x).strip()]
    genres_req  = [str(x).strip() for x in (constraints.get("genres") or []) if str(x).strip()]
    plot_points = [str(x).strip() for x in (constraints.get("plot_points") or []) if str(x).strip()]
    forbid      = [str(x).strip() for x in (constraints.get("forbidden") or []) if str(x).strip()]
    year_exact  = int(constraints.get("year_exact") or 0)
    decade_hint = (constraints.get("decade_hint") or "").strip().lower()

    # 1) — stáhni detail + alt tituly + obsazení (i postavy) —
    detail: Dict[str, Any] = {}
    alts: List[str] = []
    cast_names: List[str] = []
    char_names: List[str] = []

    try:
        if kind == "movie":
            detail = tmdb.details(int(item["id"]))
            # alt titles (filmy mají wrapper)
            try:
                alts = [rec["title"] for rec in tmdb.alternative_titles(int(item["id"]), max_items=None)]
            except TMDbError:
                alts = []
            # obsazení + jména postav
            try:
                credits = tmdb._get_json(f"/movie/{int(item['id'])}/credits", {"api_key": tmdb.api_key})
            except TMDbError:
                credits = {}
            cast_names = [c.get("name","") for c in (credits.get("cast") or []) if c.get("name")]
            # postavy bývají v 'character'
            char_names = [c.get("character","") for c in (credits.get("cast") or []) if c.get("character")]
        else:
            # tv detail
            detail = tmdb._get_json(f"/tv/{int(item['id'])}", {"api_key": tmdb.api_key, "language": tmdb.lang})
            # alt titles (TV nemají wrapper → přes _get_json)
            try:
                res = tmdb._get_json(f"/tv/{int(item['id'])}/alternative_titles", {"api_key": tmdb.api_key})
                alts = [r.get("title","") for r in (res.get("results") or []) if r.get("title")]
            except TMDbError:
                alts = []
            # aggregate_credits → jména + role (postavy)
            try:
                agg = tmdb._get_json(f"/tv/{int(item['id'])}/aggregate_credits", {"api_key": tmdb.api_key})
            except TMDbError:
                agg = {}
            cast_names = [c.get("name","") for c in (agg.get("cast") or []) if c.get("name")]
            # roles: [{"character": "..."}] – vezmeme všechny
            for c in (agg.get("cast") or []):
                for r in (c.get("roles") or []):
                    nm = (r.get("character") or "").strip()
                    if nm:
                        char_names.append(nm)
    except TMDbError as e:
        return False, {"err": f"TMDb detail error: {e}"}

    # 2) — korpus textů pro substring match —
    titles = [item.get("title") or item.get("name") or "", detail.get("original_title",""), detail.get("title",""), detail.get("name",""), *alts]
    genres = [g.get("name","") for g in (detail.get("genres") or []) if g.get("name")]
    overview = (detail.get("overview") or "").strip()

    corpus_fields = [
        " ".join(titles),
        overview,
        " ".join(genres),
        " ".join(cast_names),
        " ".join(char_names),
    ]
    corpus_norm = _norm_txt(" • ".join(corpus_fields))

    # 3) — kontrola roku/dekády —
    year_ok = True
    detail_year = 0
    if kind == "movie":
        detail_year = int(detail.get("year") or int((detail.get("release_date") or "0000")[:4] or 0))
    else:
        detail_year = int((detail.get("first_air_date") or "0000")[:4] or 0)

    if year_exact:
        year_ok = (detail_year == year_exact)
    elif decade_hint:
        # jednoduchá heuristika: "late 90s" → 1995–1999; "90s" → 1990–1999
        dec = None
        m = re.search(r"(\d{4})s|(\d{2})s", decade_hint)
        if m and (m.group(1) or m.group(2)):
            try:
                if m.group(1):
                    # plný tvar: "1990s" → base=1990
                    base = int(m.group(1))
                else:
                    # krátký tvar: "90s" → 1990, "20s" → 2020
                    short = int(m.group(2))
                    base = (1900 + short) if short >= 30 else (2000 + short)
                lo, hi = base, base + 9
                if "late" in decade_hint:
                    lo = base + 5
                elif "early" in decade_hint:
                    hi = base + 4
                year_ok = (lo <= detail_year <= hi)
            except Exception:
                year_ok = True  # když nevíme, nepokazíme to
        else:
            year_ok = True

    # 4) — sestav tokeny k ověření —
    def _all_present(names: List[str], pool: List[str]) -> bool:
        want = {_norm_txt(x) for x in names if _norm_txt(x)}
        have = {_norm_txt(x) for x in pool if _norm_txt(x)}
        return want.issubset(have)

    missing: List[str] = []
    found:   List[str] = []

    # herci/osoby → tvrdá shoda v obsazení
    if actors:
        if not _all_present(actors, cast_names):
            missing += [f"actor:{x}" for x in actors if _norm_txt(x) not in {_norm_txt(n) for n in cast_names}]
        else:
            found += [f"actor:{x}" for x in actors]
    if people:
        # persons mohou obsahovat herce/režiséry – beru jako měkké OR k actors (ale ověřím proti cast jménům)
        if people and not _all_present(people, cast_names):
            # nechci duplicitně reportovat věci, co už byly v actors
            for x in people:
                nx = _norm_txt(x)
                if nx and nx not in {_norm_txt(n) for n in cast_names} and nx not in {_norm_txt(a) for a in actors}:
                    missing.append(f"person:{x}")
        else:
            for x in people:
                found.append(f"person:{x}")

    # postavy/místa/plot‑points → substring v korpusu
    def _substr_all(tokens: List[str]) -> tuple[bool, List[str]]:
        miss = []
        for t in tokens:
            nt = _norm_txt(t)
            if nt and nt not in corpus_norm:
                # jako fallback zkusím i bez mezer (někdy TMDb uvádí bez diakritiky/oddělovačů)
                if nt.replace(" ", "") not in corpus_norm.replace(" ", ""):
                    miss.append(t)
        return (len(miss) == 0, miss)

    ok_char, miss_char = _substr_all(characters)
    ok_place, miss_place = _substr_all(places)
    ok_plot,  miss_plot  = _substr_all(plot_points)

    if not ok_char:  missing += [f"char:{x}"  for x in miss_char]
    else:            found   += [f"char:{x}"  for x in characters]
    if not ok_place: missing += [f"place:{x}" for x in miss_place]
    else:            found   += [f"place:{x}" for x in places]
    if not ok_plot:  missing += [f"plot:{x}"  for x in miss_plot]
    else:            found   += [f"plot:{x}"  for x in plot_points]

    # jazyky
    if languages:
        # normalizuj kódy a názvy
        langs_norm = {_norm_txt(x) for x in languages if _norm_txt(x)}
        spoken = [l.get("iso_639_1","") for l in (detail.get("spoken_languages") or [])]
        spoken += [detail.get("original_language","")]
        spoken += [(_norm_txt(l.get("english_name","")) or "") for l in (detail.get("spoken_languages") or [])]
        spoken = [x for x in spoken if x]
        spoken_norm = {_norm_txt(x) for x in spoken if _norm_txt(x)}
        if not langs_norm.issubset(spoken_norm):
            for x in langs_norm:
                if x not in spoken_norm:
                    missing.append(f"lang:{x}")
        else:
            for x in languages:
                found.append(f"lang:{x}")

    # země
    if countries:
        if kind == "movie":
            cset = { (c.get("iso_3166_1") or "").upper() for c in (detail.get("production_countries") or []) }
        else:
            cset = { str(c).upper() for c in (detail.get("origin_country") or []) }
        # akceptuj i textové názvy – převedeme nejběžnější aliasy na kódy
        # (zde jednoduchý přístup – vyžadujeme aspoň shodu kódu, názvy se často liší)
        norm_countries = {x.upper() for x in countries}
        if not norm_countries.intersection(cset) and not norm_countries.issubset(cset):
            for x in countries:
                if x.upper() not in cset:
                    missing.append(f"country:{x}")
        else:
            for x in countries:
                found.append(f"country:{x}")

    # žánry
    if genres_req:
        gnorm = {_norm_txt(g) for g in genres}
        wantg = {_norm_txt(g) for g in genres_req}
        if not wantg.issubset(gnorm):
            for x in genres_req:
                if _norm_txt(x) not in gnorm:
                    missing.append(f"genre:{x}")
        else:
            for x in genres_req:
                found.append(f"genre:{x}")

    # forbidden (nesmí se objevit)
    if forbid:
        for fb in forbid:
            nf = _norm_txt(fb)
            if nf and nf in corpus_norm:
                missing.append(f"forbidden:{fb}")

    ok_all = (year_ok and not missing)

    dbg = {
        "year": detail_year,
        "year_ok": year_ok,
        "found": found[:50],
        "missing": missing[:50],
        "title": item.get("title") or item.get("name") or "",
        "id": item.get("id"),
        "kind": kind,
    }
    return ok_all, dbg




# ═══════════════════════════════════════════════════════════════════════════════
#  ALIASY PRO ZPĚTNOU KOMPATIBILITU
# ═══════════════════════════════════════════════════════════════════════════════
# Tyto aliasy umožňují použít funkce s původními názvy z plugin.py

_ai_log = ai_log
_run_ai_with_progress = run_ai_with_progress
_ai_verify_tmdb_match = ai_verify_tmdb_match
