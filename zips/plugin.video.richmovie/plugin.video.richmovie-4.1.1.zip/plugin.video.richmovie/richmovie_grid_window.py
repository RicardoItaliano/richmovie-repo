# -*- coding: utf-8 -*-
"""RichMovie 4.0 — reusable Browse grid (WindowXMLDialog) — Φ1.

Jedno feed-parametrizované okno: poster mřížka pro Trendy/Top/Žánry/Podobné/
výsledky hledání. Data přes richmovie_feed.get_feed (SSOT).

Φ-R1+R2 (2026-06-12): feed fetch běží v pozadí (uc.fetch_async) — okno se
otevře okamžitě se skeleton stavem („Načítám…"), chyba = viditelný error stav.
Klik → custom Detail (rm_detail) NAD mřížkou. Estoril. Best-effort.
XML: resources/skins/default/1080i/RichMovieGrid.xml.
"""
from __future__ import annotations

import urllib.parse

import xbmc
import xbmcgui

import richmovie_ui_common as uc
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/Grid] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.grid", "RichMovie/Grid")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "Grid] " + str(msg), level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"
_XML = "RichMovieGrid.xml"
_RES = "1080i"
_BASE = f"plugin://{_ADDON_ID}/"
_GRID = 6000
_TAB_TREND = 6101
_TAB_TOP = 6102
_TAB_GENRE = 6103
_BACK = 9000
_RETRY = 9001
_SORT = 9002
_FILTER = 9003

# Sub-taby per feed rodina (Φ-P): Trendy / TOP / Žánry (žánry jen filmy —
# TMDb discover_by_genre je movie-only).
_TAB_FAMILIES = {
    "movies": {"feeds": ("browse_movies", "trending_movies", "top_movies", "genre_movies"),
               "trend": "trending_movies", "top": "top_movies", "genres": True},
    "tv": {"feeds": ("browse_tv", "trending_tv", "top_tv"),
           "trend": "trending_tv", "top": "top_tv", "genres": False},
}

# 2026-07-07 (Richie): otevření Filmy/Seriály má ukázat JEN záložky (Trendy/
# TOP/Žánry) a nechat uživatele vybrat — NEnačítat hned Trendy. „Landing" feedy
# se rozpoznají v _tab_family (rodina → záložky fungují), ale grid je nefetchuje.
_LANDING_FEEDS = {"browse_movies", "browse_tv"}


def _tab_family(feed):
    for fam in _TAB_FAMILIES.values():
        if feed in fam["feeds"]:
            return fam
    return None


class RichMovieGridWindow(uc.RMNavMixin, xbmcgui.WindowXMLDialog):

    def __init__(self, *a, feed="", title="", q="", genre_id="", ref_id="", **kw):
        super().__init__(*a, **kw)
        self._feed = feed
        self._title = title or "Procházet"
        self._q = q
        self._genre_id = genre_id
        self._ref_id = ref_id
        self._rm_closed = False
        self._fetch_gen = 0   # generation guard: starý fetch nesmí přepsat nový
        self._all_items = []  # P1-1/P1-2: raw položky pro řazení/filtr
        self._sort_mode = "default"  # default|year|rating|title
        self._filter_text = ""

    def onInit(self) -> None:
        self._sync_tabs()
        # Φ5 (2026-08-08): indikátor offline režimu (SSOT ui_common) — grid je po
        # Home nejčastější obrazovka a při výpadku sítě právě tady uživatel pozná,
        # že nabídka je z uložených dat, ne čerstvá.
        try:
            uc.apply_offline_state(self)
        except Exception:
            pass
        # Landing (Filmy/Seriály): žádné načítání, jen záložky + hint; fokus na
        # záložku Trendy, ať uživatel hned vidí a klikne, co chce procházet.
        if self._feed in _LANDING_FEEDS:
            self.setProperty("rm_g_title",
                             f"{self._title} — vyber: Trendy / Nejlepší"
                             + (" / Žánry" if self._feed == "browse_movies" else ""))
            try:
                self.getControl(_GRID).reset()
            except Exception:
                pass
            uc.focus_first(self, [_TAB_TREND, _GRID])
            return
        self.setProperty("rm_g_title", self._title)
        self._start_fetch()

    def _start_fetch(self) -> None:
        self._fetch_gen += 1
        gen = self._fetch_gen
        feed, q, genre_id, ref_id = self._feed, self._q, self._genre_id, self._ref_id

        def _fetch():
            import richmovie_feed
            # raise_on_error → síťová chyba spustí _err (retry stav), ne prázdný grid
            return richmovie_feed.get_feed(feed, q=q, genre_id=genre_id,
                                           ref_id=ref_id, raise_on_error=True)

        def _apply(items):
            if gen != self._fetch_gen:
                return  # mezitím přepnutý tab — starý výsledek zahodit
            self._apply_items(items)

        def _err(exc):
            if gen != self._fetch_gen:
                return
            self._fetch_failed(exc)

        uc.fetch_async(self, _fetch, _apply, tag="grid", on_error=_err)

    # ------------------------------------------------------------------ taby
    def _sync_tabs(self) -> None:
        fam = _tab_family(self._feed)
        self.setProperty("rm_g_tabs", "1" if fam else "")
        self.setProperty("rm_g_genres", "1" if (fam and fam["genres"]) else "")
        if not fam:
            return
        # Landing: žádná záložka není aktivní (uživatel ještě nevybral).
        if self._feed in _LANDING_FEEDS:
            self.setProperty("rm_g_tab", "")
            return
        tab = "genres" if self._feed == "genre_movies" else (
            "top" if self._feed == fam["top"] else "trend")
        self.setProperty("rm_g_tab", tab)

    def _switch_feed(self, feed, title, genre_id="") -> None:
        self._feed = feed
        self._genre_id = genre_id
        self._title = title
        self.setProperty("rm_g_title", title)
        self.clearProperty("rm_error_grid")
        # R2-P2-6: přepnutí tabu/žánru aktualizuje NavStack routu — playback
        # replay pak vrátí AKTUÁLNÍ feed, ne stale kopii z otevření okna.
        uc.nav_update(getattr(self, "_rm_nav_id", ""),
                      {"feed": feed, "title": title, "genre_id": genre_id,
                       "q": self._q, "ref_id": self._ref_id})
        self._sync_tabs()
        try:
            self.getControl(_GRID).reset()
        except Exception:
            pass
        self._start_fetch()

    def _pick_sort(self) -> None:
        """P1-1: řazení gridu (in-memory nad načtenými položkami)."""
        labels = ["Výchozí (dle zdroje)", "Nejnovější (rok)", "Nejlépe hodnocené", "Název A–Z"]
        modes = ["default", "year", "rating", "title"]
        try:
            cur = modes.index(self._sort_mode)
        except ValueError:
            cur = 0
        sel = xbmcgui.Dialog().select("Seřadit podle", labels, preselect=cur)
        if sel < 0 or modes[sel] == self._sort_mode:
            return
        self._sort_mode = modes[sel]
        self._render()
        uc.focus_first(self, [_GRID, _SORT])

    def _pick_filter(self) -> None:
        """P1-2: hledání uvnitř sekce (filtr dle názvu, in-memory)."""
        kb = xbmc.Keyboard(self._filter_text, "Filtrovat v této sekci")
        kb.doModal()
        if not kb.isConfirmed():
            return
        self._filter_text = (kb.getText() or "").strip()
        self._render()
        uc.focus_first(self, [_GRID, _FILTER])

    def _reload(self) -> None:
        """Reset mřížky + znovu načíst aktuální feed (po odebrání položky)."""
        try:
            self.getControl(_GRID).reset()
        except Exception:
            pass
        self._start_fetch()

    def _click_tab(self, controlId) -> None:
        fam = _tab_family(self._feed)
        if not fam:
            return
        is_tv = fam is _TAB_FAMILIES["tv"]
        base = "Seriály" if is_tv else "Filmy"
        if controlId == _TAB_TREND:
            self._switch_feed(fam["trend"], f"{base} – Trendy")
        elif controlId == _TAB_TOP:
            self._switch_feed(fam["top"], f"{base} – TOP hodnocené")
        elif controlId == _TAB_GENRE and fam["genres"]:
            import richmovie_feed
            genres = richmovie_feed.get_genres()
            if not genres:
                uc.notify_error("Žánry se nepodařilo načíst.", log_tag="Grid")
                return
            names = [g.get("name") or "?" for g in genres]
            sel = xbmcgui.Dialog().select("Vyber žánr", names)
            if sel < 0:
                return
            g = genres[sel]
            self._switch_feed("genre_movies", f"Filmy – {g.get('name')}",
                              genre_id=str(g.get("id") or ""))

    # ------------------------------------------------------------------ data
    def _apply_items(self, items) -> None:
        self._all_items = list(items or [])
        self._render()

    def _render(self) -> None:
        # filtr (P1-2) + řazení (P1-1) nad raw položkami
        items = self._all_items
        ft = self._filter_text.strip().lower()
        if ft:
            items = [it for it in items if ft in (it.get("title") or "").lower()]
        sm = self._sort_mode
        if sm == "year":
            items = sorted(items, key=lambda it: int(it.get("year") or 0), reverse=True)
        elif sm == "rating":
            items = sorted(items, key=lambda it: float(it.get("rating") or 0), reverse=True)
        elif sm == "title":
            items = sorted(items, key=lambda it: (it.get("title") or "").lower())
        self.setProperty("rm_g_subfilter",
                         f"Filtr: {self._filter_text}" if ft else "")
        # watched ✔ overlay (P0-1): jeden lookup setu per render, ne per item
        try:
            import richmovie_history as _hist
            watched_movies = _hist.watched_movie_ids()
        except Exception:
            watched_movies = set()
        grid = self.getControl(_GRID)
        grid.reset()
        for it in (items or []):
            yr = it.get("year") or ""
            label = f"{it.get('title') or ''}{f' ({yr})' if yr else ''}"
            li = xbmcgui.ListItem(label)
            poster = uc.img(it.get("poster_path"))
            if poster:
                li.setArt({"poster": poster, "thumb": poster, "icon": poster})
            tmdb = str(it.get("tmdb_id") or "")
            mtype = it.get("kind") or "movie"
            li.setProperty("rm_tmdb", tmdb)
            li.setProperty("rm_mtype", mtype)
            li.setProperty("rm_title", it.get("title") or "")
            li.setProperty("rm_click_url", it.get("click_url") or "")
            li.setProperty("rm_click_kind", it.get("click_kind") or "")
            if mtype == "movie" and tmdb in watched_movies:
                li.setProperty("rm_watched", "1")
            grid.addItem(li)
        try:
            uc.focus_first(self, [_GRID])
        except Exception:
            pass

    def _fetch_failed(self, exc) -> None:
        _log(f"fetch({self._feed}): {exc}", xbmc.LOGWARNING)
        self.setProperty("rm_error_grid", "1")
        try:
            uc.focus_first(self, [_RETRY, _BACK])
        except Exception:
            pass

    # ------------------------------------------------------------------ input
    def onClick(self, controlId: int) -> None:
        if controlId == _BACK:
            self.close()
            return
        if controlId == _RETRY:
            self.clearProperty("rm_error_grid")
            self._start_fetch()
            return
        if controlId == _SORT:
            self._pick_sort()
            return
        if controlId == _FILTER:
            self._pick_filter()
            return
        if controlId in (_TAB_TREND, _TAB_TOP, _TAB_GENRE):
            try:
                self._click_tab(controlId)
            except Exception as exc:
                uc.notify_error("Přepnutí se nepodařilo.", log_tag="Grid")
                _log(f"tab: {exc}", xbmc.LOGWARNING)
            return
        if controlId != _GRID:
            return
        try:
            li = self.getControl(_GRID).getSelectedItem()
            if not li:
                return
            click_url = li.getProperty("rm_click_url")
            if click_url:
                if li.getProperty("rm_click_kind") == "play":
                    # R2-P2-10: debounce parita s Home CW/hero — dvojklik jinak
                    # spustil 2× mark + 2× continue_watching + 2× PlayMedia
                    if not uc.play_debounce():
                        return
                    # Φ2: descriptor PŘED Dialog.Close (snapshot integrita)
                    uc.mark_play_from_ui()
                    # přehrávání nesmí běžet pod dialogy → složit celý stack
                    xbmc.executebuiltin("Dialog.Close(all,true)")
                xbmc.executebuiltin(f"RunPlugin({click_url})")
                return
            tmdb = li.getProperty("rm_tmdb")
            if not tmdb:
                return
            q = urllib.parse.urlencode({
                "action": "rm_detail", "tmdb_id": tmdb,
                "kind": li.getProperty("rm_mtype") or "movie",
                "title": li.getProperty("rm_title") or "",
            })
            # Detail otevři NAD mřížkou (Back se vrátí do mřížky) — nezavírat.
            xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
        except Exception as exc:
            uc.notify_error("Detail se nepodařilo otevřít.", log_tag="Grid")
            _log(f"onClick: {exc}", xbmc.LOGWARNING)

    # Φ5: mapování feed → datová doména (invalidation kontrakt, viz ui_common)
    # R3-P2-3: + watch_history_movies → watched (✔ badge po dokoukání/toggle)
    _FEED_DOMAINS = {"my_list": "my_list", "ai_recs": "ai", "cw": "cw",
                     "watch_history_movies": "watched"}

    def on_window_action(self, action) -> None:
        # Back/Stop/device latch řeší uc.RMNavMixin.onAction (Φ1 DRY)
        if action.getId() == xbmcgui.ACTION_CONTEXT_MENU:
            self._context_menu()

    def on_data_changed(self, domains) -> None:
        """Φ5 (audit A09): grid nad mutovatelným feedem (Můj seznam / AI tipy /
        CW) se přenačte, když child okno (Detail…) data změnilo."""
        dom = self._FEED_DOMAINS.get(self._feed or "")
        if dom and dom in domains:
            try:
                self._reload()
            except Exception as exc:
                _log(f"on_data_changed: {exc}", xbmc.LOGWARNING)

    def _context_menu(self) -> None:
        """Context menu na posteru — nejčastější akce rovnou (Netflix vzor):
        film → vybrat stream; seriál → sezóny/epizody; + Detail / Můj seznam."""
        try:
            if self.getFocusId() != _GRID:
                return
            li = self.getControl(_GRID).getSelectedItem()
            if not li:
                return
            tmdb = li.getProperty("rm_tmdb")
            if not tmdb:
                return
            mtype = li.getProperty("rm_mtype") or "movie"
            title = li.getProperty("rm_title") or li.getLabel()

            opts, acts = [], []
            if mtype == "tv":
                opts.append("Sezóny a epizody"); acts.append("episodes")
            else:
                opts.append("▶ Vybrat stream"); acts.append("play")
            opts.append("Detail"); acts.append("detail")
            opts.append("Podobné"); acts.append("similar")
            opts.append("+ Můj seznam"); acts.append("mylist")
            if mtype == "movie":
                import richmovie_history as _h
                _seen = _h.watched_movie_contains(tmdb)
                opts.append("Označit jako nezhlédnutý" if _seen else "Označit jako zhlédnutý ✔")
                acts.append("watched")
            if self._feed == "my_list":
                opts.append("Odebrat z Mého seznamu"); acts.append("unlist")
            if self._feed == "ai_recs":
                opts.append("Už jsem viděl (skrýt tip)"); acts.append("ai_seen")

            sel = xbmcgui.Dialog().contextmenu(opts)
            if sel < 0:
                return
            act = acts[sel]
            if act == "episodes":
                q = urllib.parse.urlencode({"action": "rm_episodes", "tv_id": tmdb,
                                            "tv_name": title})
                xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
            elif act == "play":
                import xbmcaddon
                uc.play_picker_first(
                    xbmcaddon.Addon(_ADDON_ID), action="auto",
                    poster=li.getArt("poster"), title=title, tmdb=tmdb)
            elif act == "detail":
                q = urllib.parse.urlencode({"action": "rm_detail", "tmdb_id": tmdb,
                                            "kind": mtype, "title": title})
                xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
            elif act == "similar":
                feed = "similar_tv" if mtype == "tv" else "similar_movies"
                q = urllib.parse.urlencode({"action": "rm_grid", "feed": feed,
                                            "ref_id": tmdb, "title": f"Podobné: {title}"})
                xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
            elif act == "mylist":
                import richmovie_history as hist
                now_in = hist.my_list_toggle(tmdb_id=tmdb, kind=mtype, title=title)
                _rm_notif(
                    "Přidáno do Mého seznamu" if now_in else "Odebráno",
                    xbmcgui.NOTIFICATION_INFO,
                    2000,
                    "RichMovie",
                    sound=False,
                )
            elif act == "unlist":
                import richmovie_history as hist
                hist.my_list_remove(tmdb_id=tmdb, kind=mtype)
                self._reload()  # refresh gridu Mého seznamu
            elif act == "ai_seen":
                import richmovie_history as hist
                hist.ai_dismiss(tmdb, mtype)
                self._reload()  # refresh AI gridu
            elif act == "watched":
                import richmovie_history as hist
                now_seen = hist.watched_movie_toggle(tmdb)
                li.setProperty("rm_watched", "1" if now_seen else "")
                _rm_notif(
                    "Označeno jako zhlédnuté ✔" if now_seen else "Označeno jako nezhlédnuté",
                    xbmcgui.NOTIFICATION_INFO,
                    2000,
                    "RichMovie",
                    sound=False,
                )
        except Exception as exc:
            uc.notify_error("Akce se nepodařila.", log_tag="Grid")
            _log(f"context: {exc}", xbmc.LOGWARNING)

    def close(self):  # noqa: A003 — Kodi API jméno
        self._rm_closed = True
        super().close()


def open_grid(addon, feed="", title="", q="", genre_id="", ref_id="") -> None:
    """Otevře reusable Browse grid. Best-effort."""
    try:
        w = RichMovieGridWindow(_XML, addon.getAddonInfo("path"), "default", _RES,
                                feed=feed, title=title, q=q, genre_id=genre_id,
                                ref_id=ref_id)
        _nav_id = uc.nav_push("rm_grid", {"feed": feed, "title": title, "q": q,
                                          "genre_id": genre_id, "ref_id": ref_id})  # Φ1
        w._rm_nav_id = _nav_id  # R2-P2-6: okno umí routu aktualizovat (taby)
        try:
            w.doModal()
        finally:
            uc.nav_remove(_nav_id)
        w._rm_closed = True
        del w
    except Exception as exc:
        _log(f"open_grid: {exc}", xbmc.LOGWARNING)
