# -*- coding: utf-8 -*-
"""
richmovie_quality — SSOT třídy rozlišení streamu a řadicího klíče výpisu streamů.

Proč (analýza 29.09.2026, `Handoff/PLAN_stream_order_20260929.md`):
  Z1  kvalita se určovala jen z VÝŠKY obrazu — nejbližší standard k výšce. Širokoúhlý film 1080p má ale
      1920×800 (2,39 : 1), takže vycházel jako „720p“; 1280×536 jako „576p“, 3840×1616 (4K) jako „1080p“.
      V MediaInfo cache PC bylo tak zařazeno špatně 500 z 2 423 souborů (21 %).
  Z2  štítek kvality se bral z NÁZVU souboru, řazení z výšky obrazu → „1080P“ pod „720P“.
  Z3  čtyři různá řazení téhož seznamu (výpis filmu, výpis dílu, výběr streamu v novém vzhledu, automatický
      výběr dalšího dílu) a dvě kopie `_quality_rank` — u filmu český dabing nerozhodoval vůbec a automaticky
      vybraný stream nebyl první řádek výpisu.

Rozlišení je vlastnost ŠÍŘKY i výšky:

    efektivní výška = max(výška, šířka × 9 / 16)

Film 1920×800 má efektivní výšku 1080 (šířka 1920 = Full HD), 4 : 3 video 1440×1080 také 1080.

Rozhodnutí Richieho 29.09.2026: D1 kvalita, hned za ní český dabing (kdo chce dabing vždy, má ho z preference
profilu — ta jde před kvalitu); D6 prodloužené verze a dvojdíly řadit mezi ostatní, ne na konec.

Modul je čistý (žádné `xbmc`, žádný import enginu) — testuje ho harness (scénáře 81 a 84).
"""
from __future__ import annotations

import re
from typing import Any, Dict, Optional, Tuple

# Standardní třídy (výška v řádcích), od nejlepší.
STANDARDS: Tuple[int, ...] = (2160, 1080, 720, 576, 480, 360, 320, 240)
ASPECT_W, ASPECT_H = 16, 9


def _to_int(value: Any) -> int:
    try:
        return max(0, int(float(value or 0)))
    except (TypeError, ValueError):
        return 0


def effective_height(width: Any, height: Any) -> int:
    """Výška, kterou by obraz měl při poměru 16 : 9 a téže šířce — nebo skutečná výška, je-li větší."""
    w, h = _to_int(width), _to_int(height)
    if w <= 0:
        return h
    if h > w:
        # video na výšku (1080×1920) má kvalitu obrazu 1080p — delší strana je „šířka“
        w, h = h, w
    return max(h, int(round(w * ASPECT_H / float(ASPECT_W))))


def nearest_standard(height: Any) -> int:
    """Nejbližší standardní třída k výšce; 0 = neznámá."""
    h = _to_int(height)
    if h <= 0:
        return 0
    return min(STANDARDS, key=lambda s: (abs(h - s), -s))


def resolution_class(width: Any, height: Any) -> int:
    """Třída rozlišení (2160, 1080, 720, …) z rozměrů obrazu; 0 = rozměry neznámé."""
    return nearest_standard(effective_height(width, height))


def class_from_label(label: Any) -> int:
    """Třída z popisku kvality podle NÁZVU souboru (`1080p`, `2160P`, `4k`); 0 = popisek třídu nenese
    (`webrip`, `other`, `cam`)."""
    s = str(label or "").strip().lower()
    if s in ("4k", "uhd"):
        return 2160
    if s.endswith("p") and s[:-1].isdigit():
        n = int(s[:-1])
        return n if n in STANDARDS else nearest_standard(n)
    return 0


def resolve(flags: Optional[Dict[str, Any]], ws_width: Any = None, ws_height: Any = None,
            name_label: Any = "") -> Tuple[int, str]:
    """Třída rozlišení streamu a zdroj údaje. Priorita: MediaInfo (změřeno ze souboru) → rozměry
    z Webshare `/search` → popisek z názvu. Vrací (třída, zdroj), zdroj ∈ mi2 | ws | name | none."""
    fl = flags if isinstance(flags, dict) else {}
    if not fl.get("fail"):
        c = resolution_class(fl.get("video_w"), fl.get("video_h") or fl.get("video_height"))
        if c:
            return c, "mi2"
    c = resolution_class(ws_width, ws_height)
    if c:
        return c, "ws"
    c = class_from_label(name_label)
    if c:
        return c, "name"
    return 0, "none"


def class_label(res_class: int) -> str:
    """Popisek třídy pro telemetrii: 1080 → `1080p`; 0 → prázdný řetězec."""
    return ("%dp" % int(res_class)) if res_class else ""


# ═════════════════════════════════════════════════════════════════════════════
#  ŘAZENÍ VÝPISU STREAMŮ — JEDNO PRAVIDLO (Φ-D, 30.09.2026)
# ═════════════════════════════════════════════════════════════════════════════
# Pořadí klíče (nižší = výš ve výpisu):
#   1. relevance ručního hledání · 2. preferovaný zvuk · 3. preferované titulky · 4. nesedí délka
#   5. penalizace názvu (cizí seriál) · 6. stejná verze jako minulý díl · 7. KVALITA · 8. ČESKÝ DABING
#   9. balast (trailer, sample…) · 10. potvrzená délka (D9: JEN mezi streamy stejné kvality a dabingu — neznámá
#   délka nesmí shodit 4K pod 1080p jen proto, že MediaInfo ještě neběžela) · 11. ★ shoda · 12. velikost · 13. skóre
# Je to JEN pořadí — filtr (ReleaseFilter) se tím nemění.
LABEL_DVDRIP, LABEL_WEBRIP, LABEL_CAM, LABEL_OTHER = "DVDRip", "WEBRip", "CAM", "OTHER"
RANK_OTHER = 99
_DVDRIP_RE = re.compile(r"\bDVD[-_. ]?RIP\b", re.I)
_NAME_RES_RE = re.compile(r"(?<!\d)(2160|1080|720|576|480|360|320|240)p(?!\d)", re.I)
JUNK_MARKERS: Tuple[str, ...] = ("watch party", "behind the scenes", "bts", "sample", "trailer", "extras")

RUNTIME_TOLERANCE = 0.10          # ±10 % proti referenční délce (hodnota z původního výpisu)
# D6: prodloužená / režisérská verze je TÝŽ film. Nejdelší běžné prodloužení je +31 % (Pán prstenů: Dvě věže
# 235 min proti 179 min); strop +50 % nechává rezervu a pořád odliší dvojfilm nebo jiný obsah.
EXTENDED_MAX_RATIO = 1.50
MULTI_EPISODE_MAX = 3             # dvojdíl / trojdíl v jednom souboru (seriál)
FS_ROUNDED_STEP_S = 3600          # Fastshare hlásí délku zaokrouhlenou na hodiny → taková délka není důkaz

RUNTIME_OK, RUNTIME_MISMATCH, RUNTIME_UNKNOWN = "ok", "mismatch", "unknown"


def _field(item: Any, name: str, default: Any = None) -> Any:
    """Pole streamu z objektu `Release` i ze slovníku (výběr streamu v novém vzhledu)."""
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)


def quality_rank(flags: Optional[Dict[str, Any]], ws_width: Any, ws_height: Any, name_label: Any,
                 name: Any = "") -> Tuple[int, str]:
    """(pořadí, štítek) kvality streamu — JEDNA pravda pro řazení i pro štítek ve výpisu.

    Rozměry obrazu (MediaInfo, pak Webshare) mají přednost před názvem souboru; štítek je vždy třída, podle
    které se řadí. Bez rozměrů: DVDRip / WEBRip / CAM podle názvu, pak `NNNNp` z názvu, jinak OTHER."""
    res_class, _src = resolve(flags, ws_width, ws_height, "")
    if res_class:
        return STANDARDS.index(res_class), "%dP" % res_class
    label = str(name_label or "").strip().lower()
    nm = str(name or "")
    if _DVDRIP_RE.search(nm) or label == "dvdrip":
        return len(STANDARDS), LABEL_DVDRIP
    if label == "webrip":
        return len(STANDARDS) + 1, LABEL_WEBRIP
    if label == "cam":
        return len(STANDARDS) + 2, LABEL_CAM
    m = _NAME_RES_RE.search(label) or _NAME_RES_RE.search(nm)
    if m:
        std = int(m.group(1))
        return STANDARDS.index(std), "%dP" % std
    c = class_from_label(label)
    if c:
        return STANDARDS.index(c), "%dP" % c
    return RANK_OTHER, LABEL_OTHER


def quality_of(item: Any, flags: Optional[Dict[str, Any]] = None) -> Tuple[int, str]:
    """`quality_rank` pro stream (objekt `Release` nebo slovník)."""
    return quality_rank(flags, _field(item, "ws_width"), _field(item, "ws_height"),
                        _field(item, "quality", ""), _field(item, "name", ""))


def cz_rank(flags: Optional[Dict[str, Any]], audios: Any) -> int:
    """0 = český dabing jistě (MediaInfo) · 1 = podle názvu souboru · 2 = bez českého dabingu."""
    fl = flags if isinstance(flags, dict) else {}
    if not fl.get("fail"):
        if fl.get("cz_dub"):
            return 0
        if fl.get("aud"):
            # zvukové stopy ZMĚŘENÉ ze souboru mají přednost před názvem („CZ“ v názvu bývají titulky);
            # stejně je vidí výběr streamu v novém vzhledu (cross-check Pro B-P3)
            audios = fl.get("aud")
    try:
        if "CZ" in {str(a).strip().upper()[:2] for a in (audios or []) if a}:
            return 1
    except Exception:
        pass
    return 2


def junk_rank(name: Any) -> int:
    """1 = balast (watch party, trailer, sample, extras…), 0 = běžný soubor."""
    n = str(name or "").lower()
    return 1 if any(m in n for m in JUNK_MARKERS) else 0


def duration_s(item: Any, flags: Optional[Dict[str, Any]]) -> Tuple[float, str]:
    """Délka streamu v sekundách a zdroj (ws | est | mi2 | none). Délka z Fastshare zaokrouhlená na celé
    hodiny se NEBERE (není to měření) — použije se MediaInfo, nebo je délka neznámá."""
    fl = flags if isinstance(flags, dict) else {}
    src = str(_field(item, "source", "webshare") or "webshare")

    def _num(v: Any) -> float:
        try:
            f = float(str(v).strip())
            return f if f > 0 else 0.0
        except (TypeError, ValueError):
            return 0.0

    def _trusted(sec: float) -> bool:
        return not (src == "fastshare" and sec > 0 and int(sec) % FS_ROUNDED_STEP_S == 0)

    ws = _num(_field(item, "ws_len_s"))
    if ws and _trusted(ws):
        return ws, "ws"
    est = _num(_field(item, "est_min")) * 60.0
    if est and _trusted(est):
        return est, "est"
    if not fl.get("fail"):
        for k in ("duration_s", "duration", "dur_s"):
            mi = _num(fl.get(k))
            if mi:
                return mi, "mi2"
    return 0.0, "none"


def runtime_verdict(dur_s: float, refs_min: Any, kind: str = "movie") -> str:
    """Sedí délka streamu k titulu? `ok` / `mismatch` / `unknown` (délka nebo reference chybí).

    `ok` je: ±10 % kterékoli referenční délky; u FILMU i delší verze do +50 % nejdelší reference
    (prodloužená verze); u DÍLU i dvojnásobek / trojnásobek (dvojdíl v jednom souboru)."""
    try:
        refs = sorted({float(x) * 60.0 for x in (refs_min or []) if float(x) > 0})
    except (TypeError, ValueError):
        refs = []
    if not refs or not dur_s or dur_s <= 0:
        return RUNTIME_UNKNOWN
    for ref in refs:
        if abs(dur_s - ref) <= ref * RUNTIME_TOLERANCE:
            return RUNTIME_OK
    if kind == "movie":
        if refs[-1] < dur_s <= refs[-1] * EXTENDED_MAX_RATIO:
            return RUNTIME_OK
    else:
        for ref in refs:
            for k in range(2, MULTI_EPISODE_MAX + 1):
                if abs(dur_s - k * ref) <= k * ref * RUNTIME_TOLERANCE:
                    return RUNTIME_OK
    return RUNTIME_MISMATCH


# --------------------------------------------------------------------------- #
# Dolby Vision podle schopností zařízení (noc 03.11.2026, 4.0.6, plán Φ3)
# --------------------------------------------------------------------------- #
# Bětčin Mac: 4K stream s Dolby Vision = černý obraz (Kodi 21 na macOS/Windows DV neumí, `OutputPicture - timeout
# waiting for buffer`). Profil 5 nemá kompatibilní vrstvu → bez DV nikdy obraz; 7/8 (HDR10/SDR/HLG základ) hrají.
# D3 plánu: jen POŘADÍ, nikdy filtr. „ne“ (profil 5) jde za všechny hratelné (jako vadný soubor), „asi ne“ (DV bez
# známého profilu) jen za hratelné téže kvality. Zařízení, které DV umí (`richmovie_device_env.dv_supported`), nic nemění.
DV_OK = 0
DV_MAYBE = 1
DV_NO = 2
_DV_NAME_RE = re.compile(r"(?<![a-z0-9])(dv|dovi|dolby[\s._-]?vision)(?![a-z0-9])", re.I)
_HDR_NAME_RE = re.compile(r"(?<![a-z0-9])(hdr10\+?|hdr|hlg)(?![a-z0-9])", re.I)
_DV_COMPAT_OK = ("hdr10", "sdr", "hlg")


def dv_playability(flags: Optional[Dict[str, Any]], name: Any, dv_supported: bool) -> int:
    """Přehraje TOTO zařízení obraz streamu? DV_OK / DV_MAYBE / DV_NO (čistá funkce, harness scénář 94).
    MediaInfo (Gate probe) má přednost před názvem souboru; název rozhoduje jen bez MediaInfo."""
    if dv_supported:
        return DV_OK
    fl = flags if isinstance(flags, dict) else {}
    hdr = str(fl.get("hdr") or "").upper()
    if hdr and hdr != "DOVI":
        return DV_OK                     # MediaInfo zná jiné HDR / SDR → základ hraje (i když název říká DV)
    compat = str(fl.get("dv_compat") or "").lower()
    prof = fl.get("dv_profile")
    if hdr == "DOVI":
        # profil 5 nemá kompatibilní vrstvu ze specifikace — má přednost před textem kompatibility (cross-check Argon
        # P5/P8: statická metadata SMPTE ST 2086 u profilu 5 by jinak daly „hdr10“ a černý obraz nahoře)
        if prof == 5 or compat == "none":
            return DV_NO
        if compat in _DV_COMPAT_OK or prof in (7, 8, 9):
            return DV_OK
    text = str(name or "")
    if hdr != "DOVI" and not _DV_NAME_RE.search(text):
        return DV_OK
    if _HDR_NAME_RE.search(text):
        return DV_OK                     # „DV.HDR10“ / „DoVi HDR“ = hybrid s HDR10 vrstvou
    return DV_MAYBE


def dv_label_prefix(rank: int) -> str:
    """Štítek ve výpisu streamů (jen na zařízení bez DV)."""
    if rank == DV_NO:
        return "⚠ DV · "
    if rank == DV_MAYBE:
        return "DV? · "
    return ""


SORT_KEY_FIELDS: Tuple[str, ...] = ("ws_rel", "pref_audio", "pref_subs", "runtime_mismatch", "title_penalty",
                                    "continuity", "quality", "dv_maybe", "cz_dub", "junk", "runtime_unconfirmed",
                                    "no_match", "neg_size", "score")


def stream_sort_key(item: Any, flags: Optional[Dict[str, Any]] = None, pref_terms: Tuple[int, int] = (0, 0),
                    continuity_rank: int = 0, score_key: Tuple = (), dv_rank: int = DV_OK) -> Tuple:
    """SSOT řadicí klíč streamu (nižší = výš; pole viz `SORT_KEY_FIELDS`). `item` = `Release` nebo slovník;
    `flags` = MediaInfo z cache; `pref_terms` = (zvuk, titulky) podle preference diváka; `continuity_rank`
    = stejná verze jako minulý díl; `score_key` = skóre enginu jako n-tice; `dv_rank` = `dv_playability`
    (DV_MAYBE jen za hratelné téže kvality; DV_NO řadí výš `plugin._listing_sort_key`)."""
    try:
        size = int(float(_field(item, "size", 0) or 0))
    except (TypeError, ValueError):
        size = 0
    if not size:
        try:
            size = int(float(_field(item, "size_mb", 0) or 0)) * 1_048_576
        except (TypeError, ValueError):
            size = 0
    q_rank, _label = quality_of(item, flags)
    return (
        int(_field(item, "ws_rel", 0) or 0),
        int(pref_terms[0]), int(pref_terms[1]),
        1 if _field(item, "runtime_mismatch", False) else 0,
        int(_field(item, "title_penalty", 0) or 0),
        int(continuity_rank or 0),
        q_rank,
        1 if int(dv_rank or 0) == DV_MAYBE else 0,
        cz_rank(flags, _field(item, "audios", None)),
        junk_rank(_field(item, "name", "")),
        0 if _field(item, "runtime_confirmed", False) else 1,
        0 if _field(item, "match", False) else 1,
        -size,
        tuple(score_key or ()),
    )
