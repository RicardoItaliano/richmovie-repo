# -*- coding: utf-8 -*-
"""
RichMovie — meziprocesový „claim" pro práci, která smí běžet nejvýš jednou
(3.5.118, 21.08.2026).

PROČ
----
Kodi spouští každou invokaci pluginu jako nový interpret. Modulový
`threading.Lock` tedy chrání jen jeden proces — a instalátor kolekcí startovaný
z `_root()` tak do 3.5.117 vznikal znovu při KAŽDÉM návratu do kořenového menu,
bez jakékoli vzájemné vazby (nález cross-check Pro, 21.08.2026). Jediný stav
sdílený napříč procesy jedné Kodi session jsou `Window(10000)` properties.

KONTRAKT
--------
    token = claim("collections_install", ttl_s=600)
    if token is None:
        return                      # běží jinde (a ještě nevypršel)
    try:
        ...práce...
    finally:
        release("collections_install", token)

TTL je pojistka proti sirotkům: proces, který claim drží, může být Kodi killnut
(5s okno při shutdownu) dřív, než se dostane k `release`. Po TTL je claim
považován za mrtvý a smí ho převzít další. TTL si volí volající a MUSÍ ho odvodit
z horního odhadu trvání práce (ne odhad „od oka" — do docstringu napsat, z čeho
číslo vzniklo).

CO TO NENÍ
----------
Není to mutex. Window properties nejsou atomické, takže dva procesy, které
zavolají `claim` ve stejné milisekundě, mohou oba uspět. Pro práci, kterou tenhle
modul chrání (idempotentní instalace cache s atomickými zápisy), je dvojí běh
nepříjemný, ne nebezpečný — a pravděpodobnost je řádově nižší než dnešní jistota
N paralelních běhů. Kdo potřebuje skutečnou atomicitu, musí sáhnout po souborovém
zámku na disku; to tu záměrně není (Android SMB/FAT cesty ho nespolehlivě umí).

Sdílené primitivum se stejným tvarem má `richmovie_mi2` (inflight lock per ident)
a `richmovie_diag` (once-guard) — migrují sem opportunisticky, ne v 3.5.118
(funkční kód, žádný přínos pro incident, riziko regrese).

Python 3.8 (Kodi runtime) — typy jen v komentářích.
"""
from __future__ import annotations


import threading
import time
import uuid
from typing import Optional

from richmovie_winprops import clear_prop as _clear_prop
from richmovie_winprops import get_prop as _get_prop
from richmovie_winprops import set_prop as _set_prop

_PROP_PREFIX = "richmovie.guard."

# In-process konzistence (více vláken jednoho procesu). Mezi procesy viz docstring.
_lock = threading.Lock()


def _prop(name):
    # type: (str) -> str
    return _PROP_PREFIX + str(name or "").strip()


def _now():
    # type: () -> float
    """Monotónní čas. NE `time.time()` (cross-check Pro 21.08.2026, Q7): Android
    boxy a RPi bez RTC skokově přenastavují hodiny přes NTP po bootu — kalendářní
    čas by claim buď okamžitě „expiroval", nebo prodloužil na hodiny. Monotónní
    hodiny jsou na jednom OS bootu sdílené všemi procesy (Windows QPC, Linux
    CLOCK_MONOTONIC), což přesně odpovídá životnosti `Window(10000)` properties
    (nepřežijí restart Kodi, natož bootu)."""
    return time.monotonic()


def _parse(raw):
    # type: (str) -> Optional[tuple]
    """`"<expires_ts>|<token>"` → (expires_ts, token), None když nečitelné."""
    try:
        expires_text, token = str(raw).split("|", 1)
        return float(expires_text), token
    except Exception:
        return None


def _won(name, token):
    # type: (str, str) -> bool
    """Drzi Window property po zapisu NAS token?

    `threading.Lock` chrani jen vlakna JEDNOHO procesu. Kazda invokace pluginu
    je vlastni interpret, takze dva procesy mohou soucasne precist „volno",
    oba zapsat svuj token a oba si myslet, ze vyhraly (cross-check Pro Q3).
    Zapis do Window property je „vyhrava posledni", takze staci po zapisu
    znovu precist: kdo se tam nenajde, prohral a musi se chovat jako by claim
    nedostal. Neni to atomicke CAS (Kodi zadne nenabizi), ale okno na souben
    se zkrati z „cele telo funkce" na „mezi zapisem a ctenim".
    """
    current = _parse(_get_prop(_prop(name), ""))
    return current is not None and current[1] == token


def claim(name, ttl_s):
    # type: (str, float) -> Optional[str]
    """Pokusí se převzít claim `name`. Vrací token (předat do `release`),
    nebo None, když claim drží někdo jiný a ještě nevypršel.

    Args:
        name:  Identifikátor práce (např. "collections_install").
        ttl_s: Po kolika sekundách se nevydaný claim považuje za sirotka.
    """
    if not name:
        raise ValueError("guard.claim: name je povinné")
    ttl = float(ttl_s)
    if ttl <= 0:
        # Chyba programátora, ne runtime stav — nahlas. Tiché „oříznutí" TTL by
        # změnilo chování volajícího, aniž by o tom věděl (a harness 23 by to
        # neodhalil — přesně tak vznikl první FAIL při psaní tohoto modulu).
        raise ValueError("guard.claim: ttl_s musí být > 0 (dostal %r)" % (ttl_s,))

    with _lock:
        now = _now()
        current = _parse(_get_prop(_prop(name), ""))
        if current is not None and current[0] > now:
            return None
        token = uuid.uuid4().hex
        _set_prop(_prop(name), "%.3f|%s" % (now + ttl, token))
        # Soubezna invokace mohla zapsat tesne po nas — kdo se po zapisu
        # v property nenajde, claim NEDOSTAL (cross-check Pro Q3).
        if not _won(name, token):
            return None
        return token


def renew(name, token, ttl_s):
    # type: (str, Optional[str], float) -> bool
    """Prodlouží VLASTNÍ claim o dalších `ttl_s` sekund od teď. Vrací False, když
    claim mezitím převzal někdo jiný (nebo vypršel a byl smazán) — volající má
    práci ukončit, jinak by dva procesy zapisovaly tytéž soubory.

    PROČ (cross-check Pro, 21.08.2026, Q3): TTL spočítané dopředu nikdy není
    jistý horní odhad (429 cooldowny, retry rozpočty). Místo „hádej dost velké
    číslo" se claim prodlužuje průběžně — TTL je pak signál živosti držitele,
    ne odhad délky práce. Volat při každém průběžném flushi."""
    if not name or not token:
        return False
    ttl = float(ttl_s)
    if ttl <= 0:
        raise ValueError("guard.renew: ttl_s musí být > 0 (dostal %r)" % (ttl_s,))
    with _lock:
        current = _parse(_get_prop(_prop(name), ""))
        if current is None or current[1] != token:
            return False
        _set_prop(_prop(name), "%.3f|%s" % (_now() + ttl, token))
        return True


def take_over(name, ttl_s):
    # type: (str, float) -> Optional[str]
    """Převezme claim `name` BEZ OHLEDU na současného držitele a vrátí nový token (None = zápis se nepotvrdil).

    JEN pro claim s JEDINÝM vlastníkem v Kodi — služba doplňku (Kodi ji spouští jednou): cizí držitel je pak sirotek
    MINULÉ instance služby (aktualizace doplňku za běhu), na jehož TTL nemá smysl čekat — během čekání by claim po
    vypršení na chvíli nikdo nedržel (4.0.2, relace přehrávání `richmovie_playback_dispatch`, cross-check Codex #3).
    Pro práci, kterou může chtít víc procesů, je to ŠPATNĚ — tam `claim`.
    """
    if not name:
        raise ValueError("guard.take_over: name je povinné")
    ttl = float(ttl_s)
    if ttl <= 0:
        raise ValueError("guard.take_over: ttl_s musí být > 0 (dostal %r)" % (ttl_s,))
    with _lock:
        token = uuid.uuid4().hex
        _set_prop(_prop(name), "%.3f|%s" % (_now() + ttl, token))
        if not _won(name, token):
            return None
        return token


def release(name, token):
    # type: (str, Optional[str]) -> None
    """Uvolní claim — ale jen když ho drží NÁŠ token. Cizí (novější) claim se
    nesmí smazat: proces, který přežil svůj TTL, by jinak shodil nástupce."""
    if not name or not token:
        return
    with _lock:
        current = _parse(_get_prop(_prop(name), ""))
        if current is None or current[1] == token:
            _clear_prop(_prop(name))


def note_once(name, ttl_s):
    # type: (str, float) -> bool
    """Stalo se `name` za poslednich `ttl_s` sekund?

    Vraci TOKEN, kdyz je tohle PRVNI vyskyt v okne (a okno se tim otevre),
    None, kdyz uz se to v okne stalo. Token se predava do `forget()`,
    aby smel okno zrusit jen jeho vlastnik (cross-check Flash E4). Na rozdil od `claim()` se nic
    neuvolnuje - zaznam proste vyprsi. Slouzi k dedup akci, ktere se pri
    opakovane invokaci pluginu nesmi provest znovu.

    PROC (incident Sony 19.09.2026): `richmovie_recommendations.record_click`
    si dedup drzel v modulovem dictu `_recent_click_window`. Jenze kazda
    invokace pluginu je NOVY INTERPRET, takze dict byl vzdycky prazdny a
    kazdy `Container.Refresh` od MI2 poslal klik na Gate znovu.
    """
    if not name:
        raise ValueError("guard.note_once: name je povinne")
    ttl = float(ttl_s)
    if ttl <= 0:
        raise ValueError("guard.note_once: ttl_s musi byt > 0 (dostal %r)" % (ttl_s,))

    with _lock:
        now = _now()
        current = _parse(_get_prop(_prop(name), ""))
        if current is not None and current[0] > now:
            return None
        token = uuid.uuid4().hex
        _set_prop(_prop(name), "%.3f|%s" % (now + ttl, token))
        # Soubezna invokace mohla zapsat tesne po nas — kdo se po zapisu
        # v property nenajde, claim NEDOSTAL (cross-check Pro Q3).
        if not _won(name, token):
            return None
        return token


def forget(name, token):
    # type: (str, Optional[str]) -> None
    """Zrusi okno zalozene `note_once` — akce se smi zkusit znovu hned.

    Pouziva volajici, jehoz prace po otevreni okna SELHALA. Bez toho by se
    ztratila az do vyprseni TTL (audit Fable: `record_click` otviral okno
    pred POSTem, takze neuspesny klik se uz nezkusil).
    """
    if not name or not token:
        return
    with _lock:
        current = _parse(_get_prop(_prop(name), ""))
        # Jen VLASTNI okno. Bez teto kontroly mohl souběžný proces zrušit okno,
        # ktere si prave platne otevrel nekdo jiny (cross-check Flash E4).
        if current is None or current[1] == token:
            _clear_prop(_prop(name))


def is_claimed(name):
    # type: (str) -> bool
    """True, když claim existuje a nevypršel (diagnostika, testy)."""
    current = _parse(_get_prop(_prop(name), ""))
    return current is not None and current[0] > _now()
