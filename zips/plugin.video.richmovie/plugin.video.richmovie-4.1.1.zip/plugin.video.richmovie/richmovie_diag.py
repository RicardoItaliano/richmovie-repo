# -*- coding: utf-8 -*-
"""RichMovie diag — health snapshot zařízení + strukturované logování výjimek.

CÍL (2026-07-01, iniciativa „logovat každou blbost enterprise grade")
---------------------------------------------------------------------
Aby šlo potenciální problémy diagnostikovat CO NEJLÉPE z NASu, potřebujeme dvě věci,
které dnes chybí:

  1) `session_env()` — jednou za proces vyšle bohatý **otisk zařízení** (SESSION_ENV):
     platforma/OS, Kodi build, Python, addon verze, device_hash, volná RAM, volné
     místo na profilu, rozlišení, jazyk, stav certifi/SSL a **backlog log bufferu**
     (kolik záznamů čeká na odeslání — přímý indikátor, že drainer/Gate vázne).
     → device-specific bugy (typu Martina: SSL + slabá paměť Chromecastu) jsou pak
       vidět OKAMŽITĚ v admin logu, ne až po hodině lovení.

  2) `diag_exc()` — DRY helper pro **strukturované logování chycených výjimek**.
     Nahrazuje tichý `except Exception: pass` (audit: 635× v addonu = 635 slepých
     míst). Zaloguje zprávu + traceback + kontext přes stávající pipeline, ale
     NIKDY nepropaguje výjimku dál → chování „best-effort" zůstává, jen už není slepé.

DRY/SSOT: staví VÝHRADNĚ na `richmovie_logging` (durable SQLite WAL pipeline →
Gate /v1/user_logs) + `richmovie_gate_transport` (SSOT `detect_platform`,
`get_device_hash`). Žádný paralelní kanál. Best-effort všude (diagnostika nesmí
nikdy shodit addon).

Plán: RichMovie-nas/Handoff/PLAN_observability_program_2026-07-01.md
"""
from __future__ import annotations

import logging
import os
import sys
import threading
from typing import Any, Optional

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except ImportError:  # pragma: no cover - jen mimo Kodi
    xbmc = None  # type: ignore
    xbmcaddon = None  # type: ignore
    xbmcgui = None  # type: ignore
    xbmcvfs = None  # type: ignore

from richmovie_logging import get_logger

_ADDON_ID = "plugin.video.richmovie"
_DIAG_LOGGER = "richmovie.diag"

# session_env se pošle jen 1× za proces (idempotence napříč voláními z plugin+service).
_env_lock = threading.Lock()
_env_sent = False


def _log():
    try:
        return get_logger(_DIAG_LOGGER)
    except Exception:
        return None


def _info_label(label: str) -> str:
    """Bezpečně přečti Kodi InfoLabel. "" na chybu / mimo Kodi."""
    if xbmc is None:
        return ""
    try:
        return (xbmc.getInfoLabel(label) or "").strip()
    except Exception:
        return ""


def _profile_dir() -> Optional[str]:
    if xbmcvfs is None:
        return None
    try:
        return xbmcvfs.translatePath(
            "special://profile/addon_data/%s/" % _ADDON_ID)
    except Exception:
        return None


def _addon_version() -> str:
    if xbmcaddon is None:
        return ""
    try:
        return xbmcaddon.Addon(_ADDON_ID).getAddonInfo("version") or ""
    except Exception:
        return ""


def _free_disk_mb(path: Optional[str]) -> int:
    """Volné místo na svazku profilu v MB (kde žije log buffer + cache). -1 na chybu."""
    if not path:
        return -1
    try:
        import shutil
        usage = shutil.disk_usage(path)
        return int(usage.free / (1024 * 1024))
    except Exception:
        return -1


def _certifi_status() -> str:
    """Stav vendored certifi CA bundle — přímo relevantní pro SSL cert chyby
    (incident Martina: CERTIFICATE_VERIFY_FAILED). "ok:<path>" / "missing" / "err"."""
    try:
        import certifi  # vendored v resources/lib/vendor
        where = certifi.where()
        if where and os.path.exists(where):
            return "ok"
        return "missing"
    except Exception:
        return "err"


def _buffer_backlog() -> dict[str, Any]:
    """Statistiky log bufferu — unsent backlog = indikátor, že drainer/Gate vázne."""
    try:
        prof = _profile_dir()
        if not prof:
            return {}
        from richmovie_log_buffer import get_buffer
        buf = get_buffer(os.path.join(prof, "log_buffer.db"))
        return buf.stats()
    except Exception:
        return {}


def session_env(source: str = "unknown", *, force: bool = False) -> None:
    """Vyšle jednorázový SESSION_ENV otisk zařízení (INFO). Idempotentní per proces.

    Volat co nejdřív po startu procesu (service_nextup boot + plugin root).
    `source` = kdo to volá ("service_nextup" / "plugin"). `force=True` obejde
    once-guard (pro ruční re-snapshot). Best-effort — nikdy nevyhazuje.
    """
    global _env_sent
    try:
        with _env_lock:
            if _env_sent and not force:
                return
            _env_sent = True

        # Cross-proces guard: plugin je NOVÝ proces na každý klik → per-proces guard
        # výše nestačí. Window(10000) property drží „už posláno" napříč všemi procesy
        # jedné Kodi session → SESSION_ENV padne max 1× za session (typicky ze
        # service_nextup boot; plugin root je jen fallback, když služba neběžela).
        if not force and xbmc is not None:
            try:
                _win = xbmcgui.Window(10000)
                if (_win.getProperty("richmovie.diag.env_sent") or "") == "1":
                    return
                _win.setProperty("richmovie.diag.env_sent", "1")
            except Exception:
                pass

        # SSOT identita (DRY — nikdy neduplikovat detekci).
        platform_str = ""
        device_hash = ""
        try:
            import richmovie_gate_transport as _gt
            platform_str = _gt.detect_platform()
            device_hash = _gt.get_device_hash()
        except Exception:
            pass

        prof = _profile_dir()
        ctx: dict[str, Any] = {
            "source": source,
            "platform": platform_str,
            "device_hash": device_hash,
            "addon_version": _addon_version(),
            "kodi_build": _info_label("System.BuildVersion"),
            "python": sys.version.split()[0] if sys.version else "",
            "screen": _info_label("System.ScreenResolution"),
            "language": _info_label("System.Language"),
            "mem_free": _info_label("System.Memory(free)"),
            "mem_used_pct": _info_label("System.Memory(used.percent)"),
            "disk_free_mb": _free_disk_mb(prof),
            "certifi": _certifi_status(),
            "uptime": _info_label("System.Uptime"),
            "buffer": _buffer_backlog(),
        }
        # Noc 03.11.2026: prostředí zařízení (SSOT `richmovie_device_env`) — filtr obsahu, HDR schopnosti.
        try:
            import richmovie_device_env as _denv
            ctx.update({k: v for k, v in _denv.telemetry_fields().items() if v is not None})
        except Exception:
            pass

        log = _log()
        if log is not None:
            log.info(
                "SESSION_ENV source=%s platform=%s ver=%s kodi=%s py=%s "
                "mem_free=%s disk_free_mb=%s certifi=%s unsent=%s os_filter=%s hdr=%s"
                % (source, platform_str, ctx["addon_version"], ctx["kodi_build"],
                   ctx["python"], ctx["mem_free"], ctx["disk_free_mb"],
                   ctx["certifi"], (ctx["buffer"] or {}).get("unsent", "?"),
                   ctx.get("os_filter") or "-", ctx.get("hdr_types") or "-"),
                extra={"context": ctx},
            )
    except Exception:
        pass


def diag_exc(log: Any, msg: str, *, level: int = logging.WARNING,
             **ctx: Any) -> None:
    """Strukturovaně zaloguj PRÁVĚ chycenou výjimku (v `except` bloku).

    Náhrada za tichý `except Exception: pass`. Zaloguje `msg` + traceback aktuální
    výjimky (`exc_info=True` → RichLogHandler přidá redakčně očištěný traceback do
    kontextu) + libovolný strukturovaný kontext. NIKDY nepropaguje výjimku dál —
    zachovává best-effort chování, jen už není slepé.

    Použití:
        from richmovie_diag import diag_exc
        try:
            risky()
        except Exception:
            diag_exc(log, "probe selhal", ident=ident)   # místo `pass`

    `log` = logger z get_logger(...) daného modulu. Když je None, tiše se vzdá.
    """
    try:
        if log is None:
            return
        if level not in (logging.DEBUG, logging.INFO, logging.WARNING,
                         logging.ERROR, logging.CRITICAL):
            level = logging.WARNING
        log.log(level, msg, exc_info=True,
                extra={"context": ctx} if ctx else None)
    except Exception:
        pass
