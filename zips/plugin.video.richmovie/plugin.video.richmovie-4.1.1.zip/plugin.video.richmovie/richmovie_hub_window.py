# -*- coding: utf-8 -*-
"""RichMovie 4.0 — generic Hub okno (WindowXMLDialog) — Φ2b.

Vlastní menu sekce (Moje / Zdroje) = vertikální seznam možností. Nahrazuje staré
Kodi directory menu na úrovni sekce. Položky routují na custom okna (mode=win →
RunPlugin, otevře nad hubem, Back vrací) nebo zatím na existující akce (mode=container).
SSOT: richmovie_ui_common. XML: resources/skins/default/1080i/RichMovieHub.xml. Best-effort.
"""
from __future__ import annotations

import xbmc
import xbmcgui

import richmovie_ui_common as uc


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/Hub] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.hub", "RichMovie/Hub")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "Hub] " + str(msg), level)
        except Exception:
            pass

_XML = "RichMovieHub.xml"
_RES = "1080i"
_LIST = 7000

# ── SSOT definice hubů — sekce/položky se mění JEN tady ──────────────────────
# mode: "win"   = RunPlugin custom okno NAD hubem (Back vrací do hubu)
#       "run"   = RunPlugin dialog/akce (hub zůstává — csfd_settings, reset…)
#       "container" = Kodi directory přes goto_container (long-tail leaf)
HUBS = {
    "mine": {"title": "Moje", "items": [
        {"label": "Můj seznam",                   "action": "rm_grid", "mode": "win",
         "feed": "my_list", "title": "Můj seznam"},
        {"label": "Pokračovat ve sledování",      "action": "rm_grid", "mode": "win",
         "feed": "cw", "title": "Pokračovat ve sledování"},
        {"label": "Naposledy sledované seriály",  "action": "rm_grid", "mode": "win",
         "feed": "recent_series", "title": "Naposledy sledované seriály"},
        {"label": "Historie sledování – filmy",   "action": "rm_grid", "mode": "win",
         "feed": "watch_history_movies", "title": "Historie sledování – filmy"},
        {"label": "Moje ČSFD",                    "action": "rm_hub", "mode": "win",
         "hub": "csfd"},
        {"label": "Kolekce",                      "action": "collections",    "mode": "win"},
        {"label": "Historie hledání",             "action": "history",        "mode": "win"},
        {"label": "Soukromá databáze (NAS)",      "action": "local_root",     "mode": "win"},
        # Φ0 (2026-07-06, audit A04): položka „Stahování" ODSTRANĚNA — mířila na
        # `action=download` (stažení KONKRÉTNÍHO streamu, vyžaduje ident) → modal
        # „Chybí ident streamu." v prázdném legacy okně. Browsable seznam stahování
        # v addonu neexistuje (downloads jdou do uživatelem volených složek,
        # last_download_dir je jen paměť save dialogu). Stahování se spouští
        # z kontextového menu streamu; případný download-browser = nová feature.
        {"label": "Reset cache vyhledávání",      "action": "reset_search_caches", "mode": "run"},
    ]},
    "csfd": {"title": "Moje ČSFD", "items": [
        {"label": "Moje hodnocení",               "action": "rm_grid", "mode": "win",
         "feed": "csfd_ratings", "title": "Moje ČSFD hodnocení"},
        {"label": "Chci vidět",                   "action": "rm_grid", "mode": "win",
         "feed": "csfd_watchlist", "title": "Chci vidět (ČSFD)"},
        {"label": "Top hodnocené (4–5★)",         "action": "rm_grid", "mode": "win",
         "feed": "csfd_top", "title": "Moje top (ČSFD 80 %+)"},
        # Φ7 (2026-07-06): csfd_home migrován na RmDir sink → custom list okno
        {"label": "ČSFD TV tipy a novinky",       "action": "csfd_home",      "mode": "win"},
        {"label": "ČSFD profil (připojení / sync)", "action": "csfd_settings", "mode": "run"},
    ]},
    "sources": {"title": "Zdroje", "items": [
        # Φ7 (2026-07-06): zdroje migrovány na RmDir sink → custom list okna
        # (ws_search zůstává container — má vlastní custom streams_window cestu)
        {"label": "Stream.cz",                    "action": "stream_home",    "mode": "win"},
        {"label": "YouTube",                      "action": "yt_home",        "mode": "win"},
        {"label": "SkTorrent",                    "action": "sktorrent_home", "mode": "win"},
        {"label": "iDNES.tv",                     "action": "idnestv_home",   "mode": "win"},
        {"label": "Novinky.cz",                   "action": "novinky_home",   "mode": "win"},
        {"label": "Webshare přímé hledání",       "action": "ws_search",      "mode": "container"},
        {"label": "Přihlášení k Fastshare",       "action": "fs_login_onboard", "mode": "run"},
    ]},
}


class RichMovieHubWindow(uc.RMNavMixin, xbmcgui.WindowXMLDialog):

    def __init__(self, *a, hub="", **kw):
        super().__init__(*a, **kw)
        self._hub = hub
        self._rm_closed = False  # parita lifecycle vzoru ostatních oken (fetch_async guard)

    def onInit(self) -> None:
        spec = HUBS.get(self._hub) or {"title": "RichMovie", "items": []}
        self.setProperty("rm_hub_title", spec.get("title") or "RichMovie")
        try:
            lst = self.getControl(_LIST)
            for it in spec.get("items", []):
                li = xbmcgui.ListItem(it.get("label") or "")
                li.setProperty("rm_action", it.get("action") or "")
                li.setProperty("rm_mode", it.get("mode") or "container")
                li.setProperty("rm_feed", it.get("feed") or "")
                li.setProperty("rm_t", it.get("title") or "")
                li.setProperty("rm_hub", it.get("hub") or "")
                lst.addItem(li)
            self.setFocusId(_LIST)
        except Exception as exc:
            _log(f"onInit: {exc}", xbmc.LOGWARNING)

    def onClick(self, controlId: int) -> None:
        if controlId == 9000:  # ‹ Zpět
            self.close()
            return
        if controlId != _LIST:
            return
        try:
            li = self.getControl(_LIST).getSelectedItem()
            if not li:
                return
            action = li.getProperty("rm_action")
            if not action:
                return
            qs = {"action": action}
            feed = li.getProperty("rm_feed")
            if feed:
                qs["feed"] = feed
            t = li.getProperty("rm_t")
            if t:
                qs["title"] = t
            hub = li.getProperty("rm_hub")
            if hub:
                qs["hub"] = hub
            url = uc.url(**qs)
            mode = li.getProperty("rm_mode")
            if mode == "win":
                # custom okno otevře NAD hubem (Back → hub)
                xbmc.executebuiltin(f"RunPlugin({url})")
            elif mode == "run":
                # dialog/akce — hub zůstává otevřený (žádné busy, dialog je odezva)
                xbmc.executebuiltin(f"RunPlugin({url})")
            else:
                # zatím Kodi listing (long-tail) — dialog stack se musí složit,
                # Container.Update by directory aktualizoval NEVIDITELNĚ pod okny.
                # Φ1: breadcrumb v legacy listingu povede zpět do TOHOHLE hubu
                # (parent routa), ne paušálně na home_window.
                uc.goto_container(url, parent_action="rm_hub",
                                  parent_params={"hub": self._hub} if self._hub else None)
        except Exception as exc:
            uc.notify_error("Sekci se nepodařilo otevřít.", log_tag="Hub")
            _log(f"onClick: {exc}", xbmc.LOGWARNING)

    # Back/Stop/device latch řeší uc.RMNavMixin.onAction (Φ1 DRY) — hub nemá
    # žádné okno-specifické akce, mixin default stačí.

    def close(self):  # noqa: A003 — Kodi API jméno
        self._rm_closed = True
        super().close()


def open_hub(addon, hub="") -> None:
    """Otevře generic hub. Best-effort."""
    try:
        w = RichMovieHubWindow(_XML, addon.getAddonInfo("path"), "default", _RES, hub=hub)
        _nav_id = uc.nav_push("rm_hub", {"hub": hub})  # Φ1 NavStack
        try:
            w.doModal()
        finally:
            uc.nav_remove(_nav_id)
        w._rm_closed = True
        del w
    except Exception as exc:
        _log(f"open_hub({hub}): {exc}", xbmc.LOGWARNING)
