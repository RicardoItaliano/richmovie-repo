# -*- coding: utf-8 -*-
"""
richmovie_youtube.py  -- YouTube klient

Datovy modul pro hledani a prehravani YouTube obsahu.
Hledani/browse pres Innertube API, prehravani pres yt-dlp subprocess
(Innertube player API uz neni bez autentizace funkcni).
Bez Kodi GUI zavislosti krome xbmc.log.

Vzor: richmovie_stream.py
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from urllib.parse import quote_plus, urlencode, parse_qs, urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from typing import Any

# Windows: potlacit konzolove okno pri subprocess
_SP_FLAGS: int = 0
if sys.platform == "win32":
    _SP_FLAGS = subprocess.CREATE_NO_WINDOW


# ---------------------------------------------------------------------------
#  KONSTANTY
# ---------------------------------------------------------------------------
_TIMEOUT = 15

from richmovie_gate_transport import GATE_URL as _GATE_URL
from richmovie_gate_transport import get_identity as _gate_get_identity

try:
    import xbmcaddon as _xbmcaddon
    _ADDON_VERSION = _xbmcaddon.Addon().getAddonInfo("version") or "dev"
except Exception:
    _ADDON_VERSION = "dev"


# ---------------------------------------------------------------------------
#  EXCEPTION
# ---------------------------------------------------------------------------
class YouTubeError(Exception):
    """Gate-side YouTube Innertube operace selhala. Fail-fast, žádný fallback."""


# ---------------------------------------------------------------------------
#  LOG
# ---------------------------------------------------------------------------
# 3.4.x Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log_router = _make_legacy_logger("richmovie.youtube", "RichMovie/YouTube")
    def _log(msg: str) -> None:
        _log_router(msg)
except Exception:
    def _log(msg: str) -> None:
        try:
            import xbmc
            xbmc.log(f"[RichMovie/YouTube] {msg}", xbmc.LOGINFO)
        except Exception:
            pass


# ---------------------------------------------------------------------------
#  INNERTUBE HELPER
# ---------------------------------------------------------------------------
def _innertube(endpoint: str, body: dict, *, android: bool = False) -> dict:
    """POST na Innertube API endpoint via Gate proxy. Fail-fast.

    Gate `/v1/sources/youtube/innertube` drží UA + clientVersion fingerprint
    mimo veřejný GitHub kód. Raises YouTubeError na transport/auth/upstream
    selhání. Žádný legacy direct-POST fallback.
    """
    try:
        ws_username, ws_proof = _gate_get_identity()
    except Exception as exc:
        raise YouTubeError(f"Chybí RichMovie Gate identita: {exc}") from exc
    if not ws_username or not ws_proof:
        raise YouTubeError(
            "RichMovie Gate identita není nakonfigurovaná "
            "(chybí Webshare login v nastavení)."
        )

    url = f"{_GATE_URL}/v1/sources/youtube/innertube"
    payload = {
        "endpoint": endpoint,
        "body": body,
        "android": bool(android),
    }
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "User-Agent": f"RichMovie/{_ADDON_VERSION} (+plugin.video.richmovie)",
        "Accept": "application/json",
        "Accept-Encoding": "identity",
        "Content-Type": "application/json",
        "X-WS-Username": ws_username,
        "X-WS-Proof": ws_proof,
    }
    # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. Innertube dotaz je
    # čtení (výpis videí), takže `idempotent=True` navzdory metodě POST.
    try:
        import richmovie_http as _rm_http
    except Exception as _imp_exc:  # pragma: no cover
        raise YouTubeError("richmovie_http neni k dispozici") from _imp_exc

    try:
        profile = _rm_http.profile_foreground().replace(timeout_s=float(_TIMEOUT))
        status, raw, _hdrs = _rm_http.request(
            url, method="POST", headers=headers, data=data,
            profile=profile, idempotent=True, tag="youtube",
        )
        if status != 200:
            raise YouTubeError(
                f"Gate youtube/innertube vrátil HTTP {status}."
            )
    except YouTubeError:
        raise
    except _rm_http.TransientError as exc:
        raise YouTubeError(f"Nelze se připojit k RichMovie Gate: {exc}") from exc
    except Exception as exc:
        raise YouTubeError(
            f"Gate youtube/innertube error: {exc}"
        ) from exc

    try:
        envelope = json.loads(raw.decode("utf-8", errors="replace"))
    except Exception as exc:
        raise YouTubeError(
            f"Gate youtube/innertube vrátil nevalidní JSON: {exc}"
        ) from exc
    if not isinstance(envelope, dict) or envelope.get("status") != "ok":
        err = envelope.get("error") if isinstance(envelope, dict) else None
        msg = err.get("message") if isinstance(err, dict) else None
        raise YouTubeError(msg or "Gate youtube/innertube: nevalidní envelope.")

    data_out = envelope.get("data")
    if not isinstance(data_out, dict):
        raise YouTubeError("Gate youtube/innertube: chybí 'data' v odpovědi.")
    _log(f"innertube: {endpoint} android={android}")
    return data_out


# ---------------------------------------------------------------------------
#  PARSERY
# ---------------------------------------------------------------------------
def _txt(runs: Any) -> str:
    """Extrahuje text z runs nebo simpleText."""
    if isinstance(runs, str):
        return runs
    if isinstance(runs, dict):
        if "simpleText" in runs:
            return runs["simpleText"]
        if "runs" in runs:
            return "".join(r.get("text", "") for r in runs["runs"])
    return ""


def _thumb(renderer: dict) -> str:
    """Vybere nejvetsi thumbnail."""
    thumbs = renderer.get("thumbnail", {}).get("thumbnails", [])
    if not thumbs:
        return ""
    best = max(thumbs, key=lambda t: t.get("width", 0) * t.get("height", 0))
    url = best.get("url", "")
    if url.startswith("//"):
        url = "https:" + url
    return url


def _duration_seconds(text: str) -> int:
    """Konverze '3:42' nebo '1:23:45' na sekundy."""
    if not text:
        return 0
    parts = text.strip().split(":")
    try:
        parts = [int(p) for p in parts]
    except ValueError:
        return 0
    if len(parts) == 3:
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    if len(parts) == 2:
        return parts[0] * 60 + parts[1]
    return 0


def _view_count(renderer: dict) -> int:
    """Extrahuje pocet zhlednuti."""
    # shortViewCountText: "1.5M views" / viewCountText: "1,500,000 views"
    for key in ("viewCountText", "shortViewCountText"):
        text = _txt(renderer.get(key, {}))
        if text:
            nums = re.sub(r"[^\d]", "", text)
            if nums:
                return int(nums)
    return 0


def _parse_video(renderer: dict) -> dict | None:
    """Parsuje videoRenderer na standardni dict."""
    vid = renderer.get("videoRenderer") or renderer
    video_id = vid.get("videoId")
    if not video_id:
        return None

    title = _txt(vid.get("title", {}))
    channel = _txt(vid.get("ownerText", vid.get("longBylineText", vid.get("shortBylineText", {}))))
    channel_id = ""
    for key in ("ownerText", "longBylineText", "shortBylineText"):
        runs = vid.get(key, {}).get("runs", [])
        if runs:
            nav = runs[0].get("navigationEndpoint", {}).get("browseEndpoint", {})
            channel_id = nav.get("browseId", "")
            if channel_id:
                break

    duration_text = _txt(vid.get("lengthText", {}))
    published = _txt(vid.get("publishedTimeText", {}))

    # Detekce LIVE streamu
    badges = vid.get("badges", [])
    is_live = False
    for b in badges:
        label = (b.get("metadataBadgeRenderer") or {}).get("style", "")
        if "LIVE" in label.upper():
            is_live = True
            break

    return {
        "video_id": video_id,
        "title": title,
        "channel": channel,
        "channel_id": channel_id,
        "duration": _duration_seconds(duration_text),
        "duration_text": duration_text,
        "views": _view_count(vid),
        "thumb": _thumb(vid),
        "published": published,
        "is_live": is_live,
    }


def _parse_channel(renderer: dict) -> dict | None:
    """Parsuje channelRenderer na standardni dict."""
    ch = renderer.get("channelRenderer") or renderer
    channel_id = ch.get("channelId")
    if not channel_id:
        return None

    name = _txt(ch.get("title", {}))
    subscribers = _txt(ch.get("subscriberCountText", {}))
    video_count_text = _txt(ch.get("videoCountText", {}))
    video_count = 0
    nums = re.sub(r"[^\d]", "", video_count_text)
    if nums:
        video_count = int(nums)

    return {
        "channel_id": channel_id,
        "name": name,
        "thumb": _thumb(ch),
        "subscribers": subscribers,
        "video_count": video_count,
    }


# ---------------------------------------------------------------------------
#  SAFE NESTED ACCESS
# ---------------------------------------------------------------------------
def _dig(obj: Any, *keys: str | int) -> Any:
    """Bezpecny pristup do hluboce vnorenych dict/list."""
    for k in keys:
        if obj is None:
            return None
        if isinstance(k, int):
            if isinstance(obj, list) and 0 <= k < len(obj):
                obj = obj[k]
            else:
                return None
        elif isinstance(obj, dict):
            obj = obj.get(k)
        else:
            return None
    return obj


# ---------------------------------------------------------------------------
#  SEARCH
# ---------------------------------------------------------------------------
def search(query: str, region: str = "CZ") -> dict:
    """
    Hledani na YouTube via Gate Innertube. Raises YouTubeError na selhání.
    Vraci {"videos": [...], "channels": [...]}.

    Region je přidaný do context na Gate straně (clientVersion/gl
    fingerprint tam držíme), addon posílá jen query.
    """
    _ = region  # Gate drží gl/hl v context — addon je jen předává
    resp = _innertube("search", {"query": query})

    videos = []
    channels = []

    # Parsovani: contents.twoColumnSearchResultsRenderer.primaryContents
    #   .sectionListRenderer.contents[].itemSectionRenderer.contents[]
    sections = _dig(
        resp, "contents", "twoColumnSearchResultsRenderer",
        "primaryContents", "sectionListRenderer", "contents"
    ) or []

    for section in sections:
        items = _dig(section, "itemSectionRenderer", "contents") or []
        for item in items:
            if "videoRenderer" in item:
                v = _parse_video(item)
                if v:
                    videos.append(v)
            elif "channelRenderer" in item:
                c = _parse_channel(item)
                if c:
                    channels.append(c)

    _log(f"search({query!r}): {len(videos)} videos, {len(channels)} channels")
    return {"videos": videos, "channels": channels}


# ---------------------------------------------------------------------------
#  TRENDING
# ---------------------------------------------------------------------------
def trending(region: str = "CZ") -> list[dict]:
    """
    „Trendy" — populární videa pro daný region.

    YouTube Innertube `FEtrending` browse endpoint už není veřejně funkční
    (DEAD od 2024). Jediná spolehlivá cesta je search na populární dotaz
    přes Gate Innertube — dostáváme top-N výsledků pro daný jazyk/region,
    což dává rozumnou aproximaci trendy feedu.

    Raises YouTubeError (z _innertube) na Gate selhání.
    """
    _ = region  # Gate drží gl/hl, addon je jen předává
    results = search("cesky")
    videos = results.get("videos", [])[:20]
    _log(f"trending(via search 'cesky'): {len(videos)} videos")
    return videos


# ---------------------------------------------------------------------------
#  CHANNEL
# ---------------------------------------------------------------------------
def channel_info(channel_id: str) -> dict:
    """Metadata kanalu."""
    resp = _innertube("browse", {"browseId": channel_id})

    header = resp.get("header", {}).get("c4TabbedHeaderRenderer", {})
    if not header:
        header = resp.get("header", {}).get("pageHeaderRenderer", {})

    name = _txt(header.get("title", ""))
    subscribers = _txt(header.get("subscriberCountText", {}))
    thumb = _thumb(header)

    return {
        "channel_id": channel_id,
        "name": name,
        "thumb": thumb,
        "subscribers": subscribers,
    }


def channel_videos(
    channel_id: str,
    continuation: str | None = None,
) -> tuple[list[dict], str | None]:
    """
    Videa kanalu s paginaci.
    Vraci (list_videos, next_continuation_token | None).
    """
    if continuation:
        resp = _innertube("browse", {"continuation": continuation})
    else:
        # browse channel + Videos tab (params=EgZ2aWRlb3PyBgQKAjoA)
        resp = _innertube("browse", {
            "browseId": channel_id,
            "params": "EgZ2aWRlb3PyBgQKAjoA",  # Videos tab
        })

    videos = []
    next_cont = None

    if continuation:
        # continuationItems
        actions = _dig(resp, "onResponseReceivedActions") or []
        for action in actions:
            items = _dig(action, "appendContinuationItemsAction", "continuationItems") or []
            for item in items:
                if "richItemRenderer" in item:
                    vr = _dig(item, "richItemRenderer", "content")
                    if vr and "videoRenderer" in vr:
                        v = _parse_video(vr)
                        if v:
                            videos.append(v)
                # continuation token
                cont = _dig(item, "continuationItemRenderer", "continuationEndpoint",
                            "continuationCommand", "token")
                if cont:
                    next_cont = cont
    else:
        # Najdi Videos tab
        tabs = _dig(resp, "contents", "twoColumnBrowseResultsRenderer", "tabs") or []
        for tab in tabs:
            tab_r = tab.get("tabRenderer", {})
            # Videos tab ma title "Videos" nebo "Videa"
            content = _dig(tab_r, "content", "richGridRenderer", "contents") or []
            if not content:
                continue
            for item in content:
                if "richItemRenderer" in item:
                    vr = _dig(item, "richItemRenderer", "content")
                    if vr and "videoRenderer" in vr:
                        v = _parse_video(vr)
                        if v:
                            videos.append(v)
                # continuation
                cont = _dig(item, "continuationItemRenderer", "continuationEndpoint",
                            "continuationCommand", "token")
                if cont:
                    next_cont = cont
            if videos:
                break  # nasli jsme spravny tab

    _log(f"channel_videos({channel_id}): {len(videos)} videos, has_next={next_cont is not None}")
    return videos, next_cont


# ---------------------------------------------------------------------------
#  VIDEO DETAILS
# ---------------------------------------------------------------------------
def video_details(video_id: str) -> dict:
    """
    Metadata videa + doporucena videa.
    Vraci dict s klici: video_id, title, channel, channel_id, description,
                        views, duration, thumb, published, related_videos.
    """
    resp = _innertube("next", {"videoId": video_id})

    # Primary info
    results = _dig(resp, "contents", "twoColumnWatchNextResults",
                   "results", "results", "contents") or []

    title = ""
    channel = ""
    channel_id = ""
    description = ""
    views = 0
    published = ""

    for item in results:
        if "videoPrimaryInfoRenderer" in item:
            pri = item["videoPrimaryInfoRenderer"]
            title = _txt(pri.get("title", {}))
            views_text = _txt(pri.get("viewCount", {}).get("videoViewCountRenderer", {}).get("viewCount", {}))
            nums = re.sub(r"[^\d]", "", views_text)
            if nums:
                views = int(nums)
            published = _txt(pri.get("dateText", {}))

        if "videoSecondaryInfoRenderer" in item:
            sec = item["videoSecondaryInfoRenderer"]
            owner = sec.get("owner", {}).get("videoOwnerRenderer", {})
            channel = _txt(owner.get("title", {}))
            nav = _dig(owner, "title", "runs", 0, "navigationEndpoint", "browseEndpoint")
            if nav:
                channel_id = nav.get("browseId", "")
            desc = sec.get("attributedDescription", {})
            description = desc.get("content", "")

    # Related / doporucena videa
    related = []
    secondary = _dig(resp, "contents", "twoColumnWatchNextResults",
                      "secondaryResults", "secondaryResults", "results") or []
    for item in secondary:
        if "compactVideoRenderer" in item:
            cvr = item["compactVideoRenderer"]
            v = _parse_video(cvr)
            if v:
                related.append(v)

    return {
        "video_id": video_id,
        "title": title,
        "channel": channel,
        "channel_id": channel_id,
        "description": description,
        "views": views,
        "published": published,
        "thumb": f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
        "related_videos": related,
    }


# ---------------------------------------------------------------------------
#  YT-DLP SUBPROCESS
# ---------------------------------------------------------------------------
_YTDLP_CMD = None  # cached command; None = not yet checked

def _find_ytdlp() -> list[str] | None:
    """Najde yt-dlp na systemu. Vraci command list nebo None."""
    global _YTDLP_CMD
    if _YTDLP_CMD is not None:
        return _YTDLP_CMD if _YTDLP_CMD else None

    import shutil
    # 1) yt-dlp v PATH
    if shutil.which("yt-dlp"):
        _YTDLP_CMD = ["yt-dlp"]
        return _YTDLP_CMD
    # 2) py -3 -m yt_dlp (pip install)
    try:
        r = subprocess.run(
            ["py", "-3", "-m", "yt_dlp", "--version"],
            capture_output=True, timeout=10, creationflags=_SP_FLAGS,
        )
        if r.returncode == 0:
            _YTDLP_CMD = ["py", "-3", "-m", "yt_dlp"]
            return _YTDLP_CMD
    except Exception:
        pass
    # 3) python -m yt_dlp
    try:
        r = subprocess.run(
            ["python", "-m", "yt_dlp", "--version"],
            capture_output=True, timeout=10, creationflags=_SP_FLAGS,
        )
        if r.returncode == 0:
            _YTDLP_CMD = ["python", "-m", "yt_dlp"]
            return _YTDLP_CMD
    except Exception:
        pass

    _YTDLP_CMD = []  # prazdny list = not found (cache)
    return None


def _gate_resolve_formats(video_id: str) -> list[dict] | None:
    """Gate yt-dlp resolve jako SECONDARY path pro zařízení bez local
    yt-dlp (Phase G5, 2026-04-19).

    NOT A SCRAPING FALLBACK — je to deliberate dual-path strategie:
    YouTube SABR/PO-token restrikce vrací na server-IP typicky jen 360p
    progressive, takže local-first (residential IP → 1080p+) je primární
    cesta. Gate vrací secondary 360p jen když zařízení nemá yt-dlp.

    Returns list na úspěch, None když Gate nedostupný / nemá výsledek.
    None umožňuje caller (_ytdlp_formats) fail-fast propagaci.
    """
    try:
        ws_username, ws_proof = _gate_get_identity()
    except Exception:
        return None
    if not ws_username or not ws_proof:
        return None

    url = f"{_GATE_URL}/v1/sources/youtube/resolve"
    payload = json.dumps({"video_id": video_id}, ensure_ascii=False).encode("utf-8")
    headers = {
        "User-Agent": f"RichMovie/{_ADDON_VERSION} (+plugin.video.richmovie)",
        "Accept": "application/json",
        "Accept-Encoding": "identity",
        "Content-Type": "application/json",
        "X-WS-Username": ws_username,
        "X-WS-Proof": ws_proof,
    }
    # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. Resolve je čtení
    # (extrakce formátů videa), takže `idempotent=True`. Profil `bulk` s timeoutem
    # 30 s zachovává původní hodnotu — yt-dlp extract je pomalejší než běžný dotaz.
    try:
        import richmovie_http as _rm_http
    except Exception as _imp_exc:  # pragma: no cover
        _log(f"richmovie_http chybi: {_imp_exc!r}")
        return None

    try:
        profile = _rm_http.profile_bulk().replace(timeout_s=30.0)
        status, raw, _hdrs = _rm_http.request(
            url, method="POST", headers=headers, data=payload,
            profile=profile, idempotent=True, tag="youtube_resolve",
        )
        if status != 200:
            _log(f"Gate non-200 youtube/resolve: {status}")
            return None
    except Exception as e:
        _log(f"Gate youtube/resolve error: {e}")
        return None
    try:
        envelope = json.loads(raw.decode("utf-8", errors="replace"))
    except Exception:
        return None
    if not isinstance(envelope, dict) or envelope.get("status") != "ok":
        return None
    formats = envelope.get("formats")
    if not isinstance(formats, list):
        return None
    duration = envelope.get("duration")
    _log(f"Gate yt-dlp({video_id}): {len(formats)} formats, dur={duration}")
    return formats


def _ytdlp_formats(video_id: str) -> list[dict] | None:
    """Získá yt-dlp formats list — dual-path (local primary, Gate secondary).

    YouTube SABR/PO-token restrikce vrací pro server-IP jen nízké kvality
    (360p progressive). Residenční IP addon-userů dostávají 1080p+.
    Takže NEJDŘÍV lokální yt-dlp (HQ), Gate jen pro zařízení BEZ lokálního
    yt-dlp (lepší 360p než nic). NOT A SCRAPING FALLBACK — viz
    `_gate_resolve_formats` docstring.

    Returns formats list nebo None (→ caller rozhodne jestli resolve_stream
    zkusí progressive nebo selže čistě).
    """
    cmd = _find_ytdlp()
    if cmd:
        try:
            r = subprocess.run(
                cmd + ["-j", "--no-playlist",
                       f"https://www.youtube.com/watch?v={video_id}"],
                capture_output=True, text=True, timeout=30,
                creationflags=_SP_FLAGS,
            )
            if r.returncode == 0:
                try:
                    data = json.loads(r.stdout)
                    formats = data.get("formats") or []
                    if formats:
                        duration = data.get("duration")
                        _log(f"yt-dlp({video_id}) local: "
                             f"{len(formats)} formats, dur={duration}")
                        return formats
                except Exception:
                    _log("yt-dlp: failed to parse local JSON output")
            else:
                _log(f"yt-dlp local failed (rc={r.returncode}): "
                     f"{r.stderr[:200]}")
        except Exception as e:
            _log(f"yt-dlp local subprocess error: {e}")

    # Secondary path — Gate má yt-dlp server-side (typicky 360p throttled
    # kvůli SABR restrikcím, ale dostupné na zařízeních bez local yt-dlp).
    _log(f"ytdlp_formats({video_id}): local unavailable, trying Gate secondary")
    gate_formats = _gate_resolve_formats(video_id)
    if gate_formats:
        return gate_formats
    _log(f"ytdlp_formats({video_id}): ani local ani Gate nevrátily formáty")
    return None


# ---------------------------------------------------------------------------
#  STREAM RESOLUTION
# ---------------------------------------------------------------------------
def resolve_stream(video_id: str) -> dict | None:
    """
    Resolve playable stream URL pro video.
    Pouziva yt-dlp subprocess pro ziskani URL (handles poToken, n-param).

    Vraci dict s klici:
        mode       "dash" | "progressive"
        --- dash mode ---
        mpd        str (MPD XML manifest pro inputstream.adaptive)
        quality    str ("1080p" apod.)
        url        str (progressive fallback URL, muze byt prazdny)
        --- progressive mode ---
        url        str (prima stream URL)
        quality    str
        mime       str
        width      int
        height     int
    """
    formats = _ytdlp_formats(video_id)
    if not formats:
        _log(f"resolve_stream({video_id}): no formats from yt-dlp")
        return None

    # --- Rozdeleni formatu ---
    # Progressive = video+audio v jednom souboru
    prog_formats = [
        f for f in formats
        if f.get("url")
        and f.get("vcodec", "none") != "none"
        and f.get("acodec", "none") != "none"
    ]
    # Video-only (MP4: avc1 az 1080p, av01 az 4K)
    vid_formats = [
        f for f in formats
        if f.get("url")
        and f.get("vcodec", "none") != "none"
        and f.get("acodec", "none") == "none"
        and f.get("ext") == "mp4"
        and ("avc1" in f.get("vcodec", "") or "av01" in f.get("vcodec", ""))
    ]
    # Audio-only (m4a)
    aud_formats = [
        f for f in formats
        if f.get("url")
        and f.get("vcodec", "none") == "none"
        and f.get("acodec", "none") != "none"
        and f.get("ext") == "m4a"
    ]

    # Progressive URL (360p fallback)
    prog_url = ""
    best_prog = None
    if prog_formats:
        best_prog = max(prog_formats, key=lambda f: f.get("height", 0))
        prog_url = best_prog["url"]

    # --- 1) DASH: video + audio (720p/1080p) ---
    if vid_formats and aud_formats:
        dash = _build_dash_ytdlp(vid_formats, aud_formats)
        if dash:
            dash["url"] = prog_url
            return dash

    # --- 2) Progressive (360p) ---
    if prog_url:
        quality = best_prog.get("format_note", "360p")
        _log(f"resolve_stream({video_id}): progressive {quality}")
        return {
            "mode": "progressive",
            "url": prog_url,
            "quality": quality,
            "mime": "video/mp4",
            "width": best_prog.get("width", 0),
            "height": best_prog.get("height", 0),
        }

    _log(f"resolve_stream({video_id}): no usable formats")
    return None


def _build_dash_ytdlp(
    vid_formats: list[dict],
    aud_formats: list[dict],
) -> dict | None:
    """
    Sestavi multi-representation MPD manifest z yt-dlp formatu.
    Obsahuje vsechny dostupne video kvality (360p-4K) + audio,
    inputstream.adaptive automaticky vybere dle rychlosti pripojeni.
    """
    if not vid_formats or not aud_formats:
        return None

    # Rozdeleni na kodekove rodiny (avc1 vs av01)
    avc_formats = [v for v in vid_formats if "avc1" in v.get("vcodec", "")]
    av1_formats = [v for v in vid_formats if "av01" in v.get("vcodec", "")]

    # Deduplikace: pouze jeden format na vysku per kodek (preferuj vyssi bitrate)
    def _dedup(fmts: list[dict]) -> list[dict]:
        by_h: dict[int, dict] = {}
        for v in fmts:
            h = v.get("height", 0)
            if h < 360:
                continue
            if h not in by_h or (v.get("vbr") or 0) > (by_h[h].get("vbr") or 0):
                by_h[h] = v
        return sorted(by_h.values(), key=lambda f: f.get("height", 0), reverse=True)

    avc_dedup = _dedup(avc_formats)
    av1_dedup = _dedup(av1_formats)
    # Slouci: nejdriv AV1 (vyssi kvalita), pak avc1
    sorted_videos = av1_dedup + [v for v in avc_dedup
                                  if v.get("height", 0) not in
                                  {x.get("height", 0) for x in av1_dedup}]
    if not sorted_videos:
        return None
    sorted_videos.sort(key=lambda f: f.get("height", 0), reverse=True)
    best_height = sorted_videos[0].get("height", 0)

    # Audio: vsechny m4a formaty (deduplikace dle bitrate)
    seen_abr = set()
    unique_audios = []
    for a in sorted(aud_formats, key=lambda f: f.get("abr", 0), reverse=True):
        abr = int(a.get("abr", 0))
        if abr not in seen_abr:
            seen_abr.add(abr)
            unique_audios.append(a)

    # Duration
    dur_s = 300
    first = sorted_videos[0]
    if first.get("duration"):
        dur_s = int(first["duration"])
    else:
        vbr = (first.get("vbr") or first.get("tbr") or 0) * 1000
        if vbr > 0 and first.get("filesize"):
            dur_s = int(first["filesize"] * 8 / vbr)
    dur_h = dur_s // 3600
    dur_m = (dur_s % 3600) // 60
    dur_sec = dur_s % 60
    pt_dur = f"PT{dur_h}H{dur_m}M{dur_sec}S"

    from xml.sax.saxutils import escape as xml_escape

    def _make_rep(idx: int, prefix: str, f: dict, is_audio: bool = False) -> str:
        bw = int((f.get("abr" if is_audio else "vbr") or f.get("tbr") or 0) * 1000)
        codec = f.get("acodec" if is_audio else "vcodec", "")
        if is_audio:
            sr = f.get("asr", 44100)
            return (
                f'      <Representation id="{prefix}{idx}" bandwidth="{bw}"'
                f' codecs="{codec}" audioSamplingRate="{sr}">\n'
                f'        <BaseURL>{xml_escape(f["url"])}</BaseURL>\n'
                f'      </Representation>'
            )
        w = f.get("width", 0)
        h = f.get("height", 0)
        return (
            f'      <Representation id="{prefix}{idx}" bandwidth="{bw}"'
            f' codecs="{codec}" width="{w}" height="{h}">\n'
            f'        <BaseURL>{xml_escape(f["url"])}</BaseURL>\n'
            f'      </Representation>'
        )

    # Video AdaptationSets - separatni per kodek
    v_sets = []
    for codec_family, fmts in [("avc1", avc_dedup), ("av01", av1_dedup)]:
        if not fmts:
            continue
        reps = "\n".join(_make_rep(i, f"v{codec_family[0]}", f) for i, f in enumerate(fmts))
        v_sets.append(
            f'    <AdaptationSet mimeType="video/mp4" contentType="video">\n'
            f'{reps}\n'
            f'    </AdaptationSet>'
        )

    # Audio AdaptationSet
    a_reps = "\n".join(_make_rep(i, "a", a, is_audio=True) for i, a in enumerate(unique_audios))

    mpd = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011"'
        ' profiles="urn:mpeg:dash:profile:isoff-on-demand:2011"'
        f' type="static" mediaPresentationDuration="{pt_dur}" minBufferTime="PT2S">\n'
        f'  <Period duration="{pt_dur}">\n'
        + "\n".join(v_sets) + "\n"
        f'    <AdaptationSet mimeType="audio/mp4" contentType="audio">\n'
        f'{a_reps}\n'
        f'    </AdaptationSet>\n'
        '  </Period>\n'
        '</MPD>'
    )

    quality = f"{best_height}p"
    heights = [v.get("height", 0) for v in sorted_videos]
    _log(f"resolve_stream DASH: {quality} max, {len(sorted_videos)} qualities "
         f"({', '.join(str(h) + 'p' for h in heights)}) + "
         f"{len(unique_audios)} audio (yt-dlp)")
    return {
        "mode": "dash",
        "mpd": mpd,
        "quality": quality,
    }


def resolve_stream_progressive(video_id: str) -> dict | None:
    """
    Resolve pouze progressive format (video+audio v jednom souboru).
    Pouzije se jako fallback pokud neni dostupny inputstream.adaptive.
    """
    formats = _ytdlp_formats(video_id)
    if not formats:
        return None

    prog = [
        f for f in formats
        if f.get("url")
        and f.get("vcodec", "none") != "none"
        and f.get("acodec", "none") != "none"
    ]
    if not prog:
        return None

    best = max(prog, key=lambda f: f.get("height", 0))
    quality = best.get("format_note", "360p")
    _log(f"resolve_stream_progressive({video_id}): {quality}")
    return {
        "mode": "progressive",
        "url": best["url"],
        "quality": quality,
        "mime": "video/mp4",
        "width": best.get("width", 0),
        "height": best.get("height", 0),
    }


# ---------------------------------------------------------------------------
#  FORMAT HELPERS (pro budouci pouziti)
# ---------------------------------------------------------------------------
def format_views(count: int) -> str:
    """Formatuje pocet zhlednuti: 1500000 -> '1.5M'."""
    if count >= 1_000_000:
        return f"{count / 1_000_000:.1f}M"
    if count >= 1_000:
        return f"{count / 1_000:.0f}K"
    return str(count)


def format_duration(seconds: int) -> str:
    """Formatuje delku: 3723 -> '1:02:03'."""
    if seconds <= 0:
        return ""
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h > 0:
        return f"{h}:{m:02}:{s:02}"
    return f"{m}:{s:02}"
