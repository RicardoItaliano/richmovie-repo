# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – SSOT „Kdo se dívá?" (uživatelské profily, 3.5.134)
───────────────────────────────────────────────────────────────────────────────
Plán: Handoff/PLAN_profiles_multi_user_20260905.md (D1–D14). Jediné místo, které
ví, jaký profil je aktivní, v jakém režimu účet je a jak se to hlásí Gate.

Stav (účtový soubor `profile_state.json` + Window property pro službu):
  mode            'unset' | 'single' | 'multi'   (z /auth → Gate je zdroj pravdy)
  current_id      id profilu | 0 (Host) | None (nevybráno)
  current_name, current_slot, current_is_owner
  profiles        seznam z Gate (id, name, slot, is_owner, last_used_at, has_avatar, avatar_etag)
  list_version    otisk seznamu z Gate (D14 – změny fotky/jména bez restartu)
  fetched_at      kdy byl seznam naposledy z Gate

Pravidla:
  • single / unset  → `personal_dir_key()` = None → osobní soubory v kořeni (3.5.133 chování, 15 uživatelů beze změny)
  • multi + profil  → `profiles/<id>`; Host → `profiles/guest` (vyprázdní se při každém výběru Hosta, nic se nehlásí)
  • multi bez výběru (po startu Kodi před chooserem) → poslední zvolený profil na tomto zařízení (D7: služba
    a Next-Up nikdy nepracují „do prázdna"; autoplay bez profilu se nespustí — viz `has_active_profile()`)
  • R2: Gate nedostupný → chooser jede z cache; setup (jednorázový) se bez Gate nedělá; nic se lokálně „nevymýšlí"
  • onboarding unset → multi je All-or-Nothing (Gate `/setup` → přesun souborů → zápis stavu; jinak rollback)
  • převod „Jen já“ → více profilů (S24, 15.10.2026) jde TOUŽ cestou Gate `/setup` — samoobsluha `setup_multi(from_single)`,
    převod jinde (jiné zařízení, admin) zachytí `/auth` → `apply_auth_block` → `request_chooser` (výběr hned, ne po restartu)
═══════════════════════════════════════════════════════════════════════════════
"""
from __future__ import annotations

import json
import os
import shutil
import time
import urllib.parse
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import xbmc

import richmovie_paths
import richmovie_winprops

STATE_FILE = "profile_state.json"
PROP_PROFILE_ID = "RichMovie.Profile.Id"          # "" = nevybráno, "0" = Host, "<id>"
PROP_PROFILE_NAME = "RichMovie.Profile.Name"
PROP_PROFILE_MODE = "RichMovie.Profile.Mode"

MODE_UNSET = "unset"
MODE_SINGLE = "single"
MODE_MULTI = "multi"
GUEST_ID = 0
GUEST_NAME = "Host"
UNASSIGNED_DIRNAME = "_unassigned"   # multi bez zvoleného profilu: osobní zápisy sem, ne do kořene (Fable P2-9)
PROP_FORCE_CHOOSER = "RichMovie.Profile.ForceChooser"   # smazaný/zmizelý aktivní profil → chooser znovu
STATE_LOCK_STALE_S = 10.0

PROFILES_MAX = 5              # zrcadlo Gate settings.PROFILES_MAX (Gate je autorita, tady jen UI strop)
NAME_MAX = 24

# Barvy siluet podle slotu (D9) — stálé, z dálky rozlišitelné (ARGB pro colordiffuse).
SLOT_COLORS = {1: "FF3E9BF0", 2: "FF9B59B6", 3: "FF2ECC71", 4: "FFF39C12", 5: "FFE74C3C"}
GUEST_COLOR = "FF7F8C8D"

# SSOT věta pro chooser i onboarding (Richie 05.09.: „ať to lidi neignorují").
WHY_PROFILE_MATTERS = ("Vyber, kdo se dívá. Podle profilu se ukládá historie, Pokračovat na všech "
                       "zařízeních i doporučení — špatný profil = špatná doporučení.")

_LOG_PREFIX = "[RichMovie][profile]"
LEGACY_DIRNAME = "_legacy"        # historie z doby před profily na zařízení, které NEpatří majiteli (D4)
MIGRATION_MARKER = ".migration_pending"


try:
    from richmovie_logging import make_legacy_logger as _mk_logger
    _log = _mk_logger("richmovie.profile", _LOG_PREFIX)   # routovaný logger → user_logs (Fable P2-5)
except Exception:  # harness / nástroje mimo Kodi
    def _log(msg: str, level: int = xbmc.LOGINFO) -> None:
        xbmc.log("%s %s" % (_LOG_PREFIX, msg), level)


# ─────────────────────────────────────────────────────────────────────────────
#  Stav (soubor + Window property)
# ─────────────────────────────────────────────────────────────────────────────

def _state_path() -> Path:
    return richmovie_paths.account_path(STATE_FILE)


def _empty_state() -> Dict[str, Any]:
    return {"mode": MODE_UNSET, "current_id": None, "current_name": "", "current_slot": 0,
            "current_is_owner": False, "profiles": [], "list_version": "", "fetched_at": 0,
            "count": 0, "max": PROFILES_MAX, "setup_required": False, "device_owner_profile_id": None,
            # 3.5.147 (Φ1 noc 09.→10.09.): kolikrát uživatel onboarding odložil („Později") a kdy se ptalo naposled
            "onboarding_later": 0, "onboarding_last_ask": 0}


# ── Onboarding u `unset` účtu: neotravovat při každém startu (3.5.147, D1) ──────────────
# Do 3.5.146 se velký dialog „Kdo se dívá?" ukázal při KAŽDÉM startu Kodi, dokud člověk
# nerozhodl; volba „Později" se nelogovala (9 účtů rodiny v `unset`, incident Róbert 09.09.).
ONBOARDING_LATER_THRESHOLD = 3     # od 3. „Později" = zjednodušený dotaz s doporučením „Jen já"
ONBOARDING_REASK_S = 24 * 3600     # …a nejvýš jednou za den


def onboarding_simplified(st: Dict[str, Any]) -> bool:
    """Už tolikrát odloženo, že se má nabídnout jednoduchá volba s doporučením „Jen já"."""
    return int(st.get("onboarding_later") or 0) >= ONBOARDING_LATER_THRESHOLD


def onboarding_should_ask(st: Dict[str, Any], now: float) -> bool:
    """Ptát se při tomto startu? Prvních `ONBOARDING_LATER_THRESHOLD` odložení = při každém
    startu (rozhodnutí je důležité), pak nejvýš jednou za `ONBOARDING_REASK_S`."""
    if st.get("mode") != MODE_UNSET or not st.get("setup_required"):
        return False
    if not onboarding_simplified(st):
        return True
    last = float(st.get("onboarding_last_ask") or 0)
    return (float(now) - last) >= ONBOARDING_REASK_S


def note_onboarding_later(now: Optional[float] = None) -> Dict[str, Any]:
    """Uživatel dal „Později"/zavřel dialog → počítadlo + razítko (atomicky, pod zámkem)."""
    import time as _time
    ts = float(now if now is not None else _time.time())

    def _fn(st: Dict[str, Any]) -> bool:
        st["onboarding_later"] = int(st.get("onboarding_later") or 0) + 1
        st["onboarding_last_ask"] = ts
        return True

    return _mutate(_fn)


def _state_lock():
    """Meziprocesový zámek `profile_state.json` (Fable P1-1): plugin (chooser, /auth blok)
    a služba (seznam profilů každých 30 s) dělají read-modify-write téhož souboru.
    Každý zápis = načíst POD zámkem, změnit, uložit."""
    import richmovie_atomic as _atomic
    return _atomic.FileLock(str(_state_path()) + ".lock", stale_s=STATE_LOCK_STALE_S)


def _mutate(fn) -> Dict[str, Any]:
    """Atomický read-modify-write stavu: `fn(st) -> bool` (True = uložit)."""
    with _state_lock():
        st = load_state(force_refresh=True)
        if fn(st):
            save_state(st)
        return st


_state_cache = {"path": "", "key": None, "state": None}   # (mtime, size) → poslední načtený stav


def load_state(*, force_refresh: bool = False) -> Dict[str, Any]:
    """Stav profilu ze souboru; parsuje se jen když se soubor změnil (mtime_ns+size) —
    služba se ptá každých 5 s (`sync_scope`), chybějící soubor = prázdný stav bez
    opakovaného logu READ_NO_FILE. `force_refresh` = pod zámkem VŽDY z disku
    (cross-check T1 Pro P3: stejná velikost + hrubé mtime by vrátilo starou kopii).
    Vrací vždy novou kopii (volající mutují)."""
    import os as _os
    path = str(_state_path())
    try:
        st_ = _os.stat(path)
        key = (getattr(st_, "st_mtime_ns", st_.st_mtime), st_.st_size)
    except OSError:
        key = None
    c = _state_cache
    if not force_refresh and c["path"] == path and c["key"] == key and c["state"] is not None:
        return dict(c["state"])
    data = None
    if key is not None:
        try:
            import richmovie_atomic as _atomic
            data, _state = _atomic.read_json(path, None, name="profile_state", expected_type=dict)
        except Exception:
            data = None
    st = _empty_state()
    if isinstance(data, dict):
        st.update({k: v for k, v in data.items() if k in st})
    c.update({"path": path, "key": key, "state": dict(st)})
    return st


def save_state(st: Dict[str, Any]) -> bool:
    try:
        import richmovie_atomic as _atomic
        _state_cache["key"] = None   # po zápisu znovu načíst (mtime se změní; jistota i při stejném rozlišení)
        ok = _atomic.write_json(str(_state_path()), st, indent=2)
    except Exception as exc:
        _log("state save failed: %r" % (exc,), xbmc.LOGWARNING)
        ok = False
    _publish_props(st)
    return ok


def _publish_props(st: Dict[str, Any]) -> None:
    """Window property = kanál do procesu služby (service_nextup) a MI2 vláken."""
    cid = st.get("current_id")
    richmovie_winprops.set_prop(PROP_PROFILE_ID, "" if cid is None else str(int(cid)))
    richmovie_winprops.set_prop(PROP_PROFILE_NAME, str(st.get("current_name") or ""))
    richmovie_winprops.set_prop(PROP_PROFILE_MODE, str(st.get("mode") or MODE_UNSET))


def mode() -> str:
    m = richmovie_winprops.get_prop(PROP_PROFILE_MODE, "")
    if m:
        return m
    return load_state().get("mode") or MODE_UNSET


def is_multi() -> bool:
    return mode() == MODE_MULTI


def current_id() -> Optional[int]:
    """Aktivní profil: Window prop (rychlé, cross-process) → stav na disku (po startu
    služby před pluginem). None = single/unset NEBO multi bez volby."""
    raw = richmovie_winprops.get_prop(PROP_PROFILE_ID, "")
    if raw not in ("", None):
        try:
            return int(raw)
        except ValueError:
            pass
    st = load_state()
    if st.get("mode") != MODE_MULTI:
        return None
    cid = st.get("current_id")
    if cid is None:
        return None
    _publish_props(st)   # služba startuje dřív než plugin → doplň prop ze stavu
    return int(cid)


def is_guest() -> bool:
    return is_multi() and current_id() == GUEST_ID


def has_active_profile() -> bool:
    """multi: profil (ne Host, ne nevybráno); single/unset: vždy True."""
    if not is_multi():
        return True
    cid = current_id()
    return cid is not None and cid != GUEST_ID


def personal_dir_key() -> Optional[str]:
    """Klíč podadresáře osobních dat pro `richmovie_paths.personal_dir()`."""
    if not is_multi():
        return None
    cid = current_id()
    if cid is None:
        return UNASSIGNED_DIRNAME   # multi bez volby: nic do kořene (kořen = data z doby před profily → majitel)
    if cid == GUEST_ID:
        return richmovie_paths.GUEST_DIRNAME
    return str(cid)


def current() -> Dict[str, Any]:
    st = load_state()
    cid = current_id()
    return {"id": cid, "name": st.get("current_name") or (GUEST_NAME if cid == GUEST_ID else ""),
            "slot": int(st.get("current_slot") or 0), "is_owner": bool(st.get("current_is_owner")),
            "is_guest": cid == GUEST_ID, "mode": st.get("mode")}


def slot_color(slot: int, *, guest: bool = False) -> str:
    if guest:
        return GUEST_COLOR
    return SLOT_COLORS.get(int(slot or 0), SLOT_COLORS[1])


def autoplay_allowed() -> bool:
    """D12: Host smí Next-Up (bez zápisu); multi bez zvoleného profilu ne (nevíme, čí
    díl by to byl). Persistenci hlídá `has_active_profile()` — dvě různé otázky."""
    if not is_multi():
        return True
    return current_id() is not None


def telemetry_profile_id() -> Optional[int]:
    """Co posílat v eventech: id profilu; None u single/unset. Host → eventy se
    neposílají vůbec (volající kontroluje `is_guest()`)."""
    if not is_multi():
        return None
    cid = current_id()
    if cid is None or cid == GUEST_ID:
        return None
    return int(cid)


# ─────────────────────────────────────────────────────────────────────────────
#  /auth blok + Gate klient
# ─────────────────────────────────────────────────────────────────────────────

def became_multi(prev_mode: Optional[str], new_mode: Optional[str]) -> bool:
    """Čistá (S24, 15.10.2026): účet právě přešel na více profilů (z „Jen já“ / nerozhodnuto), ne na tomto zařízení
    vlastním setupem (ten zapisuje režim sám, `setup_multi`). Spouští výběr „Kdo se dívá?“ hned, ne až po restartu."""
    return new_mode == MODE_MULTI and (prev_mode or MODE_UNSET) != MODE_MULTI


def _fill_current_from_cache(st: Dict[str, Any]) -> None:
    """Jméno/slot/majitel aktivního profilu z uloženého seznamu (S24 R4): `current_id` přišel z `/auth`
    (`last_profile_id`) bez jména → řádek „Dívá se:“ by do tiku služby ukazoval „nevybráno“."""
    cid = st.get("current_id")
    if cid is None:
        return
    for p in st.get("profiles") or []:
        try:
            if int(p.get("id", -1)) == int(cid):
                st["current_name"] = str(p.get("name") or "")
                st["current_slot"] = int(p.get("slot") or 0)
                st["current_is_owner"] = bool(p.get("is_owner"))
                return
        except (TypeError, ValueError):
            continue


def request_chooser(reason: str) -> None:
    """Výběr „Kdo se dívá?“ při NEJBLIŽŠÍ stavbě hlavního menu v tomto běhu Kodi (S24 D5) — JEDINÉ místo, které to umí:
    `PROP_FORCE_CHOOSER` (krok profilu výběr ukáže i po dřívější volbě) + znovu otevřená uvítací sekvence (jinak je
    v tomto běhu Kodi „hotová“ a krok profilu by do restartu neproběhl — do S24 tak tiše selhávala i větev „profil
    smazán v Gate“ níže). Idempotentní kroky sekvence před profilem nic nezobrazí. Nikdy nevyhazuje."""
    try:
        richmovie_winprops.set_prop(PROP_FORCE_CHOOSER, "1")
        import richmovie_onboarding as _ob
        _ob.reopen(reason)
    except Exception as exc:
        _log("request_chooser(%s) failed: %r" % (reason, exc), xbmc.LOGWARNING)


def _on_became_multi(st: Dict[str, Any]) -> None:
    """S24 / D5: účet přešel na více profilů (převod jinde — samoobsluha na jiném zařízení, správce v adminu) →
    výběr HNED v tomto běhu Kodi. Překreslení menu žádá jen volající z pozadí
    (`richmovie_profile_ui.after_background_auth`) — `/auth` v popředí běží PŘED krokem profilu téhož menu."""
    request_chooser("profile_mode_multi")
    _log("MODE_SWITCH → multi (current_id=%s) — výběr profilu vyžádán" % (st.get("current_id"),))


def needs_profile_list(st: Optional[Dict[str, Any]] = None) -> bool:
    """Multi účet bez použitelného seznamu profilů (S24 R4): chybí seznam, nebo v něm není aktivní profil / chybí
    jeho jméno → stáhnout `GET /v1/profiles/` (jména, pořadí, fotky)."""
    st = st or load_state()
    if st.get("mode") != MODE_MULTI:
        return False
    if not st.get("profiles"):
        return True
    cid = st.get("current_id")
    return cid not in (None, GUEST_ID) and not st.get("current_name")


def telemetry_profile_mode() -> Optional[str]:
    """Režim profilů v okamžiku vzniku události (S24 D3): Gate podle něj přiřadí událost bez profilu z doby
    „Jen já“ majiteli, i když dorazí až po přepnutí účtu (trvanlivý buffer telemetrie)."""
    try:
        m = mode()
        return m if m in (MODE_UNSET, MODE_SINGLE, MODE_MULTI) else None
    except Exception:
        return None


def apply_auth_block(block: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Z `/auth.profiles` (mode/count/setup_required/last_profile_id). Starší Gate
    bez bloku → beze změny (stav zůstává). Vrací aktuální stav.
    S24: přechod na multi (`became_multi`) → `_on_became_multi` (výběr profilu hned, ne po restartu Kodi)."""
    if not isinstance(block, dict):
        return load_state()
    new_mode = str(block.get("mode") or MODE_UNSET)
    mode_changed = {"v": False}
    prev = {"mode": None}

    def _apply(st: Dict[str, Any]) -> bool:
        before = dict(st)
        prev["mode"] = st.get("mode")
        mode_changed["v"] = new_mode != st.get("mode")
        st["mode"] = new_mode
        st["count"] = int(block.get("count") or 0)
        st["max"] = int(block.get("max") or PROFILES_MAX)
        st["setup_required"] = bool(block.get("setup_required"))
        try:
            st["device_owner_profile_id"] = int(block["device_owner_profile_id"]) if block.get("device_owner_profile_id") else None
        except (TypeError, ValueError):
            st["device_owner_profile_id"] = None
        if new_mode != MODE_MULTI:
            st["current_id"] = None
            st["current_name"] = ""
            st["current_slot"] = 0
            st["current_is_owner"] = False
        elif st.get("current_id") is None and block.get("last_profile_id"):
            st["current_id"] = int(block["last_profile_id"])
            _fill_current_from_cache(st)   # S24 R4: jméno hned, když seznam už je v cache
        return st != before   # zápis jen při změně (Fable P3-7)

    st = _mutate(_apply)
    if mode_changed["v"]:
        _log("mode from /auth: %s (count=%s)" % (new_mode, st["count"]))
    if became_multi(prev["mode"], new_mode):
        _on_became_multi(st)
    return st


class ProfileGateError(Exception):
    def __init__(self, code: str, transient: bool, detail: str = "") -> None:
        self.code = code
        self.transient = transient
        self.detail = detail
        super().__init__("%s (%s)" % (code, "transient" if transient else "authoritative"))


NOT_MODIFIED = {"unchanged": True}


def _check_identity_allowed() -> None:
    """Fable P3-2: po autoritativním 403 (REJECTED) fail-fast lokálně — žádné N × 403
    z chooseru/fotek; `/auth` je cesta zotavení a jde jinudy."""
    try:
        import richmovie_identity_state as _ident
        if not _ident.allow_gate_request():
            raise ProfileGateError("identity", False, "identity rejected by Gate")
    except ProfileGateError:
        raise
    except Exception:
        pass


def _http_profile(_rm_http, timeout: float, *, quick: bool = False, background: bool = False):
    """quick = jeden pokus, celý rozpočet = timeout (render hlavního menu, Fable P2-10);
    background = profil služby; jinak foreground (UI cesta s retry rozpočtem)."""
    base = _rm_http.profile_background() if background else _rm_http.profile_foreground()
    if quick:
        return base.replace(timeout_s=float(timeout), budget_s=float(timeout), max_attempts=1)
    return base.replace(timeout_s=float(timeout))


def _gate_get(path: str, params: Optional[Dict[str, Any]] = None, timeout: float = 12.0,
              *, etag: Optional[str] = None, quick: bool = False, background: bool = False) -> Dict[str, Any]:
    """GET s identitou v query. `etag` → `If-None-Match`; 304 vrací `NOT_MODIFIED`
    (seznam profilů se každých 30 s NEparsuje ani nepřenáší, cross-check PC10)."""
    import richmovie_http as _rm_http
    from richmovie_gate_transport import GATE_URL, auth_header, gate_headers, get_device_hash, get_identity
    _check_identity_allowed()
    username, proof = get_identity()
    if not username:
        raise ProfileGateError("no_identity", False)
    qp = dict(params or {})
    qp.update({"device_hash": get_device_hash() or ""})   # identita jde v hlavičce (3.5.147, D6)
    url = "%s%s?%s" % (GATE_URL, path, urllib.parse.urlencode(qp))
    profile = _http_profile(_rm_http, timeout, quick=quick, background=background)
    headers = gate_headers()   # User-Agent povinný (Cloudflare) — incident 05.09.2026
    headers.update(auth_header(username, proof))
    if etag:
        headers["If-None-Match"] = '"%s"' % etag
    try:
        status, raw, _hdrs = _rm_http.request(url, headers=headers, profile=profile, tag="profiles")
    except _rm_http.TransientError as exc:
        raise ProfileGateError("transport", True, repr(exc))
    except Exception as exc:
        raise ProfileGateError("transport", True, repr(exc))
    if int(status) == 304 and etag:
        return NOT_MODIFIED
    return _decode(status, raw)


def _gate_post(path: str, body: Dict[str, Any], timeout: float = 20.0) -> Dict[str, Any]:
    from richmovie_gate_transport import build_common_fields, post_json
    full = dict(body)
    full.update(build_common_fields())
    try:
        status, parsed = post_json(path, full, timeout=timeout)
    except Exception as exc:
        raise ProfileGateError("transport", True, repr(exc))
    if isinstance(parsed, dict) and 200 <= int(status) < 300:
        return parsed
    return _decode(status, json.dumps(parsed).encode() if isinstance(parsed, (dict, list)) else b"")


def _decode(status: int, raw: bytes) -> Dict[str, Any]:
    try:
        data = json.loads(raw.decode("utf-8")) if raw else {}
    except Exception:
        data = {}
    if 200 <= int(status) < 300 and isinstance(data, dict):
        return data
    code = "http_%s" % status
    if isinstance(data, dict):
        err = data.get("detail", data.get("error"))
        if isinstance(err, dict):
            err = err.get("error", err)
        if isinstance(err, dict) and err.get("code"):
            code = str(err["code"])
        elif isinstance(err, str) and err:
            code = err
    transient = int(status) in (0, 408, 425, 429, 502, 503, 504) or int(status) >= 500
    if int(status) in (401, 403) and code.startswith("http_"):
        # bez Gate JSON kódu = Cloudflare/edge (bot fight, browser integrity) → transport, ne identita
        code, transient = "edge_blocked", True
    raise ProfileGateError(code, transient, str(data)[:200])


def _apply_list(st: Dict[str, Any], data: Dict[str, Any]) -> Dict[str, Any]:
    st["mode"] = str(data.get("mode") or st.get("mode") or MODE_UNSET)
    st["max"] = int(data.get("max") or PROFILES_MAX)
    st["profiles"] = [p for p in (data.get("profiles") or []) if isinstance(p, dict)]
    st["count"] = len(st["profiles"])
    st["list_version"] = str(data.get("version") or "")
    st["fetched_at"] = int(time.time())
    st["setup_required"] = st["mode"] == MODE_UNSET
    ids = {int(p.get("id")) for p in st["profiles"] if p.get("id") is not None}
    cid = st.get("current_id")
    if cid not in (None, GUEST_ID) and int(cid) not in ids:
        st["current_id"] = None      # profil smazán v Gate (D14) → chooser při dalším otevření menu
        st["current_name"] = ""
        request_chooser("profile_gone")   # S24: i když už uvítací sekvence v tomto běhu Kodi proběhla
    if st.get("current_id") is None and data.get("last_profile_id") in ids:
        st["current_id"] = int(data["last_profile_id"])
    for p in st["profiles"]:
        if st.get("current_id") is not None and int(p.get("id", -1)) == int(st["current_id"]):
            st["current_name"] = str(p.get("name") or "")
            st["current_slot"] = int(p.get("slot") or 0)
            st["current_is_owner"] = bool(p.get("is_owner"))
    return st


def fetch_profiles() -> Dict[str, Any]:
    """GET /v1/profiles/ → aktualizuje stav. Při chybě vyhodí ProfileGateError
    (volající použije cache — `load_state()`)."""
    data = _gate_get("/v1/profiles/")
    st = _mutate(lambda st_: bool(_apply_list(st_, data)))   # čerstvý stav pod zámkem (Fable P1-1)
    _sync_avatars_background(st)   # Φ4/D14: chooser se nezdrží (cross-check PC9); fotky doskočí
    return st


_avatar_thread = {"thread": None}


def _sync_avatars_background(st: Dict[str, Any]) -> None:
    """Stažení fotek mimo UI vlákno (non-daemon: Kodi shutdown ho počká, síť má
    vlastní timeouty). Chooser vykreslí cache/siluetu a při dalším otevření už
    fotku; službě to doplní stejný tik (`refresh_list_if_changed`)."""
    import threading
    th = _avatar_thread["thread"]
    if th is not None and th.is_alive():
        return

    def _work() -> None:
        try:
            sync_avatars(st, timeout=6.0)
        except Exception as exc:
            _log("avatar sync (background) failed: %r" % exc, xbmc.LOGWARNING)

    # daemon=True: stažení fotek je idempotentní (etag) a zápis atomický — zabití při
    # vypínání Kodi nic neztratí; non-daemon by drželo 5s okno (cross-check T1 Pro P8).
    th = threading.Thread(target=_work, name="RMAvatarSync", daemon=True)
    _avatar_thread["thread"] = th
    th.start()


def order_profiles(profiles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Zrcadlo Gate `service.order_profiles` (mig 0031): naposledy na TOMTO zařízení první, pak
    použití jinde, pak abecedně. Lokálně kvůli výběru bez Gate a hned po výběru (chooser se
    nesmí přeskládat až po dalším stažení seznamu)."""
    def _ts(v: Any) -> float:
        try:
            return float(_state_sync_to_epoch(v)) if v else 0.0
        except Exception:
            return 0.0
    here = [p for p in profiles if p.get("last_used_here_at")]
    elsewhere = [p for p in profiles if not p.get("last_used_here_at") and p.get("last_used_at")]
    fresh = [p for p in profiles if not p.get("last_used_here_at") and not p.get("last_used_at")]
    _nm = lambda p: (str(p.get("name") or "").casefold(), int(p.get("slot") or 0))   # sekundární klíč (Pro P0)
    here.sort(key=lambda p: (-_ts(p.get("last_used_here_at")),) + _nm(p))
    elsewhere.sort(key=lambda p: (-_ts(p.get("last_used_at")),) + _nm(p))
    fresh.sort(key=_nm)
    return here + elsewhere + fresh


def _state_sync_to_epoch(v: Any) -> float:
    from richmovie_sync_queue import to_epoch
    return to_epoch(v)


def profiles_cached(st: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    st = st or load_state()
    return order_profiles(list(st.get("profiles") or []))


def select_profile(profile: Dict[str, Any], *, report: bool = True) -> Dict[str, Any]:
    """Uživatel vybral profil v chooseru. Uloží stav (okamžitě, lokálně) a
    best-effort ohlásí Gate `POST /{id}/use` (R2: selhání Gate = jen log)."""
    pid = int(profile.get("id"))

    def _apply(st: Dict[str, Any]) -> bool:
        st["current_id"] = pid
        st["current_name"] = str(profile.get("name") or "")
        st["current_slot"] = int(profile.get("slot") or 0)
        st["current_is_owner"] = bool(profile.get("is_owner"))
        for p in st.get("profiles") or []:
            if int(p.get("id", -1)) == pid:
                now_iso = time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime())
                p["last_used_at"] = now_iso
                p["last_used_here_at"] = now_iso   # mig 0031: tenhle výběr byl TADY
        return True

    st = _mutate(_apply)
    _log("selected profile id=%s name=%r" % (pid, st["current_name"]))
    # 3.5.155: profil bez vlastní volby zvuku se zeptá jednou (preference je PROFILU, ne zařízení —
    # incident Chromecast 26.09.2026). Best-effort, dialog v UI kontextu chooseru.
    if report:
        try:
            import richmovie_localization as _loc
            _loc.ask_profile_prefs()
        except Exception as _av_exc:
            _log("profile audio prefs ask failed: %r" % (_av_exc,), xbmc.LOGWARNING)
    if report:
        _report_use_background(pid)
    return st


def _report_use_background(pid: int) -> None:
    """Ohlášení výběru `POST /v1/profiles/{id}/use` MIMO UI cestu (Φ2, 29.09.2026).

    Dřív se na něj synchronně čekalo (strop 8 s) mezi zavřením chooseru a vykreslením menu —
    p50 1,5 s, p90 5,3 s holého kolečka (audit A07 F7). Výběr je platný lokálně hned (stav výše);
    Gate jen uloží čas použití a srovná čas z hodin serveru. Non-daemon vlákno: zápis na Gate
    se nesmí utnout (Kodi při ukončení počká), invokace pluginu na něj čeká až po `endOfDirectory`."""
    import threading

    def _work() -> None:
        try:
            resp = _gate_post("/v1/profiles/%d/use" % pid, {}, timeout=8.0)
            server_ts = (resp or {}).get("last_used_at") if isinstance(resp, dict) else None
            if server_ts:
                # čas výběru ze serveru — hodiny zařízení (Android boxy) nejsou důvěryhodné (Pro P1)
                def _fix(st2: Dict[str, Any]) -> bool:
                    for p in st2.get("profiles") or []:
                        if int(p.get("id", -1)) == pid:
                            p["last_used_at"] = server_ts
                            p["last_used_here_at"] = server_ts
                    return True
                _mutate(_fix)
        except ProfileGateError as exc:
            _log("use report failed (%s) — local state kept" % exc.code, xbmc.LOGWARNING)
        except Exception as exc:
            _log("use report failed: %r — local state kept" % (exc,), xbmc.LOGWARNING)

    threading.Thread(target=_work, name="RMProfileUse").start()


def select_guest() -> Dict[str, Any]:
    """Host (D12): nic se neukládá — adresář hosta se vyprázdní při každém výběru."""
    def _apply(st: Dict[str, Any]) -> bool:
        st["current_id"] = GUEST_ID
        st["current_name"] = GUEST_NAME
        st["current_slot"] = 0
        st["current_is_owner"] = False
        return True

    st = _mutate(_apply)
    gd = richmovie_paths.profile_subdir(richmovie_paths.GUEST_DIRNAME)
    try:
        if gd.is_dir():
            shutil.rmtree(str(gd), ignore_errors=True)
        gd.mkdir(parents=True, exist_ok=True)
    except Exception as exc:
        _log("guest dir reset failed: %r" % (exc,), xbmc.LOGWARNING)
    _log("guest selected (no persistence)")
    return st


# ─────────────────────────────────────────────────────────────────────────────
#  Onboarding / správa (Gate je autorita; lokální data se přesouvají All-or-Nothing)
# ─────────────────────────────────────────────────────────────────────────────

def setup_single() -> Dict[str, Any]:
    _gate_post("/v1/profiles/setup", {"mode": MODE_SINGLE, "names": [], "own_device": False})

    def _apply(st: Dict[str, Any]) -> bool:
        st["mode"] = MODE_SINGLE
        st["setup_required"] = False
        st["current_id"] = None
        return True

    return _mutate(_apply)


def setup_multi(names: List[str], *, own_device: bool, from_single: bool = False) -> Dict[str, Any]:
    """Přechod na profily. Pořadí: Gate `/setup` (idempotentní) → osobní soubory → stav.

    Onboarding (`unset`): `own_device` → přesun souborů majiteli All-or-Nothing (selže = soubory zpět, stav single-like,
    Gate setup zůstává hotový — další pokus jen dokončí přesun); sdílené zařízení → archiv `_legacy` (D4).
    Převod „Jen já“ → více profilů (`from_single`, S24 D6 — samoobsluha v Nastavení → Profily): Gate převede účet
    TOUŽ cestou (DP3: historie účtu → majitel, zařízení účtu předvolená na majitele). Data doby „Jen já“ na tomto
    zařízení jsou majitelova bez ohledu na to, čí zařízení je → stav se zapíše hned a soubory převezme
    `reconcile_multi_layout` (stejná idempotentní cesta jako na ostatních zařízeních účtu při dalším startu)."""
    try:
        data = _gate_post("/v1/profiles/setup",
                          {"mode": MODE_MULTI, "names": list(names), "own_device": bool(own_device)})
        profiles = [p for p in (data.get("profiles") or []) if isinstance(p, dict)]
    except ProfileGateError as exc:
        if exc.code != "already_setup":
            raise
        profiles = profiles_cached(fetch_profiles())
    owner = next((p for p in profiles if p.get("is_owner")), None)
    if owner is None:
        raise ProfileGateError("no_owner", False, "setup returned no owner profile")
    # `from_single`: soubory převezme `reconcile_multi_layout` až po zápisu stavu (níže)
    if own_device and not from_single:
        migrate_personal_files(owner_id=int(owner["id"]))
    elif not from_single:
        # D4 platí i pro onboarding (Fable P2-4): historie sdílené TV je směs lidí a nepatří
        # majiteli — stejné pravidlo jako `reconcile_multi_layout` o den později.
        moved = archive_legacy_files()
        _log("multi setup on shared device: %d root files archived to profiles/%s (D4)"
             % (len(moved), LEGACY_DIRNAME))

    def _apply(st: Dict[str, Any]) -> bool:
        st["mode"] = MODE_MULTI
        st["setup_required"] = False
        st["profiles"] = profiles
        st["count"] = len(profiles)
        st["current_id"] = int(owner["id"])
        st["current_name"] = str(owner.get("name") or "")
        st["current_slot"] = int(owner.get("slot") or 1)
        st["current_is_owner"] = True
        return True

    st = _mutate(_apply)
    _log("multi setup done: %d profiles, owner=%s, from_single=%s" % (len(profiles), owner.get("name"), from_single))
    if from_single:
        reconcile_multi_layout()   # idempotentní; selhání = zkusí se při dalším startu (ensure_profile_at_start)
    return st


def migrate_personal_files(*, owner_id: int, overwrite: bool = False) -> List[str]:
    """Přesun osobních souborů z kořene do `profiles/<owner>/` — All-or-Nothing:
    1) kopie všech (atomický zápis) 2) ověření OBSAHU (bajty zpět, ne jen velikost)
    3) smazání originálů. Selhání v 1–2 → kopie z tohoto běhu pryč, originály
    netknuté, výjimka. `overwrite=False` (onboarding): existující cílový soubor =
    chyba `target_exists` (nic se nepřepíše potichu); `overwrite=True` (reconcile):
    kořen má přednost."""
    import richmovie_atomic as _atomic
    root = richmovie_paths.addon_data_dir()
    dest = richmovie_paths.profile_subdir(str(owner_id))
    names = richmovie_paths.personal_files_present(root)
    if not names:
        dest.mkdir(parents=True, exist_ok=True)
        return []
    dest.mkdir(parents=True, exist_ok=True)
    marker = dest / MIGRATION_MARKER
    try:
        marker.write_text(time.strftime("%Y-%m-%dT%H:%M:%S"), encoding="utf-8")
    except Exception:
        pass
    copied: List[Path] = []
    written: List[Path] = []   # i soubory zapsané, ale neověřené (částečná kopie → marker zůstává)
    try:
        for name in names:
            src = root / name
            target = dest / name
            if target.exists() and not overwrite:
                raise OSError("target_exists: %s" % target)
            data = src.read_bytes()
            if not _atomic.write_bytes(str(target), data):
                raise OSError("atomic write failed: %s" % target)
            written.append(target)
            if target.read_bytes() != data:
                raise OSError("content mismatch after copy: %s" % target)
            copied.append(target)
    except Exception as exc:
        if not overwrite:
            for t in written:      # i neověřená kopie (Fable P3-2) — cíl má být jako před během
                try:
                    t.unlink()
                except Exception:
                    pass
        # marker zůstává JEN když tento běh něco do cíle zapsal (částečná kopie → reconcile
        # ji smí přepsat kořenem); když nic (target_exists), stav cíle je původní → marker pryč
        if not written:
            try:
                marker.unlink()
            except Exception:
                pass
        _log("migration failed, originals untouched: %r" % (exc,), xbmc.LOGERROR)
        raise ProfileGateError("migration_failed", False, repr(exc))
    for name in names:
        try:
            (root / name).unlink()
        except Exception as exc:
            _log("original cleanup failed (%s): %r" % (name, exc), xbmc.LOGWARNING)
    try:
        marker.unlink()
    except Exception:
        pass
    _log("migrated %d personal files → profiles/%d" % (len(names), owner_id))
    return names


def create_profile(name: str) -> Dict[str, Any]:
    data = _gate_post("/v1/profiles/", {"name": name})
    fetch_profiles()
    return data.get("profile") or {}


def rename_profile(profile_id: int, name: str) -> Dict[str, Any]:
    # PATCH = zápis → přes richmovie_http bez retry (post_json umí jen POST).
    import richmovie_http as _rm_http
    from richmovie_gate_transport import GATE_URL, build_common_fields as _bcf, gate_headers
    body = dict(_bcf())
    body["name"] = name
    prof = _rm_http.profile_foreground().replace(timeout_s=12.0)
    try:
        status, raw, _h = _rm_http.request("%s/v1/profiles/%d" % (GATE_URL, int(profile_id)),
                                           headers=gate_headers(content_type="application/json"),
                                           profile=prof, tag="profiles", method="PATCH",
                                           data=json.dumps(body).encode("utf-8"), idempotent=False)
    except Exception as exc:
        raise ProfileGateError("transport", True, repr(exc))
    data = _decode(status, raw)
    fetch_profiles()
    return data.get("profile") or {}


def delete_profile(profile_id: int) -> None:
    import richmovie_http as _rm_http
    from richmovie_gate_transport import GATE_URL, auth_header, gate_headers, get_device_hash, get_identity
    _check_identity_allowed()
    username, proof = get_identity()
    qp = urllib.parse.urlencode({"device_hash": get_device_hash() or ""})   # identita v hlavičce (D6)
    prof = _rm_http.profile_foreground().replace(timeout_s=12.0)
    headers = gate_headers()
    headers.update(auth_header(username, proof))
    try:
        status, raw, _h = _rm_http.request("%s/v1/profiles/%d?%s" % (GATE_URL, int(profile_id), qp),
                                           headers=headers, profile=prof,
                                           tag="profiles", method="DELETE", idempotent=False)
    except Exception as exc:
        raise ProfileGateError("transport", True, repr(exc))
    _decode(status, raw)
    sub = richmovie_paths.profile_subdir(str(int(profile_id)))
    try:
        if sub.is_dir():
            shutil.rmtree(str(sub), ignore_errors=True)
    except Exception:
        pass
    # `_apply_list` uvnitř `fetch_profiles` smazaný profil sám odvolí (current_id None +
    # ForceChooser) — pod zámkem; žádný další zápis tady (Flash T1 NAVÍC 2: mrtvý kód).
    fetch_profiles()


def _set_if_changed(st: Dict[str, Any], key: str, value: Any) -> bool:
    if st.get(key) == value:
        return False
    st[key] = value
    return True


def claim_this_device(profile_id: int) -> int:
    """„Toto zařízení patří profilu" → Gate přiřadí zařízení (chooser předvybírá) a dosud
    nepřiřazenou historii z něj (D4 pro zařízení). Archiv `_legacy` se importuje automaticky
    majiteli (DP3, `richmovie_profile_items.import_legacy_dir`) — tady už nic lokálního.
    Vrací počet přiřazených eventů."""
    from richmovie_player_hook import _compute_device_cluster_id
    data = _gate_post("/v1/profiles/%d/claim-device" % int(profile_id),
                      {"device_cluster_id": _compute_device_cluster_id()})
    _mutate(lambda st: _set_if_changed(st, "device_owner_profile_id", int(profile_id)))
    return int(data.get("backfilled_events") or 0)


def gate_get(path: str, params: Optional[Dict[str, Any]] = None, timeout: float = 12.0,
             *, quick: bool = False, background: bool = False) -> Dict[str, Any]:
    """Veřejný GET na Gate s identitou v query (SSOT pro /v1/profiles/* čtení) —
    používá ho i `richmovie_state_sync` (deltový pull stavu). Vyhazuje
    `ProfileGateError` (transient = transport, jinak autoritativní kód Gate)."""
    return _gate_get(path, params=params, timeout=timeout, quick=quick, background=background)


# ── Φ4: fotky profilů (lokální cache podle etagu) + D14 obnova seznamu ───────
AVATAR_FILE = "avatar.jpg"
AVATAR_ETAG_FILE = "avatar.etag"
AVATAR_MAX_BYTES = 256 * 1024     # Gate posílá ≤ 128 kB; dvojnásobek = tvrdý strop čtení


def avatar_path(p: Dict[str, Any]) -> str:
    """Lokálně stažená fotka profilu (`profiles/<id>/avatar.jpg`); "" = silueta.
    SSOT pro chooser i root řádek."""
    try:
        path = _avatar_dir(int(p.get("id"))) / AVATAR_FILE
        return str(path) if path.is_file() else ""
    except Exception:
        return ""


def _avatar_dir(profile_id: int) -> Path:
    import richmovie_paths
    return richmovie_paths.profile_subdir(str(int(profile_id)))


def _local_avatar_etag(profile_id: int) -> str:
    try:
        d = _avatar_dir(profile_id)
        if not (d / AVATAR_FILE).is_file():
            return ""
        return (d / AVATAR_ETAG_FILE).read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def _gate_get_bytes(path: str, timeout: float = 10.0) -> Tuple[int, bytes]:
    """GET binárního obsahu s identitou v hlavičce (fotka). Transport → ProfileGateError."""
    import richmovie_http as _rm_http
    from richmovie_gate_transport import GATE_URL, auth_header, gate_headers, get_device_hash, get_identity
    _check_identity_allowed()
    username, proof = get_identity()
    if not username:
        raise ProfileGateError("no_identity", False)
    qp = {"device_hash": get_device_hash() or ""}
    url = "%s%s?%s" % (GATE_URL, path, urllib.parse.urlencode(qp))
    profile = _rm_http.profile_background().replace(timeout_s=float(timeout))
    headers = gate_headers(accept="image/jpeg")
    headers.update(auth_header(username, proof))
    try:
        status, raw, _hdrs = _rm_http.request(url, headers=headers, profile=profile, tag="profiles")
    except Exception as exc:
        raise ProfileGateError("transport", True, repr(exc))
    return int(status), bytes(raw or b"")


def _remove_local_avatar(profile_id: int) -> bool:
    removed = False
    try:
        d = _avatar_dir(profile_id)
        for name in (AVATAR_FILE, AVATAR_ETAG_FILE):
            f = d / name
            if f.exists():
                f.unlink()
                removed = True
    except Exception as exc:
        _log("avatar remove failed id=%s: %r" % (profile_id, exc), xbmc.LOGWARNING)
    return removed


def sync_avatars(st: Optional[Dict[str, Any]] = None, *, timeout: float = 10.0) -> int:
    """Srovná lokální cache fotek se seznamem z Gate (etag). Stáhne nové/změněné,
    smaže odebrané. Vrací počet změněných profilů. R2: transport = nic se nemění
    (starý obrázek zůstává), 404 = autoritativně bez fotky → lokální smazat."""
    st = st or load_state()
    changed = 0
    for p in st.get("profiles") or []:
        try:
            pid = int(p.get("id"))
        except (TypeError, ValueError):
            continue
        remote_etag = str(p.get("avatar_etag") or "") if p.get("has_avatar") else ""
        local_etag = _local_avatar_etag(pid)
        if not remote_etag:
            if local_etag or (_avatar_dir(pid) / AVATAR_FILE).is_file():
                if _remove_local_avatar(pid):
                    changed += 1
            continue
        if remote_etag == local_etag:
            continue
        try:
            status, raw = _gate_get_bytes("/v1/profiles/%d/avatar" % pid, timeout=timeout)
        except ProfileGateError as exc:
            _log("avatar fetch id=%s failed (%s) — keeping cached" % (pid, exc.code), xbmc.LOGWARNING)
            if exc.transient:
                break   # Gate nedostupný: další profily by jen násobily timeout (chooser čeká)
            continue
        if status == 404:
            if _remove_local_avatar(pid):
                changed += 1
            continue
        if status != 200 or not raw or len(raw) > AVATAR_MAX_BYTES or not raw.startswith(b"\xff\xd8"):
            _log("avatar fetch id=%s: HTTP %s / %d B — ignored" % (pid, status, len(raw)), xbmc.LOGWARNING)
            continue
        import richmovie_atomic as _atomic
        d = _avatar_dir(pid)
        d.mkdir(parents=True, exist_ok=True)
        if _atomic.write_bytes(str(d / AVATAR_FILE), raw) and _atomic.write_text(str(d / AVATAR_ETAG_FILE), remote_etag):
            changed += 1
            _log("avatar id=%s updated (etag %s)" % (pid, remote_etag))
    return changed


def refresh_list_if_changed(*, timeout: float = 8.0) -> bool:
    """D14: seznam profilů z Gate (jména, pořadí, fotky) → stav + cache fotek,
    bez restartu Kodi. Vrací True, když se něco změnilo (volající smí podle D11
    překreslit hlavní menu). Vyhazuje ProfileGateError při chybě Gate."""
    before = load_state()
    prev_version = str(before.get("list_version") or "")
    data = _gate_get("/v1/profiles/", timeout=timeout, etag=prev_version or None, background=True)
    if data is NOT_MODIFIED:
        return sync_avatars(before, timeout=timeout) > 0   # seznam beze změny; fotky jen dorovnat (obvykle 0 volání)
    # Fable P1-1: seznam se zapisuje do ČERSTVÉHO stavu pod zámkem — volba profilu z pluginu
    # (current_*) mezitím nesmí být přepsána starou kopií.
    st = _mutate(lambda st_: bool(_apply_list(st_, data)))
    changed = str(data.get("version") or "") != prev_version
    if sync_avatars(st, timeout=timeout) > 0:
        changed = True
    return changed


def archive_legacy_files() -> List[str]:
    """Osobní soubory z kořene → `profiles/_legacy/` (přesun, nic se nemaže). Pro sdílená
    zařízení (TV v obýváku): historie před profily je směs lidí a nepatří nikomu (D4);
    zůstává dohledatelná pro pozdější „toto zařízení je moje" (claim → import)."""
    root = richmovie_paths.addon_data_dir()
    dest = richmovie_paths.profile_subdir(LEGACY_DIRNAME)
    dest.mkdir(parents=True, exist_ok=True)
    moved: List[str] = []
    for name in richmovie_paths.personal_files_present(root):
        try:
            target = dest / name
            if target.exists():
                target = dest / ("%s.%d" % (name, int(time.time())))
            (root / name).replace(target)
            moved.append(name)
        except Exception as exc:
            _log("legacy archive failed (%s): %r" % (name, exc), xbmc.LOGWARNING)
    return moved


def reconcile_multi_layout() -> Optional[int]:
    """Idempotentní dokončení přechodu na multi (Fable P1-2; DP3 plánu PLAN_profile_data_sync):
    účet je `multi`, ale osobní soubory z doby „jednoho profilu" leží v kořeni. Data z doby
    před profily PATŘÍ MAJITELI na každém zařízení (Richie 05.09.: „o vše jsem přišel"):
      • adresář majitele prázdný → přesun souborů (`migrate_personal_files`; existující cíl se
        přepisuje JEN s markerem `.migration_pending` = zbytek selhané kopie),
      • adresář majitele už má data (sync z Gate) → kořen do `profiles/_legacy/` a
        `richmovie_profile_items.import_legacy_dir` ho sloučí po položkách (LWW přes Gate).
    Vrací id majitele, když se přesouvalo k němu, jinak None. Nikdy nevyhazuje."""
    try:
        if not is_multi():
            return None
        root = richmovie_paths.addon_data_dir()
        if not richmovie_paths.personal_files_present(root):
            return None
        profiles = profiles_cached()
        if not profiles:
            try:
                profiles = profiles_cached(fetch_profiles())
            except ProfileGateError:
                return None   # bez seznamu nevíme, kdo je majitel — příště
        owner = next((p for p in profiles if p.get("is_owner")), None) \
            or (min(profiles, key=lambda p: int(p.get("slot") or 99)) if profiles else None)
        if owner is None:
            return None
        owner_id = int(owner.get("id"))
        dest = richmovie_paths.profile_subdir(str(owner_id))
        pending = (dest / MIGRATION_MARKER).exists()
        if richmovie_paths.personal_files_present(dest) and not pending:
            # Majitel už má na tomto zařízení data (sync z Gate) → kořen do archivu; položky z něj
            # doimportuje `richmovie_profile_items.import_legacy_dir` po položkách (LWW), ne po souborech.
            moved = archive_legacy_files()
            _log("multi layout: owner dir already populated → %d root files archived for item-level import" % len(moved))
            return None
        moved = migrate_personal_files(owner_id=owner_id, overwrite=pending)
        _log("multi layout reconciled: %d files → owner %d (pending=%s)" % (len(moved), owner_id, pending))
        return owner_id
    except Exception as exc:
        _log("reconcile_multi_layout failed: %r" % (exc,), xbmc.LOGWARNING)
        return None
