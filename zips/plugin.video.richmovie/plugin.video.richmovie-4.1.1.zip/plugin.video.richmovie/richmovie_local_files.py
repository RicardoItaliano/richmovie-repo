# -*- coding: utf-8 -*-
"""
RichMovie – lokální soubory (LAN / SMB)

2025-12-27 23:40 CET (Europe/Prague)

Tento modul přidává podporu pro procházení a přehrávání lokálních video souborů
přes SMB share v lokální síti (typicky BD/UHD remuxy v MKV na domácím PC/serveru).

FUNKCE:
- Procházení SMB složek přes xbmcvfs.listdir() (funguje i na Android/Chromecast)
- Přehrávání přes přímé smb:// URL
- Zobrazení jen pro whitelist Webshare účtů (case-insensitive)
- Filtr "jen video soubory" podle přípon

NOVĚ: TMDb meta pro lokální soubory (FILMY)
- Parsování title + year z filename (např. "Titanic (1997) [..].mkv")
- TMDb lookup + výběr nejlepší shody
- Disková cache: mapování "relativní cesta v share → TMDb meta"
- Negativní cache (MISS) pro špatné/neidentifikované názvy

FIX (praktický – Die Another Day apod.):
- TMDb search běží v en-US (lepší shoda na originální názvy)
- TMDb details běží v cs-CZ (český popis)
- Filtrování podezřelých bonusů/featurette (krátká stopáž / klíčová slova / "Title: Something")

⚠️ Bezpečnost:
- SMB uživatelské jméno i heslo jsou zde natvrdo (záměrně, dle zadání).
- Menu se ukáže jen vybraným Webshare účtům (whitelist níže).
"""

# --------------------------------------------------------------------------- #
#  IMPORTY (aktualizováno: 2025-12-27 23:40 CET (Europe/Prague))
# --------------------------------------------------------------------------- #
from __future__ import annotations

# =========================
# STANDARDNÍ KNIHOVNY
# =========================
import os
import re
import socket
import time
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote

# =========================
# KODI
# =========================
import xbmc
import xbmcaddon
import xbmcvfs

# =========================
# LOKÁLNÍ MODULY
# =========================

# 3.4.x Phase 9: log helper routes via richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.local_files", "RichMovie/LocalFiles")
except Exception:
    def _log(msg, level=1, *, context=None):
        try:
            xbmc.log(f"[RichMovie/LocalFiles] {msg}", level)
        except Exception:
            pass


# =============================================================================
# KONFIG
# =============================================================================

# Rychlý test dostupnosti NAS (TCP port 445, timeout v sekundách).
# Když NAS neodpoví do SMB_REACHABILITY_TIMEOUT, celý SMB blok se přeskočí
# místo čekání ~42 s na Kodi SMB timeout.
SMB_REACHABILITY_TIMEOUT = 2.0


# --------------------------------------------------------------------------- #
#  SMB credentials – z Gate serveru
# --------------------------------------------------------------------------- #
_smb_settings_cache: Optional[Dict[str, str]] = None


def _get_smb_settings() -> Dict[str, str]:
    """
    Vrátí SMB config z Gate cache.
    Výsledek se cachuje po celou dobu běhu pluginu.
    """
    global _smb_settings_cache
    if _smb_settings_cache is not None:
        return _smb_settings_cache

    empty = {"host": "", "share": "", "user": "", "pass": ""}

    try:
        import richmovie_gate
        if not richmovie_gate.is_local_filmoteka_allowed():
            _smb_settings_cache = empty
            return empty
        config = richmovie_gate.get_smb_config()
        if config and config.get("host"):
            _smb_settings_cache = config
            _log("SMB config z Gate", xbmc.LOGDEBUG)
        else:
            _smb_settings_cache = empty
    except ImportError:
        _smb_settings_cache = empty

    return _smb_settings_cache


def _smb_configured() -> bool:
    """True pokud je SMB config dostupný z Gate."""
    s = _get_smb_settings()
    return bool(s["host"])


def is_allowed_webshare_user(username: str) -> bool:
    """
    Vrátí True, pokud má uživatel přístup k LAN menu (řízeno Gate permissions).
    """
    try:
        import richmovie_gate
        return richmovie_gate.is_local_filmoteka_allowed()
    except ImportError:
        return False

# "Všechna video" – pragmatický whitelist běžných přípon (Kodi si poradí i s dalšími,
# ale nechceme zobrazovat .nfo, .srt, atd.)
VIDEO_EXTS = {
    ".3g2",
    ".3gp",
    ".asf",
    ".avi",
    ".bdmv",
    ".divx",
    ".dvr-ms",
    ".f4v",
    ".flv",
    ".img",
    ".iso",
    ".m1v",
    ".m2ts",
    ".m2v",
    ".m4v",
    ".mkv",
    ".mov",
    ".mp4",
    ".mpe",
    ".mpeg",
    ".mpg",
    ".mpv",
    ".mts",
    ".mxf",
    ".ogm",
    ".rm",
    ".rmvb",
    ".strm",
    ".tp",
    ".trp",
    ".ts",
    ".vob",
    ".webm",
    ".wmv",
    ".wtv",
}


# ---------------------------------- METODA ---------------------------------- #
# richmovie_local_files.py › sanitize_relative_path
# sanitize_relative_path (vytvořeno/aktualizováno: 2025-12-27 23:40 CET (Europe/Prague) – normalizace relativní cesty, ochrana proti "..")
# ---------------------------------------------------------------------------- #
def sanitize_relative_path(relative_path: str) -> str:
    """
    2025-12-27 23:40 CET (Europe/Prague)

    Normalizuje relativní cestu (podsložky/soubor v rámci share):
    - sjednotí \\ na /
    - odstraní prázdné segmenty a "."
    - odstraní segmenty ".." (aby nešlo utéct mimo share)
    """
    p = (relative_path or "").strip().replace("\\\\", "/").replace("\\", "/")
    p = p.strip("/")

    if not p:
        return ""

    parts: List[str] = []
    for seg in p.split("/"):
        seg = seg.strip()
        if not seg or seg == ".":
            continue
        if seg == "..":
            continue
        parts.append(seg)

    return "/".join(parts)


# ---------------------------------- METODA ---------------------------------- #
# richmovie_local_files.py › join_relative_path
# join_relative_path (vytvořeno/aktualizováno: 2025-12-27 23:40 CET (Europe/Prague) – bezpečné spojení relativních cest)
# ---------------------------------------------------------------------------- #
def join_relative_path(base: str, name: str) -> str:
    """
    2025-12-27 23:40 CET (Europe/Prague)

    Spojí relativní cestu base a child name do jedné relativní cesty (posix styl).
    """
    b = sanitize_relative_path(base)
    n = sanitize_relative_path(name)
    if not b:
        return n
    if not n:
        return b
    return f"{b}/{n}"


# ---------------------------------- METODA ---------------------------------- #
# richmovie_local_files.py › _mask_smb_url
# _mask_smb_url (vytvořeno/aktualizováno: 2025-12-27 23:40 CET (Europe/Prague) – maskování hesla v logu)
# ---------------------------------------------------------------------------- #
def _mask_smb_url(url: str) -> str:
    """
    2025-12-27 23:40 CET (Europe/Prague)

    Maskuje heslo v SMB URL, aby se nevypisovalo do logu.
    """
    try:
        # smb://user:pass@host/share/...  → smb://user:***@host/share/...
        return re.sub(r"(smb://[^:]+:)([^@]+)@", r"\1***@", url)
    except Exception:
        return url


# ---------------------------------- METODA ---------------------------------- #
# richmovie_local_files.py › build_smb_url
# build_smb_url (upraveno: 2025-12-27 23:40 CET (Europe/Prague) – FIX: pro SMB playback v Kodi NEpercent-enkódovat názvy souborů/složek; Kodi pak často nedekóduje %xx; enkódujeme pouze credentials)
# ---------------------------------------------------------------------------- #
def build_smb_url(relative_path: str = "", *, is_dir: bool = True) -> str:
    """
    2025-12-27 23:40 CET (Europe/Prague)

    Sestaví plnou SMB URL s natvrdo credentials, hostem a share.

    DŮLEŽITÉ (FIX):
    - Kodi SMB přehrávání často NEdekóduje percent-encoding (%20, %28, ...).
      Když tedy pošleme cestu s %xx, Kodi se snaží otevřít soubor doslova s "%20"
      v názvu a skončí na OpenInputStream.
    - Proto NEenkódujeme share ani path segmenty (mezery, závorky, apostrofy atd.).
    - Enkódujeme pouze SMB_USER/SMB_PASS, protože jsou v "authority" části URL.

    Pozn.:
    - Relativní cesta je sanitizovaná (ochrana proti ..).
    - Používáme "/" (posix styl), protože Kodi SMB takto očekává cestu.
    """
    rel = sanitize_relative_path(relative_path)

    s = _get_smb_settings()
    user_q = quote(s["user"], safe="")
    pass_q = quote(s["pass"], safe="")
    host = s["host"]

    share = s["share"].replace("\\", "/").strip("/")
    base = f"smb://{user_q}:{pass_q}@{host}/{share}"

    if rel:
        base = base + "/" + rel

    if is_dir:
        if not base.endswith("/"):
            base += "/"
    else:
        base = base.rstrip("/")

    return base


# ---------------------------------- METODA ---------------------------------- #
# richmovie_local_files.py › is_smb_host_reachable
# is_smb_host_reachable (vytvořeno: 2026-04-02 – rychlý TCP check portu 445)
# ---------------------------------------------------------------------------- #
_smb_reachable_cache: Optional[Tuple[float, bool]] = None
_SMB_CACHE_TTL = 300  # 5 minut – necachovat navěky, NAS se může připojit/odpojit

def is_smb_host_reachable() -> bool:
    """
    Rychlý test dostupnosti SMB hostu (TCP port 445).
    Výsledek se cachuje na 5 minut, aby se neopakoval při každém volání.
    Bez tohoto checku Kodi SMB timeout blokuje ~42 sekund na nedostupném NASu.
    """
    global _smb_reachable_cache
    now = time.monotonic()

    if _smb_reachable_cache is not None:
        cached_ts, cached_result = _smb_reachable_cache
        if now - cached_ts < _SMB_CACHE_TTL:
            return cached_result

    host = _get_smb_settings()["host"]
    if not host:
        _smb_reachable_cache = (now, False)
        return False

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(SMB_REACHABILITY_TIMEOUT)
        sock.connect((host, 445))
        sock.close()
        reachable = True
    except (socket.timeout, socket.error, OSError):
        reachable = False

    _smb_reachable_cache = (now, reachable)
    if not reachable:
        xbmc.log(
            f"[RichMovie/LocalFiles] NAS {host}:445 nedostupný (timeout {SMB_REACHABILITY_TIMEOUT}s) – SMB přeskočen",
            xbmc.LOGINFO,
        )
    return reachable


# ---------------------------------- METODA ---------------------------------- #
# richmovie_local_files.py › list_dir
# list_dir (upraveno: 2026-04-02 – přidán rychlý reachability check před SMB listing)
# ---------------------------------------------------------------------------- #
def list_dir(relative_path: str = "") -> Tuple[List[str], List[str]]:
    """
    Vrátí (dirs, files) pro danou relativní cestu v rámci SMB share.

    Používá xbmcvfs.listdir(), takže funguje i na Android/Chromecast Kodi.
    Před SMB voláním kontroluje dostupnost NAS přes rychlý TCP check (port 445,
    timeout 2s). Pokud NAS neodpoví, vrátí prázdné seznamy okamžitě.
    """
    if not _smb_configured() or not is_smb_host_reachable():
        return [], []

    smb_dir = build_smb_url(relative_path, is_dir=True)
    try:
        dirs, files = xbmcvfs.listdir(smb_dir)
        return list(dirs or []), list(files or [])
    except Exception as e:
        xbmc.log(
            f"[RichMovie/LocalFiles] list_dir error: {e} | dir={_mask_smb_url(smb_dir)}",
            xbmc.LOGWARNING,
        )
        return [], []


# ---------------------------------- METODA ---------------------------------- #
# richmovie_local_files.py › is_video_file
# is_video_file (vytvořeno/aktualizováno: 2025-12-27 23:40 CET (Europe/Prague) – filtr video souborů podle přípony)
# ---------------------------------------------------------------------------- #
def is_video_file(name: str) -> bool:
    """
    2025-12-27 23:40 CET (Europe/Prague)

    True pokud soubor vypadá jako video dle whitelistu VIDEO_EXTS.
    """
    try:
        n = (name or "").strip()
        if not n or "." not in n:
            return False
        ext = "." + n.rsplit(".", 1)[1].lower()
        return ext in VIDEO_EXTS
    except Exception:
        return False


# ---------------------------------- METODA ---------------------------------- #
# richmovie_local_files.py › pretty_label
# pretty_label (vytvořeno/aktualizováno: 2025-12-27 23:40 CET (Europe/Prague) – čitelný label z názvu souboru/složky)
# ---------------------------------------------------------------------------- #
def pretty_label(name: str, *, is_dir: bool = False) -> str:
    """
    2025-12-27 23:40 CET (Europe/Prague)

    Z filename typu:
        Prometheus.2012.UHD.BDRemux.2160p.mkv
    udělá přívětivější:
        Prometheus 2012 UHD BDRemux 2160p

    Pozn.: tvoje názvy už jsou hezké (Titanic (1997) [..]), takže je jen jemně očistíme.
    """
    try:
        n = (name or "").strip()
        if not n:
            return ""
        if not is_dir and "." in n:
            n = n.rsplit(".", 1)[0]

        n = n.replace("_", " ").replace(".", " ")
        n = re.sub(r"\s+", " ", n).strip()
        return n or (name or "")
    except Exception:
        return name or ""


# =============================================================================
# TMDb META PRO LOKÁLNÍ SOUBORY (bez nového modulu)
# =============================================================================

# ============================================================================ #
# TMDb SEKCE ODSTRANENA (Faze CD, 3.5.128)
# ---------------------------------------------------------------------------- #
# Cache _local_tmdb_cache.json, parsovani nazvu, ranking kandidatu a
# get_local_tmdb_movie_meta bezely na KLIENTOVI pri kazdem startu (gunzik
# 30.08.2026: "cim vic souboru, tim dele") a parovaly soubor bez kontextu
# slozky (Zoufale manzelky S08E01 -> "Bellator 85"). Nahrazeno katalogem na
# Gate (RichMovie-nas/services/gate/app/local/) + klientem
# richmovie_local_catalog.py (lokalni kopie, delta sync pres sluzbu).
# Tento modul dal vlastni: SMB config/URL/reachability, listing (fallback),
# sanitizace cest a pretty_label.
