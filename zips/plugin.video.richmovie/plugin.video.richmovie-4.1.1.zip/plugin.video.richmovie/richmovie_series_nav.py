# -*- coding: utf-8 -*-
"""
richmovie_series_nav — kde v seriálu pokračovat (4.0.3, plán PLAN_watched_progress_integrity §3.2, nález M6)
==============================================================================================================

JEDNO místo pro otázky „který díl je další" a „kde divák v seriálu je":
  • `next_coords(tmdb, tv_id, s, e)` — díl po (s, e) podle TMDb (konec řady → první díl další řady; None = seriál
    skončil). Dřív dvě kopie: `service_nextup._next_coords` (autoplay, Pokračovat) a vložený kód
    `plugin._tv_next_episode` („Další díl").
  • `first_coords(tmdb, tv_id)` — první díl první řádné řady (speciály, řada 0, se přeskakují).
  • `continue_point(tv_id, …)` — kde v seriálu pokračovat, ČISTĚ nad lokálními daty profilu: nejdřív položka
    pohledu Pokračovat (rozkoukaný díl nebo nabídnutý další díl), jinak díl po posledním ✔ (bez ⏾ — prokázaný
    spánek se znovu nabízí), jinak None (od začátku). Dřív „Další díl" bral poslední SPUŠTĚNÝ díl z historie
    sledování: rozkoukaný díl přeskočil a díl s ⏾ už nenabídl.
Python 3.8 (Kodi). Bez Kodi importů (harness 90).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from richmovie_playback_end import is_completed   # SSOT „dokoukáno“ (čistý modul, bez Kodi)


def next_coords(tmdb: Any, tv_id: int, season: int, episode: int) -> Optional[Tuple[int, int]]:
    """(další řada, další díl), nebo None POUZE když seriál skončil. Chyby lookupu (TMDbError) PROPAGUJÍ —
    volající je nesmí zaměnit s koncem seriálu (3.5.118: CW backfill pak tiše zahodil seriál)."""
    eps = tmdb.season_details(int(tv_id), int(season))
    max_ep = max((int(e.get("episode_number") or 0) for e in eps or []), default=0)
    if int(episode) < max_ep:
        return int(season), int(episode) + 1
    show = tmdb.tv_details(int(tv_id)) or {}
    later = sorted(int(s.get("season_number") or 0) for s in show.get("seasons") or []
                   if int(s.get("season_number") or 0) > int(season))
    if not later:
        return None
    eps2 = tmdb.season_details(int(tv_id), later[0])
    return later[0], min((int(e.get("episode_number") or 1) for e in eps2 or []), default=1)


def first_coords(tmdb: Any, tv_id: int) -> Optional[Tuple[int, int]]:
    """První díl první řádné řady (řada 0 = speciály se přeskakuje). None = seriál nemá řady."""
    show = tmdb.tv_details(int(tv_id)) or {}
    regular = sorted(int(s.get("season_number") or 0) for s in show.get("seasons") or []
                     if int(s.get("season_number") or 0) > 0)
    if not regular:
        return None
    eps = tmdb.season_details(int(tv_id), regular[0])
    return regular[0], min((int(e.get("episode_number") or 1) for e in eps or []), default=1)


def continue_point(tv_id: Any, *, view_items: Optional[List[Dict[str, Any]]] = None,
                   watched: Optional[Dict[Tuple[int, int], Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
    """Kde v seriálu pokračovat (čisté nad předanými daty; bez nich se načtou lokální soubory profilu).
      {"at": (s, e), "position": p}  — položka Pokračovat seriálu (rozkoukaný / nabídnutý další díl)
      {"after": (s, e)}              — díl po NEJVZDÁLENĚJŠÍM ✔ (attended / manual; rewatch staršího dílu postup nevrací)
      None                            — od začátku seriálu"""
    tid = str(tv_id)
    if view_items is None or watched is None:
        import richmovie_history as _h
        if view_items is None:
            view_items = _h.cw_view_load().get("items") or []
        if watched is None:
            watched = _h.watched_info_for_series(tid)
    for it in view_items or []:
        if it.get("type") == "episode" and str(it.get("tv_id")) == tid:
            try:
                s_, e_ = int(it.get("season") or 0), int(it.get("episode") or 0)
            except (TypeError, ValueError):
                continue
            pos, dur = float(it.get("position") or 0), float(it.get("duration") or 0)
            if s_ > 0 and e_ > 0 and not is_completed(pos, dur):
                # dokoukaný řádek (konec nepřišel, úklid po startu ho ještě neuzavřel — cross-check Pro B PB5)
                # = ne „pokračuj tady“, ale díl po něm (rozhodne ✔ níže / řádek je i ve ✔)
                return {"at": (s_, e_), "position": pos}
    best: Optional[Tuple[int, int]] = None
    for key, info in (watched or {}).items():
        if (info or {}).get("kind") == "unattended":
            continue   # prokázaný spánek: díl se nabízí znovu (Pokračovat ho drží s volbou „už ho mám za sebou“)
        try:
            s_, e_ = int(key[0]), int(key[1])
        except (TypeError, ValueError, IndexError):
            continue
        if s_ <= 0 or e_ <= 0:
            continue
        if best is None or (s_, e_) > best:
            best = (s_, e_)
    if best is not None:
        return {"after": best}
    return None
