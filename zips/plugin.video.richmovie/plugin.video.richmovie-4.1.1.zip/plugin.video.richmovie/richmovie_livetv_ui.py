# -*- coding: utf-8 -*-
"""Televize v doplňku — výpis kanálů a spuštění živého kanálu (08.11.2026, plán Televizní kanály F3/F4 MVP).

`plugin.py` jen rozdělí akce (`live_home` = výpis, `live_play` = přehrání); veškerá logika Televize v UI je tady:

- výpis přes `richmovie_rmdir.RmDir` (nový vzhled = okno seznamu, starý = adresář Kodi): logo přes NAS, co běží
  teď a kolik zbývá, co bude potom; kanály a program se načtou souběžně;
- přehrání: tiket z Gate → první dosažitelná báze NASu (`richmovie_livetv.pick_url`) → živá položka JEN se značkou
  druhu média (`richmovie_media_kind.PROP = live`) a kanálem — nikdy `richmovie.ident` / `tv_id` / `m_tmdb`, aby ji
  služba nevzala za film; HLS přes inputstream.adaptive, je-li zapnutý (celý žebříček kvalit), jinak vestavěný
  přehrávač s jednou kvalitou (relay dostane `isa=False`);
- plno ve skupině kanálů (`409 slots_full`) = nabídka připojit se k běžícímu kanálu skupiny (nové místo
  nespotřebuje), nikdy „zkus znovu“; chyby = česká věta (`richmovie_livetv.MESSAGES`), technický text jen do logu.
"""

from __future__ import annotations

import concurrent.futures
import datetime
import json
import urllib.parse
import uuid

import xbmc
import xbmcgui
import xbmcplugin

import richmovie_livetv as _tv
import richmovie_media_kind as _kind

HEADING = "Televize"
_ISA_ID = "inputstream.adaptive"
_GREY = "FF9A9AA6"


def _log(msg: str, warning: bool = False) -> None:
    try:
        import richmovie_logging as _rl
        lg = _rl.get_logger("richmovie.livetv")
        (lg.warning if warning else lg.info)(msg)
    except Exception:
        xbmc.log("[RichMovie/Televize] %s" % msg, xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _say(err: "_tv.LiveError") -> None:
    """Chyba Televize → trvalá = dialog (zaslouží si pozornost), přechodná = toast. Log s kódem a detailem."""
    _log("LIVETV_UI_ERROR code=%s status=%s detail=%s" % (err.code, err.status, err.detail[:200]), warning=True)
    import richmovie_feedback as _fb
    if err.permanent:
        try:
            xbmcgui.Dialog().ok(HEADING, err.message)
            return
        except Exception:
            pass
    _fb.warn(err.message, heading=HEADING)


def isa_available() -> bool:
    try:
        return bool(xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % _ISA_ID))
    except Exception:
        return False


ISA_MISSING_TEXT = ("Přehrávač živého vysílání (InputStream Adaptive) se na tomhle zařízení nepodařilo zapnout — vysílání "
                    "může po chvíli vypadnout.")
_missing_logged = False   # služba žije dny: „chybí“ do logu jednou za proces, ne à 10 min


def ensure_isa() -> bool:
    """Přehrávač živého vysílání (inputstream.adaptive) zapnutý? Kodi ho v balíčku nese, ale bez doplňku, který by ho
    vyžadoval, zůstane VYPNUTÝ → živý kanál hraje vestavěný FFmpeg Kodi a ten na Chromecastu Petry 08.11.2026 skončil vždy
    po 22–31 s jako konec souboru (Nova, HBO, HBO 2: `isa=False`, `LIVE_ENDED kind=ended`). Relay za to nemůže: FFmpeg 7.1
    mimo Kodi hrál tentýž master živě přes 100 s (08.11. 07:53 a 07:58) a cesta s ISA hraje na PC hodiny. Přesnou příčinu
    v FFmpegu Kodi pro Android jsme nezopakovali (PC: `Player.Open` do otevřeného vlastního okna = „two concurrent
    busydialogs“) — proto se nespoléhá na záložní cestu, ale zapne se ta navržená.
    Nainstalovaný a vypnutý → zapnout JSON-RPC `Addons.SetAddonEnabled` (Kodi API k tomu určené, totéž dělá
    inputstreamhelper; vratné v Doplňcích). Vedlejší účinek: YouTube v RichMovie pak hraje DASH přes ISA (jeho zamýšlená
    cesta, `plugin._yt_has_inputstream_adaptive`). Nenainstalovaný → False (FFmpeg záložně + pravdivá věta).
    Rozhoduje stav Kodi po volání, ne text odpovědi. Uživatel nic nenastavuje ani nepotvrzuje (Richie 08.11.2026)."""
    global _missing_logged
    if isa_available():
        return True
    try:
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % _ISA_ID):
            if not _missing_logged:
                _missing_logged = True
                _log("LIVETV ISA missing — FFmpeg záložně", warning=True)
            return False
        raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                              "params": {"addonid": _ISA_ID, "enabled": True}}))
        ok = isa_available()
        _log("LIVETV ISA enable ok=%s rpc=%s" % (ok, str(raw)[:120]), warning=not ok)
        return ok
    except Exception as exc:
        _log("LIVETV ISA enable failed: %r" % (exc,), warning=True)
        return False


def ensure_isa_for_device(source: str) -> bool:
    """Služba — start (= i hned po aktualizaci doplňku) a à 10 min: zařízení s Televizí má přehrávač živého vysílání
    zapnutý dřív, než divák klikne na kanál (Richie 08.11.2026: „toto by se mělo automaticky zapnout s aktualizací, nechci,
    aby uživatel richmovie cokoliv musel nastavovat“). JEN zařízení s oprávněním `live_tv` (SSOT
    `richmovie_gate.is_live_tv_allowed`, fail-closed) — jinde se systémový doplněk Kodi nemění. Zapnutý = bez volání;
    oprávnění přidané později dožene další tik, spuštění kanálu má vlastní pojistku (`play`)."""
    try:
        import richmovie_gate as _gate
        if not _gate.is_live_tv_allowed():
            return False
    except Exception as exc:
        _log("LIVETV ISA ensure: oprávnění nečitelné (%r) — nic neměním" % (exc,), warning=True)
        return False
    if isa_available():
        return True
    ok = ensure_isa()
    _log("LIVETV ISA ensure source=%s ok=%s" % (source, ok))
    return ok


def _now() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)


def _labels(name: str, slot: dict | None, now) -> tuple:
    """(řádek výpisu, popis) pro kanál — „ČT24  Události · ještě 12 min“ + „Teď … / Potom 20:15 …“."""
    current = (slot or {}).get("current")
    nxt = (slot or {}).get("next")
    label = name
    plot_lines = []
    if isinstance(current, dict) and current.get("title"):
        rest = _tv.remaining_text(current, now)
        label = "%s  [COLOR %s]%s%s[/COLOR]" % (name, _GREY, current["title"], (" · " + rest) if rest else "")
        plot_lines.append("Teď: %s%s" % (current["title"], (" (" + rest + ")") if rest else ""))
    if isinstance(nxt, dict) and nxt.get("title"):
        plot_lines.append("Potom %s: %s" % (_tv.clock_text(nxt.get("start")), nxt["title"]))
    return label, "\n".join(plot_lines)


def list_channels(handle: int, url_fn) -> None:
    """Výpis kanálů zařízení (akce `live_home`)."""
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(handle, HEADING)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        f_channels = pool.submit(_tv.channels)
        f_now = pool.submit(_tv.now_playing)
        try:
            data = f_channels.result()
        except _tv.LiveError as err:
            _say(err)
            rmdir.finish(succeeded=False)
            return
        try:
            now_map = f_now.result()
        except _tv.LiveError as err:          # program je ozdoba — bez něj výpis kanálů pořád dává smysl
            _log("LIVETV now unavailable code=%s" % err.code, warning=True)
            now_map = {}
    bases = data["bases"]
    image_base = None
    if bases:
        image_base = bases[0] if _tv.health_probe(_tv.base_of(bases[0])) else None
    if bases and image_base is None:
        _tv_err = _tv.LiveError("nas_unreachable")
        _log("LIVETV list without reachable NAS base", warning=True)
        li = xbmcgui.ListItem("[COLOR %s]%s[/COLOR]" % (_GREY, _tv_err.message))
        li.setArt({"icon": "DefaultIconInfo.png"})
        rmdir.add(url_fn(action="noop"), li, False)
    try:
        xbmcplugin.setPluginCategory(handle, HEADING)
        xbmcplugin.setContent(handle, "videos")
    except Exception:
        pass
    now = _now()
    chans = sorted(data["channels"], key=lambda c: (c.get("position") is None, c.get("position") or 0, c.get("name")))
    for ch in chans:
        name = str(ch.get("name") or ch["id"])
        label, plot = _labels(name, now_map.get(ch["id"]), now)
        li = xbmcgui.ListItem(label)
        logo = _tv.image_url(bases, ch.get("logo_path"), image_base) if image_base else ""
        art = {"icon": logo or "DefaultAddonPVRClient.png"}
        if logo:
            art.update({"thumb": logo, "poster": logo})
        li.setArt(art)
        # playcount 0: Kodi si u živého kanálu po přehrání zapíše vlastní „zhlédnuto“ (MyVideos `files.playCount`,
        # ověřeno 08.11.2026 na 20 kanálech) → bez přepisu by starý vzhled ukázal u kanálu ✔
        li.setInfo("video", {"title": name, "plot": plot, "mediatype": "video", "playcount": 0})
        li.setProperty("IsPlayable", "true")
        rmdir.add(url_fn(action="live_play", ch=ch["id"], name=name), li, False)
    rmdir.finish()


def _choose_join(options: list) -> tuple | None:
    """Plno ve skupině → nabídka běžících kanálů (připojit se = bez nového místa). Vrací (kanál, jméno), nebo None."""
    if not options:
        return None
    labels = ["Přidat se: %s" % text for _ch, _name, text in options]
    try:
        pick = xbmcgui.Dialog().select("%s — na téhle skupině kanálů už se dívá moc zařízení" % HEADING, labels)
    except Exception:
        return None
    return (options[pick][0], options[pick][1]) if 0 <= pick < len(options) else None


def _back_to_list() -> None:
    """Start kanálu nevyšel a přehrávání se pouštělo z okna RichMovie (nový vzhled zavřel seznam před klikem) →
    vrátit diváka do seznamu kanálů, ne nechat na Home (§9 intuitivní: každý stav má cestu ven; audit Fable T-6).
    Starý vzhled (adresář Kodi) návratový popis nemá a seznam zůstává pod dialogem sám."""
    try:
        import richmovie_ui_common as _uc
        desc = _uc.consume_return_route()
        if desc:
            _uc.replay_return_routes(desc)
    except Exception as exc:
        _log("LIVETV back_to_list failed: %r" % (exc,), warning=True)


def play(handle: int, params: dict) -> None:
    """Akce `live_play`: tiket → cesta k NASu → živá položka → `setResolvedUrl`. Pojistku jednoho spuštění
    (`richmovie_playback_dispatch`) převezme stejně jako `plugin._play`: neúspěch ji uvolní hned (jinak by další klik do
    20 s dostal „Už to spouštím…“ — audit Fable T-1), úspěch ji předá službě (uvolní ji obraz nebo chyba přehrávače)."""
    import richmovie_playback_dispatch as _rm_dispatch
    channel = (params.get("ch") or "").strip()
    name = (params.get("name") or channel).strip()
    if not channel:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    token = _rm_dispatch.begin_resolve("live:" + channel, source="click")
    if token is None:                       # jiné spouštění už běží → nic nedělat (druhé by se rozjelo souběžně)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    try:
        _play_resolve(handle, channel, name, token, _rm_dispatch)
    finally:
        _rm_dispatch.end_resolve(token)     # neúspěch = uvolnit hned; po `note_resolved` nic nedělá


def _play_resolve(handle: int, channel: str, name: str, token, _rm_dispatch) -> None:
    isa = ensure_isa()   # služba ho po startu zapíná sama; tady pojistka (oprávnění přidané před chvílí, start bez cache)
    if not isa:
        import richmovie_feedback as _fb
        _fb.warn(ISA_MISSING_TEXT, heading=HEADING)
    csid = str(uuid.uuid4())     # identita TÉTO relace: konec přehrávání ukončí na NASu jen ji
    try:
        try:
            sess = _tv.open_session(channel, isa=isa, client_session_id=csid)
        except _tv.LiveError as err:
            if err.code != "slots_full":
                raise
            options = _tv.offer_lines(err.offer)
            joined = _choose_join(options)
            if not joined:
                _log("LIVETV slots_full channel=%s join=none options=%d" % (channel, len(options)))
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                if not options:
                    _say(err)
                _back_to_list()
                return
            _log("LIVETV slots_full channel=%s join=%s" % (channel, joined[0]))
            channel, name = joined
            sess = _tv.open_session(channel, isa=isa, client_session_id=csid)
        url = _tv.pick_url(sess["urls"], _tv.health_probe)
        if url is None:
            raise _tv.LiveError("nas_unreachable")
    except _tv.LiveError as err:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        _say(err)
        _back_to_list()
        return
    li = xbmcgui.ListItem(label=name, path=url)
    li.setProperty(_kind.PROP, _kind.LIVE)
    li.setProperty(_tv.PROP_CHANNEL, channel)
    li.setProperty(_tv.PROP_CHANNEL_NAME, name)
    li.setProperty(_tv.PROP_SESSION, csid)
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)
    if isa:
        li.setProperty("inputstream", _ISA_ID)
        # rezerva za živým okrajem — bez ní výpadky zvuku à úsek (F4-P, `richmovie_livetv.LIVE_DELAY_S`)
        li.setProperty(_ISA_ID + ".live_delay", str(_tv.LIVE_DELAY_S))
    li.setInfo("video", {"title": name, "mediatype": "video"})
    _log("LIVETV play channel=%s isa=%s base=%s" % (channel, isa, _tv.base_of(url)))
    _rm_dispatch.note_resolved(token, ident="live:" + channel)   # PŘED předáním (vzor `_play`, audit Fable F-2)
    xbmcplugin.setResolvedUrl(handle, True, li)


def parse_params(argv2: str) -> dict:
    """`?action=live_play&ch=ct24&name=ČT24` → {"ch": "ct24", "name": "ČT24"} (jen první hodnota)."""
    q = urllib.parse.parse_qs((argv2 or "").lstrip("?"))
    return {k: (v[0] if v else "") for k, v in q.items()}
