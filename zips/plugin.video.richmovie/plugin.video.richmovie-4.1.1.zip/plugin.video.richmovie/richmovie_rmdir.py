# -*- coding: utf-8 -*-
"""RichMovie 4.0 — directory-capture sink (SSOT) — Φ0 long-tail custom okna.

Tenký shim nad `xbmcplugin.addDirectoryItem`/`endOfDirectory`. Umožní long-tail
obrazovkám (Historie, Kolekce, NAS, ČSFD tipy, Zdroje) renderovat BUĎ jako klasický
Kodi directory (rodina / legacy), NEBO jako vlastní `RichMovieListWindow` (RM 4.0
custom UI) — BEZ duplikace datové logiky. Funkce postaví ListItemy jednou; sink je
podle režimu nasměruje.

Režim se čte z `Window(10000)` property `richmovie.rm_new_ui` (nastavuje plugin.py
router 1× per invokaci z autoritativního `_rm_new_ui()`) — žádný import plugin.py
(zamezí cyklický import). Default = legacy (bezpečné pro rodinu).

Použití (v long-tail funkci místo přímého xbmcplugin):
    rmdir = richmovie_rmdir.RmDir(HANDLE, title="Historie hledání")
    ...
    rmdir.add(url, li, isFolder=True)      # místo xbmcplugin.addDirectoryItem
    ...
    rmdir.finish()                          # místo xbmcplugin.endOfDirectory

V custom režimu `finish()` otevře `RichMovieListWindow` (doModal) s nasbíranými
ListItemy; v legacy režimu propustí 1:1 na xbmcplugin. setContent/addSortMethod
ponech v původní funkci — v custom režimu běží proti HANDLE=-1 (no-op, neškodí).
"""
from __future__ import annotations

import xbmc
import xbmcgui
import xbmcplugin


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/RmDir] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.rmdir", "RichMovie/RmDir")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "RmDir] " + str(msg), level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"


def is_custom_ui() -> bool:
    """True = RM 4.0 custom UI režim (rozhoduje plugin.py router přes window prop)."""
    try:
        return xbmcgui.Window(10000).getProperty("richmovie.rm_new_ui") == "1"
    except Exception:
        return False


class RmDir:
    """Zachytávací/propouštěcí sink pro directory listing.

    custom=None → autodetekce z window property; jinak vynucený režim.
    """

    def __init__(self, handle: int, title: str = "", *, custom=None):
        self.handle = handle
        self.title = title or "RichMovie"
        self.custom = is_custom_ui() if custom is None else bool(custom)
        self._items = []

    # ── přidání položky ──────────────────────────────────────────────────────
    def add(self, url, listitem, isFolder: bool = False) -> None:
        """Mirror `xbmcplugin.addDirectoryItem`. Custom: zapamatuj + označ
        rm_target_url/rm_isFolder/rm_playable; legacy: propusť na xbmcplugin."""
        if self.custom:
            try:
                listitem.setProperty("rm_target_url", url or "")
                listitem.setProperty("rm_isFolder", "1" if isFolder else "")
                # Přehratelná JEN když non-folder A má IsPlayable (video/smb/play
                # akce). Non-folder bez IsPlayable = akční položka (např. „Vymazat
                # historii") → NEpřehrávat, jen RunPlugin (řeší okno).
                _pl = ((listitem.getProperty("IsPlayable") or
                        listitem.getProperty("isPlayable") or "").strip().lower()
                       == "true")
                listitem.setProperty("rm_playable", "1" if (not isFolder and _pl) else "")
            except Exception:
                pass
            self._items.append(listitem)
        else:
            try:
                xbmcplugin.addDirectoryItem(self.handle, url, listitem, isFolder)
            except Exception as exc:
                _log(f"add legacy: {exc}", xbmc.LOGWARNING)

    def add_items(self, tuples) -> None:
        """Batch helper: tuples = iterable (url, listitem, isFolder)."""
        for url, li, isf in tuples:
            self.add(url, li, isf)

    @property
    def count(self) -> int:
        return len(self._items)

    # ── dokončení ────────────────────────────────────────────────────────────
    def finish(self, succeeded: bool = True, *, cacheToDisc: bool = False,
               updateListing: bool = False) -> None:
        """Mirror `xbmcplugin.endOfDirectory`. Custom: otevři RichMovieListWindow;
        legacy: propusť na xbmcplugin (1:1 chování pro rodinu)."""
        if self.custom:
            # uvolnit (RunPlugin) handle neškodně — directory se v custom režimu
            # nezobrazuje, okno kreslí seznam samo
            try:
                xbmcplugin.endOfDirectory(self.handle, succeeded=False,
                                          updateListing=False)
            except Exception:
                pass
            try:
                import sys
                import xbmcaddon
                import richmovie_list_window
                # Φ1 NavStack: routa listu = přesně invokační URL, ze kterého
                # ListItemy vznikly (sys.argv[0]+[2]) — jediná cesta, jak je
                # list okno rekonstruovatelné pro playback replay.
                route_url = ""
                try:
                    if len(sys.argv) > 2 and str(sys.argv[0]).startswith("plugin://"):
                        route_url = str(sys.argv[0]) + str(sys.argv[2])
                except Exception:
                    route_url = ""
                richmovie_list_window.open_list(
                    xbmcaddon.Addon(_ADDON_ID), title=self.title,
                    items=self._items, route_url=route_url)
            except Exception as exc:
                _log(f"open_list: {exc}", xbmc.LOGWARNING)
        else:
            try:
                xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded,
                                          updateListing=updateListing,
                                          cacheToDisc=cacheToDisc)
            except Exception as exc:
                _log(f"finish legacy: {exc}", xbmc.LOGWARNING)
