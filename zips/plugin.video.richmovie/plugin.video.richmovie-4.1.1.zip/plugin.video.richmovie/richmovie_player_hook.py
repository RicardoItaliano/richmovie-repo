# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_player_hook.py
# Kodi xbmc.Player subclass tracking rich psychology signals during playback.
# Phase A3 (RichMovie 3.1.0) — AI Personalized Recommendations feature.
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie 3.1.0 — Player psychology hook

Subclasses `xbmc.Player` to capture rich engagement signals per playback
session, then enqueues them into `richmovie_telemetry` for batched flush
to the Gate.

Tracked signals (per Handoff plan Section 5.2 + 6.2.1):

    - Timing:        started_at, ended_at, duration_watched_s, completion%,
                     drop_point_s (NULL = natural end)
    - Engagement:    pause_count, resume_count, seek_count, seek_fwd/back,
                     speed_used, speed_changes_count
    - Audio/subs:    audio_used, audio_switched_count, subs_used, subs_switched_count
    - Source/quality:source_used (WS/FS), quality_picked, quality_options
    - Context:       device_cluster_id, platform, addon_version, session_id
    - Sequence:      binge_session_id, is_part_of_binge, preceded_by_event_id

Multi-persona detection (Section 5/6 — taste profile compute) requires
*stable per-device fingerprint* — `device_cluster_id`. This module computes
it from Kodi build version + platform + hostname + screen resolution; same
physical device produces the same cluster_id across sessions.

Architecture:
    - One singleton `RichMoviePlayer` instance, started by service_warm.py
    - Kodi delivers callbacks (onAVStarted, onPlayBackPaused, …) on the
      Kodi UI thread; we mutate state directly (single-threaded delivery).
    - On `onPlayBackEnded` / `onPlayBackStopped`, we build the event payload
      and enqueue via richmovie_telemetry. NO blocking HTTP — flush is async.
    - Background position checkpoint thread polls `getTime()` every 5s (3.5.119)
      while playing — provides crash-safe drop point estimate (last known
      position survives Kodi crash mid-playback).

Author: Richie (autonomous Phase A3 implementation 2026-04-25)
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import platform as py_platform
import socket
import threading
import time
import uuid
from typing import Any

import xbmc
import xbmcaddon
import xbmcgui

from richmovie_telemetry import enqueue_watch_event, quarantine_watch_event
from richmovie_playback_end import EndKind, completion_ratio

# ─────────────────────────────────────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

_LOG_PREFIX = "[RichMovie.player]"

# 2026-07-01 (observability program): logování přehrávacího hooku přepnuto z
# přímého xbmc.log na ROUTOVANÝ logger → chyby onAVStarted/finalize/poll (dřív
# LOGERROR jen v lokálním kodi.log) nově tečou na NAS. `_log(msg, level=INFO)`.
try:
    from richmovie_logging import make_legacy_logger as _ph_make_legacy_logger
    _log = _ph_make_legacy_logger("richmovie.player", "RichMovie.player")
except Exception:
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log("{} {}".format(_LOG_PREFIX, msg), level)
        except Exception:
            pass

# Position polling interval — granularity of crash-safe drop_point.
# 3.5.119: 30 → 5 s = stejná granularita jako service_nextup._CHECK_EVERY.
# Hook i service klasifikují konec přehrávání ze SVÉHO checkpointu (dva
# xbmc.Player v jednom procesu — Kodi nedovolí sdílet instanci); s 30 s
# checkpointem se lišily až o 25 s a u EOF těsně nad prahem 0.93 se rozcházely
# (cross-check Pro Q9, 23.08.2026). Stáří checkpointu se navíc předává do
# `classify_end_shared(position_lag_s=…)` z reálného času zápisu.
_POSITION_CHECKPOINT_SECONDS = 5

# Window properties (IPC bridge between plugin.py and this player) used to
# carry tmdb_id + title metadata that the user clicked on. plugin.py sets
# these just before xbmc.Player().play(...).
_WIN_PROP_TMDB_ID = "RichMovie.PlayerCtx.tmdb_id"
_WIN_PROP_KIND    = "RichMovie.PlayerCtx.kind"          # 'movie' | 'tv'
_WIN_PROP_SEASON  = "RichMovie.PlayerCtx.season"
_WIN_PROP_EPISODE = "RichMovie.PlayerCtx.episode"
_WIN_PROP_TITLE   = "RichMovie.PlayerCtx.title"
_WIN_PROP_YEAR    = "RichMovie.PlayerCtx.year"
_WIN_PROP_GENRES  = "RichMovie.PlayerCtx.genres_json"
_WIN_PROP_ORIGIN  = "RichMovie.PlayerCtx.origin"
_WIN_PROP_RATING  = "RichMovie.PlayerCtx.imdb_rating"
_WIN_PROP_SOURCE  = "RichMovie.PlayerCtx.source"        # 'WS' | 'FS'
_WIN_PROP_QUALITY = "RichMovie.PlayerCtx.quality"       # '1080p' | '720p' | ...
_WIN_PROP_QUALITY_OPTIONS = "RichMovie.PlayerCtx.quality_options_json"

# Binge detection: same TV show, gap < this between consecutive episodes
_BINGE_GAP_SECONDS = 30 * 60

# Session-scoped previous event memory (binge sequence linker)
_last_session_state = {
    "session_id": None,
    "tmdb_id": None,
    "kind": None,
    "ended_at_epoch": None,
    "binge_session_id": None,
    "client_event_id": None,
}
_last_session_lock = threading.Lock()


# ─────────────────────────────────────────────────────────────────────────────
#  DEVICE CLUSTER FINGERPRINT
# ─────────────────────────────────────────────────────────────────────────────
# Stable per-device ID for multi-persona detection (Section 5/6 in plan).
# Same physical device → same cluster_id across sessions and reboots.
# Hostname + platform + screen resolution = enough entropy to distinguish
# TV-livingroom vs PC-bedroom vs Phone. Hostname avoids changing on
# Kodi update; resolution catches the case where same hostname runs on
# different displays (rare).
# ─────────────────────────────────────────────────────────────────────────────

_device_cluster_id_cache: str | None = None


def _detect_platform_kind() -> str:
    """Return 'TV' | 'PC' | 'Phone' | 'Tablet' | 'Other'."""
    try:
        sysname = py_platform.system().lower()
    except Exception:
        sysname = ""
    # Kodi-specific InfoLabel
    try:
        build = xbmc.getInfoLabel("System.BuildVersion") or ""
    except Exception:
        build = ""

    if "android" in build.lower() or "android" in sysname:
        # Android can be TV, phone, or tablet — heuristic on screen size
        try:
            w = int(xbmc.getInfoLabel("System.ScreenWidth") or 0)
            h = int(xbmc.getInfoLabel("System.ScreenHeight") or 0)
        except (TypeError, ValueError):
            w = h = 0
        diag = max(w, h)
        if diag >= 1900:
            return "TV"
        if diag >= 1200:
            return "Tablet"
        return "Phone"
    if sysname.startswith("linux"):
        # Linux — likely TV box or PC. Use Kodi build hint.
        if "libreelec" in build.lower() or "coreelec" in build.lower():
            return "TV"
        return "PC"
    if sysname.startswith("windows"):
        return "PC"
    if sysname.startswith("darwin"):
        return "PC"
    return "Other"


def payload_tmdb_ok(ctx: dict) -> bool:
    """Čistá: má kontext platné tmdb_id (int > 0)? Pro verdikt bdělosti v telemetrii (3.5.156)."""
    try:
        return int((ctx or {}).get("tmdb_id") or 0) > 0
    except (TypeError, ValueError):
        return False


def _compute_device_cluster_id() -> str:
    """Stable fingerprint, computed once per addon session."""
    global _device_cluster_id_cache
    if _device_cluster_id_cache is not None:
        return _device_cluster_id_cache

    try:
        hostname = socket.gethostname() or "unknown"
    except Exception:
        hostname = "unknown"
    # Strip volatile suffixes (.local, .lan, etc.) so cluster_id is stable
    hostname = hostname.split(".")[0].strip().lower() or "unknown"

    kind = _detect_platform_kind()  # 'TV' | 'PC' | 'Phone' | 'Tablet' | 'Other'

    # 3.5.152 (backlog 3.5.151): rozlišení OKNA Kodi bylo součástí otisku (`PC-richie-lenovo-1800p` vs.
    # `-781p` po zmenšení okna) → jedno zařízení ve dvou clusterech telemetrie. Otisk = druh + hostname.
    cluster = "{}-{}".format(kind, hostname)
    _device_cluster_id_cache = cluster
    _log("device_cluster_id = {}".format(cluster), xbmc.LOGINFO)
    return cluster


# ─────────────────────────────────────────────────────────────────────────────
#  HELPERS — ISO time, addon version, window props
# ─────────────────────────────────────────────────────────────────────────────

def _utcnow_iso() -> str:
    """RFC 3339 UTC timestamp with 'Z' suffix — Gate parses to TIMESTAMPTZ."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _profile_mode_now():
    """Režim profilů teď (SSOT `richmovie_profile.telemetry_profile_mode`); None = nečitelné."""
    try:
        import richmovie_profile as _rp
        return _rp.telemetry_profile_mode()
    except Exception:
        return None


def _addon_version() -> str:
    try:
        return xbmcaddon.Addon().getAddonInfo("version") or "unknown"
    except Exception:
        return "unknown"


def _get_window_prop(key: str, default: str = "") -> str:
    try:
        return xbmcgui.Window(10000).getProperty(key) or default
    except Exception:
        return default


def _clear_window_prop(key: str) -> None:
    try:
        xbmcgui.Window(10000).clearProperty(key)
    except Exception:
        pass


def _read_player_context() -> dict[str, Any]:
    """Read the {{tmdb_id, kind, title, year, genres, origin, rating, source,
    quality}} context that plugin.py wrote into Window properties just before
    xbmc.Player.play()."""
    ctx: dict[str, Any] = {}
    raw_id = _get_window_prop(_WIN_PROP_TMDB_ID)
    try:
        ctx["tmdb_id"] = int(raw_id) if raw_id else None
    except (TypeError, ValueError):
        ctx["tmdb_id"] = None

    ctx["kind"] = _get_window_prop(_WIN_PROP_KIND, "movie") or "movie"
    s_raw = _get_window_prop(_WIN_PROP_SEASON)
    e_raw = _get_window_prop(_WIN_PROP_EPISODE)
    ctx["season"] = int(s_raw) if s_raw.isdigit() else None
    ctx["episode"] = int(e_raw) if e_raw.isdigit() else None
    ctx["title"] = _get_window_prop(_WIN_PROP_TITLE) or "(unknown)"
    y_raw = _get_window_prop(_WIN_PROP_YEAR)
    ctx["year"] = int(y_raw) if y_raw.isdigit() else None

    g_raw = _get_window_prop(_WIN_PROP_GENRES)
    try:
        ctx["genres"] = json.loads(g_raw) if g_raw else []
    except (json.JSONDecodeError, TypeError):
        ctx["genres"] = []

    ctx["origin_country"] = _get_window_prop(_WIN_PROP_ORIGIN) or None
    r_raw = _get_window_prop(_WIN_PROP_RATING)
    try:
        ctx["imdb_rating"] = float(r_raw) if r_raw else None
    except (TypeError, ValueError):
        ctx["imdb_rating"] = None

    ctx["source_used"] = _get_window_prop(_WIN_PROP_SOURCE) or None
    ctx["quality_picked"] = _get_window_prop(_WIN_PROP_QUALITY) or None
    qo_raw = _get_window_prop(_WIN_PROP_QUALITY_OPTIONS)
    try:
        ctx["quality_options"] = json.loads(qo_raw) if qo_raw else []
    except (json.JSONDecodeError, TypeError):
        ctx["quality_options"] = []

    ctx["ident"] = _get_window_prop(_WIN_PROP_IDENT) or None
    ctx["search_id"] = _get_window_prop(_WIN_PROP_SEARCH_ID) or None
    p_raw = _get_window_prop(_WIN_PROP_LIST_POS)
    ctx["list_pos"] = int(p_raw) if p_raw.isdigit() else 0

    return ctx


_WIN_PROP_SET_AT = "RichMovie.PlayerCtx.set_at"   # epoch zápisu kontextu (3.5.152, úklid po neotevřeném streamu)
_WIN_PROP_IDENT = "RichMovie.PlayerCtx.ident"          # Φ-A: ident přehrávaného streamu
_WIN_PROP_SEARCH_ID = "RichMovie.PlayerCtx.search_id"  # Φ-A: sid hledání, z jehož výpisu se vybíralo
_WIN_PROP_LIST_POS = "RichMovie.PlayerCtx.list_pos"    # Φ-A: pozice ve výpisu (1 = první; 0 = neznámá)


def _clear_player_context() -> None:
    for k in (
        _WIN_PROP_TMDB_ID, _WIN_PROP_KIND, _WIN_PROP_SEASON, _WIN_PROP_EPISODE,
        _WIN_PROP_TITLE, _WIN_PROP_YEAR, _WIN_PROP_GENRES, _WIN_PROP_ORIGIN,
        _WIN_PROP_RATING, _WIN_PROP_SOURCE, _WIN_PROP_QUALITY,
        _WIN_PROP_QUALITY_OPTIONS, _WIN_PROP_SET_AT,
        _WIN_PROP_IDENT, _WIN_PROP_SEARCH_ID, _WIN_PROP_LIST_POS,
    ):
        _clear_window_prop(k)


def context_set_at() -> float:
    """Epoch zápisu aktuálního kontextu (0 = neznámo)."""
    try:
        return float(_get_window_prop(_WIN_PROP_SET_AT) or 0)
    except (TypeError, ValueError):
        return 0.0


def clear_player_context_if_older(than_epoch: float) -> bool:
    """3.5.152 (backlog 3.5.151, Fable QB5): stream se neotevřel (Stopped bez OnAVStarted) → kontext
    titulu by přežil do dalšího přehrávání mimo RichMovie (cizí video by dostalo cizí titul).
    Maže se JEN kontext zapsaný PŘED tímto otevřením — pozdní Stopped nesmí smazat kontext,
    který mezitím zapsal další `_play`. True = smazáno."""
    set_at = context_set_at()
    if set_at and than_epoch and set_at > float(than_epoch):
        return False
    _clear_player_context()
    return True


# ─────────────────────────────────────────────────────────────────────────────
#  PUBLIC: PLAYER CONTEXT BOOTSTRAP (called from plugin.py before play())
# ─────────────────────────────────────────────────────────────────────────────

def set_player_context(*,
                        tmdb_id: int | None,
                        kind: str = "movie",
                        season: int | None = None,
                        episode: int | None = None,
                        title: str = "",
                        year: int | None = None,
                        genres: list[str] | None = None,
                        origin_country: str | None = None,
                        imdb_rating: float | None = None,
                        source_used: str | None = None,
                        quality_picked: str | None = None,
                        quality_options: list[str] | None = None,
                        ident: str | None = None,
                        search_id: str | None = None,
                        list_pos: int = 0) -> None:
    """plugin.py calls this just before xbmc.Player().play(...).

    Player hook then reads these props in onAVStarted() and includes them
    in the watch event payload. Must be called before play() so that
    asynchronous callback delivery sees populated context.
    """
    win = xbmcgui.Window(10000)
    # Clear-then-set: zabrání zdědění starých polí (season/episode/year/…) z
    # předchozího přehrávání, které z nějakého důvodu nefinalizovalo (a tedy
    # nezavolalo _clear_player_context). Bez toho by film po seriálu mohl nést
    # starý season/episode.
    _clear_player_context()
    win.setProperty(_WIN_PROP_SET_AT, "%.3f" % time.time())
    if tmdb_id is not None:
        win.setProperty(_WIN_PROP_TMDB_ID, str(int(tmdb_id)))
    win.setProperty(_WIN_PROP_KIND, kind or "movie")
    if season is not None:
        win.setProperty(_WIN_PROP_SEASON, str(int(season)))
    if episode is not None:
        win.setProperty(_WIN_PROP_EPISODE, str(int(episode)))
    if title:
        win.setProperty(_WIN_PROP_TITLE, title)
    if year is not None:
        win.setProperty(_WIN_PROP_YEAR, str(int(year)))
    if genres:
        win.setProperty(_WIN_PROP_GENRES, json.dumps(genres, ensure_ascii=False))
    if origin_country:
        win.setProperty(_WIN_PROP_ORIGIN, origin_country)
    if imdb_rating is not None:
        win.setProperty(_WIN_PROP_RATING, "{:.1f}".format(float(imdb_rating)))
    if source_used:
        win.setProperty(_WIN_PROP_SOURCE, source_used)
    if quality_picked:
        win.setProperty(_WIN_PROP_QUALITY, quality_picked)
    if quality_options:
        win.setProperty(_WIN_PROP_QUALITY_OPTIONS,
                        json.dumps(quality_options, ensure_ascii=False))
    # Φ-A (30.09.2026, E5-F01): který stream, z kterého hledání a z které pozice výpisu — jen do LOGU konce
    # přehrání (do události pro Gate nejdou; schéma `WatchEventIn` se nemění)
    if ident:
        win.setProperty(_WIN_PROP_IDENT, str(ident))
    if search_id:
        win.setProperty(_WIN_PROP_SEARCH_ID, str(search_id))
    if list_pos:
        win.setProperty(_WIN_PROP_LIST_POS, str(int(list_pos)))


# ─────────────────────────────────────────────────────────────────────────────
#  RichMoviePlayer — main subclass
# ─────────────────────────────────────────────────────────────────────────────

class RichMoviePlayer(xbmc.Player):
    """Tracks engagement signals per playback session.

    Lifecycle: created once at addon startup (`service_warm.py`), persists
    until Kodi shuts down. Kodi delivers all callbacks on a single thread,
    so internal mutation does not require locking — only the position
    checkpoint thread reads/writes _last_known_position_s, which is
    protected by `_state_lock`.
    """

    def __init__(self) -> None:
        super().__init__()
        self._state_lock = threading.Lock()
        self._reset_state()

    def _reset_state(self) -> None:
        """Called per playback session in onAVStarted."""
        self.session_id = uuid.uuid4().hex
        self.client_event_id = uuid.uuid4().hex
        self.started_at_iso: str | None = None
        self.started_at_epoch: float = 0.0
        self._profile_mode_at_start: str | None = None   # S24 D3: režim profilů na začátku přehrání

        self.context: dict[str, Any] = {}
        self.total_runtime_s: int = 0
        self.last_known_position_s: int = 0
        self.last_position_at: float = 0.0   # time.monotonic() zápisu checkpointu

        # Engagement counters
        self.pause_count = 0
        self.resume_count = 0
        self.seek_count = 0
        self.seek_fwd_count = 0
        self.seek_back_count = 0
        self.speed_changes_count = 0
        self.current_speed = "1.0x"
        self.audio_switched_count = 0
        self.subs_switched_count = 0
        self._langs_known = False       # stav stop se už podařilo přečíst (první čtení = výchozí stav)

        # Initial audio/sub stream snapshot
        self.initial_audio: str | None = None
        self.initial_subs: str | None = None
        self.last_seen_audio: str | None = None
        self.last_seen_subs: str | None = None

        # Background position polling thread
        self._poll_thread: threading.Thread | None = None
        self._stop_polling = threading.Event()

        # Track if event was already finalized (avoid double-fire on
        # onPlayBackEnded → onPlayBackStopped sequence on some platforms)
        self._finalized = False

        # 3.5.151 (Fable F2): soubor, ke kterému segment patří (`getPlayingFile` v onAVStarted).
        # Když Kodi otevře jiný soubor ZA BĚHU, checkpoint pozice už patří novému segmentu.
        self._playing_file: str = ""

        # Televizní kanály F3 (08.11.2026): segment je živý kanál RichMovie — bez TMDb, délky a dokoukání → žádná
        # událost zhlédnutí, žádné sledování pozice, binge paměť beze změny (druh = SSOT `richmovie_media_kind`).
        self._live: bool = False

    def _playing_is_live(self) -> bool:
        """Druh přehrávané položky jako ve službě (`getPlayingItem().getProperty`, `richmovie_livetv.is_live_item`).
        Nečitelná položka = ne (VOD a cizí přehrávání beze změny)."""
        try:
            li = self.getPlayingItem()
        except Exception:
            return False
        try:
            import richmovie_livetv as _live
            return _live.is_live_item(li.getProperty)
        except Exception:
            return False

    # -----------------------------------------------------------------------
    #  Kodi player callbacks
    # -----------------------------------------------------------------------

    def onAVStarted(self) -> None:
        """Playback truly started (audio+video flowing). Snapshot context."""
        try:
            # 3.5.151 (Fable F2): nový soubor otevřený ZA BĚHU — obnova spojení službou (`Player.play`)
            # nebo spuštění jiného titulu bez Stopu. Kodi pak pošle jen onAVStarted, žádné Ended/Stopped
            # (VideoPlayer.cpp PLAYER_OPENFILE), a `_reset_state` by rozpracovaný segment zahodil bez
            # eventu. Uzavírá se TADY, až nový stream opravdu hraje: když se obnova neotevře, starý
            # stream hraje z bufferu dál a jeho segment (polling pozice, kontext) zůstává netknutý.
            live = self._playing_is_live()
            if live:
                # Televizní kanály F3 (A4 pasti 15–16): plugin pro kanál kontext hráče NEpíše → Window props pořád
                # patří předchozímu titulu. Smazat PŘED uzavřením jeho segmentu: shoda klíčů by film přepnutý na kanál
                # uzavřela jako „obnovu téhož titulu“ (utnutí) a kanál by kontext filmu převzal.
                _clear_player_context()
            if self.started_at_epoch and not self._finalized:
                self._finalize(kodi_ended=True, superseded=True)
            self._reset_state()
            if live:
                self._live = True
                _log("session={} živý kanál — telemetrie zhlédnutí, pozice a binge paměť vypnuté".format(
                    self.session_id), xbmc.LOGINFO)
                return
            self.started_at_iso = _utcnow_iso()
            self.started_at_epoch = time.time()
            # S24 D3 (cross-check Codex #1): režim profilů v okamžiku ZAČÁTKU přehrání — přepnutí účtu na více profilů
            # během filmu nesmí z doby „Jen já“ udělat událost „multi bez profilu“ (Gate by ji nedal majiteli).
            self._profile_mode_at_start = _profile_mode_now()
            self.context = _read_player_context()
            try:
                self._playing_file = self.getPlayingFile() or ""
            except Exception:
                self._playing_file = ""

            try:
                self.total_runtime_s = int(self.getTotalTime() or 0)
            except Exception:
                self.total_runtime_s = 0

            self.initial_audio, self.initial_subs, self._langs_known = self._current_stream_langs()
            self.last_seen_audio = self.initial_audio
            self.last_seen_subs = self.initial_subs

            _log(
                "session={} tmdb_id={} title={!r} runtime={}s".format(
                    self.session_id, self.context.get("tmdb_id"),
                    self.context.get("title"), self.total_runtime_s,
                ),
                xbmc.LOGINFO,
            )

            # Start background position polling
            self._stop_polling.clear()
            # A#7 (Fable audit): daemon — vlákno nedělá HTTP (jen getTime +
            # Window prop) a non-daemon bez abort-checku držel interpret služby
            # při shutdownu za přehrávání až do 5s force-killu Kodi.
            self._poll_thread = threading.Thread(
                target=self._position_checkpoint_loop,
                name="RichMovie-position-poll",
                daemon=True,
            )
            self._poll_thread.start()
        except Exception as exc:  # pragma: no cover — best-effort
            _log("onAVStarted exception: {!r}".format(exc), xbmc.LOGERROR)

    def onPlayBackPaused(self) -> None:
        self.pause_count += 1

    def onPlayBackResumed(self) -> None:
        self.resume_count += 1

    def onPlayBackSeek(self, time_ms: int, seekOffset_ms: int) -> None:
        self.seek_count += 1
        if seekOffset_ms > 0:
            self.seek_fwd_count += 1
        elif seekOffset_ms < 0:
            self.seek_back_count += 1

    def onPlayBackSpeedChanged(self, speed: int) -> None:
        # Kodi delivers integer speed (1, 2, 4, 8, -2, ...). Normalize.
        new_speed = "{}x".format(float(speed)) if speed else "1.0x"
        if new_speed != self.current_speed:
            self.speed_changes_count += 1
            self.current_speed = new_speed

    def onPlayBackEnded(self) -> None:
        # Kodi „konec souboru" ≠ dokoukáno — CDN utne stream a Kodi ohlásí
        # totéž (incident Zelňačka 23.08.2026). Rozhoduje richmovie_playback_end.
        self._finalize(kodi_ended=True)

    def onPlayBackStopped(self) -> None:
        self._finalize(kodi_ended=False)

    def onPlayBackError(self) -> None:
        # Kodi failed to play — don't enqueue an event (no engagement to record)
        # 3.5.151 (Fable N1): chyba otevření souboru ZA BĚHU (obnova spojení) přijde uprostřed rozpracovaného
        # segmentu (Kodi zahodí vstup starého streamu a `Prepare` nového selže → OnPlayBackError). Sledování před
        # výpadkem se uzavře stejně jako při úspěšném otevření: týž titul = utnutí, jiný titul = zastavení.
        if self.started_at_epoch and not self._finalized:
            self._finalize(kodi_ended=True, superseded=True)
        self._stop_polling.set()
        self._finalized = True

    # -----------------------------------------------------------------------
    #  Audio / subs language polling — Kodi doesn't fire callbacks on switch
    # -----------------------------------------------------------------------

    def _current_stream_langs(self) -> tuple:
        """(jazyk zvukové stopy, jazyk titulků | None když jsou vypnuté, stav znám) právě hrajícího videa.
        Třetí prvek False = stav se nepodařilo přečíst (Kodi ještě neotevřelo stream, selhal dotaz) —
        volající pak NIC nemění (neznámý stav není „titulky vypnuté“).

        Φ-A (30.09.2026, E5-F04): dřív `getAudioStream()` / `getSubtitleStream()` — ty `xbmc.Player`
        NEMÁ (jen `set…`), takže každé čtení skončilo výjimkou a `audio_used` byl prázdný u všech
        2 304 přehrání za 60 dní. Pravdu drží JSON-RPC `Player.GetProperties`."""
        try:
            resp = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "Player.GetActivePlayers"})) or "{}")
            pid = next((int(x.get("playerid")) for x in (resp.get("result") or [])
                        if x.get("type") == "video"), None)
            if pid is None:
                return (None, None, False)
            resp = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "Player.GetProperties",
                "params": {"playerid": pid,
                           "properties": ["currentaudiostream", "currentsubtitle", "subtitleenabled"]}})) or "{}")
            props = resp.get("result")
            if not isinstance(props, dict) or "subtitleenabled" not in props:
                return (None, None, False)
            audio = str((props.get("currentaudiostream") or {}).get("language") or "").strip() or None
            subs = None
            if props.get("subtitleenabled"):
                subs = str((props.get("currentsubtitle") or {}).get("language") or "").strip() or None
            return (audio, subs, True)
        except Exception:
            return (None, None, False)

    def _current_audio_lang(self) -> str | None:
        """Jazyk právě vybrané zvukové stopy (None = neznámý)."""
        return self._current_stream_langs()[0]

    def _current_subs_lang(self) -> str | None:
        """Jazyk zobrazených titulků (None = vypnuté nebo neznámý)."""
        return self._current_stream_langs()[1]

    def _check_stream_switches(self) -> None:
        """Called from position polling — detects mid-stream audio/sub changes."""
        cur_audio, cur_subs, known = self._current_stream_langs()
        if not known:
            return
        # Přepnutí = změna ZNÁMÉ stopy na jinou. První zjištění jazyka (po startu ještě neznámého) ani
        # chvilkově nečitelný stav přepnutím nejsou.
        if cur_audio is not None and cur_audio != self.last_seen_audio:
            if self.last_seen_audio is not None:
                self.audio_switched_count += 1
            self.last_seen_audio = cur_audio
            if self.initial_audio is None:
                self.initial_audio = cur_audio
        if not self._langs_known:
            # první čitelný stav po startu = výchozí stav, ne přepnutí
            self._langs_known = True
            self.initial_subs = cur_subs
            self.last_seen_subs = cur_subs
        elif cur_subs != self.last_seen_subs:
            self.subs_switched_count += 1
            self.last_seen_subs = cur_subs

    # -----------------------------------------------------------------------
    #  Position checkpoint loop — crash-safe drop_point estimate
    # -----------------------------------------------------------------------

    def _position_checkpoint_loop(self) -> None:
        """Poll getTime() while playing. Persist last-known-position to
        Window prop so a crash mid-playback still records a useful drop point.
        """
        _poll_mon = xbmc.Monitor()
        # 3.5.151 (Fable F2): událost i soubor TOHOTO segmentu. `_reset_state` při souboru otevřeném za
        # běhu nastaví nové hned po uzavření starého segmentu — čtení přes `self.` by staré vlákno
        # nechalo běžet dál vedle nového a zapisovat pozice cizího streamu.
        stop = self._stop_polling
        segment_file = self._playing_file
        foreign_logged = False
        while not stop.is_set():
            if stop.wait(_POSITION_CHECKPOINT_SECONDS):
                break
            if _poll_mon.abortRequested():  # A#7: Kodi se vypíná
                break
            try:
                if not self.isPlaying():
                    continue
                if segment_file:
                    try:
                        current_file = self.getPlayingFile() or ""
                    except Exception:
                        current_file = ""
                    if current_file and current_file != segment_file:
                        # už hraje jiný soubor (obnova spojení / jiný titul) → pozice patří novému segmentu
                        if not foreign_logged:
                            foreign_logged = True
                            _log("position poll: přehrává se jiný soubor než segment {} → pozice se nezapisuje".format(
                                self.session_id), xbmc.LOGINFO)
                        continue
                # 3.5.119 (B1): délka se dřív četla JEDNOU v onAVStarted; u části
                # streamů ji Kodi v tu chvíli ještě nezná (0) → event s
                # total_runtime_s=0 → Gate 422 → poison pill ve frontě (15 dní
                # mrtvá telemetrie na Richie-Home, 08.–23.08.2026). Obnovovat,
                # dokud není známá.
                try:
                    known = int(self.getTotalTime() or 0)
                except Exception:
                    known = 0
                if known <= 0:
                    # 3.5.151 (cross-check Pro B1 QB2): délka 0 = stream se právě otevírá (`CVideoPlayer::Prepare`
                    # stav maže) — čas je 0 i u navázání na 40:00; zápis by uzavřenému segmentu dal pozici 0.
                    continue
                if self.total_runtime_s <= 0:
                    self.total_runtime_s = known
                    _log("runtime resolved late: {}s".format(known), xbmc.LOGINFO)
                pos = int(self.getTime() or 0)
                with self._state_lock:
                    self.last_known_position_s = pos
                    self.last_position_at = time.monotonic()
                # Write to window prop so a crashed Kodi can be cleaned
                # up by next addon startup (future enhancement: on startup,
                # if this prop has a non-zero value but no recent flushed
                # event with this session_id, synthesize a "best-guess"
                # crash event from the persisted state).
                xbmcgui.Window(10000).setProperty(
                    "RichMovie.PlayerCtx.last_position_s", str(pos)
                )
                # Also poll for audio/sub stream switches
                self._check_stream_switches()
            except Exception as exc:  # pragma: no cover
                _log("position poll exception: {!r}".format(exc), xbmc.LOGWARNING)

    # -----------------------------------------------------------------------
    #  Finalize & enqueue
    # -----------------------------------------------------------------------

    def _finalize(self, kodi_ended: bool, *, superseded: bool = False) -> None:
        """Uzavře session a zařadí watch event.

        Args:
            kodi_ended: True = `onPlayBackEnded` (Kodi tvrdí konec souboru),
                        False = `onPlayBackStopped`. Co to znamená pro
                        „dokoukáno" rozhoduje SSOT `richmovie_playback_end`
                        (3.5.119, B2) — ne tenhle flag.
            superseded: 3.5.151 (Fable F2) — segment uzavírá onAVStarted NOVÉHO souboru
                        otevřeného za běhu. Přehrávač i Window props už patří novému
                        streamu: pozice jen z checkpointu, klíč z vlastního kontextu,
                        verdikt bez sdílení se službou (ta tenhle segment neklasifikuje)
                        a props se NEMAŽOU. Týž titul (obnova spojení) = utnutí zdrojem,
                        jiný titul = zastavení.
        """
        # onPlayBackEnded is sometimes followed by onPlayBackStopped on the
        # same session — guard against double finalize.
        if self._finalized:
            return
        self._finalized = True
        self._stop_polling.set()
        if self._live:
            # Televizní kanály F3: konec kanálu není konec titulu — žádná událost zhlédnutí ani karanténa, binge paměť
            # beze změny (TV mezi díly seriálu řetěz nepřetrhne), kontext hráče se nemaže (není náš, smazal ho start)
            _log("finalize: živý kanál — bez události zhlédnutí", xbmc.LOGDEBUG)
            return

        # 3.5.129 (Φ5 v hooku, Fable audit F-09): Stopped/Ended BEZ onAVStarted =
        # Kodi stream neotevřelo (HTML místo videa, CDN 4xx). Žádný event:
        # runtime 0 by skončil v karanténě telemetrie jako šum, ne jako sledování.
        # Diagnostiku (PLAY_OPEN_FAILED + dt) loguje služba; tady jen tichý úklid.
        if not self.started_at_epoch:
            _log("finalize skipped: no onAVStarted for this playback (open failed / stopped while buffering)",
                 xbmc.LOGINFO)
            return

        try:
            ended_at_iso = _utcnow_iso()
            ended_at_epoch = time.time()

            # Last position read: prefer live getTime() over checkpoint.
            # 3.5.119: po Ended/Stopped už Kodi přehrávač nemá → getTime() vyhodí
            # RuntimeError a Kodi ji zaloguje jako ERROR („Kodi is not playing any
            # media file", 4× při každém stopu). Ptát se jen když ještě hraje.
            pos_s = None
            position_lag_s = 0.0
            try:
                if not superseded and self.isPlaying():
                    pos_s = int(self.getTime() or 0)
            except Exception:
                pos_s = None
            if pos_s is None:
                with self._state_lock:
                    pos_s = int(self.last_known_position_s)
                    if self.last_position_at > 0.0:
                        position_lag_s = max(0.0, time.monotonic() - self.last_position_at)

            runtime = int(self.total_runtime_s or 0)
            if runtime <= 0 and not superseded:
                # Poslední šance — u některých streamů Kodi zná délku až za běhu.
                try:
                    if self.isPlaying():
                        runtime = int(self.getTotalTime() or 0)
                except Exception:
                    runtime = 0

            completion = completion_ratio(pos_s, runtime)
            from richmovie_playback_end import (classify_end, classify_end_shared as _classify_shared,
                                                ctx_key as _key_of, player_ctx_key as _ctx_key)
            if superseded:
                own_key = _key_of(self.context)
                same_title = bool(own_key) and own_key == _ctx_key()
                end_kind = classify_end(kodi_ended=same_title, position_s=pos_s,
                                        duration_s=runtime, position_lag_s=position_lag_s)
                if same_title and end_kind is EndKind.NATURAL:
                    # Obnova TÉHOŽ titulu = utnutí zdrojem, přehrávání pokračuje dál. Pozice nad prahem dokoukání
                    # (obnova rozhodnutá těsně pod prahem, stream se otevřel o pár sekund později) nesmí dát
                    # ✔ ani „přirozený konec" — ten patří až skutečnému konci (cross-check Pro B1 QB3 / Flash 3a).
                    end_kind = EndKind.UNEXPECTED_EOF
                _log("segment superseded: {} → end={} pos={}s".format(
                    "obnova téhož titulu" if same_title else "jiný titul", end_kind.value, pos_s), xbmc.LOGINFO)
            else:
                end_kind = _classify_shared(_ctx_key(), kodi_ended=kodi_ended, position_s=pos_s,
                                            duration_s=runtime, position_lag_s=position_lag_s)
            natural_end = end_kind is EndKind.NATURAL

            duration_watched_s = max(0, int(ended_at_epoch - self.started_at_epoch))

            # drop_point: NULL JEN při skutečném dokoukání. UNEXPECTED_EOF (CDN
            # utnul stream) nese pozici jako každé jiné přerušení — jinak AI
            # dostává „přirozený konec" při 40 % (incident Zelňačka).
            drop_point_s: int | None
            if natural_end:
                drop_point_s = None
            else:
                drop_point_s = pos_s

            # Binge sequence detection — same TV show, gap < 30 min
            binge_session_id, preceded_by_event_id = self._detect_binge_link(ended_at_epoch)

            # Build payload (matches Section 6.2.1 watch_history_json schema)
            ctx = self.context or {}
            # Profily (3.5.134): event patří profilu aktivnímu v okamžiku přehrání
            # (čteno z Window prop → i po přepnutí v pluginu). Host → event se
            # neposílá (viz níže), aby návštěva nepokazila nikomu historii.
            try:
                import richmovie_profile as _rp
                _profile_id = _rp.telemetry_profile_id()
                _is_guest = _rp.is_guest()
            except Exception:
                _profile_id, _is_guest = None, False
            # S24 D3: režim ze ZAČÁTKU přehrání (onAVStarted); bez něj (segment bez startu) režim teď
            _profile_mode = getattr(self, "_profile_mode_at_start", None) or _profile_mode_now()
            # 3.5.156 (Φ1b, Gate mig 0037): verdikt bdělosti z `richmovie_attention` do telemetrie —
            # jen u dílu seriálu (tracker sleduje řetěz autoplaye), film = None (Gate odvodí ze signálů).
            _w_kind_tel = None
            if ctx.get("kind") == "tv" and payload_tmdb_ok(ctx):
                try:
                    import richmovie_attention as _att_tel
                    _w_kind_tel = _att_tel.TRACKER.current_kind(
                        "tv:%d:%d:%d" % (int(ctx.get("tmdb_id") or 0), int(ctx.get("season") or 0),
                                         int(ctx.get("episode") or 0)))
                except Exception:
                    _w_kind_tel = None
            payload = {
                "client_event_id": self.client_event_id,
                "session_id": self.session_id,
                "profile_id": _profile_id,
                "profile_mode": _profile_mode,   # S24 D3 — Gate: event bez profilu z doby „Jen já“ → majitel
                "watched_kind": _w_kind_tel if _w_kind_tel in ("attended", "unattended", "manual") else None,

                # Title metadata (from plugin.py via Window props)
                "tmdb_id": ctx.get("tmdb_id"),
                "kind": ctx.get("kind") or "movie",
                "season": ctx.get("season"),
                "episode": ctx.get("episode"),
                "title": ctx.get("title") or "(unknown)",
                "year": ctx.get("year"),
                "genres": ctx.get("genres") or [],
                "origin_country": ctx.get("origin_country"),
                "imdb_rating": ctx.get("imdb_rating"),

                # Timing
                "started_at": self.started_at_iso,
                "ended_at": ended_at_iso,
                "duration_watched_s": duration_watched_s,
                "total_runtime_s": runtime,
                "completion": round(completion, 3),
                "drop_point_s": drop_point_s,

                # Device cluster + meta
                "device_cluster_id": _compute_device_cluster_id(),
                "platform": py_platform.system() if hasattr(py_platform, "system") else None,
                "addon_version": _addon_version(),

                # Audio / subs
                "audio_used": self.last_seen_audio,
                "audio_switched_count": self.audio_switched_count,
                "subs_used": self.last_seen_subs,
                "subs_switched_count": self.subs_switched_count,

                # Engagement
                "pause_count": self.pause_count,
                "resume_count": self.resume_count,
                "seek_count": self.seek_count,
                "seek_fwd_count": self.seek_fwd_count,
                "seek_back_count": self.seek_back_count,
                "speed_used": self.current_speed,
                "speed_changes_count": self.speed_changes_count,

                # Source / quality
                "source_used": ctx.get("source_used"),
                "quality_picked": ctx.get("quality_picked"),
                "quality_options": ctx.get("quality_options") or [],

                # Binge sequence
                "binge_session_id": binge_session_id,
                "is_part_of_binge": bool(binge_session_id),
                # B#1 (Fable audit): Gate čte `preceded_by_client_event_id`
                # (schemas.py) a extra="ignore" starý klíč tiše zahazoval —
                # binge řetěz byl v DB od 3.1.0 vždy NULL.
                "preceded_by_client_event_id": preceded_by_event_id,
            }

            # Skip enqueue if tmdb_id is missing (we can't link to TMDb metadata)
            # — most likely an external play (file://, http://) outside our flow.
            if payload["tmdb_id"] and runtime <= 0:
                # 3.5.119 (B1): Gate (Pydantic gt=0 + DB CHECK) event bez délky
                # odmítne. Dřív šel do fronty a jako první prvek blokoval
                # 422 na celý batch — 15 dní mrtvé telemetrie. Karanténa =
                # data se neztratí (diagnostika), fronta zůstává průchozí.
                quarantine_watch_event(payload, reason="runtime_unknown")
                _log(
                    "watch_event QUARANTINED tmdb_id={} reason=runtime_unknown "
                    "end={} pos={}s".format(payload["tmdb_id"], end_kind.value, pos_s),
                    xbmc.LOGWARNING,
                )
            elif payload["tmdb_id"] and _is_guest:
                _log("watch_event SKIPPED (Host profil — nic se neukládá) tmdb_id={}".format(payload["tmdb_id"]))
            elif payload["tmdb_id"]:
                enqueue_watch_event(payload)
                _log(
                    "enqueued watch_event tmdb_id={} completion={:.2f} "
                    "end={} drop={} pauses={} seeks={} ident={} sid={} pos={} q={} audio={} subs={}".format(
                        payload["tmdb_id"], completion, end_kind.value,
                        drop_point_s if drop_point_s is not None else "natural",
                        self.pause_count, self.seek_count,
                        ctx.get("ident") or "-", ctx.get("search_id") or "-", ctx.get("list_pos") or 0,
                        ctx.get("quality_picked") or "-", self.last_seen_audio or "-",
                        self.last_seen_subs or "-",
                    ),
                    xbmc.LOGINFO,
                    context={"ev": "PLAY_RESULT", "ident": ctx.get("ident"), "sid": ctx.get("search_id"),
                             "pos": ctx.get("list_pos") or 0, "end": end_kind.value,
                             "completion": round(completion, 3), "watched_s": duration_watched_s,
                             "q": ctx.get("quality_picked"), "audio": self.last_seen_audio,
                             "subs": self.last_seen_subs, "src": ctx.get("source_used")},
                )
                # 2026-05-30: flush HNED po dokončení přehrávání → event dorazí na
                # Gate během pár vteřin, NEZÁVISLE na zavření/restartu Kodi (TV jde
                # do standby, Kodi se prakticky nikdy nezavírá). Daemon flush vlákno
                # (durable buffer + idempotentní Gate) → neblokuje shutdown.
                try:
                    from richmovie_telemetry import flush_in_background as _flush_now
                    _flush_now()
                except Exception as _fe:
                    # 2026-07-01: dřív tiché — flush selhání je diagnosticky užitečné
                    # (telemetrie/AI signály). DEBUG (buffer je durable, retry běží dál).
                    _log("watch_event flush_in_background failed: {!r}".format(_fe), xbmc.LOGDEBUG)

                # Lokální „dokoukáno" SSOT pro watched markery v UI seznamu epizod.
                # watch_history (plugin._play) je start-based; tohle je completion-based.
                # Best-effort, fail-safe — nikdy nesmí shodit finalizaci playbacku.
                # 3.5.119: JEN při NATURAL (práh = richmovie_playback_end, dřív 0.95 zde
                # vs 0.93 v service → dva prahy pro jednu pravdu).
                if natural_end \
                        and ctx.get("kind") == "tv" \
                        and ctx.get("season") is not None \
                        and ctx.get("episode") is not None:
                    try:
                        import richmovie_history as _rmh
                        # 4.0.3 (D1): dokoukáno = ✔ `attended`; ⏾ dá jen verdikt spánku služby (`_sleep_verdict`).
                        # Přítomnost u dílu (`current_kind`) jde jen do telemetrie (váha kulisy v doporučeních).
                        _rmh.watched_mark_episode(
                            tv_id=payload["tmdb_id"],
                            season=ctx.get("season"),
                            episode=ctx.get("episode"),
                            completion=completion,
                            kind="attended",
                        )
                    except Exception as _me:
                        # 2026-07-01: dřív tiché — selhání ovlivní zelené ✔ markery
                        # dokoukaných epizod v UI. WARNING (viditelné centrálně).
                        _log("watched_mark_episode failed: {!r}".format(_me), xbmc.LOGWARNING)

            # Update binge sequence memory for next session
            self._update_binge_memory(ended_at_epoch)

            # Clean window props so next play reads fresh context.
            # Uzavřený segment souboru otevřeného za běhu: props už patří novému streamu (Fable F2).
            if not superseded:
                _clear_player_context()
        except Exception as exc:
            _log("finalize exception: {!r}".format(exc), xbmc.LOGERROR)

    # -----------------------------------------------------------------------
    #  Binge sequence linker
    # -----------------------------------------------------------------------

    def _detect_binge_link(self, _now_epoch: float) -> tuple[str | None, str | None]:
        """Check global last-session memory: was the previous event the same
        TV show, ended < 30min ago? If yes, this session is part of a binge —
        either inherit the prior binge_session_id or start a new one.

        Returns (binge_session_id, preceded_by_client_event_id).

        Note: preceded_by_event_id in the DB schema is BIGINT FK to user_watch_events.id;
        Gate-side resolves our `client_event_id` → `id` at INSERT time (lookup via
        unique index on (user_id, client_event_id)). Addon does not know the DB id.
        """
        ctx = self.context or {}
        if ctx.get("kind") != "tv":
            return (None, None)
        cur_tmdb = ctx.get("tmdb_id")
        if not cur_tmdb:
            return (None, None)

        with _last_session_lock:
            prev = dict(_last_session_state)

        if (prev["kind"] == "tv"
                and prev["tmdb_id"] == cur_tmdb
                and prev["ended_at_epoch"] is not None
                and (self.started_at_epoch - prev["ended_at_epoch"]) <= _BINGE_GAP_SECONDS):
            binge_id = prev["binge_session_id"] or uuid.uuid4().hex
            return (binge_id, prev["client_event_id"])

        return (None, None)

    def _update_binge_memory(self, ended_at_epoch: float) -> None:
        """Remember this session for next finalize's binge check."""
        ctx = self.context or {}
        # Recompute: if THIS session was part of a binge, propagate binge_id;
        # otherwise start a fresh chain with no binge_id.
        binge_id, _ = self._detect_binge_link(ended_at_epoch)
        if binge_id is None and ctx.get("kind") == "tv":
            # New TV session — could become start of a future binge
            binge_id = uuid.uuid4().hex
        with _last_session_lock:
            _last_session_state["session_id"] = self.session_id
            _last_session_state["client_event_id"] = self.client_event_id
            _last_session_state["tmdb_id"] = ctx.get("tmdb_id")
            _last_session_state["kind"] = ctx.get("kind")
            _last_session_state["ended_at_epoch"] = ended_at_epoch
            _last_session_state["binge_session_id"] = binge_id


# ─────────────────────────────────────────────────────────────────────────────
#  Singleton instance — created once by service_warm.py
# ─────────────────────────────────────────────────────────────────────────────

_player_singleton: RichMoviePlayer | None = None


def get_player() -> RichMoviePlayer:
    """Singleton accessor. Creates once; never replaced (Kodi attaches the
    instance to its event dispatcher when first instantiated)."""
    global _player_singleton
    if _player_singleton is None:
        _player_singleton = RichMoviePlayer()
        _log("singleton instantiated", xbmc.LOGINFO)
    return _player_singleton
