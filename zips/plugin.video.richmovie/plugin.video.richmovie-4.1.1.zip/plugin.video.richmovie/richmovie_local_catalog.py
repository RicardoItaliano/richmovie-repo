# -*- coding: utf-8 -*-
"""
richmovie_local_catalog.py — klient katalogu lokálních souborů (Fáze CD, 3.5.128)
=================================================================================

PROČ (gunžík 30.08.2026: „po každém spuštění analýza složek, čím víc, tím déle")
--------------------------------------------------------------------------------
Do 3.5.127 procházel doplněk při startu celý SMB share rekurzivně a každý soubor
hledal na TMDb sám — na televizi, přes Wi-Fi, pokaždé. Katalog teď staví Gate
přímo na NASu (inkrementálně) a tenhle modul si drží jen LOKÁLNÍ KOPII:

    addon_data/local_catalog.json   {"version": N, "items": {rel_path: {...}}}

Menu NASu čte výhradně kopii (okamžité, offline-schopné). Synchronizace =
`GET /v1/local/catalog?since=<naše verze>` — delta, 304 při shodě. Běží ve
SLUŽBĚ (`service_nextup`), ne v invokaci pluginu; plugin si ji jen vyžádá
Window property (stejný vzor jako obnova stavu účtu).

Přehrávání se NEMĚNÍ: přímé `smb://` URL staví dál `richmovie_local_files`.
Tvar metadat (`get_local_meta`) je záměrně shodný se starým
`get_local_tmdb_movie_meta`, aby vykreslení v plugin.py zůstalo beze změny.
"""

from __future__ import annotations

import json
import os
import time
from typing import Any, Dict, List, Optional, Tuple

try:
    import xbmc
    import xbmcvfs
except Exception:  # pragma: no cover — mimo Kodi (harness)
    xbmc = None  # type: ignore
    xbmcvfs = None  # type: ignore

import richmovie_atomic as _atomic
import richmovie_winprops as _winprops

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.local_catalog", "RichMovie/LocalCatalog")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/LocalCatalog] %s" % msg, level)
        except Exception:
            pass

_LOGINFO = getattr(xbmc, "LOGINFO", 1)
_LOGWARNING = getattr(xbmc, "LOGWARNING", 2)

ADDON_ID = "plugin.video.richmovie"
CATALOG_FILE = "local_catalog.json"
SCHEMA_VERSION = 1

# Lokální kopie se považuje za čerstvou tolik sekund — menu NASu při otevření
# jen požádá o sync, když je starší (server má vlastní interval skenu 15 min).
FRESH_S = 15 * 60

PROP_SYNC_REQUEST = "richmovie.localcatalog.sync"

TMDB_IMG = "https://image.tmdb.org/t/p/"


# ─────────────────────────────────────────────────────────────────────────────
#  LOKÁLNÍ KOPIE
# ─────────────────────────────────────────────────────────────────────────────
def _catalog_path() -> str:
    if xbmcvfs is None:
        return os.path.join(os.path.expanduser("~"), CATALOG_FILE)
    profile = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    return os.path.join(profile, CATALOG_FILE)


def load() -> Dict[str, Any]:
    """Lokální kopie katalogu, nebo prázdná (poškozená jde do karantény + ERROR)."""
    data, _state = _atomic.read_json(_catalog_path(), None, name=CATALOG_FILE,
                                     expected_type=dict)
    if (isinstance(data, dict) and isinstance(data.get("items"), dict)
            and int(data.get("schema_version") or 0) == SCHEMA_VERSION):
        return data
    return {"schema_version": SCHEMA_VERSION, "version": 0, "fetched_at": 0, "items": {}}


def save(catalog: Dict[str, Any]) -> bool:
    catalog["schema_version"] = SCHEMA_VERSION
    return _atomic.write_json(_catalog_path(), catalog,
                              separators=(",", ":"))


def version() -> int:
    try:
        return int(load().get("version") or 0)
    except Exception:
        return 0


def is_stale() -> bool:
    cat = load()
    return (time.time() - float(cat.get("fetched_at") or 0)) > FRESH_S


# ─────────────────────────────────────────────────────────────────────────────
#  ČTENÍ PRO UI (nahrazuje SMB listing + per-soubor TMDb lookup)
# ─────────────────────────────────────────────────────────────────────────────
def list_dir(relative_path: str = "") -> Tuple[List[str], List[str]]:
    """(složky, video soubory) přímo pod `relative_path` — z lokální kopie,
    žádné SMB kolo. Stejný kontrakt jako `richmovie_local_files.list_dir`."""
    rel = (relative_path or "").replace("\\", "/").strip("/")
    prefix = rel + "/" if rel else ""
    dirs = set()
    files = []
    for rel_path in load()["items"]:
        if not rel_path.startswith(prefix):
            continue
        rest = rel_path[len(prefix):]
        if "/" in rest:
            dirs.add(rest.split("/", 1)[0])
        else:
            files.append(rest)
    return sorted(dirs, key=str.lower), sorted(files, key=str.lower)


def get_local_meta(relative_path: str) -> Tuple[Optional[Dict[str, Any]], bool]:
    """Metadata souboru ve TVARU starého `get_local_tmdb_movie_meta`:
    (meta|None, did_network_lookup=False). Síť se odsud NIKDY nevolá."""
    item = load()["items"].get((relative_path or "").replace("\\", "/").strip("/"))
    if not isinstance(item, dict) or not item.get("tmdb_id"):
        return None, False
    poster = item.get("poster_path") or ""
    backdrop = item.get("backdrop_path") or ""
    meta = {
        "tmdb_id": int(item["tmdb_id"]),
        "title": item.get("title") or "",
        "original_title": item.get("original_title") or "",
        "year": int(item.get("year") or 0),
        "runtime": int(item.get("runtime_min") or 0),
        "plot": item.get("plot") or "",
        "rating": float(item.get("rating") or 0.0),
        "votes": 0,
        "genres": list(item.get("genres") or []),
        "release_badge": "",
        "provider": "",
        "kind": item.get("kind") or "movie",
        "season": item.get("season"),
        "episode": item.get("episode"),
        "art": {
            "poster": (TMDB_IMG + "w342" + poster) if poster else "",
            "fanart": (TMDB_IMG + "original" + backdrop) if backdrop else "",
        },
    }
    return meta, False


# ─────────────────────────────────────────────────────────────────────────────
#  ŽÁDOST O SYNC (plugin → služba)
# ─────────────────────────────────────────────────────────────────────────────
def request_sync(reason: str = "menu") -> None:
    try:
        _winprops.set_prop(PROP_SYNC_REQUEST, reason)
    except Exception as exc:
        _log("request_sync failed: %r" % (exc,), _LOGWARNING)


def consume_sync_request() -> str:
    try:
        reason = (_winprops.get_prop(PROP_SYNC_REQUEST, "") or "").strip()
        if reason:
            _winprops.clear_prop(PROP_SYNC_REQUEST)
        return reason
    except Exception:
        return ""


# ─────────────────────────────────────────────────────────────────────────────
#  SYNCHRONIZACE (běží ve službě)
# ─────────────────────────────────────────────────────────────────────────────
def sync_now(reason: str = "manual") -> str:
    """Stáhne delta katalogu z Gate a slije do lokální kopie.

    Vrací: "updated" | "unchanged" | "skipped:<proč>" | "failed:<proč>".
    R2: jakékoli selhání nechává lokální kopii beze změny (stale-first).
    Delta se aplikuje jen z ODPOVĚDI s kontraktním tvarem (`status: ok`).
    """
    try:
        import richmovie_gate as _gate
        if not _gate.is_local_filmoteka_allowed():
            return "skipped:no_permission"
        import richmovie_gate_transport as _gt
        import richmovie_http as _rm_http

        username, proof = _gt.get_identity_strict()
        if not username or not proof:
            return "skipped:no_identity"

        cat = load()
        url = "%s/v1/local/catalog?since=%d" % (_gt.GATE_URL, int(cat.get("version") or 0))
        headers = {
            "Accept": "application/json",
            "User-Agent": "RichMovie (+plugin.video.richmovie)",
            "X-WS-Username": username,
            "X-WS-Proof": proof,
            "X-Device-Hash": _gt.get_device_hash(),
        }
        profile = _rm_http.profile_background().replace(timeout_s=30.0)
        status, raw, _hdrs = _rm_http.request(url, headers=headers, profile=profile,
                                              tag="local_catalog")
        if status == 304:
            cat["fetched_at"] = int(time.time())
            save(cat)
            return "unchanged"
        if status != 200:
            _log("sync failed: HTTP %s" % status, _LOGWARNING,
                 context={"status": status, "reason": reason})
            return "failed:http_%s" % status

        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict) or payload.get("status") != "ok":
            return "failed:bad_payload"

        items = cat["items"] if not payload.get("full") else {}
        for item in payload.get("items") or []:
            if isinstance(item, dict) and item.get("rel_path"):
                items[item["rel_path"]] = item
        for rel_path in payload.get("removed") or []:
            items.pop(rel_path, None)

        new_cat = {
            "schema_version": SCHEMA_VERSION,
            "version": int(payload.get("version") or 0),
            "fetched_at": int(time.time()),
            "items": items,
        }
        if not save(new_cat):
            return "failed:write"
        _log("sync %s: v%s items=%d (+%d/-%d) full=%s" % (
            reason, new_cat["version"], len(items),
            len(payload.get("items") or []), len(payload.get("removed") or []),
            bool(payload.get("full"))), _LOGINFO,
            context={"reason": reason, "version": new_cat["version"],
                     "items": len(items), "full": bool(payload.get("full"))})
        try:
            import richmovie_ui_common as _uc
            _uc.data_rev_bump("local")
        except Exception:
            pass
        return "updated"
    except Exception as exc:
        _log("sync failed: %r" % (exc,), _LOGWARNING, context={"reason": reason})
        return "failed:%s" % type(exc).__name__
