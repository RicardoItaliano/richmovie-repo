# -*- coding: utf-8 -*-
"""RichMovie 4.0 — custom Episodes okno (WindowXMLDialog) — Φ2a.

Seriálový tok celý custom: 2 úrovně v jednom listu (sezóny → epizody se zelenou ✔).

Φ-R1+R2 (2026-06-12):
  • TMDb fetch (tv_details / season_details) běží v pozadí (uc.fetch_async) —
    okno reaguje okamžitě, „Načítám…" v podtitulku, chyba viditelná.
  • Klik na epizodu = PICKER-FIRST: Stream-picker se otevře HNED („Hledám
    streamy…") NAD Episodes, tv_play search běží v jiném invokeru (token).
    Back z pickeru vrací do epizod — binge tok bez slepého čekání.

Data: TMDb + watched_episodes.json (✔). SSOT: richmovie_ui_common.
XML: RichMovieEpisodes.xml. Best-effort, neshodí addon.
"""
from __future__ import annotations

import xbmc
import xbmcaddon
import xbmcgui

import richmovie_ui_common as uc
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/Episodes] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.episodes", "RichMovie/Episodes")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "Episodes] " + str(msg), level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"
_XML = "RichMovieEpisodes.xml"
_RES = "1080i"
_LIST = 7100


class RichMovieEpisodesWindow(uc.RMNavMixin, xbmcgui.WindowXMLDialog):

    def __init__(self, *a, tv_id="", tv_name="", **kw):
        super().__init__(*a, **kw)
        self._tv_id = str(tv_id or "")
        self._tv_name = tv_name or ""
        self._level = "seasons"
        self._season = 0
        self._tc = None
        self._poster = ""   # show poster (TMDb) → picker ho zobrazí HNED
        self._eps_meta = {}  # {episode_no: {overview, still_path}} pro detail/picker
        self._rm_closed = False

    def onInit(self) -> None:
        self.setProperty("rm_ep_title", self._tv_name)
        self._load_seasons()

    def _tmdb(self):
        if self._tc is None:
            try:
                from tmdb_client import TMDb
                from richmovie_settings import get_tmdb_api_key
                # SSOT 3.5.69 (bandog vzor): lokální setting je jen cache plněná
                # při WS-loginu — accessor padá na klíč z Gate lease cache.
                key = get_tmdb_api_key()
                self._tc = TMDb(key, lang="cs-CZ") if key else False
            except Exception:
                self._tc = False
        return self._tc or None

    # ------------------------------------------------------------------ sezóny
    def _load_seasons(self) -> None:
        self._level = "seasons"
        self.setProperty("rm_ep_sub", "Načítám sezóny…")
        uc.fetch_async(self, self._fetch_seasons, self._apply_seasons,
                       tag="eps", on_error=self._fetch_failed)

    def _fetch_seasons(self):
        tc = self._tmdb()
        if not (tc and self._tv_id):
            raise RuntimeError("TMDb klient není k dispozici")
        return tc.tv_details(int(self._tv_id)) or {}

    def _apply_seasons(self, d) -> None:
        if self._level != "seasons":
            return  # uživatel mezitím kliknul na sezónu
        self.setProperty("rm_ep_sub", "Vyber sezónu")
        if d.get("poster_path"):
            self._poster = d.get("poster_path") or ""
        if d.get("backdrop_path"):
            self.setProperty("rm_ep_fanart", uc.img(d.get("backdrop_path"), "w1280"))
        lst = self.getControl(_LIST)
        lst.reset()
        for s in (d.get("seasons") or []):
            try:
                sn = int(s.get("season_number") or 0)
            except Exception:
                continue
            if sn < 1:
                continue  # přeskoč speciály (sezóna 0)
            cnt = s.get("episode_count") or 0
            li = xbmcgui.ListItem(f"Sezóna {sn}   [COLOR FF9AA4B2]({cnt} epizod)[/COLOR]")
            li.setProperty("rm_kind", "season")
            li.setProperty("rm_season", str(sn))
            lst.addItem(li)
        uc.focus_first(self, [_LIST])

    # ------------------------------------------------------------------ epizody
    def _load_episodes(self, season_no: int) -> None:
        self._level = "episodes"
        self._season = season_no
        self.setProperty("rm_ep_sub", f"Sezóna {season_no} · načítám…")

        def _fetch():
            tc = self._tmdb()
            if not tc:
                raise RuntimeError("TMDb klient není k dispozici")
            eps = tc.season_details(int(self._tv_id), season_no) or []
            # 4.0.3 (A5/A9): čerstvý stav profilu (probuzené zařízení) a stav dílů ze SSOT `episode_badge`
            try:
                import richmovie_state_sync as _ss_ep
                _ss_ep.pull_if_stale(max_age_s=_ss_ep.LIST_FRESH_MAX_AGE_S, step="pull_list")
            except Exception:
                pass
            badges = {}
            try:
                import richmovie_history as hist
                w_info = hist.watched_info_for_series(self._tv_id)
                p_info = hist.progress_for_series(self._tv_id)
                for e in eps:
                    no = int(e.get("episode_number") or 0)
                    badges[no] = hist.episode_badge(w_info.get((season_no, no)), p_info.get((season_no, no)))
            except Exception:
                badges = {}
            return {"eps": eps, "badges": badges, "season": season_no}

        uc.fetch_async(self, _fetch, self._apply_episodes,
                       tag="eps", on_error=self._fetch_failed)

    def _apply_episodes(self, data) -> None:
        if self._level != "episodes" or self._season != data.get("season"):
            return  # mezitím se přepnula úroveň/sezóna
        self.setProperty("rm_ep_sub", f"Sezóna {self._season}")
        badges = data.get("badges") or {}
        lst = self.getControl(_LIST)
        lst.reset()
        self._eps_meta = {}
        for e in (data.get("eps") or []):
            try:
                no = int(e.get("episode_number") or 0)
            except Exception:
                continue
            name = (e.get("name") or "").strip()
            label = f"{no}. {name}" if name else f"Epizoda {no}"
            li = xbmcgui.ListItem(label)
            li.setProperty("rm_kind", "episode")
            li.setProperty("rm_ep", str(no))
            li.setProperty("rm_name", name)
            # Episode-specific náhled + popis (detail panel vpravo)
            overview = (e.get("overview") or "").strip()
            still = (e.get("still_path") or "").strip()
            li.setProperty("rm_still", uc.img(still, "w780") if still else "")
            li.setProperty("rm_plot", overview or "Popis epizody není k dispozici.")
            meta = []
            if e.get("air_date"):
                meta.append(str(e.get("air_date")))
            try:
                if float(e.get("vote_average") or 0) > 0:
                    meta.append(f"★ {float(e.get('vote_average')):.1f}")
            except Exception:
                pass
            try:
                if int(e.get("runtime") or 0) > 0:
                    meta.append(f"{int(e.get('runtime'))} min")
            except Exception:
                pass
            badge = badges.get(no) or {}
            if badge.get("text"):
                meta.insert(0, "[COLOR %s]%s%s[/COLOR]" % (badge.get("color") or "FFFFFFFF", badge.get("symbol") or "",
                                                         badge["text"].replace(" · ", " ", 1)))
            li.setProperty("rm_ep_meta", "   ·   ".join(meta))
            li.setProperty("rm_ep_state", str(badge.get("state") or ""))
            if badge.get("watched"):
                li.setProperty("rm_watched", "1")
            if float(badge.get("position") or 0) > 0 and float(badge.get("duration") or 0) > 0:
                try:   # proužek postupu = nativní ListItem.PercentPlayed (bod navázání PROFILU)
                    li.getVideoInfoTag().setResumePoint(float(badge["position"]), float(badge["duration"]))
                except Exception:
                    pass
            lst.addItem(li)
            self._eps_meta[no] = {"overview": overview, "still_path": still}
        uc.focus_first(self, [_LIST])

    def _fetch_failed(self, exc) -> None:
        _log(f"fetch: {exc}", xbmc.LOGWARNING)
        self.setProperty("rm_ep_sub", "Načtení se nepodařilo — zkontroluj připojení.")

    # ------------------------------------------------------------------ input
    def onClick(self, controlId: int) -> None:
        if controlId == 9000:  # ‹ Zpět — z epizod na sezóny, ze sezón zavřít
            if self._level == "episodes":
                self._load_seasons()
            else:
                self.close()
            return
        if controlId != _LIST:
            return
        try:
            li = self.getControl(_LIST).getSelectedItem()
            if not li:
                return
            kind = li.getProperty("rm_kind")
            if kind == "season":
                self._load_episodes(int(li.getProperty("rm_season") or 1))
            elif kind == "episode":
                self._play_episode_picker_first(li)
        except Exception as exc:
            uc.notify_error("Akce se nepodařila spustit.", log_tag="Episodes")
            _log(f"onClick: {exc}", xbmc.LOGWARNING)

    def _play_episode_picker_first(self, li) -> None:
        """Okamžitá odezva: picker se otevře HNED, tv_play search běží na pozadí (SSOT helper)."""
        ep_no = li.getProperty("rm_ep")
        try:
            _title = f"{self._tv_name} S{int(self._season):02d}E{int(ep_no or 0):02d}"
        except Exception:
            _title = self._tv_name
        try:
            _meta = self._eps_meta.get(int(ep_no or 0), {})
        except Exception:
            _meta = {}
        uc.play_picker_first(
            xbmcaddon.Addon(_ADDON_ID), action="tv_play",
            poster=self._poster, title=_title,
            kind="tv", still=_meta.get("still_path") or "",
            overview=_meta.get("overview") or "",
            tv_id=self._tv_id, tv_name=self._tv_name,
            season=str(self._season), episode=ep_no,
            ep_title=li.getProperty("rm_name"))

    def on_back(self) -> bool:
        # Dvouúrovňový Back (jediné okno s interní navigací): epizody → sezóny
        # → teprve pak zavřít (řeší uc.RMNavMixin, když vrátíme False).
        if self._level == "episodes":
            try:
                self._load_seasons()  # zpět na sezóny (ne zavřít okno)
                return True
            except Exception:
                pass
        return False

    def on_window_action(self, action) -> None:
        # Back/Stop/device latch řeší uc.RMNavMixin.onAction (Φ1 DRY)
        if action.getId() == xbmcgui.ACTION_CONTEXT_MENU:
            self._context_menu()

    def _context_menu(self) -> None:
        """Toggle ✔ na epizodě; na sezóně hromadná akce „celá sezóna ✔" (P2-1)."""
        try:
            lst = self.getControl(_LIST)
            li = lst.getSelectedItem()
            if not li:
                return
            # SEZÓNA: hromadné označení celé sezóny (P2-1)
            if self._level == "seasons" and li.getProperty("rm_kind") == "season":
                self._season_bulk_watched(int(li.getProperty("rm_season") or 0))
                return
            if self._level != "episodes":
                return
            if li.getProperty("rm_kind") != "episode":
                return
            ep_no = int(li.getProperty("rm_ep") or 0)
            if ep_no <= 0:
                return
            import richmovie_history as hist
            watched = li.getProperty("rm_watched") == "1"
            label = "Odznačit jako zhlédnuté" if watched else (
                "Viděl jsem to ✔" if li.getProperty("rm_ep_state") == "asleep" else "Označit jako zhlédnuté ✔")
            sel = xbmcgui.Dialog().contextmenu([label])
            if sel != 0:
                return
            if watched:
                hist.watched_unmark_episode(tv_id=self._tv_id,
                                            season=self._season, episode=ep_no)
                li.setProperty("rm_watched", "")
                li.setProperty("rm_ep_state", "")
            else:
                # 3.5.149: ruční přepnutí = `manual` (nikdy `unattended`, i kdyby díl
                # předtím přehrál autoplay bez diváka)
                hist.watched_mark_episode(tv_id=self._tv_id, season=self._season,
                                          episode=ep_no, completion=1.0, kind="manual")
                li.setProperty("rm_watched", "1")
                li.setProperty("rm_ep_state", "watched")
        except Exception as exc:
            uc.notify_error("Označení se nepodařilo.", log_tag="Episodes")
            _log(f"context: {exc}", xbmc.LOGWARNING)

    def _season_bulk_watched(self, season_no: int) -> None:
        """P2-1: označit/odznačit celou sezónu jako zhlédnutou (hromadná akce).
        Stáhne počet epizod ze sezóny (TMDb) a označí 1..N."""
        if season_no <= 0:
            return
        try:
            import richmovie_history as hist
            already = hist.watched_set_for_series(self._tv_id)
            season_eps = [e for (s, e) in already if s == season_no]
            sel = xbmcgui.Dialog().contextmenu(
                ["Označit celou sezónu jako zhlédnutou ✔",
                 "Odznačit celou sezónu"])
            if sel < 0:
                return
            tc = self._tmdb()
            eps = []
            try:
                eps = tc.season_details(int(self._tv_id), season_no) if tc else []
            except Exception:
                eps = []
            nums = []
            for e in (eps or []):
                try:
                    nums.append(int(e.get("episode_number") or 0))
                except Exception:
                    continue
            nums = [n for n in nums if n > 0]
            if not nums and season_eps:
                nums = sorted(season_eps)  # fallback: aspoň známé z watched setu
            if sel == 0:
                for n in nums:
                    hist.watched_mark_episode(tv_id=self._tv_id, season=season_no,
                                              episode=n, completion=1.0, kind="manual")
                msg = f"Sezóna {season_no} označena ({len(nums)} epizod) ✔"
            else:
                for n in nums:
                    hist.watched_unmark_episode(tv_id=self._tv_id, season=season_no,
                                                episode=n)
                msg = f"Sezóna {season_no} odznačena"
            _rm_notif(msg, xbmcgui.NOTIFICATION_INFO, 2500, "RichMovie", sound=False)
        except Exception as exc:
            uc.notify_error("Hromadné označení se nepodařilo.", log_tag="Episodes")
            _log(f"season bulk: {exc}", xbmc.LOGWARNING)

    def close(self):  # noqa: A003 — Kodi API jméno
        self._rm_closed = True
        super().close()


def open_episodes(addon, tv_id="", tv_name="") -> None:
    """Otevře custom Episodes okno. Best-effort."""
    try:
        w = RichMovieEpisodesWindow(_XML, addon.getAddonInfo("path"), "default", _RES,
                                    tv_id=tv_id, tv_name=tv_name)
        _nav_id = uc.nav_push("rm_episodes", {"tv_id": tv_id, "tv_name": tv_name})  # Φ1
        try:
            w.doModal()
        finally:
            uc.nav_remove(_nav_id)
        w._rm_closed = True
        del w
    except Exception as exc:
        _log(f"open_episodes: {exc}", xbmc.LOGWARNING)
