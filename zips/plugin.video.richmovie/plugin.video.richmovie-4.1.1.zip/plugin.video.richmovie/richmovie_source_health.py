# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_source_health — vadný soubor = opakovaný konec na stejném místě (3.5.158)
───────────────────────────────────────────────────────────────────────────────
PROČ
  Incident 27.09.2026 (Chromecast ložnice, Lioness S02E08, Fastshare 2160p 1,6 GB):
  soubor končí / je poškozený kolem 36:15. Kodi ohlásil konec souboru v 36:15, auto-resume
  navázal na 36:15 a stream po 5 s skončil znovu (36:14). Čítač pokusů auto-resume žije jen
  v paměti služby a nuluje se po restartu Kodi i po ručním „Pokračovat" — Petra tak
  dostávala stále „Zdroj přerušil stream – navazuji (1/3)" a nabídka jiného streamu po
  vyčerpání pokusů nikdy nepřišla.

PRAVIDLO (SSOT)
  Utnutí sítí nastane pokaždé jinde. Soubor, který na STEJNÉ pozici (± tolerance) skončil
  aspoň dvakrát, je vadný od té pozice — navazovat na totéž místo nemá smysl.
  • Záznam je TRVALÝ (přežije restart Kodi i ruční Pokračovat) a patří ZAŘÍZENÍ
    (kořen dat, ne profil): vadný soubor je vadný pro kohokoli.
  • Vadný ident se NIKDY nefiltruje (filter parity — feedback_addon_release_filter_is_ssot),
    jen jde v pořadí za ostatní, výpis ho označí a Next-Up / auto výběr ho přeskočí, když
    existuje jiná verze.
  • Φ6 (29.09.2026): navázání na pozici, které se ani po `richmovie_start_watch.STALL_OFFER_S`
    neotevře, se počítá jako konec na tom místě (`note_open_stall`) — utnutí + zaseknuté navázání
    rozhodne o vadném souboru hned při prvním pokusu.
  • Čisté funkce (`evaluate`, `rank`) bez Kodi → harness scénář 70. Python 3.8.
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional

try:
    import xbmc as _xbmc
    _LOGINFO, _LOGWARNING = _xbmc.LOGINFO, _xbmc.LOGWARNING
except Exception:  # mimo Kodi (harness)
    _xbmc = None
    _LOGINFO, _LOGWARNING = 1, 2

HEALTH_FILE = "broken_sources.json"   # soubor zařízení (kořen dat)
SCHEMA = 1
MIN_REPEATS = 2                        # kolikrát na stejném místě = vadný soubor
TOLERANCE_MIN_S = 30.0                 # pozice checkpointu je přesná na jednotky sekund
TOLERANCE_PCT = 0.01                   # u dlouhých souborů 1 % délky
EOF_KEEP = 6                           # posledních N konců per ident (stačí na rozhodnutí)
RECORD_TTL_S = 30 * 24 * 3600          # CDN soubor se může opravit / zmizet
MAX_IDENTS = 300                       # strop souboru (nejstarší pryč)
LABEL_PREFIX = "[COLOR FFE06060]⚠ vadný od %s[/COLOR] "


def _log(msg: str, level: int = _LOGINFO) -> None:
    if _xbmc is not None:
        try:
            _xbmc.log("[RichMovie/SourceHealth] " + msg, level)
        except Exception:
            pass


# Φ6 (29.09.2026): jeden formát času pro všechny texty navazování a zdraví zdroje (dřív kopie)
from richmovie_resume import format_time  # noqa: E402  (re-export: `richmovie_source_health.format_time`)


def tolerance_s(duration: float) -> float:
    try:
        d = float(duration or 0)
    except (TypeError, ValueError):
        d = 0.0
    return max(TOLERANCE_MIN_S, d * TOLERANCE_PCT)


# ─────────────────────────────────────────────────────────────────────────────
#  ČISTÉ ROZHODNUTÍ
# ─────────────────────────────────────────────────────────────────────────────
def _clean_eofs(record: Optional[Dict[str, Any]], now: float) -> List[Dict[str, float]]:
    out: List[Dict[str, float]] = []
    for e in (record or {}).get("eofs") or []:
        try:
            pos, ts = float(e.get("pos")), float(e.get("ts"))
        except (TypeError, ValueError, AttributeError):
            continue
        if pos > 0 and 0 <= now - ts <= RECORD_TTL_S:
            out.append({"pos": pos, "ts": ts})
    return out


def evaluate(record: Optional[Dict[str, Any]], position: float, duration: float,
             now: float) -> Dict[str, Any]:
    """Přidá konec souboru na `position` a rozhodne. Vrací NOVÝ záznam
    `{"eofs": [...], "duration": d, "broken_at": pos|None, "ts": now}`.
    Vadný = aspoň `MIN_REPEATS` konců v okně ± tolerance kolem téhož místa; `broken_at` =
    nejnižší pozice v tom shluku (odtud dál soubor nejde)."""
    eofs = _clean_eofs(record, now)
    try:
        pos = float(position or 0)
    except (TypeError, ValueError):
        pos = 0.0
    dur = float(duration or (record or {}).get("duration") or 0)
    if pos > 0:
        eofs.append({"pos": pos, "ts": float(now)})
    eofs = eofs[-EOF_KEEP:]
    tol = tolerance_s(dur)
    broken_at: Optional[float] = None
    for e in eofs:
        cluster = [x["pos"] for x in eofs if abs(x["pos"] - e["pos"]) <= tol]
        if len(cluster) >= MIN_REPEATS:
            low = min(cluster)
            broken_at = low if broken_at is None else min(broken_at, low)
    return {"eofs": eofs, "duration": dur, "broken_at": broken_at, "ts": float(now)}


def broken_at_in(data: Optional[Dict[str, Any]], ident: str, now: float) -> Optional[float]:
    """Pozice, od které je `ident` vadný, nebo None (záznam prošlý / nerozhodnutý)."""
    rec = ((data or {}).get("idents") or {}).get(str(ident or ""))
    if not isinstance(rec, dict):
        return None
    try:
        ts = float(rec.get("ts") or 0)
        at = rec.get("broken_at")
        at = float(at) if at is not None else None
    except (TypeError, ValueError):
        return None
    if at is None or not (0 <= now - ts <= RECORD_TTL_S):
        return None
    return at


def rank(ident: str, broken: Dict[str, float]) -> int:
    """Pořadí pro výběr streamu: 1 = vadný (za ostatní), 0 = v pořádku. Nikdy filtr."""
    return 1 if str(ident or "") in broken else 0


def _prune(idents: Dict[str, Any], now: float) -> Dict[str, Any]:
    live = {}
    for k, v in idents.items():
        try:
            if isinstance(v, dict) and 0 <= now - float(v.get("ts") or 0) <= RECORD_TTL_S:
                live[k] = v
        except (TypeError, ValueError):
            continue
    if len(live) > MAX_IDENTS:
        keep = sorted(live.items(), key=lambda kv: float(kv[1].get("ts") or 0))[-MAX_IDENTS:]
        live = dict(keep)
    return live


# ─────────────────────────────────────────────────────────────────────────────
#  PERSISTENCE (jediný zapisovatel = služba; plugin jen čte)
# ─────────────────────────────────────────────────────────────────────────────
def _path() -> str:
    import richmovie_paths
    return str(richmovie_paths.account_path(HEALTH_FILE))


def _load() -> Dict[str, Any]:
    path = _path()
    if not os.path.isfile(path):
        return {}   # většina zařízení — žádný READ_NO_FILE při každém výpisu
    import richmovie_atomic as _atomic
    data, _state = _atomic.read_json(path, {}, name="broken_sources", expected_type=dict)
    return data if isinstance(data, dict) else {}


def note_unexpected_eof(ident: str, position: float, duration: float,
                        now: Optional[float] = None) -> Optional[float]:
    """Služba po UNEXPECTED_EOF. Vrací pozici, od které je soubor vadný, nebo None.
    Selhání zápisu = None (R2: nic se nepředstírá; auto-resume jede jako dřív)."""
    return _note(ident, position, duration, now, "SOURCE_EOF")


def note_open_stall(ident: str, position: float, duration: float,
                    now: Optional[float] = None) -> Optional[float]:
    """Φ6 (29.09.2026, audit A05 F8): navázání na `position` se ani po `richmovie_start_watch.STALL_OFFER_S`
    neotevřelo. Počítá se jako konec souboru na tom místě — soubor tam nejde přehrát. Navázání po utnutí
    tak rozhodne o vadném souboru už při PRVNÍM pokusu (utnutí + zaseknutí na témže místě), ne až po dalších
    75–90 s a druhém utnutí. Start od začátku (pozice 0) se nepočítá (`evaluate` bere jen pozici > 0).
    Za 60 dní se nad 30 s nespustil žádný zdravý soubor (7/7 = vadné), falešný záznam jen mění pořadí."""
    return _note(ident, position, duration, now, "SOURCE_STALL")


def _note(ident: str, position: float, duration: float, now: Optional[float], tag: str) -> Optional[float]:
    if not ident:
        return None
    now = time.time() if now is None else float(now)
    try:
        import richmovie_atomic as _atomic
        from richmovie_paths import LOCK_STALE_S
        # jediný zapisovatel je služba, zámek hlídá souběh vláken téhož procesu i čtení pluginem
        with _atomic.FileLock(_path() + ".lock", stale_s=LOCK_STALE_S):
            data = _load()
            idents = _prune(dict(data.get("idents") or {}), now)
            rec = evaluate(idents.get(ident), position, duration, now)
            idents[ident] = rec
            ok = bool(_atomic.write_json(_path(), {"schema": SCHEMA, "idents": idents}))
        at = rec.get("broken_at")
        _log("%s ident=%s pos=%s repeats=%d broken_at=%s saved=%s" % (
            tag, ident, format_time(position), len(rec["eofs"]),
            format_time(at) if at is not None else "-", ok),
            _LOGWARNING if at is not None else _LOGINFO)
        return at if ok else None
    except Exception as exc:
        _log("%s failed: %r" % (tag, exc), _LOGWARNING)
        return None


def broken_map(now: Optional[float] = None) -> Dict[str, float]:
    """{ident: broken_at} všech živých vadných souborů (plugin: pořadí a popisek výpisu)."""
    now = time.time() if now is None else float(now)
    try:
        data = _load()
    except Exception:
        return {}
    out: Dict[str, float] = {}
    for ident in (data.get("idents") or {}):
        at = broken_at_in(data, ident, now)
        if at is not None:
            out[ident] = at
    return out


def label_prefix(ident: str, broken: Dict[str, float]) -> str:
    at = broken.get(str(ident or ""))
    return (LABEL_PREFIX % format_time(at)) if at is not None else ""
