# -*- coding: utf-8 -*-
"""
richmovie_sktorrent  –  Gate-only client pro SkTorrent (SkTonline)
===================================================================

~49 000 videí (filmy, seriály, dokumenty) v CZ/SK dabingu a titulcích.
Streamy jsou direct MP4 URL bez DRM/autentizace (BYOC — klient ↔ CDN,
Gate se bytes nedotýká).

Scraping probíhá **výhradně na Gate NAS** (`/v1/sources/sktorrent/*`).
Addon drží pouze orchestraci + statické metadata (CATEGORIES, parse_title).
Při Gate nedostupnosti/chybě vyhodíme `SkTorrentError` — plugin.py to
chytá v try/except a zobrazí modal. Žádný legacy direct-scrape fallback.

Veřejné API
-----------
get_categories()                      → list[dict]      (statická data)
search(query, page=1)                 → (items, has_next)
browse(category_slug, page=1, sort=…) → (items, has_next)
resolve(video_id)                     → dict  (streams, subtitles, metadata)
parse_title(raw)                      → dict  (offline parser SkTorrent titulků)
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

try:
    import xbmc
    _HAS_XBMC = True
except ImportError:
    _HAS_XBMC = False

try:
    import xbmcaddon
    _HAS_XBMCADDON = True
except ImportError:
    _HAS_XBMCADDON = False

from richmovie_gate_transport import GATE_URL as _GATE_URL
from richmovie_gate_transport import get_identity as _gate_get_identity


# ---------------------------------------------------------------------------
#  Constants
# ---------------------------------------------------------------------------

_TIMEOUT = 15

CATEGORIES: list[dict[str, str]] = [
    {"slug": "filmy-cz-sk",                           "name": "Filmy CZ/SK dabing"},
    {"slug": "filmy-cz-sk-titulky",                   "name": "Filmy CZ/SK titulky"},
    {"slug": "serialy-cz-sk",                         "name": "Seriály CZ/SK dabing"},
    {"slug": "serialy-cz-sk-titulky",                 "name": "Seriály CZ/SK titulky"},
    {"slug": "dokumenty-cz-sk-dabing",                "name": "Dokumenty CZ/SK"},
    {"slug": "rozpravky-cz-sk-kreslene-animovane",    "name": "Pohádky / Animované"},
    {"slug": "tv-porady",                              "name": "TV pořady"},
    {"slug": "hudba",                                  "name": "Hudba / Koncerty"},
]


# ---------------------------------------------------------------------------
#  Exception
# ---------------------------------------------------------------------------

class SkTorrentError(Exception):
    """Gate-side SkTorrent operace selhala (transport/auth/upstream).

    Callers v plugin.py to chytají v try/except a zobrazují modal. Žádný
    fallback — fail-fast princip (viz CLAUDE.md, RichMovie 3.4+)."""


# ---------------------------------------------------------------------------
#  Helpers
# ---------------------------------------------------------------------------

# 3.4.x Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log_router = _make_legacy_logger("richmovie.sktorrent", "RichMovie/SkTorrent")
    def _log(msg: str) -> None:
        _log_router(msg)
except Exception:
    def _log(msg: str) -> None:
        if _HAS_XBMC:
            xbmc.log(f"[RichMovie/SkTorrent] {msg}", xbmc.LOGINFO)


def _gate_get(path: str, params: dict | None = None) -> dict:
    """GET /v1/sources/sktorrent/* via Gate proxy. Fail-fast.

    Raises SkTorrentError on any failure (transport, auth missing, non-200,
    bad JSON, non-ok status). Returns parsed dict on success.
    """
    try:
        ws_username, ws_proof = _gate_get_identity()
    except Exception as exc:
        raise SkTorrentError(
            f"Chybí RichMovie Gate identita: {exc}"
        ) from exc
    if not ws_username or not ws_proof:
        raise SkTorrentError(
            "RichMovie Gate identita není nakonfigurovaná "
            "(chybí Webshare login v nastavení)."
        )

    qs = urllib.parse.urlencode(params) if params else ""
    url = f"{_GATE_URL}{path}" + (f"?{qs}" if qs else "")

    try:
        _av = xbmcaddon.Addon().getAddonInfo("version") if _HAS_XBMCADDON else "dev"
    except Exception:
        _av = "dev"
    headers = {
        "User-Agent": f"RichMovie/{_av} (+plugin.video.richmovie)",
        "Accept": "application/json",
        "X-WS-Username": ws_username,
        "X-WS-Proof": ws_proof,
    }

    # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. Všechny cesty tohohle
    # klienta jsou GET (search/detail), tedy bezpečně opakovatelné.
    try:
        import richmovie_http as _rm_http
    except Exception as _imp_exc:  # pragma: no cover
        raise SkTorrentError("richmovie_http neni k dispozici") from _imp_exc

    try:
        profile = _rm_http.profile_foreground().replace(timeout_s=float(_TIMEOUT))
        status, body, _hdrs = _rm_http.request(
            url, headers=headers, profile=profile, tag="sktorrent",
        )
        if status != 200:
            raise SkTorrentError(f"Gate {path} vrátil HTTP {status}.")
    except SkTorrentError:
        raise
    except _rm_http.TransientError as exc:
        raise SkTorrentError(f"Nelze se připojit k RichMovie Gate: {exc}") from exc
    except Exception as exc:
        raise SkTorrentError(f"Gate fetch error: {exc}") from exc

    try:
        data = json.loads(body.decode("utf-8", errors="replace"))
    except Exception as exc:
        raise SkTorrentError(
            f"Gate {path} vrátil nevalidní JSON: {exc}"
        ) from exc

    if not isinstance(data, dict):
        raise SkTorrentError(
            f"Gate {path} vrátil nečekaný typ odpovědi: {type(data).__name__}"
        )
    if data.get("status") != "ok":
        err = data.get("error") or {}
        msg = err.get("message") if isinstance(err, dict) else str(err)
        raise SkTorrentError(msg or f"Gate {path} vrátil status={data.get('status')!r}")
    return data


# ---------------------------------------------------------------------------
#  Offline helpers (žádný HTTP — SKTorrent title parser)
# ---------------------------------------------------------------------------

def parse_title(raw: str) -> dict[str, str]:
    """Rozloží SkTorrent titulek na části. Čistě offline string operace.

    Vstupní formáty:
      "Anakonda /  Anaconda (2025)(CZ)"
      "Avatar: Legenda o Aangovi / Avatar: The Last Airbender S01E08 (CZ)"
      "Galaxy Quest (1999)(CZ)"

    Vrací dict: title_cs, title_en, year, lang, season, episode.
    """
    s = raw.strip()

    lang = ""
    m_lang = re.search(r"\(([A-Z]{2})\)\s*$", s)
    if m_lang:
        lang = m_lang.group(1)
        s = s[:m_lang.start()].strip()

    year = ""
    m_year = re.search(r"\((\d{4})\)\s*$", s)
    if m_year:
        year = m_year.group(1)
        s = s[:m_year.start()].strip()

    season = ""
    episode = ""
    m_se = re.search(r"S(\d+)E(\d+)", s, re.IGNORECASE)
    if m_se:
        season = m_se.group(1)
        episode = m_se.group(2)

    title_cs = s
    title_en = ""
    parts = re.split(r"\s*/\s*", s, maxsplit=1)
    if len(parts) == 2 and len(parts[0]) > 1 and len(parts[1]) > 1:
        title_cs = parts[0].strip()
        title_en = parts[1].strip()
        if m_se:
            title_en = re.sub(r"\s*S\d+E\d+\b", "", title_en).strip()

    return {
        "title_cs": title_cs,
        "title_en": title_en,
        "year": year,
        "lang": lang,
        "season": season,
        "episode": episode,
    }


# ---------------------------------------------------------------------------
#  Public API (Gate-only)
# ---------------------------------------------------------------------------

def get_categories() -> list[dict[str, str]]:
    """Statický seznam kategorií (beze změn napříč Gate reload)."""
    return list(CATEGORIES)


def search(query: str, page: int = 1) -> tuple[list[dict[str, Any]], bool]:
    """Hledání na SkTorrent via Gate. Raises SkTorrentError na selhání."""
    data = _gate_get("/v1/sources/sktorrent/search", {"q": query, "page": page})
    items = data.get("items") or []
    has_next = bool(data.get("has_next"))
    _log(f"search: {query!r} page={page} → {len(items)} items")
    return items, has_next


def browse(category_slug: str, page: int = 1,
           sort: str = "mr") -> tuple[list[dict[str, Any]], bool]:
    """Procházení kategorie via Gate. Raises SkTorrentError na selhání.

    sort: mr=nejnovější, mv=nejsledovanější, tr=nejlépe hodnocené,
          bw=právě sledované, lg=nejdelší.
    """
    data = _gate_get(
        "/v1/sources/sktorrent/browse",
        {"slug": category_slug, "page": page, "sort": sort},
    )
    items = data.get("items") or []
    has_next = bool(data.get("has_next"))
    _log(f"browse: {category_slug} page={page} sort={sort} → {len(items)} items")
    return items, has_next


def resolve(video_id: str) -> dict[str, Any]:
    """Resolve video detail via Gate. Raises SkTorrentError na selhání.

    Returns dict:
        title, description, poster,
        streams:   [{url, quality, height}],
        subtitles: [{url, label}],
        duration:  float (seconds)

    Stream URLs jsou direct MP4 na CDN — BYOC streaming (klient↔CDN bez Gate).
    """
    data = _gate_get(
        f"/v1/sources/sktorrent/resolve/{urllib.parse.quote(video_id, safe='')}"
    )
    streams = data.get("streams") or []
    subs = data.get("subtitles") or []
    _log(f"resolve: {video_id} → {len(streams)} streams, {len(subs)} subs")
    return {
        "title":       data.get("title", f"Video {video_id}"),
        "description": data.get("description", ""),
        "poster":      data.get("poster", ""),
        "streams":     streams,
        "subtitles":   subs,
        "duration":    float(data.get("duration") or 0.0),
    }
