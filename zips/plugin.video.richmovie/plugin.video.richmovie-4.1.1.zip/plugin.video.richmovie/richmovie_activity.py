# -*- coding: utf-8 -*-
"""RichMovie — „uživatel právě kliká“: ohleduplná práce na pozadí (Φ4, 29.09.2026, audit A08 F5/F6).

PROČ EXISTUJE
-------------
Kodi 21 pouští všechny interprety (klik v pluginu, služba, vlákna) v JEDNOM procesu s jedním GIL
(Python 3.8, `PythonInvoker.cpp:163–181`). Když zrovna běží warm-up TMDb, instalátor kolekcí nebo
odesílání logu, import pluginu po kliknutí trvá 1 133 ms místo 410 ms (medián, PC) a start interpretu
128–213 ms místo 15 ms. Pád 29.09. 12:59 se stal přesně ve chvíli, kdy warm-up běžel přes oba kliky
na „Pokračovat“. Do 3.5.162 pozadí o uživateli nevědělo nic (jediné brzdy: obnova menu D11 a
auto-resume).

KONTRAKT
--------
    token = note_invocation_begin()     # plugin `main` (každá akce)
    note_invocation_end(token)          # plugin `main` ve finally
    should_yield()  → (bool, důvod)     # čisté rozhodnutí podle značky a nečinnosti Kodi
    wait_while_busy(monitor)            # pozadí: před krokem počká, nejvýš `YIELD_MAX_S`

Uživatel „pracuje“, když běží invokace pluginu (značka ne starší než `YIELD_MAX_S`), nebo když
v posledních `USER_ACTIVE_IDLE_S` sekundách sáhl na ovladač (`getGlobalIdleTime`). Přehrávání samo
o sobě pozadí NEbrzdí (divák nemačká nic). Realtime kanály (long-poll stavu, handoff) se neptají.

Python 3.8 (Kodi runtime).
"""
from __future__ import annotations

import time
import uuid
from typing import Any, Optional, Tuple

from richmovie_winprops import clear_prop as _clear_prop
from richmovie_winprops import get_prop as _get_prop
from richmovie_winprops import set_prop as _set_prop

try:  # pragma: no cover - mimo Kodi (harness má stuby)
    import xbmc
except ImportError:  # pragma: no cover
    xbmc = None  # type: ignore

PROP_INVOCATION = "richmovie.ui.invocation"   # "<token>|<monotonic začátku>" (monotonic sdílí celý proces Kodi)

# Hranice „uživatel právě pracuje s ovladačem“ (3 s = rozhodnutí D3 13.09.2026 pro samovolnou obnovu menu D11).
# SSOT: rozhoduje `should_yield` pro bránu programového refreshe z pozadí (`richmovie_playback_dispatch.probe_refresh(
# background=True)`) — tou od 4.0.4 (S18) prochází i samovolná obnova menu D11 přes frontu obnov výpisu.
USER_ACTIVE_IDLE_S = 3.0
# Strop jednoho odkladu i stáří značky invokace: p90 nejdelší interaktivní akce za 30 dní (díl → seznam
# streamů 83,2 s, audit A03 §9), zaokrouhleno nahoru. Delší čekání = vyhladovění pozadí; delší značka =
# sirotek po nativním pádu interpretu.
YIELD_MAX_S = 90.0
# Krok čekání pozadí: po konci kliknutí se práce rozjede nejvýš 0,5 s pozdě (pod `USER_ACTIVE_IDLE_S`), a
# `waitForAbort` zároveň drží 5s okno Kodi na ukončení.
YIELD_TICK_S = 0.5


def note_invocation_begin() -> str:
    token = uuid.uuid4().hex[:12]
    _set_prop(PROP_INVOCATION, "%s|%r" % (token, time.monotonic()))
    return token


def note_invocation_end(token: str) -> None:
    """Smaže značku jen její vlastník (souběžné invokace: značku drží ta pozdější)."""
    parts = _get_prop(PROP_INVOCATION, "").split("|")
    if len(parts) == 2 and parts[0] == token:
        _clear_prop(PROP_INVOCATION)


def invocation_running(now_monotonic: Optional[float] = None) -> bool:
    parts = _get_prop(PROP_INVOCATION, "").split("|")
    if len(parts) != 2:
        return False
    try:
        began = float(parts[1])
    except ValueError:
        return False
    now = time.monotonic() if now_monotonic is None else float(now_monotonic)
    return 0.0 <= now - began < YIELD_MAX_S


def _idle_s() -> float:
    try:
        return float(xbmc.getGlobalIdleTime() or 0) if xbmc is not None else 1e9
    except Exception:
        return 1e9


def should_yield(*, now_monotonic: Optional[float] = None, idle_s: Optional[float] = None) -> Tuple[bool, str]:
    """Má práce na pozadí teď ustoupit? (čisté vůči vstupům; bez nich čte stav Kodi)"""
    if invocation_running(now_monotonic):
        return True, "invocation"
    idle = _idle_s() if idle_s is None else float(idle_s)
    if idle < USER_ACTIVE_IDLE_S:
        return True, "user_active"
    return False, ""


def wait_while_busy(monitor: Any, *, max_wait_s: float = YIELD_MAX_S) -> bool:
    """Počká, dokud uživatel pracuje (nejvýš `max_wait_s`). Vrací False, když Kodi končí (abort)."""
    started = time.monotonic()
    while True:
        busy, _why = should_yield()
        if not busy or (time.monotonic() - started) >= max_wait_s:
            return True
        if monitor.waitForAbort(YIELD_TICK_S):
            return False
