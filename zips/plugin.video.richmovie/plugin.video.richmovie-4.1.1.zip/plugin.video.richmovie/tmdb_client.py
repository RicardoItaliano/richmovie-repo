# -*- coding: utf-8 -*-
"""Lehký TMDb klient (API v3) – hledání filmů, detail a alternativní stopáže."""

from __future__ import annotations        # → typové anotace jako str (Py 3.8)

# ──────────────  STANDARD LIBRARY  ──────────────
import json
import os
import re
import sqlite3
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.83): NAS-routovaný diagnosticky logger
# pro dřív TICHÁ except místa (EN fallback detail, texture DB introspekce).
# Event logger self._log (plugin _log_event, per-search soubor) NEDOTČEN.
# Fallback = no-op (klient nesmí spadnout kvůli diagnostice).
try:
    from richmovie_logging import make_legacy_logger as _tmdb_make_legacy_logger
    _diag_log = _tmdb_make_legacy_logger("richmovie.tmdb", "RichMovie/TMDb")
except Exception:
    def _diag_log(msg, level=1, *, context=None):
        pass
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# Φ0 network resilience (2026-08-08): SSOT klasifikace síťových chyb. Do dneška
# TMDb transport neposílal do NAS pipeline NIC — za 14 dní bylo v `user_logs`
# 0 záznamů se `source='richmovie.tmdb'` a řetězec „Errno 101" se v tabulce
# nevyskytoval ani jednou, přestože uživateli vyskočil modální dialog
# (incident Chromecast 08.08.2026). Bez tohohle napojení nemáme jak měřit,
# jestli zbytek opravy zabral.
# Fallback = None → logujeme aspoň holý text (klient nesmí spadnout kvůli diagnostice).
# ---------------------------------------------------------------------------
try:
    import richmovie_http as _rm_http
except Exception:  # pragma: no cover
    _rm_http = None  # type: ignore

# ──────────────  KODI API  ──────────────
# (pouze pro čtení Textures DB / Thumbnails – kvůli reportu velikostí)
import xbmcvfs

# (abort-safe detekce platformy + rychlé ukončení při rušení invokeru)
try:
    import xbmc  # type: ignore
except Exception:  # pragma: no cover
    xbmc = None  # type: ignore

# 2026-04-19 bugfix: User-Agent header v Gate requestu. Bez toho Cloudflare
# bot-fight-mode blokuje Python-urllib default UA s HTTP 403 error code 1010.
try:
    import xbmcaddon  # type: ignore
except Exception:  # pragma: no cover
    xbmcaddon = None  # type: ignore


# ───────────────────  VÝJIMKY  ──────────────────
class TMDbError(RuntimeError):
    """Chyba při komunikaci s TMDb."""


class TMDbTransientError(TMDbError):
    """Přechodná síťová chyba — volající SMÍ degradovat na expirovanou cache.

    Φ4 (2026-08-08). Podtřída `TMDbError` schválně: veškerý existující kód, který
    chytá `except TMDbError`, ji odbaví beze změny. Rozdíl je jen v tom, že metody
    s diskovou cache si podle ní můžou dovolit vrátit stará data místo chyby —
    film z roku 2016 se za 31 dní nezměnil a vyhodit kvůli tomu uživateli dialog
    je nesmysl.

    Trvalé chyby (403 identity, 404, nevalidní JSON) tuhle třídu NEDOSTANOU:
    tam by stará data zakrývala skutečný problém.
    """


class TMDbAuthError(TMDbError):
    """Gate autoritativně odmítl IDENTITU (401/403 s JSON kódem proof_mismatch,
    not_authorized, inactive…), nebo je identita už zamítnutá a volání selhalo
    lokálně bez sítě (fail-fast).

    3.5.118 (2026-08-21). Podtřída `TMDbError` — stávající `except TMDbError`
    odbaví beze změny. Rozdíl proti obecné `TMDbError("Status 403")`: volající
    s negativní cache (instalátor kolekcí, MI2) podle ní poznají, že výsledek
    NENÍ vlastnost titulu/souboru a NESMÍ se perzistovat jako „neexistuje".
    Cloudflare HTML 403 (bez Gate JSON) tuhle třídu NEDOSTANE — zůstává obecnou
    `TMDbError`, protože o identitě nic neříká.
    """


class TMDbNotFoundError(TMDbError):
    """HTTP 404 — AUTORITATIVNÍ odpověď zdroje pravdy „tohle neexistuje".

    3.5.118 (2026-08-21). Jediný druh selhání, který smí negativní cache
    perzistovat (R2 plánu): titul/sezóna na TMDb není a další pokus to nezmění.
    Všechno ostatní (transport, 5xx, 429, identita) je stav infrastruktury.
    """


# ---------------------------------- FUNKCE ---------------------------------- #
# tmdb_client.py
# _err_context  (vytvořeno: 08.08.2026 10:45 CEST, Europe/Prague – Φ0 observability)
# ---------------------------------------------------------------------------- #
def _err_context(exc, http_status=None, **extra):
    # type: (Optional[BaseException], Optional[int], Any) -> Dict[str, Any]
    """Sestaví `context` dict pro routovaný log (JSONB v `user_logs` na Gate).

    Proč přes `richmovie_http.describe_error()` a ne ručně na každém call-site:
    klasifikace síťových chyb je SSOT jednoho modulu. Kdyby si ji tenhle soubor
    dělal po svém, za půl roku se rozejde s retry logikou a začneme retryovat
    něco jiného, než co hlásíme do logu.

    Fallback (chybí `richmovie_http`) degraduje na holý typ + text — pořád lepší
    než dnešní stav, kdy do NAS pipeline neteklo vůbec nic.

    Args:
        exc:         Zachycená výjimka.
        http_status: HTTP kód, pokud je znám.
        **extra:     Doplňkové klíče (path, attempt, elapsed_ms, timeout_s …).

    Returns:
        Dict vhodný pro `_diag_log(..., context=...)`. Nikdy nevyhodí výjimku.
    """
    ctx = {}  # type: Dict[str, Any]
    try:
        if _rm_http is not None:
            ctx.update(_rm_http.describe_error(exc, http_status=http_status))
        else:
            ctx.update({
                "err_class": "unknown",
                "err_type": type(exc).__name__ if exc is not None else None,
                "errno": None,
                "http_status": http_status,
                "err_text": (str(exc) if exc is not None else "")[:200],
            })
    except Exception:
        # Diagnostika nesmí NIKDY přebít původní chybu (viz richmovie_logging).
        ctx = {"err_class": "unknown", "err_text": "<popis chyby selhal>"}
    try:
        ctx.update(extra)
    except Exception:
        pass
    return ctx




# 2026-04-19 Phase 3g: thin Gate-proxy transport. All network calls go through
# https://gate.svcnode.org/v1/tmdb/* (crowd-shared cache). Client-side rate
# limit is kept as a defensive throttle but in practice the Gate handles
# TMDb rate-limiting for all 16 users.
try:
    from richmovie_gate_transport import GATE_URL as _GATE_URL
    from richmovie_gate_transport import get_identity as _gate_get_identity
    from richmovie_gate_transport import get_device_hash as _gate_get_device_hash
    _GATE_AVAILABLE = True
except Exception:
    _GATE_URL = "https://gate.svcnode.org"
    _GATE_AVAILABLE = False
    _gate_get_identity = None  # type: ignore
    _gate_get_device_hash = None  # type: ignore

# 3.5.118 (2026-08-21): SSOT stavu identity. Best-effort import — bez něj se
# chová `_get_json` jako do 3.5.117 (403 = obecná TMDbError, žádný fail-fast).
try:
    import richmovie_identity_state as _identity
except Exception:  # pragma: no cover
    _identity = None  # type: ignore


# ───────────────────  KLIENT  ────────────────────
class TMDb:
    """Minimalistický wrapper kolem TMDb API v3 (JSON).

    Phase 3g (2026-04-19): všechna volání TMDb běží přes RichMovie Gate na
    NASu jako SkyHook proxy. Addon nikdy nevolá api.themoviedb.org přímo —
    Gate drží TMDb klíč a sdílí cache napříč 16 uživateli. Původní
    ``BASE_URL`` zůstává jen kvůli legacy kompatibilitě (někteří callers
    loggují URL).
    """

    # Gate proxy path prefix. Direct TMDb BASE_URL still referenced by some
    # log messages as the "upstream" we point to, but we never hit it from
    # the client.
    BASE_URL = "https://api.themoviedb.org/3"
    GATE_PROXY_PREFIX = "/v1/tmdb"

    # Sdílené zámky – inicializovány na úrovni třídy (thread-safe, bez race condition)
    _CACHE_LOCK = threading.Lock()
    _RL_LOCK    = threading.Lock()

    # ── Client-side 429 circuit breaker (SSOT, 2026-07-12) ──────────────────────
    # Incident: sdílený účet richiefm dostal od Gate 429 ("Too many requests"),
    # a addon 429 dotazy OPAKOVAL → 1 dotaz zesílen na ~1900 requestů, což Gate
    # kýbl drželo vyčerpaný. Gate-side fix (upstream limiter) je hlavní oprava;
    # tohle je defense-in-depth NA STRANĚ ADDONU: jakmile Gate vrátí 429, klient
    # se globálně (napříč vlákny) uspí do `Retry-After` a KAŽDÝ další TMDb call
    # během cooldownu selže LOKÁLNĚ (bez sítě) → storm se ke Gate vůbec nedostane.
    # Chrání SSOT: jediný chokepoint `_get_json` → platí pro všechny volající
    # (search, detaily, kolekce, enrichment) bez nutnosti hlídat každou smyčku.
    _RL_COOLDOWN_UNTIL     = 0.0    # time.monotonic(), do kdy fail-fast
    _RL_COOLDOWN_DEFAULT_S = 30.0   # když 429 nemá Retry-After hlavičku
    _RL_COOLDOWN_MAX_S     = 120.0  # strop, ať se nezasekneme na absurdní Retry-After

    # ── Stale-first degradace (Φ4, 2026-08-08) ──────────────────────────────────
    # Jak stará data smí addon při výpadku sítě ukázat místo chybové hlášky.
    # 180 dní je kompromis: metadata filmů jsou prakticky neměnná (název, rok,
    # stopáž, obsazení), takže půl roku stará odpověď je pro uživatele k nerozeznání
    # od čerstvé — a rozhodně lepší než prázdná obrazovka na hotelové Wi-Fi.
    # Zároveň je to strop, aby zařízení po půl roce v šuplíku nezačalo servírovat
    # dávno neplatný obsah jako aktuální.
    # Hodnota řídí i úklid cache v `_cache_get()` — expirované záznamy se do téhle
    # hranice nechávají ležet právě proto, aby měla degradace z čeho brát.
    STALE_MAX_AGE_S = 180 * 24 * 3600
    # Φ5A (29.09.2026): TTL dat, která se u vydaného filmu prakticky nemění (termíny vydání, kolekce) —
    # stejné jako detail filmu (`details`: 30 dní).
    STATIC_META_TTL_S = 30 * 24 * 3600



    #  2025-08-16 09:24 CEST (Europe/Prague)
    def __init__(
        self,
        api_key: str,
        lang: str = "cs-CZ",
        *,
        logger: Optional[Callable[..., None]] = None,
    ):
        """
        Minimalistický wrapper na TMDb API.

        Novinky 07/2025
        ----------------
        • volitelný `logger` – funkce se signaturou `fn(event, *params)`
          (v RichMovie předáváme `plugin._log_event`)
        • pokud není předán, pokusí se najít `plugin._log_event` dynamicky;
          jinak použije „tichou" lambda – žádné další importy nejsou nutné

        Novinka 08/2025
        ----------------
        • interní **disková cache TMDb odpovědí** (JSON) pro šetření API:
          vybrané metody (`search`, `search_tv`, `episode_details`, `tv_details`)
          čtou/zapisují do souboru `tmdb_meta_cache.json` v profilu doplňku.
        """
        # Phase 3g (2026-04-19): api_key is no longer required — Gate holds
        # the canonical TMDb key server-side (SkyHook model). Accept empty
        # value so addon works before /auth lease populates the cached key
        # (and long-term for users who get no key back from Gate at all).
        self.api_key = api_key or ""
        self.lang    = lang

        # – auto‑detekce loggeru –
        if logger is None:
            # Φ4 (29.09.2026): SSOT registr událostního logu místo `import plugin` (A08 F7 — dřív se
            # tím celé tělo plugin.py vykonalo v invokaci znovu a přepsalo callbacky)
            try:
                import richmovie_event_log as _rm_event_log
                logger = _rm_event_log.log_event if _rm_event_log.registered() else None
            except Exception:
                logger = None
        self._log = logger or (lambda *_, **__: None)

        # – inicializace sdílené JSON cache (jen jednou na proces) –
        if not hasattr(TMDb, "_CACHE_PATH"):
            cache_dir: Optional[Path] = None
            try:
                import richmovie_paths   # kořen dat doplňku (= dřívější plugin.PROFILE_DIR), Φ4
                cache_dir = Path(str(richmovie_paths.addon_data_dir()))
            except Exception:
                cache_dir = None
            if cache_dir is None:
                # Fallback: ~/.richmovie/
                cache_dir = Path(os.path.expanduser("~/.richmovie"))
            try:
                cache_dir.mkdir(parents=True, exist_ok=True)
            except Exception:
                # Poslední záchrana: aktuální pracovní adresář
                cache_dir = Path(os.getcwd())
                try:
                    cache_dir.mkdir(parents=True, exist_ok=True)
                except Exception:
                    pass
            TMDb._CACHE_PATH = cache_dir / "tmdb_meta_cache.json"

        if not hasattr(TMDb, "_CACHE"):
            # Načti existující cache (tiše ignoruj poškozené)
            data: Dict[str, Any] = {}
            try:
                if TMDb._CACHE_PATH.exists():
                    text = TMDb._CACHE_PATH.read_text("utf-8")
                    data = json.loads(text) if text else {}
            except Exception as e:
                self._log("TMDB_CACHE_LOAD_ERR", str(e))
                data = {}
            TMDb._CACHE = data





    #  2025-08-16 09:24 CEST (Europe/Prague)
    def _cache_get(self, key: str, ttl_seconds: int) -> Optional[Any]:
        """
        Vrátí uložená data z interní TMDb JSON cache, pokud **nevypršel TTL**.

        - `key`        – logický klíč (např. "search:movie:cs-CZ:matrix:10")
        - `ttl_seconds`– doba platnosti v sekundách
        """
        try:
            with TMDb._CACHE_LOCK:
                entry = TMDb._CACHE.get(key)
                if not entry:
                    return None
                ts = float(entry.get("ts") or 0)
                age = time.time() - ts
                if age > max(0, int(ttl_seconds)):
                    # Φ4 (2026-08-08): expirovaný záznam se NEMAŽE hned.
                    # Do `STALE_MAX_AGE_S` slouží jako záchranná síť pro offline
                    # režim (`_cache_get_stale`) — dřív ho tenhle řádek zahodil
                    # při prvním čtení, takže by degradace neměla z čeho čerpat.
                    # Úklid se tím neztrácí, jen posouvá: co je starší než strop,
                    # je bezcenné a letí ven.
                    if age > TMDb.STALE_MAX_AGE_S:
                        TMDb._CACHE.pop(key, None)
                    return None
                data = entry.get("data", None)
                if data is not None:
                    self._log("TMDB_CACHE_HIT", key)
                return data
        except Exception as e:
            self._log("TMDB_CACHE_ERR", f"get: {e}")
            return None




    # ---------------------------------------------------------------------------- #
    # tmdb_client.py › class TMDb
    # _cache_get_stale  (vytvořeno: 08.08.2026 12:35 CEST, Europe/Prague – Φ4)
    # ---------------------------------------------------------------------------- #
    def _cache_get_stale(self, key: str) -> Optional[Any]:
        """Vrátí i **expirovaný** záznam z cache — poslední záchrana při výpadku sítě.

        Volá se VÝHRADNĚ z `except TMDbTransientError` větví. Smysl: film z roku
        2016 se za 31 dní nezměnil, takže vyhodit uživateli dialog jen proto, že
        vypršelo TTL a zrovna nejede Wi-Fi, je nesmysl. Lepší je ukázat data
        o den (nebo o měsíc) starší.

        Strop `STALE_MAX_AGE_S` je pojistka proti tomu, aby addon po půl roce
        v šuplíku ukazoval dávno neplatná data jako čerstvá.

        Returns:
            Uložená data, nebo None (žádný záznam / starší než strop).
        """
        try:
            with TMDb._CACHE_LOCK:
                entry = TMDb._CACHE.get(key)
                if not entry:
                    return None
                ts = float(entry.get("ts") or 0)
                age = time.time() - ts
                if age > TMDb.STALE_MAX_AGE_S:
                    return None
                return entry.get("data", None)
        except Exception as e:
            self._log("TMDB_CACHE_ERR", f"get_stale: {e}")
            return None




    # ---------------------------------------------------------------------------- #
    # tmdb_client.py › class TMDb
    # _serve_stale  (vytvořeno: 08.08.2026 12:35 CEST, Europe/Prague – Φ4)
    # ---------------------------------------------------------------------------- #
    def _serve_stale(self, key: str, what: str, validator=None) -> Optional[Any]:
        """Zkusí degradovat na expirovanou cache a zaloguje to.

        Jedno místo pro celou degradaci — kdyby si každá metoda dělala vlastní,
        rozešly by se guardy (a přesně jeden chybějící guard stačil k „Lost"
        incidentu 30.04.2026).

        Args:
            key:       Klíč v TMDb cache.
            what:      Popis pro log (`movie_details`, `search` …).
            validator: Volitelná funkce `data -> bool`. Když vrátí False, stará
                       data se NEPOUŽIJÍ. Tady se hlídá partial-detail guard.

        Returns:
            Data k použití, nebo None (nechť volající vyhodí původní chybu).
        """
        data = self._cache_get_stale(key)
        if data is None:
            return None
        if validator is not None:
            try:
                if not validator(data):
                    return None
            except Exception:
                return None

        age_days = None
        try:
            with TMDb._CACHE_LOCK:
                entry = TMDb._CACHE.get(key) or {}
            ts = float(entry.get("ts") or 0)
            if ts:
                age_days = round((time.time() - ts) / 86400.0, 1)
        except Exception:
            age_days = None

        self._log("TMDB_STALE_SERVED", what, key, age_days)
        _diag_log(
            "TMDB_STALE_SERVED %s age=%s d" % (what, age_days),
            xbmc.LOGINFO if xbmc else 1,
            context={"what": what, "cache_key": key, "age_days": age_days,
                     "err_class": "transient", "degraded": True},
        )
        return data




    #  21.12.2025 17:58 CET (Europe/Prague)
    def _cache_set(self, key: str, data: Any) -> None:
        """
        21.12.2025 17:58 CET (Europe/Prague)

        Uloží data do interní TMDb JSON cache.

        FÁZE 2 – výkon/IO (debounce):
          • Původně se při každém setu přepsal celý `tmdb_meta_cache.json`.
            Při více voláních za sebou (search → details → alt titles → runtimes…) to zbytečně
            zatěžovalo disk a v Kodi to umí dělat mikro-lagy.
          • NOVĚ:
              - cache se vždy aktualizuje v RAM (okamžitě)
              - diskový zápis je **debouncovaný**
              - pokud se hodnota pro klíč reálně nezměnila, diskový zápis se přeskočí

        Poznámka:
          • Zápis je pořád atomický (tmp → replace).
          • Log `TMDB_CACHE_SAVE` se vypisuje pouze při skutečném zápisu na disk.
        """
        try:
            with TMDb._CACHE_LOCK:
                # lazy init (abychom nemuseli sahat do __init__)
                if not hasattr(TMDb, "_CACHE_DIRTY"):
                    TMDb._CACHE_DIRTY = False
                    TMDb._CACHE_DIRTY_COUNT = 0
                    TMDb._CACHE_LAST_FLUSH = 0.0

                    # konzervativní debounce: chceme výrazně snížit počet zápisů,
                    # ale zároveň skoro vždy stihnout flush ještě v rámci jednoho invokeru
                    TMDb._CACHE_FLUSH_MIN_INTERVAL = 0.8   # sekundy
                    TMDb._CACHE_FLUSH_EVERY_N = 12         # změn

                # porovnej, jestli se data reálně změnila (kvůli skipu disk zápisu)
                prev = TMDb._CACHE.get(key) if hasattr(TMDb, "_CACHE") else None
                prev_data = None
                try:
                    if isinstance(prev, dict):
                        prev_data = prev.get("data")
                except Exception:
                    prev_data = None

                changed = True
                try:
                    if prev is not None and prev_data == data:
                        changed = False
                except Exception:
                    changed = True

                # update RAM cache (ts vždy aktualizujeme – reprezentuje "kdy jsme to získali")
                TMDb._CACHE[key] = {"ts": time.time(), "data": data}

                # FIX 21.02.2026: prevence unbounded cache growth (OOM na Android/Chromecast)
                _CACHE_MAX = 400
                if len(TMDb._CACHE) > _CACHE_MAX:
                    try:
                        # smazat nejstarsi zaznamy (podle ts)
                        sorted_keys = sorted(
                            TMDb._CACHE,
                            key=lambda k: float((TMDb._CACHE[k] or {}).get("ts", 0) or 0),
                        )
                        for _evict_key in sorted_keys[:len(TMDb._CACHE) - _CACHE_MAX]:
                            TMDb._CACHE.pop(_evict_key, None)
                    except Exception:
                        pass

                # dirty jen pokud se změnila hodnota
                if changed:
                    TMDb._CACHE_DIRTY = True
                    try:
                        TMDb._CACHE_DIRTY_COUNT = int(getattr(TMDb, "_CACHE_DIRTY_COUNT", 0) or 0) + 1
                    except Exception:
                        TMDb._CACHE_DIRTY_COUNT = 1

                # rozhodnutí o flush (debounce)
                do_flush = False
                try:
                    last = float(getattr(TMDb, "_CACHE_LAST_FLUSH", 0.0) or 0.0)
                except Exception:
                    last = 0.0
                try:
                    min_int = float(getattr(TMDb, "_CACHE_FLUSH_MIN_INTERVAL", 0.8) or 0.8)
                except Exception:
                    min_int = 0.8
                try:
                    every_n = int(getattr(TMDb, "_CACHE_FLUSH_EVERY_N", 12) or 12)
                except Exception:
                    every_n = 12
                try:
                    dirty_cnt = int(getattr(TMDb, "_CACHE_DIRTY_COUNT", 0) or 0)
                except Exception:
                    dirty_cnt = 0

                # první zápis (soubor neexistuje) chceme uložit hned
                try:
                    file_exists = bool(TMDb._CACHE_PATH.exists())
                except Exception:
                    file_exists = True

                if not file_exists:
                    do_flush = True
                elif (time.time() - last) >= max(0.0, min_int):
                    do_flush = True
                elif dirty_cnt >= max(1, every_n):
                    do_flush = True

                if do_flush and bool(getattr(TMDb, "_CACHE_DIRTY", False)):
                    path: Path = TMDb._CACHE_PATH
                    tmp = path.with_suffix(".tmp")
                    tmp.write_text(json.dumps(TMDb._CACHE, ensure_ascii=False), "utf-8")
                    try:
                        tmp.replace(path)
                    except Exception:
                        # Windows: pokud replace selže, zkus smazat a přejmenovat
                        try:
                            if path.exists():
                                path.unlink()
                        except Exception:
                            pass
                        tmp.rename(path)

                    TMDb._CACHE_DIRTY = False
                    TMDb._CACHE_DIRTY_COUNT = 0
                    TMDb._CACHE_LAST_FLUSH = time.time()

                    self._log("TMDB_CACHE_SAVE", key)
        except Exception as e:
            self._log("TMDB_CACHE_ERR", f"set: {e}")


    def cache_evict(self, key: str) -> bool:
        """Hard-evict a key from the local TMDb disk cache. Returns True if the
        key was present. Used by callers (e.g. _tv_seasons in plugin.py) when a
        previously-cached partial detail needs to be purged so a retry will
        re-hit the network. Best-effort — never raises.

        Defense-in-depth complement to migration 0006 (Gate side). Even if the
        addon ever locally cached a partial despite tv_details rejecting it,
        this method ensures a clean retry on user-triggered failures.
        """
        try:
            with TMDb._CACHE_LOCK:
                if key in TMDb._CACHE:
                    TMDb._CACHE.pop(key, None)
                    TMDb._CACHE_DIRTY = True
                    self._log("TMDB_CACHE_EVICT", key)
                    return True
        except Exception as e:
            self._log("TMDB_CACHE_ERR", "evict: {}".format(e))
        return False








    # 16-08-2025 08:43 CEST (Europe/Prague)
    def _is_latin_text(self, text: str) -> bool:
        """
        Zjistí, zda text obsahuje alespoň jedno písmeno a všechna písmena
        patří do rozsahu 'LATIN' (včetně české/SL diakritiky: č, š, ě, ů …).

        - Používáme `unicodedata.name(ch)`, protože `isascii()` by vyřadilo
          i latinku s diakritikou.
        - Nepísmena (čísla, mezery, interpunkci) ignorujeme.
        """
        has_letter = False
        for ch in text or "":
            if ch.isalpha():
                has_letter = True
                # Pokud Unicode jméno znaku neobsahuje "LATIN", není to latinka.
                if "LATIN" not in unicodedata.name(ch, ""):
                    return False
        return has_letter




    def _prefer_latin_title(self, *, media: str, _id: int, primary: str, original: str = "") -> str:
        """
        2025-08-17 00:30 CEST (Europe/Prague)

        Vybere latinkový název podle jasného pořadí:
          1) `primary` (aktuální název) – pokud je latinkou,
          2) `original` (originální titul) – pokud je latinkou,
          3) alternativní tituly (preferujeme země: US, GB, CA, AU),
          4) EN detail (`language=en-US`).

        Nové (mikro-cache – „kosmetika" pro omezení síťových volání):
          • Alt‑titles (movie/tv) se ukládají do interní JSON cache na ~3 dny.
          • EN detail (movie/tv) se ukládá do interní JSON cache na ~3 dny.
          • Klíče cache: 
              - alt_titles:movie:{id}  /  alt_titles:tv:{id}
              - detail_en:movie:{id}   /  detail_en:tv:{id}
          • Síťové chyby ponechávají původní tichý fallback – logiku neměníme.

        Pozn.: `_cache_get/_cache_set` používají společný `tmdb_meta_cache.json`
        a již řeší atomický zápis a uzamčení. Zbytek logiky metody zůstává beze změny.
        """
        # 1) primární název (už latinkový?)
        if self._is_latin_text(primary):
            return (primary or "").strip()

        # 2) original_name / original_title
        if self._is_latin_text(original):
            return (original or "").strip()

        # 3) alternativní tituly – NOVĚ: krátká disková cache
        try:
            ttl = 3 * 24 * 3600  # ~3 dny
            akind = "movie" if media == "movie" else "tv"
            akey  = f"alt_titles:{akind}:{int(_id)}"

            items = self._cache_get(akey, ttl_seconds=ttl)
            if not isinstance(items, list):
                if media == "movie":
                    data = self._get_json(f"/movie/{_id}/alternative_titles", {"api_key": self.api_key})
                    items = [
                        {"title": (t.get("title") or "").strip(), "country": (t.get("iso_3166_1") or "").strip()}
                        for t in (data.get("titles") or [])
                    ]
                else:
                    data = self._get_json(f"/tv/{_id}/alternative_titles", {"api_key": self.api_key})
                    items = [
                        {"title": (t.get("title") or "").strip(), "country": (t.get("iso_3166_1") or "").strip()}
                        for t in (data.get("results") or [])
                    ]
                self._cache_set(akey, items)

            pref_ctrs   = {"US", "GB", "CA", "AU"}
            first_latin = None
            for rec in items or []:
                t = (rec.get("title") or "").strip()
                if not t:
                    continue
                if self._is_latin_text(t) and (rec.get("country") or "") in pref_ctrs:
                    return t
                if first_latin is None and self._is_latin_text(t):
                    first_latin = t
            if first_latin:
                return first_latin
        except Exception:
            # `_get_json()` už loguje chyby; zachováváme původní tiché fallbacky.
            pass

        # 4) EN detail – NOVĚ: krátká disková cache
        try:
            ttl = 3 * 24 * 3600  # ~3 dny
            dkind = "movie" if media == "movie" else "tv"
            dkey  = f"detail_en:{dkind}:{int(_id)}"

            t = self._cache_get(dkey, ttl_seconds=ttl)
            if not (isinstance(t, str) and t):
                if media == "movie":
                    en = self._get_json(f"/movie/{_id}", {"api_key": self.api_key, "language": "en-US"})
                    t  = (en.get("title") or "").strip()
                else:
                    en = self._get_json(f"/tv/{_id}", {"api_key": self.api_key, "language": "en-US"})
                    t  = (en.get("name") or "").strip()
                self._cache_set(dkey, t)

            if t and self._is_latin_text(t):
                return t
        except Exception as _en_e:
            # Dřív tiché: EN-detail fetch selhal → zůstane nelatinkový titul.
            _diag_log(f"EN title fallback fetch fail: {_en_e}", 0)

        # Nic lepšího – vrať původní (aby se aspoň něco zobrazilo)
        return (primary or original or "").strip()





    def search(self, query: str, limit: int = 10) -> List[Dict]:
        """
        2025-09-07 09:10 CEST (Europe/Prague)
        Vyhledání filmů dle `query` s prioritou latinky v titulku.

        Zachováno:
        - volání `/search/movie` s `language=self.lang`, `include_adult=false`
        - struktura položek: {"id","title","year","poster_path","backdrop_path","overview","rating","votes"}
        - zaokrouhlení ratingu na 1 desetinné místo a int `votes`
        - `_get_json()` řeší logování TMDB_REQ / RESP / ERR a timeout

        Nové:
        - **disková cache** výsledků (TTL ≈ 30 dní)
        - pokud `title` není latinkou, nahradíme jej latinkovou variantou
            (alt tituly → EN detail), viz `_prefer_latin_title()`.
        """
        # Cache key: zahrň `lang` a `limit`, ať se neliší výsledky
        _ttl = 30 * 24 * 3600
        _key = f"search:movie:{self.lang}:{(query or '').strip().lower()}:{int(limit or 10)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {
            "api_key":       self.api_key,
            "query":         query,
            "language":      self.lang,
            "include_adult": "false",
            "page":          1,
        }
        try:
            data = self._get_json("/search/movie", params)
        except TMDbTransientError:
            # Φ4 (2026-08-08): opakované hledání téhož titulu při výpadku sítě
            # vrátí dřívější výsledky místo prázdna. Validátor hlídá tvar (seznam),
            # protože degradujeme na už zpracovanou projekci, ne na syrovou odpověď.
            _stale = self._serve_stale(_key, "search_movie",
                                       validator=lambda d: isinstance(d, list))
            if _stale is None:
                raise
            return _stale

        out: List[Dict] = []
        for r in data.get("results", [])[:limit]:
            title_primary = (r.get("title") or "").strip()
            if not title_primary:
                continue

            title_final = self._prefer_latin_title(
                media="movie",
                _id=int(r["id"]),
                primary=title_primary,
                original=(r.get("original_title") or "").strip(),
            )

            out.append(
                {
                    "id":            r["id"],
                    "title":         title_final,
                    "year":          int((r.get("release_date") or "0000")[:4] or 0),
                    "poster_path":   r.get("poster_path") or "",
                    "backdrop_path": r.get("backdrop_path") or "",
                    "overview":      (r.get("overview") or "").strip(),
                    "rating":        round(float(r.get("vote_average") or 0), 1),
                    "votes":         int(r.get("vote_count") or 0),
                }
            )
        self._cache_set(_key, out)
        return out




    # ---------------------------------------------------------------------------- #
    # tmdb_client.py › class TMDb
    # _rl_shared_left / _rl_shared_set  (vytvořeno: 03.11.2026 21:15 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    _RL_SHARED_PROP = "richmovie.tmdb.rl_until"   # epoch konce cooldownu 429 (Window(10000), sdílí všechny interprety)

    @staticmethod
    def _rl_shared_left() -> float:
        """Zbývající sekundy sdíleného cooldownu 429 (0 = žádný). Chyba čtení = 0 (beze změny chování)."""
        try:
            import richmovie_winprops as _wp
            until = float(_wp.get_prop(TMDb._RL_SHARED_PROP, "") or 0.0)
        except Exception:
            return 0.0
        left = until - time.time()
        # strop proti posunutým hodinám: víc než MAX_S nikdy (stejný strop jako Retry-After)
        return max(0.0, min(left, TMDb._RL_COOLDOWN_MAX_S))

    @staticmethod
    def _rl_shared_set(seconds: float) -> None:
        """Zapíše konec cooldownu pro ostatní interprety; kratší cooldown delší nepřepíše."""
        try:
            import richmovie_winprops as _wp
            until = time.time() + float(seconds)
            current = float(_wp.get_prop(TMDb._RL_SHARED_PROP, "") or 0.0)
            if until > current:
                _wp.set_prop(TMDb._RL_SHARED_PROP, "%.3f" % until)
        except Exception:
            pass

    # ---------------------------------- METODA ---------------------------------- #
    # _parse_retry_after  (vytvořeno: 12.07.2026, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    @staticmethod
    def _parse_retry_after(value) -> float:
        """Přelož ``Retry-After`` hlavičku na sekundy cooldownu (clamp 1..MAX).

        Podporuje číselný tvar (delta-seconds); HTTP-date tvar je u našeho Gate
        nepoužíván, takže při neparsovatelné hodnotě padáme na default. Vrací vždy
        rozumnou kladnou hodnotu, ať se breaker nezasekne ani nezběsí.
        """
        try:
            secs = float(str(value).strip())
            if secs <= 0:
                secs = TMDb._RL_COOLDOWN_DEFAULT_S
        except (TypeError, ValueError):
            secs = TMDb._RL_COOLDOWN_DEFAULT_S
        return max(1.0, min(secs, TMDb._RL_COOLDOWN_MAX_S))


    #  21.12.2025 19:38 CET (Europe/Prague) – PRIORITA A: abort-safe + kratší timeout na Androidu
    def _get_json(self, path: str, params: Dict) -> Dict:
        """
        Interní helper: provede HTTP GET, zaloguje a vrátí dekódovaný JSON.

            TMDB_REQ   <plná URL>
            TMDB_RESP  <HTTP status> <bytes>
            TMDB_ERR   <str(e)>

        • Při HTTP ≠ 200 vyvolá TMDbError
        • Timeout 6 s → GUI nezamrzá

        Aktualizace: 2025-08-18 21:09 CEST (Europe/Prague)
        -----------------------
        • Přidán **globální rate‑limit** pro *všechny* instance TMDb:
        max. **20 požadavků / sekundu** (token‑bucket sdílený napříč vlákny).
        Chrání nás proti 429 a udrží stabilní zátěž.

        Aktualizace: 21.12.2025 19:38 CET (Europe/Prague)
        -----------------------
        PRIORITA A – stabilita (Chromecast/Android):
          • Pokud Kodi ruší invoker (`abortRequested=True`), musíme skončit okamžitě,
            jinak Kodi po ~5 s killne addon („script didn't stop in 5 seconds").
          • Na Androidu zkracujeme timeout (typicky 4 s), aby ani probíhající HTTP call
            nepřekročil kill okno.
        """
        # Abort monitor (best-effort) – při rušení invokeru končíme ihned.
        mon = None
        try:
            if xbmc:
                mon = xbmc.Monitor()
                if mon.abortRequested():
                    raise SystemExit
        except Exception:
            mon = None

        # 0) Client-side 429 cooldown (circuit breaker) — pokud nám Gate nedávno
        #    vrátil 429, jsme v cooldownu: selži OKAMŽITĚ a LOKÁLNĚ (bez sítě), ať
        #    žádný volající (ani ve smyčce) nezesiluje storm proti Gate. Cooldown
        #    respektuje Retry-After z 429 (nastaveno v except bloku níže).
        with TMDb._RL_LOCK:
            _cooldown_left = TMDb._RL_COOLDOWN_UNTIL - time.monotonic()
        # Noc 03.11.2026 (BACKLOG „cooldown 429 TMDb napříč interprety“): každé kliknutí v pluginu = nový interpret
        # s prázdnou třídou → první dotaz po 429 šel znovu na Gate. Cooldown je proto i ve Window(10000) (sdílený
        # pluginem i službou v rámci běhu Kodi); platí delší z obou.
        _cooldown_left = max(_cooldown_left, TMDb._rl_shared_left())
        if _cooldown_left > 0:
            self._log("TMDB_RL_COOLDOWN", f"skip {path} ({_cooldown_left:.1f}s left)")
            # Φ0 (2026-08-08): i fail-fast musí být vidět v NAS pipeline. Bez toho
            # vypadá cooldown v logu jako ticho a nepoznáme rozdíl mezi „Gate nás
            # rate-limituje" a „addon vůbec nic nezkusil".
            _diag_log(
                "TMDB_RL_COOLDOWN path=%s left=%.1fs" % (path, _cooldown_left),
                xbmc.LOGWARNING if xbmc else 2,
                context={"path": path, "cooldown_left_s": round(_cooldown_left, 1),
                         "err_class": "ratelimit"},
            )
            raise TMDbError(f"rate-limit cooldown {_cooldown_left:.1f}s")

        # 1) Rate‑limit – sdílený napříč instancemi a vlákny (token‑bucket)
        if not hasattr(TMDb, "_RL_TOKENS"):
            TMDb._RL_TOKENS   = 20.0      # aktuální stav kbelíku
            TMDb._RL_CAPACITY = 20.0      # max tokenů v kbelíku
            TMDb._RL_RATE     = 20.0      # tok: 20 tokenů / sekundu
            TMDb._RL_LAST     = time.monotonic()

        # Požadujeme 1 token pro jeden HTTP request
        while True:
            with TMDb._RL_LOCK:
                now = time.monotonic()
                # dopočet doplnění tokenů od poslední aktualizace
                elapsed = now - TMDb._RL_LAST
                if elapsed > 0:
                    TMDb._RL_TOKENS = min(TMDb._RL_CAPACITY, TMDb._RL_TOKENS + elapsed * TMDb._RL_RATE)
                    TMDb._RL_LAST   = now

                if TMDb._RL_TOKENS >= 1.0:
                    TMDb._RL_TOKENS -= 1.0
                    sleep_for = 0.0
                else:
                    need = 1.0 - TMDb._RL_TOKENS
                    sleep_for = need / TMDb._RL_RATE

            if sleep_for <= 0:
                break

            # krátký nenáročný spánek mimo zámek; max 100 ms, nebo přesně dle výpočtu
            if mon:
                # pokud se během čekání ruší invoker, skončíme okamžitě
                if mon.waitForAbort(min(0.1, sleep_for)):
                    raise SystemExit
            else:
                time.sleep(min(0.1, sleep_for))

        # 2) Gate proxy URL — Phase 3g (2026-04-19) SkyHook model.
        # Strip api_key from params: Gate injects its own key server-side.
        # Everyone (all 16 users) shares the same cache keyed by
        # (endpoint, params_hash, lang) on the server.
        proxy_params = {k: v for k, v in (params or {}).items() if k != "api_key"}
        url = (
            f"{_GATE_URL}{self.GATE_PROXY_PREFIX}{path}"
            f"?{urllib.parse.urlencode(proxy_params)}"
        )
        self._log("TMDB_REQ", url)

        # Auth headers for Gate's lightweight proof check.
        # CRITICAL (2026-04-19): **musíme mít explicit User-Agent** —
        # Cloudflare Bot Fight Mode blokuje ``Python-urllib/X.X`` default UA
        # s HTTP 403 error code 1010 ("banned browser signature"). Bez UA
        # všechny addon TMDb calls selhávaly 403 před dosažením Gate.
        try:
            _addon_version = xbmcaddon.Addon().getAddonInfo("version") or "dev"
        except Exception:
            _addon_version = "dev"
        headers: Dict[str, str] = {
            "User-Agent": f"RichMovie/{_addon_version} (+plugin.video.richmovie)",
            "Accept": "application/json",
        }
        if _GATE_AVAILABLE and _gate_get_identity is not None:
            try:
                ws_username, ws_proof = _gate_get_identity()
                if ws_username and ws_proof:
                    headers["X-WS-Username"] = ws_username
                    headers["X-WS-Proof"] = ws_proof
                    # Per-device atribuce (mig 0016) — Gate loguje device_hash i na 403.
                    if _gate_get_device_hash is not None:
                        _dh = _gate_get_device_hash()
                        if _dh:
                            headers["X-Device-Hash"] = _dh
                else:
                    # 3.5.120: prázdná identita → NEPOSÍLAT request naslepo.
                    # Do 3.5.119 tady tiché `pass` znamenalo anonymní dotaz,
                    # Gate 403 (`tmdb auth no-headers`) a modál „Data se
                    # nepodařilo načíst" bez jakékoli rady (incident bandog).
                    # Rozlišujeme ale poctivě: jen PROKÁZANÁ porucha čtení je
                    # důvod k selhání — „ještě nenastaveno" projde dál jako dřív
                    # (čerstvá instalace se musí umět přihlásit).
                    from richmovie_gate_transport import identity_read_failed \
                        as _gt_identity_read_failed
                    if _gt_identity_read_failed():
                        self._log("TMDB_IDENTITY_UNAVAILABLE", path)
                        _diag_log(
                            "TMDB_IDENTITY_UNAVAILABLE path=%s" % (path,),
                            xbmc.LOGWARNING if xbmc else 2,
                            context={"path": path,
                                     "err_class": "identity_unavailable"},
                        )
                        raise TMDbAuthError("identity unavailable (settings read)")
            except TMDbAuthError:
                raise
            except Exception:
                # Identity resolution failure → Gate returns 403, caller
                # surfaces as TMDbError, same as before.
                pass

        # 3.5.118 (2026-08-21): fail-fast na zamítnutou identitu — stejný vzor
        # jako 429 cooldown výše. Jakmile Gate identitu autoritativně odmítl
        # (`richmovie_identity_state` REJECTED), každé další identitu nesoucí
        # volání selže LOKÁLNĚ bez sítě. Incident gunžik: 2629× 403 v jednom
        # běhu — ani jeden z nich nemohl dopadnout jinak než ten první.
        # Jediný chokepoint `_get_json` → platí pro všechny volající (kolekce,
        # detaily, enrich, NextUp) bez hlídání každé smyčky zvlášť.
        _identity_sent = "X-WS-Proof" in headers
        if _identity_sent and _identity is not None and _identity.is_rejected():
            _reason = _identity.rejection_reason()
            self._log("TMDB_IDENTITY_FAILFAST", path, _reason)
            _diag_log(
                "TMDB_IDENTITY_FAILFAST path=%s reason=%s" % (path, _reason),
                xbmc.LOGWARNING if xbmc else 2,
                context={"path": path, "reason": _reason, "err_class": "identity"},
            )
            raise TMDbAuthError("identity rejected: %s" % _reason)

        # Φ3 (2026-08-08): transport přes `richmovie_http` — SSOT retry vrstva.
        # Profil `foreground` nese TYTÉŽ timeouty, jaké tady byly natvrdo od
        # 21.12.2025 (Android 5 s / ostatní 8 s); nově je nad nimi rozpočet, díky
        # kterému se rychlá chyba (ENETUNREACH ~1 ms) stihne zopakovat, kdežto
        # timeout retry nedostane. Lokální výpočet timeoutu zmizel — držet ho na
        # dvou místech by znamenalo drift (DRY).
        if _rm_http is None:
            # Vlastní modul addonu chybí → poškozená instalace. Hlasité selhání je
            # lepší než tichý downgrade na cestu bez retry, o kterém by nikdo nevěděl.
            raise TMDbError("richmovie_http neni k dispozici (poskozena instalace)")

        prof = _rm_http.profile_foreground()
        timeout_s = prof.timeout_s

        # abort check těsně před blokující operací
        if mon and mon.abortRequested():
            raise SystemExit

        # Φ0 (2026-08-08): měř KAŽDOU cestu (OK i chybovou). `elapsed_ms` je to,
        # co v `user_logs` odliší „síť je mrtvá" (chyba do pár ms) od „síť je
        # pomalá" (chyba až na timeoutu) — bez toho se ta dvě selhání v datech
        # nedají rozeznat a nevíme, jestli má retry vůbec šanci se stihnout.
        _t0 = time.monotonic()

        try:
            status, body, resp_headers = _rm_http.request(
                url, headers=headers, profile=prof, tag="tmdb",
            )

            # 429 z Gate → aktivuj client-side cooldown (respektuj Retry-After),
            # ať addon dotaz NEOPAKUJE ve smyčce a nezesiluje storm (viz breaker
            # výše). Retry vrstva 429 zásadně neopakuje, cooldown je druhá pojistka.
            if status == 429:
                retry_after = self._parse_retry_after(
                    resp_headers.get("Retry-After") if resp_headers else None
                )
                with TMDb._RL_LOCK:
                    TMDb._RL_COOLDOWN_UNTIL = time.monotonic() + retry_after
                TMDb._rl_shared_set(retry_after)
                self._log("TMDB_RL_429", f"cooldown {retry_after:.1f}s ({path})")
                _diag_log(
                    "TMDB_RL_429 path=%s cooldown=%.1fs" % (path, retry_after),
                    xbmc.LOGWARNING if xbmc else 2,
                    context=_err_context(
                        None, http_status=429, path=path,
                        cooldown_s=round(retry_after, 1),
                        elapsed_ms=int((time.monotonic() - _t0) * 1000),
                        timeout_s=timeout_s,
                    ),
                )
                # Text zachován shodný s původní `HTTPError` podobou, protože ho
                # čtou volající i per-search logy (vstup pro _tools/heuristics_replay).
                self._log("TMDB_ERR", "HTTP Error 429: Too Many Requests")
                # 3.5.141 (cross-check T5 Pro P7): 429 = stav infrastruktury, ne chyba dat →
                # TransientError, aby zabrala stale-first cache (ráno 8 zařízení jednoho účtu =
                # prázdné menu s chybou, ač disková cache je plná). Retry se nekoná (breaker výše).
                raise TMDbTransientError("HTTP Error 429: Too Many Requests")

            cache_status = ""
            if resp_headers is not None:
                try:
                    cache_status = resp_headers.get("X-Cache-Status") or ""
                except Exception:
                    cache_status = ""
            self._log(
                "TMDB_RESP",
                status, len(body),
                f"cache={cache_status}" if cache_status else "",
            )

            # 3.5.118: jediný hook stavu identity pro GET cestu. Na 401/403
            # s Gate JSON kódem přepne REJECTED; na 200 po REJECTED vrátí
            # AUTHENTICATED (důkaz opaku). HTML 403 (Cloudflare) ignoruje.
            _reject_code = ""
            if _identity is not None:
                _reject_code = _identity.observe_gate_response(
                    status, body, identity_sent=_identity_sent,
                )

            if status != 200:
                # Doručená, ale nepoužitelná odpověď (403 identity, 404, 5xx po
                # vyčerpaných pokusech). Chování shodné s původní implementací,
                # kde `urlopen` vyhodil HTTPError.
                _diag_log(
                    "TMDB_ERR path=%s status=%s" % (path, status),
                    xbmc.LOGWARNING if xbmc else 2,
                    context=_err_context(
                        None, http_status=status, path=path,
                        elapsed_ms=int((time.monotonic() - _t0) * 1000),
                        timeout_s=timeout_s,
                        reject_code=_reject_code or None,
                    ),
                )
                self._log("TMDB_ERR", f"Status {status}")
                if _reject_code:
                    raise TMDbAuthError(f"Status {status}: {_reject_code}")
                if status == 404:
                    raise TMDbNotFoundError(f"Status {status}")
                raise TMDbError(f"Status {status}")

            return json.loads(body.decode())

        except TMDbError:
            # Vlastní chyby (429, non-200) už jsou zalogované výše — nepřebalovat.
            raise
        except Exception as e:
            self._log("TMDB_ERR", str(e))
            _diag_log(
                "TMDB_ERR path=%s %s" % (path, type(e).__name__),
                xbmc.LOGWARNING if xbmc else 2,
                context=_err_context(
                    e, path=path,
                    elapsed_ms=int((time.monotonic() - _t0) * 1000),
                    timeout_s=timeout_s,
                    attempts_profile=prof.name,
                ),
            )
            # Φ4 (2026-08-08): přechodné chyby dostanou vlastní typ, aby volající
            # s diskovou cache mohl degradovat na stará data místo dialogu. Sem
            # spadá i `OfflineError` (fail-fast breaker) — je to podtřída
            # `TransientError`, a právě v offline režimu má stale cache největší cenu.
            if _rm_http is not None and _rm_http.is_transient(e):
                raise TMDbTransientError(str(e)) from e
            raise TMDbError(str(e)) from e









    def log_cache_footprint(self) -> None:
        """
        Vypočítá a **zapíše do RichMovie logu** velikost cache po kategoriích:

        • **textová data** (JSON soubory v profilu doplňku):
            – tmdb_meta_cache.json
            – search_cache.json
            – nextup_cache.json
        • **obrázky na pozadí** (fanart) – součet souborů v Kodi *Texture cache*,
            které vznikly ze zdrojových URL `https://image.tmdb.org/t/p/original…`
            (plus `…/w1280…` jako běžná alternativa u některých skinů).
        • **loga filmů** – součet souborů v Kodi *Texture cache*,
            které vznikly ze zdrojových URL `https://image.tmdb.org/t/p/w500…`
            (v RichMovie používáno výlučně pro **clearlogo**).

        Poznámky:
        – Neuchováváme **druhou kopii** obrázků; čteme pouze Kodi cache (Thumbnails + Textures*.db).
        – Výstup se zapíše jako událost **CACHE_USAGE** (strukturované hodnoty i čitelný přehled).
        – Pokud Textures DB nenajdeme, zapíše se alespoň velikost textových dat.

        Vytvořeno: 2025-08-18 21:09 CEST (Europe/Prague)
        """
        # ──────────────────────────────────────────────────────────────────
        # Pomocné funkce
        # ──────────────────────────────────────────────────────────────────
        def _fmt_bytes(n: int) -> str:
            units = ["B", "KB", "MB", "GB", "TB"]
            x = float(n)
            for u in units:
                if x < 1024.0 or u == units[-1]:
                    return f"{x:.1f} {u}"
                x /= 1024.0
            return f"{n} B"

        def _file_size(path: Path) -> int:
            try:
                return int(Path(path).stat().st_size)
            except Exception:
                return 0

        # ──────────────────────────────────────────────────────────────────
        # 1) TEXTOVÁ DATA – soubory v profilu doplňku
        # ──────────────────────────────────────────────────────────────────
        # 3.5.134 (profily): účtové cache z kořene, `nextup_cache.json` je osobní soubor
        # aktivního profilu — cesty jen přes SSOT `richmovie_paths` (Fable P3-12).
        try:
            import richmovie_paths as _rp
            paths = [
                _rp.account_path("tmdb_meta_cache.json"),
                _rp.account_path("search_cache.json"),
                _rp.personal_path("nextup_cache.json"),
            ]
        except Exception:
            paths = []
        text_bytes = sum(_file_size(p) for p in paths)

        # ──────────────────────────────────────────────────────────────────
        # 2) OBRÁZKY – z Kodi Textures DB → cached soubory v Thumbnails/
        # ──────────────────────────────────────────────────────────────────
        backdrops_bytes = 0
        logos_bytes     = 0
        try:
            # Najdi poslední Textures*.db
            db_root = "special://database"
            _, files = xbmcvfs.listdir(db_root)
            cand = sorted([f for f in files if f.lower().startswith("textures") and f.lower().endswith(".db")])
            db_path = xbmcvfs.translatePath(f"{db_root}/{cand[-1]}") if cand else None

            if db_path and os.path.exists(db_path):
                con = sqlite3.connect(db_path)
                con.row_factory = lambda cur, row: row[0]
                cur = con.cursor()

                # backdrops: original + (volitelně) w1280
                bd_cached = set()
                for like in ("https://image.tmdb.org/t/p/original%", "https://image.tmdb.org/t/p/w1280%"):
                    try:
                        cur.execute("SELECT cachedurl FROM texture WHERE url LIKE ?", (like,))
                        rows = cur.fetchall() or []
                        bd_cached.update(rows)
                    except Exception as _tx_e:
                        # Dřív tiché: texture DB dotaz selhal (schema drift?).
                        _diag_log(f"texture DB backdrop query fail: {_tx_e}", 0)

                # logos: w500 (v RichMovie používáme pouze pro clearlogo)
                lg_cached = set()
                try:
                    cur.execute("SELECT cachedurl FROM texture WHERE url LIKE 'https://image.tmdb.org/t/p/w500%'")
                    rows = cur.fetchall() or []
                    lg_cached.update(rows)
                except Exception:
                    pass

                con.close()

                # Převeď cachedurl → reálný soubor v Thumbnails/
                tbn_root = xbmcvfs.translatePath("special://thumbnails/")
                def _to_path(cachedurl: str) -> str:
                    if not cachedurl:
                        return ""
                    if cachedurl.startswith("special://"):
                        return xbmcvfs.translatePath(cachedurl)
                    # standardní případ: relativní cesta vůči Thumbnails/
                    return os.path.join(tbn_root, cachedurl.replace("\\\\", "/").lstrip("/"))

                bd_files = {_to_path(u) for u in bd_cached}
                lg_files = {_to_path(u) for u in lg_cached}

                backdrops_bytes = sum(_file_size(Path(p)) for p in bd_files if p)
                logos_bytes     = sum(_file_size(Path(p)) for p in lg_files if p)

        except Exception as e:
            # když něco selže (jiné umístění DB apod.), zapíšeme aspoň text
            self._log("CACHE_USAGE_WARN", str(e))

        total_bytes = int(text_bytes + backdrops_bytes + logos_bytes)

        # Strukturovaný zápis + čitelný řádek
        self._log(
            "CACHE_USAGE",
            {
                "total_bytes":     total_bytes,
                "text_bytes":      int(text_bytes),
                "backdrops_bytes": int(backdrops_bytes),
                "logos_bytes":     int(logos_bytes),
                "profile_dir":     str(getattr(_rp, "addon_data_dir", lambda: "")()) if paths else "",
            },
        )
        self._log(
            "CACHE_USAGE_SUMMARY",
            f"total={_fmt_bytes(total_bytes)}  text={_fmt_bytes(text_bytes)}  backdrops={_fmt_bytes(backdrops_bytes)}  logos={_fmt_bytes(logos_bytes)}  (Kodi texture cache)",
        )









    def search_tv(self, query: str, limit: int = 10) -> List[Dict]:
        """
        2025-09-07 09:10 CEST (Europe/Prague)
        Vyhledání TV seriálů dle `query` s prioritou latinky v `name`.

        Výstupní struktura (beze změny):
        [{"id","name","year","poster_path","backdrop_path","overview","rating","votes"}, …]
        """
        _ttl = 30 * 24 * 3600
        _key = f"search:tv:{self.lang}:{(query or '').strip().lower()}:{int(limit or 10)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {
            "api_key":       self.api_key,
            "query":         query,
            "language":      self.lang,
            "page":          1,
        }
        try:
            data = self._get_json("/search/tv", params)
        except TMDbTransientError:
            # Φ4 (2026-08-08): stejná degradace jako u filmového hledání.
            _stale = self._serve_stale(_key, "search_tv",
                                       validator=lambda d: isinstance(d, list))
            if _stale is None:
                raise
            return _stale

        out: List[Dict] = []
        for r in data.get("results", [])[:limit]:
            name_primary = (r.get("name") or "").strip()
            if not name_primary:
                continue

            name_final = self._prefer_latin_title(
                media="tv",
                _id=int(r["id"]),
                primary=name_primary,
                original=(r.get("original_name") or "").strip(),
            )

            out.append(
                {
                    "id":            r["id"],
                    "name":          name_final,
                    "year":          int((r.get("first_air_date") or "0000")[:4] or 0),
                    "poster_path":   r.get("poster_path") or "",
                    "backdrop_path": r.get("backdrop_path") or "",
                    "overview":      (r.get("overview") or "").strip(),
                    "rating":        round(float(r.get("vote_average") or 0), 1),
                    "votes":         int(r.get("vote_count") or 0),
                }
            )
        self._cache_set(_key, out)
        return out






    #  2025-08-16 09:24 CEST (Europe/Prague)
    def episode_details(self, tv_id: int, season_no: int, episode_no: int) -> Dict:
        """
        Detail jedné epizody (/tv/{tv_id}/season/{season_no}/episode/{episode_no})
        Vrací např. {"id":..., "name":"...", "overview":"...", "still_path": "..."}.

        Nové:
        -----
        • disková cache s TTL ≈ 30 dní
        """
        params = {"api_key": self.api_key, "language": self.lang}

        _ttl = 30 * 24 * 3600
        _key = self._episode_cache_key(tv_id, season_no, episode_no)
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, dict):
            return cached

        try:
            data = self._get_json(
                f"/tv/{tv_id}/season/{season_no}/episode/{episode_no}", params
            )
        except TMDbTransientError:
            # Φ4 (2026-08-08): název a popis epizody se nemění vůbec. Když jede
            # autoplay dalšího dílu a zrovna vypadne Wi-Fi, je nesrovnatelně lepší
            # ukázat starý název než přerušit sledování chybou.
            _stale = self._serve_stale(_key, "episode_details",
                                       validator=lambda d: isinstance(d, dict))
            if _stale is None:
                raise
            return _stale

        self._cache_set(_key, data)
        return data



    def episode_translations(self, tv_id: int, season_no: int, episode_no: int) -> Dict[str, str]:
        """
        Překlady názvu epizody → mapování „jazyk(-země) → name".

        10-08-2025 16:31 CEST (Europe/Prague)
        -------------------------------------
        • /tv/{tv_id}/season/{sn}/episode/{ep}/translations
        • Klíč volím jako "iso_639_1-iso_3166_1" (pokud je země známa),
          jinak jen "iso_639_1".  Vždy beru nejdelší dostupné jméno
          pro daný klíč (bývá to plný název typu „The One Where …").

        Vrací:
            {"en-US": "The One Where Monica Gets a Roommate",
             "en-GB": "The One Where Monica Gets a Flatmate",
             "en":    "The One Where Monica Gets a Roommate",
             "cs-CZ": "Zrušená svatba", ...}
        """
        params = {"api_key": self.api_key}
        # Φ-B (30.09.2026): lokální cache (30 d, stale-first). Překlady názvu dílu se nemění a hledání dílu
        # je od 3.5.171 společné pro výpis i předstažení ve službě — bez cache by každé předstažení
        # přidalo dotaz na TMDb.
        data: Dict[str, Any] = self._get_json_cached(
            f"/tv/{tv_id}/season/{season_no}/episode/{episode_no}/translations", params,
            key=f"ep_translations:{int(tv_id)}:{int(season_no)}:{int(episode_no)}",
            ttl_s=self.STATIC_META_TTL_S, what="episode_translations")
        return self._parse_translation_map(data)

    @staticmethod
    def _parse_translation_map(data: Dict[str, Any], field: str = "name") -> Dict[str, str]:
        """SSOT parser odpovědi TMDb /translations (epizoda i seriál mají
        identický tvar, film nese název v `data.title` → `field="title"`).
        Klíč „iso_639_1[-iso_3166_1]" → název; při kolizi klíče preferuj DELŠÍ
        název (bývá plná věta)."""
        out: Dict[str, str] = {}
        for tr in (data.get("translations", []) or []):
            lang = (tr.get("iso_639_1") or "").strip()
            ctry = (tr.get("iso_3166_1") or "").strip()
            dat  = tr.get("data") or {}
            name = (dat.get(field) or "").strip()
            if not (lang and name):
                continue
            key = f"{lang}-{ctry}" if ctry else lang
            if key not in out or len(name) > len(out[key]):
                out[key] = name
        return out

    def tv_translations(self, tv_id: int) -> Dict[str, str]:
        """Překlady názvu SERIÁLU → mapování „jazyk(-země) → name".

        2026-07-07 (HΦ5) – doplňuje alternative_titles: TMDb `alternative_titles`
        je user-curated a nemusí obsahovat každý lokalizovaný název (např. SK
        „Priatelia" pro Friends). `/tv/{id}/translations` nese OFICIÁLNÍ
        lokalizovaný `data.name` per jazyk. Používá se k obohacení
        ser_title_variants → cizojazyčný název už nepenalizuje správný soubor
        a zlepšuje recall u souborů pojmenovaných jen lokálním názvem. Mirror
        episode_translations (stejný tvar odpovědi)."""
        params = {"api_key": self.api_key}
        data: Dict[str, Any] = self._get_json_cached(
            f"/tv/{tv_id}/translations", params, key=f"tv_translations:{int(tv_id)}",
            ttl_s=self.STATIC_META_TTL_S, what="tv_translations")
        return self._parse_translation_map(data)

    # Jazyky oficiálních překladů názvu FILMU, pod kterými se soubory na českých a slovenských úložištích
    # jmenují (pořadí = pořadí v seznamu názvů pro filtr).
    MOVIE_TITLE_LANGS = ("en-US", "en-GB", "en", "cs-CZ", "cs", "sk-SK", "sk", "pl-PL", "pl")

    def movie_localized_titles(self, movie_id: int) -> List[str]:
        """Oficiální lokalizované názvy FILMU (TMDb `/movie/{id}/translations`, `data.title`) v jazycích
        `MOVIE_TITLE_LANGS`, bez duplicit, jen s latinkou. Lokální cache 30 d.

        Φ-B (30.09.2026, E3-F02): filtr filmu znal jen český a PŮVODNÍ název. U filmu s neanglickým
        originálem („Le Cinquième Élément“) tak zahodil všechny soubory pojmenované anglicky
        („The.Fifth.Element.1997…“ včetně 4K) — seriály tuhle sadu názvů mají od HΦ5."""
        data = self._get_json_cached(
            f"/movie/{int(movie_id)}/translations", {"api_key": self.api_key},
            key=f"movie_translations:{int(movie_id)}", ttl_s=self.STATIC_META_TTL_S,
            what="movie_translations")
        by_lang = self._parse_translation_map(data if isinstance(data, dict) else {}, field="title")
        out: List[str] = []
        seen: set = set()
        for lc in self.MOVIE_TITLE_LANGS:
            nm = (by_lang.get(lc) or "").strip()
            if nm and re.search(r"[A-Za-z]", nm) and nm.casefold() not in seen:
                seen.add(nm.casefold())
                out.append(nm)
        return out

    def tv_alternative_titles(self, tv_id: int) -> List[Dict[str, Any]]:
        """Alternativní názvy SERIÁLU (`/tv/{id}/alternative_titles` → `results`), lokální cache 30 d.

        Φ-B (30.09.2026): dřív je `plugin._tv_play_run` četl přímým `_get_json` při KAŽDÉM hledání dílu
        (bez cache). Položky: {"iso_3166_1": "US", "title": "…", "type": "…"}; filtr zemí dělá volající."""
        data = self._get_json_cached(
            f"/tv/{int(tv_id)}/alternative_titles", {"api_key": self.api_key},
            key=f"tv_alt_titles:{int(tv_id)}", ttl_s=self.STATIC_META_TTL_S, what="tv_alternative_titles")
        res = data.get("results", []) if isinstance(data, dict) else []
        return [r for r in res if isinstance(r, dict)]





    def tv_details(self, tv_id: int) -> Dict[str, Any]:
        """
        Detail seriálu – preferujeme latinkový `name` (alt tituly → EN detail).
        Disková cache s TTL ≈ 30 dní.

        2026-04-30 — Defense-in-depth proti partial-detail cache poisoning
        (Lost incident, viz Handoff/session_2026-04-30_tmdb_partial_cache_
        poisoning.md). Validuje, že payload má tvar plného detailu (`seasons`
        klíč, žádný `_partial_from` marker). Pokud Gate vrátí partial:
          • lokální disková cache se NEPŘEPÍŠE (zůstává předchozí full nebo prázdno)
          • při `cached` jako partial: ignoruj a fetchni znovu
          • zaloguje warning (`TV_DETAIL_PARTIAL_REJECTED`) pro diagnostiku
        Server-side fix v Gate (migration 0006) by měl tento případ eliminovat,
        ale defense-in-depth chrání addon i v přechodném okně před Gate redeploy.
        """
        params = {"api_key": self.api_key, "language": self.lang}

        _ttl = 30 * 24 * 3600
        _key = f"tv_details:{int(tv_id)}:{self.lang}"

        cached = self._cache_get(_key, _ttl)
        cached_is_full = (
            isinstance(cached, dict)
            and "seasons" in cached
            and "_partial_from" not in cached
        )

        served_stale = False
        if cached_is_full:
            data = dict(cached)
        else:
            try:
                data = self._get_json(f"/tv/{tv_id}", params)
            except TMDbTransientError:
                # Φ4 (2026-08-08): stejná degradace jako u filmů, se stejným
                # partial guardem — právě tady „Lost" incident (30.04.2026) začal,
                # takže tudy stará partial data projít NESMÍ.
                _stale = self._serve_stale(
                    _key, "tv_details",
                    validator=lambda d: (isinstance(d, dict)
                                         and "seasons" in d
                                         and "_partial_from" not in d),
                )
                if _stale is None:
                    raise
                data = dict(_stale)
                served_stale = True

        is_partial_payload = (
            "_partial_from" in data
            or "seasons" not in data
        )

        # Apply latin-title preference regardless (caller expects `name` set).
        data["name"] = self._prefer_latin_title(
            media="tv",
            _id=int(tv_id),
            primary=(data.get("name") or "").strip(),
            original=(data.get("original_name") or "").strip(),
        )

        if is_partial_payload:
            # Don't pollute the local cache. Caller (e.g. _tv_seasons) is
            # responsible for surfacing this to the user — we just hand back
            # the partial unchanged so they can detect and react.
            try:
                self._log(
                    "TV_DETAIL_PARTIAL_REJECTED",
                    "tv_id={} keys={}".format(
                        int(tv_id), sorted(list(data.keys()))[:20],
                    ),
                )
            except Exception:
                pass
            return data

        # Φ4 (2026-08-08): degradovaná data zpět do cache NEUKLÁDAT — zápis by jim
        # dal čerstvé razítko a příštích 30 dní by se tvářila jako aktuální.
        if not served_stale:
            self._cache_set(_key, data)
        return data


    def tv_logos(self, tv_id: int) -> List[Dict]:
        """
        Loga serialu z /tv/{tv_id}/images (pouze typ 'logos').
        Vraci list [{"file_path": "/abc.png", ...}, ...] serazeny
        podle vote_average desc.  Cachovano 30 dni.
        """
        _ttl = 30 * 24 * 3600
        _key = f"tv_logos:{int(tv_id)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        try:
            params = {"api_key": self.api_key}
            data = self._get_json(f"/tv/{tv_id}/images", params)
            logos = data.get("logos") or []
            logos.sort(key=lambda x: float(x.get("vote_average") or 0), reverse=True)
        except Exception:
            logos = []
        self._cache_set(_key, logos)
        return logos


    # Placeholder pattern — TMDb vrací pro nepřeložené epizody defaultní
    # "Epizoda 3" / "Episode 3" / "Episódio 3" místo reálného titulu.
    _EPISODE_PLACEHOLDER_RE = re.compile(
        r"^(epizoda|episode|episódio|episodio)\s*\d+\s*$",
        re.IGNORECASE,
    )

    def season_details(self, tv_id: int, season_no: int) -> List[Dict]:
        """
        Vrátí list epizod v dané sezóně:

            [{"episode_number":1, "name":"Winter Is Coming"}, …]

        Phase G3 (2026-04-19) — EN fallback pro nepřeložené epizody:
        pokud TMDb vrátí v lokalizaci (cs-CZ) placeholder "Epizoda N",
        doplníme EN název z druhého volání /season?language=en-US. Druhé
        volání jen když aspoň jedna epizoda placeholder obsahuje (šetří
        RTT na plně lokalizovaných seriálech).
        """
        params = {"api_key": self.api_key, "language": self.lang}
        data = self._get_json(f"/tv/{tv_id}/season/{season_no}", params)

        raw_eps: List[Dict] = data.get("episodes", []) or []

        def _is_placeholder(nm: str) -> bool:
            return bool(self._EPISODE_PLACEHOLDER_RE.match((nm or "").strip()))

        needs_en = (self.lang or "").lower() != "en-us" and any(
            (not e.get("name")) or _is_placeholder(e.get("name", ""))
            for e in raw_eps
        )

        # EN fallback: chybějící CZ název I popis doplníme z en-US (popisy bývají
        # u méně populárních seriálů v cs prázdné častěji než názvy).
        en_map: Dict[int, str] = {}
        en_overview: Dict[int, str] = {}
        if needs_en:
            try:
                en_data = self._get_json(
                    f"/tv/{tv_id}/season/{season_no}",
                    {"api_key": self.api_key, "language": "en-US"},
                )
                for ee in en_data.get("episodes", []) or []:
                    _no = int(ee.get("episode_number") or 0)
                    en_name = (ee.get("name") or "").strip()
                    if en_name and not _is_placeholder(en_name):
                        en_map[_no] = en_name
                    en_ov = (ee.get("overview") or "").strip()
                    if en_ov:
                        en_overview[_no] = en_ov
            except Exception:
                # Best-effort — chybějící EN fallback nesmí shodit flow.
                pass

        eps: List[Dict] = []
        for e in raw_eps:
            name = (e.get("name") or "").strip()
            ep_no = int(e.get("episode_number") or 0)
            if not name or _is_placeholder(name):
                alt = en_map.get(ep_no, "")
                if alt:
                    name = alt
            if not name:
                continue
            overview = (e.get("overview") or "").strip() or en_overview.get(ep_no, "")
            eps.append({
                "episode_number": ep_no,
                "name":           name,
                # Φ — episode-specific metadata (dřív zahazováno): náhled + popis
                # pro Episodes okno (detail panel) i Stream-picker.
                "overview":       overview,
                "still_path":     (e.get("still_path") or "").strip(),
                "air_date":       (e.get("air_date") or "").strip(),
                "vote_average":   e.get("vote_average") or 0,
                "runtime":        e.get("runtime") or 0,
            })
        return eps

    def season_air_date(self, tv_id: int, season_no: int) -> str:
        """Datum premiéry sezóny (`air_date` sezóny, ISO `YYYY-MM-DD`), "" když
        není známé. JEDNA cesta pro obě vyhledávací větve (plán adaptivní cache
        Φ0a, 25.08.2026): do 3.5.125 volala jedna větev `season_details()` a četla
        z něj `.get("air_date")` — jenže `season_details` vrací LIST epizod, takže
        každé volání skončilo `'list' object has no attribute 'get'`, tiše
        spolknuto do DEBUG (186× za 14 dní ve flotile), a `allowed_years` nikdy
        nedostaly rok sezóny. Druhá větev volala `_get_json` napřímo = druhá pravda.
        Výjimky propouští (volající si je řeší jako dosud); disková cache 30 dní."""
        params = {"api_key": self.api_key, "language": self.lang}
        _ttl = 30 * 24 * 3600
        _key = f"season_air_date:{int(tv_id)}:{int(season_no)}:{self.lang}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, dict) and "air_date" in cached:
            return (cached.get("air_date") or "").strip()
        data = self._get_json(f"/tv/{int(tv_id)}/season/{int(season_no)}", params)
        air = ((data or {}).get("air_date") or "").strip() if isinstance(data, dict) else ""
        try:
            self._cache_set(_key, {"air_date": air})
        except Exception:
            pass
        return air



    # 16-08-2025 08:43 CEST (Europe/Prague)
    # ---------------------------------------------------------------------------- #
    # tmdb_client.py › class TMDb
    # peek_details / peek_tv_details / player_context_meta
    # (vytvořeno: 05.09.2026 07:20 CEST, Europe/Prague – 3.5.131, doporučení v2 R1)
    # ---------------------------------------------------------------------------- #
    def peek_details(self, movie_id: int) -> Optional[Dict[str, Any]]:
        """Plný detail filmu POUZE z diskové cache (i expirované, do
        `STALE_MAX_AGE_S`), 0 síťových volání. Partial (search-projekce) se
        ignoruje — stejná brána jako v `details()`. None = neznámý."""
        cached = self._cache_get_stale(f"movie_details:{int(movie_id)}:{self.lang}")
        if isinstance(cached, dict) and "_partial_from" not in cached and "genres" in cached:
            return dict(cached)
        return None

    def _episode_cache_key(self, tv_id: int, season_no: int, episode_no: int) -> str:
        """Klíč diskové cache detailu epizody — jeden pro `episode_details` i `peek_episode_details`."""
        return f"episode:{int(tv_id)}:{int(season_no)}:{int(episode_no)}:{self.lang}"

    def peek_episode_details(self, tv_id: int, season_no: int, episode_no: int) -> Optional[Dict[str, Any]]:
        """Detail epizody POUZE z diskové cache (i expirované, do `STALE_MAX_AGE_S`), 0 síťových volání.
        Φ6 (29.09.2026): `plugin._play` pro OSD — HTTP před `setResolvedUrl` zdržoval každý start."""
        cached = self._cache_get_stale(self._episode_cache_key(tv_id, season_no, episode_no))
        return dict(cached) if isinstance(cached, dict) else None

    def peek_tv_details(self, tv_id: int) -> Optional[Dict[str, Any]]:
        """Detail seriálu POUZE z diskové cache (viz `peek_details`)."""
        cached = self._cache_get_stale(f"tv_details:{int(tv_id)}:{self.lang}")
        if isinstance(cached, dict) and "_partial_from" not in cached and "genres" in cached:
            return dict(cached)
        return None

    @staticmethod
    def extract_player_context_meta(detail: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Čistá projekce detailu → {genres: [názvy], rating: float|None,
        origin_country: iso|None} pro `richmovie_player_hook.set_player_context`.
        Země: origin_country[0] (seriál) → production_countries[0] (film) →
        original_language (poslední záchrana, `cs` ≈ CZ)."""
        if not isinstance(detail, dict):
            return {}
        genres = [
            str(g.get("name")) for g in (detail.get("genres") or [])
            if isinstance(g, dict) and g.get("name")
        ]
        rating = detail.get("vote_average")
        try:
            rating = float(rating) if rating not in (None, "") and float(rating) > 0 else None
        except (TypeError, ValueError):
            rating = None
        origin = None
        oc = detail.get("origin_country")
        if isinstance(oc, list) and oc:
            origin = str(oc[0]).lower()
        else:
            pc = detail.get("production_countries")
            if isinstance(pc, list) and pc and isinstance(pc[0], dict) and pc[0].get("iso_3166_1"):
                origin = str(pc[0]["iso_3166_1"]).lower()
            elif detail.get("original_language"):
                origin = str(detail["original_language"]).lower()
        return {"genres": genres, "rating": rating, "origin_country": origin}

    def player_context_meta(self, kind: str, tmdb_id: int) -> Dict[str, Any]:
        """`peek_*` + projekce — jediný vstup pro `_play` (0 síť)."""
        detail = self.peek_tv_details(tmdb_id) if kind == "tv" else self.peek_details(tmdb_id)
        return self.extract_player_context_meta(detail)

    def details(self, movie_id: int) -> Dict[str, Any]:  # 2025-09-27 13:34 CEST (Europe/Prague)

        """
        Detail filmu – rozšířen o preferenci latinky v `title`.
        Další logika beze změny:
          - EN fallback pro `runtime` (pokud chybí v lokalizaci),
          - zajištění klíčů `year` (YYYY z `release_date`) a `original_title`.
        """
        # Lokalizovaný detail (cs-CZ apod.)
        params = {"api_key": self.api_key, "language": self.lang}

        # 2025-09-27 13:34 CEST (Europe/Prague) – disková cache (TTL ≈ 30 dní)
        _ttl = 30 * 24 * 3600
        _key = f"movie_details:{int(movie_id)}:{self.lang}"
        # Σ-audit Φ3.18: stejná obrana proti partial-detail cache poisoning jako
        # tv_details (Lost incident). Plný /movie/{id} detail má klíč `genres`;
        # search-projekce (partial, např. CSFD-resolved poster/plot) ho nemá nebo
        # nese `_partial_from` marker. Partial se NEPŘEPÍŠE do lokální cache a
        # cached-partial se ignoruje + refetchne.
        cached = self._cache_get(_key, _ttl)
        cached_is_full = (
            isinstance(cached, dict)
            and "_partial_from" not in cached
            and "genres" in cached
        )
        served_stale = False
        if cached_is_full:
            data: Dict[str, Any] = dict(cached)  # kopie pro jistotu
        else:
            try:
                data: Dict[str, Any] = self._get_json(f"/movie/{movie_id}", params)
            except TMDbTransientError:
                # Φ4 (2026-08-08): síť je dole → radši detail o pár dní starší než
                # dialog s chybou. Validátor drží TENTÝŽ partial guard jako čerstvá
                # cesta výše — degradace NESMÍ oživit „Lost" incident (30.04.2026),
                # kdy se search-projekce tvářila jako plný detail.
                _stale = self._serve_stale(
                    _key, "movie_details",
                    validator=lambda d: (isinstance(d, dict)
                                         and "_partial_from" not in d
                                         and "genres" in d),
                )
                if _stale is None:
                    raise
                data: Dict[str, Any] = dict(_stale)
                served_stale = True

        # Preferovat latinku v title (alt tituly → EN detail)
        data["title"] = self._prefer_latin_title(
            media="movie",
            _id=int(movie_id),
            primary=(data.get("title") or "").strip(),
            original=(data.get("original_title") or "").strip(),
        )

        # Fallback runtime z EN detailu, pokud chybí
        if not data.get("runtime"):
            try:
                en = self._get_json(f"/movie/{movie_id}", {"api_key": self.api_key, "language": "en-US"})
                if en.get("runtime"):
                    data["runtime"] = en["runtime"]
            except TMDbError as _en_e:
                _diag_log(f"EN runtime fallback fail: {_en_e}", 0)

        # Zajisti `year` a `original_title` (stejné chování jako původně)
        if not data.get("year"):
            data["year"] = int((data.get("release_date") or "0000")[:4] or 0)
        if not data.get("original_title"):
            data["original_title"] = data.get("title", "")

        # Σ-audit Φ3.18: NEukládej partial do cache (jinak by se „Lost" poisoning
        # přenesl i na filmy). Vrať ho nezměněný (caller má aspoň title/poster),
        # ale příští volání refetchne plný detail.
        is_partial_payload = ("_partial_from" in data) or ("genres" not in data)
        if is_partial_payload:
            try:
                self._log(
                    "MOVIE_DETAIL_PARTIAL_REJECTED",
                    "movie_id={} keys={}".format(
                        int(movie_id), sorted(list(data.keys()))[:20],
                    ),
                )
            except Exception:
                pass
            return data

        # 2025-09-27 13:34 CEST (Europe/Prague) – ulož do cache (read‑through)
        # Φ4 (2026-08-08): degradovaná (stale) data se NEUKLÁDAJÍ zpátky. Zápis by
        # jim nastavil čerstvé razítko, čímž by data „omládla" o svoje skutečné
        # stáří a příštích 30 dní by se tvářila jako aktuální — tichá ztráta
        # informace, kterou by nikdo nezpozoroval.
        if not served_stale:
            try:
                self._cache_set(_key, data)
            except Exception:
                # Cache je „best effort" – nikdy nesmí shodit volání
                pass
        return data




    # ---------------------------------- METODA ---------------------------------- #
    # tmdb_client.py › class TMDb # movie_enrich (upraveno: 2025-12-23 21:22 CET (Europe/Prague) – 1× request (append release_dates + watch/providers) + TTL 24h badge pro GUI)
    # ---------------------------------------------------------------------------- #
    def movie_enrich(
        self,
        movie_id: int,
        *,
        region: str = "CZ",
        fallback_region: str = "US",
    ) -> Dict[str, Any]:
        """
        2025-12-23 21:22 CET (Europe/Prague)

        Best-effort „enrichment" pro GUI výpisy (Trendy / TOP / Žánry) – **FILMY**.

        Co vrací:
          • `runtime`        – stopáž v minutách (0 pokud neznáme)
          • `overview`       – popis (lokalizovaný dle `self.lang`)
          • `backdrop_path`  – pozadí (fanart)
          • `release_badge`  – krátký štítek do názvu, např.:
                [Kino CZ 23.1.2026 • Netflix]
                [Digitál CZ 7.10.2024 • Netflix]
                [TV US 10.1.2025 • Canal+]

        Proč to existuje:
          • Chceme „lepší GUI zážitek" – u nových titulů ukázat, kdy a kde má premiéru,
            a u vydaných titulů aspoň poslední relevantní release.
          • Musí to být úsporné k API: používáme **1 HTTP request** díky:
              append_to_response = release_dates, watch/providers
          • Výsledek ukládáme do diskové JSON cache (TTL 24 h).

        Poznámky:
          • `release_badge` je vždy best-effort – nesmí shodit GUI.
          • Pokud TMDb nic nevrátí (nebo se nepovede parsování), badge bude prázdný řetězec.
        """
        try:
            _mid = int(movie_id or 0)
        except Exception:
            _mid = 0
        if _mid <= 0:
            return {}

        # Denní cache (TTL 24 h: štítek premiéry závisí na dnešním datu a nabídce platforem)
        _reg, _fb = self._enrich_regions(region, fallback_region)
        _key = self._enrich_key(_mid, _reg, _fb)

        cached = self._cache_get(_key, self.ENRICH_TTL_S)
        if isinstance(cached, dict):
            # kopie – ať si volající omylem neupraví globální cache data
            return dict(cached)

        # Jeden request: detail + release_dates + watch/providers
        params = {
            "api_key": self.api_key,
            "language": self.lang,
            "append_to_response": ",".join(self.ENRICH_APPEND),
        }

        try:
            data = self._get_json(f"/movie/{_mid}", params)
        except Exception:
            # GUI nikdy nesmí padnout – vracíme prázdno
            return {}

        out = self._enrich_from_detail(data, _reg, _fb)
        try:
            self._cache_set(_key, out)
        except Exception:
            pass
        return out

    # ---------------------------------- METODA ---------------------------------- #
    # tmdb_client.py › class TMDb
    # _enrich_regions / _enrich_key / _enrich_from_detail / movie_enrich_many / _bulk_fetch_movies
    # (Φ6, 29.09.2026 — rozhodnutí D10, audit A06 F11/R09)
    # ---------------------------------------------------------------------------- #
    # `append_to_response` obohacení — JEDEN tvar pro dotaz po jednom i hromadný (Gate pak sdílí klíč cache).
    ENRICH_APPEND = ("release_dates", "watch/providers")
    ENRICH_TTL_S = 24 * 3600
    # Strop jednoho hromadného dotazu = Gate `BulkFetchRequest.items` (max_length=100).
    BULK_MAX_ITEMS = 100

    @staticmethod
    def _enrich_regions(region: str, fallback_region: str) -> Tuple[str, str]:
        return ((region or "CZ").strip().upper() or "CZ",
                (fallback_region or "US").strip().upper() or "US")

    def _enrich_key(self, movie_id: int, reg: str, fb: str) -> str:
        return f"movie_enrich:{int(movie_id)}:{self.lang}:{reg}:{fb}"

    def _enrich_from_detail(self, data: Dict[str, Any], _reg: str, _fb: str) -> Dict[str, Any]:
        """Projekce detailu filmu (s `release_dates` a `watch/providers`) → řádek výpisu:
        stopáž, popis, pozadí, hodnocení a štítek premiéry. Čistá (bez sítě a cache)."""

        # --- základní metadata (stejné jako dříve z details) --------------------
        overview = (data.get("overview") or "").strip()
        backdrop_path = data.get("backdrop_path") or ""
        runtime_min = 0
        try:
            runtime_min = int(data.get("runtime") or 0)
        except Exception:
            runtime_min = 0

        # --- release badge ------------------------------------------------------
        release_badge = ""

        # ISO date pro porovnání – lexikograficky funguje (YYYY-MM-DD)
        today = time.strftime("%Y-%m-%d", time.localtime())

        def _fmt_date(iso_date: str) -> str:
            """YYYY-MM-DD → D.M.YYYY (CZ styl)."""
            try:
                y, m, d = (iso_date or "").split("-")
                return f"{int(d)}.{int(m)}.{y}"
            except Exception:
                return (iso_date or "").strip()

        def _type_label(t: int) -> str:
            """TMDb release type → krátký text."""
            # https://developer.themoviedb.org/reference/movie-release-dates
            return {
                1: "Premiéra",
                2: "Kino (omezeno)",
                3: "Kino",
                4: "Digitál",
                5: "Fyzická",
                6: "TV",
            }.get(int(t or 0), "Release")

        def _future_prio(t: int) -> int:
            """Priorita typu u budoucích událostí (nižší = lepší)."""
            return {
                3: 0,  # Kino
                2: 1,  # Kino (omezeno)
                1: 2,  # Premiéra
                4: 3,  # Digitál
                5: 4,  # Fyzická
                6: 5,  # TV
            }.get(int(t or 0), 9)

        def _past_prio(t: int) -> int:
            """Priorita typu u minulých událostí (vyšší = lepší)."""
            return {
                4: 6,  # Digitál je často nejvíc „relevantní teď"
                6: 5,  # TV
                5: 4,  # Fyzická
                3: 3,  # Kino
                2: 2,  # Kino (omezeno)
                1: 1,  # Premiéra
            }.get(int(t or 0), 0)

        def _extract_provider_from_note(note: str) -> str:
            """Z poznámky release (TMDb) vytáhne známou platformu."""
            n = (note or "").strip()
            if not n:
                return ""
            low = n.lower()

            if "netflix" in low:
                return "Netflix"
            if "prime video" in low or "amazon" in low:
                return "Prime Video"
            if "apple tv" in low or "itunes" in low:
                return "Apple TV"
            if "hbo" in low:
                return "Max"
            if "disney" in low:
                return "Disney+"
            if "voyo" in low:
                return "Voyo"
            if "skyshowtime" in low:
                return "SkyShowtime"
            if "canal+" in low:
                return "Canal+"
            if "sky cinema" in low:
                return "Sky Cinema"

            if 1 <= len(n) <= 24:
                return n
            return ""

        def _provider_display(name: str) -> str:
            """Zkrácení/normalizace názvů providerů z watch/providers."""
            n = (name or "").strip()
            if not n:
                return ""
            low = n.lower()
            if low == "amazon prime video":
                return "Prime Video"
            if low == "apple tv plus":
                return "Apple TV+"
            if low in ("hbo max", "max"):
                return "Max"
            if low == "google play movies":
                return "Google Play"
            return n

        def _best_provider_from_watch(watch_blob: Dict[str, Any], iso: str) -> str:
            """
            Z `watch/providers` vybere 1 „nejlepší" provider pro daný region:
              1) flatrate (subscription)
              2) free / ads
              3) rent
              4) buy
            Podle `display_priority` (nižší je lepší).
            """
            try:
                results = (watch_blob or {}).get("results") or {}
                reg = results.get(iso) or {}
            except Exception:
                reg = {}

            def _pick(lst: Any) -> str:
                if not isinstance(lst, list) or not lst:
                    return ""
                best = None
                best_pr = 10**9
                for p in lst:
                    if not isinstance(p, dict):
                        continue
                    pr = p.get("display_priority")
                    try:
                        pr_i = int(pr) if pr is not None else 10**9
                    except Exception:
                        pr_i = 10**9
                    if pr_i < best_pr:
                        best = p
                        best_pr = pr_i
                if not isinstance(best, dict):
                    return ""
                return _provider_display(best.get("provider_name") or "")

            for key in ("flatrate", "free", "ads", "rent", "buy"):
                got = _pick(reg.get(key))
                if got:
                    return got
            return ""

        def _events_for_iso(release_results: Any, iso: str) -> list[dict]:
            out_e: list[dict] = []
            if not isinstance(release_results, list):
                return out_e
            for block in release_results:
                if not isinstance(block, dict):
                    continue
                if (block.get("iso_3166_1") or "").upper() != iso:
                    continue
                for ev in (block.get("release_dates") or []):
                    if not isinstance(ev, dict):
                        continue
                    dt = (ev.get("release_date") or "")[:10]
                    if not dt or len(dt) != 10:
                        continue
                    try:
                        t = int(ev.get("type") or 0)
                    except Exception:
                        t = 0
                    out_e.append(
                        {
                            "date": dt,
                            "type": t,
                            "note": (ev.get("note") or "").strip(),
                        }
                    )
            return out_e

        def _pick_best_event(events: list[dict]) -> dict | None:
            if not events:
                return None
            future = [e for e in events if (e.get("date") or "") >= today]
            past   = [e for e in events if (e.get("date") or "") <  today]

            if future:
                future.sort(key=lambda e: ((e.get("date") or ""), _future_prio(int(e.get("type") or 0))))
                return future[0]

            past.sort(key=lambda e: ((e.get("date") or ""), _past_prio(int(e.get("type") or 0))), reverse=True)
            return past[0] if past else None

        release_blob = data.get("release_dates") or {}
        release_results = release_blob.get("results") if isinstance(release_blob, dict) else []

        watch_blob = data.get("watch/providers") or {}

        chosen_iso = _reg
        events = _events_for_iso(release_results, chosen_iso)
        best = _pick_best_event(events)
        if not best and _fb and _fb != chosen_iso:
            chosen_iso = _fb
            events = _events_for_iso(release_results, chosen_iso)
            best = _pick_best_event(events)

        provider = ""
        if best:
            provider = _extract_provider_from_note(best.get("note") or "")
        if not provider:
            provider = _best_provider_from_watch(watch_blob, chosen_iso)

        if best:
            t_txt = _type_label(int(best.get("type") or 0))
            d_txt = _fmt_date(best.get("date") or "")
            base = f"{t_txt} {chosen_iso} {d_txt}"
            if provider:
                base += f" • {provider}"
            release_badge = f"[{base}]"
        else:
            if provider:
                release_badge = f"[{provider}]"

        out = {
            "runtime": runtime_min,
            "overview": overview,
            "poster_path": data.get("poster_path") or "",
            "backdrop_path": backdrop_path,
            "vote_average": round(float(data.get("vote_average") or 0), 1),
            "vote_count": int(data.get("vote_count") or 0),
            "release_badge": release_badge,
        }
        return out

    def movie_enrich_many(
        self,
        movie_ids: Sequence[Any],
        *,
        region: str = "CZ",
        fallback_region: str = "US",
    ) -> Dict[int, Dict[str, Any]]:
        """Obohacení celého výpisu filmů: {tmdb_id: enrich} (stejný tvar jako `movie_enrich`).

        Dřív výpis (Trendy, TOP, Žánry, hledání) volal `movie_enrich` 40× za sebou: p50 3,8 s, p90 11,7 s
        kolečka navíc (audit A06 F11). Teď: disková cache → chybějící JEDNÍM `POST /v1/tmdb/bulk_fetch`
        (po `BULK_MAX_ITEMS`) → co nepřišlo, doplní stará cache (stale-first). Dotazy po jednom se NEdělají
        ani při selhání (výpadek Gate by je jinak znásobil) — řádek pak jen nemá stopáž/štítek."""
        _reg, _fb = self._enrich_regions(region, fallback_region)
        ids: List[int] = []
        for raw in movie_ids or ():
            try:
                mid = int(raw or 0)
            except (TypeError, ValueError):
                continue
            if mid > 0 and mid not in ids:
                ids.append(mid)
        out: Dict[int, Dict[str, Any]] = {}
        misses: List[int] = []
        for mid in ids:
            cached = self._cache_get(self._enrich_key(mid, _reg, _fb), self.ENRICH_TTL_S)
            if isinstance(cached, dict):
                out[mid] = dict(cached)
            else:
                misses.append(mid)
        fetched = self._bulk_fetch_movies(misses, self.ENRICH_APPEND) if misses else {}
        stale = 0
        for mid in misses:
            key = self._enrich_key(mid, _reg, _fb)
            data = fetched.get(mid)
            if isinstance(data, dict):
                try:
                    enr = self._enrich_from_detail(data, _reg, _fb)
                except Exception as exc:   # projekce nesmí shodit výpis
                    self._log("TMDB_ENRICH_PARSE_ERR", mid, repr(exc)[:120])
                    continue
                out[mid] = enr
                try:
                    self._cache_set(key, enr)
                except Exception:
                    pass
            else:
                old = self._cache_get_stale(key)
                if isinstance(old, dict):
                    out[mid] = dict(old)
                    stale += 1
        self._log("TMDB_ENRICH_MANY", len(ids), len(ids) - len(misses), len(fetched), stale,
                  len(ids) - len(out))
        return out

    def _bulk_fetch_movies(self, movie_ids: Sequence[int], append: Sequence[str]) -> Dict[int, Dict[str, Any]]:
        """{tmdb_id: detail} přes Gate `bulk_fetch` (čtecí POST — opakování jen přechodných chyb transportem,
        429 nikdy). Selhání = {} nebo částečný výsledek; nic se nekešuje jako „nenalezeno“ (R2)."""
        with TMDb._RL_LOCK:
            left = TMDb._RL_COOLDOWN_UNTIL - time.monotonic()
        if left > 0:
            self._log("TMDB_RL_COOLDOWN", f"skip bulk_fetch ({left:.1f}s left)")
            return {}
        try:
            import richmovie_gate_transport as _gt
            import richmovie_http as _rm_http_b
        except Exception as exc:   # pragma: no cover — poškozená instalace
            self._log("TMDB_BULK_ERR", "import", repr(exc)[:120])
            return {}
        # UI cesta (výpis čeká): profil `foreground` jako jeden dotaz TMDb — ne `background` (rozpočet 60 s, 4 pokusy)
        profile = _rm_http_b.profile_foreground()
        result: Dict[int, Dict[str, Any]] = {}
        ids = [int(m) for m in movie_ids]
        for i in range(0, len(ids), self.BULK_MAX_ITEMS):
            chunk = ids[i:i + self.BULK_MAX_ITEMS]
            body = _gt.build_common_fields()
            body["items"] = [{"kind": "movie", "tmdb_id": mid, "lang": self.lang, "append": list(append)}
                             for mid in chunk]
            t0 = time.monotonic()
            try:
                status, resp = _gt.post_json("/v1/tmdb/bulk_fetch", body, profile=profile)
            except Exception as exc:
                self._log("TMDB_BULK_ERR", len(chunk), type(exc).__name__, repr(exc)[:160])
                _diag_log("TMDB_BULK_ERR items=%d err=%s" % (len(chunk), type(exc).__name__),
                          xbmc.LOGWARNING if xbmc else 2,
                          context={"items": len(chunk), "err_class": type(exc).__name__})
                break
            dt_ms = int((time.monotonic() - t0) * 1000)
            if status == 429:
                retry_after = self._parse_retry_after(((resp or {}).get("error") or {}).get("retry_after"))
                with TMDb._RL_LOCK:
                    TMDb._RL_COOLDOWN_UNTIL = time.monotonic() + retry_after
                self._log("TMDB_RL_429", f"cooldown {retry_after:.1f}s (bulk_fetch)")
                break
            results = (resp or {}).get("results") if status == 200 else None
            if not isinstance(results, dict):
                self._log("TMDB_BULK_FAIL", status, dt_ms)
                _diag_log("TMDB_BULK_FAIL status=%s items=%d dt_ms=%d" % (status, len(chunk), dt_ms),
                          xbmc.LOGWARNING if xbmc else 2,
                          context={"status": status, "items": len(chunk), "dt_ms": dt_ms})
                break
            for composite, payload in results.items():
                kind, _, raw_id = str(composite).partition(":")
                try:
                    mid = int(raw_id)
                except ValueError:
                    continue
                if kind == "movie" and isinstance(payload, dict):
                    result[mid] = payload
            self._log("TMDB_BULK_OK", len(chunk), len(results), dt_ms)
        return result









    def trending(self, media_type: str = "movie", period: str = "day",
                limit: int = 20, page: int = 1) -> List[Dict]:
        """
        2025-09-07 09:10 CEST (Europe/Prague)
        Vrátí trending položky pro zadané období, s preferencí latinky v `title`.

        Pozn.:
        - V praxi používáme `media_type="movie"`.
        - Stránkujeme po 20, dokud nedosáhneme `limit` nebo poslední stránky.
        - Logy: `TMDB_PAGE` (průběh), `TMDB_PAGINATE_ERR` (chyba na další stránce).
        """
        if media_type != "movie" or limit <= 0:
            return []

        # Denní JSON cache pro Trendy (TTL 24 h)
        _ttl = 24 * 3600
        # 3.5.131: `page` = počáteční TMDb stránka (stránkování v UI: stránka N
        # výpisu = TMDb stránky 2N-1..2N), klíč cache ji nese — dřív se pro
        # stránku 5 stahovalo 1..200 (cross-check Pro PB8).
        page = max(1, int(page or 1))
        _key = f"trending:{media_type}:{period}:{self.lang}:{page}:{int(limit or 20)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        out: List[Dict] = []
        max_pages = 500

        while len(out) < limit and page <= max_pages:
            params = {"api_key": self.api_key, "language": self.lang, "page": page}
            try:
                data = self._get_json(f"/trending/{media_type}/{period}", params)
            except TMDbError as e:
                # Pokud první stránka spadne, propustíme výjimku; jinak jen zalogujeme a skončíme.
                if page == 1:
                    raise
                self._log("TMDB_PAGINATE_ERR", "trending", media_type, page, str(e))
                break

            results = data.get("results", []) or []
            if not results:
                break

            for r in results:
                title_primary = (r.get("title") or "").strip()
                if not title_primary:
                    continue

                title_final = self._prefer_latin_title(
                    media="movie",
                    _id=int(r["id"]),
                    primary=title_primary,
                    original=(r.get("original_title") or "").strip(),
                )

                out.append(
                    {
                        "id":            r["id"],
                        "title":         title_final,
                        "year":          int((r.get("release_date") or "0000")[:4] or 0),
                        "poster_path":   r.get("poster_path") or "",
                        "backdrop_path": r.get("backdrop_path") or "",
                        "overview":      (r.get("overview") or "").strip(),
                        "rating":        round(float(r.get("vote_average") or 0), 1),
                        "votes":         int(r.get("vote_count") or 0),
                    }
                )
                if len(out) >= limit:
                    break

            # průběžné logování stránkování
            self._log("TMDB_PAGE", "trending", media_type, period, page, len(results), len(out))

            # TMDb typicky vrací 20 na stránku; menší počet znamená poslední stránku.
            if len(results) < 20:
                break
            page += 1

        self._cache_set(_key, out)
        return out






    # ---------------------------------- METODA ---------------------------------- #
    # tmdb_client.py › class TMDb # top_rated (upraveno: 2025-12-23 21:22 CET (Europe/Prague) – denní cache 24h pro TOP filmy)
    # ---------------------------------------------------------------------------- #
    def top_rated(self, page: int = 1, limit: int = 20) -> List[Dict]:
        """
        Nejlépe hodnocené filmy – s preferencí latinkového názvu.
        Stránkujeme od `page` a skládáme výsledky do dosažení `limit`.

        NOVĚ:
        ------
        • Denní JSON cache (TTL 24 h) – TOP filmy se v GUI typicky otevírají často,
          ale data se mění pomalu. Cache výrazně šetří TMDb API a zrychluje menu.
        """
        if limit <= 0:
            return []

        # Denní cache (TTL 24 h)
        _ttl = 24 * 3600
        _page = max(1, int(page or 1))
        _lim = max(1, int(limit or 20))
        _key = f"top_rated:movie:{self.lang}:{_page}:{_lim}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        out: List[Dict] = []
        cur_page = _page
        max_pages = 500

        while len(out) < _lim and cur_page <= max_pages:
            params = {"api_key": self.api_key, "language": self.lang, "page": cur_page}
            try:
                data = self._get_json("/movie/top_rated", params)
            except TMDbError as e:
                if cur_page == _page:
                    # První stránka – propouštíme výjimku
                    raise
                # Další stránka – jen zalogujeme a skončíme
                self._log("TMDB_PAGINATE_ERR", "top_rated", cur_page, str(e))
                break

            results = data.get("results", []) or []
            if not results:
                break

            for r in results:
                title_primary = (r.get("title") or "").strip()
                if not title_primary:
                    continue

                title_final = self._prefer_latin_title(
                    media="movie",
                    _id=int(r["id"]),
                    primary=title_primary,
                    original=(r.get("original_title") or "").strip(),
                )

                out.append(
                    {
                        "id":            r["id"],
                        "title":         title_final,
                        "year":          int((r.get("release_date") or "0000")[:4] or 0),
                        "poster_path":   r.get("poster_path") or "",
                        "backdrop_path": r.get("backdrop_path") or "",
                        "overview":      (r.get("overview") or "").strip(),
                        "rating":        round(float(r.get("vote_average") or 0), 1),
                        "votes":         int(r.get("vote_count") or 0),
                    }
                )
                if len(out) >= _lim:
                    break

            self._log("TMDB_PAGE", "top_rated", cur_page, len(results), len(out))

            if len(results) < 20:
                break
            cur_page += 1

        out = out[:_lim]

        # Ulož do cache (best-effort)
        try:
            self._cache_set(_key, out)
        except Exception:
            pass
        return out




    # ---------------------------------- METODA ---------------------------------- #
    # tmdb_client.py › class TMDb # genres (upraveno: 2025-12-23 21:22 CET (Europe/Prague) – měsíční cache 30 dní)
    # ---------------------------------------------------------------------------- #
    def genres(self) -> List[Dict]:
        """
        Seznam filmových žánrů (id, name).

        NOVĚ:
        ------
        • Měsíční JSON cache (TTL 30 dní) – žánry se prakticky nemění a nemá smysl
          je tahat při každém otevření menu.
        """
        _ttl = 30 * 24 * 3600
        _key = f"genres:movie:{self.lang}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {"api_key": self.api_key, "language": self.lang}
        data   = self._get_json("/genre/movie/list", params)
        out = data.get("genres", []) or []

        try:
            self._cache_set(_key, out)
        except Exception:
            pass
        return out











    def trending_tv(self, period: str = "day", limit: int = 20, page: int = 1) -> List[Dict]:
        """
        2025-09-07 09:10 CEST (Europe/Prague)
        Vrátí „trending" seriály (day/week) – s preferencí latinkového `name`.
        Stránkujeme po 20 záznamech do dosažení `limit`.
        """
        if limit <= 0:
            return []

        # Denní JSON cache pro Trendy TV (TTL 24 h)
        _ttl = 24 * 3600
        page = max(1, int(page or 1))   # 3.5.131: počáteční TMDb stránka (viz trending)
        _key = f"trending:tv:{period}:{self.lang}:{page}:{int(limit or 20)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        out: List[Dict] = []
        max_pages = 500

        while len(out) < limit and page <= max_pages:
            params = {"api_key": self.api_key, "language": self.lang, "page": page}
            path = f"/trending/tv/{period}"
            try:
                data = self._get_json(path, params)
            except TMDbError as e:
                if page == 1:
                    raise
                self._log("TMDB_PAGINATE_ERR", "trending_tv", page, str(e))
                break

            results = data.get("results", []) or []
            if not results:
                break

            for r in results:
                name_primary = (r.get("name") or "").strip()
                if not name_primary:
                    continue

                name_final = self._prefer_latin_title(
                    media="tv",
                    _id=int(r["id"]),
                    primary=name_primary,
                    original=(r.get("original_name") or "").strip(),
                )

                out.append(
                    {
                        "id":            r["id"],
                        "name":          name_final,
                        "year":          int((r.get("first_air_date") or "0000")[:4] or 0),
                        "poster_path":   r.get("poster_path") or "",
                        "backdrop_path": r.get("backdrop_path") or "",
                        "overview":      (r.get("overview") or "").strip(),
                        "rating":        round(float(r.get("vote_average") or 0), 1),
                        "votes":         int(r.get("vote_count") or 0),
                    }
                )
                if len(out) >= limit:
                    break

            self._log("TMDB_PAGE", "trending_tv", period, page, len(results), len(out))

            if len(results) < 20:
                break
            page += 1

        self._cache_set(_key, out)
        return out







    # ---------------------------------- METODA ---------------------------------- #
    # tmdb_client.py › class TMDb # top_rated_tv (upraveno: 2025-12-23 21:22 CET (Europe/Prague) – denní cache 24h pro TOP seriály)
    # ---------------------------------------------------------------------------- #
    def top_rated_tv(self, page: int = 1, limit: int = 20) -> List[Dict]:
        """
        Globální TOP hodnocené seriály – latinkový `name`, zachováno stránkování.

        NOVĚ:
        ------
        • Denní JSON cache (TTL 24 h) – stejné chování jako u TOP filmů.
        """
        if limit <= 0:
            return []

        # Denní cache (TTL 24 h)
        _ttl = 24 * 3600
        _page = max(1, int(page or 1))
        _lim = max(1, int(limit or 20))
        _key = f"top_rated:tv:{self.lang}:{_page}:{_lim}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        out: List[Dict] = []
        cur_page = _page
        max_pages = 500

        while len(out) < _lim and cur_page <= max_pages:
            params = {
                "api_key":  self.api_key,
                "language": self.lang,
                "page":     cur_page,
            }
            try:
                data = self._get_json("/tv/top_rated", params)
            except TMDbError as e:
                if cur_page == _page:
                    raise
                self._log("TMDB_PAGINATE_ERR", "top_rated_tv", cur_page, str(e))
                break

            results = data.get("results", []) or []
            if not results:
                break

            for r in results:
                name_primary = (r.get("name") or "").strip()
                if not name_primary:
                    continue

                name_final = self._prefer_latin_title(
                    media="tv",
                    _id=int(r["id"]),
                    primary=name_primary,
                    original=(r.get("original_name") or "").strip(),
                )

                out.append(
                    {
                        "id":            r["id"],
                        "name":          name_final,
                        "year":          int((r.get("first_air_date") or "0000")[:4] or 0),
                        "poster_path":   r.get("poster_path") or "",
                        "backdrop_path": r.get("backdrop_path") or "",
                        "overview":      (r.get("overview") or "").strip(),
                        "rating":        round(float(r.get("vote_average") or 0), 1),
                        "votes":         int(r.get("vote_count") or 0),
                    }
                )
                if len(out) >= _lim:
                    break

            self._log("TMDB_PAGE", "top_rated_tv", cur_page, len(results), len(out))

            if len(results) < 20:
                break
            cur_page += 1

        out = out[:_lim]
        try:
            self._cache_set(_key, out)
        except Exception:
            pass
        return out






    # ---------------------------------- METODA ---------------------------------- #
    # tmdb_client.py › class TMDb # discover_by_genre (upraveno: 2025-12-23 21:22 CET (Europe/Prague) – denní cache 24h pro žánry)
    # ---------------------------------------------------------------------------- #
    def discover_by_genre(
        self,
        genre_id: int,
        *,
        sort_by: str = "vote_average.desc",
        vote_count_gte: int = 100,
        page: int = 1,
        limit: int = 20,
    ) -> List[Dict]:
        """
        Výpis filmů pro daný žánr s preferencí latinkového `title`.

        Zachováno: parametry `sort_by`, `vote_count.gte`, stránkování přes `page`,
        struktura výstupu a výpočty rating/votes/year.

        NOVĚ:
        ------
        • Denní JSON cache (TTL 24 h) pro „žánrové" menu – v praxi se otevírá často.
        """
        if limit <= 0:
            return []

        _ttl = 24 * 3600
        _gid = int(genre_id or 0)
        _page = max(1, int(page or 1))
        _lim = max(1, int(limit or 20))
        _key = f"discover_genre:{_gid}:{self.lang}:{sort_by}:{int(vote_count_gte or 0)}:{_page}:{_lim}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {
            "api_key":        self.api_key,
            "language":       self.lang,
            "with_genres":    _gid,
            "sort_by":        sort_by,
            "vote_count.gte": int(vote_count_gte or 0),
            "page":           _page,
        }
        data = self._get_json("/discover/movie", params)

        out: List[Dict] = []
        for r in (data.get("results", []) or [])[:_lim]:
            title_primary = (r.get("title") or "").strip()
            if not title_primary:
                continue

            title_final = self._prefer_latin_title(
                media="movie",
                _id=int(r["id"]),
                primary=title_primary,
                original=(r.get("original_title") or "").strip(),
            )

            out.append(
                {
                    "id":            r["id"],
                    "title":         title_final,
                    "year":          int((r.get("release_date") or "0000")[:4] or 0),
                    "poster_path":   r.get("poster_path") or "",
                    "backdrop_path": r.get("backdrop_path") or "",
                    "overview":      (r.get("overview") or "").strip(),
                    "rating":        round(float(r.get("vote_average") or 0), 1),
                    "votes":         int(r.get("vote_count") or 0),
                }
            )

        try:
            self._cache_set(_key, out)
        except Exception:
            pass
        return out













    # --------------------------------------------------------------- #
    #  CAST – TOP N herců
    # --------------------------------------------------------------- #
    def cast(self, movie_id: int, limit: int = 10) -> List[str]:
        """
        Vrátí seznam jmen herců (podle pořadí „billing order")
        z endpointu `/movie/{id}/credits`.

        Args:
            movie_id:  TMDb ID filmu
            limit:     kolik jmen vrátit (default 10)

        Raises:
            TMDbError – při síťové chybě nebo HTTP != 200
        """
        params = {"api_key": self.api_key}
        data   = self._get_json(f"/movie/{movie_id}/credits", params)

        cast: List[str] = [
            c["name"] for c in data.get("cast", [])
            if c.get("name")
        ]
        return cast[:limit]




    # --------------------------------------------------------------- #
    #  ALTERNATIVE TITLES  –  vrací i zemi, abychom mohli filtrovat   #
    # --------------------------------------------------------------- #
    def alternative_titles(self, movie_id: int,
                           *, max_items: int | None = None) -> List[Dict[str, str]]:
        """
        Vrátí seznam alternativních názvů + země původu.

        [{"title": "Cosy Dens", "country": "CA"}, …]
        Duplicitní i prázdné názvy jsou odfiltrovány; pořadí zachováno.
        """
        params = {"api_key": self.api_key}
        data   = self._get_json(f"/movie/{movie_id}/alternative_titles", params)

        out: List[Dict[str, str]] = []
        seen: set[str] = set()

        for rec in data.get("titles", []):
            title = (rec.get("title") or "").strip()
            if not title:
                continue

            norm = unicodedata.normalize("NFKC", title).lower()
            if norm in seen:
                continue
            seen.add(norm)

            out.append({"title": title, "country": rec.get("iso_3166_1", "")})
            if max_items and len(out) >= max_items:
                break
        return out



    def _get_json_cached(self, path: str, params: Dict[str, Any], *, key: str, ttl_s: int,
                         what: str) -> Dict[str, Any]:
        """SSOT (Φ5A, 29.09.2026): odpověď TMDb přes lokální cache s TTL a stale-first degradací.

        Dřív šly `/collection/{id}` a `/movie/{id}/release_dates` na síť při KAŽDÉM hledání filmu (i při
        návratu Zpět) a `release_dates` dokonce dvakrát (alt. stopáže + povolené roky) — ~2,4 s kolečka před
        dialogem (audit A06 F08). Ukládá se jen úspěšná odpověď (dict); selhání se nekešuje (R2)."""
        cached = self._cache_get(key, ttl_s)
        if isinstance(cached, dict):
            return cached
        try:
            data = self._get_json(path, params)
        except TMDbTransientError:
            stale = self._serve_stale(key, what, validator=lambda d: isinstance(d, dict))
            if stale is None:
                raise
            return stale
        if isinstance(data, dict):
            self._cache_set(key, data)
        return data if isinstance(data, dict) else {}

    def _release_dates(self, movie_id: int) -> Dict[str, Any]:
        """`/movie/{id}/release_dates` z cache — jeden zdroj pro alt. stopáže i povolené roky."""
        return self._get_json_cached(
            f"/movie/{int(movie_id)}/release_dates", {"api_key": self.api_key},
            key=f"release_dates:{int(movie_id)}", ttl_s=self.STATIC_META_TTL_S, what="release_dates")

    # --------------------------------------------------------------- #
    #  COLLECTION PARTS – vrací názvy všech filmů v kolekci          #
    # --------------------------------------------------------------- #
    def collection_parts(self, coll_id: int) -> List[str]:
        """
        Načte /collection/{id} (lokální cache, Φ5A) a vrátí list titulů jednotlivých dílů.
        """
        params = {"api_key": self.api_key, "language": self.lang}
        data   = self._get_json_cached(f"/collection/{coll_id}", params,
                                       key=f"collection:{int(coll_id)}:{self.lang}",
                                       ttl_s=self.STATIC_META_TTL_S, what="collection")
        return [p["title"] for p in data.get("parts", []) if p.get("title")]



    def get_alt_runtimes(self, movie_id: int) -> List[int]:
        """
        Vrátí alternativní délky filmu (kino / director’s cut …) v minutách.

        Endpoint `/movie/{id}/release_dates` obsahuje pole `runtime`
        jen u některých releasů; všechny hodnoty sjednotíme do seřazeného listu.
        """
        data   = self._release_dates(movie_id)

        runtimes: set[int] = set()
        for rel in data.get("results", []):
            for rd in rel.get("release_dates", []):
                if (rt := rd.get("runtime")):
                    try:
                        runtimes.add(int(rt))
                    except (TypeError, ValueError):
                        pass          # ignorujeme neplatné hodnoty
        return sorted(runtimes)




    # ---------------------------------- METODA ---------------------------------- #
    # tmdb_client.py › class TMDb
    # allowed_years (upraveno: 31.12.2025 13:48 CET (Europe/Prague) – FIX: skutečná tolerance ±margin i bez výskytu roku v release_dates; zachováno: relevantní země + ladicí log TMDB_ALLOWED_YEARS)
    # ---------------------------------------------------------------------------- #
    def allowed_years(  # 31.12.2025 13:48 CET (Europe/Prague)
        self,
        movie_id: int,
        *,
        primary_year: Optional[int] = None,
        major_markets: Sequence[str] = ("US", "GB", "CA", "DE", "FR", "IT", "ES", "AU", "CZ", "SK"),
        margin: int = 1,
    ) -> List[int]:
        """
        31.12.2025 13:48 CET (Europe/Prague)

        Vrátí „povolené roky vydání" pro film podle TMDb s následující logikou:
        • země = produkční země z `/movie/{id}`  ∪  pevný seznam hlavních trhů
        • pro každou z těchto zemí vezme nejčasnější rok z `/movie/{id}/release_dates`
        • do výstupu pustí roky z release_dates v toleranci ±margin oproti `primary_year`
        • NOVĚ: vždy přidá „hard" toleranci `primary_year ± margin` i když daný rok v `/release_dates` vůbec není
          (řeší rozdíly typu ČSFD uvádí 1964, TMDb 1965 → releasy s (1964) by jinak padaly jako `year_miss`)
        • `primary_year` doplní z detailu, pokud není předán

        Výsledek se použije pouze ve FILTRU releasů (dotazy zůstávají s primárním rokem).
        """
        # 1) detail – produkční země a případně primární rok. Φ5A: `details()` (lokální cache, tentýž
        #    `/movie/{id}`), dřív vlastní dotaz na síť navíc při každém hledání filmu.
        det = self.details(movie_id)  # může vyhodit TMDbError
        prod_codes = {c.get("iso_3166_1", "").upper() for c in det.get("production_countries", []) if c.get("iso_3166_1")}
        if primary_year is None:
            primary_year = int((det.get("release_date") or "0000")[:4] or 0)

        # 2) release_dates – sběr roků pro relevantní země (sdílená cache s `get_alt_runtimes`, Φ5A)
        data = self._release_dates(movie_id)
        relevant = prod_codes | {c.upper() for c in major_markets}
        years_by_country: dict[str, int] = {}

        for rec in data.get("results", []):
            cc = (rec.get("iso_3166_1") or "").upper()
            if cc not in relevant:
                continue
            # nejčasnější datum v dané zemi
            years = []
            for rd in rec.get("release_dates", []):
                d = (rd.get("release_date") or "")[:4]
                if d.isdigit():
                    years.append(int(d))
            if years:
                years_by_country[cc] = min(years)

        # 3) sestavíme whitelist roků v toleranci ±margin
        allowed: set[int] = set()
        forced_span: list[int] = []

        # vždy přidej primary_year (pokud existuje) + hard toleranci ±margin
        if primary_year:
            allowed.add(primary_year)
            if margin and margin > 0:
                for y in range(int(primary_year) - int(margin), int(primary_year) + int(margin) + 1):
                    if y > 0:
                        allowed.add(y)
                        forced_span.append(y)

        # roky z relevantních zemí pustíme jen pokud sedí do tolerance
        for y in years_by_country.values():
            if primary_year and abs(y - primary_year) <= margin:
                allowed.add(y)

        out = sorted(y for y in allowed if y > 0)

        # log pro ladění
        try:
            self._log(
                "TMDB_ALLOWED_YEARS",
                movie_id,
                json.dumps(
                    {
                        "primary_year": primary_year,
                        "production": sorted(prod_codes),
                        "majors": sorted(relevant - prod_codes),
                        "years_by_country": {k: v for k, v in sorted(years_by_country.items())},
                        "forced_span": sorted(set(forced_span)) if forced_span else [],
                        "allowed": out,
                    },
                    ensure_ascii=False,
                ),
            )
        except Exception:
            pass

        return out


    # --------------------------------------------------------------- #
    #  SIMILAR MOVIES – podobne filmy k danemu TMDb ID
    # --------------------------------------------------------------- #
    def similar_movies(self, movie_id: int, limit: int = 20) -> List[Dict]:
        """
        Vraci podobne filmy k danemu TMDb movie ID.
        Pouziva endpoint /movie/{id}/similar, cache 7 dni.
        Vystupni format je kompatibilni s trending() / top_rated().
        """
        if limit <= 0:
            return []

        _ttl = 7 * 24 * 3600  # 7 dni
        _key = f"similar:movie:{int(movie_id)}:{self.lang}:{int(limit)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {"api_key": self.api_key, "language": self.lang, "page": 1}
        try:
            data = self._get_json(f"/movie/{movie_id}/similar", params)
        except TMDbError:
            raise

        out: List[Dict] = []
        for r in (data.get("results") or [])[:limit]:
            title_primary = (r.get("title") or "").strip()
            if not title_primary:
                continue

            title_final = self._prefer_latin_title(
                media="movie",
                _id=int(r["id"]),
                primary=title_primary,
                original=(r.get("original_title") or "").strip(),
            )

            out.append({
                "id":            r["id"],
                "title":         title_final,
                "year":          int((r.get("release_date") or "0000")[:4] or 0),
                "poster_path":   r.get("poster_path") or "",
                "backdrop_path": r.get("backdrop_path") or "",
                "overview":      (r.get("overview") or "").strip(),
                "rating":        round(float(r.get("vote_average") or 0), 1),
                "votes":         int(r.get("vote_count") or 0),
            })

        try:
            self._cache_set(_key, out)
        except Exception:
            pass
        return out


    # --------------------------------------------------------------- #
    #  SIMILAR TV – podobne serialy k danemu TMDb ID
    # --------------------------------------------------------------- #
    def similar_tv(self, tv_id: int, limit: int = 20) -> List[Dict]:
        """
        Vraci podobne serialy k danemu TMDb TV ID.
        Pouziva endpoint /tv/{id}/similar, cache 7 dni.
        Vystupni format je kompatibilni s top_rated_tv().
        """
        if limit <= 0:
            return []

        _ttl = 7 * 24 * 3600  # 7 dni
        _key = f"similar:tv:{int(tv_id)}:{self.lang}:{int(limit)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {"api_key": self.api_key, "language": self.lang, "page": 1}
        try:
            data = self._get_json(f"/tv/{tv_id}/similar", params)
        except TMDbError:
            raise

        out: List[Dict] = []
        for r in (data.get("results") or [])[:limit]:
            name_primary = (r.get("name") or "").strip()
            if not name_primary:
                continue

            name_final = self._prefer_latin_title(
                media="tv",
                _id=int(r["id"]),
                primary=name_primary,
                original=(r.get("original_name") or "").strip(),
            )

            out.append({
                "id":            r["id"],
                "name":          name_final,
                "year":          int((r.get("first_air_date") or "0000")[:4] or 0),
                "poster_path":   r.get("poster_path") or "",
                "backdrop_path": r.get("backdrop_path") or "",
                "overview":      (r.get("overview") or "").strip(),
                "rating":        round(float(r.get("vote_average") or 0), 1),
                "votes":         int(r.get("vote_count") or 0),
            })

        try:
            self._cache_set(_key, out)
        except Exception:
            pass
        return out



# ---------------------------------------------------------------- #
# Phase 3g (2026-04-19) — prewarmed collection bundle helper added
# as a patch on the TMDb class. Kept at module level (not inside the
# class block above) to minimize diff against the legacy implementation.
# ---------------------------------------------------------------- #

BUNDLE_NOT_MODIFIED = "not_modified"   # status výsledku `get_collection_bundle` při 304 (Φ7)


def _tmdb_get_collection_bundle(
    self: "TMDb", slug: str, lang: str = "cs-CZ", etag: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Fetch a prewarmed curated-collection bundle from Gate.

    Replaces ~160 individual ``search`` + ``movie_enrich`` calls per curated
    collection (21 collections × ~160 items = 3500+ calls today) with a
    single HTTP GET that returns the whole collection resolved with full
    TMDb detail.

    Returns the bundle dict or None when:
        - Gate hasn't prewarmed this slug yet (404 bundle_not_prewarmed)
        - transport failure
        - user has no identity (addon not yet authenticated)

    Caller should fall back to the legacy per-item search path in that
    case to preserve functional parity with 2.5.x.

    Φ7 (29.09.2026, audit A09 N6): `etag` = ETag z minulého úspěšného stažení → `If-None-Match`;
    Gate odpoví 304 a vrací se `{"status": BUNDLE_NOT_MODIFIED}` (nic se nestahuje ani neparsuje).
    Úspěšná odpověď nese ETag v `_etag` (None = Gate ho neposlal).
    """
    if not _GATE_AVAILABLE or _gate_get_identity is None:
        return None
    try:
        ws_username, ws_proof = _gate_get_identity()
    except Exception:
        return None
    if not ws_username or not ws_proof:
        return None

    # 3.5.118: zamítnutá identita → žádný request (viz `_get_json`). Bundle je
    # největší payload addonu; 21× ho poslat proti jistému 403 je čistý hluk.
    if _identity is not None and _identity.is_rejected():
        self._log("TMDB_BUNDLE_IDENTITY_FAILFAST", slug, _identity.rejection_reason())
        return None

    url = (
        f"{_GATE_URL}{self.GATE_PROXY_PREFIX}/collection-bundle/"
        f"{urllib.parse.quote(slug, safe='')}"
        f"?lang={urllib.parse.quote(lang)}"
    )
    try:
        _av = xbmcaddon.Addon().getAddonInfo("version") if xbmcaddon else "dev"
    except Exception:
        _av = "dev"
    # UA nutný — CF bot-fight-mode jinak blokuje Python-urllib (viz _get_json).
    headers = {
        "User-Agent": f"RichMovie/{_av} (+plugin.video.richmovie)",
        "Accept": "application/json",
        "X-WS-Username": ws_username,
        "X-WS-Proof": ws_proof,
    }
    if etag:
        headers["If-None-Match"] = etag
    self._log("TMDB_BUNDLE_REQ", slug, lang, "etag" if etag else "-")

    # Φ3 (2026-08-08): profil `bulk` nese TYTÉŽ timeouty, které tu byly natvrdo
    # (Android 20 s / ostatní 30 s) — bundle je největší přenos addonu a krátký
    # timeout by ho na pomalé lince utnul. Nad nimi rozpočet pro retry.
    if _rm_http is None:
        self._log("TMDB_BUNDLE_ERR", slug, "richmovie_http chybi")
        return None

    prof = _rm_http.profile_bulk()
    timeout_s = prof.timeout_s

    # Φ0 (2026-08-08): stejné měření jako v `_get_json` — bundle je největší
    # payload, jaký addon tahá, a právě na něm cloudflared 08.08.2026 v 10:07:12
    # zaznamenal „Incoming request ended abruptly" (klient utnul spojení).
    _t0 = time.monotonic()

    try:
        status, body, _resp_headers = _rm_http.request(
            url, headers=headers, profile=prof, tag="tmdb_bundle",
        )

        if status == 404:
            # 404 = Gate slug ještě nepředehřál. Očekávaný stav, ne chyba →
            # zůstává INFO, ať nezaneřádíme WARNING kanál v `user_logs`.
            self._log("TMDB_BUNDLE_MISS", slug, "not_prewarmed")
            _diag_log(
                "TMDB_BUNDLE_MISS slug=%s not_prewarmed" % slug,
                xbmc.LOGINFO if xbmc else 1,
                context={"slug": slug, "lang": lang, "http_status": 404,
                         "err_class": "permanent"},
            )
            return None

        if _identity is not None:
            # Identita je tu vždy poslána (guard výše) → hook smí soudit.
            _identity.observe_gate_response(status, body, identity_sent=True)

        if status == 304 and etag:
            self._log("TMDB_BUNDLE_NOT_MODIFIED", slug)
            return {"status": BUNDLE_NOT_MODIFIED}

        if status != 200:
            self._log("TMDB_BUNDLE_RESP", slug, status)
            _diag_log(
                "TMDB_BUNDLE_ERR slug=%s status=%s" % (slug, status),
                xbmc.LOGWARNING if xbmc else 2,
                context=_err_context(
                    None, http_status=status, slug=slug, lang=lang,
                    elapsed_ms=int((time.monotonic() - _t0) * 1000),
                    timeout_s=timeout_s,
                ),
            )
            return None

        data = json.loads(body.decode())
        if isinstance(data, dict):
            try:
                data["_etag"] = (_resp_headers.get("ETag") if _resp_headers is not None else None) or None
            except Exception:
                data["_etag"] = None
        self._log(
            "TMDB_BUNDLE_OK", slug,
            data.get("item_count", 0),
            data.get("resolved_count", 0),
            len(body),
        )
        return data

    except Exception as e:
        self._log("TMDB_BUNDLE_ERR", slug, str(e))
        _diag_log(
            "TMDB_BUNDLE_ERR slug=%s %s" % (slug, type(e).__name__),
            xbmc.LOGWARNING if xbmc else 2,
            context=_err_context(
                e, slug=slug, lang=lang,
                elapsed_ms=int((time.monotonic() - _t0) * 1000),
                timeout_s=timeout_s,
            ),
        )
        return None


# Attach as TMDb method (enterprise-clean: public surface stays class-scoped)
TMDb.get_collection_bundle = _tmdb_get_collection_bundle
