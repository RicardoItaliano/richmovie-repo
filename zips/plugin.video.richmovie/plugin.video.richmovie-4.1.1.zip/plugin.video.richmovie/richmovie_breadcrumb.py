# -*- coding: utf-8 -*-
"""RichMovie breadcrumb — durable trasování akcí pro ladění NATIVNÍCH pádů Kodi.

PROČ EXISTUJE (incident 2026-07-01, Martina Šulcová / Android Chromecast)
------------------------------------------------------------------------
Kodi na jejím zařízení tvrdě (nativně) padalo při renderu výsledků hledání —
proces zemřel POD Pythonem, takže `sys.excepthook` (richmovie_crash.py) neměl
co zachytit: nula tracebacků, nula crash_reports, jen opakované boot cykly.
Naše Python telemetrie tak o pádu „nevěděla".

Tento modul zavádí ENTERPRISE-grade diagnostiku, která nativní pád PŘEŽIJE:

  1) DURABLE STOPA (SSOT přes stávající log pipeline)
     Každý breadcrumb se zapíše přes `richmovie_logging` → `richmovie_log_buffer`
     (SQLite WAL, `synchronous=FULL`, `BEGIN IMMEDIATE`/`COMMIT` per insert).
     To znamená: KAŽDÝ breadcrumb je fsync'nutý na disk JEŠTĚ NEŽ se spustí další
     řádek kódu. Když proces vzápětí nativně zemře, poslední úspěšný breadcrumb
     je na disku a drainer (service_nextup) ho po restartu nahraje na Gate.
     → V admin logu pak přesně vidíme, KTERÝ krok Kodi složil.

  2) DETEKCE PÁDU PŘEDCHOZÍ SESSION (convenience flag)
     Malý durable „sentinel" soubor drží PRÁVĚ probíhající akci. `begin_action`
     ho zapíše, `end_action` smaže. Pokud proces nativně zemře uprostřed akce,
     sentinel na disku zůstane „viset". Při startu DALŠÍHO procesu ho
     `detect_prior_crash()` najde a vydá jasný ERROR
     `PRIOR_SESSION_UNCLEAN_EXIT ...` → v adminu filtrovatelné (WARNING+ index).

Vztah obou vrstev: (1) je autoritativní, race-free (každá session má unikátní
`session_id` + monotónní `seq`); (2) je best-effort pohodlný signál. Pro forenzní
analýzu je zdrojem pravdy stopa (1) na Gate.

DESIGN / ZÁRUKY
---------------
• Best-effort filozofie: žádná funkce NIKDY nevyhodí výjimku do volajícího
  (chyba diagnostiky nesmí shodit addon). Vše obalené try/except.
• Zápis sentinelu je atomický + durable: tmp soubor → `flush()` + `os.fsync()`
  → `os.replace()` (atomický rename na stejném FS).
• Sentinel píše VÝHRADNĚ router v plugin.py `__main__` (jedna invokace = jedna
  akce). Služby (service_nextup/service_warm) breadcrumby NEpíší.
• PER-INVOKAČNÍ SENTINELY + PID GUARD (3.5.78 — fix boot race z 3.5.71):
  Kodi spouští plugin invokace jako SUB-INTERPRETRY v jednom OS procesu
  (kodi.exe) — při bootu Home custom UI běží 3-4 raily souběžně. Původní
  jediný sdílený sentinel soubor proto (a) hlásil falešné
  PRIOR_SESSION_UNCLEAN_EXIT (invokace B přečetla 2 ms starý sentinel souběžně
  běžící invokace A) a (b) end_action jedné invokace mazal sentinel jiné
  (okno pro false-negative). Nový design:
    - každá invokace píše VLASTNÍ soubor `crash_sentinel_<id>.json`
      (žádné vzájemné přepisování/mazání),
    - `detect_prior_crash` skenuje všechny sentinely a PŘESKOČÍ ty se
      `pid == os.getpid()`: nativní pád zabíjí CELÝ kodi.exe, takže sentinel
      od aktuálně běžícího PID je z definice souběžná ŽIVÁ invokace, nikdy
      pád (deterministické pravidlo, ne heuristika s časovým oknem),
    - report je „claim-by-remove": kdo úspěšně smaže soubor, ten hlásí →
      žádný double-report mezi souběžnými invokacemi po restartu.
  Známý mez: OS může po restartu Kodi znovu přidělit stejný PID (vzácné);
  pak by se jeden pád nenahlásil. Dopad = 1 zmeškaný convenience signál —
  autoritativní stopa (1) na Gate je nedotčená.

Použití (viz wiring v plugin.py `__main__`):
    import richmovie_breadcrumb as _bc
    _bc.detect_prior_crash()                 # 1× hned po startu procesu
    _bc.begin_action(action, params)         # před dispatch
    try:
        ... dispatch ...
    finally:
        _bc.end_action()                     # po dispatch (čistý konec)

    # volitelné jemné checkpointy uvnitř rizikových cest:
    _bc.checkpoint("list_releases", count=len(rels), ui="new")

Plán: RichMovie-nas/Handoff/PLAN_breadcrumb_native_crash_diag_2026-07-01.md
"""
from __future__ import annotations

import contextlib
import functools
import os
import threading
import time
from pathlib import Path
from typing import Any, Callable, Iterator, Optional, TypeVar

F = TypeVar("F", bound=Callable[..., Any])

# Kodi API — modul musí přežít i mimo Kodi (import v testech nesmí spadnout).
try:
    import xbmcaddon
    import xbmcvfs
except ImportError:  # pragma: no cover - jen mimo Kodi
    xbmcaddon = None  # type: ignore
    xbmcvfs = None  # type: ignore

from richmovie_logging import get_logger, get_session_id


# ---------------------------------------------------------------------------
# Konstanty
# ---------------------------------------------------------------------------
_ADDON_ID = "plugin.video.richmovie"
# Per-invokační sentinel: crash_sentinel_<id>.json (3.5.78). Glob pokrývá i
# legacy jednosouborový `crash_sentinel.json` z 3.5.71-77 (upgrade kompat).
_SENTINEL_PREFIX = "crash_sentinel"
_SENTINEL_GLOB = "crash_sentinel*.json"
_TRACE_LOGGER = "richmovie.trace"

# Max detailních ERROR reportů z jednoho detect_prior_crash (víc leftover
# sentinelů = víc souběžných invokací v momentě pádu; zbytek shrneme).
_DETECT_REPORT_CAP = 5

# Kolik znaků max z jedné hodnoty parametru dáme do stopy (query text apod.).
_PARAM_VALUE_CAP = 80
# Kolik parametrů max serializujeme (ochrana proti nafouknutí kontextu).
_PARAM_KEYS_CAP = 12

# Klíče parametrů, které NIKDY nelogujeme (mohly by nést citlivé/velké hodnoty).
# Redakce v pipeline je defense-in-depth; tady je to prevence na zdroji.
_PARAM_DENYLIST = frozenset({"ws_token", "wst", "token", "rm_token",
                             "password", "pass", "fs_hash", "cookie"})

# Φ0 (29.09.2026, plán PLAN_ux_latency_feedback_20260929): krok uvnitř akce se do
# stopy zapíše, jen když trval aspoň tolik. Odvození, ne odhad:
#   • Kodi samo ukáže kolečko až po 100 ms (adresář, `GUIMediaWindow` Wait(100))
#     a po 220 ms (resolve, `ScriptRunner` 20 + 200 ms) — krok pod polovinou nejkratší
#     z těch prodlev sám o sobě „mrtvé“ čekání nevyrobí;
#   • jeden checkpoint stojí ~2–3 ms (fsync sentinelu + SQLite záznam, audit A08 F11),
#     logovat každý mikrokrok by samo přidávalo latenci, kterou měříme.
STEP_LOG_MIN_MS = 50


# ---------------------------------------------------------------------------
# Stav modulu (per proces)
# ---------------------------------------------------------------------------
_lock = threading.RLock()
_seq = 0                                  # monotónní pořadí breadcrumbů v procesu
_profile_dir: Optional[Path] = None       # cache profil adresáře
_sentinel_path: Optional[Path] = None     # cache cesty k VLASTNÍMU sentinelu
_addon_version: str = ""
_current_action: Optional[str] = None     # akce vlastněná TÍMTO procesem
_proc_start_ts: float = time.time()
# Φ0: monotónní začátek akce — `end_action` z něj sám spočítá `ms` celé akce, takže
# doba nezávisí na párování begin/end v user_logs (session_id tam dřív nesl id dávky).
_action_t0: Optional[float] = None


def _log():
    """Vrátí trace logger (durable pipeline). Best-effort."""
    try:
        return get_logger(_TRACE_LOGGER)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Resolvery (lazy, best-effort)
# ---------------------------------------------------------------------------
def _resolve_profile_dir() -> Optional[Path]:
    """Zjisti addon_data profil dir stejně jako richmovie_logging."""
    if xbmcaddon is None or xbmcvfs is None:
        return None
    try:
        addon = xbmcaddon.Addon(_ADDON_ID)
        global _addon_version
        if not _addon_version:
            try:
                _addon_version = addon.getAddonInfo("version") or ""
            except Exception:
                _addon_version = ""
        return Path(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
    except Exception:
        return None


def _get_profile_dir() -> Optional[Path]:
    global _profile_dir
    with _lock:
        if _profile_dir is not None:
            return _profile_dir
        prof = _resolve_profile_dir()
        if prof is None:
            return None
        try:
            prof.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        _profile_dir = prof
        return _profile_dir


def _invocation_file_id() -> str:
    """Unikátní, filename-safe id TÉTO invokace pro jméno sentinel souboru.

    Primárně session_id z logging pipeline (UUID4 per invokace/sub-interpretr).
    Fallback (pipeline ještě neběží): pid + thread id + µs čas — unikátnost
    stačí na to, aby si dvě souběžné invokace nikdy nesdílely soubor."""
    sid = ""
    try:
        sid = get_session_id() or ""
    except Exception:
        sid = ""
    if sid:
        return "".join(ch for ch in sid if ch.isalnum())[:16]
    return "p%dt%dx%d" % (os.getpid(), threading.get_ident(),
                          int(time.time() * 1000000) % 1000000000)


def _get_sentinel_path() -> Optional[Path]:
    """Cesta k VLASTNÍMU per-invokačnímu sentinelu (cache po první volbě)."""
    global _sentinel_path
    with _lock:
        if _sentinel_path is not None:
            return _sentinel_path
        prof = _get_profile_dir()
        if prof is None:
            return None
        _sentinel_path = prof / ("%s_%s.json"
                                 % (_SENTINEL_PREFIX, _invocation_file_id()))
        return _sentinel_path


def _next_seq() -> int:
    global _seq
    with _lock:
        _seq += 1
        return _seq


def _summarize_params(params: Any) -> dict[str, str]:
    """Zredukuj Kodi params (dict[str, list[str]]) na malý bezpečný slovník.

    • denylist klíčů (tokeny) se vynechá,
    • hodnoty se ořežou na _PARAM_VALUE_CAP,
    • max _PARAM_KEYS_CAP klíčů.
    Nikdy nevyhazuje výjimku.
    """
    out: dict[str, str] = {}
    if not isinstance(params, dict):
        return out
    try:
        for i, (k, v) in enumerate(params.items()):
            if i >= _PARAM_KEYS_CAP:
                break
            kl = str(k)
            if kl.lower() in _PARAM_DENYLIST:
                out[kl] = "[skipped]"
                continue
            if isinstance(v, (list, tuple)):
                val = v[0] if v else ""
            else:
                val = v
            out[kl] = str(val)[:_PARAM_VALUE_CAP]
    except Exception:
        pass
    return out


# ---------------------------------------------------------------------------
# Durable sentinel I/O (atomický + fsync)
# ---------------------------------------------------------------------------
def _write_sentinel(payload: dict[str, Any]) -> None:
    """Atomicky + durable zapiš sentinel (tmp → fsync → os.replace).

    3.5.123: implementace se přestěhovala do SSOT `richmovie_atomic` — byla to
    jediná správná (fsync) z 16 zápisových míst v doplňku a stala se vzorem pro
    všechny ostatní. Sémantika beze změny: nikdy nevyhazuje."""
    path = _get_sentinel_path()
    if path is None:
        return
    try:
        import richmovie_atomic as _atomic
        _atomic.write_json(str(path), payload)
    except Exception:
        pass


def _read_sentinel_file(path: Path) -> Optional[dict[str, Any]]:
    """Přečti a zparsuj konkrétní sentinel soubor. Best-effort → None."""
    try:
        if not path.exists():
            return None
        import json
        with open(str(path), "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _read_sentinel() -> Optional[dict[str, Any]]:
    """Přečti VLASTNÍ per-invokační sentinel (pro checkpoint update)."""
    path = _get_sentinel_path()
    if path is None:
        return None
    return _read_sentinel_file(path)


def _clear_sentinel() -> None:
    """Smaž VLASTNÍ per-invokační sentinel. Cizí soubory se nikdy nemažou
    odsud — o leftovery po pádu se stará výhradně detect_prior_crash
    (claim-by-remove), takže souběžné invokace si sentinely nestomují."""
    path = _get_sentinel_path()
    if path is None:
        return
    try:
        if path.exists():
            os.remove(str(path))
    except Exception:
        pass


def _iter_sentinel_files() -> "list[Path]":
    """Všechny sentinel soubory v profilu (vč. legacy jednosouborového),
    seřazené deterministicky podle jména. Best-effort → prázdný list."""
    prof = _get_profile_dir()
    if prof is None:
        return []
    try:
        return sorted(prof.glob(_SENTINEL_GLOB))
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Veřejné API
# ---------------------------------------------------------------------------
def detect_prior_crash() -> Optional[dict[str, Any]]:
    """Zkontroluj, zda předchozí BĚH Kodi skončil čistě.

    Volat 1× hned po startu invokace (PŘED begin_action). Skenuje všechny
    per-invokační sentinely; „visící" sentinel z JINÉHO OS procesu = předchozí
    kodi.exe zemřel uprostřed akce → ERROR `PRIOR_SESSION_UNCLEAN_EXIT`
    s detaily (akce, poslední fáze, stáří, pid) → v admin logu filtrovatelné
    jako indikace nativního pádu, který Python crash handler nezachytil.

    Race-free pravidla (3.5.78, viz docstring modulu):
      • `sentinel.pid == os.getpid()` → souběžná ŽIVÁ invokace v TOMTO běhu
        Kodi (nativní pád by zabil celý proces) → přeskočit, NEmazat.
      • claim-by-remove: report vydá jen invokace, jejíž `os.remove` uspěl —
        souběžné invokace po restartu tak tentýž pád nenahlásí dvakrát.

    Vrací dict prvního nahlášeného sentinelu, jinak None. Nikdy nevyhazuje.
    """
    try:
        cur_pid = os.getpid()
        now = time.time()
        first_reported: Optional[dict[str, Any]] = None
        reported = 0
        skipped_over_cap = 0

        for path in _iter_sentinel_files():
            prior = _read_sentinel_file(path)
            if not prior:
                # Nečitelný/poškozený soubor: zkus uklidit (claim), ale nehlásit
                # — bez dat by report byl jen šum.
                try:
                    os.remove(str(path))
                except Exception:
                    pass
                continue

            # PID guard: sentinel od aktuálně běžícího kodi.exe = souběžná živá
            # invokace (raily při bootu), nikdy pád. Nesahat na něj.
            try:
                if int(prior.get("pid") or -1) == cur_pid:
                    continue
            except Exception:
                pass

            # Claim-by-remove: kdo soubor smaže, ten hlásí. Prohra = jiná
            # invokace už pád nahlásila → ticho.
            try:
                os.remove(str(path))
            except Exception:
                continue

            if reported >= _DETECT_REPORT_CAP:
                skipped_over_cap += 1
                continue

            started = 0.0
            try:
                started = float(prior.get("started_ts") or 0.0)
            except Exception:
                started = 0.0
            age_s = round(now - started, 1) if started else -1.0

            ctx = {
                "prior_action": prior.get("action"),
                "prior_phase": prior.get("last_phase") or prior.get("phase"),
                "prior_session_id": prior.get("session_id"),
                "prior_pid": prior.get("pid"),
                "prior_addon_version": prior.get("addon_version"),
                "prior_seq": prior.get("seq"),
                "prior_params": prior.get("params"),
                "age_s": age_s,
            }
            log = _log()
            if log is not None:
                log.error(
                    "PRIOR_SESSION_UNCLEAN_EXIT action=%s last_phase=%s age=%ss "
                    "pid=%s ver=%s (nativní pád? — Python crash handler to nezachytil)"
                    % (prior.get("action"), ctx["prior_phase"], age_s,
                       prior.get("pid"), prior.get("addon_version")),
                    extra={"context": ctx},
                )
            reported += 1
            if first_reported is None:
                first_reported = prior

        if skipped_over_cap:
            log = _log()
            if log is not None:
                log.warning(
                    "PRIOR_SESSION_UNCLEAN_EXIT: +%d dalších leftover sentinelů "
                    "(nad cap %d) uklizeno bez detailu"
                    % (skipped_over_cap, _DETECT_REPORT_CAP),
                    extra={"context": {"skipped": skipped_over_cap,
                                        "cap": _DETECT_REPORT_CAP}},
                )

        return first_reported
    except Exception:
        return None


def begin_action(action: str, params: Any = None, **fields: Any) -> None:
    """Označ start uživatelské akce (router dispatch). Zapíše durable breadcrumb
    + sentinel. Vlastnictví akce si drží tento proces (kvůli end_action).

    `fields` (Φ0, 29.09.2026) = měřené údaje startu invokace, typicky `import_ms`
    (doba od prvního řádku `plugin.py` po dispatch) — jdou do zprávy i kontextu."""
    global _current_action, _action_t0
    try:
        seq = _next_seq()
        session_id = ""
        try:
            session_id = get_session_id()
        except Exception:
            session_id = ""
        params_summary = _summarize_params(params)
        _current_action = action
        _action_t0 = time.monotonic()

        sentinel = {
            "action": action,
            "phase": "begin",
            "last_phase": "begin",
            "params": params_summary,
            "session_id": session_id,
            "pid": os.getpid(),
            "addon_version": _addon_version,
            "seq": seq,
            "started_ts": time.time(),
        }
        _write_sentinel(sentinel)

        log = _log()
        if log is not None:
            extra_txt = "".join(" %s=%s" % (k, v) for k, v in fields.items())
            log.info(
                "TRACE action=%s phase=begin seq=%s%s" % (action, seq, extra_txt),
                extra={"context": dict({"action": action, "phase": "begin",
                                        "seq": seq, "params": params_summary}, **fields)},
            )
    except Exception:
        pass


def checkpoint(name: str, **fields: Any) -> None:
    """Jemný checkpoint uvnitř rizikové cesty (např. render N položek).

    Zapíše durable breadcrumb a zaktualizuje `last_phase` v sentinelu — takže
    když proces vzápětí nativně zemře, `detect_prior_crash` v dalším procesu
    nahlásí přesně tuto fázi jako poslední dosaženou."""
    try:
        seq = _next_seq()
        action = _current_action or "?"

        # Aktualizuj last_phase v sentinelu (best-effort; přepíše celý soubor).
        try:
            existing = _read_sentinel()
            if isinstance(existing, dict):
                existing["last_phase"] = name
                existing["last_seq"] = seq
                existing["last_ts"] = time.time()
                _write_sentinel(existing)
        except Exception:
            pass

        log = _log()
        if log is not None:
            # Krátká, greppable message + strukturovaný kontext.
            extra_txt = " ".join("%s=%s" % (k, v) for k, v in fields.items())
            log.info(
                "TRACE action=%s phase=%s seq=%s %s" % (action, name, seq, extra_txt),
                extra={"context": dict({"action": action, "phase": name,
                                        "seq": seq}, **fields)},
            )
    except Exception:
        pass


#: S15 (10.10.2026): vlákno, jehož kroky běží MIMO cestu akce (akce na něj nečeká) — značí ho `background_steps()`.
_thread_ctx = threading.local()
BACKGROUND_SUFFIX = "_bg"


# ---------------------------------- METODA ---------------------------------- #
# richmovie_breadcrumb.py › background_steps
# background_steps  (vytvořeno: 10.10.2026, Europe/Prague — S15)
# ---------------------------------------------------------------------------- #
@contextlib.contextmanager
def background_steps() -> Iterator[None]:
    """Kroky měřené v tomto vlákně (i dekorátorem `timed_step`) se zapíší jako `<krok>_bg` s `bg=1`.

    PROČ (S15): ověření `/auth` na pozadí (menu už stojí z lease) se zapisovalo jako krok `gate_auth` akce `root` —
    na Nokia boxu 645–3 029 ms, takže součet kroků rootu lhal a vypadalo to, že menu čeká na Gate. Jméno kroku
    rozhoduje volající vlákna, ne měřená funkce (tatáž `gate_auth` na popředí blokuje menu a jméno nemění)."""
    prev = getattr(_thread_ctx, "background", False)
    _thread_ctx.background = True
    try:
        yield
    finally:
        _thread_ctx.background = prev


# ---------------------------------- METODA ---------------------------------- #
# richmovie_breadcrumb.py › step
# step  (vytvořeno: 29.09.2026 14:35 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
@contextlib.contextmanager
def step(name: str, **fields: Any) -> Iterator[dict[str, Any]]:
    """Změř blokující krok uvnitř akce (síť, čekání, dialog) — Φ0, plán ux_latency.

    PROČ: TRACE dřív znal jen začátek a konec akce, takže 1,4 s ticha po kliknutí
    na „Pokračovat“ (29.09.2026, pád Kodi) šlo z logu jen odvodit. Krok, který trval
    aspoň `STEP_LOG_MIN_MS`, se zapíše jako checkpoint `phase=step step=<name> ms=<n>`
    (durable, do user_logs). Volající může do vráceného slovníku doplnit výsledek
    kroku (`with step("mi2_wait") as st: … st["reason"] = reason`).

    Nikdy nevyhazuje vlastní výjimku; výjimku z těla kroku propustí beze změny
    a krok zapíše s `error=<typ>`.
    """
    extra: dict[str, Any] = dict(fields)
    if getattr(_thread_ctx, "background", False):   # S15: vlákno mimo cestu akce → vlastní jméno kroku
        name, extra["bg"] = name + BACKGROUND_SUFFIX, 1
    t0 = time.monotonic()
    try:
        yield extra
    except BaseException as exc:
        extra["error"] = type(exc).__name__
        raise
    finally:
        try:
            ms = int((time.monotonic() - t0) * 1000)
            if ms >= STEP_LOG_MIN_MS or "error" in extra:
                checkpoint("step", step=name, ms=ms, **extra)
        except Exception:
            pass


# ---------------------------------- METODA ---------------------------------- #
# richmovie_breadcrumb.py › timed_step
# timed_step  (vytvořeno: 29.09.2026 14:43 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def timed_step(name: str,
               fields: Optional[Callable[..., dict[str, Any]]] = None,
               result_fields: Optional[Callable[[Any], dict[str, Any]]] = None) -> Callable[[F], F]:
    """Dekorátor: celé volání funkce = jeden měřený krok `step(name)` (Φ0).

    `fields(*args, **kwargs)` doplní údaje ze vstupu (např. počet položek),
    `result_fields(result)` údaje z výsledku (např. kód odpovědi). Obě jsou
    best-effort — chyba v nich měření nezruší ani nezmění výsledek funkce.
    Jeden mechanismus místo ručních obalů `_impl` u každé měřené funkce (DRY).
    """
    def decorator(fn: F) -> F:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            extra: dict[str, Any] = {}
            if fields is not None:
                try:
                    extra.update(fields(*args, **kwargs) or {})
                except Exception:
                    pass
            with step(name, **extra) as st:
                result = fn(*args, **kwargs)
                if result_fields is not None:
                    try:
                        st.update(result_fields(result) or {})
                    except Exception:
                        pass
                return result
        return wrapper  # type: ignore[return-value]
    return decorator


def action_elapsed_ms() -> Optional[int]:
    """Kolik ms běží akce této invokace (od `begin_action`); None mimo akci."""
    t0 = _action_t0
    if t0 is None:
        return None
    return int((time.monotonic() - t0) * 1000)


def end_action(ok: bool = True, **fields: Any) -> None:
    """Označ čistý konec akce. Smaže VLASTNÍ per-invokační sentinel (akce
    doběhla bez nativního pádu) a zapíše durable breadcrumb `phase=end`.

    Φ0 (29.09.2026): automaticky přidá `ms` = doba akce od `begin_action`
    (monotónní hodiny procesu) — doba nezávisí na párování záznamů v user_logs."""
    global _current_action, _action_t0
    try:
        seq = _next_seq()
        action = _current_action or "?"
        elapsed = action_elapsed_ms()
        if elapsed is not None and "ms" not in fields:
            fields = dict(fields, ms=elapsed)

        _clear_sentinel()

        log = _log()
        if log is not None:
            extra_txt = " ".join("%s=%s" % (k, v) for k, v in fields.items())
            log.info(
                "TRACE action=%s phase=end ok=%s seq=%s %s"
                % (action, ok, seq, extra_txt),
                extra={"context": dict({"action": action, "phase": "end",
                                        "ok": bool(ok), "seq": seq}, **fields)},
            )
    except Exception:
        pass
    finally:
        _current_action = None
        _action_t0 = None
