# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Webshare SDK + autentizační a GUI helpery
───────────────────────────────────────────────────────────────────────────────
Tento modul slučuje **veškerou** logiku Webshare z původních souborů
`webshare_client.py` a fragmentů v `plugin.py` do jednoho, snadno udržovatelného
místa.

• **WebshareClient** – tenký wrapper nad REST API (původní implementace)
• **_JSONCache**     – lenivá JSON cache (stopáž, alt‑titles)
• **SessionManager** – odpovědný za token, login dialogy a VIP stav v GUI
• back‑compat funkce `_probe_cache_get / _probe_cache_put`

⚠️  DŮLEŽITÉ – VENDORED MediaInfo ⚠️
────────────────────────────────────
Doplněk obsahuje vlastní kopii:

    resources/lib/pymediainfo/
    resources/lib/libmediainfo.*   (Win / Linux x86 / ARM / arm64 …)

* `addon.xml` NESMÍ uvádět `<import addon="script.module.pymediainfo">`,
  aby instalace fungovala i bez repozitáře.
* Níže provádíme import v bloku try/except a uživateli jednou za relaci
  zobrazíme, zda se MediaInfo načetlo (pomáhá při ladění exotických boxů).

Autor: Richie (2023–2025) – refaktor 06/2025
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY  (ABECEDNĚ + tematické skupiny)
# ─────────────────────────────────────────────────────────────────────────────
# — Standardní knihovny —
from __future__ import annotations

import datetime
import hashlib
import json
import os
import threading
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs




# — Lokální / projektové —
import richmovie_settings as _rm_settings
from tmdb_client import TMDbError


# ------------------------------------------------------------------------- #
#  MediaInfo probe - Phase I1 (2026-04-19): delegovano plne na Gate.
#  Addon uz nebundluje libmediainfo ani pymediainfo. Probe logika
#  (ranged download + libmediainfo parsing + container mapping) je
#  drzena centralne na NAS (/v1/mediainfo/probe) a skryta pred GitHubem.
# ------------------------------------------------------------------------- #
MEDIAINFO_AVAILABLE = True  # Gate cesta vzdy dostupna

from richmovie_gate_transport import (
    probe_mediainfo_via_gate as _gate_mi_probe,
    gate_payload_to_legacy_mi as _gate_mi_to_legacy,
)




from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)

# Událostní log hledání: SSOT `richmovie_event_log` (Φ4, 29.09.2026) — dřív `import plugin`, který
# v každé invokaci vykonal tělo plugin.py podruhé a spadl na ImportError (audit A08 F7).
import richmovie_event_log as _rm_event_log

# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
API_URL      = "https://webshare.cz/api/"
# D4 (měřeno 30.09.2026, `WS_LIMIT_PROBE`): jeden požadavek `limit=200` vrátí totéž co dvě stránky po 100 (stejná
# množina i pořadí) — a u populárních dotazů (Matrix, Avatar) druhá stránka `offset=100` vracela PRÁZDNO (API hlásilo
# `total` 92–96), zatímco 200 najednou přišlo. Větší stránka = polovina požadavků a nikdy méně výsledků.
PAGE_SIZE    = 200
ITOA64       = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

PROBE_CHUNK_KB = 256          # kolik KB stáhnout najednou při sondování
PROBE_MAX_MB   = 10           # horní limit dat ke stažení (MB)

# – Cesty k datovým a log souborům –
_ADDON       = xbmcaddon.Addon()
_PROFILE_DIR = Path(
    xbmcvfs.translatePath(f"special://profile/addon_data/{_ADDON.getAddonInfo('id')}")
)
_PROFILE_DIR.mkdir(parents=True, exist_ok=True)

_PROBE_CACHE_PATH      = _PROFILE_DIR / "probe_cache.json"
_ALT_TITLES_CACHE_PATH = _PROFILE_DIR / "alt_titles_cache.json"

_LOG_LOCK = threading.Lock()

# ─────────────────────────────────────────────────────────────────────────────
#  POMOCNÉ LOGOVACÍ FUNKCE
# ─────────────────────────────────────────────────────────────────────────────
# 3.4.x Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _ws_log_router = _make_legacy_logger("richmovie.webshare", "RichMovie/Webshare")
    def _log(msg: str) -> None:
        """Kratky INFO zaznam do Kodi logu + user_logs telemetry."""
        _ws_log_router(msg, level=1)
except Exception:
    def _log(msg: str) -> None:
        xbmc.log(f"[RichMovie] {msg}", xbmc.LOGINFO)


def _log_event(*parts: object) -> None:
    """
    Událost do logu hledání přes SSOT `richmovie_event_log` (zaregistrovaný `plugin._log_event`).
    Bez registrace (mimo plugin, unit‑test) zapisuje lokálně přes `_log()`.
    """
    if _rm_event_log.registered():
        _rm_event_log.log_event(*parts)
    else:
        _log(" | ".join(map(str, parts)))




def _handle_api_error(func, *args, **kwargs):
    """
    Ochranný wrapper: opakuje API volání až 3×, případně přepne jazyk (TMDb).

    Vrací výsledek volání, nebo znovu vyhazuje výjimku po vyčerpání pokusů.
    """
    kwargs = dict(kwargs)  # kopie – aby fallback lang neovlivnil volajícího
    max_retries = 3
    for attempt in range(1, max_retries + 1):
        try:
            return func(*args, **kwargs)
        except (APIError, TMDbError) as e:
            _log_event("API_ERROR", f"{func.__name__} attempt {attempt}: {e}")
            if attempt == max_retries:
                raise
            # speciální fallback pro TMDb – zkus EN
            if isinstance(e, TMDbError):
                kwargs["lang"] = "en-US"





def _probe_log(event: str, *params: object) -> None:
    """
    **Trvalý** logger pro sondování stopáže.

    ▸ vždy zapíše do rotačního logu (`richmovie_search.log`)  
    ▸ paralelně zapisuje i do souboru s příponou `.probe`
    """
    # 1) stopa v hlavním logu
    _log_event(event, *params)

    # 2) cesta k `.probe` souboru (sdílená s plugin.py)
    # 2b) Φ4: cesta přes SSOT registr (dřív `_plg_mod`, v invokacích kvůli padajícímu `import plugin` None)
    log_path = (
        _rm_event_log.current_log_path()
        or xbmcvfs.translatePath("special://logpath/richmovie/fallback")
    ) + ".probe"

    # 3) zápis (thread‑safe)
    ts   = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = "\t".join([ts, event, *map(str, params)])
    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with _LOG_LOCK:
            with open(log_path, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except Exception:
        pass            # log nesmí nikdy shodit doplněk


def _credentials_read_failed() -> bool:
    """True JEN když je PROKÁZÁNO, že se přihlašovací údaje nepřečetly.

    Rozdíl proti „údaje chybí" je zásadní: chybějící údaje znamenají, že se má
    uživatel přihlásit, kdežto nepřečtené znamenají poruchu — a v tom případě se
    nesmí nic mazat ani se na nic ptát (pravidlo R2, incident bandog 27.08.2026).

    Rozhoduje `richmovie_settings.diagnose_read()`, tedy porovnání dvou nezávislých
    cest ke stejné hodnotě (Kodi API vs. přímé čtení `settings.xml`) — ne odhad.
    Při jakékoli nejistotě vrací False, aby se běžné přihlašování nezablokovalo.
    """
    try:
        import richmovie_settings as _s
        for key in ("username", "password"):
            if _s.diagnose_read(key).get("verdict") == _s.VERDICT_READ_FAILURE:
                return True
    except Exception:
        pass
    return False

# ─────────────────────────────────────────────────────────────────────────────
#  CACHE (lenivá JSON implementace)
# ─────────────────────────────────────────────────────────────────────────────
class _JSONCache:
    """
    Lenivě načítaná JSON cache *bez* proudového zápisu – uloží se jen při změně.

    Parametry
    ---------
    path : Path
        Soubor, do kterého se cache ukládá.
    """

    def __init__(self, path: Path) -> None:
        self._path   = path
        self._data   : dict[str, object] = {}
        self._loaded = False
        self._lock   = threading.Lock()

    # – interní –
    def _load(self) -> None:
        if self._loaded:
            return
        with self._lock:
            if self._loaded:
                return
            try:
                with open(self._path, "r", encoding="utf-8") as fh:
                    self._data = json.load(fh)
            except Exception:
                self._data = {}
            self._loaded = True

    def _flush(self) -> None:
        try:
            with self._lock:
                with open(self._path, "w", encoding="utf-8") as fh:
                    json.dump(self._data, fh, ensure_ascii=False, indent=2)
        except Exception as exc:
            _log(f"Cache flush failed: {exc}")

    # – veřejné API –
    def get(self, key: str) -> Optional[object]:
        self._load()
        return self._data.get(key)

    def put(self, key: str, value: object) -> None:
        self._load()
        self._data[key] = value
        self._flush()                   # okamžitý zápis → minimální riziko kolize



    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_webshare.py › class _JSONCache # clear (vytvořeno: 13.12.2025 11:39 CET, Europe/Prague – bezpečné vymazání JSON cache (RAM+disk))
    # ---------------------------------------------------------------------------- #
    def clear(self) -> None:
        """
        Vymaže cache (RAM i disk).

        Použití:
            • nextup_cache.json (epizody / Next-Up)
            • případně další JSON cache v doplňku

        Pozn.:
            _flush() používá interní lock, takže v clear() NEDRŽÍME lock při volání _flush().
        """
        try:
            self._load()
            with self._lock:
                self._data = {}
                self._loaded = True
            # zapiš prázdnou cache na disk
            self._flush()
        except Exception:
            # best effort – nikdy nesmí shodit doplněk
            pass





    def __len__(self) -> int:          # syntactic sugar → ``len(cache)``
        self._load()
        return len(self._data)


# Konkrétní cache instance (stopáž, alternativní názvy)
_ProbeCache     = _JSONCache(_PROBE_CACHE_PATH)
_AltTitlesCache = _JSONCache(_ALT_TITLES_CACHE_PATH)

# Back‑compat helpery (plugin.py na ně stále odkazuje)
def probe_cache_get(fid: str) -> Optional[int]:
    """Vrátí délku videa (sekundy) z cache nebo ``None``."""
    val = _ProbeCache.get(fid)
    return int(val) if isinstance(val, int) else None


def probe_cache_put(fid: str, seconds: int) -> None:
    """Uloží délku videa do cache."""
    _ProbeCache.put(fid, int(seconds))

# ─────────────────────────────────────────────────────────────────────────────
#  KRYPTOGRAFIE  (Webshare používá proprietární MD5‑crypt)
# ─────────────────────────────────────────────────────────────────────────────
def _to64(v: int, l: int) -> str:
    """Interní převodník pro MD5‑crypt."""
    s = ""
    while l:
        s += ITOA64[v & 0x3F]
        v >>= 6
        l -= 1
    return s


def md5_crypt(pw: str, salt: str, magic: str = "$1$") -> str:
    """
    Minimalistická implementace **MD5‑crypt** (nutná pro `/api/login/`).

    • Zkrácená a optimalizovaná verze – plně kompatibilní s PHP implementací  
    • Nekryptografická bezpečnost zde není kritická (hash posíláme po HTTPS)
    """
    salt = salt.split("$")[0][:8]
    pw_b = pw.encode()

    ctx = hashlib.md5()
    ctx.update(pw_b + magic.encode() + salt.encode())

    alt = hashlib.md5(pw_b + salt.encode() + pw_b).digest()
    for i in range(len(pw_b)):
        ctx.update(alt[i % 16 : i % 16 + 1])

    i = len(pw_b)
    while i:
        ctx.update(b"\x00" if i & 1 else pw_b[:1])
        i >>= 1

    final = ctx.digest()
    for i in range(1000):
        m = hashlib.md5()
        m.update(pw_b if i & 1 else final)
        if i % 3:
            m.update(salt.encode())
        if i % 7:
            m.update(pw_b)
        m.update(final if i & 1 else pw_b)
        final = m.digest()

    parts = (
        (final[0] << 16) | (final[6] << 8) | final[12],
        (final[1] << 16) | (final[7] << 8) | final[13],
        (final[2] << 16) | (final[8] << 8) | final[14],
        (final[3] << 16) | (final[9] << 8) | final[15],
        (final[4] << 16) | (final[10] << 8) | final[5],
        final[11],
    )
    enc = (
        _to64(parts[0], 4)
        + _to64(parts[1], 4)
        + _to64(parts[2], 4)
        + _to64(parts[3], 4)
        + _to64(parts[4], 4)
        + _to64(parts[5], 2)
    )
    return f"{magic}{salt}${enc}"

# ─────────────────────────────────────────────────────────────────────────────
#  VÝJIMKY KLIENTA
# ─────────────────────────────────────────────────────────────────────────────
class APIError(Exception):
    """Obecná chyba Webshare API (network error, HTTP 500…).

    3.5.125: nese `code` (např. `LOGIN_FATAL_1`, `FILE_INFO_FATAL_1`, nebo ""
    u síťové chyby), aby volající rozhodovali podle TYPU/KÓDU, nikdy podle
    textu zprávy (pravidlo SÍŤOVÁ VRSTVA: `"timeout" in str(e)` je zakázáno).
    """

    def __init__(self, message: str = "", code: str = "") -> None:
        super().__init__(message)
        self.code = code or ""

    @property
    def is_authoritative_login_failure(self) -> bool:
        """Webshare odmítl přihlášení (špatné jméno/heslo) — ne síť, ne 5xx."""
        return self.code.startswith("LOGIN_FATAL")

    # Kódy Webshare API → česká věta pro uživatele (3.5.129, cross-check Flash F36:
    # do UI nikdy technický text). Zdroj: webshare.cz/apidoc (file_link, login).
    _USER_MESSAGES = {
        "FILE_LINK_FATAL_1": "Webshare tento soubor už nemá (byl smazán).",
        "FILE_LINK_FATAL_3": "Soubor je chráněný heslem.",
        "FILE_LINK_FATAL_4": "Soubor je na Webshare dočasně nedostupný – zkus jiný stream.",
        "FILE_LINK_FATAL_5": "Webshare hlásí příliš mnoho běžících stahování na více zařízeních.",
        "FILE_LINK_FATAL_6": "Soubor není veřejný (pravděpodobně chráněný obsah).",
        "LOGIN_FATAL_1": "Webshare odmítl přihlášení – zkontroluj jméno a heslo.",
        "LOGIN_INTERACTIVE_REQUIRED": "Přihlášení k Webshare vypršelo – otevři RichMovie a přihlas se znovu.",
        "HTTP_429": "Webshare teď brzdí příliš mnoho požadavků – zkus to za chvíli.",
    }

    @property
    def user_message(self) -> str:
        """Věta pro dialog: podle KÓDU Webshare (ne textu); síťová chyba a
        neznámý kód dostanou obecné, ale srozumitelné znění."""
        if self.code in self._USER_MESSAGES:
            return self._USER_MESSAGES[self.code]
        if self.code.startswith("LOGIN_FATAL"):
            return self._USER_MESSAGES["LOGIN_FATAL_1"]
        if not self.code:
            return "Webshare právě neodpovídá (síťová chyba) – zkus to za chvíli."
        return "Webshare požadavek odmítl (kód %s)." % self.code


class RateLimited(APIError):
    """Webshare odpověděl HTTP 429 (brzdí požadavky). S2 (10.10.2026): dřív `richmovie_http` vrátil 429 bez výjimky
    a `_post` parsoval tělo, které není XML → `ParseError` bez stavu — brzdění nešlo poznat podle TYPU. Podtřída
    `APIError`: stávající obsluha („síťová chyba“, vlna hledání pokračuje) se nemění, nový kód může rozlišit."""


class TokenExpired(APIError):
    """Vypršela relace – je nutné se znovu přihlásit."""

# ─────────────────────────────────────────────────────────────────────────────
#  KLIENT WEBSHARE  (původní implementace beze změny)
# ─────────────────────────────────────────────────────────────────────────────
class WebshareClient:
    """
    Lehký wrapper nad REST API Webshare.cz
    -------------------------------------

    • login() / search() / file_info() / file_link()  
    • probe_duration() – přesný odhad stopáže (MediaInfo + HTTP range)  
    • get_alt_titles() – heuristická extrakce alternativních názvů
    """

    # ––– bootstrap MediaInfo knihovny (funguje na *všech* platformách) –––
    # ──────────────────────────────────────────────────────────────────
    #  KONSTRUKTOR
    # ──────────────────────────────────────────────────────────────────
    def __init__(self, token: str | None = None) -> None:
        """Phase I1 (2026-04-19): simplified ctor. Probe se dela na
        Gate, takze addon uz nebootstrapuje libmediainfo, neresi
        Android lib sandbox ani neprobira resources/bin kandidaty."""
        self.token = token
        self._library_file: str | None = None  # legacy placeholder



    def file_info_duration(self, ident: str) -> int | None:
        """
        Nejrychlejší cesta k délce videa – / api/file_info vrací <video_length>
        v sekundách.  Vrací int nebo None, nechytá výjimky.
        """
        root = self._post("file_info", ident=ident)
        try:
            secs = int(root.findtext("video_length", "0") or 0)
            return secs or None
        except ValueError:
            return None




    # ------------------------------------------------------------------ #
    #  Phase I1 (2026-04-19): libmediainfo DLL detection ODSTRANENA.
    #  Probe jde pres Gate /v1/mediainfo/probe, zadne platform mapping,
    #  zadne Android sandbox copy, zadne ctypes.CDLL preload.
    # ------------------------------------------------------------------ #




    # --------------------------------------------------------------------- #
    def _post(self, func: str, **params):
        """Interní helper: POST → XML → ElementTree.

        Vytvořeno/aktualizováno: 21.12.2025 19:38 CET (Europe/Prague)

        PRIORITA A – stabilita (Chromecast/Android):
          • Pokud Kodi ruší invoker (`abortRequested=True`), MUSÍME skončit okamžitě,
            jinak Kodi po ~5 s addon killne („script didn't stop in 5 seconds“).
          • Na Androidu používáme kratší HTTP timeouty, aby blokující síťový call
            nepřekročil kill okno (a neblokoval přehrávání / UI).
        """
        # Abort = okamžitý konec (BaseException, neodchytí se přes `except Exception`)
        try:
            if xbmc.Monitor().abortRequested():
                raise SystemExit
        except Exception:
            pass

        if self.token:
            params["wst"] = self.token
        data = urllib.parse.urlencode(params).encode()
        url  = f"{API_URL}{func}/"

        # Android: agresivnější timeout (typicky 4 s), jinde necháváme původní 15 s.
        timeout_s: float = 15.0
        try:
            if xbmc.getCondVisibility("system.platform.android"):
                timeout_s = 4.0
        except Exception:
            timeout_s = 15.0

        # Φ3b (2026-08-08): transport přes SSOT retry vrstvu (`richmovie_http`).
        # Timeout zůstává na dosavadních hodnotách (Android 4 s / ostatní 15 s) —
        # nad ně se přidává jen rozpočet, takže rychlé síťové chyby dostanou druhý
        # pokus, kdežto timeout ne.
        #
        # `idempotent=True` navzdory metodě POST: Webshare API se tu používá
        # výhradně pro ČTENÍ a přihlášení — `search`, `file_info`, `file_link`,
        # `user_data`, `salt`, `session`. Ani jedna z nich nemění stav účtu, takže
        # zopakování nemůže nic zdvojit. Kdyby sem přibyla zapisující funkce
        # (mazání, sdílení), MUSÍ dostat vlastní větev bez retry.
        try:
            import richmovie_http as _rm_http
        except Exception as _imp_exc:  # pragma: no cover
            _log(f"richmovie_http chybi: {_imp_exc!r}")
            raise APIError("Síťová chyba") from _imp_exc

        try:
            profile = _rm_http.profile_foreground().replace(timeout_s=timeout_s)
            _status, raw, _hdrs = _rm_http.request(
                url, method="POST", data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                profile=profile, idempotent=True, tag="webshare",
            )
            body = raw.decode()
        except Exception as e:
            _log(f"HTTP error: {e}")
            raise APIError("Síťová chyba") from e
        if _status == 429:
            # 429 se NIKDY neopakuje (`richmovie_http`) a tělo není XML API → typovaná chyba, ne `ParseError` (S2)
            _log(f"API {func}: HTTP 429 — Webshare brzdí požadavky")
            raise RateLimited("Webshare brzdí požadavky", "HTTP_429")

        root = ET.fromstring(body)
        if root.findtext("status") != "OK":
            code = root.findtext("code") or "ERR"
            msg  = root.findtext("message") or "Unknown"
            # Obogacení logu o ident (pokud volající předal v paramech) —
            # umožní tracovat konkrétní failed stream z Webshare.
            ident_hint = params.get("ident") if isinstance(params, dict) else None
            ident_frag = f" ident={ident_hint}" if ident_hint else ""
            _log(f"API {func} fail: {code} – {msg}{ident_frag}")
            if code in ("SESSION_EXPIRED", "INVALID_TOKEN"):
                raise TokenExpired(msg, code)
            raise APIError(msg, code)
        return root










    # --------------------------------------------------------------------- #
    #                    VEŘEJNÉ API METODY
    # --------------------------------------------------------------------- #
    def login(self, user: str, pw: str) -> str:
        """Přihlášení – uloží a vrátí token."""
        salt   = self._post("salt", username_or_email=user).findtext("salt", "")
        digest = hashlib.sha1(md5_crypt(pw, salt).encode()).hexdigest()

        self.token = self._post(
            "login",
            username_or_email=user,
            password=digest,
            keep_logged_in=1,
        ).findtext("token", "")
        _log("login OK")
        return self.token

    # ------------------------------------------------------------------ #
    def account_info(self) -> dict:
        """Vrátí základní info o uživateli (VIP, kredit…)."""
        root = self._post("user_data")
        return {
            "username":  root.findtext("username", "") or "",
            "email":     root.findtext("email", "") or "",
            "vip":       root.findtext("vip", "0") == "1",
            "vip_days":  int(root.findtext("vip_days", "0") or 0),
            "vip_until": root.findtext("vip_until", "") or "",
            "credit":    int(root.findtext("credit", "0") or 0),
        }

    # ------------------------------------------------------------------ #
    def session_info(self) -> dict:
        """Vrátí info o aktuální session (IP, platforma, klient)."""
        root = self._post("session")
        return {
            "ip_address": root.findtext("ip_address", "") or "",
            "browser":    root.findtext("browser", "") or "",
            "platform":   root.findtext("platform", "") or "",
        }

    # ------------------------------------------------------------------ #
    def file_link(
        self,
        ident: str,
        download_type: str | None = "video_stream",
        force_https: int = 1,
    ) -> str:
        """Vrátí přímý (VIP) odkaz na stream nebo download."""
        params = {"ident": ident, "force_https": force_https}
        if download_type:
            params["download_type"] = download_type
        return self._post("file_link", **params).findtext("link", "")

    # ------------------------------------------------------------------ #
    def file_info(self, ident: str) -> dict:
        """Detail souboru (viz `/api/file_info/`)."""
        root = self._post("file_info", ident=ident)
        _to_int = lambda x: int(x or 0)
        return {
            "ident":           ident,
            "name":            (root.findtext("name") or "").strip(),
            "size":            _to_int(root.findtext("size")),
            "password":        root.findtext("password", "0") == "1",
            "hash":            root.findtext("hash", ""),
            "video_length":    _to_int(root.findtext("video_length")),
            "video_width":     _to_int(root.findtext("video_width")),
            "video_height":    _to_int(root.findtext("video_height")),
            "audio_channels":  _to_int(root.findtext("audio_channels")),
            "positive_votes":  _to_int(root.findtext("positive_votes")),
            "negative_votes":  _to_int(root.findtext("negative_votes")),
            "downloads":       _to_int(root.findtext("downloads")),
            "created":         root.findtext("created", ""),
        }

    # ------------------------------------------------------------------ #
    def search(
        self,
        query: str,
        *,
        limit: int = PAGE_SIZE,
        offset: int = 0,
        file_type: str = "video",
    ) -> list[dict]:
        """Vyhledá soubory a vrátí list slovníků s metadata."""
        root = self._post(
            "search",
            what=query,
            offset=offset,
            limit=limit,
            category=file_type,
        )

        files: list[dict] = []
        raw = root.findall("file")
        removed = 0
        for f in raw:
            if f.findtext("removed") == "1":
                removed += 1
                continue
            files.append(
                {
                    "ident":          f.findtext("ident", ""),
                    "name":           (f.findtext("name") or "").strip(),
                    "size":           int(f.findtext("size", "0") or 0),
                    "password":       f.findtext("password", "0") == "1",
                    "video_length":   int(f.findtext("video_length", "0") or 0),
                    "video_width":    int(f.findtext("video_width", "0") or 0),
                    "video_height":   int(f.findtext("video_height", "0") or 0),
                    "positive_votes": int(f.findtext("positive_votes", "0") or 0),
                    "negative_votes": int(f.findtext("negative_votes", "0") or 0),
                }
            )
        # surový počet + smazané (D4, 30.09.2026): bez nich nejde poznat, zda prázdná stránka je konec výsledků,
        # nebo stránka plná smazaných souborů; `total` = celkový počet podle API (je-li v odpovědi)
        _log(f'search "{query}" offset={offset} limit={limit} → {len(files)} files '
             f'(raw={len(raw)} removed={removed} total={root.findtext("total", "?")})')
        return files





    # ------------------------------------------------------------------ #
    # richmovie_webshare.py › class WebshareClient
    # probe_duration (upraveno: 21.12.2025 19:38 CET (Europe/Prague) – PRIORITA A: abort-safe + kratší timeouty na Androidu)
    # ------------------------------------------------------------------ #
    #  MediaInfo probe (Phase I1, 2026-04-19) - Gate-only.
    #  Zadny lokalni libmediainfo, zadne ranged chunk parsing v addonu.
    #  Gate /v1/mediainfo/probe dela celou heavy-lift pipeline + cache.
    # ------------------------------------------------------------------ #

    def probe_duration(self, ident: str) -> Optional[int]:
        """Duration-only fast probe. Phase I1 (2026-04-19) - Gate-side.

        Postup:
          1) probe_cache (in-memory + disk)
          2) Webshare /file_info/ video_length (nejlevnejsi)
          3) Gate /v1/mediainfo/probe (ranged + libmediainfo na NAS)
        """
        try:
            if xbmc.Monitor().abortRequested():
                raise SystemExit
        except Exception:
            pass

        cached = probe_cache_get(ident)
        if cached is not None:
            _probe_log("PROBE_CACHE_HIT", ident, cached)
            return cached

        try:
            finfo = self.file_info(ident)
        except APIError:
            return None
        if finfo.get("video_length"):
            secs = int(finfo["video_length"])
            probe_cache_put(ident, secs)
            _probe_log("PROBE_API_LEN", ident, secs)
            return secs

        try:
            url = self.file_link(ident, download_type=None)
        except APIError:
            return None
        if not url:
            return None
        payload = _gate_mi_probe("ws", ident, url, probe_max_mb=5)
        if payload is None:
            return None
        dur = payload.get("duration_sec")
        if dur:
            probe_cache_put(ident, int(dur))
            _probe_log("PROBE_GATE_LEN", ident, dur)
            return int(dur)
        return None


    def probe_mediainfo(self, ident: str) -> dict | None:
        """Full MediaInfo probe. Phase I1 (2026-04-19) - Gate-side.

        Vraci legacy {"duration": sec, "tracks": [pymediainfo-like]}
        shape pro zpetnou kompatibilitu s mi2._extract().
        """
        try:
            if xbmc.Monitor().abortRequested():
                raise SystemExit
        except Exception:
            pass

        try:
            url = self.file_link(ident, download_type=None)
        except APIError:
            return None
        if not url:
            return None

        payload = _gate_mi_probe("ws", ident, url)
        if payload is None:
            _probe_log("PROBE_MI_GATE_FAIL", ident)
            return None

        data_out = _gate_mi_to_legacy(payload)
        _probe_log(
            "PROBE_MI_OK_GATE",
            ident, data_out.get("duration"),
            len(data_out.get("tracks", [])),
        )
        return data_out


    # ------------------------------------------------------------------ #
    #  Phase I1 (2026-04-19): lokalni incremental parse helper ODSTRANEN.
    #  Gate ranged-downloaduje + parsuje v jednom shot pres
    #  /v1/mediainfo/probe.
    # ------------------------------------------------------------------ #




    # ------------------------------------------------------------------ #
    def get_alt_titles(self, tmdb_id: str | int) -> list[str]:
        """
        Vrátí *alternativní názvy* filmu podle TMDb ID.

        • Nejprve zkusí lokální cache  
        • Pak heuristicky prohledá Webshare (``search()``) a výsledek uloží
        """
        fid = str(tmdb_id)
        cached = _AltTitlesCache.get(fid)
        if cached:
            return list(cached)            # type: ignore[arg-type]

        alt: set[str] = set()
        try:
            for f in self.search(fid, limit=50):
                alt.add(f["name"])
        except Exception as exc:
            _log_event("ALT_TITLES_FAIL", fid, exc)

        titles = sorted(alt)
        _AltTitlesCache.put(fid, titles)
        _log_event("ALT_TITLES_CACHE_PUT", fid, len(titles))
        return titles


# ─────────────────────────────────────────────────────────────────────────────
#  KONTROLA ODKAZU PŘED PŘEHRÁNÍM (3.5.129, incident PeterFM 02.09.2026)
# ─────────────────────────────────────────────────────────────────────────────
# Webshare `file_link` vrátí status OK a odkaz i tehdy, když odkaz NEvydá video:
# Free účet (HTML stránka místo souboru), „soubor dočasně nedostupný", limit
# zařízení, čerstvě smazaný soubor. Kodi pak otevře HTML a ukáže vlastní dialog
# „Přehrávání selhalo" — bez jediného řádku v našem logu. Tahle kontrola se ptá
# CDN ze ZAŘÍZENÍ (odkaz je vázaný na účet/IP — Gate proba pro to není důkaz,
# nález N2 incidentu) jedním ohraničeným požadavkem a rozhodne PŘED
# `setResolvedUrl`. Fail-open: transport/timeout/5xx → hrát (nezdržovat start).
LINK_OK = "ok"                 # 200/206 + Content-Type není HTML/JSON → předat Kodi
LINK_NOT_MEDIA = "not_media"   # HTML/JSON tělo nebo CDN 4xx → autoritativně nepřehratelné
LINK_UNKNOWN = "unknown"       # transport, timeout, 5xx, 429 → nevíme, Kodi si poradí

# Content-Type, které nikdy nejsou video (zrcadlo Gate `probe._NOT_MEDIA_CONTENT_TYPES`).
_LINK_NOT_MEDIA_CONTENT_TYPES = ("text/html", "application/xhtml+xml", "application/json")
# CDN říká „tenhle odkaz nemá obsah" — 404/410 dostane i Kodi se stejnou URL.
# 401/403 sem NEPATŘÍ (cross-check Pro 02.09.2026, PB4/PB9): autorizační odpověď
# může záviset na hlavičkách/Range a Kodi by přehrálo → fail-open (LINK_UNKNOWN).
_LINK_REJECTED_HTTP_STATUS = (404, 410)
# Kolik bajtů těla si vyžádat: HTML stránka i hlavička videa se vejdou; strop
# `max_bytes` v `richmovie_http` chrání, když CDN Range ignoruje a pošle 200.
_LINK_CHECK_RANGE_BYTES = 1024
_LINK_CHECK_MAX_BYTES = 4096
# Timeouty = dosavadní profil Webshare (Android 4 s / jinde 15 s) — viz `_post`.
# Bez retry rozpočtu: kontrola má stát jeden RTT, ne oddalovat start videa.
_LINK_CHECK_TIMEOUT_ANDROID_S = 4.0
_LINK_CHECK_TIMEOUT_DEFAULT_S = 6.0
# Záložní UA jen mimo Kodi (harness); v Kodi se bere `xbmc.getUserAgent()` — kontrola
# musí jít na CDN se STEJNOU identitou, jakou pak pošle přehrávač (Pro 02.09.2026, PB5).
_LINK_CHECK_UA_FALLBACK = "Kodi/21.0 (RichMovie linkcheck)"


def _link_check_user_agent() -> str:
    """User-Agent shodný s Kodi přehrávačem (`xbmc.getUserAgent()`), jinak fallback."""
    try:
        ua = xbmc.getUserAgent()
        if isinstance(ua, str) and ua.strip():
            return ua.strip()
    except Exception:
        pass
    return _LINK_CHECK_UA_FALLBACK
# Hláška pro uživatele, když CDN odmítl všechny kandidáty (VIP účet) — SSOT textu,
# `plugin._resolve_webshare_stream` ji jen zobrazí. Bez technických detailů.
LINK_NOT_MEDIA_MESSAGE = (
    "Stream nejde přehrát",
    "Webshare tento soubor právě nevydá – může být dočasně nedostupný, smazaný, "
    "nebo běží limit současně používaných zařízení. Zkus jiný stream.",
)


# Začátky těla, které jsou značkovací text, ne kontejner videa. Video kontejnery
# začínají binárními signaturami (EBML `1A 45 DF A3`, MP4 `....ftyp`, AVI `RIFF`,
# TS `0x47`) — HTML/XML/JSON stránka začíná po bílých znacích jedním z těchto tokenů.
_MARKUP_PREFIXES = (b"<!doctype", b"<html", b"<?xml", b"<head", b"<body", b"{\"", b"[{")


def looks_like_markup(head: bytes) -> bool:
    """Čistý sniff prvních bajtů těla: HTML/XML/JSON stránka místo videa.

    Fable audit 03.09.2026 (F-01): Content-Type stránky, kterou Webshare posílá
    Free účtu / při limitu zařízení, nikdo nikdy neviděl — CDN běžně posílá
    typ odvozený z názvu souboru (`video/x-matroska`) i pro chybovou stránku.
    Tělo už je v paměti (ohraničené `max_bytes`), takže sniff je zdarma a chytí
    i to, co Content-Type zamlčí. BOM a bílé znaky se přeskočí; porovnání je
    case-insensitive. Binární data (video) nikdy nezačínají `<` ani `{`.
    """
    if not head:
        return False
    sample = bytes(head[:512])
    if sample.startswith(b"\xef\xbb\xbf"):
        sample = sample[3:]
    sample = sample.lstrip(b" \t\r\n").lower()
    return any(sample.startswith(p) for p in _MARKUP_PREFIXES)


def classify_stream_response(status: int, content_type: str | None,
                             body_head: bytes = b"") -> str:
    """Čistá klasifikace odpovědi CDN na ohraničený GET (harness scénář 48).

    Stejná pravidla jako Gate `probe.classify_response_not_media` + navíc 404/410,
    protože tady se ptá ZAŘÍZENÍ stejnou URL, jakou dostane Kodi:
      • 404/410 → NOT_MEDIA (odkaz nemá obsah; Kodi by dostalo totéž),
      • 200/206 + HTML/JSON Content-Type NEBO tělo začínající značkou → NOT_MEDIA
        (chybová stránka místo videa; sniff těla kryje generický Content-Type, F-01),
      • 200/206 jinak → OK,
      • cokoli jiného (401/403, 416, 429, 5xx, 3xx bez follow) → UNKNOWN (fail-open).
    """
    try:
        st = int(status or 0)
    except (TypeError, ValueError):
        st = 0
    if st in _LINK_REJECTED_HTTP_STATUS:
        return LINK_NOT_MEDIA
    if st not in (200, 206):
        return LINK_UNKNOWN
    ct = (content_type or "").split(";", 1)[0].strip().lower()
    if ct and any(ct == t or ct.startswith(t + "+") for t in _LINK_NOT_MEDIA_CONTENT_TYPES):
        return LINK_NOT_MEDIA
    if looks_like_markup(body_head):
        return LINK_NOT_MEDIA
    return LINK_OK


def validate_stream_link(url: str, *, opener=None, probe: bool = False, report_failures: bool = True) -> dict:
    """Ověří ze zařízení, že `url` vydá médium. Vrací slovník pro log i rozhodnutí:
        {"verdict": LINK_OK|LINK_NOT_MEDIA|LINK_UNKNOWN, "status": int,
         "content_type": str, "host": str, "dt_ms": int, "detail": str}

    `probe=True` (3.5.151, Fable F1): kontrola cesty ke zdroji po výpadku sítě (služba před
    navázáním) je zdravotní sonda — projde otevřeným breakerem `richmovie_netstate` a úspěch
    vrátí stav do ONLINE. Bez toho by po výpadku Gate zůstal breaker zavřený i pro CDN.

    Jeden požadavek přes SSOT vrstvu `richmovie_http` (žádný přímý `urlopen`),
    `max_attempts=1` = žádné retry (kontrola je informace, ne doručení), tělo
    ohraničené `max_bytes`. Transportní chyba → UNKNOWN (fail-open), technický
    text výjimky zůstává v logu, nikdy nejde do UI. Nikdy nevyhazuje
    (kromě `SystemExit` = Kodi ruší invoker).
    """
    import time as _time
    try:
        import richmovie_http as _rm_http
    except Exception as _imp_exc:  # pragma: no cover
        _log(f"linkcheck: richmovie_http chybi: {_imp_exc!r}")
        return {"verdict": LINK_UNKNOWN, "status": 0, "content_type": "",
                "host": "", "dt_ms": 0, "detail": "no_http_layer"}

    host = ""
    try:
        host = urllib.parse.urlsplit(url).hostname or ""
    except Exception:
        host = ""

    timeout_s = _LINK_CHECK_TIMEOUT_DEFAULT_S
    try:
        if xbmc.getCondVisibility("system.platform.android"):
            timeout_s = _LINK_CHECK_TIMEOUT_ANDROID_S
    except Exception:
        pass

    t0 = _time.monotonic()
    try:
        profile = _rm_http.profile_foreground().replace(timeout_s=timeout_s, max_attempts=1)
        status, _body, hdrs = _rm_http.request(
            url, method="GET",
            # `Connection: close` — spojení z kontroly nesmí zůstat viset jako
            # „běžící stahování" u Webshare (FILE_LINK_FATAL_5; Pro 02.09.2026, PB6).
            headers={"Range": f"bytes=0-{_LINK_CHECK_RANGE_BYTES - 1}",
                     "User-Agent": _link_check_user_agent(),
                     "Accept-Encoding": "identity", "Connection": "close"},
            profile=profile, idempotent=True, tag="ws_linkcheck", probe=bool(probe),
            report_failures=bool(report_failures),
            opener=opener, max_bytes=_LINK_CHECK_MAX_BYTES,
        )
    except SystemExit:
        raise
    except Exception as exc:
        dt_ms = int((_time.monotonic() - t0) * 1000)
        _log(f"linkcheck: transport err host={host} dt={dt_ms}ms err={type(exc).__name__}: {exc}")
        return {"verdict": LINK_UNKNOWN, "status": 0, "content_type": "", "host": host,
                "dt_ms": dt_ms, "detail": type(exc).__name__}

    dt_ms = int((_time.monotonic() - t0) * 1000)
    content_type = ""
    try:
        if hdrs is not None:
            content_type = str(hdrs.get("Content-Type") or hdrs.get("content-type") or "")
    except Exception:
        content_type = ""
    head = bytes(_body or b"")[:512]
    verdict = classify_stream_response(status, content_type, head)
    markup = looks_like_markup(head)
    if markup and verdict != LINK_NOT_MEDIA:
        # 3xx/4xx bez Content-Type s HTML tělem (login stránka CDN): Kodi by HTML „přehrálo".
        # Tělo je autoritativní důkaz, že to není médium (cross-check T3 Pro P5).
        verdict = LINK_NOT_MEDIA
    detail = "markup_body" if (verdict == LINK_NOT_MEDIA and markup) else ""
    return {"verdict": verdict, "status": int(status or 0),
            "content_type": content_type.split(";", 1)[0].strip().lower(),
            "host": host, "dt_ms": dt_ms, "detail": detail}


# Varianta hlášky, když stav účtu ještě neexistuje (čistá instalace) a všechny
# odkazy vydaly stránku: příčina je nejspíš Free účet, ale autoritativně to
# nevíme → říct obojí a vyžádat obnovu stavu (Fable audit 03.09.2026, F-14).
LINK_NOT_MEDIA_MESSAGE_NO_STATE = (
    "Stream nejde přehrát",
    "Webshare místo videa vrátil stránku – buď účtu vypršel VIP, nebo je soubor "
    "dočasně nedostupný / smazaný. Zkus jiný stream; stav účtu se právě obnovuje.",
)

# Výsledky `resolve_playable_stream` (klíč "kind" při ok=False) — uzavřený výčet.
RESOLVE_KIND_LOGIN_FAILED = "login_failed"
RESOLVE_KIND_NOT_MEDIA = "not_media"
RESOLVE_KIND_API_ERROR = "api_error"


def link_and_info(client, ident: str):
    """`(file_link, file_info)` jednoho identu — obě volání SOUBĚŽNĚ (Φ6, 29.09.2026, audit A05 R5a/F7).

    Obě jen čtou a `file_info` potřebuje jen ident (délka, velikost, název jdou až do ListItemu), takže
    není důvod čekat na odkaz: dřív za sebou ~0,35–0,5 s p50 na každém startu z Webshare. `_post` je
    bezstavový (požadavek = vlastní spojení), klient se smí volat ze dvou vláken. Výjimka se hlásí ve
    stejném pořadí jako dřív (nejdřív `file_link`), `SystemExit` (abort Kodi) z vlákna projde beze změny.
    Vlákno není daemon (HTTP v Kodi — feedback_daemon_threads_kodi); `join` čeká nejvýš timeout dotazu."""
    box = {}

    def _info() -> None:
        try:
            box["info"] = client.file_info(ident)
        except BaseException as exc:   # noqa: B902 — přenos do volajícího vlákna, včetně SystemExit
            box["exc"] = exc

    worker = threading.Thread(target=_info, name="RMWsFileInfo", daemon=False)
    worker.start()
    try:
        url = client.file_link(ident)
    finally:
        worker.join()
    if "exc" in box:
        raise box["exc"]
    return url, box.get("info")


def resolve_playable_stream(client, ident: str, fallback_list, *, ensure_login,
                            mark_not_media, log, net_error_message, account_state,
                            interactive: bool = True) -> dict:
    """Vrátí přehratelný Webshare odkaz pro `ident` (nebo první fallback), nebo důvod.

    3.5.129 (incident PeterFM 02.09.2026): Webshare `file_link` vrátí OK + odkaz i
    Free účtu, ale odkaz servíruje HTML stránku → Kodi „Přehrávání selhalo" bez
    jediného našeho logu. Tři vrstvy, každá s vlastním SSOT:
      1. `account_state.playback_allowed` — Free účet = nehrát, říct proč
         (0 síťových volání; blokuje JEN autoritativní stav z Webshare, R2).
      2. `validate_stream_link` — jeden ohraničený GET ze ZAŘÍZENÍ: HTML/JSON
         (Content-Type nebo sniff těla) či 404/410 = odkaz zahodit, zkusit další
         kandidát, zapsat lokální marker MI2; transport/401/403/5xx = fail-open.
      3. Fallback identy (autoplay pořadí) se zkouší stejnou cestou — dřív jen
         při `APIError` primárního identu, HTML odkaz fallback nikdy nedostal.

    Závislosti jsou INJEKTOVANÉ (Fable audit F-07: testovatelnost bez Kodi):
      client            WebshareClient s tokenem
      ensure_login(c, interactive)   login při TokenExpired (plugin `_ensure_login`);
                        `interactive=False` = autoplay bez uživatele → žádný dialog
      mark_not_media(ident, check)   lokální MI2 marker (plugin `_mi2_mark_not_media`)
      log(msg, level)   logger pluginu (WARNING/INFO úrovně z `xbmc`)
      net_error_message(exc) → (text, transient)   richmovie_helpers
      account_state     modul richmovie_account_state

    Návrat (dict, nikdy výjimka kromě SystemExit):
      ok=True : url, finfo, vid_len, ident (skutečně použitý), check
      ok=False: kind ∈ {ws_free, login_failed, not_media, api_error}, heading, message,
                silent (True = dialog už ukázal někdo jiný, volající ho neopakuje)
    Každá cesta má log: PLAY_BLOCKED / PLAY_LINK_REJECTED / PLAY_FILE_LINK_FAIL (WARNING)
    a PLAY_RESOLVED source=webshare (INFO) — parita s Fastshare.
    """
    warn = getattr(xbmc, "LOGWARNING", 2)
    info = getattr(xbmc, "LOGINFO", 1)

    # 1) Free účet → nehrát, vysvětlit. Bez sítě, bez file_link.
    state = account_state.load()
    allowed, block_reason = account_state.playback_allowed(state, source="webshare")
    if not allowed:
        heading, text = account_state.free_block_message(state)
        log(f"PLAY_BLOCKED reason={block_reason} ident={ident} "
            f"user={(state or {}).get('username') or '-'}", warn)
        # Uživatel právě mohl VIP obnovit: požádat službu o obnovu stavu (brzda
        # 120 s je v `refresh_now`), ať blokace nepřežije platbu déle, než musí.
        account_state.request_refresh(account_state.REASON_FREE)
        return {"ok": False, "kind": block_reason, "heading": heading, "message": text,
                "silent": False}

    candidates = [ident] + [x for x in (fallback_list or []) if x and x != ident]
    last_api_error = None
    rejected_links = 0

    for idx, cand in enumerate(candidates):
        # 2) Odkaz + délka z Webshare API (TokenExpired → interaktivní login, jako dřív)
        try:
            url, finfo = link_and_info(client, cand)     # Φ6: souběžně
        except TokenExpired:
            # Jen PŘIHLÁŠENÍ má vlastní větev (Pro PB13): chyba `file_link`/`file_info`
            # po úspěšném loginu je chyba odkazu, ne účtu — nesmí posílat měnit heslo.
            try:
                ensure_login(client, interactive)
            except Exception as e2:
                log(f"PLAY_LOGIN_FAILED ident={cand} interactive={int(bool(interactive))} "
                    f"err={type(e2).__name__}: {e2}", warn)
                # Interaktivní `ensure_login` pluginu při APIError dialog UŽ ukázal
                # (F-04) → silent; v autoplay (interactive=False) dialog nikdo neukázal
                # a ani nesmí — volající dá jen notifikaci (3.5.130, Pro PB7).
                if isinstance(e2, APIError):
                    # brzdění (429) dialog neukázal nikdo — `ensure_login` ho propouští bez dotazu na heslo (S2)
                    return {"ok": False, "kind": RESOLVE_KIND_LOGIN_FAILED,
                            "heading": "Přihlášení k Webshare", "message": e2.user_message,
                            "silent": bool(interactive) and not isinstance(e2, RateLimited)}
                why, _transient = net_error_message(e2)
                return {"ok": False, "kind": RESOLVE_KIND_LOGIN_FAILED,
                        "heading": "Přihlášení k Webshare", "message": why, "silent": False}
            try:
                url, finfo = link_and_info(client, cand)
            except RateLimited as e:
                last_api_error = e
                log(f"PLAY_FILE_LINK_RATELIMITED ident={cand} fallback_idx={idx} after_relogin=1 — další kandidáti se "
                    f"nezkouší (429 se neopakuje)", warn)
                break
            except APIError as e:
                last_api_error = e
                log(f"PLAY_FILE_LINK_FAIL ident={cand} code={getattr(e, 'code', '') or '-'} "
                    f"err={e} fallback_idx={idx} after_relogin=1", warn)
                continue
        except RateLimited as e:
            # S2 (cross-check Codex #4): Webshare brzdí → další kandidát = další požadavek do téhož brzdění; 429 se
            # NIKDY neopakuje (pravidlo síťové vrstvy) → konec smyčky, divák dostane větu „Webshare teď brzdí…“
            last_api_error = e
            log(f"PLAY_FILE_LINK_RATELIMITED ident={cand} fallback_idx={idx} — další kandidáti se nezkouší", warn)
            break
        except APIError as e:
            last_api_error = e
            log(f"PLAY_FILE_LINK_FAIL ident={cand} code={getattr(e, 'code', '') or '-'} "
                f"err={e} fallback_idx={idx}", warn)
            continue
        if not url:
            last_api_error = last_api_error or APIError("Webshare nevrátil odkaz na soubor.")
            log(f"PLAY_FILE_LINK_EMPTY ident={cand} fallback_idx={idx}", warn)
            continue

        # 3) Kontrola odkazu ze zařízení — HTML místo videa se Kodi nikdy nepředá.
        check = validate_stream_link(url)
        if check.get("verdict") == LINK_NOT_MEDIA:
            rejected_links += 1
            log(f"PLAY_LINK_REJECTED ident={cand} host={check.get('host') or '-'} "
                f"status={check.get('status')} ct={check.get('content_type') or '-'} "
                f"detail={check.get('detail') or '-'} dt_ms={check.get('dt_ms')} "
                f"fallback_idx={idx}", warn)
            mark_not_media(cand, check)
            continue

        try:
            vid_len = int((finfo or {}).get("video_length") or 0)
        except (TypeError, ValueError):
            vid_len = 0
        log(f"PLAY_RESOLVED source=webshare ident={cand} host={check.get('host') or '-'} "
            f"status={check.get('status')} ct={check.get('content_type') or '-'} "
            f"verdict={check.get('verdict')} dt_ms={check.get('dt_ms')} "
            f"fallback_idx={idx} vid_len={vid_len}", info)
        if idx > 0:
            log(f"Fallback OK: {cand}", info)
        return {"ok": True, "url": url, "finfo": finfo or {}, "vid_len": vid_len,
                "ident": cand, "check": check}

    # 4) Nic nešlo přehrát — hláška podle toho, CO selhalo (žádný technický text z CDN).
    if rejected_links and last_api_error is None:
        if state is None:
            # Čistá instalace bez stavu účtu: příčina může být Free → obnovit stav (F-14).
            account_state.request_refresh(account_state.REASON_NO_STATE)
            heading, text = LINK_NOT_MEDIA_MESSAGE_NO_STATE
        else:
            heading, text = LINK_NOT_MEDIA_MESSAGE
        return {"ok": False, "kind": RESOLVE_KIND_NOT_MEDIA, "heading": heading,
                "message": text, "silent": False}
    if last_api_error is not None:
        # Česká věta podle kódu Webshare (`APIError.user_message`), ne text API.
        return {"ok": False, "kind": RESOLVE_KIND_API_ERROR, "heading": "Přehrání selhalo",
                "message": last_api_error.user_message, "silent": False}
    heading, text = LINK_NOT_MEDIA_MESSAGE
    return {"ok": False, "kind": RESOLVE_KIND_NOT_MEDIA, "heading": heading,
            "message": text, "silent": False}

# ─────────────────────────────────────────────────────────────────────────────
#  SESSION MANAGER  (token + GUI helpery)
# ─────────────────────────────────────────────────────────────────────────────
class SessionManager:
    """
    Vyšší vrstva nad **WebshareClient** zajišťující:

    • získání klienta s uloženým tokenem  
    • login (tichý i interaktivní) s dialogem a retry  
    • aktualizaci VIP stavu v titulku hlavního menu
    """

    def __init__(self, addon: xbmcaddon.Addon, handle: int) -> None:
        self._addon  = addon
        self._handle = handle
        self.client  = WebshareClient(_rm_settings.get_ws_token())

    # ───────────────────────────────────────────────────────────────────
    #  LOGIN WORKFLOW
    # ───────────────────────────────────────────────────────────────────
    def relogin(self, *, interactive: bool = False) -> None:
        """Webshare autoritativně řekl `SESSION_EXPIRED` → uložený token je mrtvý.
        (3.5.130, Fable audit N1: `ensure_login` platný-vypadající token jen znovu
        nasadil a nikdy nepřihlásil → `TokenExpired` při přehrání se neopravil ani
        ručně, protože Gate `ws_verify_failed` od Σ1 nevrací.)

        Pořadí: smazat token (R2: SESSION_EXPIRED je autoritativní odpověď zdroje
        pravdy) → tichý login z uložených údajů → při neúspěchu a `interactive`
        klasický dialog (`ensure_login`), jinak `APIError` bez dialogu (autoplay).
        """
        self.client.token = None
        _rm_settings.set_ws_token("")
        _log_event("WEB_SHARE_TOKEN_EXPIRED", "token smazán, relogin interactive=%s" % int(bool(interactive)))
        user = _rm_settings.get_ws_username() or ""
        pw = _rm_settings.get_ws_password() or ""
        if user and pw:
            try:
                self.client.login(user, pw)
                _rm_settings.set_ws_token(self.client.token)
                _log_event("WEB_SHARE_RELOGIN_OK_SILENT")
                return
            except RateLimited as e:
                # brzdění není špatné heslo: žádný dialog s heslem, věta „Webshare teď brzdí…“ (cross-check Codex #4)
                _log_event("WEB_SHARE_RELOGIN_RATELIMITED", str(e))
                raise
            except APIError as e:
                _log_event("WEB_SHARE_RELOGIN_SILENT_FAIL", str(e))
                if e.is_authoritative_login_failure and not interactive:
                    raise
        if not interactive:
            raise APIError("Přihlášení k Webshare vypršelo a bez zásahu uživatele ho nejde obnovit.",
                           "LOGIN_INTERACTIVE_REQUIRED")
        self.ensure_login(interactive=True)

    def ensure_login(
        self, *, interactive: bool = False, max_attempts: int = 3
    ) -> None:
        """
        Zajistí platný token – může zobrazit přihlašovací dialog.
        Logika vychází z původního _ensure_login().
        """
        user  = _rm_settings.get_ws_username() or ""
        pw    = _rm_settings.get_ws_password() or ""
        token = _rm_settings.get_ws_token() or ""

        # 1) Chybí přihlašovací údaje, ale token máme.
        #
        # 3.5.120 — ZMĚNA CHOVÁNÍ (incident bandog 27.08.2026, pravidlo R2
        # „selhání se neperzistuje"):
        # Do 3.5.119 se token v tomhle stavu bez ptaní SMAZAL a tok pokračoval do
        # interaktivní větve — uživateli se otevřela klávesnice a addon po něm chtěl
        # Webshare heslo. Jenže prázdné `user`/`pw` neznamená „uživatel nemá účet";
        # může to být PORUCHA ČTENÍ nastavení (přesně to se stalo). Zahodit kvůli ní
        # platný token je perzistence selhání a navíc vede k žádosti o údaje, které
        # zařízení ve skutečnosti má.
        #
        # Nově: rozhodne diagnostika (dvě nezávislé cesty ke stejné hodnotě).
        #   • PROKÁZANÁ porucha čtení → token NEMAZAT, žádný dialog, hlasitě zalogovat
        #     a skončit. Volající dostane token z předchozí session (self.client.token
        #     zůstává), takže přehrávání běží dál.
        #   • Prokazatelně nenastaveno → původní chování (token je sirotek, zahodit).
        # Token smí zmizet jen na autoritativní odpověď (Webshare `LOGIN_FATAL_*`,
        # Gate `AUTH_TOKEN_INVALID`) — ta se řeší jinde, ne tady.
        if token and (not user or not pw):
            if _credentials_read_failed():
                _log_event(
                    "LOGIN_CRED_READ_FAILURE",
                    "nastaveni se neprecetlo – token PONECHAN, dialog potlacen",
                )
                self.client.token = token
                return
            _log_event("LOGIN_ORPHAN_TOKEN", "token smazán – chybí cred")
            token = ""
            _rm_settings.set_ws_token("")

        # 2) hotovo (token + cred)
        if token and user and pw:
            self.client.token = token
            return

        # 3) tichý login
        if user and pw:
            self.client.token = None
            try:
                self.client.login(user, pw)
                _rm_settings.set_ws_token(self.client.token)
                _notify("Úspěšně přihlášeno k Webshare.cz")
                _log_event("WEB_SHARE_LOGIN_OK_SILENT")
                return
            except RateLimited as e:
                # 429 = Webshare brzdí, údaje jsou v pořádku → NEPTAT se na heslo (cross-check Codex #4, S2)
                _log_event("WEB_SHARE_LOGIN_RATELIMITED", str(e))
                raise
            except APIError as e:
                _log_event("WEB_SHARE_LOGIN_SILENT_FAIL", str(e))
                # padáme na interaktivní dialog

        # 4) interaktivní kolečko
        #
        # 3.5.120: než otevřeme klávesnici, ujisti se, že údaje opravdu CHYBÍ.
        # Ptát se uživatele na heslo kvůli tomu, že si addon nepřečetl vlastní
        # nastavení, je nejhorší možná reakce — údaje na zařízení jsou, jen
        # nejsou vidět. Guard je i tady (nejen u větve s tokenem), protože sem
        # vede cesta i ze stavu bez tokenu.
        if _credentials_read_failed():
            _log_event(
                "LOGIN_CRED_READ_FAILURE",
                "nastaveni se neprecetlo – interaktivni prihlaseni potlaceno",
            )
            raise APIError(
                "Nepodařilo se načíst přihlašovací údaje. Restartuj prosím Kodi."
            )

        if not interactive:
            interactive = True

        attempt = 0
        while attempt < max_attempts:
            user, pw = self._prompt_credentials()
            if not user or not pw:
                raise APIError("Přihlášení zrušeno uživatelem.")

            try:
                self.client.login(user, pw)
            except RateLimited as err:
                # brzdění: další pokus s heslem by jen přidal požadavek do téhož brzdění (429 se neopakuje) → konec
                _log_event("WEB_SHARE_LOGIN_RATELIMITED", "interactive", str(err))
                xbmcgui.Dialog().ok("Webshare přihlášení", err.user_message)
                raise
            except APIError as err:
                attempt += 1
                _log_event("WEB_SHARE_LOGIN_FAIL", f"attempt {attempt}", str(err))

                # ── NOVÉ: pouze 2 parametry ─────────────────────────
                # Česká věta podle kódu Webshare, technický text jen v logu (F-04/F36).
                msg = err.user_message
                if attempt < max_attempts:
                    msg += "\nZkuste to prosím znovu."
                xbmcgui.Dialog().ok("Webshare přihlášení", msg)
                # ----------------------------------------------------
                continue
            else:
                # 3.5.124: identita All-or-Nothing s ověřením zpětným čtením.
                # Kodi umí zápis tiše ztratit (Addon.cpp: SaveSettings vrací
                # success i při selhání serializace) — dřív by uživatel viděl
                # „Úspěšně přihlášeno" a při příštím startu dostal dialog znovu.
                if not _rm_settings.write_identity(user, pw, self.client.token):
                    _log_event("WEB_SHARE_LOGIN_SAVE_FAILED", user)
                    raise APIError(
                        "Přihlášení proběhlo, ale nepodařilo se ho uložit. "
                        "Restartuj prosím Kodi a zkus to znovu."
                    )
                _notify("Úspěšně přihlášeno k Webshare.cz")
                _log_event("WEB_SHARE_LOGIN_OK_INTERACTIVE")
                return

        raise APIError("Nepodařilo se přihlásit k Webshare.cz.")





    def update_vip_status(self) -> Optional[dict]:
        """Titulek root menu ze STAVU účtu — bez jediného síťového volání.

        3.5.125 (Fáze A, audit 29.08.2026): do 3.5.124 tady byl blokující dotaz
        na Webshare (15 s timeout) při každém vykreslení a při timeoutu větev
        „OFFLINE": toast, `sleep(4000)`, `Action(Back)` a zápis přechodného
        stavu sítě do nastavení jako dat o účtu (porušení R2). Nově:
          • stav čte `richmovie_account_state.load()` (stale-first),
          • offline rozhoduje výhradně `richmovie_netstate` (SSOT konektivity),
          • když je obnova na řadě (podle STAVU, ne TTL), jen se VYŽÁDÁ Window
            property — provede ji služba mimo UI vlákno a mimo 5s okno pluginu.
        Vrací načtený stav (volající ho použije pro denní toast) nebo None.
        """
        import richmovie_account_state as _account
        try:
            import richmovie_netstate as _netstate
            offline = bool(_netstate.is_offline())
        except Exception:
            offline = False

        state = _account.load()
        if self._handle >= 0:
            try:
                xbmcplugin.setPluginCategory(self._handle, _account.title(state, offline=offline))
            except Exception:
                pass

        due, reason = _account.refresh_due(state)
        if due and not offline:
            _account.request_refresh(reason)
        _log_event("VIP_STATUS", _account.days_left(state) if state else "unknown",
                   "refresh=%s" % (reason or "-"))
        return state


    # ----------------------------------------------------------------- #
    def _prompt_credentials(self) -> tuple[str | None, str | None]:
        """
        Jednoduchý dialog s Kodi klávesnicí.

        Vrací: (username, password) – může obsahovat ``None``, pokud uživatel
        stiskl *Cancel*.
        """
        user = _keyboard_input("Uživatelské jméno Webshare")
        if not user:
            return None, None
        pw = _keyboard_input("Heslo k Webshare", hidden=True)
        if not pw:
            return None, None
        return user, pw









# ─────────────────────────────────────────────────────────────────────────────
#  MALÉ POMOCNÉ FUNKCE (UI, notifikace, klávesnice)
# ─────────────────────────────────────────────────────────────────────────────
def _keyboard_input(heading: str, hidden: bool = False) -> str | None:
    kb = xbmc.Keyboard("", heading, hidden)
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else None


def _notify(msg: str,
            lvl: int = xbmcgui.NOTIFICATION_INFO,
            ms: int = 4000) -> None:
    """Krátká Kodi notifikace + echo do logu."""
    _rm_notif(msg, lvl, ms, "RichMovie")
    _log(msg)
