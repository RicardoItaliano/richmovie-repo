# -*- coding: utf-8 -*-
"""
RichMovie NetState — SSOT stavu síťové konektivity pro celý addon.

PROČ TENHLE MODUL EXISTUJE
--------------------------
Addon do 08.08.2026 neměl ponětí o tom, jestli zařízení vůbec je online. Důsledky:

    • Každý modul čekal na svůj vlastní timeout. Uživatel na mrtvé Wi-Fi zaplatil
      5 sekund zmrzlého UI za KAŽDÉ volání, protože nikdo nikde neevidoval, že
      předchozí tři requesty selhaly ze stejného důvodu.
    • Offline-grace (3.4.11) sice existovala, ale property ``richmovie.offline_mode``
      se jen zapisovala (``plugin.py:5306``) a mazala (``:5321``) — **nikdo ji nečetl**.
      Uživatel tedy o omezeném režimu nevěděl a UI se podle něj nechovalo.

Tenhle modul je jediná autorita na otázku „jsme online?". Stav se drží ve
``Window(10000)`` properties, takže ho vidí všechny plugin invokery i služba
(stejný IPC vzor, jaký addon používá pro ``richmovie.rev.*`` nebo streams lifecycle).

TŘI STAVY
---------
    ONLINE     poslední kontakt se sítí vyšel
    DEGRADED   něco selhalo, ale ještě nevíme, jestli je to síť nebo jeden server
    OFFLINE    zařízení je bez konektivity → transport fail-fastuje bez pokusu o síť

JAK SE POZNÁ „SÍŤ JE DOLE" OD „JEDEN SERVER JE DOLE"
----------------------------------------------------
Naivní pravidlo „3 selhání = offline" by shodilo celý addon do offline režimu pokaždé,
když je dole jeden scraper (SOSAC umí být mrtvý týden), zatímco Gate i Webshare běží.
Proto se rozhoduje ze dvou nezávislých signálů:

    1. **Víc různých hostů** — ≥3 selhání a ≥2 různé domény. Když nefunguje Gate
       *i* Webshare, není to náhoda serveru.
    2. **Typ chyby** — ``ENETUNREACH``/``ENETDOWN``/``EHOSTUNREACH`` a DNS selhání
       nejsou výroky o serveru, ale o lokální síti. „Nemám routu" nemůže poslat
       vzdálený stroj. Dvě takové chyby stačí, i kdyby byly ze stejné domény.

Bod 2 je v praxi ten důležitý: veškerý provoz addonu kromě BYOC zdrojů teče přes
jediný host ``gate.svcnode.org``, takže na bod 1 by se u běžného prohlížení nedošlo.

Naopak HTTP 429 se jako selhání **nepočítá vůbec** — server odpověděl, síť tedy
funguje. Kdyby se počítal, tři rate-limity by addon odstřihly od všeho, což je přesný
opak toho, co po incidentu 12.07.2026 chceme.

JISTIČ PER HOST (08.11.2026, `Handoff/PLAN_webshare_outage_20261108.md` W1)
-------------------------------------------------------------------------
Incident 08.11.2026: `webshare.cz` byl od půlnoci nedostupný a KAŽDÝ požadavek na něj čekal na vypršení
spojení (2 pokusy × 4 s) — hledání trvalo 2–5 minut. Globální stav to neuměl zkrátit (DEGRADED nic
neblokuje) a navíc střídal DEGRADED ↔ ONLINE, protože úspěch JAKÉHOKOLI hostu mazal evidenci všech.
Proto vedle globálního stavu:

    • **Úspěch maže jen svůj host.** Globální DEGRADED → ONLINE až když žádný host nemá čerstvé selhání
      a žádný jistič není otevřený (konec střídání). Návrat z OFFLINE se NEMĚNÍ (síť prokázaně jede).
    • **Jistič hostu** se otevře po ``_HOST_OPEN_FAILS`` selháních NAVÁZÁNÍ SPOJENÍ za ``_HOST_FAIL_WINDOW_S``
      (rozhoduje TYP chyby v ``richmovie_http.is_connect_failure``; pomalá odpověď ani lokální chyba sítě
      ho neotevře, systémový filtr obsahu taky ne). Otevřený = požadavky na host selžou HNED
      (``richmovie_http.HostDownError``), bez sítě a bez opakování; jen počítadlo, žádný řádek logu na požadavek.
    • Po pauze 30 → 60 → 120 s propustí JEDEN zkušební požadavek (claim ``richmovie_guard`` — zápis
      s ověřením, kdo vyhrál, meziprocesově). Úspěch (nebo navázané spojení) = zavřeno; další selhání
      spojení = delší pauza.
    • Jistič jen říká „teď ne“ — opakování dál dělá jen ``richmovie_http`` (žádný druhý retry mechanismus).

Python 3.8 kompat (Kodi bundled CPython).
"""

from __future__ import annotations

# ──────────────  STANDARD LIBRARY  ──────────────
import json
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

# ──────────────  KODI API  ──────────────
# Modul musí být importovatelný i mimo Kodi (offline harness Φ6).
try:
    import xbmc  # type: ignore
except Exception:  # pragma: no cover
    xbmc = None  # type: ignore

try:
    import xbmcgui  # type: ignore
except Exception:  # pragma: no cover
    xbmcgui = None  # type: ignore

# ──────────────  RICHMOVIE  ──────────────
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.netstate", "RichMovie/NetState")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):
        # type: (str, int, Optional[Dict[str, Any]]) -> None
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/NetState] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Stavy
# --------------------------------------------------------------------------- #
STATE_ONLINE = "online"
STATE_DEGRADED = "degraded"
STATE_OFFLINE = "offline"

# --------------------------------------------------------------------------- #
# Window(10000) properties — IPC mezi plugin invokery a službou
# --------------------------------------------------------------------------- #
_PROP_STATE = "richmovie.net.state"
_PROP_SINCE = "richmovie.net.since"
_PROP_FAILS = "richmovie.net.fails"
_PROP_PROBE_NEXT = "richmovie.net.probe_next"
_PROP_PROBE_STEP = "richmovie.net.probe_step"
_PROP_GRACE = "richmovie.offline_mode"   # zpětná kompatibilita s 3.4.11
_PROP_HOSTS = "richmovie.net.hosts"      # jistič per host (08.11.2026) — JSON {host: záznam}

# --------------------------------------------------------------------------- #
# Prahy
# --------------------------------------------------------------------------- #
# Selhání starší než tohle okno se zapomínají. Krátká paměť je záměr: chceme
# odpovědět na otázku „jsme offline TEĎ", ne „měli jsme dnes výpadek".
_FAIL_WINDOW_S = 120.0

# Cesta A — víc různých hostů (viz docstring modulu).
_OFFLINE_MULTIHOST_STREAK = 3
_OFFLINE_MULTIHOST_DISTINCT = 2

# Cesta B — chyby, které může vyrobit jen lokální síť.
_OFFLINE_LOCAL_STREAK = 2

# Backoff zdravotní sondy. Začíná svižně (výpadek Wi-Fi bývá otázka sekund), ale
# rychle se prodlužuje, aby zařízení v letadle nebušilo do sítě každých 5 s celou noc.
_PROBE_BACKOFF_S = (5.0, 15.0, 30.0, 60.0)

# Sonda musí být rychlá — běží v service tiku a nesmí ho zdržet.
_PROBE_TIMEOUT_S = 4.0

# Jistič per host (08.11.2026, W1). Dvě selhání navázání spojení za 30 s = host neodpovídá: jedno může být
# výkyv Wi-Fi, dvě v těsném sledu (typicky dva pokusy téhož požadavku, 2 × 4 s na Androidu) už ne. Jeden
# požadavek své vlastní opakování dokončí vždy (jistič se kontroluje jen na jeho začátku) — u jednopokusových
# profilů je tedy potřeba druhý požadavek (pojistka pro Gate, kde jeden výkyv nesmí odříznout 30 s provozu).
_HOST_FAIL_WINDOW_S = 30.0
_HOST_OPEN_FAILS = 2
# Selhání musí dělit aspoň tolik sekund: souběžné dotazy jedné vlny (pool 2–6) při JEDNOM výkyvu Wi-Fi selžou ve stejnou
# chvíli — to není výpadek hostu. Skutečný výpadek otevře jistič druhým kolem pokusů (~4–8 s po prvním) — cross-check
# S31 Argon P-2a, 08.11.2026.
_HOST_OPEN_SPREAD_S = 1.5
# Pauzy otevřeného jističe: krátká první (výpadek serveru bývá minuty, ne sekundy — ale návrat chceme poznat
# brzy), pak delší, strop 2 min. Mezi pauzami jediný zkušební požadavek.
_HOST_PAUSE_S = (30.0, 60.0, 120.0)
# Záznamů hostů nejvýš tolik (CDN uzly Webshare mají každý vlastní jméno; property nesmí růst bez meze).
_HOST_MAX_ENTRIES = 32
_HOST_TRIAL_GUARD = "nethost."

# In-process zámek. Window properties nejsou atomické; tohle drží konzistenci
# aspoň v rámci jednoho procesu (MediaInfo workery jedou v 5 vláknech naráz).
_lock = threading.Lock()

# Přístup k `Window(10000)` + fallback mimo Kodi (harness) je od 3.5.118 SSOT
# v `richmovie_winprops` — dřív tu byla vlastní kopie `_win/_get_prop/_set_prop`,
# kterou by `richmovie_identity_state` musel duplikovat. Aliasy drží původní
# jména, aby zbytek modulu zůstal beze změny (harness Φ6 ho pokrývá 67 asercemi).
from richmovie_winprops import (  # noqa: E402
    clear_prop as _clear_prop,
    get_prop as _get_prop,
    set_prop as _set_prop,
)
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# get_state  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def get_state():
    # type: () -> str
    """Aktuální stav konektivity. Výchozí (nic se ještě nestalo) je ONLINE.

    Optimistický výchozí stav je záměr: dokud nemáme důkaz o výpadku, nesmíme
    uživateli omezovat funkce. Pesimistický start by po každém restartu Kodi na
    chvíli vypnul síť, dokud by ji něco „nepovolilo".
    """
    value = _get_prop(_PROP_STATE, STATE_ONLINE)
    return value if value in (STATE_ONLINE, STATE_DEGRADED, STATE_OFFLINE) else STATE_ONLINE


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# state_since  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def state_since():
    # type: () -> float
    """Unixový čas, kdy addon vstoupil do aktuálního stavu (0 = neznámo).

    Používá UI (Φ5) pro rozhodnutí, jestli má cenu hlásit „jsme offline" —
    dvousekundový výpadek při přepínání AP nikoho zajímat nemusí.
    """
    try:
        return float(_get_prop(_PROP_SINCE, "0") or 0)
    except Exception:
        return 0.0


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# is_offline  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def is_offline():
    # type: () -> bool
    """True, když je addon v offline režimu (breaker otevřen NEBO auth grace).

    Sjednocuje dva dřív nezávislé signály: náš breaker a offline-grace z ``/auth``
    (3.4.11). Pro UI je to jedna a tatáž informace — „jedeme z uložených dat".
    """
    if get_state() == STATE_OFFLINE:
        return True
    return _get_prop(_PROP_GRACE, "") == "1"


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# allow_request  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def allow_request(probe=False):
    # type: (bool) -> bool
    """Smí transport zkusit síť?

    Ve stavu OFFLINE vrací False — a to je celý pocitový rozdíl pro uživatele:
    místo pěti sekund zmrzlého UI dostane odpověď do jednotek milisekund a addon
    může okamžitě sáhnout po uložených datech.

    Args:
        probe: True u zdravotní sondy. Ta musí projít i otevřeným breakerem,
               jinak by se stav nikdy nemohl vrátit na ONLINE (klasická past
               circuit breakeru, který si sám zavře cestu k zotavení).

    Returns:
        True = zkus to; False = jsme offline, nezkoušej.
    """
    if probe:
        return True
    return get_state() != STATE_OFFLINE


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# _os_filter_active  (vytvořeno: 03.11.2026 21:20 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _os_filter_active():
    # type: () -> bool
    """Stojí v cestě systémový filtr obsahu? SSOT `richmovie_device_env.filtered()`; chyba = ne (beze změny chování)."""
    try:
        import richmovie_device_env as _denv
        return bool(_denv.filtered())
    except Exception:
        return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# _load_fails / _store_fails  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _load_fails():
    # type: () -> Dict[str, Any]
    """Načte evidenci posledních selhání z Window property.

    Tvar: ``{"events": [[ts, host, local_bool], ...]}``. Držíme seznam, ne jen
    čítač, protože potřebujeme odpovědět na dvě různé otázky (kolik různých hostů,
    kolik lokálních chyb) a obě s časovým oknem.
    """
    raw = _get_prop(_PROP_FAILS, "")
    if not raw:
        return {"events": []}
    try:
        data = json.loads(raw)
        if isinstance(data, dict) and isinstance(data.get("events"), list):
            return data
    except Exception:
        pass
    return {"events": []}


def _store_fails(data):
    # type: (Dict[str, Any]) -> None
    """Uloží evidenci selhání. Ořezává na 20 záznamů (víc k rozhodnutí netřeba)."""
    try:
        events = list(data.get("events") or [])[-20:]
        _set_prop(_PROP_FAILS, json.dumps({"events": events}))
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# report_success  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def report_success(host=""):
    # type: (str) -> None
    """Ohlásí úspěšný kontakt se sítí — jediná cesta zpátky do ONLINE.

    Z OFFLINE (beze změny od 08.08.2026): když projde jeden request, síť prokazatelně funguje → evidence
    selhání celá pryč a ONLINE.

    Jinak (08.11.2026, W1) se maže jen evidence TOHO hostu a jeho jistič se zavře. Do 07.11. mazal úspěch
    evidenci celou — každý úspěch Gate během výpadku Webshare znamenal `NETSTATE_RECOVERED` a další selhání
    Webshare zase `NETSTATE_DEGRADED` (64× / 65× za hodinu na jednom Chromecastu). Teď DEGRADED → ONLINE až
    když žádný host nemá čerstvé selhání a žádný jistič není otevřený.
    """
    with _lock:
        previous = get_state()
        host = str(host or "").lower()
        hosts = _load_hosts()
        if host and host in hosts:
            _close_host(hosts, host, reason="uspesny request")
            _store_hosts(hosts)
        if previous == STATE_OFFLINE:
            _store_fails({"events": []})
            # síť prokazatelně jede → selhání spojení z doby výpadku linky nejsou důkaz výpadku hostů; otevřené jističe
            # by jinak ještě až 30 s rychle odmítaly Webshare, TMDb i Gate (audit Fable S-3, 08.11.2026)
            _store_hosts({})
            _enter_state(STATE_ONLINE, reason="uspesny request", host=host)
        else:
            now = time.time()
            events = [e for e in (_load_fails().get("events") or [])
                      if isinstance(e, (list, tuple)) and len(e) >= 3
                      and (now - float(e[0])) <= _FAIL_WINDOW_S and str(e[1]) != host]
            _store_fails({"events": events})
            if previous != STATE_ONLINE and not events and not _any_host_open(hosts, _host_now()):
                _enter_state(STATE_ONLINE, reason="uspesny request", host=host)
        _set_prop(_PROP_PROBE_STEP, "0")
        _set_prop(_PROP_PROBE_NEXT, "0")


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# report_failure  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def report_failure(err_class, host="", local=False, connect=False):
    # type: (str, str, bool, bool) -> None
    """Ohlásí neúspěšný pokus o spojení a případně překlopí stav.

    Args:
        err_class: Třída z ``richmovie_http.classify()``. Jiná než ``transient``
                   se ignoruje — trvalá chyba (404, TLS) o konektivitě nic neříká
                   a rate-limit dokonce dokazuje, že síť funguje.
        host:      Doména, na které se to stalo (rozlišení „síť" vs „jeden server").
        local:     True, když chyba může pocházet jen z lokální sítě
                   (``ENETUNREACH`` a spol., DNS) — viz docstring modulu.
        connect:   True, když selhalo NAVÁZÁNÍ spojení s hostem (``richmovie_http.is_connect_failure``:
                   connect / TLS handshake timeout, odmítnutí) — podklad jističe hostu (08.11.2026, W1).
                   Pomalá odpověď (read timeout) a 5xx jistič neotevírají.
    """
    if err_class != "transient":
        return

    with _lock:
        if host:
            hosts = _load_hosts()
            if _note_host_failure(hosts, str(host).lower(), connect=bool(connect) and not bool(local)):
                _store_hosts(hosts)
        now = time.time()
        data = _load_fails()
        events = [e for e in (data.get("events") or [])
                  if isinstance(e, (list, tuple)) and len(e) >= 3
                  and (now - float(e[0])) <= _FAIL_WINDOW_S]
        events.append([now, str(host or ""), bool(local)])
        _store_fails({"events": events})

        streak = len(events)
        distinct_hosts = len({str(e[1]) for e in events if e[1]})
        local_count = sum(1 for e in events if bool(e[2]))

        multihost_trip = (streak >= _OFFLINE_MULTIHOST_STREAK
                          and distinct_hosts >= _OFFLINE_MULTIHOST_DISTINCT)
        local_trip = local_count >= _OFFLINE_LOCAL_STREAK

        # Noc 03.11.2026 (Φ1, Bětčin Mac): přes systémový filtr obsahu (`richmovie_device_env.filtered`)
        # vypadají timeouty na několika hostech stejně jako výpadek sítě, ale síť jede — filtr jen zdržuje.
        # „Více hostů“ proto při filtru NENÍ důkaz offline (jinak fail-fast odřízne Webshare, TMDb i kolekce).
        # Lokální chyby (DNS, ENETUNREACH) vznikají PŘED filtrem → dál platí.
        if multihost_trip and not local_trip and _os_filter_active():
            multihost_trip = False
            _log("NETSTATE_FILTERED streak=%d hosts=%d — selhání přes systémový filtr, ne výpadek sítě"
                 % (streak, distinct_hosts), 1)

        if multihost_trip or local_trip:
            if get_state() != STATE_OFFLINE:
                _enter_state(
                    STATE_OFFLINE,
                    reason=("lokalni sit" if local_trip else "vice hostu"),
                    host=host, streak=streak, distinct_hosts=distinct_hosts,
                    local_count=local_count,
                )
                # Sondu naplánuj hned na první krok backoffu, ne až za minutu.
                _set_prop(_PROP_PROBE_STEP, "0")
                _set_prop(_PROP_PROBE_NEXT, str(now + _PROBE_BACKOFF_S[0]))
        elif get_state() == STATE_ONLINE:
            _enter_state(STATE_DEGRADED, reason="prvni selhani", host=host,
                         streak=streak)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# _enter_state  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _enter_state(state, reason="", host="", **extra):
    # type: (str, str, str, Any) -> None
    """Přepne stav, zaloguje přechod a při návratu na ONLINE probudí UI.

    Volá se VÝHRADNĚ zevnitř modulu pod ``_lock``. Log úrovně WARNING u OFFLINE
    je záměr — přesně tenhle záznam v ``user_logs`` odpoví na otázku „jak často
    a komu vypadává síť", kterou jsme do 08.08.2026 neuměli zodpovědět vůbec.
    """
    previous = get_state()
    if previous == state:
        return

    _set_prop(_PROP_STATE, state)
    _set_prop(_PROP_SINCE, str(time.time()))

    context = {"state": state, "previous": previous, "reason": reason,
               "host": host or ""}
    try:
        context.update({k: v for k, v in extra.items() if v is not None})
    except Exception:
        pass

    if state == STATE_OFFLINE:
        _log("NETSTATE_OFFLINE duvod=%s host=%s" % (reason, host or "-"),
             xbmc.LOGWARNING if xbmc else 2, context=context)
    elif state == STATE_ONLINE:
        _log("NETSTATE_RECOVERED z=%s duvod=%s" % (previous, reason),
             xbmc.LOGINFO if xbmc else 1, context=context)
        if previous == STATE_OFFLINE:
            _wake_ui_after_recovery()
    else:
        _log("NETSTATE_DEGRADED host=%s" % (host or "-"),
             xbmc.LOGINFO if xbmc else 1, context=context)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# _wake_ui_after_recovery  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _wake_ui_after_recovery():
    # type: () -> None
    """Po návratu online řekne UI, že se má překreslit z čerstvých dat.

    Používá stávající mechanismus ``ui_common.data_rev_bump()`` — tentýž, kterým
    si RM 4.0 okna hlídají změny „Pokračovat", zhlédnutých a AI doporučení. Žádný
    nový signál se nezavádí: obrazovky, které už umí reagovat na změnu revize, se
    obnoví samy a ostatní to ignorují.

    Best-effort. Když se nepovede, uživatel prostě uvidí čerstvá data až při
    dalším vstupu do sekce — což je pořád lepší než dnešní stav.
    """
    try:
        import richmovie_ui_common as _uc
        for domain in getattr(_uc, "DATA_REV_DOMAINS", ()):
            try:
                _uc.data_rev_bump(domain)
            except Exception:
                pass
    except Exception:
        pass

    # Jednorázový nenápadný toast. Uživatel, který zrovna kouká na uloženou
    # nabídku, se má dozvědět, že je zase živá — ale jen jednou a bez blokování.
    # Nikdy se nezobrazuje během přehrávání: přerušit film hláškou „zpět online"
    # by bylo přesně to obtěžování, kterému se tahle práce vyhýbá.
    try:
        if xbmc is not None and xbmc.getCondVisibility("Player.HasVideo"):
            return
    except Exception:
        pass
    try:
        if xbmcgui is not None:
            _rm_notif("Připojení obnoveno", xbmcgui.NOTIFICATION_INFO, 3000, "RichMovie")
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# note_auth_offline_grace  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def note_auth_offline_grace(active):
    # type: (bool) -> None
    """Zaznamená, že ``/auth`` jede na offline-grace (Gate nedostupný, lease platí).

    Do 08.08.2026 se property ``richmovie.offline_mode`` sice nastavovala, ale nikdo
    ji nečetl. Nechávám ji zapisovat pod původním jménem kvůli zpětné kompatibilitě
    (a protože ji čte admin diagnostika), ale autoritou pro UI je od teď
    ``is_offline()``, které kombinuje grace i breaker.
    """
    try:
        if active:
            _set_prop(_PROP_GRACE, "1")
        else:
            _clear_prop(_PROP_GRACE)
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# probe_now  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def probe_now(timeout_s=_PROBE_TIMEOUT_S):
    # type: (float) -> bool
    """Zdravotní sonda na Gate ``/health``. True = síť je zpátky.

    Jde vědomě na Gate, ne na obecný internet: kdyby byl dostupný internet, ale ne
    náš server, přepnutí na ONLINE by uživateli nepomohlo — addon stejně potřebuje
    Gate. Sonda běží s ``probe=True``, takže projde otevřeným breakerem.

    Výjimka (3.5.151, Fable F1/N4): navázání přehrávání Gate NEPOTŘEBUJE (resolve jde na
    Webshare/Fastshare, stream na jejich CDN). Služba proto před navázáním sonduje CDN
    streamu (``richmovie_webshare.validate_stream_link(probe=True)``, rozhodnutí
    ``richmovie_resume.resume_route``) a úspěšná odpověď CDN přepne netstate do ONLINE
    i při nedostupném Gate — v souladu s ``report_success`` („síť prokazatelně funguje").
    Tahle funkce zůstává sondou Gate; pro navázání je jen druhou volbou, když CDN mlčí.

    Jeden pokus, žádný retry (``max_attempts=1``) — od opakování je tu backoff
    v ``recovery_tick()``; dvojité opakování by jen prodloužilo service tik.

    Returns:
        True při HTTP 200, jinak False. Nikdy nevyhodí.
    """
    try:
        import richmovie_http as _http
        from richmovie_gate_transport import GATE_URL as _gate_url

        profile = _http.RetryProfile("probe", budget_s=timeout_s + 1.0,
                                     timeout_s=timeout_s, max_attempts=1)
        status, _body, _headers = _http.request(
            "%s/health" % _gate_url, profile=profile, tag="netprobe", probe=True,
        )
        return int(status) == 200
    except Exception:
        return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# recovery_tick  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def recovery_tick():
    # type: () -> bool
    """Jeden krok automatického zotavení. Volá ``service_nextup`` ve své smyčce.

    PROČ NE VLASTNÍ VLÁKNO: služba už tiká každých 5 s a má korektní abort
    handling. Další vlákno by znamenalo další objekt, který se musí správně
    ukončit v pětisekundovém okně, které Kodi dává na shutdown (viz memory
    ``feedback_daemon_threads_kodi`` — daemon vlákna s HTTP jsou v Kodi zakázaná).
    Tik je levný: mimo OFFLINE stav se okamžitě vrátí.

    Backoff 5 → 15 → 30 → 60 s. Zařízení, které leží celou noc bez sítě, se tak
    ptá jednou za minutu, ne dvanáctkrát.

    Returns:
        True, pokud sonda právě obnovila spojení (užitečné pro testy a log).
    """
    if get_state() != STATE_OFFLINE:
        return False

    now = time.time()
    try:
        due = float(_get_prop(_PROP_PROBE_NEXT, "0") or 0)
    except Exception:
        due = 0.0
    if now < due:
        return False

    try:
        step = int(_get_prop(_PROP_PROBE_STEP, "0") or 0)
    except Exception:
        step = 0

    if probe_now():
        with _lock:
            _store_fails({"events": []})
            _enter_state(STATE_ONLINE, reason="sonda /health")
            _set_prop(_PROP_PROBE_STEP, "0")
            _set_prop(_PROP_PROBE_NEXT, "0")
        return True

    next_step = min(step + 1, len(_PROBE_BACKOFF_S) - 1)
    _set_prop(_PROP_PROBE_STEP, str(next_step))
    _set_prop(_PROP_PROBE_NEXT, str(now + _PROBE_BACKOFF_S[next_step]))
    return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# snapshot  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def snapshot():
    # type: () -> Dict[str, Any]
    """Kompletní stav pro diagnostiku, UI a testy.

    Sestavuje se ze stejných properties, jaké čte zbytek addonu — žádný paralelní
    zdroj pravdy, který by se mohl rozejít.
    """
    since = state_since()
    fails = _load_fails().get("events") or []
    hosts = _load_hosts()
    return {
        "hosts_open": sorted(h for h, r in hosts.items() if r.get("open")),
        "state": get_state(),
        "since": since,
        "age_s": round(time.time() - since, 1) if since else None,
        "offline": is_offline(),
        "auth_grace": _get_prop(_PROP_GRACE, "") == "1",
        "recent_failures": len(fails),
        "distinct_hosts": len({str(e[1]) for e in fails
                               if isinstance(e, (list, tuple)) and len(e) >= 2 and e[1]}),
    }


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# reset  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def reset():
    # type: () -> None
    """Vrátí stav do výchozího ONLINE a zahodí evidenci selhání.

    Určeno pro offline harness (Φ6), aby scénáře nezačínaly se stavem po
    předchozím testu. V produkci se nevolá.
    """
    with _lock:
        _set_prop(_PROP_STATE, STATE_ONLINE)
        _set_prop(_PROP_SINCE, str(time.time()))
        _set_prop(_PROP_PROBE_STEP, "0")
        _set_prop(_PROP_PROBE_NEXT, "0")
        _store_fails({"events": []})
        _clear_prop(_PROP_HOSTS)


# =========================================================================== #
#  JISTIČ PER HOST (08.11.2026, Handoff/PLAN_webshare_outage_20261108.md W1)  #
# =========================================================================== #

def _host_now():
    # type: () -> float
    """Monotónní čas jističe (vzor ``richmovie_guard._now``): sdílený všemi procesy jednoho bootu, odolný
    proti skoku hodin přes NTP (Android boxy bez RTC). Harness ho podvrhuje."""
    return time.monotonic()


def _load_hosts():
    # type: () -> Dict[str, Dict[str, Any]]
    """Záznamy hostů z Window property: ``{host: {"cf": [t…], "open": bool, "until": t, "step": n,
    "since": t, "ff": n}}`` — ``cf`` = časy selhání navázání spojení, ``ff`` = rychlá selhání (počítadlo)."""
    raw = _get_prop(_PROP_HOSTS, "")
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k): v for k, v in data.items() if isinstance(v, dict)}


def _store_hosts(hosts):
    # type: (Dict[str, Dict[str, Any]]) -> None
    """Uloží záznamy; zahodí zavřené hosty bez čerstvého selhání a drží strop počtu (nejstarší pryč)."""
    now = _host_now()
    keep = {}  # type: Dict[str, Dict[str, Any]]
    for host, rec in hosts.items():
        cf = [float(t) for t in (rec.get("cf") or []) if isinstance(t, (int, float))
              and 0.0 <= now - float(t) <= _HOST_FAIL_WINDOW_S]
        if rec.get("open") or cf:
            rec = dict(rec)
            rec["cf"] = cf
            keep[host] = rec
    if len(keep) > _HOST_MAX_ENTRIES:
        ordered = sorted(keep.items(), key=lambda kv: (bool(kv[1].get("open")),
                                                       max(kv[1].get("cf") or [0.0])))
        keep = dict(ordered[-_HOST_MAX_ENTRIES:])
    try:
        if keep:
            _set_prop(_PROP_HOSTS, json.dumps(keep, separators=(",", ":")))
        else:
            _clear_prop(_PROP_HOSTS)
    except Exception:
        pass


def _any_host_open(hosts, now):
    # type: (Dict[str, Dict[str, Any]], float) -> bool
    """Drží nějaký host AKTIVNÍ pauzu jističe? Po pauze bez dalšího požadavku je stav hostu neznámý (záznam zůstává
    a první další požadavek bude zkušební) — globální DEGRADED kvůli němu nesmí viset do konce běhu Kodi
    (cross-check S31 A1-11b, 08.11.2026)."""
    return any(bool(r.get("open")) and now < float(r.get("until") or 0.0) for r in hosts.values())


def _note_host_failure(hosts, host, connect):
    # type: (Dict[str, Dict[str, Any]], str, bool) -> bool
    """Zapíše selhání do záznamu hostu a rozhodne o jističi. Vrací, jestli se záznam změnil (uložit).

    - zavřený jistič + selhání spojení: čas do ``cf``; ``_HOST_OPEN_FAILS`` za okno = otevřít (ne při filtru);
    - otevřený jistič po pauze (= zkušební požadavek): selhání spojení = znovu otevřít s delší pauzou;
      jiné selhání (spojení se navázalo, odpověď nepřišla) = host je dosažitelný → zavřít;
    - otevřený jistič během pauzy: požadavek, který vyrazil ještě před otevřením — nic neměnit.
    """
    now = _host_now()
    rec = hosts.get(host)
    if rec is None:
        if not connect:
            return False
        rec = {"cf": [], "open": False, "until": 0.0, "step": 0, "since": 0.0, "ff": 0}
        hosts[host] = rec
    if rec.get("open"):
        if not connect:
            # spojení se navázalo, jen odpověď nepřišla = host je DOSAŽITELNÝ → zavřít i během pauzy (druhý pokus
            # zkušebního požadavku po prvním selhání spojení by jinak nechal jistič otevřený celou novou pauzu —
            # cross-check S31 Argon P-1b, 08.11.2026)
            _close_host(hosts, host, reason="spojeni navazano")
            return True
        if now < float(rec.get("until") or 0.0):
            return False
        if _os_filter_active():
            _close_host(hosts, host, reason="filtr obsahu")
            return True
        step = min(int(rec.get("step") or 0) + 1, len(_HOST_PAUSE_S) - 1)
        rec["step"] = step
        rec["until"] = now + _HOST_PAUSE_S[step]
        _log("NETSTATE_HOST_OPEN host=%s pause=%ds duvod=zkouska selhala fast_fails=%d"
             % (host, int(_HOST_PAUSE_S[step]), int(rec.get("ff") or 0)),
             xbmc.LOGWARNING if xbmc else 2,
             context={"host": host, "pause_s": _HOST_PAUSE_S[step], "step": step, "trial": "failed",
                      "fast_fails": int(rec.get("ff") or 0)})
        return True
    if not connect:
        return False
    cf = [float(t) for t in (rec.get("cf") or []) if 0.0 <= now - float(t) <= _HOST_FAIL_WINDOW_S]
    cf.append(now)
    rec["cf"] = cf
    if len(cf) >= _HOST_OPEN_FAILS and cf[-1] - cf[0] >= _HOST_OPEN_SPREAD_S:
        if _os_filter_active():
            # selhání přes systémový filtr obsahu nejsou důkaz výpadku hostu (Φ1 noci 03.11.2026)
            _log("NETSTATE_HOST_FILTERED host=%s fails=%d — jistič se přes filtr obsahu neotevírá"
                 % (host, len(cf)), xbmc.LOGINFO if xbmc else 1)
            return True
        rec.update({"open": True, "step": 0, "until": now + _HOST_PAUSE_S[0], "since": now, "ff": 0})
        _log("NETSTATE_HOST_OPEN host=%s pause=%ds duvod=selhani spojeni fails=%d"
             % (host, int(_HOST_PAUSE_S[0]), len(cf)),
             xbmc.LOGWARNING if xbmc else 2,
             context={"host": host, "pause_s": _HOST_PAUSE_S[0], "step": 0, "fails": len(cf)})
    return True


def _close_host(hosts, host, reason):
    # type: (Dict[str, Dict[str, Any]], str, str) -> None
    """Zavře jistič hostu (jen při přechodu zaloguje dobu výpadku a počet rychlých selhání)."""
    rec = hosts.get(host)
    if rec is None:
        return
    if rec.get("open"):
        down_s = max(0.0, _host_now() - float(rec.get("since") or 0.0))
        _log("NETSTATE_HOST_CLOSE host=%s down_s=%d fast_fails=%d duvod=%s"
             % (host, int(down_s), int(rec.get("ff") or 0), reason),
             xbmc.LOGINFO if xbmc else 1,
             context={"host": host, "down_s": round(down_s, 1), "fast_fails": int(rec.get("ff") or 0),
                      "reason": reason})
    hosts.pop(host, None)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# host_open / host_admit / host_trial_done  (vytvořeno: 08.11.2026 01:40 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def host_open(host):
    # type: (str) -> bool
    """Je jistič hostu otevřený (host teď neodpovídá, požadavky na něj selhávají rychle, nejvýš jeden
    zkušební)? Pro pravdivou větu divákovi („Webshare teď neodpovídá“). Chyba čtení = ne."""
    try:
        rec = _load_hosts().get(str(host or "").lower())
        return bool(rec and rec.get("open"))
    except Exception:
        return False


def host_admit(host, trial_ttl_s):
    # type: (str, float) -> Tuple[str, Optional[str]]
    """Smí požadavek na `host` do sítě? Volá ``richmovie_http.request`` na začátku požadavku (ne mezi pokusy).

    Returns:
        ("go", None)       jistič zavřený;
        ("trial", token)   pauza uplynula a tenhle požadavek je JEDINÝ zkušební (claim ``richmovie_guard``
                           platí `trial_ttl_s`; token vrátit přes ``host_trial_done``);
        ("fast", None)     jistič otevřený nebo zkouší někdo jiný → selhat hned (počítadlo ``ff``).
    """
    host = str(host or "").lower()
    if not host:
        return "go", None
    with _lock:
        hosts = _load_hosts()
        rec = hosts.get(host)
        if not rec or not rec.get("open"):
            return "go", None
        if _host_now() >= float(rec.get("until") or 0.0):
            try:
                import richmovie_guard as _guard
                token = _guard.claim(_HOST_TRIAL_GUARD + host, max(1.0, float(trial_ttl_s)))
            except Exception:
                token = None
            if token:
                return "trial", token
            # claim prohrál: jiný proces zkouší — jeho výsledek mohl mezitím přepsat stav; zápis nad starým snímkem
            # by zkoušku vrátil (cross-check S31 Argon P-1a) → načíst znovu, zavřený = pustit
            hosts = _load_hosts()
            rec = hosts.get(host)
            if not rec or not rec.get("open"):
                return "go", None
        rec["ff"] = int(rec.get("ff") or 0) + 1
        _store_hosts(hosts)
        return "fast", None


def host_trial_done(host, token):
    # type: (str, Optional[str]) -> None
    """Uvolní claim zkušebního požadavku (výsledek už zapsal ``report_success`` / ``report_failure``)."""
    if not token:
        return
    try:
        import richmovie_guard as _guard
        _guard.release(_HOST_TRIAL_GUARD + str(host or "").lower(), token)
    except Exception:
        pass


def hosts_snapshot():
    # type: () -> List[Dict[str, Any]]
    """Stav jističů pro diagnostiku a harness: [{host, open, step, until_in_s, ff, fails}]."""
    now = _host_now()
    out = []
    for host, rec in sorted(_load_hosts().items()):
        out.append({"host": host, "open": bool(rec.get("open")), "step": int(rec.get("step") or 0),
                    "until_in_s": round(float(rec.get("until") or 0.0) - now, 1) if rec.get("open") else None,
                    "ff": int(rec.get("ff") or 0), "fails": len(rec.get("cf") or [])})
    return out

