# -*- coding: utf-8 -*-
"""
RichMovie AI Client — thin HTTP client for Gate /v1/ai/* endpoints.

Architecture (RichMovie 3.000, see
S:\\test\\richmovie\\Handoff\\session_2026-04-18_richmovie_3000_rcai_integration.md):

    Kodi addon (this module, Python 3.8, stdlib urllib)
          |
          | POST https://gate.svcnode.org/v1/ai/{recommend,identify,chat,usage}
          | Body: {schema_version, ws_username, ws_proof, quality, <context>}
          v
    RichMovie Gate (FastAPI on NAS)
          | auth → ai_enabled → rate limit → prompt build → RCAI
          v
    RichClaudeAI (richclaude-gateway:8420, tenant='richmovie', priority=BULK)
          v
    Claude (Opus/Sonnet/Haiku per quality)

Identity/transport concerns (ws_proof, urllib POST) live in the shared
`richmovie_gate_transport` module — consolidated in phase 3b.5 so that the
mediainfo/search/future clients don't each re-implement the same 4 helpers.
This module owns only AI-specific prompt envelopes and error translation.

Python 3.8 compat (Kodi bundled): Optional/Tuple from typing, no `X | None`.
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional, Tuple

import xbmc

from richmovie_gate_transport import (
    build_common_fields,
    get_identity,
    post_json,
)


# --------------------------------------------------------------------------- #
# AI-specific constants
# --------------------------------------------------------------------------- #
# Addon socket timeout — must be GREATER than Gate's RCAI_JOB_TIMEOUT_SECONDS
# (150s), otherwise addon disconnects while RCAI is still working and user gets
# a generic "transport timeout" instead of Gate's clean 504 error. Real-world
# Opus quality="high" + BULK tenant priority = 60-120s typical. 180s adds margin.
_AI_REQUEST_TIMEOUT_SECONDS = 180.0

# Error codes returned by Gate /v1/ai/* (see gate/app/ai/router.py::_error_response)
ERR_NOT_AUTHORIZED = "not_authorized"        # user not whitelisted
ERR_INACTIVE = "inactive"                     # is_active=0
ERR_PROOF_MISSING = "proof_missing"           # user never completed /auth
ERR_PROOF_MISMATCH = "proof_mismatch"         # SHA256 did not match
ERR_AI_NOT_ENABLED = "ai_not_enabled"         # ai_enabled=0 in DB
ERR_RATE_LIMITED = "ai_rate_limited"          # hourly/daily cap reached
ERR_TENANT_CAP = "ai_tenant_cap"              # RCAI tenant-level 429
ERR_TIMEOUT = "ai_timeout"                    # RCAI did not return in time
ERR_PROVIDER_ERROR = "ai_provider_error"      # RCAI returned failed job
ERR_UNAVAILABLE = "ai_unavailable"            # RCAI unreachable / network issue
ERR_TRANSPORT = "transport_error"             # local urllib exception
ERR_UNKNOWN = "unknown_error"


# --------------------------------------------------------------------------- #
# Lightweight logging
# --------------------------------------------------------------------------- #
# 3.4.0 Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.ai", "RichMovie/AI")
except Exception:
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        # type: (str, int, dict | None) -> None
        try:
            xbmc.log("[RichMovie/AI] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# AI-specific transport wrapper — delegates to shared helper with higher
# timeout. Kept as a local indirection so call-site patches (retry, logging,
# tracing) would only change this one function.
# --------------------------------------------------------------------------- #
def _post(path, body):
    # type: (str, Dict[str, Any]) -> Tuple[int, Dict[str, Any]]
    return post_json(path, body, timeout=_AI_REQUEST_TIMEOUT_SECONDS)


# --------------------------------------------------------------------------- #
# Result envelope — returned by every public call
# --------------------------------------------------------------------------- #
class AIResult(object):
    """Mutable result object returned to plugin.py callers.

    success:  True if content is usable
    content:  Claude's response text (empty string on failure)
    error_code: one of ERR_* constants (empty on success)
    error_message: human-readable Czech message suitable for Kodi dialog
    usage:    {'tokens_in': int, 'tokens_out': int} or None
    meta:     {'model_used': str, 'request_id': str, 'prompt_version': str,
               'retry_after': int|None} — diagnostics, don't show to users
    """

    __slots__ = ("success", "content", "error_code", "error_message",
                 "usage", "meta")

    def __init__(
        self,
        success,           # type: bool
        content="",        # type: str
        error_code="",     # type: str
        error_message="",  # type: str
        usage=None,        # type: Optional[Dict[str, int]]
        meta=None,         # type: Optional[Dict[str, Any]]
    ):
        self.success = success
        self.content = content
        self.error_code = error_code
        self.error_message = error_message
        self.usage = usage
        self.meta = meta or {}

    def __bool__(self):
        return self.success

    __nonzero__ = __bool__  # Py2 compat harmless in Py3.8+


# --------------------------------------------------------------------------- #
# Error translation — HTTP status + Gate error code → user-friendly Czech
# --------------------------------------------------------------------------- #
def _translate_error(status, body):
    # type: (int, Dict[str, Any]) -> AIResult
    """Map Gate's error envelope to an AIResult with Czech message."""
    err = body.get("error") or {}
    code = err.get("code", "") or ("http_%d" % status if status else ERR_UNKNOWN)
    msg = err.get("message", "") or ""
    meta = {
        "request_id": body.get("request_id", ""),
        "retry_after": err.get("retry_after"),
        "details": err.get("details"),
    }

    # Defaults — overridden per code.
    friendly = msg or "AI služba vrátila chybu."

    if code == ERR_NOT_AUTHORIZED:
        friendly = "Tvůj účet není registrován v RichMovie."
    elif code == ERR_INACTIVE:
        friendly = "Tvůj účet je deaktivován. Kontaktuj správce."
    elif code == ERR_PROOF_MISSING:
        friendly = "Tvé přihlášení je zastaralé. Zavři a spusť RichMovie znovu."
    elif code == ERR_PROOF_MISMATCH:
        friendly = "Identita se neověřila. Zkontroluj Webshare heslo v nastavení."
    elif code == ERR_AI_NOT_ENABLED:
        friendly = ("AI funkce nejsou pro tvůj účet aktivovány. "
                    "Kontaktuj správce RichMovie.")
    elif code == ERR_RATE_LIMITED:
        # msg from server already contains reset time in Czech
        friendly = msg or "Vyčerpal jsi limit AI dotazů. Zkus to později."
    elif code == ERR_TENANT_CAP:
        friendly = ("AI služba je momentálně plně vytížená. "
                    "Zkus to prosím později.")
    elif code == ERR_TIMEOUT:
        friendly = "AI nestihla odpovědět v rozumném čase. Zkus to znovu."
    elif code == ERR_PROVIDER_ERROR:
        friendly = "AI vrátila chybu. Pokud se to opakuje, kontaktuj správce."
    elif code == ERR_UNAVAILABLE:
        friendly = "AI služba není momentálně dostupná. Zkus to později."

    return AIResult(
        success=False,
        content="",
        error_code=code,
        error_message=friendly,
        meta=meta,
    )


# --------------------------------------------------------------------------- #
# Common path: build request → POST → parse response
# --------------------------------------------------------------------------- #
def _call(path, extra_body):
    # type: (str, Dict[str, Any]) -> AIResult
    """Do a single Gate /v1/ai/* call. No retries (rate limit is global)."""
    username, proof = get_identity()
    if not username or not proof:
        _log("No Webshare credentials — AI call aborted", xbmc.LOGWARNING)
        return AIResult(
            success=False,
            error_code=ERR_PROOF_MISSING,
            error_message="V nastavení chybí Webshare login/heslo.",
        )

    body = build_common_fields()
    body.update(extra_body)

    started = time.time()
    try:
        status, response = _post(path, body)
    except Exception as exc:
        _log("Transport error on %s: %r" % (path, exc), xbmc.LOGERROR)
        return AIResult(
            success=False,
            error_code=ERR_TRANSPORT,
            error_message="Nelze se připojit k RichMovie Gate. Zkontroluj připojení.",
        )

    if status == 200 and response.get("status") == "ok":
        elapsed = time.time() - started
        _log("OK %s model=%s tokens=%s/%s in %.1fs" % (
            path,
            response.get("model_used", "?"),
            (response.get("usage") or {}).get("tokens_in", 0),
            (response.get("usage") or {}).get("tokens_out", 0),
            elapsed,
        ))
        return AIResult(
            success=True,
            content=response.get("content", "") or "",
            usage=response.get("usage"),
            meta={
                "model_used": response.get("model_used", ""),
                "request_id": response.get("request_id", ""),
                "prompt_version": response.get("prompt_version", ""),
            },
        )

    _log("FAIL %s status=%d body=%s" % (path, status, json.dumps(response)[:300]),
         xbmc.LOGWARNING)
    return _translate_error(status, response)


# --------------------------------------------------------------------------- #
# Public API — called from plugin.py
# --------------------------------------------------------------------------- #
def recommend(
    seed_title,          # type: str
    seed_year=None,      # type: Optional[int]
    watched_titles=None, # type: Optional[List[str]]
    genre_prefs=None,    # type: Optional[Dict[str, float]]
    language="cs",       # type: str
    count=5,             # type: int
    quality="high",      # type: str
):
    # type: (...) -> AIResult
    """Ask RCAI for N film recommendations similar to seed.

    Returns AIResult with content = JSON string (server-side prompt instructs
    Claude to emit `{"recommendations": [...]}`). Parsing is caller's job —
    AI client doesn't own domain-specific schema.
    """
    body = {
        "quality": quality,
        "seed": {"title": seed_title, "year": seed_year},
        "watched_titles": watched_titles or [],
        "genre_prefs": genre_prefs or {},
        "language": language,
        "count": max(1, min(10, int(count))),
    }
    return _call("/v1/ai/recommend", body)


def identify(
    filename=None,        # type: Optional[str]
    partial_title=None,   # type: Optional[str]
    release_tag=None,     # type: Optional[str]
    year_hint=None,       # type: Optional[int]
    language_hint=None,   # type: Optional[str]
    extra=None,           # type: Optional[str]
    quality="high",       # type: str
):
    # type: (...) -> AIResult
    """Identify a film/TV title from partial / noisy metadata.

    Returns AIResult.content = JSON with title/year/type/confidence.
    """
    hints = {}
    if filename:       hints["filename"] = filename
    if partial_title:  hints["partial_title"] = partial_title
    if release_tag:    hints["release_tag"] = release_tag
    if year_hint:      hints["year_hint"] = int(year_hint)
    if language_hint:  hints["language_hint"] = language_hint
    if extra:          hints["extra"] = extra

    return _call("/v1/ai/identify", {"quality": quality, "hints": hints})


def chat(prompt, quality="high"):
    # type: (str, str) -> AIResult
    """Generic Claude prompt → response. Plain-text output."""
    return _call("/v1/ai/chat", {"quality": quality, "prompt": prompt or ""})


def get_usage_stats():
    # type: () -> AIResult
    """Fetch per-user AI usage stats (limits + history).

    Result.content is empty; useful data lives in result.meta['usage_data']
    which is the raw JSON dict from the server.
    """
    username, proof = get_identity()
    if not username or not proof:
        return AIResult(
            success=False,
            error_code=ERR_PROOF_MISSING,
            error_message="V nastavení chybí Webshare login/heslo.",
        )
    try:
        status, response = _post("/v1/ai/usage", build_common_fields())
    except Exception as exc:
        _log("Transport error on /v1/ai/usage: %r" % exc, xbmc.LOGERROR)
        return AIResult(
            success=False,
            error_code=ERR_TRANSPORT,
            error_message="Nelze se připojit k RichMovie Gate.",
        )
    if status == 200 and response.get("status") == "ok":
        return AIResult(
            success=True,
            content="",
            meta={"usage_data": response},
        )
    return _translate_error(status, response)


def is_available():
    # type: () -> bool
    """Quick check: is addon configured with Webshare creds? (Does NOT probe Gate.)

    Useful for plugin.py to decide whether to show the 'AI' menu item at all.
    Cheap (no network) — safe to call before every UI render.
    """
    username, proof = get_identity()
    return bool(username and proof)


# =========================================================================== #
# AI client functions — call RichMovie Gate → RichClaudeAI (Claude Opus).
# plugin.py imports these by name. (Historically these were shims for the
# removed richmovie_open_ai module; OpenAI is no longer used anywhere.)
# =========================================================================== #

class AIError(Exception):
    """Raised when an AI call fails in a way that should abort the user's
    action (as opposed to an AIResult(success=False) which callers may render
    as a softer UI dialog). The Gate-titles helpers below raise this for any
    non-success result so plugin.py error paths can catch a single type.
    """


def _call_titles(path, extra_body):
    # type: (str, Dict[str, Any]) -> List[Dict[str, Any]]
    """Shared helper: call Gate titles endpoint, return List[Dict].

    Raises AIError on any failure (transport, auth, rate limit, provider).
    """
    username, proof = get_identity()
    if not username or not proof:
        raise AIError("V nastavení chybí Webshare login/heslo.")

    body = build_common_fields()
    body.update(extra_body)

    started = time.time()
    try:
        status, response = _post(path, body)
    except Exception as exc:
        _log("Transport error on %s: %r" % (path, exc), xbmc.LOGERROR)
        raise AIError(
            "Nelze se připojit k RichMovie Gate. Zkontroluj připojení."
        )

    if status == 200 and response.get("status") == "ok":
        elapsed = time.time() - started
        titles = response.get("titles") or []
        _log("OK %s model=%s titles=%d tokens=%s/%s in %.1fs" % (
            path,
            response.get("model_used", "?"),
            len(titles),
            (response.get("usage") or {}).get("tokens_in", 0),
            (response.get("usage") or {}).get("tokens_out", 0),
            elapsed,
        ))
        return titles

    # Non-OK — build AIResult-style error, then raise AIError.
    translated = _translate_error(status, response)
    _log(
        "FAIL %s code=%s msg=%s" % (
            path, translated.error_code, translated.error_message,
        ),
        xbmc.LOGWARNING,
    )
    raise AIError(translated.error_message)


def recommend_titles(
    api_key,              # type: Optional[str]
    user_text,            # type: str
    want="any",           # type: str
    limit=8,              # type: int    (was 20 originally; 10 proved too
                          #               tight under 100s Cloudflare timeout
                          #               once we restored 3-6-sentence personi-
                          #               fied reasons — 10 × ~500 chars ≈ 5k
                          #               tokens ≈ 100s. 8 titles × 500 chars
                          #               ≈ 2200 tokens ≈ 45s, comfortable
                          #               headroom under the 100s wall.)
    model=None,           # type: Optional[str]
    timeout=None,         # type: Optional[int]
    retries=None,         # type: Optional[int]
    quality="high",       # type: str
):
    # type: (...) -> List[Dict[str, Any]]
    """Recommend titles via Gate → RCAI (Claude Opus).

    api_key is IGNORED (kept in signature for call-site compat). Tenant token
    lives on Gate, not passed from addon.
    model/timeout/retries are also IGNORED — Gate + RCAI handle retries and
    model selection via `quality` (default 'high' = Opus per plan).

    Returns List[Dict] with keys: title, year, kind, reason.
    Raises AIError on failure. (api_key/model/timeout/retries kept in the
    signature for call-site compatibility but ignored — Gate + RCAI own them.)
    """
    if want not in ("movie", "tv", "any"):
        want = "any"
    return _call_titles(
        "/v1/ai/recommend_titles",
        {"user_text": user_text or "",
         "want": want,
         "limit": max(1, min(30, int(limit))),
         "quality": quality},
    )


def identify_titles(
    api_key,              # type: Optional[str]
    user_text,            # type: str
    limit=5,              # type: int
    model=None,           # type: Optional[str]
    timeout=None,         # type: Optional[int]
    retries=None,         # type: Optional[int]
    quality="high",       # type: str
):
    # type: (...) -> List[Dict[str, Any]]
    """Identify titles from a free-text description via Gate → RCAI.

    See recommend_titles() for parameter semantics. Returns List[Dict] with:
    title, kind, year, reason, confidence, missing_facts.
    """
    return _call_titles(
        "/v1/ai/identify_titles",
        {"user_text": user_text or "",
         "limit": max(1, min(10, int(limit))),
         "quality": quality},
    )
