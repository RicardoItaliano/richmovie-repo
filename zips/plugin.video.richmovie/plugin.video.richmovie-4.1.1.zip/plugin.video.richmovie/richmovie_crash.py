# -*- coding: utf-8 -*-
"""
RichMovie – Crash Reporting (Gate /crash endpoint)

Automaticky zachytava neosetrene Python vyjimky a odesila je
na Gate server (/crash endpoint).

Architektura:
  1) sys.excepthook zachyti pad → zapis do crash_queue.json (okamzity)
  2) Pri dalsim startu pluginu/servicu → flush_pending() odesle na Gate

DULEZITE: Vsechny funkce jsou obalene v try/except.
Tento modul NESMI nikdy spadnout sam.
"""

from __future__ import annotations

import hashlib
import json
import socket
import sys
import time
import traceback
import threading
import urllib.request
from pathlib import Path
from typing import Any

# Kodi API (nepovinne – modul musi prezit i mimo Kodi pro testovani)
try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except ImportError:
    xbmc = None  # type: ignore
    xbmcaddon = None  # type: ignore
    xbmcvfs = None  # type: ignore


# ─────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────
_ADDON_ID = "plugin.video.richmovie"

_MAX_REPORTS_PER_HOUR = 5
_MAX_QUEUE_SIZE = 20
_MAX_LOG_LINES = 30
_MAX_TB_CHARS = 2000
_STALE_DAYS = 7
_QUEUE_FILENAME = "crash_queue.json"


# ─────────────────────────────────────────────────────────────
#  STAV MODULU
# ─────────────────────────────────────────────────────────────
_installed = False
_original_excepthook = None
_source = "plugin"


# ─────────────────────────────────────────────────────────────
#  HELPERY
# ─────────────────────────────────────────────────────────────
_log_router = None  # lazy cache routovaného loggeru (viz _log)


def _log(msg: str, level: int = 1) -> None:
    """Observability 2026-07-02 (3.5.84): routovaný logger → záznamy crash
    reporteru (vč. selhání uložení fronty) tečou i na NAS. Lazy init = žádná
    závislost na pořadí importů (crash modul se instaluje jako první);
    make_legacy_logger má vlastní fallback na přímý xbmc.log, dokud pipeline
    neběží. Best-effort — nikdy nevyhazuje."""
    global _log_router
    try:
        if _log_router is None:
            from richmovie_logging import make_legacy_logger as _cr_mll
            _log_router = _cr_mll("richmovie.crash", "RichMovie/Crash")
        _log_router(msg, level)
        return
    except Exception:
        pass
    try:
        if xbmc:
            xbmc.log(f"[RichMovie/Crash] {msg}", level)
    except Exception:
        pass


def _get_profile_dir() -> Path:
    try:
        if xbmcvfs and xbmcaddon:
            p = xbmcvfs.translatePath(
                xbmcaddon.Addon(_ADDON_ID).getAddonInfo("profile")
            )
            path = Path(p)
            path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    return Path(".")


def _get_queue_path() -> Path:
    return _get_profile_dir() / _QUEUE_FILENAME


# ─────────────────────────────────────────────────────────────
#  DEVICE INFO
# ─────────────────────────────────────────────────────────────
def _device_info() -> dict[str, str]:
    info: dict[str, str] = {}

    # Platform: SSOT z richmovie_gate_transport (stejny zdroj jako auth_logs/user_logs).
    # Defenzivni fallback na lokalni detekci — crash path musi prezit i kdyz SSOT import
    # selze (vc. pripadu kdy pad zpusobil prave gate_transport).
    try:
        import richmovie_gate_transport
        info["platform"] = richmovie_gate_transport.detect_platform()
    except Exception:
        try:
            import platform as _plat
            info["platform"] = _plat.system() or "?"
            if xbmc and xbmc.getCondVisibility("system.platform.android"):
                info["platform"] = "Android"
        except Exception:
            info.setdefault("platform", "?")

    # arch (nezavisly na platform SSOT — crash report chce i architekturu)
    try:
        import platform as _plat
        info["arch"] = _plat.machine() or "?"
    except Exception:
        info.setdefault("arch", "?")

    # Kodi verze
    try:
        if xbmc:
            info["kodi_version"] = xbmc.getInfoLabel("System.BuildVersion") or "?"
    except Exception:
        info.setdefault("kodi_version", "?")

    # Addon verze
    try:
        if xbmcaddon:
            info["addon_version"] = xbmcaddon.Addon(_ADDON_ID).getAddonInfo("version") or "?"
    except Exception:
        info.setdefault("addon_version", "?")

    # Device hash (anonymni ale stabilni identifikator)
    try:
        hostname = socket.gethostname() or "unknown"
        info["device_hash"] = hashlib.sha256(hostname.encode("utf-8")).hexdigest()[:6]
    except Exception:
        info["device_hash"] = "000000"

    return info


# ─────────────────────────────────────────────────────────────
#  LOG TAIL
# ─────────────────────────────────────────────────────────────
def _last_log_lines(n: int = _MAX_LOG_LINES) -> str:
    try:
        log_path = _get_profile_dir() / "richmovie.log"
        if not log_path.exists():
            return "(log unavailable)"
        text = log_path.read_text(encoding="utf-8", errors="replace")
        lines = text.strip().splitlines()
        return "\n".join(lines[-n:])
    except Exception:
        return "(log unavailable)"


# ─────────────────────────────────────────────────────────────
#  FINGERPRINT (deduplikace)
# ─────────────────────────────────────────────────────────────
def _fingerprint(exc_type_name: str, tb_text: str) -> str:
    try:
        # Posledni "File ..." radek z tracebacku = misto padu
        last_file = ""
        for line in tb_text.splitlines():
            stripped = line.strip()
            if stripped.startswith("File "):
                last_file = stripped
        combined = f"{exc_type_name}:{last_file}"
        return hashlib.md5(combined.encode("utf-8")).hexdigest()[:8]
    except Exception:
        return "00000000"


# ─────────────────────────────────────────────────────────────
#  FRONTA (crash_queue.json)
# ─────────────────────────────────────────────────────────────
def _load_queue() -> dict[str, Any]:
    try:
        qp = _get_queue_path()
        if qp.exists():
            with open(qp, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {"version": 1, "reports": []}


def _save_queue(data: dict[str, Any]) -> None:
    """Trvanlivý atomický zápis přes SSOT `richmovie_atomic` (3.5.123):
    fronta crash reportů je poslední stopa padajícího procesu — nesmí zmizet
    ani při výpadku napájení hned po zápisu."""
    try:
        import richmovie_atomic as _atomic
        if not _atomic.write_json(str(_get_queue_path()), data, indent=1):
            _log("Queue save failed", xbmc.LOGWARNING)
    except Exception as exc:
        try:
            _log("Queue save failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass


def _enqueue(record: dict[str, Any]) -> None:
    try:
        data = _load_queue()
        reports = data.get("reports", [])
        if not isinstance(reports, list):
            reports = []
        reports.append(record)
        # Omez velikost fronty
        if len(reports) > _MAX_QUEUE_SIZE:
            reports = reports[-_MAX_QUEUE_SIZE:]
        data["reports"] = reports
        _save_queue(data)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────
#  EXCEPTHOOK
# ─────────────────────────────────────────────────────────────
def _on_crash(exc_type, exc_value, exc_tb) -> None:
    """sys.excepthook callback."""
    try:
        # Zavolej puvodni hook (aby Kodi dostal normalni traceback do logu)
        if _original_excepthook:
            _original_excepthook(exc_type, exc_value, exc_tb)
    except Exception:
        pass

    # SystemExit / KeyboardInterrupt nereportujeme
    if exc_type in (SystemExit, KeyboardInterrupt):
        return

    try:
        tb_text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        if len(tb_text) > _MAX_TB_CHARS:
            tb_text = tb_text[-_MAX_TB_CHARS:]

        exc_type_name = getattr(exc_type, "__name__", str(exc_type))
        exc_msg = str(exc_value or "")[:200]

        now = time.time()
        dev = _device_info()

        record = {
            "id": f"{dev.get('device_hash', '?')}-{int(now)}",
            "ts": int(now),
            "ts_iso": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(now)),
            "exc_type": exc_type_name,
            "exc_msg": exc_msg,
            "traceback": tb_text,
            "fingerprint": _fingerprint(exc_type_name, tb_text),
            "device": dev,
            "log_tail": _last_log_lines(),
            "source": _source,
            "sent": False,
            "sent_ts": None,
        }

        _enqueue(record)
        _log(f"Crash captured: {exc_type_name}: {exc_msg[:80]}")

        # Best-effort: pokus o okamzite odeslani (async).
        # 3.4.7 (audit Ω2, 2026-05-17): daemon=False per memory rule. Crash
        # event = nejpravděpodobnější chvíle pro Kodi shutdown → daemon
        # thread killed mid-POST, mid-queue-rewrite. Record je už v queue
        # (line ~255) tak durabilita přežije, ale silent kill během rewrite
        # může korumpovat queue. Non-daemon: krátký work (<2s timeout
        # nahoře), join na Kodi exit je akceptovatelný.
        try:
            if xbmcaddon:
                import richmovie_settings as _rm_settings   # SSOT (nová instance, 3.5.124)
                ws_pw = _rm_settings.get_str("password")
                if ws_pw:
                    threading.Thread(
                        target=_try_send_one,
                        args=(record, ws_pw),
                        daemon=False,
                        name="RMCrashFlush",
                    ).start()
        except Exception:
            pass

    except Exception:
        pass


def _try_send_one(record: dict[str, Any], ws_password: str = "") -> None:
    """Pokusi se odeslat jeden crash report na Gate /crash. Bezi v daemon threadu."""
    try:
        import richmovie_gate
        gate_url = richmovie_gate.get_gate_url()
        if not gate_url:
            return
        ok = _send_to_gate(gate_url, record)
        if ok:
            _log(f"Crash sent: {record.get('id', '?')}")
            try:
                data = _load_queue()
                for r in data.get("reports", []):
                    if r.get("id") == record.get("id"):
                        r["sent"] = True
                        r["sent_ts"] = int(time.time())
                        break
                _save_queue(data)
            except Exception:
                pass
    except Exception as e:
        _log(f"Send failed: {e}")


# ─────────────────────────────────────────────────────────────
#  VEREJNE API
# ─────────────────────────────────────────────────────────────
def install(source: str = "plugin") -> None:
    """
    Registruje sys.excepthook pro zachytavani padu.
    Idempotentni – pri vicenasobnem volani se registruje jen jednou.

    Args:
        source: identifikator procesu ("plugin", "service_nextup", "service_warm")
    """
    global _installed, _original_excepthook, _source
    try:
        if _installed:
            return
        _source = source
        _original_excepthook = sys.excepthook
        sys.excepthook = _on_crash
        _installed = True
        _log(f"Installed (source={source})")
    except Exception:
        pass


def flush_pending(ws_password: str = "") -> None:
    """
    Odesle vsechny cekajici crash reporty na Gate /crash endpoint.
    Volat z plugin.py / service po prihlaseni.

    Args:
        ws_password: zachovano pro zpetnou kompatibilitu (uz se nepouziva)
    """
    try:
        # Zjisti Gate URL
        try:
            import richmovie_gate
            gate_url = richmovie_gate.get_gate_url()
        except ImportError:
            gate_url = ""

        if not gate_url:
            _log("Flush: no Gate URL available")
            return

        data = _load_queue()
        reports = data.get("reports", [])
        if not isinstance(reports, list) or not reports:
            return

        # Throttle: max N reportu za hodinu
        now = time.time()
        recent_sent = sum(
            1 for r in reports
            if r.get("sent") and r.get("sent_ts") and (now - r["sent_ts"]) < 3600
        )
        if recent_sent >= _MAX_REPORTS_PER_HOUR:
            _log(f"Flush throttled ({recent_sent} sent in last hour)")
            return

        sent_count = 0
        for record in reports:
            if record.get("sent"):
                continue

            if (recent_sent + sent_count) >= _MAX_REPORTS_PER_HOUR:
                break

            try:
                ok = _send_to_gate(gate_url, record)
                if ok:
                    record["sent"] = True
                    record["sent_ts"] = int(now)
                    sent_count += 1
                    _log(f"Flushed: {record.get('id', '?')}")
            except Exception as e:
                _log(f"Flush send error: {e}")
                break  # Selhani site → prestaneme (retry priste)

        # Cistka: smazat stare zaznamy (> 7 dni)
        cutoff = now - (_STALE_DAYS * 86400)
        reports = [r for r in reports if r.get("ts", 0) > cutoff]

        data["reports"] = reports
        _save_queue(data)

        if sent_count:
            _log(f"Flush done: {sent_count} sent")
    except Exception as e:
        _log(f"Flush error: {e}")


def _send_to_gate(gate_url: str, record: dict[str, Any]) -> bool:
    """Send crash report to Gate /crash endpoint."""
    dev = record.get("device", {})
    ws_username = ""
    try:
        if xbmcaddon:
            import richmovie_settings as _rm_settings   # SSOT (nová instance, 3.5.124)
            ws_username = _rm_settings.get_str("username")
    except Exception:
        pass

    # 3.5.121: doložení identity — BEST-EFFORT, nikdy jako podmínka odeslání.
    # Crash report je poslední zpráva padajícího procesu; kdyby ho zablokovalo
    # nedostupné nastavení (ze kterého se proof odvozuje), ztratili bychom stopu
    # přesně po tom druhu pádu, který vyšetřujeme (incident bandog 27.08.2026).
    # Server proto crash bez proof přijme — odmítne jen prokazatelně nesedící
    # identitu. `device_hash` se posílá ze SOUBORU, takže nezávisí na nastavení.
    body = {
        "ws_username": ws_username,
        "platform": dev.get("platform", ""),
        "kodi_version": dev.get("kodi_version", ""),
        "addon_version": dev.get("addon_version", ""),
        "exc_type": record.get("exc_type", ""),
        "exc_msg": record.get("exc_msg", ""),
        "traceback": record.get("traceback", ""),
        "fingerprint": record.get("fingerprint", ""),
        "log_tail": record.get("log_tail", ""),
        "source": record.get("source", ""),
    }
    try:
        import richmovie_gate_transport as _gt
        _dh = _gt.get_device_hash()
        if _dh:
            body["device_hash"] = _dh
        _u, _proof = _gt.get_identity()
        if _proof:
            body["ws_proof"] = _proof
    except Exception:
        # Ticho je tady správně: bez identity se crash pošle stejně a server ho
        # přijme jako `trust='none'`. Logovat by znamenalo riskovat rekurzi
        # v okamžiku pádu.
        pass

    payload = json.dumps(body, ensure_ascii=False).encode("utf-8")

    req = urllib.request.Request(
        f"{gate_url}/crash",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    resp = urllib.request.urlopen(req, timeout=5)
    return resp.getcode() in (200, 201)
