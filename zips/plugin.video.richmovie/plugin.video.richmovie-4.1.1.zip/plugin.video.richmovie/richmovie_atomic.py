# -*- coding: utf-8 -*-
"""
richmovie_atomic.py — SSOT trvanlivých zápisů a diagnostikovaných čtení souborů
==============================================================================

PROČ TENHLE MODUL EXISTUJE (incident gunžík 30.08.2026)
-------------------------------------------------------
Doplněk měl `os.replace` v 16 modulech a **`os.fsync` jen v jednom** (breadcrumb).
Vzor „temp → replace" je atomický vůči *souběhu* (nikdo nikdy nevidí půl souboru),
ale NE vůči *výpadku napájení*: rename je na žurnálovaných FS trvalý dřív než data,
takže po vytržení ze zásuvky (Android TV box), pádu notebooku „ve spánku" nebo
tvrdém vypnutí může být přejmenovaný soubor **nulové délky**. Nulový JSON pak
propadl jako „soubor chybí" → tichý default → u kolekcí plná reinstalace 4 386
položek, u Pokračovat ve sledování ztráta pozic, u telemetrie ztráta bufferu.

Druhá polovina problému byla tichost: chybějící nebo poškozený soubor se logoval
na DEBUG (nebo vůbec) a **další zápis důkaz přepsal**. Nešlo pak rozlišit čerstvou
instalaci od ztráty dat (`feedback_diagnostic_channel_independence`).

CO MODUL GARANTUJE
------------------
`write_*`  : tmp ve STEJNÉ složce → zápis → `flush` → `fsync(fd)` → `os.replace`
             → (POSIX) `fsync` adresáře. Po návratu `True` je obsah na disku a
             soubor je buď celý starý, nebo celý nový — nikdy prázdný, nikdy
             půlka. `False` = nic se nezměnilo (tmp uklizen) a důvod je v logu.
`read_json`: vrací `(hodnota, stav)`. Stav rozlišuje OK / NO_FILE / EMPTY /
             CORRUPT / UNREADABLE — stejná disciplína jako
             `richmovie_settings.read_key_from_file`. Poškozený soubor se
             **přejmenuje do karantény** (`<jméno>.corrupt-<ts>`), zaloguje se
             ERROR s velikostí, mtime a prvními bajty, a teprve pak se vrátí
             default. Důkaz se nikdy nepřepisuje.

Modul NIKDY nevyhazuje — chyba I/O nesmí shodit doplněk. Žádné Kodi závislosti
mimo routovaný logger (s fallbackem), takže je použitelný i z breadcrumb vrstvy
a v offline harnessu.

Python 3.8 (Kodi runtime).
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from typing import Any, Optional, Tuple

try:
    import xbmc
    _LOGINFO, _LOGWARNING, _LOGERROR, _LOGDEBUG = (
        xbmc.LOGINFO, xbmc.LOGWARNING, xbmc.LOGERROR, xbmc.LOGDEBUG)
except Exception:  # pragma: no cover — mimo Kodi (nástroje, testy)
    xbmc = None  # type: ignore
    _LOGDEBUG, _LOGINFO, _LOGWARNING, _LOGERROR = 0, 1, 2, 3

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.atomic", "RichMovie/Atomic")
except Exception:  # pragma: no cover
    def _log(msg, level=_LOGINFO, *, context=None):
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/Atomic] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Stavy čtení — jediné místo, kde jsou vyjmenované
# --------------------------------------------------------------------------- #
STATE_OK = "ok"                  # soubor přečten a rozparsován
STATE_NO_FILE = "no_file"        # soubor neexistuje (čerstvá instalace, nebo ztráta)
STATE_EMPTY = "empty"            # soubor existuje, ale má 0 bajtů (typicky pád po rename)
STATE_CORRUPT = "corrupt"        # soubor má obsah, ale není to platný JSON / tvar
STATE_UNREADABLE = "unreadable"  # I/O chyba při čtení (práva, zamčený soubor)

QUARANTINE_SUFFIX = ".corrupt-"
QUARANTINE_MAX_AGE_S = 30 * 24 * 3600

_TMP_SUFFIX = ".tmp"
# 3.5.151 (plán PLAN_resume_native_start_sync_integrity_20260916, Φ3): tmp je JEDINEČNÝ per
# zapisovatel (`<soubor>.<pid>-<vlákno>.tmp`). Pevné `<soubor>.tmp` sdílely dva procesy: první
# startovní pull služby a dvakrát spuštěné hlavní menu zapisovaly `watched_episodes.json` naráz
# (notebook 16.09.2026 22:14:27–22:15:06: 30× WRITE_FAILED FileNotFoundError / PermissionError) —
# jeden `O_TRUNC` přepsal rozepsaný tmp druhého a `os.replace` pak přesunul cizí obsah.
_TMP_TAGGED = re.compile(r"\.\d+-\d+\.tmp$")
STALE_TMP_MAX_AGE_S = 24 * 3600     # osiřelý tmp (proces zabit mezi zápisem a replace)


def _tmp_path(path: str) -> str:
    return "%s.%d-%d%s" % (path, os.getpid(), threading.get_ident(), _TMP_SUFFIX)


class _FailureScope(object):
    """Počítadlo selhaných zápisů v jednom vláknu (viz `failure_scope`)."""

    def __init__(self) -> None:
        self.failed = 0
        self.paths = []   # type: list

    def __enter__(self):
        stack = getattr(_scopes, "stack", None)
        if stack is None:
            stack = []
            _scopes.stack = stack
        stack.append(self)
        return self

    def __exit__(self, *exc):
        stack = getattr(_scopes, "stack", None) or []
        if stack and stack[-1] is self:
            stack.pop()
        elif self in stack:
            stack.remove(self)
        return False


_scopes = threading.local()


def failure_scope() -> _FailureScope:
    """Kontext, který spočítá selhané `write_*` v TOMTO vlákně (i vnořené volání).

        with richmovie_atomic.failure_scope() as writes:
            apply_remote(items)          # uvnitř desítky save funkcí, které chybu jen zalogují
        ok = writes.failed == 0          # kurzor synchronizace posunout JEN když se vše zapsalo

    PROČ: sloučení stavu z Gate volá mutátory (`watched_*`, `cw_*`, `save_history`…), které
    selhání zápisu z historických důvodů polykají. Kurzor se pak posunul, přestože data na disku
    nejsou (R2 „selhání se neperzistuje" — porušeno tiše). Scope sbírá výsledek bez změny
    návratových typů desítek funkcí."""
    return _FailureScope()


def _note_write_failure(path: str) -> None:
    for scope in getattr(_scopes, "stack", None) or []:
        scope.failed += 1
        scope.paths.append(os.path.basename(path))


class FileLock:
    """CROSS-PROCESS zámek nad souborem (lockfile `O_CREAT|O_EXCL`, atomický na
    všech Kodi platformách vč. Android/SMB-free profilu). Plugin (nový interpret
    na každou invokaci) a služba zapisují TYTÉŽ soubory — `threading.Lock` chrání
    jen vlastní proces. Retry 20×50 ms, stale zámek (držitel umřel, > `stale_s`)
    se ukradne. Best-effort: po timeoutu se pokračuje bez zámku (zápis dat nesmí
    blokovat UI). Původně `richmovie_telemetry._PendingSearchFileLock` (Φ8),
    povýšeno sem 3.5.134 pro frontu stavu profilu (richmovie_state_sync)."""

    STALE_S = 3.0
    WAIT_S = 1.0          # výchozí čekání na cizí zámek (UI nesmí mrznout); pak best-effort bez zámku
    POLL_S = 0.05

    def __init__(self, lock_path: str, *, stale_s: Optional[float] = None,
                 wait_s: Optional[float] = None) -> None:
        self._path = str(lock_path)
        self._stale_s = float(stale_s if stale_s is not None else self.STALE_S)
        # 3.5.151 (cross-check Pro B PB2a): dávkový zápis ✔ s fsync na pomalém TV boxu trvá déle
        # než výchozí 1 s — takový zapisovatel si řekne o delší čekání (< stale_s, jinak by kradl).
        self._wait_s = max(self.POLL_S, float(wait_s if wait_s is not None else self.WAIT_S))
        self._acquired = False

    def __enter__(self):
        for _ in range(max(1, int(round(self._wait_s / self.POLL_S)))):
            try:
                fd = os.open(self._path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                # os.write může selhat (disk full) PO úspěšném os.open → fd MUSÍ být
                # uzavřen i na chybové cestě, jinak leak file descriptoru.
                try:
                    os.write(fd, str(time.time()).encode("ascii"))
                finally:
                    os.close(fd)
                self._acquired = True
                return self
            except FileExistsError:
                try:
                    if (time.time() - os.path.getmtime(self._path)) > self._stale_s:
                        os.unlink(self._path)  # stale — držitel umřel
                        continue
                except OSError:
                    pass
                time.sleep(self.POLL_S)
            except OSError:
                break  # FS problém → best-effort bez zámku
        return self

    def __exit__(self, *exc):
        if self._acquired:
            try:
                os.unlink(self._path)
            except OSError:
                pass
        return False


# --------------------------------------------------------------------------- #
# Zápis
# --------------------------------------------------------------------------- #
def write_bytes(path: str, data: bytes, *, mode: int = 0o644) -> bool:
    """Trvanlivý atomický zápis bajtů. `True` = obsah je na disku pod `path`.

    Pořadí je podstatné a nesmí se měnit:
      1. tmp ve stejné složce (rename přes hranici FS není atomický),
      2. `os.write` celého obsahu (smyčka — `write` smí zapsat méně),
      3. `os.fsync(fd)` — data na disku DŘÍV, než se objeví pod cílovým jménem,
      4. `os.replace` — atomická výměna jména,
      5. `fsync` adresáře (POSIX) — aby přežil i samotný rename.
    """
    path = str(path)
    directory = os.path.dirname(path) or "."
    tmp = _tmp_path(path)
    fd = -1
    try:
        os.makedirs(directory, exist_ok=True)
        # O_BINARY: Kodi vestavěný Python 3.8 na Windows otevírá `os.open` v TEXTOVÉM režimu
        # (CPython v CLI si nastaví binární `_fmode` při startu, embedded interpret ne) →
        # každé `\n` odchází jako `\r\n`. Incident 05.09.2026: kopie continue_watching.json
        # (už s CRLF) dostala `\r\r\n`, kontrola velikosti migrace profilů selhala.
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_BINARY", 0), mode)
        view = memoryview(data)
        offset = 0
        while offset < len(view):
            written = os.write(fd, view[offset:])
            if written <= 0:
                raise OSError("os.write returned %r" % (written,))
            offset += written
        os.fsync(fd)
        os.close(fd)
        fd = -1
        _replace_with_retry(tmp, path)
        _fsync_directory(directory)
        return True
    except Exception as exc:
        _log("WRITE_FAILED %s: %r" % (os.path.basename(path), exc), _LOGWARNING,
             context={"path": path, "err_class": type(exc).__name__,
                      "free_mb": _free_space_mb(directory)})
        _note_write_failure(path)
        return False
    finally:
        if fd >= 0:
            try:
                os.close(fd)
            except Exception:
                pass
        try:
            if os.path.exists(tmp):
                os.unlink(tmp)
        except Exception:
            pass


REPLACE_RETRIES = 4            # N7 (13.09.2026): Windows sharing violation při souběhu plugin × služba
REPLACE_RETRY_WAIT_S = 0.05    # 4 × 50 ms = 200 ms; čtenář drží soubor jen po dobu `read()`


def _replace_with_retry(tmp: str, path: str) -> None:
    """`os.replace` s krátkým opakováním na `PermissionError` (Windows: druhý proces má cíl právě
    otevřený ke čtení → ERROR_SHARING_VIOLATION; incident Richie-Office 13.09. 11:14, WRITE_FAILED
    pending_state.json). Není to síťový retry (pravidlo „nikdy time.sleep v retry cestě" se týká
    HTTP) — souborový zámek se uvolní za milisekundy. Po posledním pokusu výjimka propadne
    volajícímu (WRITE_FAILED + fronta zůstává, R2)."""
    for attempt in range(REPLACE_RETRIES):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:
            if attempt == REPLACE_RETRIES - 1:
                raise
            time.sleep(REPLACE_RETRY_WAIT_S)


def write_text(path: str, text: str, *, encoding: str = "utf-8") -> bool:
    try:
        payload = text.encode(encoding)
    except Exception as exc:
        _log("WRITE_ENCODE_FAILED %s: %r" % (os.path.basename(str(path)), exc), _LOGWARNING)
        _note_write_failure(str(path))
        return False
    return write_bytes(path, payload)


def write_json(path: str, obj: Any, *, indent: Optional[int] = None,
               ensure_ascii: bool = False,
               separators: Optional[Tuple[str, str]] = None) -> bool:
    """Serializace probíhá PŘED otevřením souboru — neserializovatelný objekt
    nesmí zanechat prázdný tmp ani sáhnout na existující data."""
    try:
        text = json.dumps(obj, ensure_ascii=ensure_ascii, indent=indent,
                          separators=separators, default=_json_default)
    except Exception as exc:
        _log("WRITE_SERIALIZE_FAILED %s: %r" % (os.path.basename(str(path)), exc),
             _LOGWARNING, context={"path": str(path), "err_class": type(exc).__name__})
        _note_write_failure(str(path))
        return False
    return write_text(path, text)


def _json_default(value: Any) -> Any:
    """`default=str` by tiše přepsal nečekaný typ na text; tohle je stejně
    tolerantní, ale zapíše do logu, KDE se nečekaný typ vzal."""
    _log("WRITE_JSON_COERCED %s" % type(value).__name__, _LOGDEBUG)
    return str(value)


# --------------------------------------------------------------------------- #
# Čtení s diagnostikou
# --------------------------------------------------------------------------- #
def read_json(path: str, default: Any, *, name: Optional[str] = None,
              expected_type: Optional[type] = None,
              quarantine_on_corrupt: bool = True) -> Tuple[Any, str]:
    """Načte JSON a vrátí `(hodnota, stav)`.

    `default` se vrací pro každý stav kromě OK — ale s odlišnou hlasitostí:
      NO_FILE     → INFO (legitimní u čerstvé instalace; kontext nese, co jiného
                    ve složce je, takže ztráta jednoho souboru se pozná od prázdné
                    složky),
      EMPTY       → ERROR + karanténa (nulový soubor = typický otisk pádu po rename),
      CORRUPT     → ERROR + karanténa (obsah, který není JSON, nebo špatný tvar),
      UNREADABLE  → ERROR bez karantény (soubor tam možná je, jen ho nejde číst).
    `expected_type` (např. `dict`) povyšuje špatný tvar na CORRUPT — platný JSON
    se špatným tvarem je pro volajícího stejně nepoužitelný jako rozbitý.
    """
    path = str(path)
    label = name or os.path.basename(path)
    try:
        if not os.path.isfile(path):
            # DEBUG (3.5.152): na čerstvé instalaci chybí desítky souborů legitimně — desítky INFO
            # řádků při každém startu byly šum (backlog 3.5.151); ztrátu souboru odhalí volající.
            _log("READ_NO_FILE %s" % label, _LOGDEBUG,
                 context={"path": path, "state": STATE_NO_FILE,
                          "dir_entries": _dir_entry_count(os.path.dirname(path))})
            return default, STATE_NO_FILE
    except Exception as exc:
        _log("READ_UNREADABLE %s: %r" % (label, exc), _LOGERROR,
             context={"path": path, "state": STATE_UNREADABLE})
        return default, STATE_UNREADABLE

    try:
        with open(path, "rb") as fh:
            raw = fh.read()
    except Exception as exc:
        _log("READ_UNREADABLE %s: %r" % (label, exc), _LOGERROR,
             context={"path": path, "state": STATE_UNREADABLE,
                      "err_class": type(exc).__name__})
        return default, STATE_UNREADABLE

    if not raw.strip():
        _report_bad_file(path, label, STATE_EMPTY, raw, quarantine_on_corrupt)
        return default, STATE_EMPTY

    try:
        value = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        _report_bad_file(path, label, STATE_CORRUPT, raw, quarantine_on_corrupt,
                         detail=repr(exc)[:160])
        return default, STATE_CORRUPT

    if expected_type is not None and not isinstance(value, expected_type):
        _report_bad_file(path, label, STATE_CORRUPT, raw, quarantine_on_corrupt,
                         detail="expected %s, got %s" % (
                             expected_type.__name__, type(value).__name__))
        return default, STATE_CORRUPT

    return value, STATE_OK


def _report_bad_file(path: str, label: str, state: str, raw: bytes,
                     quarantine: bool, detail: str = "") -> None:
    ctx = {"path": path, "state": state, "bytes": len(raw),
           "head": raw[:48].decode("utf-8", errors="replace"), "detail": detail}
    try:
        ctx["mtime"] = int(os.stat(path).st_mtime)
    except Exception:
        pass
    quarantined = quarantine_file(path) if quarantine else None
    ctx["quarantined_to"] = os.path.basename(quarantined) if quarantined else ""
    _log("READ_%s %s bytes=%d quarantined=%s %s" % (
        state.upper(), label, len(raw), bool(quarantined), detail), _LOGERROR,
        context=ctx)


def quarantine_file(path: str) -> Optional[str]:
    """Přejmenuje poškozený soubor na `<path>.corrupt-<ts>`. Vrací novou cestu,
    nebo None. Původní jméno se tím uvolní pro čistý zápis defaultu; důkaz
    zůstává vedle něj do úklidu (`cleanup_quarantine`)."""
    try:
        # Jméno musí být unikátní i při dvou karanténách v téže vteřině (harness
        # scénář 40 to trefil hned) — jinak by druhý `os.replace` PŘEPSAL první
        # důkaz. Milisekundy + pořadové číslo, když by i to kolidovalo.
        base = "%s%s%d" % (path, QUARANTINE_SUFFIX, int(time.time() * 1000))
        target = base
        counter = 1
        while os.path.exists(target):
            target = "%s-%d" % (base, counter)
            counter += 1
        os.replace(path, target)
        return target
    except Exception as exc:
        _log("QUARANTINE_FAILED %s: %r" % (os.path.basename(path), exc), _LOGWARNING)
        return None


def cleanup_quarantine(directory: str, *, max_age_s: int = QUARANTINE_MAX_AGE_S) -> int:
    """Smaže karanténní soubory starší než `max_age_s`. Vrací počet."""
    removed = 0
    try:
        for entry in os.listdir(directory):
            if QUARANTINE_SUFFIX not in entry:
                continue
            full = os.path.join(directory, entry)
            try:
                if time.time() - os.stat(full).st_mtime > max_age_s:
                    os.unlink(full)
                    removed += 1
            except Exception:
                continue
    except Exception:
        pass
    return removed


def cleanup_stale_tmp(directory: str, *, max_age_s: int = STALE_TMP_MAX_AGE_S) -> int:
    """Smaže osiřelé tmp soubory (proces zabit mezi zápisem a `os.replace`) starší než
    `max_age_s`: nové `<soubor>.<pid>-<vlákno>.tmp` i staré pevné `<soubor>.json.tmp`
    z verzí ≤ 3.5.150. Čerstvé tmp nechá — může je právě psát živý proces."""
    removed = 0
    try:
        for entry in os.listdir(directory):
            if not (_TMP_TAGGED.search(entry) or entry.endswith(".json" + _TMP_SUFFIX)):
                continue
            full = os.path.join(directory, entry)
            try:
                if os.path.isfile(full) and time.time() - os.stat(full).st_mtime > max_age_s:
                    os.unlink(full)
                    removed += 1
            except Exception:
                continue
    except Exception:
        pass
    return removed


def cleanup_data_dirs(root: str) -> Tuple[int, int]:
    """Úklid kořene dat a adresářů profilů (`profiles/*`): (tmp, karanténa). Volá služba
    jednou při startu. Do 3.5.150 se `cleanup_quarantine` nevolal nikde."""
    tmp_removed = quarantine_removed = 0
    dirs = [root]
    try:
        profiles = os.path.join(root, "profiles")
        if os.path.isdir(profiles):
            dirs.extend(os.path.join(profiles, d) for d in os.listdir(profiles)
                        if os.path.isdir(os.path.join(profiles, d)))
    except Exception:
        pass
    for directory in dirs:
        tmp_removed += cleanup_stale_tmp(directory)
        quarantine_removed += cleanup_quarantine(directory)
    if tmp_removed or quarantine_removed:
        _log("CLEANUP tmp=%d karanténa=%d (%d adresářů)" % (tmp_removed, quarantine_removed, len(dirs)),
             _LOGINFO)
    return tmp_removed, quarantine_removed


# --------------------------------------------------------------------------- #
# Pomocné
# --------------------------------------------------------------------------- #
def _fsync_directory(directory: str) -> None:
    """Na POSIX je rename trvalý až po fsync adresáře. Windows to nepodporuje
    (`os.open` adresáře selže) — tam NTFS žurnál rename drží sám."""
    if os.name == "nt":
        return
    try:
        dfd = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except Exception:
        pass


def _dir_entry_count(directory: str) -> int:
    try:
        return len(os.listdir(directory))
    except Exception:
        return -1


def _free_space_mb(directory: str) -> int:
    try:
        import shutil
        return int(shutil.disk_usage(directory).free // (1024 * 1024))
    except Exception:
        return -1
