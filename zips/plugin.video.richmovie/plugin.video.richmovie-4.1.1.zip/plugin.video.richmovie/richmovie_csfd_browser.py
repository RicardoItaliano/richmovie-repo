# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_csfd_browser.py
# Addon-side "Moje CSFD" browser — ratings, watchlist, top-rated.
# Phase B11 (RichMovie 3.2.0-beta.2, 2026-04-26).
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie 3.2.0 — "Moje CSFD" browser

Renders three Kodi listings backed by Gate's `/v1/csfd/my/*` endpoints:

    show_my_csfd_root()          — submenu (3 items)
    show_my_ratings(page=0)      — paginated ratings list
    show_my_watchlist(page=0)    — paginated watchlist
    show_my_top_rated(page=0)    — filter: rating_pct >= 80 (4-5★)

Each item shows poster + title + rating + year (when TMDb mapping resolved).
Items lacking TMDb resolution still appear — title + year + rating only —
and the resolver fills posters for next visit. No on-demand TMDb fetch on
the browse path, so opening the list is always fast.

Click default:
    - With TMDb id (movie):  ?action=auto&tmdb=<id>           → direct releases
    - With TMDb id (tv):     ?action=tv_seasons&tv_id=<id>... → seasons listing
    - Without TMDb id:       ?action=movie_search/tv_search&q=<title>

Context menu:
    - "Hledat releases"  → fallback path (same as no-TMDb click)
    - "Podobné filmy/seriály" → existing TMDb similarity flow

Author: Richie (autonomous Phase B11 implementation 2026-04-26)
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import sys
import urllib.parse
import urllib.request
import urllib.error
from typing import Any

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import richmovie_routes as _routes

_LOG_PREFIX = "[RichMovie/CSFD/Browser]"

PAGE_SIZE = 100  # 100 per page = ~8 pages for Richie's 786 ratings


# ─────────────────────────────────────────────────────────────────────────────
#  Logging — 3.4.0 Phase 9: richmovie_logging pipeline
# ─────────────────────────────────────────────────────────────────────────────

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.csfd_browser", "RichMovie/CSFD/Browser")
except Exception:
    def _log(msg: str, level: int = xbmc.LOGINFO, *, context: dict | None = None) -> None:
        try:
            xbmc.log("{} {}".format(_LOG_PREFIX, msg), level)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  Gate transport — GET helper specific to /v1/csfd/my/*
# ─────────────────────────────────────────────────────────────────────────────

def _gate_get(path: str, params: dict[str, Any] | None = None,
               timeout: float = 30.0) -> tuple[int, dict[str, Any]]:
    """Authed GET to /v1/csfd/my/*. Returns (status, body)."""
    try:
        from richmovie_gate_transport import get_identity, GATE_URL
    except ImportError as exc:
        _log("transport import failed: {!r}".format(exc), xbmc.LOGERROR)
        return 503, {"error": "transport_unavailable"}

    username, proof = get_identity()
    if not username or not proof:
        _log("no identity — aborting", xbmc.LOGERROR)
        return 401, {"error": "no_identity"}

    qp = dict(params or {})
    qp["ws_username"] = username
    qp["ws_proof"] = proof
    # 3.5.152: ČSFD per profil (Gate mig 0032) — SSOT profilu pro ČSFD je v klientu
    import richmovie_csfd_client as _cc
    profile_id = _cc._csfd_profile_id()
    if profile_id is _cc._GUEST:
        return 403, {"error": "guest_no_csfd"}
    if profile_id is not None:
        qp["profile_id"] = int(profile_id)
    url = "{}{}?{}".format(GATE_URL, path, urllib.parse.urlencode(qp))
    from richmovie_gate_transport import gate_headers as _gate_headers
    headers = _gate_headers()   # SSOT (User-Agent proti Cloudflare, X-Request-ID)

    # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. Browser čte hodnocení
    # a watchlist — samé GETy, opakování je bezpečné. Kontrakt návratu zůstává
    # `(status, dict)` včetně chybových stavů, na což staví volající.
    try:
        import richmovie_http as _rm_http
    except Exception as exc:  # pragma: no cover
        _log("richmovie_http chybi: {!r}".format(exc), xbmc.LOGERROR)
        return 599, {"error": "transport_fail", "detail": repr(exc)}

    try:
        profile = _rm_http.profile_foreground().replace(timeout_s=float(timeout))
        status, raw, _hdrs = _rm_http.request(
            url, headers=headers, profile=profile, tag="csfd_browser",
        )
        if status >= 400:
            _log("HTTP {}: {}".format(status, path), xbmc.LOGWARNING)
        try:
            text = raw.decode("utf-8") if raw else ""
            return status, (json.loads(text) if text else {})
        except Exception:
            return status, {"error": "http_{}".format(status)}
    except Exception as exc:
        _log("transport fail {}: {!r}".format(path, exc), xbmc.LOGERROR)
        return 599, {"error": "transport_fail", "detail": repr(exc)}


# ─────────────────────────────────────────────────────────────────────────────
#  URL building
# ─────────────────────────────────────────────────────────────────────────────

def _addon_url() -> str:
    """Plugin handle URL prefix (sys.argv[0])."""
    return sys.argv[0] if len(sys.argv) > 0 else "plugin://plugin.video.richmovie/"


def _build_url(**params: Any) -> str:
    return "{}?{}".format(_addon_url(), urllib.parse.urlencode(params))


def _handle() -> int:
    return int(sys.argv[1]) if len(sys.argv) > 1 else -1


# ─────────────────────────────────────────────────────────────────────────────
#  Star rendering helpers
# ─────────────────────────────────────────────────────────────────────────────

def _stars(rating_pct: int) -> tuple[str, int]:
    """Render 0-100% to (graphic stars, integer star count).

    1★ = 1-20%, 2★ = 21-40%, 3★ = 41-60%, 4★ = 61-80%, 5★ = 81-100%.
    """
    n = max(0, min(5, (rating_pct + 19) // 20))
    return "★" * n + "☆" * (5 - n), n


def _format_iso_date(iso_str: str | None, default: str = "?") -> str:
    """ISO timestamp → `21. 4. 2026` v lokálním čase (SSOT `richmovie_helpers.format_local_date`,
    3.5.133 — dřív ořez řetězce = UTC datum, po půlnoci CEST o den vedle)."""
    import richmovie_helpers
    return richmovie_helpers.format_local_date(iso_str, default)


def _aging_label(days_old: int) -> str:
    """Czech relative time for watchlist freshness (used as boost descriptor
    not as a claim about real CSFD addedAt — CSFD's mobile API doesn't expose
    that, so this represents `synced_at` from our DB)."""
    if days_old <= 1:
        return "dnes"
    if days_old < 30:
        return "před {} dny".format(days_old)
    if days_old < 365:
        months = days_old // 30
        return "před {} {}".format(
            months,
            "měsícem" if months == 1 else "měsíci" if months <= 4 else "měsíci",
        )
    years = days_old // 365
    return "před {} {}".format(
        years, "rokem" if years == 1 else "lety",
    )


# ─────────────────────────────────────────────────────────────────────────────
#  ListItem builder — shared between ratings / watchlist / top-rated
# ─────────────────────────────────────────────────────────────────────────────

_TMDB_IMG_W342 = "https://image.tmdb.org/t/p/w342"
_TMDB_IMG_FANART = "https://image.tmdb.org/t/p/w1280"


def _build_list_item(item: dict[str, Any], *, mode: str) -> tuple[str, xbmcgui.ListItem, bool]:
    """Build (url, ListItem, is_folder) for one CSFD entry.

    `mode`: 'rating' / 'watchlist' — controls label prefix.
    """
    csfd_film_id = int(item.get("csfd_film_id") or 0)
    tmdb_id = item.get("tmdb_id")
    kind = item.get("kind") or "movie"
    title = item.get("title") or "?"
    year = item.get("year")
    tmdb = item.get("tmdb") or {}

    poster_path = tmdb.get("poster_path") or ""
    backdrop_path = tmdb.get("backdrop_path") or ""
    overview = (tmdb.get("overview") or "").strip()
    vote_avg = tmdb.get("vote_average")
    runtime = tmdb.get("runtime")
    original_title = tmdb.get("original_title") or ""

    # Label — mode-specific prefix
    if mode == "rating":
        rating_pct = int(item.get("rating_pct") or 0)
        stars_glyph, stars_n = _stars(rating_pct)
        rated_at_short = _format_iso_date(item.get("rated_at"), "?")
        # Visible at-a-glance: stars + numeric (X/5) + date hodnocení
        prefix = (
            "[B][COLOR gold]{glyph}[/COLOR][/B]"
            "[COLOR FFCCCCCC] ({n}/5)[/COLOR]"
            "  [COLOR FF99CCFF]{date}[/COLOR]"
        ).format(glyph=stars_glyph, n=stars_n, date=rated_at_short)
    else:  # watchlist
        # 3.5.131 (Richie: „není to sexy"): ★ hodnocení jako u TV tipů (TMDb) +
        # ČSFD % když je v cache + „přidáno d.m." barevně podle stáří (AI boost).
        days_old = int(item.get("days_old") or 0)
        boost = item.get("boost") or "soft"
        boost_color = {
            "strong": "FFFF8000",   # orange — "zapomenuto, AI BOOST silný"
            "medium": "FFFFCC00",   # gold — středně dlouho čeká
            "soft":   "FFAAAAAA",   # gray — nedávno přidáno
        }.get(boost, "FFAAAAAA")
        added_short = _format_iso_date(item.get("added_at"), "?")
        parts = []
        if vote_avg:
            parts.append("[B][COLOR gold]★ {:.1f}[/COLOR][/B]".format(float(vote_avg)))
        csfd_pct = item.get("csfd_rating_pct")
        if csfd_pct:
            parts.append("[COLOR FFCC4444]ČSFD {} %[/COLOR]".format(int(csfd_pct)))
        parts.append("[COLOR {}]přidáno {}[/COLOR]".format(boost_color, added_short))
        prefix = "  ".join(parts)

    title_disp = "{} ({})".format(title, year) if year else title
    if kind == "tv":
        title_disp += " [I][seriál][/I]"
    label = "{}  {}".format(prefix, title_disp)

    li = xbmcgui.ListItem(label)

    # Artwork — TMDb-resolved or placeholder
    art: dict[str, str] = {}
    if poster_path and poster_path.startswith("/"):
        art["poster"] = _TMDB_IMG_W342 + poster_path
        art["thumb"] = _TMDB_IMG_W342 + poster_path
    else:
        # Items without TMDb mapping get the addon icon as thumb so the row
        # looks consistent in poster/list views (no broken image placeholder).
        art["thumb"] = "DefaultVideo.png"
    if backdrop_path and backdrop_path.startswith("/"):
        art["fanart"] = _TMDB_IMG_FANART + backdrop_path
    li.setArt(art)

    # Info tag — Kodi reads year/rating/plot for views that show them.
    info: dict[str, Any] = {"title": title}
    if year:
        try:
            info["year"] = int(year)
        except (TypeError, ValueError):
            pass
    if mode == "rating":
        # CSFD's 0-100 rating mapped to 0-10 IMDb-style scale (Kodi expects 0-10).
        info["rating"] = round(int(item.get("rating_pct") or 0) / 10.0, 1)
    elif vote_avg:
        info["rating"] = float(vote_avg)
    if runtime:
        try:
            info["duration"] = int(runtime) * 60
        except (TypeError, ValueError):
            pass
    if original_title and original_title != title:
        info["originaltitle"] = original_title
    info["mediatype"] = "tvshow" if kind == "tv" else "movie"

    # Plot — prepend per-mode CSFD context to the TMDb overview.
    plot_lines = []
    if mode == "rating":
        rating_pct = int(item.get("rating_pct") or 0)
        stars_glyph, stars_n = _stars(rating_pct)
        rated_at_long = _format_iso_date(item.get("rated_at"), "neznámé datum")
        plot_lines.append(
            "[B][COLOR gold]Tvé CSFD hodnocení:[/COLOR][/B] "
            "{glyph}  ([B]{n}/5[/B], {pct} %)  "
            "[COLOR FF99CCFF]ze dne {date}[/COLOR]".format(
                glyph=stars_glyph, n=stars_n, pct=rating_pct, date=rated_at_long,
            )
        )
    else:  # watchlist
        added_long = _format_iso_date(item.get("added_at"), "neznámé datum")
        plot_lines.append(
            "[B][COLOR FFFFCC00]Chci vidět[/COLOR][/B] — "
            "[COLOR FF99CCFF]přidáno {} (čeká {} dní)[/COLOR]".format(added_long, days_old)
        )
        csfd_pct = item.get("csfd_rating_pct")
        if csfd_pct:
            plot_lines.append("[COLOR FFCC4444]ČSFD hodnocení: {} % ({} hlasů)[/COLOR]".format(
                int(csfd_pct), item.get("csfd_rating_count") or "?"))
        plot_lines.append(
            "[COLOR FFAAAAAA][I]Datum = kdy položku poprvé viděla naše synchronizace "
            "(ČSFD API skutečný čas přidání neposkytuje); stárnutí zvyšuje váhu v AI doporučení.[/I][/COLOR]"
        )
    if vote_avg:
        plot_lines.append(
            "[COLOR FFAAAAAA]TMDb rating: {} ({} hlasů)[/COLOR]".format(
                vote_avg, tmdb.get("vote_count") or "?",
            )
        )
    if overview:
        plot_lines.append("")  # blank line separator before the body text
        plot_lines.append(overview)
    if plot_lines:
        info["plot"] = "\n".join(plot_lines)

    li.setInfo("video", info)

    # Click target — TMDb-id-based jump if known, else title search fallback
    # `click_action` se drží zvlášť, aby `isFolder` šel z registru rout pro TUTÉŽ akci,
    # na kterou URL míří (dřív `is_folder = kind == "tv"` označil film za nesložku).
    if tmdb_id and kind == "movie":
        click_action = "auto"
        click_url = _build_url(action=click_action, tmdb=str(tmdb_id))
    elif tmdb_id and kind == "tv":
        click_action = "tv_seasons"
        click_url = _build_url(action=click_action, tv_id=str(tmdb_id), tv_name=title)
    elif kind == "tv":
        click_action = "tv_search"
        click_url = _build_url(action=click_action, q=title)
    else:
        click_action = "movie_search"
        click_url = _build_url(action=click_action, q=title)

    # Context menu — always offers title-search fallback (release pool may
    # differ from TMDb-id-only path), plus similarity if TMDb id known.
    ctx = []
    if kind == "movie":
        ctx.append((
            "Hledat releases (vyhledat podle názvu)",
            "Container.Update({})".format(_build_url(action="movie_search", q=title)),
        ))
        if tmdb_id:
            ctx.append((
                "Podobné filmy",
                "Container.Update({})".format(_build_url(
                    action="similar_movies", tmdb_id=str(tmdb_id),
                )),
            ))
    else:
        ctx.append((
            "Hledat releases (seriál podle názvu)",
            "Container.Update({})".format(_build_url(action="tv_search", q=title)),
        ))
        if tmdb_id:
            ctx.append((
                "Sezóny seriálu",
                "Container.Update({})".format(_build_url(
                    action="tv_seasons", tv_id=str(tmdb_id), tv_name=title,
                )),
            ))
            ctx.append((
                "Podobné seriály",
                "Container.Update({})".format(_build_url(
                    action="similar_tv", tmdb_id=str(tmdb_id),
                )),
            ))
    li.addContextMenuItems(ctx)

    # Oba cíle staví ADRESÁŘ: `tv_seasons` výpis řad, `auto`/`movie_search` výpis
    # streamů. Dřívější `kind == "tv"` označilo film za nesložku — tatáž vada,
    # kvůli které se v Doporučeních nikdy nezobrazil seznam streamů
    # (root cause 19.09.2026; tohle místo našel až finální audit Fable).
    return click_url, li, _routes.is_folder(click_action)


def _action_of(url: str) -> str:
    """`action` z plugin URL (pro dotaz do registru rout u datově řízených menu)."""
    try:
        return (urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get("action") or [""])[0]
    except Exception:
        return ""


def _add_pagination_item(handle: int, action: str, total: int, page: int,
                          extra_params: dict[str, Any] | None = None) -> None:
    """Append a "Next page" entry if there are more rows."""
    next_offset = (page + 1) * PAGE_SIZE
    if next_offset >= total:
        return
    next_label = "[B]→ Další stránka[/B]  ({}/{})".format(
        min(next_offset, total), total,
    )
    li = xbmcgui.ListItem(next_label)
    li.setArt({"icon": "DefaultFolderBack.png"})
    params = dict(extra_params or {})
    params["action"] = action
    params["page"] = str(page + 1)
    xbmcplugin.addDirectoryItem(
        handle, _build_url(**params), li, isFolder=True,
    )


# ─────────────────────────────────────────────────────────────────────────────
#  Public listing handlers (called from plugin.py router)
# ─────────────────────────────────────────────────────────────────────────────

def show_my_csfd_root() -> None:
    """Submenu listing: ratings / watchlist / top-rated."""
    _log("show_my_csfd_root")
    handle = _handle()
    xbmcplugin.setContent(handle, "files")

    # 3.5.131 (M1): stav synchronizace je vidět, ne skrytý — od 26.4.2026 sync
    # tiše selhával (ČSFD zrušilo staré API) a nikdo to neviděl.
    status_label, status_plot = _sync_status_line()
    if status_label:
        st = xbmcgui.ListItem(status_label)
        st.setArt({"icon": "DefaultAddonService.png", "thumb": "DefaultAddonService.png"})
        st.setInfo("video", {"title": status_label, "plot": status_plot})
        xbmcplugin.addDirectoryItem(handle, _build_url(action="csfd_settings"), st, isFolder=False)

    items = [
        ("★ Moje hodnocení v RichMovie",
         "Filmy a seriály, které jsi ohodnotil přímo v RichMovie (po dokoukání nebo z menu). "
         "Funguje i bez ČSFD a počítá se do doporučení stejně jako ČSFD hodnocení.",
         _build_url(action="my_ratings_local"),
         "DefaultFavourites.png"),
        ("⭐ Moje hodnocení na ČSFD",
         "Všechna tvá CSFD hodnocení, řazená od nejnovějších.",
         _build_url(action="csfd_my_ratings", page="0"),
         "DefaultMusicAlbums.png"),
        ("👁 Chci vidět",
         "Tvá CSFD watchlist. Starší položky mají v AI doporučení silnější váhu.",
         _build_url(action="csfd_my_watchlist", page="0"),
         "DefaultPlaylist.png"),
        ("🏆 Top hodnocené (4-5★)",
         "Jen filmy/seriály, kterým jsi dal 4 nebo 5 hvězd.",
         _build_url(action="csfd_my_top_rated", page="0"),
         "DefaultFavourites.png"),
        ("↻ Spustit TMDb resolution",
         "Doplnění posterů a popisů u položek bez TMDb mappingu (background task).",
         _build_url(action="csfd_my_resolve"),
         "DefaultAddonService.png"),
    ]

    for label, plot, url, icon in items:
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon, "thumb": icon})
        li.setInfo("video", {"title": label, "plot": plot})
        # isFolder podle AKCE v URL, ne paušálně True: `csfd_my_resolve` je ACTION
        # (spustí úlohu na pozadí) a jako složka otevírala prázdný adresář
        # (cross-check Flash G3, noc 19.→20.09.2026).
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=_routes.is_folder(_action_of(url)))

    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def show_my_richmovie_ratings() -> None:
    """Výpis hodnocení zadaných v RichMovie (3.5.152, SSOT `richmovie_ratings`): „★★★★☆ Titul (2019)",
    klik = hledání (film) / sezóny (seriál), kontextové menu Změnit / Smazat hodnocení."""
    import richmovie_ratings as _rt
    handle = _handle()
    xbmcplugin.setContent(handle, "movies")
    ratings = _rt.all_ratings()
    if not ratings:
        li = xbmcgui.ListItem("[COLOR FFAAAAAA]Zatím žádné hodnocení — po dokoukání filmu se RichMovie zeptá, "
                              "nebo použij „Ohodnotit ★“ v menu titulu.[/COLOR]")
        # Placeholder míří na ADRESÁŘ → musí být složka (dřív nesložka = klik bez efektu).
        xbmcplugin.addDirectoryItem(handle, _build_url(action="csfd_my_root"), li,
                                    isFolder=_routes.is_folder("csfd_my_root"))
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return
    for rec in ratings:
        label = "[COLOR gold]{}[/COLOR]  {}".format(_rt.stars(rec["rating"]), rec["title"] or "(bez názvu)")
        if rec["kind"] == "tv":
            label += " [I][seriál][/I]"
        li = xbmcgui.ListItem(label)
        li.setInfo("video", {"title": rec["title"], "plot": "Tvoje hodnocení: {} ({})\nUloženo: {}".format(
            _rt.stars(rec["rating"]), _rt.LABELS.get(rec["rating"], ""),
            _format_iso_date(__import__("datetime").datetime.fromtimestamp(rec["ts"]).isoformat()))})
        li.addContextMenuItems([
            ("Změnit hodnocení ★", "RunPlugin({})".format(_build_url(
                action="rate_title", kind=rec["kind"], tmdb_id=str(rec["tmdb_id"]), title=rec["title"]))),
            ("Smazat hodnocení", "RunPlugin({})".format(_build_url(
                action="clear_rating", kind=rec["kind"], tmdb_id=str(rec["tmdb_id"]), title=rec["title"]))),
        ])
        if rec["kind"] == "tv":
            url = _build_url(action="tv_seasons", tv_id=str(rec["tmdb_id"]), tv_name=rec["title"])
        else:
            url = _build_url(action="auto", tmdb=str(rec["tmdb_id"]))
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def _sync_status_line() -> tuple[str, str]:
    """(label, plot) pro stavový řádek Moje ČSFD z Gate `/v1/csfd/status`
    (`sync_health` od 3.5.131). Prázdný label = stav nelze zjistit (offline)."""
    try:
        import richmovie_csfd_client
        st = richmovie_csfd_client.csfd_status()
    except Exception as exc:
        _log("status fetch failed: {!r}".format(exc), xbmc.LOGWARNING)
        return "", ""
    if not isinstance(st, dict) or not st.get("connected"):
        if isinstance(st, dict) and st.get("error"):
            # Diagnostický kanál nesmí mlčet, ale nesmí ani lhát (Fable P1-1):
            # 401/403/404 = Gate autoritativně říká „ČSFD není pro účet aktivní",
            # cokoli jiného = Gate/transport.
            http = int(st.get("status") or 0)
            if http in (401, 403, 404):
                return ("[COLOR FFAAAAAA]ČSFD profil není pro tvůj účet aktivní[/COLOR]",
                        "Gate: {}. Aktivaci ČSFD integrace pro účet dělá správce.".format(st.get("error")))
            return ("[COLOR FFAAAAAA]Stav synchronizace ČSFD nelze zjistit (Gate nedostupný)[/COLOR]",
                    "Chyba: {}".format(st.get("error")))
        return ("[COLOR FFAAAAAA]ČSFD profil není propojen[/COLOR]",
                "Propoj ČSFD účet v nastavení RichMovie (Moje ČSFD).")
    health = st.get("sync_health") or {}
    state = str(health.get("state") or "")
    import richmovie_helpers
    last_ok = richmovie_helpers.format_local_datetime(
        health.get("last_success_at") or st.get("last_sync_finished_at"), default="nikdy")
    if state == "failing":
        code = str(health.get("last_error_code") or st.get("last_sync_error") or "chyba")
        if code.startswith("csfd_transport"):
            # Přechodná chyba sítě ≠ rozbitá integrace (Fable P2-3): žlutě, s datem dat.
            return (
                "[COLOR FFFFCC00]Poslední synchronizace ČSFD neproběhla (síť), data z {}[/COLOR]".format(last_ok),
                "Poslední pokus skončil chybou sítě ({}). Další pokus proběhne v noci; "
                "klikni pro ruční synchronizaci.".format(code),
            )
        return (
            "[COLOR FFFF5555]⚠ Synchronizace ČSFD selhává (poslední úspěch {})[/COLOR]".format(last_ok),
            "Poslední chyba: {}\nData níže jsou ze synchronizace {}. Klikni pro nastavení / "
            "ruční synchronizaci.".format(code, last_ok),
        )
    if state == "never":
        return ("[COLOR FFFFCC00]Synchronizace ČSFD ještě neproběhla[/COLOR]",
                "Klikni pro ruční synchronizaci.")
    return ("[COLOR FF66BB66]✓ Synchronizováno {}[/COLOR]".format(last_ok),
            "Hodnocení: {} · Chci vidět: {}".format(st.get("total_ratings") or 0, st.get("total_watchlist") or 0))


def _render_listing(handle: int, body: dict[str, Any], *,
                     action: str, mode: str, page: int,
                     content_type: str = "movies") -> None:
    """Common rendering for ratings / watchlist / top-rated."""
    items = body.get("items") or []
    total = int(body.get("total") or len(items))
    _log("rendering {} items (total {}, page {})".format(len(items), total, page))

    xbmcplugin.setContent(handle, content_type)

    for it in items:
        url, li, is_folder = _build_list_item(it, mode=mode)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=is_folder)

    _add_pagination_item(handle, action=action, total=total, page=page)

    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_VIDEO_TITLE)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def get_my_feed(which: str, page: int = 0) -> list:
    """Public data accessor pro RM 4.0 custom UI (rm_grid feedy) — Φ-P 2026-06-12.

    which: 'ratings' | 'watchlist' | 'top'. Vrací syrové Gate items
    (tmdb_id, kind, title, year, rating_pct, tmdb.poster_path, …).
    Chyba → RuntimeError (volající fetch_async ji zobrazí jako error stav).
    """
    params: dict[str, Any] = {"limit": PAGE_SIZE, "offset": page * PAGE_SIZE}
    path = "/v1/csfd/my/watchlist" if which == "watchlist" else "/v1/csfd/my/ratings"
    if which == "top":
        params["min_rating_pct"] = 80
    status, body = _gate_get(path, params=params)
    if status != 200:
        raise RuntimeError("CSFD Gate HTTP {} ({})".format(status, which))
    return body.get("items") or []


def show_my_ratings(page: int = 0) -> None:
    _log("show_my_ratings page={}".format(page))
    handle = _handle()
    status, body = _gate_get(
        "/v1/csfd/my/ratings",
        params={"limit": PAGE_SIZE, "offset": page * PAGE_SIZE},
    )
    if status != 200:
        _show_error("Hodnocení z ČSFD teď nejdou načíst", body, handle)
        return
    _render_listing(handle, body,
                     action="csfd_my_ratings", mode="rating", page=page)


def show_my_watchlist(page: int = 0) -> None:
    _log("show_my_watchlist page={}".format(page))
    handle = _handle()
    status, body = _gate_get(
        "/v1/csfd/my/watchlist",
        params={"limit": PAGE_SIZE, "offset": page * PAGE_SIZE},
    )
    if status != 200:
        _show_error("„Chci vidět“ z ČSFD teď nejde načíst", body, handle)
        return
    _render_listing(handle, body,
                     action="csfd_my_watchlist", mode="watchlist", page=page)


def show_my_top_rated(page: int = 0) -> None:
    _log("show_my_top_rated page={}".format(page))
    handle = _handle()
    status, body = _gate_get(
        "/v1/csfd/my/ratings",
        params={"limit": PAGE_SIZE, "offset": page * PAGE_SIZE,
                "min_rating_pct": 80},
    )
    if status != 200:
        _show_error("Nejlépe hodnocené teď nejdou načíst", body, handle)
        return
    _render_listing(handle, body,
                     action="csfd_my_top_rated", mode="rating", page=page)


def trigger_resolve_now() -> None:
    """User-triggered TMDb resolution. Runs in foreground with a busy
    dialog — typically takes 1-2 seconds per unmapped row, so for a fresh
    user (~880 unmapped) this is several minutes. We surface progress via
    a Kodi notification at the end."""
    _log("trigger_resolve_now")
    import richmovie_feedback as _fb  # Φ2 (29.09.2026): SSOT odezvy, žádný technický text do UI
    from richmovie_gate_transport import post_json, get_identity, build_common_fields

    username, _ = get_identity()
    if not username:
        _fb.warn("Nejdřív se přihlas k Webshare (Nastavení).", heading="Moje ČSFD")
        return
    try:
        with _fb.working("Páruji filmy z ČSFD s katalogem… (může to trvat pár minut)"):
            status, resp = post_json("/v1/csfd/my/resolve", build_common_fields(), timeout=600)
    except Exception as exc:
        _log("resolve transport fail: {!r}".format(exc), xbmc.LOGERROR)
        _fb.error(exc, heading="Moje ČSFD")
        return

    if status == 200 and isinstance(resp, dict) and resp.get("ok"):
        _fb.info("Spárováno {} z {} filmů · {} bez shody".format(
            resp.get("resolved", 0), resp.get("considered", 0), resp.get("unresolved", 0)),
            heading="Moje ČSFD")
    else:
        _log("resolve failed: HTTP {} {}".format(status, str(resp)[:200]), xbmc.LOGWARNING)
        _fb.warn("Párování se teď nepovedlo — zkus to prosím později.", heading="Moje ČSFD")


# ─────────────────────────────────────────────────────────────────────────────
#  Error rendering
# ─────────────────────────────────────────────────────────────────────────────

def _show_error(headline: str, body: dict[str, Any], handle: int) -> None:
    detail = body.get("detail") if isinstance(body, dict) else None
    if isinstance(detail, dict):
        detail_str = detail.get("detail") or detail.get("error") or str(detail)
    elif isinstance(detail, str):
        detail_str = detail
    else:
        detail_str = body.get("error") or "neznámá chyba"
    _log("error rendering: {}: {}".format(headline, detail_str), xbmc.LOGERROR)

    # Φ2 (29.09.2026): kód Gate jen do logu, na obrazovku věta (SSOT textů ČSFD = `friendly_error`)
    import richmovie_csfd_client as _cc
    import richmovie_feedback as _fb
    _fb.warn(_cc.friendly_error(detail_str), heading=headline)
    xbmcplugin.endOfDirectory(handle, succeeded=False)
