# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_profile_items — osobní kolekce profilu napříč zařízeními
 (plán PLAN_profile_data_sync_20260905, DP2/DP5/DP7; Gate mig 0027 `profile_items`)
═══════════════════════════════════════════════════════════════════════════════

„Profil = člověk, všechno jeho jde s ním": historie hledání, historie sledování,
Moje listy, preference audia/titulků a „nezajímá mě" jsou od 3.5.144 uložené na
Gate per profil; lokální JSON soubory profilu (formát beze změny, UI je čte dál)
jsou jen cache + zdroj lokálních změn.

SSOT mapování kolekce ↔ lokální soubor je TADY:
  kolekce        soubor                 klíč položky                         payload
  search         history.json           <kategorie>|<dotaz lower>            {category, record, ts}
  watch_history  watch_history.json     movie:<tmdb> | movie:t:<název>|<rok> {branch, record}
                                        tv:<tv_id>:<s>:<e>
  my_list        my_list.json           <kind>:<tmdb_id>                     {record}
  title_prefs    title_prefs.json       <make_title_key>                     {pref}
  ai_dismissed   ai_dismissed.json      <kind>:<tmdb_id>                     {ts}

Tok:
  zapisovače (`richmovie_history`, `richmovie_title_prefs`) → `note_*` → fronta
  (`richmovie_sync_queue.SyncQueue`, soubor `pending_items.json` v adresáři profilu)
  → služba (`ServiceTicker`) `flush()` → Gate LWW → `newer` / pull → `apply_remote()`
  pod `applying_remote` guardem (echo se nezařadí) → lokální soubory přes existující
  SSOT save funkce (rails/UI se invalidují jako při lokální změně).

První sync profilu na zařízení (`seed_from_local`): lokální položky → fronta s časem
položky (`ts`), bez času = mtime souboru → Gate je sloučí LWW (DP3: data z doby před
profily jsou majitelova a na PC/TV se sejdou).

Pravidla: R2 (transport/5xx/429 = fronta zůstává), karanténa jen na autoritativní
per-položkové 422, tombstone = smazání se šíří LWW, manuální preference titulu má
přednost před pozorovanou i přes LWW (deterministicky na všech zařízeních).
"""
from __future__ import annotations

import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import richmovie_sync_queue as _sq

# `ratings` (3.5.152, Gate mig 0032): hodnocení 1–5★ v RichMovie (`richmovie_ratings`), klíč `movie:<tmdb>` /
# `tv:<tmdb>`, payload `{"record": {...}}`; AI ho bere jako ČSFD hodnocení.
COLLECTIONS = ("search", "watch_history", "my_list", "title_prefs", "ai_dismissed", "ratings")
QUEUE_FILE = "pending_items.json"
CURSOR_FILE = "items_sync.json"
ITEMS_PATH = "/v1/profiles/items"
PUSH_BATCH_MAX = 200            # = Gate PUSH_MAX_ITEMS
QUEUE_MAX_ITEMS = 2000          # seed profilu = stovky položek; strop nad tím = nejstarší pryč
QUARANTINE_MAX_ITEMS = 200
SEARCH_MAX_PER_CATEGORY = 50    # = richmovie_history (kategorie drží 50)
SEED_MARK = "seeded"
SEED_MAX_AGE_S = 7 * 86400      # položky bez `ts` (staré řetězce v history.json) = nejvýš 7 dní zpět

OUTCOME_SENT = _sq.OUTCOME_SENT
OUTCOME_EMPTY = _sq.OUTCOME_EMPTY
OUTCOME_SKIPPED = _sq.OUTCOME_SKIPPED
OUTCOME_FAILED = _sq.OUTCOME_FAILED
OUTCOME_CONTRACT = _sq.OUTCOME_CONTRACT
OUTCOME_DROPPED = _sq.OUTCOME_DROPPED
OUTCOME_APPLIED = _sq.OUTCOME_APPLIED
OUTCOME_UNCHANGED = _sq.OUTCOME_UNCHANGED

try:
    import xbmc
    _HAVE_KODI = True
except ImportError:  # harness
    _HAVE_KODI = False

try:
    from richmovie_logging import make_legacy_logger as _mk_logger
    _log = _mk_logger("richmovie.profile_items", "[RichMovie/ProfileItems]")
except Exception:  # harness / nástroje mimo Kodi
    def _log(msg: str, level: int = 1) -> None:
        if _HAVE_KODI:
            xbmc.log("[RichMovie/ProfileItems] %s" % msg, level)

_flush_lock = threading.Lock()
_pull_lock = threading.Lock()
PULL_CLAIM = "items_pull"   # 3.5.151 (Φ3): meziprocesový claim pullu — parita s `richmovie_state_sync.PULL_CLAIM`


def _state():
    """Sdílené primitivy kanálu stavu: scope (D7), preconditions (identita/síť), echo guard."""
    import richmovie_state_sync as _ss
    return _ss


def _item_key(it: Dict[str, Any]) -> str:
    return "%s|%s" % (it.get("collection"), it.get("item_key"))


def _item_ts(it: Dict[str, Any]) -> float:
    return _sq.to_epoch(it.get("client_updated_at"))


_QUEUE = _sq.SyncQueue(QUEUE_FILE, _item_key, _item_ts, max_items=QUEUE_MAX_ITEMS,
                       quarantine_max=QUARANTINE_MAX_ITEMS, name="pending_items",
                       log=lambda m, l=1: _log(m, l))
_CURSOR = _sq.SyncCursor(CURSOR_FILE, name="items_sync")


# ── klíče (SSOT tvaru; Gate je jen ukládá) ───────────────────────────────────

def _int(v: Any) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def search_key(category: str, query: str) -> str:
    return "%s|%s" % ((category or "other").lower(), " ".join(str(query or "").split()).lower())


def _record_query(entry: Any) -> str:
    if isinstance(entry, dict):
        return str(entry.get("query") or "").strip()
    return str(entry or "").strip()


def watch_movie_key(rec: Dict[str, Any]) -> Optional[str]:
    tmdb = _int(rec.get("tmdb"))
    if tmdb > 0:
        return "movie:%d" % tmdb
    title = str(rec.get("title") or "").strip().lower()
    if not title:
        return None
    return "movie:t:%s|%s" % (title, rec.get("year") or "")


def watch_episode_key(rec: Dict[str, Any]) -> Optional[str]:
    tv = str(rec.get("tv_id") or "").strip()
    if not tv:
        return None
    return "tv:%s:%d:%d" % (tv, _int(rec.get("season")), _int(rec.get("episode")))


def list_key(tmdb_id: Any, kind: Any) -> Optional[str]:
    tmdb = str(tmdb_id or "").strip()
    if not tmdb:
        return None
    return "%s:%s" % ((kind or "movie").lower(), tmdb)


PAYLOAD_SOFT_MAX = 3600         # < Gate PAYLOAD_MAX_BYTES 4096 — ořez TADY, ne 422 → karanténa (Pro A P6/C P6)
TEXT_MAX = 300                  # dlouhá textová pole (TMDb overview) se ořežou; UI je zobrazí zkrácená
DROPPABLE = ("overview", "backdrop_path")   # když ani ořez nestačí, tahle pole položce nechybí


def shrink_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Deterministický ořez payloadu pod strop Gate: 1) řetězce > TEXT_MAX zkrátit,
    2) pak vyhodit DROPPABLE pole. Autoritativní 422 by položku poslalo do karantény
    NAVŽDY, i kdyby se text později zkrátil — proto se rozhoduje u zdroje (SSOT)."""
    import json as _json

    def _size(p: Any) -> int:
        return len(_json.dumps(p, ensure_ascii=False).encode("utf-8"))

    def _cut(node: Any) -> Any:
        if isinstance(node, str):
            return node[:TEXT_MAX] if len(node) > TEXT_MAX else node
        if isinstance(node, dict):
            return {k: _cut(v) for k, v in node.items()}
        if isinstance(node, list):
            return [_cut(v) for v in node]
        return node

    def _drop(node: Any) -> Any:
        if isinstance(node, dict):
            return {k: _drop(v) for k, v in node.items() if k not in DROPPABLE}
        if isinstance(node, list):
            return [_drop(v) for v in node]
        return node

    out = dict(payload or {})
    if _size(out) <= PAYLOAD_SOFT_MAX:
        return out
    out = _cut(out)
    if _size(out) <= PAYLOAD_SOFT_MAX:
        return out
    return _drop(out)


def make_item(collection: str, key: str, payload: Optional[Dict[str, Any]], *, deleted: bool = False,
              ts: Optional[float] = None) -> Dict[str, Any]:
    return {"collection": collection, "item_key": str(key)[:256], "payload": shrink_payload(payload or {}),
            "deleted": bool(deleted), "client_updated_at": _sq.to_iso(time.time() if ts is None else ts)}


# ── zápis lokální změny do fronty ────────────────────────────────────────────

def note_change(collection: str, key: Optional[str], payload: Optional[Dict[str, Any]], *,
                deleted: bool = False, ts: Optional[float] = None) -> bool:
    """Jediný vstup pro zapisovače. False = nic (Host / bez profilu / echo z pullu / bez klíče)."""
    if collection not in COLLECTIONS or not key:
        return False
    ss = _state()
    if ss.is_applying_remote() or ss.sync_scope() is None:
        return False
    ok = _QUEUE.enqueue(make_item(collection, key, payload, deleted=deleted, ts=ts))
    if ok:
        ss.request_push("items")
    return ok


def note_many(items: List[Dict[str, Any]]) -> int:
    ss = _state()
    if not items or ss.is_applying_remote() or ss.sync_scope() is None:
        return 0
    n = _QUEUE.enqueue_many(items)
    if n > 0:
        ss.request_push("items")
    return max(0, n)


def note_search(category: str, record: Any) -> bool:
    q = _record_query(record)
    if not q:
        return False
    ts = float(record.get("ts") or time.time()) if isinstance(record, dict) else None
    return note_change("search", search_key(category, q), {"category": (category or "other").lower(),
                                                            "record": record, "ts": int(ts or time.time())}, ts=ts)


def note_search_clear(hist_before: Dict[str, List[Any]]) -> int:
    now = time.time()
    items = [make_item("search", search_key(cat, _record_query(e)), None, deleted=True, ts=now)
             for cat, entries in (hist_before or {}).items() for e in (entries or []) if _record_query(e)]
    return note_many(items)


def note_watch(branch: str, rec: Dict[str, Any]) -> bool:
    key = watch_movie_key(rec) if branch == "movies" else watch_episode_key(rec)
    if not key:
        return False
    ts = float(rec.get("ts") or time.time())
    return note_change("watch_history", key, {"branch": branch, "record": rec}, ts=ts)


def note_watch_clear(data_before: Dict[str, List[Dict[str, Any]]]) -> int:
    now = time.time()
    items = []
    for branch, keyfn in (("movies", watch_movie_key), ("episodes", watch_episode_key)):
        for rec in (data_before or {}).get(branch) or []:
            key = keyfn(rec) if isinstance(rec, dict) else None
            if key:
                items.append(make_item("watch_history", key, None, deleted=True, ts=now))
    return note_many(items)


def note_my_list(rec: Dict[str, Any]) -> bool:
    key = list_key(rec.get("tmdb_id"), rec.get("kind"))
    return note_change("my_list", key, {"record": rec}, ts=float(rec.get("ts") or time.time())) if key else False


def note_my_list_remove(tmdb_id: Any, kind: Any) -> bool:
    key = list_key(tmdb_id, kind)
    return note_change("my_list", key, None, deleted=True) if key else False


def note_title_pref(key: str, pref: Dict[str, Any]) -> bool:
    return note_change("title_prefs", key, {"pref": pref}, ts=float(pref.get("ts") or time.time())) if key else False


def note_title_prefs_clear(titles_before: Dict[str, Any]) -> int:
    now = time.time()
    return note_many([make_item("title_prefs", k, None, deleted=True, ts=now) for k in (titles_before or {}) if k])


def note_ai_dismiss(key: str, ts: Optional[float] = None) -> bool:
    return note_change("ai_dismissed", key, {"ts": int(ts or time.time())}, ts=ts) if key else False


# ── seed: první sync profilu na tomto zařízení ───────────────────────────────

def _read_json(path: Any) -> Any:
    """Čtení lokálního JSON souboru bez výjimek (poškozený/chybějící = None)."""
    try:
        import richmovie_atomic as _atomic
        data, _state = _atomic.read_json(str(path), None, name="profile_items", quarantine_on_corrupt=False)
        return data
    except Exception:
        return None


def _capped_mtime(base: Any, name: str, now: float) -> float:
    """Čas pro položky BEZ vlastního času: mtime souboru, ale nejvýš SEED_MAX_AGE_S zpět — soubor
    obnovený ze zálohy / archivovaný dnes nesmí v LWW přepsat skutečnou aktivitu profilu z jiných
    zařízení (Pro B P12, Fable P2-4). Jedna funkce pro kolekce i stav (DRY)."""
    from pathlib import Path
    try:
        return min(float((Path(str(base)) / name).stat().st_mtime), now - SEED_MAX_AGE_S)
    except Exception:
        return now - SEED_MAX_AGE_S


def file_variants(base: Any, name: str) -> List[Any]:
    """`název` + `název.<epoch>` (kolize v `archive_legacy_files` = druhá archivace téhož souboru).
    Bez toho by se druhá várka archivu nikdy neimportovala (Fable P3)."""
    from pathlib import Path
    b = Path(str(base))
    out = [b / name] if (b / name).is_file() else []
    try:
        out += sorted(p for p in b.glob(name + ".*") if p.is_file() and p.name[len(name) + 1:].isdigit())
    except Exception:
        pass
    return out


def items_from_dir(dir_path: Any, now: Optional[float] = None) -> List[Dict[str, Any]]:
    """Položky kolekcí z osobních souborů v adresáři `dir_path` (aktuální profil = seed;
    `profiles/_legacy` = import dat z doby před profily). Čas položky = `ts` záznamu,
    bez něj mtime souboru minus pořadí (soubory drží nejnovější první) — starší než
    cokoli čerstvého, ale nikdy nula (nula by v LWW prohrála i s tombstonem)."""
    from pathlib import Path
    base = Path(str(dir_path))
    now = time.time() if now is None else now

    out: List[Dict[str, Any]] = []
    for f in file_variants(base, "history.json"):
        m = _capped_mtime(base, f.name, now)
        hist = _read_json(f)
        if isinstance(hist, list):              # starý formát = filmové dotazy
            hist = {"movie": hist}
        for cat, entries in (hist or {}).items() if isinstance(hist, dict) else []:
            if not isinstance(entries, list):
                continue
            for i, e in enumerate(entries):
                q = _record_query(e)
                if not q:
                    continue
                ts = float(e.get("ts") or 0) if isinstance(e, dict) else 0.0
                ts = ts or (m - i)
                out.append(make_item("search", search_key(cat, q), {"category": str(cat).lower(), "record": e, "ts": int(ts)}, ts=ts))
    for f in file_variants(base, "watch_history.json"):
        m = _capped_mtime(base, f.name, now)
        data = _read_json(f)
        data = data if isinstance(data, dict) else {}
        for branch, keyfn in (("movies", watch_movie_key), ("episodes", watch_episode_key)):
            for i, rec in enumerate(data.get(branch) or []):
                key = keyfn(rec) if isinstance(rec, dict) else None
                if key:
                    out.append(make_item("watch_history", key, {"branch": branch, "record": rec},
                                         ts=float(rec.get("ts") or 0) or (m - i)))
    for f in file_variants(base, "my_list.json"):
        m = _capped_mtime(base, f.name, now)
        ml = _read_json(f)
        for i, rec in enumerate((ml.get("items") if isinstance(ml, dict) else None) or []):
            key = list_key(rec.get("tmdb_id"), rec.get("kind")) if isinstance(rec, dict) else None
            if key:
                out.append(make_item("my_list", key, {"record": rec}, ts=float(rec.get("ts") or 0) or (m - i)))
    for f in file_variants(base, "title_prefs.json"):
        m = _capped_mtime(base, f.name, now)
        tp = _read_json(f)
        for key, pref in ((tp.get("titles") if isinstance(tp, dict) else None) or {}).items():
            if key and isinstance(pref, dict):
                out.append(make_item("title_prefs", key, {"pref": pref}, ts=float(pref.get("ts") or 0) or m))
    for f in file_variants(base, "ai_dismissed.json"):
        m = _capped_mtime(base, f.name, now)
        ad = _read_json(f)
        for i, key in enumerate(sorted(str(k) for k in ((ad.get("ids") if isinstance(ad, dict) else None) or []) if k)):
            out.append(make_item("ai_dismissed", key, {"ts": int(m)}, ts=m - i))
    return out


def local_items(now: Optional[float] = None) -> List[Dict[str, Any]]:
    """Všechny lokální položky kolekcí aktuálního profilu jako položky fronty."""
    import richmovie_paths as RP
    return items_from_dir(RP.personal_dir(), now)


def legacy_state_items(dir_path: Any, now: Optional[float] = None) -> List[Dict[str, Any]]:
    """Položky KANÁLU STAVU (Pokračovat/✔) z archivu `_legacy` — mapování přes SSOT
    `richmovie_state_sync.item_*` (žádný druhý tvar položky stavu)."""
    from pathlib import Path
    ss = _state()
    base = Path(str(dir_path))
    now = time.time() if now is None else now
    out: List[Dict[str, Any]] = []

    for f in file_variants(base, "continue_watching.json"):
        m = _capped_mtime(base, f.name, now)
        cw = _read_json(f)
        for rec in ((cw.get("items") if isinstance(cw, dict) else None) or []):
            if isinstance(rec, dict):
                it = ss.item_from_cw(rec, client_time=float(rec.get("ts") or 0) or m)
                if it:
                    out.append(it)
    for f in file_variants(base, "watched_episodes.json"):
        m = _capped_mtime(base, f.name, now)
        we = _read_json(f)
        for rec in ((we.get("episodes") if isinstance(we, dict) else None) or []):
            if isinstance(rec, dict):
                # záznam ✔ nese `watched_at` (richmovie_history.watched_mark_episode), ne `ts` (Fable P2-4)
                when = float(rec.get("watched_at") or rec.get("ts") or 0) or m
                it = ss.item_watched_episode(rec.get("tv_id"), rec.get("season", 0), rec.get("episode", 0),
                                             rec.get("completion"), now=when)
                if it:
                    out.append(it)
    for f in file_variants(base, "watched_movies.json"):
        m = _capped_mtime(base, f.name, now)
        wm = _read_json(f)
        for tmdb in ((wm.get("ids") if isinstance(wm, dict) else None) or []):
            it = ss.item_watched_movie(tmdb, now=m)
            if it:
                out.append(it)
    return out


def legacy_queue_items(dir_path: Any, queue: Any, file_name: str) -> List[Dict[str, Any]]:
    """S24 R8 (audit Fable N6, 15.10.2026): NEODESLANÉ položky fronty z archivu `_legacy` (všechny varianty souboru).
    Nejde je odvodit ze souborů stavu/kolekcí — tombstone „odebrat z Pokračovat“ nebo „smazat ze seznamu“ existuje
    JEN ve frontě (soubor položku už nemá); bez převzetí by ho Gate nikdy nedostal a pull by smazanou věc vrátil.
    Karanténa se nepřebírá (položku Gate autoritativně odmítl — zůstává v archivu k dohledání)."""
    from pathlib import Path
    base = Path(str(dir_path))
    out: List[Dict[str, Any]] = []
    for f in file_variants(base, file_name):
        try:
            items = (queue.load(str(f)).get("items") or {})
        except Exception as exc:
            _log("legacy queue %s nečitelná: %r — přeskočeno" % (f.name, exc), 2)
            continue
        out.extend(it for it in items.values() if isinstance(it, dict))
    return out


def import_legacy_dir(owner_id: Optional[int]) -> int:
    """DP3: archiv `profiles/_legacy` (osobní data z doby před profily na tomto zařízení)
    → fronty obou kanálů MAJITELE (v JEHO adresáři profilu, i když je zrovna aktivní jiný
    profil — Pro B P13: na sdílené TV si první vybere dítě a archiv by čekal na majitele)
    → Gate je sloučí LWW → pull je vrátí do profilu na každém zařízení. Push proběhne, až
    bude majitel na tomto zařízení aktivní (fronta je trvanlivá). Soubory se po zařazení
    přejmenují na `<název>.imported-<ts>` (nic se nemaže). Vrací počet položek."""
    import richmovie_paths as RP
    import richmovie_profile as _p
    ss = _state()
    if owner_id is None or not _p.is_multi():
        return 0
    legacy = RP.profile_subdir(_p.LEGACY_DIRNAME)
    if not legacy.is_dir():
        return 0
    files = [f for name in sorted(RP.PERSONAL_FILES) for f in file_variants(legacy, name)]
    if not files:
        return 0
    owner_dir = RP.profile_subdir(str(int(owner_id)))
    owner_dir.mkdir(parents=True, exist_ok=True)
    # odvozené ze souborů + neodeslané z front (S24 R8: tombstony); `enqueue_many` slučuje podle klíče, novější vyhrává
    coll = items_from_dir(legacy) + legacy_queue_items(legacy, _QUEUE, QUEUE_FILE)
    st = legacy_state_items(legacy) + legacy_queue_items(legacy, ss._QUEUE, ss.QUEUE_FILE)
    n_coll = _QUEUE.enqueue_many(coll, path=str(owner_dir / QUEUE_FILE)) if coll else 0
    n_state = ss._QUEUE.enqueue_many(st, path=str(owner_dir / ss.QUEUE_FILE)) if st else 0
    if n_coll < 0 or n_state < 0:
        # zápis fronty selhal → archiv NEpřejmenovat, příště znovu (R2: marker až po absolutním úspěchu)
        _log("legacy import: zařazení do front majitele selhalo (kolekce %d, stav %d) — archiv zůstává" % (n_coll, n_state), 3)
        return 0
    n = n_coll + n_state
    stamp = int(time.time())
    for f in files:
        try:
            f.replace(legacy / ("%s.imported-%d" % (f.name, stamp)))
        except Exception as exc:
            _log("legacy import: rename %s failed: %r" % (f.name, exc), 2)
    _log("legacy import: %d položek (%d kolekce, %d stav) z profiles/%s → fronty majitele %s"
         % (n, len(coll), len(st), _p.LEGACY_DIRNAME, owner_id))
    scope = ss.sync_scope()
    if n and scope and scope.get("profile_id") == owner_id:
        ss.request_push("items")
        if n_state:
            ss.request_push("state")
    return n


def owner_profile_id() -> Optional[int]:
    try:
        import richmovie_profile as _p
        for p in _p.profiles_cached():
            if p.get("is_owner"):
                return int(p.get("id"))
    except Exception:
        pass
    return None


def seed_from_local(profile_id: Optional[int]) -> int:
    """Jednou per (zařízení, profil): lokální kolekce → fronta. Značka v kurzoru profilu
    (kurzor leží v adresáři profilu, takže je per profil sama od sebe)."""
    cur = _CURSOR.load()
    if (cur.get("extra") or {}).get(SEED_MARK):
        return 0
    items = local_items()
    n = _QUEUE.enqueue_many(items) if items else 0
    if n < 0:
        _log("seed: zápis fronty selhal → značka se nezapíše, příště znovu (profil %s)" % profile_id, 3)
        return 0
    _CURSOR.save(int(cur.get("version") or 0), profile_id, full_at=cur.get("full_at"), extra={SEED_MARK: True},
                 touch_pull=False)   # značka seedu ≠ pull (čerstvé zařízení musí zůstat bez pulled_at)
    _log("seed: %d lokálních položek kolekcí do fronty (profil %s)" % (n, profile_id))
    if n:
        _state().request_push("items")
    return n


# ── push ─────────────────────────────────────────────────────────────────────

def _transport_post(path: str, body: Dict[str, Any], timeout: float) -> Tuple[int, Any]:
    from richmovie_gate_transport import post_json
    return post_json(path, body, timeout=timeout)


def _transport_get(path: str, params: Dict[str, Any], timeout: float, *, quick: bool = False) -> Dict[str, Any]:
    import richmovie_profile as _p
    return _p.gate_get(path, params=params, timeout=timeout, quick=quick, background=not quick)


def push_body(scope: Dict[str, Any], batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    ss = _state()
    return _sq.identity_body({"profile_id": scope.get("profile_id"), "device_label": ss.device_label(),
                              "items": batch, "client_now": _sq.to_iso(time.time())})


def pending_count() -> int:
    return _QUEUE.pending_count()


def _ensure_seeded(scope: Dict[str, Any]) -> None:
    """Seed + import archivu při KAŽDÉ příležitosti (push i pull): ticker pushuje jen když je
    fronta neprázdná, takže na čistém zařízení by seed schovaný jen ve `flush()` nikdy
    neproběhl (na PC 05.09. ho spustila jen náhodou čekající položka stavu)."""
    try:
        seed_from_local(scope.get("profile_id"))
        import_legacy_dir(owner_profile_id())   # DP3: archiv z doby před profily → majitel
    except Exception as exc:
        _log("seed/legacy import failed: %r" % exc, 3)


def flush(reason: str = "tick", timeout: float = 20.0) -> str:
    ss = _state()
    ok, _why = ss._preconditions()
    if not ok:
        return OUTCOME_SKIPPED
    scope = ss.sync_scope() or {}
    _ensure_seeded(scope)
    return _sq.flush_queue(_QUEUE, endpoint=ITEMS_PATH, body_builder=lambda batch: push_body(scope, batch),
                           transport_post=_transport_post, timeout=timeout, reason=reason,
                           batch_max=PUSH_BATCH_MAX, on_newer=apply_remote, log=_log, flush_lock=_flush_lock)


# ── pull + aplikace ──────────────────────────────────────────────────────────

def _remote_ts(it: Dict[str, Any]) -> float:
    return _sq.to_epoch(it.get("client_updated_at"))


def _local_newer(local_ts: Any, remote_ts: float) -> bool:
    try:
        return float(local_ts or 0) > remote_ts
    except (TypeError, ValueError):
        return False


def _same(local: Any, remote: Any) -> bool:
    """Lokální záznam == vzdálený (po JSON normalizaci) → žádná změna. Bez toho by každý
    pull s překryvem 50 verzí přepisoval soubory a invalidoval raily každých 30 s
    (pozorováno 05.09. 21:31 po prvním nasazení: „50 změn sloučeno" každý tik)."""
    try:
        import json as _json
        return _json.dumps(local, sort_keys=True, ensure_ascii=False) == _json.dumps(remote, sort_keys=True, ensure_ascii=False)
    except Exception:
        return False


def _valid_record(collection: str, payload: Dict[str, Any], deleted: bool) -> bool:
    """Tvar payloadu z Gate před zápisem do lokálního souboru (Pro B P16.2): cizí/poškozená
    položka nesmí rozbít JSON, který čte UI. Tombstone tvar nepotřebuje."""
    if deleted:
        return True
    rec = payload.get("record") if collection != "title_prefs" else payload.get("pref")
    if collection == "search":
        return isinstance(rec, str) or (isinstance(rec, dict) and isinstance(rec.get("query"), str))
    if collection == "watch_history":
        return isinstance(rec, dict) and (isinstance(rec.get("tv_id"), (str, int)) or "title" in rec or "tmdb" in rec)
    if collection == "my_list":
        return isinstance(rec, dict) and rec.get("tmdb_id") not in (None, "")
    if collection == "title_prefs":
        return isinstance(rec, dict) and "audio_lang" in rec
    if collection == "ai_dismissed":
        return True
    if collection == "ratings":
        import richmovie_ratings as _rt
        return _rt.parse_record(rec) is not None
    return False


def _apply_search(items: List[Dict[str, Any]]) -> int:
    import richmovie_history as H
    hist = H.load_history()
    changed = 0
    for it in items:
        payload = it.get("payload") or {}
        cat = str(payload.get("category") or (it.get("item_key") or "").split("|", 1)[0] or "other").lower()
        rts = _remote_ts(it)
        entries = list(hist.get(cat) or [])
        key = it.get("item_key")
        keep = []
        skip = False
        rec = payload.get("record")
        for e in entries:
            if search_key(cat, _record_query(e)) == key:
                if (isinstance(e, dict) and _local_newer(e.get("ts"), rts)) or (not it.get("deleted") and _same(e, rec)):
                    skip = True   # lokální novější → zůstává (je ve frontě / už na Gate); shodný = no-op
                    keep.append(e)
                continue
            keep.append(e)
        if skip:
            continue
        if not it.get("deleted"):
            if rec is None:
                continue
            keep.insert(0, rec)
        elif len(keep) == len(entries):
            continue   # tombstone na položku, kterou nemáme → no-op
        keep.sort(key=lambda e: float(e.get("ts") or 0) if isinstance(e, dict) else 0.0, reverse=True)
        new_list = keep[:SEARCH_MAX_PER_CATEGORY]
        if _same(new_list, entries):
            continue   # položka nad lokální strop / bez efektu = žádná změna (Fable P2-3)
        hist[cat] = new_list
        changed += 1
    if changed:
        H.save_history(hist)
    return changed


def _apply_watch(items: List[Dict[str, Any]]) -> int:
    import richmovie_history as H
    data = H.watch_load() or {"movies": [], "episodes": []}
    changed = 0
    for it in items:
        payload = it.get("payload") or {}
        key = it.get("item_key") or ""
        branch = payload.get("branch") or ("episodes" if key.startswith("tv:") else "movies")
        keyfn = watch_episode_key if branch == "episodes" else watch_movie_key
        rts = _remote_ts(it)
        lst = list(data.get(branch) or [])
        keep, skip = [], False
        for rec in lst:
            if isinstance(rec, dict) and keyfn(rec) == key:
                if _local_newer(rec.get("ts"), rts) or (not it.get("deleted") and _same(rec, payload.get("record"))):
                    skip = True
                    keep.append(rec)
                continue
            keep.append(rec)
        if skip:
            continue
        if not it.get("deleted") and isinstance(payload.get("record"), dict):
            keep.insert(0, payload["record"])
        elif it.get("deleted") and len(keep) == len(lst):
            continue
        keep.sort(key=lambda r: float(r.get("ts") or 0) if isinstance(r, dict) else 0.0, reverse=True)
        new_list = keep[:H.WATCH_MAX_ITEMS] if H.WATCH_MAX_ITEMS > 0 else keep
        if _same(new_list, lst):
            continue   # nad lokální strop = no-op (Fable P2-3)
        data[branch] = new_list
        changed += 1
    if changed:
        H.watch_save(data)
    return changed


def _apply_my_list(items: List[Dict[str, Any]]) -> int:
    import richmovie_history as H
    data = H.my_list_load() or {"items": []}
    changed = 0
    for it in items:
        payload = it.get("payload") or {}
        key = it.get("item_key")
        rts = _remote_ts(it)
        keep, skip = [], False
        cur_items = data.get("items") or []
        for rec in cur_items:
            if isinstance(rec, dict) and list_key(rec.get("tmdb_id"), rec.get("kind")) == key:
                if _local_newer(rec.get("ts"), rts) or (not it.get("deleted") and _same(rec, payload.get("record"))):
                    skip = True
                    keep.append(rec)
                continue
            keep.append(rec)
        if skip:
            continue
        if not it.get("deleted") and isinstance(payload.get("record"), dict):
            keep.insert(0, payload["record"])
        elif it.get("deleted") and len(keep) == len(cur_items):
            continue
        keep.sort(key=lambda r: float(r.get("ts") or 0) if isinstance(r, dict) else 0.0, reverse=True)
        new_list = keep[:H.MY_LIST_MAX_ITEMS] if H.MY_LIST_MAX_ITEMS > 0 else keep
        if _same(new_list, cur_items):
            continue   # nad lokální strop = no-op (Fable P2-3)
        data["items"] = new_list
        changed += 1
    if changed:
        H._my_list_save(data)
    return changed


def _apply_title_prefs(items: List[Dict[str, Any]]) -> int:
    import richmovie_title_prefs as TP
    data = TP._load()
    titles = data.setdefault("titles", {})
    changed = 0
    reassert: List[Dict[str, Any]] = []
    for it in items:
        key = it.get("item_key")
        if not key:
            continue
        payload = it.get("payload") or {}
        pref = payload.get("pref")
        existing = titles.get(key) or {}
        rts = _remote_ts(it)
        if existing and (_local_newer(existing.get("ts"), rts) or (not it.get("deleted") and _same(existing, pref))):
            continue
        if existing and existing.get("source", "manual") == "manual" and isinstance(pref, dict) \
                and pref.get("source") == "observed":
            # manuální volba je svatá i přes LWW (deterministicky na všech zařízeních):
            # Gate má observed → pošleme manuál znovu s čerstvým časem, ať konverguje
            reassert.append(make_item("title_prefs", key, {"pref": dict(existing, ts=int(time.time()))}))
            continue
        if it.get("deleted"):
            if key in titles:
                titles.pop(key, None)
                changed += 1
            continue
        if isinstance(pref, dict):
            titles[key] = pref
            changed += 1
    if changed:
        data["version"] = 1
        TP._save(data)
    if reassert:
        _QUEUE.enqueue_many(reassert)   # vědomě mimo `note_change` (jsme pod applying_remote)
    return changed


def _apply_ai_dismissed(items: List[Dict[str, Any]]) -> int:
    import richmovie_history as H
    ids = list(H.ai_dismissed_ids())
    before = set(ids)
    for it in items:
        key = it.get("item_key")
        if not key:
            continue
        if it.get("deleted"):
            ids = [k for k in ids if k != key]
        elif key not in ids:
            ids.insert(0, key)
    if set(ids) == before:
        return 0
    H._ai_dismissed_save(ids)
    return 1


def _apply_ratings(items: List[Dict[str, Any]]) -> int:
    """Hodnocení z jiných zařízení (3.5.152): LWW per titul, tombstone = smazané hodnocení.
    Zápis dělá SSOT `richmovie_ratings.apply_remote` (pod zámkem souboru drží volající)."""
    import richmovie_ratings as _rt
    return _rt.apply_remote(items)


_FILES = {"search": "history.json", "watch_history": "watch_history.json", "my_list": "my_list.json",
          "title_prefs": "title_prefs.json", "ai_dismissed": "ai_dismissed.json",
          "ratings": "title_ratings.json"}

_APPLIERS = {
    "search": _apply_search,
    "watch_history": _apply_watch,
    "my_list": _apply_my_list,
    "title_prefs": _apply_title_prefs,
    "ai_dismissed": _apply_ai_dismissed,
    "ratings": _apply_ratings,
}


def apply_remote(items: List[Dict[str, Any]]) -> int:
    """Položky z Gate (pull i `newer` z pushu) → lokální soubory. Vrací počet změn.
    Pod `applying_remote`: zapisovače historie NEzařadí echo."""
    return apply_remote_ex(items)[0]


_APPLY_OK = "ok"
_APPLY_BLOCKED = "blocked"        # chyba prostředí / nezapsaný soubor → kurzor stojí (R2)
_APPLY_ITEM_ERROR = "item_error"  # logická chyba sloučení → izolovat vadnou položku (R2b)


def _apply_group(coll: str, group: List[Dict[str, Any]]) -> Tuple[int, str, Optional[BaseException]]:
    """Jedno sloučení skupiny položek kolekce pod zámkem souboru a `failure_scope`: (změny, výsledek, výjimka)."""
    import richmovie_atomic as _atomic
    import richmovie_paths as RP
    writes = None
    try:
        # 3.5.151 (Φ3): save funkce historie selhání zápisu jen logují — scope ho zachytí,
        # jinak by se kurzor posunul nad daty, která na disku nejsou (R2)
        with RP.personal_lock(_FILES[coll]), _atomic.failure_scope() as writes:
            changed = int(_APPLIERS[coll](group) or 0)
    except Exception as exc:
        if _sq.apply_error_blocks_cursor(exc) or (writes is not None and writes.failed):
            return 0, _APPLY_BLOCKED, exc
        return 0, _APPLY_ITEM_ERROR, exc
    if writes.failed:
        return changed, _APPLY_BLOCKED, None
    return changed, _APPLY_OK, None


def apply_remote_ex(items: List[Dict[str, Any]]) -> Tuple[int, bool]:
    """(počet změn, ok). `ok=False` = některá kolekce se nesloučila kvůli prostředí (I/O, zápis) → volající
    (pull) NEposune kurzor, aby se dávka zkusila znovu (Pro B P16.1, R2).

    Logická chyba sloučení (Fable F4 + cross-check Pro B2 QC3, 17.09.2026): kolekce se sloučí znovu PO JEDNÉ
    položce — dobré položky se zapíšou, vadná se přeskočí s ERROR logem (zůstává na Gate, R2b). Dřív jedna
    vadná položka zastavila kurzor navždy (P16.1), resp. zahodila celou dávku kolekce."""
    groups: Dict[str, List[Dict[str, Any]]] = {}
    skipped = 0
    for it in items or []:
        coll = it.get("collection")
        if it.get("from_this_device"):
            continue   # echo vlastního pushe (Gate označuje `updated_device` == náš device_hash)
        if coll not in _APPLIERS or not it.get("item_key"):
            continue
        if not _valid_record(coll, it.get("payload") or {}, bool(it.get("deleted"))):
            skipped += 1
            continue
        groups.setdefault(coll, []).append(it)
    if skipped:
        _log("apply: %d položek s neplatným tvarem přeskočeno" % skipped, 2)
    if not groups:
        return 0, True
    ss = _state()
    total = 0
    ok = True
    with ss.applying_remote():
        for coll, group in groups.items():
            changed, outcome, exc = _apply_group(coll, group)
            total += changed
            if outcome == _APPLY_BLOCKED:
                ok = False
                _log("apply %s: zápis selhal (%r) → kurzor zůstává" % (coll, exc), 3)
                continue
            if outcome == _APPLY_OK:
                continue
            _log("apply %s: sloučení dávky spadlo (%r) → po jedné položce" % (coll, exc), 3)
            for single in group:
                changed, outcome, exc = _apply_group(coll, [single])
                total += changed
                if outcome == _APPLY_BLOCKED:
                    ok = False
                    _log("apply %s: zápis selhal (%r) → kurzor zůstává" % (coll, exc), 3)
                    break
                if outcome == _APPLY_ITEM_ERROR:
                    _log("apply %s: vadná položka %s přeskočena (%r) — zůstává na Gate" % (
                        coll, single.get("item_key"), exc), 3)
    # invalidaci UI dělají SSOT save funkce (save_history → "search", watch_save → "watch",
    # _my_list_save → "my_list", _ai_dismissed_save → "ai") — žádný paušální bump (Fable P2-2)
    return total, ok


def pull_and_apply(reason: str = "tick", timeout: float = 8.0, max_pages: int = _sq.PULL_PAGES_MAX) -> Tuple[int, str]:
    ss = _state()
    ok, _why = ss._preconditions()
    if not ok:
        return 0, OUTCOME_SKIPPED
    scope = ss.sync_scope() or {}
    _ensure_seeded(scope)   # seed → fronta → ticker v dalším tiku pushne (request_push uvnitř seedu)
    return _sq.pull_queue(endpoint=ITEMS_PATH, cursor=_CURSOR, profile_id=scope.get("profile_id"),
                          transport_get=_transport_get, on_apply=apply_remote_ex, log=_log, pull_lock=_pull_lock,
                          reason=reason, timeout=timeout, max_pages=max_pages, include_param="include_deleted",
                          quick=(reason == "menu"), claim_name=PULL_CLAIM)


def last_pull_age_s() -> float:
    return _CURSOR.last_pull_age_s()
