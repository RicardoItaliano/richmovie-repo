# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_continuity — stejná verze streamu u dalšího dílu (3.5.151, Φ3c + D4)
───────────────────────────────────────────────────────────────────────────────
Plán: `Handoff/PLAN_resume_native_start_sync_integrity_20260916.md` (Nález D).

PROČ
  Richie 16.09.2026 (vlak, S05E15 → S05E16): „Má se automaticky pustit díl, který má
  cca stejnou velikost nebo blízkou jako předchozí a hlavně má dabing a titulky, které
  uživatel u předchozího dílu měl aktivní." Dabing a titulky řeší per-title preference
  (`_pref_match_terms`, zůstávají dealbreakerem). Verzi ne: po dabingu rozhodovala
  nejvyšší kvalita a pak NEJVĚTŠÍ soubor. S05E15 = 1080p HEVC CZ 2.0 (~0,67 Mbit/s);
  pro S05E16 existovala stejná řada (`x4ed0NKKsK`), vyhrál ale `5nFjjotDa4` (1080p AVC,
  CZ + EN 5.1) jen proto, že je větší — na děravé síti přesně naopak.

JAK
  • Při konci přehrávání (≥ 300 s sledování, parita s observed preferencí) služba uloží
    PROFIL VERZE titulu: kodek a výška z Kodi (`currentvideostream`), datový tok
    (velikost / délka), technický podpis názvu vydání (rozlišení, kodek, zdroj, audio
    značky, skupina, přípona) a zdroj.
  • `continuity_rank()` zařadí kandidáta: 0 stejná verze → 1 podobná → 2 neutrální →
    3 vzdálená (datový tok mimo 0,5–2×). Vkládá se do `plugin._release_sort_key` ZA
    dealbreakery (dabing/titulky, runtime, název) a PŘED kvalitu a velikost. Bez profilu
    je rank pro všechny 0 = pořadí beze změny.
  • D4 (Richie 16.09.2026): po utnutí streamu nebo mrtvém zdroji na TOMTO zařízení
    (`note_stress`, 6 h) se preferuje stejný nebo NIŽŠÍ datový tok (> 1,1× = vzdálená).

D5 (rozhodnutí implementace): profil verze je osobní (per profil) a LOKÁLNÍ — mezi
zařízeními se nesynchronizuje. Linka i displej se liší (TV obývák 4K vs. telefon ve
vlaku); „stejná verze" dává smysl na zařízení, kde se právě dívám.

Čisté funkce bez Kodi → harness scénář 62. Python 3.8 (Kodi runtime).
"""

from __future__ import annotations

import os
import re
import time
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Tuple

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.continuity", "RichMovie/Continuity")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):
        try:
            import xbmc
            xbmc.log("[RichMovie/Continuity] %s" % msg, level)
        except Exception:
            pass

_LOGDEBUG, _LOGINFO, _LOGWARNING, _LOGERROR = 0, 1, 2, 3


# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
PROFILES_FILE = "stream_profiles.json"   # osobní soubor profilu (richmovie_paths.PERSONAL_FILES)
STRESS_FILE = "playback_stress.json"     # soubor zařízení (kořen dat, ne profil)
PROFILES_MAX = 300                       # LRU podle `ts`; ~300 seriálů je víc, než kdo rozkouká
PROFILE_MIN_WATCHED_S = 300.0            # omylem spuštěný díl verzi neurčuje (parita s observed pref)
STRESS_TTL_S = 6 * 3600                  # výpadky ve vlaku / na chatě = tentýž večer

NEAR_LOW, NEAR_HIGH = 0.70, 1.40         # „podobná velikost" (±30–40 % kolísá i jedna řada mezi díly)
FAR_LOW, FAR_HIGH = 0.50, 2.00           # za tím už je to jiná třída verze
STRESS_MAX_RATIO = 1.10                  # D4: po výpadcích nic dražšího než minulý díl
FAMILY_MIN_JACCARD = 0.75
FAMILY_MIN_TOKENS = 2

RANK_SAME_VERSION = 0
RANK_SIMILAR = 1
RANK_NEUTRAL = 2
RANK_FAR = 3

STRESS_UNEXPECTED_EOF = "unexpected_eof"
STRESS_DEAD_SOURCE = "dead_source"

CODEC_ALIASES = {
    "x265": "hevc", "h265": "hevc", "hevc": "hevc",
    "x264": "h264", "h264": "h264", "avc": "h264", "avc1": "h264",
    "xvid": "xvid", "divx": "xvid", "mpeg4": "xvid",
    "av1": "av1", "vp9": "vp9",
}
RESOLUTION_TOKENS = {"2160p": 2160, "4k": 2160, "uhd": 2160, "1080p": 1080, "1080i": 1080,
                     "fhd": 1080, "720p": 720, "576p": 576, "540p": 540, "480p": 480, "360p": 360}
_OTHER_TECH = {
    # holé „web" se NEpočítá (cross-check Flash F13: „The.Tholian.Web" je název dílu); WEB-DL / WEBRip ano
    "webdl", "webrip", "bluray", "bdrip", "brrip", "dvdrip", "hdtv", "tvrip", "remux", "hdrip",
    "cz", "czech", "cesky", "dabing", "dab", "titulky", "tit", "sk", "en", "eng", "multi", "dual",
    "ac3", "eac3", "dd51", "ddp", "aac", "dts", "truehd", "atmos", "ch51", "ch20", "ch71",
    "hdr", "hdr10", "dv", "10bit",
}
TECH_TOKENS = frozenset(set(CODEC_ALIASES) | set(RESOLUTION_TOKENS) | _OTHER_TECH)

_NORMALIZE = (
    (re.compile(r"h[\.\s]?265"), "h265"),
    (re.compile(r"h[\.\s]?264"), "h264"),
    (re.compile(r"web[\.\-\s]?dl"), "webdl"),
    (re.compile(r"web[\.\-\s]?rip"), "webrip"),
    (re.compile(r"blu[\.\-\s]?ray"), "bluray"),
    (re.compile(r"dd[\+p]?[\.\s]?5[\.\s]1"), "dd51"),
    (re.compile(r"(?<![\d.])5[\.\s]1(?![\d.])"), "ch51"),
    (re.compile(r"(?<![\d.])2[\.\s]0(?![\d.])"), "ch20"),
    (re.compile(r"(?<![\d.])7[\.\s]1(?![\d.])"), "ch71"),
    (re.compile(r"10[\s\-]?bit"), "10bit"),
)
_EPISODE_MARKERS = re.compile(
    r"\b(?:s\d{1,2}[\s._-]*e\d{1,3}(?:[\s._-]*e\d{1,3})?|\d{1,2}x\d{1,3}|ep?\d{1,3}|part[\s._-]*\d+|dil[\s._-]*\d+)\b")
_EXT = re.compile(r"\.([a-z0-9]{2,4})$")
_GROUP = re.compile(r"-([a-z0-9]{2,15})$")


# ─────────────────────────────────────────────────────────────────────────────
#  PODPIS NÁZVU A VLASTNOSTI KANDIDÁTA (čisté)
# ─────────────────────────────────────────────────────────────────────────────
def name_signature(name: Any) -> FrozenSet[str]:
    """Technický podpis názvu vydání: rozlišení, kodek (kanonicky), zdroj, audio značky,
    skupina (`-GRP` na konci) a přípona. Název dílu a čísla epizod se nepočítají —
    jinak by se dva díly TÉŽE řady nikdy neshodly."""
    text = str(name or "").strip().lower()
    if not text:
        return frozenset()
    sig = set()
    m = _EXT.search(text)
    if m and _is_video_ext(m.group(1)):
        sig.add("ext:" + m.group(1))
        text = text[:m.start()]
    g = _GROUP.search(text)
    if g and g.group(1) not in TECH_TOKENS and not g.group(1).isdigit():
        sig.add("grp:" + g.group(1))
    for pattern, repl in _NORMALIZE:
        text = pattern.sub(repl, text)
    text = _EPISODE_MARKERS.sub(" ", text)
    for tok in re.split(r"[^a-z0-9]+", text):
        if tok in CODEC_ALIASES:
            sig.add("codec:" + CODEC_ALIASES[tok])
        elif tok in TECH_TOKENS:
            sig.add(tok)
    return frozenset(sig)


def _is_video_ext(ext: str) -> bool:
    """Konec názvu je přípona videa? Seznam = SSOT filtru vydání `richmovie_engine.ALLOWED_VIDEO_EXTS`
    (tentýž propouští kandidáty do výběru). Fable F8: název bez přípony („Film.2019", „S05E15.720p")
    dával `ext:2019` / `ext:720p` a rozlišení se z podpisu ztratilo. Import líně: modul zůstává
    bez Kodi závislostí; bez enginu (mimo addon) se přípona do podpisu nepočítá — u profilu i kandidátů stejně."""
    try:
        from richmovie_engine import ALLOWED_VIDEO_EXTS
    except Exception:
        return False
    return ("." + str(ext or "").lower()) in ALLOWED_VIDEO_EXTS


def codec_from_signature(sig: Iterable[str]) -> str:
    for tok in sig or ():
        if tok.startswith("codec:"):
            return tok[6:]
    return ""


def height_from_signature(sig: Iterable[str]) -> int:
    best = 0
    for tok in sig or ():
        h = RESOLUTION_TOKENS.get(tok)
        if h:
            best = max(best, int(h))
    return best


def normalize_codec(raw: Any) -> str:
    text = str(raw or "").strip().lower().replace(".", "").replace("-", "")
    return CODEC_ALIASES.get(text, text)


def bitrate(size_bytes: Any, duration_s: Any) -> Optional[float]:
    try:
        size = float(size_bytes or 0)
        dur = float(duration_s or 0)
    except (TypeError, ValueError):
        return None
    if size <= 0 or dur <= 0:
        return None
    return size * 8.0 / dur


def family_match(sig_a: Iterable[str], sig_b: Iterable[str]) -> bool:
    a, b = frozenset(sig_a or ()), frozenset(sig_b or ())
    if len(a) < FAMILY_MIN_TOKENS or len(b) < FAMILY_MIN_TOKENS:
        return False
    union = a | b
    return bool(union) and (len(a & b) / float(len(union))) >= FAMILY_MIN_JACCARD


def release_features(release: Any, mi_flags: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Vlastnosti kandidáta (Release z enginu) pro porovnání s profilem. `mi_flags` =
    `richmovie_engine.mi2_get_flags(ident)` (výška a délka z MediaInfo, když je)."""
    mi = mi_flags if isinstance(mi_flags, dict) else {}
    sig = name_signature(getattr(release, "name", ""))
    duration = 0.0
    for candidate in (getattr(release, "ws_len_s", None), mi.get("duration_s")):
        try:
            if candidate and float(candidate) > 0:
                duration = float(candidate)
                break
        except (TypeError, ValueError):
            continue
    if duration <= 0:
        try:
            est = float(getattr(release, "est_min", 0) or 0)
            duration = est * 60.0 if est > 0 else 0.0
        except (TypeError, ValueError):
            duration = 0.0
    height = 0
    for candidate in (getattr(release, "ws_height", None), mi.get("video_h")):
        try:
            if candidate and int(candidate) > 0:
                height = int(candidate)
                break
        except (TypeError, ValueError):
            continue
    if height <= 0:
        height = height_from_signature(sig)
    size = int(getattr(release, "size", 0) or 0)
    return {
        "sig": sig,
        "codec": codec_from_signature(sig),
        "height": height,
        "size_bytes": size,
        "duration_s": duration,
        "bitrate_bps": bitrate(size, duration),
        "audios": sorted({str(a).strip().upper()[:2] for a in (getattr(release, "audios", None) or []) if str(a).strip()}),
        "source": (getattr(release, "source", "") or "webshare"),
    }


# ─────────────────────────────────────────────────────────────────────────────
#  POŘADÍ (čisté)
# ─────────────────────────────────────────────────────────────────────────────
def continuity_rank(profile: Optional[Dict[str, Any]], feat: Dict[str, Any], *,
                    prefer_lower: bool = False) -> int:
    """0 stejná verze / 1 podobná / 2 neutrální / 3 vzdálená. Bez profilu 0 pro všechny.

    D10 (Richie 30.09.2026, incident SG-1 S08E01 řádek 02): stream, o kterém NIC nevíme (bez rozlišení, bez datového
    toku, bez rodiny vydání), je „vzdálený“ — neznámý údaj nesmí předběhnout potvrzené 1080p soubory s jiným tokem
    (dřív „neutrální“ 2 < „vzdálená“ 3)."""
    if not profile:
        return RANK_SAME_VERSION
    if (not feat.get("height") and not feat.get("bitrate_bps")
            and not family_match(profile.get("sig") or (), feat.get("sig") or ())):
        return RANK_FAR
    p_rate = profile.get("bitrate_bps")
    f_rate = feat.get("bitrate_bps")
    ratio = None
    try:
        if p_rate and f_rate and float(p_rate) > 0:
            ratio = float(f_rate) / float(p_rate)
    except (TypeError, ValueError):
        ratio = None
    p_codec, f_codec = profile.get("codec") or "", feat.get("codec") or ""
    p_height, f_height = int(profile.get("height") or 0), int(feat.get("height") or 0)
    codec_ok = not (p_codec and f_codec and p_codec != f_codec)
    height_ok = not (p_height and f_height and p_height != f_height)
    shape = codec_ok and height_ok
    family = shape and family_match(profile.get("sig") or (), feat.get("sig") or ())
    if prefer_lower:
        # D4: po výpadcích nic dražšího než minulý díl. Neznámý tok je nejistota — ne „ověřeně
        # nižší" (cross-check Pro B PB4b): řada bez toku 1, jinak 2; ověřeně ≤ 1,1× 0/1.
        if ratio is not None and ratio > STRESS_MAX_RATIO:
            return RANK_FAR
        if ratio is None:
            return RANK_SIMILAR if family else RANK_NEUTRAL
        return RANK_SAME_VERSION if family else RANK_SIMILAR
    # Vyšší rozlišení se srovnatelným tokem (≤ 2×) je stejná nebo LEPŠÍ verze (cross-check Pro B PB4a):
    # profil z 480p ripu nesmí trvale držet 480p, když je k dispozici 1080p HEVC podobné velikosti.
    # O pořadí mezi nimi pak rozhodne kvalita; 20GB 4K (tok ≫ 2×) upgrade není.
    if codec_ok and p_height and f_height > p_height and (ratio is None or ratio <= FAR_HIGH):
        return RANK_SAME_VERSION
    near = ratio is None or NEAR_LOW <= ratio <= NEAR_HIGH
    if family and near:
        return RANK_SAME_VERSION
    if shape and near:
        return RANK_SIMILAR
    if ratio is None or FAR_LOW <= ratio <= FAR_HIGH:
        return RANK_NEUTRAL
    return RANK_FAR


def rank_release(release: Any, context: Optional[Dict[str, Any]]) -> int:
    """Rank kandidáta pro `plugin._release_sort_key`. `context` z `context_for_title`."""
    if not context or not context.get("profile"):
        return RANK_SAME_VERSION
    try:
        mi = None
        ident = str(getattr(release, "ident", "") or "")
        if ident:
            try:
                from richmovie_engine import mi2_get_flags
                mi = mi2_get_flags(ident) or None
            except Exception:
                mi = None
        return continuity_rank(context["profile"], release_features(release, mi),
                               prefer_lower=bool(context.get("prefer_lower")))
    except Exception as exc:
        _log("rank_release failed: %r" % (exc,), _LOGDEBUG)
        return RANK_SAME_VERSION


def describe_release(release: Any, rank: Optional[int] = None, *, prefer_lower: bool = False,
                     mi_flags: Optional[Dict[str, Any]] = None) -> Tuple[str, str]:
    """(důvod, parametry) pro toast: („stejná verze jako minulý díl", „1080p HEVC · CZ · 220 MB")."""
    feat = release_features(release, mi_flags)
    parts = []
    video = []
    if feat["height"]:
        video.append("%dp" % feat["height"])
    if feat["codec"]:
        video.append({"hevc": "HEVC", "h264": "H.264"}.get(feat["codec"], feat["codec"].upper()))
    if video:
        parts.append(" ".join(video))
    if feat["audios"]:
        parts.append("+".join(feat["audios"]))
    size = feat["size_bytes"]
    if size > 0:
        parts.append(("%.1f GB" % (size / 1073741824.0)) if size >= 1073741824 else ("%d MB" % round(size / 1048576.0)))
    reason = ""
    if rank == RANK_SAME_VERSION:
        reason = "stejná verze jako minulý díl"
    elif rank == RANK_SIMILAR:
        reason = "nižší datový tok kvůli výpadkům" if prefer_lower else "podobná verze jako minulý díl"
    return reason, " · ".join(parts)


# ─────────────────────────────────────────────────────────────────────────────
#  PROFIL VERZE (osobní soubor profilu)
# ─────────────────────────────────────────────────────────────────────────────
def build_profile(*, release_name: str, size_bytes: Any, duration_s: Any, source: str, ident: str,
                  video_codec: Any = "", video_height: Any = 0, now: Optional[float] = None) -> Dict[str, Any]:
    """Profil z reálně přehrávaného streamu. Kodek/výška z Kodi mají přednost před názvem."""
    sig = name_signature(release_name)
    codec = normalize_codec(video_codec) or codec_from_signature(sig)
    try:
        height = int(video_height or 0)
    except (TypeError, ValueError):
        height = 0
    if height <= 0:
        height = height_from_signature(sig)
    return {
        "sig": sorted(sig),
        "codec": codec,
        "height": height,
        "size_bytes": int(float(size_bytes or 0)),
        "duration_s": round(float(duration_s or 0), 1),
        "bitrate_bps": bitrate(size_bytes, duration_s),
        "source": source or "webshare",
        "ident": ident or "",
        "ts": int(time.time() if now is None else now),
    }


def _profiles_path() -> str:
    import richmovie_paths
    return str(richmovie_paths.personal_path(PROFILES_FILE))


def load_profile(title_key: str) -> Optional[Dict[str, Any]]:
    if not title_key:
        return None
    try:
        import richmovie_atomic as _atomic
        path = _profiles_path()
        if not os.path.isfile(path):
            return None   # čtení běží při každém řazení streamů — chybějící soubor není událost pro log
        data, _state = _atomic.read_json(path, None, name="stream_profiles", expected_type=dict)
        prof = ((data or {}).get("titles") or {}).get(title_key)
        return prof if isinstance(prof, dict) else None
    except Exception:
        return None


def save_profile(title_key: str, profile: Dict[str, Any]) -> bool:
    """RMW pod `personal_lock`; I/O chyba čtení (UNREADABLE) = nic nepřepisovat."""
    if not title_key or not isinstance(profile, dict):
        return False
    try:
        import richmovie_atomic as _atomic
        import richmovie_paths as _rp
        path = _profiles_path()
        with _rp.personal_lock(PROFILES_FILE):
            data, state = _atomic.read_json(path, None, name="stream_profiles", expected_type=dict)
            if state == _atomic.STATE_UNREADABLE:
                return False
            if not isinstance(data, dict):
                data = {}
            titles = data.get("titles") if isinstance(data.get("titles"), dict) else {}
            titles[title_key] = profile
            if len(titles) > PROFILES_MAX:
                keep = sorted(titles.items(), key=lambda kv: int((kv[1] or {}).get("ts") or 0), reverse=True)
                titles = dict(keep[:PROFILES_MAX])
            return bool(_atomic.write_json(path, {"schema": 1, "titles": titles}))
    except Exception as exc:
        _log("save_profile failed: %r" % (exc,), _LOGWARNING)
        return False


# ─────────────────────────────────────────────────────────────────────────────
#  STRES SÍTĚ NA ZAŘÍZENÍ (D4)
# ─────────────────────────────────────────────────────────────────────────────
def _stress_path() -> str:
    import richmovie_paths
    return str(richmovie_paths.account_path(STRESS_FILE))


def stress_active_in(data: Optional[Dict[str, Any]], now: Optional[float] = None) -> bool:
    now = time.time() if now is None else float(now)
    try:
        ts = float((data or {}).get("ts") or 0)
    except (TypeError, ValueError):
        return False
    return ts > 0 and (now - ts) <= STRESS_TTL_S


def note_stress(reason: str, now: Optional[float] = None) -> bool:
    """Zařízení právě zažilo utnutí streamu / mrtvý zdroj. Vrací True = zapsáno.

    Noc 03.11.2026 (Φ1): přes systémový filtr obsahu (`richmovie_device_env.filtered`) utnutí neříká nic o lince
    ani o datovém toku — filtr zdržuje každý velký přenos. Zápis by dalších 6 h snižoval kvalitu bez důvodu."""
    now = time.time() if now is None else float(now)
    try:
        import richmovie_device_env as _denv
        if _denv.filtered():
            _log("STREAM_STRESS_SKIPPED reason=%s (%s: %s)" % (reason, _denv.STRESS_SKIP_REASON, _denv.os_filter()),
                 _LOGINFO)
            return False
    except Exception:
        pass
    try:
        import richmovie_atomic as _atomic
        path = _stress_path()
        prev, _state = _atomic.read_json(path, None, name="playback_stress", expected_type=dict)
        count = int((prev or {}).get("count") or 0) if stress_active_in(prev, now) else 0
        ok = bool(_atomic.write_json(path, {"schema": 1, "ts": int(now), "reason": str(reason or ""),
                                            "count": count + 1}))
        if ok:
            _log("STREAM_STRESS reason=%s count=%d (další díl preferuje nižší datový tok %d h)" % (
                reason, count + 1, STRESS_TTL_S // 3600), _LOGINFO)
        return ok
    except Exception as exc:
        _log("note_stress failed: %r" % (exc,), _LOGWARNING)
        return False


def stress_active(now: Optional[float] = None) -> bool:
    try:
        import richmovie_atomic as _atomic
        path = _stress_path()
        if not os.path.isfile(path):
            return False   # zařízení bez výpadku (většina) — žádný READ_NO_FILE při každém řazení
        data, _state = _atomic.read_json(path, None, name="playback_stress", expected_type=dict)
        return stress_active_in(data, now)
    except Exception:
        return False


def context_for_title(title_key: Optional[str]) -> Optional[Dict[str, Any]]:
    """Kontext pořadí pro volající (`_pick_best_release`, výpis streamů seriálu)."""
    if not title_key:
        return None
    profile = load_profile(title_key)
    if not profile:
        return None
    return {"profile": profile, "prefer_lower": stress_active(), "title_key": title_key}
