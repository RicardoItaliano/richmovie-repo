# -*- coding: utf-8 -*-
"""RichMovie — SSOT událostního logu hledání (`_log_event`) pro knihovní moduly (Φ4, 29.09.2026).

PROČ EXISTUJE (audit A08 F7)
---------------------------
Událostní log (`plugin._log_event`: rotační `richmovie.log` + per-search log, vstup regresního harnessu
`heuristics_replay`) žije v `plugin.py`, protože drží stav hledání (`_SEARCH_LOG_PATH`, dotaz vlákna).
Knihovny (`richmovie_webshare`, `tmdb_client`, `richmovie_downloads`) se k němu dostávaly přes
`import plugin` — a protože hlavní skript Kodi je `__main__`, ne `plugin`, vykonalo se tělo 15k-řádkového
`plugin.py` v jedné invokaci 2–3× (jednou s tiše spolknutým ImportError, jednou s přepsáním callbacků).

KONTRAKT
--------
    register(fn, path_provider)  # plugin při importu: `_log_event` + „kam teď logovat“ (log hledání)
    log_event(*parts)            # knihovna: zapiš událost (bez registrace → routovaný logger)
    current_log_path()           # knihovna: cesta aktuálního logu hledání ("" = žádný)

Knihovní moduly `import plugin` NESMÍ (harness scénář 75 lint); smí jen služba (`service_nextup`) a
spouštěč (`default.py`).

Python 3.8 (Kodi runtime).
"""
from __future__ import annotations

from typing import Any, Callable, Optional

_sink = {"fn": None, "path": None}   # type: dict


def register(fn: Optional[Callable[..., Any]], path_provider: Optional[Callable[[], str]] = None) -> None:
    """Zaregistruje zapisovač událostí (plugin `_log_event`) a poskytovatele cesty aktuálního logu
    hledání. None = odregistrovat (testy)."""
    _sink["fn"] = fn
    _sink["path"] = path_provider


def current_log_path() -> str:
    """Cesta aktuálního logu hledání (`plugin._SEARCH_LOG_PATH`, jinak rotační log); "" bez registrace."""
    provider = _sink["path"]
    if provider is None:
        return ""
    try:
        return str(provider() or "")
    except Exception:
        return ""


def registered() -> bool:
    return _sink["fn"] is not None


def log_event(*parts: object) -> None:
    """Zapíše událost. Nikdy nevyhazuje — log nesmí shodit hledání ani stahování."""
    fn = _sink["fn"]
    if fn is not None:
        try:
            fn(*parts)
            return
        except Exception:
            pass
    try:
        import richmovie_logging as _rl
        _rl.get_logger("richmovie.event").debug(" | ".join(str(p) for p in parts))
    except Exception:
        pass
