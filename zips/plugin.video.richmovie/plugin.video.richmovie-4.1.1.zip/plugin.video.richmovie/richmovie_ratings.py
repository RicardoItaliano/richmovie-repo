# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_ratings — hodnocení titulů v RichMovie (1–5★), per profil (3.5.152)
───────────────────────────────────────────────────────────────────────────────
Plán: `Handoff/PLAN_petra_csfd_profiles_ratings_20260918.md` (Φ3).

PROČ: doporučení dostávala explicitní signál jen z ČSFD (Richieho účet). Petra (a každý
bez ČSFD) neměla jak říct „tohle jsem milovala / nesnesla". Po dokoukání filmu se jednou
zeptáme (`should_ask`), hodnocení se uloží do osobního souboru `title_ratings.json`
a kolekcí `ratings` (`richmovie_profile_items`, Gate mig 0032) doputuje na ostatní zařízení
i do AI (`taste_profile._compute_csfd_signal` — stejná váha jako ČSFD).

SSOT souboru: {"items": {"movie:603": {"rating": 5, "title": "Matrix", "kind": "movie",
"tmdb_id": 603, "ts": 1789600000}}, "skipped": {"movie:604": {"n": 2, "ts": …}}}
Zápisy pod `richmovie_paths.personal_lock` (plugin i služba = jiné procesy). Čisté funkce
(`parse_record`, `should_ask`, `stars`) → harness scénář 63. Python 3.8 (Kodi).
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.ratings", "RichMovie/Ratings")
except Exception:  # pragma: no cover — mimo Kodi bez logovací pipeline
    def _log(msg, level=1, *, context=None):
        try:
            import xbmc
            xbmc.log("[RichMovie/Ratings] %s" % msg, level)
        except Exception:
            pass

FILE_NAME = "title_ratings.json"
COLLECTION = "ratings"
KINDS = ("movie", "tv")
RATING_MIN, RATING_MAX = 1, 5
SKIP_LIMIT = 2                 # „Teď ne" 2× (nebo 2× timeout) = titul se už neptá (D4)
ASK_TIMEOUT_S = 45.0           # dialog po dokoukání zmizí sám; počítá se jako „Teď ne"
SOURCE = "richmovie"

# Seriály (3.5.154, rozhodnutí Richie 20.09.2026 — ruší D3 „seriály se po dokoukání neptají").
# Ptáme se po POLOVINĚ PRVNÍ ŘADY, nejpozději po 5. dílu: u Simpsonových (22 dílů v řadě)
# by polovina znamenala 11 dílů, tedy dávno po chvíli, kdy divák ví, jestli ho to baví.
# Spodní mez 2 díly brání dotazu hned po pilotu u krátkých minisérií.
SERIES_ASK_CAP = 5
SERIES_ASK_FLOOR = 2
STAGE_FIRST_SEASON = "first_season"
STAGE_FINISHED = "finished"
#: Nejmenší odstup dvou dotazů na SERIÁL v jednom profilu. Kdo má rozkoukaných pět seriálů
#: z doby před 3.5.154, překročil práh u všech naráz — bez brzdy by dostal pět dialogů během
#: pár večerů (cross-check Pro Q5, 20.09.2026). Jeden denně je snesitelný.
SERIES_ASK_MIN_GAP_S = 20 * 3600.0

#: Jak dlouho platí přečtený soubor. Plugin je při každé invokaci nový interpret a jedno
#: vykreslení seznamu se ptá na hodnocení u KAŽDÉ položky — bez cache to je tolik čtení
#: souboru, kolik je řádků. Služba běží dlouho, proto TTL a ne trvalá paměť.
CACHE_TTL_S = 3.0

STAR_FULL, STAR_EMPTY = "★", "☆"   # ★ ☆
LABELS = {1: "Odpad", 2: "Slabé", 3: "Dobré", 4: "Výborné", 5: "Skvělé"}


# ─────────────────────────────────────────────────────────────────────────────
#  Čisté funkce
# ─────────────────────────────────────────────────────────────────────────────
def make_key(kind: Any, tmdb_id: Any) -> str:
    """`movie:603` / `tv:1399`; "" při neplatném vstupu."""
    try:
        kind = str(kind or "movie").lower()
        tmdb = int(tmdb_id)
    except (TypeError, ValueError):
        return ""
    if kind not in KINDS or tmdb <= 0:
        return ""
    return "%s:%d" % (kind, tmdb)


def parse_record(rec: Any, *, default_ts: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """Záznam hodnocení (lokální i z Gate) → kanonický tvar nebo None (vadný tvar se přeskočí).
    `default_ts` = čas obálky z Gate pro záznam bez `ts` (jinak by „teď" navždy vyhrálo LWW — Fable P3-1)."""
    if not isinstance(rec, dict):
        return None
    try:
        rating = int(rec.get("rating") or 0)
        tmdb_id = int(rec.get("tmdb_id") or 0)
    except (TypeError, ValueError):
        return None
    kind = str(rec.get("kind") or "movie").lower()
    if kind not in KINDS or tmdb_id <= 0 or not RATING_MIN <= rating <= RATING_MAX:
        return None
    try:
        ts = float(rec.get("ts") or 0) or float(default_ts or 0) or time.time()
    except (TypeError, ValueError):
        ts = float(default_ts or 0) or time.time()
    return {"tmdb_id": tmdb_id, "kind": kind, "rating": rating,
            "title": str(rec.get("title") or "")[:200], "ts": int(ts), "source": str(rec.get("source") or SOURCE)}


def stars(rating: Any) -> str:
    """`4` → „★★★★☆"; mimo rozsah → ""."""
    try:
        r = int(rating)
    except (TypeError, ValueError):
        return ""
    if not RATING_MIN <= r <= RATING_MAX:
        return ""
    return STAR_FULL * r + STAR_EMPTY * (RATING_MAX - r)


def should_ask(existing: Optional[Dict[str, Any]], skipped_n: int, *, watched_kind: str,
               is_guest: bool, enabled: bool = True) -> bool:
    """Ptát se po dokoukání? (čisté) Ne, když: vypnuto v nastavení, Host (nic se neukládá),
    už hodnoceno, 2× odloženo (D4), nebo díl proběhl bez diváka (`unattended`, 3.5.149)."""
    if not enabled or is_guest:
        return False
    if existing:
        return False
    if int(skipped_n or 0) >= SKIP_LIMIT:
        return False
    return str(watched_kind or "attended") == "attended"


def decorate_label(label: Any, kind: Any, tmdb_id: Any) -> str:
    """Předřadí popisku hvězdičky vlastního hodnocení. SSOT vzhledu napříč celým UI.

    Do 3.5.154 si tohle skládalo každé místo samo (výsledky hledání, doporučení), seriály
    hvězdičky neukazovaly vůbec a v Pokračovat, Historii ani Moje ČSFD nebyly.
    """
    text = str(label or "")
    rec = get(kind, tmdb_id)
    if not rec:
        return text
    return "[COLOR gold]{}[/COLOR] {}".format(stars(rec["rating"]), text)


def kodi_userrating(kind: Any, tmdb_id: Any) -> Optional[int]:
    """Naše 1–5★ na Kodi škálu 1–10 (`userrating` ve `setInfo`), None = nehodnoceno.

    Kodi `userrating` je nativní pole; skiny ho umí zobrazit samy a řadit podle něj.
    Hvězdičky v popisku jsou pojistka pro skiny, které ho ignorují.
    """
    rec = get(kind, tmdb_id)
    if not rec:
        return None
    try:
        return max(1, min(10, int(rec["rating"]) * 2))
    except (TypeError, ValueError):
        return None


def series_ask_threshold(first_season_episodes: Any) -> int:
    """Kolik dokoukaných dílů (u kterých divák BYL) stačí na dotaz u seriálu.

    Polovina první řady, oříznutá shora `SERIES_ASK_CAP` a zdola `SERIES_ASK_FLOOR`.
    Neznámý počet dílů (TMDb mlčí) → strop; radši se zeptat později než po pilotu.
    """
    try:
        n = int(first_season_episodes or 0)
    except (TypeError, ValueError):
        n = 0
    if n <= 0:
        return SERIES_ASK_CAP
    half = (n + 1) // 2  # nahoru: 3dílná řada → 2 díly
    return max(SERIES_ASK_FLOOR, min(SERIES_ASK_CAP, half))


def first_season_episodes(tv_detail: Any) -> Optional[int]:
    """Počet dílů PRVNÍ řady z TMDb detailu seriálu. None = nevíme.

    Sezóna 0 jsou speciály (vánoční díly, zákulisí) — ta se ignoruje, jinak by u seriálu
    se dvěma speciály vyšel práh na jeden díl.
    """
    for season in ((tv_detail or {}).get("seasons") or []):
        if not isinstance(season, dict):
            continue
        try:
            if int(season.get("season_number")) != 1:
                continue
            n = int(season.get("episode_count") or 0)
        except (TypeError, ValueError):
            continue
        return n if n > 0 else None
    return None


def total_episodes(tv_detail: Any) -> Optional[int]:
    """Počet dílů celého seriálu z TMDb detailu. None = nevíme."""
    try:
        n = int((tv_detail or {}).get("number_of_episodes") or 0)
    except (TypeError, ValueError):
        return None
    return n if n > 0 else None


def should_ask_series(existing: Optional[Dict[str, Any]], skipped_n: int, *,
                      attended_episodes: Any, first_season_episodes: Any,
                      series_finished: bool, asked: Any,
                      is_guest: bool, enabled: bool = True,
                      last_ask_age_s: Optional[float] = None) -> Optional[str]:
    """Která fáze dotazu se má u seriálu spustit — čistá funkce.

    Vrací `STAGE_FIRST_SEASON`, `STAGE_FINISHED`, nebo None (neptat se).
    Dvě fáze jsou rozhodnutí Richieho z 20.09.2026: názor po pilotu a názor po posledním
    dílu se běžně liší, takže se ptáme dvakrát za život seriálu — ne víc.

    POZOR: `attended_episodes` smí počítat JEN díly, u kterých divák opravdu byl. Kulisa
    (Futurama: 62 % dílů bez jediného doteku ovladače) by jinak práh překročila za noc.
    """
    if not enabled or is_guest:
        return None
    if int(skipped_n or 0) >= SKIP_LIMIT:
        return None
    if last_ask_age_s is not None and 0 <= float(last_ask_age_s) < SERIES_ASK_MIN_GAP_S:
        return None   # dnes už jeden dotaz na seriál byl; tenhle počká na příští díl

    done = set(asked or ())
    if series_finished and STAGE_FINISHED not in done:
        # Konec seriálu: ptáme se i tehdy, když už hodnocení z první řady existuje —
        # dialog ho nabídne ke změně.
        return STAGE_FINISHED
    if STAGE_FIRST_SEASON in done or existing:
        return None
    try:
        watched = int(attended_episodes or 0)
    except (TypeError, ValueError):
        return None
    if watched >= series_ask_threshold(first_season_episodes):
        return STAGE_FIRST_SEASON
    return None


# ─────────────────────────────────────────────────────────────────────────────
#  Soubor (osobní, per profil)
# ─────────────────────────────────────────────────────────────────────────────
def _path() -> str:
    import richmovie_paths as _rp
    return str(_rp.personal_path(FILE_NAME))


_CACHE: Optional[Dict[str, Any]] = None
_CACHE_AT = 0.0
_CACHE_PATH = ""


def invalidate_cache() -> None:
    """Zahodí přečtený soubor. Volá se po zápisu; přepnutí profilu řeší cesta v klíči cache."""
    global _CACHE, _CACHE_AT, _CACHE_PATH
    _CACHE, _CACHE_AT, _CACHE_PATH = None, 0.0, ""


def _load() -> Dict[str, Any]:
    """UI čtení: při chybě prázdno (zápisy jdou přes `_load_for_update`).

    Výsledek se krátce cachuje (`CACHE_TTL_S`). Cache je vázaná na CESTU souboru, takže
    přepnutí profilu za běhu služby ji zneplatní samo (jiný profil = jiná cesta).
    """
    global _CACHE, _CACHE_AT, _CACHE_PATH
    import time as _time
    path = _path()
    if (_CACHE is not None and _CACHE_PATH == path
            and (_time.monotonic() - _CACHE_AT) < CACHE_TTL_S):
        return _CACHE
    import richmovie_atomic as _atomic
    data, _state = _atomic.read_json(path, None, name="title_ratings", expected_type=dict)
    if not isinstance(data, dict):
        # Nečitelný soubor se NEcachuje — příští pokus musí zkusit číst znovu (R2).
        return {"items": {}, "skipped": {}, "asked": {}}
    data.setdefault("items", {})
    data.setdefault("skipped", {})
    data.setdefault("asked", {})
    _CACHE, _CACHE_AT, _CACHE_PATH = data, _time.monotonic(), path
    return data


def _load_for_update() -> Optional[Dict[str, Any]]:
    """Read-modify-write: UNREADABLE (I/O chyba) = nezapisovat (parita `richmovie_history._load_for_update`)."""
    import richmovie_atomic as _atomic
    data, state = _atomic.read_json(_path(), None, name="title_ratings", expected_type=dict)
    if state == _atomic.STATE_UNREADABLE:
        return None
    if not isinstance(data, dict):
        data = {}
    data.setdefault("items", {})
    data.setdefault("skipped", {})
    data.setdefault("asked", {})
    return data


def _save(data: Dict[str, Any]) -> bool:
    import richmovie_atomic as _atomic
    ok = _atomic.write_json(_path(), {"items": dict(data.get("items") or {}),
                                      "skipped": dict(data.get("skipped") or {}),
                                      # `asked` = fáze dotazů u seriálů (3.5.154). Bez tohohle
                                      # řádku by se pole při každém uložení ZTRATILO a divák
                                      # by dostal tentýž dotaz znovu.
                                      "asked": dict(data.get("asked") or {}),
                                      "last_series_ask_ts": float(data.get("last_series_ask_ts") or 0.0)},
                           indent=None)
    if ok:
        invalidate_cache()
        try:
            import richmovie_ui_common as _uc
            _uc.data_rev_bump("ratings")
        except Exception:
            pass
    return ok


def _lock():
    import richmovie_paths as _rp
    return _rp.personal_lock(FILE_NAME)


def get(kind: Any, tmdb_id: Any) -> Optional[Dict[str, Any]]:
    key = make_key(kind, tmdb_id)
    if not key:
        return None
    return parse_record((_load().get("items") or {}).get(key))


def all_ratings() -> List[Dict[str, Any]]:
    """Všechna hodnocení profilu, nejnovější první (výpis „Moje hodnocení")."""
    out = []
    for key, rec in (_load().get("items") or {}).items():
        parsed = parse_record(rec)
        if parsed and make_key(parsed["kind"], parsed["tmdb_id"]) == key:
            out.append(parsed)
    out.sort(key=lambda r: r["ts"], reverse=True)
    return out


def skipped_count(kind: Any, tmdb_id: Any) -> int:
    key = make_key(kind, tmdb_id)
    try:
        return int(((_load().get("skipped") or {}).get(key) or {}).get("n") or 0)
    except (TypeError, ValueError):
        return 0


def asked_stages(kind: Any, tmdb_id: Any) -> List[str]:
    """Fáze dotazu, které u tohoto titulu už proběhly (`first_season`, `finished`)."""
    key = make_key(kind, tmdb_id)
    if not key:
        return []
    val = (_load().get("asked") or {}).get(key)
    return [str(x) for x in val] if isinstance(val, list) else []


def last_series_ask_age_s() -> Optional[float]:
    """Kolik sekund uplynulo od posledního dotazu na seriál v tomto profilu. None = ještě nikdy.

    Hodiny zařízení se mohly vrátit (záporné stáří) → bere se jako „nevím" a dotaz se nebrzdí.
    """
    import time as _time_l
    try:
        ts = float(_load().get("last_series_ask_ts") or 0.0)
    except (TypeError, ValueError):
        return None
    if ts <= 0:
        return None
    age = _time_l.time() - ts
    return age if age >= 0 else None


def note_asked(kind: Any, tmdb_id: Any, stage: str) -> bool:
    """Zapíše, že se na titul v dané fázi už ptalo. Idempotentní; True = uloženo.

    Zapisuje se PŘED otevřením dialogu: když divák Kodi zavře nebo dialog spadne, druhý
    dotaz na totéž je horší než žádný (pravidlo „neotravovat" z profilu uživatele).
    """
    key = make_key(kind, tmdb_id)
    if not key or str(stage) not in (STAGE_FIRST_SEASON, STAGE_FINISHED):
        return False
    with _lock():
        data = _load_for_update()
        if data is None:
            return False
        asked = data.setdefault("asked", {})
        cur = asked.get(key)
        cur = [str(x) for x in cur] if isinstance(cur, list) else []
        if str(stage) in cur:
            return True
        cur.append(str(stage))
        asked[key] = cur
        import time as _time_a
        data["last_series_ask_ts"] = _time_a.time()
        return _save(data)


def set_rating(kind: Any, tmdb_id: Any, rating: Any, *, title: str = "") -> bool:
    """Uloží hodnocení (přepíše starší) a pošle ho do fronty pro Gate. True = na disku."""
    key = make_key(kind, tmdb_id)
    rec = parse_record({"tmdb_id": tmdb_id, "kind": kind, "rating": rating, "title": title, "ts": time.time()})
    if not key or rec is None:
        return False
    with _lock():
        data = _load_for_update()
        if data is None:
            _log("RATING_WRITE_SKIPPED key=%s (soubor nečitelný)" % key, 2)
            return False
        data["items"][key] = rec
        data["skipped"].pop(key, None)
        if not _save(data):
            return False
    _log("RATING_SET key=%s rating=%d title=%s" % (key, rec["rating"], rec["title"][:60]), 1,
         context={"key": key, "rating": rec["rating"]})
    _note_change(key, rec)
    return True


def clear_rating(kind: Any, tmdb_id: Any) -> bool:
    """Smaže hodnocení (tombstone pro ostatní zařízení)."""
    key = make_key(kind, tmdb_id)
    if not key:
        return False
    with _lock():
        data = _load_for_update()
        if data is None or key not in data["items"]:
            return False
        data["items"].pop(key, None)
        if not _save(data):
            return False
    _note_change(key, None, deleted=True)
    return True


def note_skipped(kind: Any, tmdb_id: Any) -> int:
    """„Teď ne" / timeout: zvýší počítadlo titulu (lokální, nesynchronizuje se). Vrací nový počet."""
    key = make_key(kind, tmdb_id)
    if not key:
        return 0
    with _lock():
        data = _load_for_update()
        if data is None:
            return 0
        entry = dict((data["skipped"] or {}).get(key) or {})
        n = int(entry.get("n") or 0) + 1
        data["skipped"][key] = {"n": n, "ts": int(time.time())}
        if not _save(data):
            return int(entry.get("n") or 0)   # zápis selhal → platí uložený stav (cross-check QA2)
    return n


def _note_change(key: str, rec: Optional[Dict[str, Any]], *, deleted: bool = False) -> None:
    """Fronta pro Gate (SSOT `richmovie_profile_items.note_change`); best-effort."""
    try:
        import richmovie_profile_items as _pi
        payload = {"record": rec} if rec is not None else None
        _pi.note_change(COLLECTION, key, payload, deleted=deleted, ts=(rec or {}).get("ts"))
    except Exception as exc:
        _log("ratings note_change failed: %r" % (exc,), 2)


def apply_remote(items: List[Dict[str, Any]]) -> int:
    """Sloučení z Gate (volá `richmovie_profile_items._apply_ratings` pod `personal_lock` a
    `applying_remote` — žádné echo do fronty). LWW per klíč podle `client_updated_at`; tombstone maže.
    Vrací počet změn; při nečitelném souboru 0 bez zápisu (R2 — kurzor drží `failure_scope`? ne:
    UNREADABLE se hlásí výjimkou OSError, aby kurzor stál)."""
    import richmovie_sync_queue as _sq
    data = _load_for_update()
    if data is None:
        raise OSError("title_ratings.json unreadable")
    changed = 0
    items_map = data["items"]
    for it in items or []:
        key = str(it.get("item_key") or "")
        if not key:
            continue
        remote_ts = _sq.to_epoch(it.get("client_updated_at"))
        local = parse_record(items_map.get(key))
        if local and float(local["ts"]) > float(remote_ts or 0):
            continue   # lokální novější (je ve frontě / už na Gate)
        if it.get("deleted"):
            if key in items_map:
                items_map.pop(key, None)
                changed += 1
            continue
        rec = parse_record(((it.get("payload") or {}).get("record")), default_ts=remote_ts)
        if rec is None or make_key(rec["kind"], rec["tmdb_id"]) != key:
            continue
        if local == rec:
            continue
        items_map[key] = rec
        data["skipped"].pop(key, None)
        changed += 1
    if changed:
        _save(data)
    return changed
