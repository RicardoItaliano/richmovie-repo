# -*- coding: utf-8 -*-
"""richmovie_onboarding.py — SSOT první sekvence po startu (3.5.146)

Proč to existuje (incident Róbert/Xiaomi 09.09.2026 22:09)
--------------------------------------------------------
Kodi spouští kořenové menu doplňku při startu DVAKRÁT (dva procesy pluginu, rozestup
2–5 s — viz CLAUDE.md „/auth se volá 2× při každém otevření root menu"). Do 3.5.145 jel
každý z nich celou uvítací sekvenci sám: první visel v přihlášení k Webshare, druhý mezitím
otevřel chooser „Kdo se dívá?", pak přes něj vyskočil uvítací pozdrav (2 stránky) a dotaz na
FastShare. Uživatel viděl dialogy v nesmyslném pořadí a dvakrát.

Dvě pravidla, která tenhle modul drží
-------------------------------------
1. **Pořadí je jedno a neměnné** (`STEPS`): přihlášení k Webshare → uvítání → FastShare →
   zvuk a titulky (Φ3) → **profil „Kdo se dívá?" jako POSLEDNÍ** (Richie 09.09.2026: „výběr profilů se má zobrazit,
   až je vše vyplněno"). Každý krok je idempotentní (marker/flag), takže opakovaný průchod nic
   nezobrazí znovu.
2. **Dialogy kreslí jen JEDEN proces.** Sekvence běží pod meziprocesovým claimem
   (`richmovie_guard`, Window props + TTL — modulový Lock nestačí, každá invokace pluginu je
   nový interpret). Druhý souběžný běh **počká**, až držitel skončí (uživatel je stejně
   v modálním dialogu), a pak projde sekvenci bez dialogů — všechny markery už jsou zapsané.
   Když držitel zemře, claim vyprší (TTL) a čekající proces sekvenci převezme interaktivně,
   aby uživatel nikdy neskončil ve slepé uličce. TTL drží při životě keepalive vlákno
   (dialog `yesno` blokuje, takže `renew` mezi kroky by nestačil).

Použití (plugin `_root`)::

    seq = richmovie_onboarding.begin()
    try:
        _ensure_login(cli, interactive=seq.interactive)
        ...
        if seq.interactive:
            if seq.step("welcome"):   maybe_show_welcome(...)
            if seq.step("fastshare"): _fs_onboarding()
            if seq.step("profile"):   ensure_profile_at_start()
    finally:
        seq.end()

`end()` je idempotentní a MUSÍ být ve `finally` — bez něj by keepalive vlákno po výjimce
drželo claim a každý další start by čekal (pojistka `MAX_HOLD_S` to jen ohraničí).
"""

from __future__ import annotations

import threading
import time
from typing import Optional, Tuple

import xbmc

import richmovie_guard as _guard
import richmovie_winprops as _winprops

try:
    from richmovie_logging import make_legacy_logger as _ob_make_logger
    _log = _ob_make_logger("richmovie.onboarding", "RichMovie/Onboarding")
except Exception:  # pragma: no cover — fallback mimo pipeline
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log("[RichMovie/Onboarding] " + str(msg), level)
        except Exception:
            pass

GUARD_KEY = "onboarding_sequence"
GUARD_TTL_S = 120.0        # claim bez keepalive = sirotek po 2 minutách (držitel spadl)
KEEPALIVE_S = 30.0         # keepalive vlákno prodlužuje TTL i během blokujícího dialogu
# Φ3 (29.09.2026): strop ČEKÁNÍ druhého procesu z dat (60 dní user_logs, `Temp/ux_latency_20260929/scripts/
# FABLE/onboarding_wait.py`): držitel dokončil sekvenci p50 3,1 s, p90 27,2 s (n=21); spadlý držitel se
# převzal po 47–56 s. Po stropu čekající běh jen vykreslí menu bez dialogů — cena je jedno vykreslení
# navíc, ne slepá ulička. Dřív 900 s: 2× 15 min holého kolečka (A07 F1).
WAIT_MAX_S = 30.0
# Strop DRŽENÍ (keepalive držitele) zůstává 15 min: legitimní dialog (přihlášení, uvítání) trval až 273 s
# a převzetí sekvence uprostřed dialogu by znamenalo dva choosery. Odděleno od `WAIT_MAX_S`.
MAX_HOLD_S = 900.0
WAIT_TEXT = "Dokončuji uvítání…"
WAIT_TICK_S = 0.5
PROP_COMPLETED = "richmovie.onboarding.completed"   # Window prop: sekvence v tomto běhu Kodi dokončena

# Jediné pravdivé pořadí kroků. Profil je POSLEDNÍ — chooser „Kdo se dívá?" se ukáže,
# až je všechno ostatní vyplněné.
# Φ3 (29.09.2026): průvodce zvuk/titulky („localization“) patří do sekvence — do 3.5.161 běžel z prologu
# KAŽDÉ akce, před přihlášením a mimo claim, s `xbmc.sleep` smyčkou až 30 s (audit A07 F12).
# Noc 03.11.2026 (4.0.6): „os_filter“ = jednorázové vysvětlení systémového filtru obsahu (`richmovie_device_env`),
# „autostart“ = jednou za život zařízení dotaz „otevírat RichMovie po zapnutí Kodi?“ (`richmovie_autostart`).
STEPS = ("login", "welcome", "fastshare", "localization", "os_filter", "autostart", "profile")


class Sequence(object):
    """Držení (nebo vzdání se) uvítací sekvence pro jednu invokaci pluginu."""

    def __init__(self, token: Optional[str], interactive: bool, *, waited_s: float = 0.0,
                 aborted: bool = False) -> None:
        self.token = token
        self.interactive = bool(interactive)
        self.waited_s = float(waited_s)
        self.aborted = bool(aborted)
        self._stop = threading.Event()
        self._keepalive: Optional[threading.Thread] = None
        self._ended = False
        # S24 (cross-check Codex #5): generace znovuotevření na začátku kroku profilu — jiná při `complete` = během kroku
        # proběhl `reopen` a krok viděl starý stav (počítadlo, ne čas: monotonic má na Windows rozlišení ~15 ms)
        self._profile_step_gen = reopened_gen()
        if self.token:
            self._start_keepalive()

    # ── držitel ──────────────────────────────────────────────────────────────
    def _start_keepalive(self) -> None:
        def _loop() -> None:
            mon = xbmc.Monitor()
            started = time.monotonic()
            while True:
                # tikat po 1 s: vypnutí Kodi (5s okno) nesmí čekat na 30s `wait`
                for _ in range(int(KEEPALIVE_S)):
                    if self._stop.wait(1.0):
                        return
                    if mon.abortRequested():
                        return
                if (time.monotonic() - started) >= MAX_HOLD_S:
                    # Pojistka proti věčnému držení (proces bez `end()`): po stropu claim
                    # vyprší a další start sekvenci převezme.
                    _log("keepalive: strop %.0f s → přestávám prodlužovat" % MAX_HOLD_S, xbmc.LOGWARNING)
                    return
                try:
                    if not _guard.renew(GUARD_KEY, self.token, GUARD_TTL_S):
                        _log("keepalive: claim převzal jiný proces → končím prodlužování",
                             xbmc.LOGWARNING)
                        return
                except Exception as exc:
                    _log("keepalive renew selhal: %r" % (exc,), xbmc.LOGWARNING)
                    return

        # daemon=False (memory feedback_daemon_threads_kodi): vlákno se ukončí přes `_stop`
        # v `end()`; nikdy nedělá HTTP, jen Window props.
        self._keepalive = threading.Thread(target=_loop, name="rm-onboarding-keepalive", daemon=False)
        self._keepalive.start()

    def step(self, name: str) -> bool:
        """Zaznamená krok a prodlouží claim (držitel). Vrací True = tenhle proces smí krok
        kreslit (drží claim); False = ne (čekající proces, nebo claim mezitím převzal jiný).

        Značku „sekvence v tomto běhu Kodi dokončena" (Window prop, zaniká s restartem Kodi)
        zapisuje `complete()` po posledním dialogu: čekající proces pak sekvenci NEpřebírá
        (cross-check Flash F10.2 09.09.2026 — bez značky by po uvolnění claimu vždy převzal
        a větev „bez dialogů" by nikdy nenastala). Držitel, který spadl dřív, značku nezapíše
        → další běh sekvenci převezme interaktivně a dokončí, co chybí.
        """
        if name not in STEPS:
            raise ValueError("onboarding.step: neznámý krok %r (povolené: %s)" % (name, ", ".join(STEPS)))
        if self.token:
            try:
                still_mine = _guard.renew(GUARD_KEY, self.token, GUARD_TTL_S)
            except Exception as exc:
                _log("renew u kroku %s selhal: %r" % (name, exc), xbmc.LOGWARNING)
                still_mine = True
            if not still_mine:
                # Claim mezitím převzal jiný proces (držitel „zmizel" déle než TTL — uspání
                # zařízení, zamrzlý interpret). Dva držitelé = dva choosery; proto se tenhle
                # proces sám degraduje na „bez dialogů" (Pro P3 09.09.2026). Cizí claim se
                # NEuvolňuje — `release` stejně pustí jen vlastní token.
                _log("krok %s: claim převzal jiný proces → dál bez dialogů" % name, xbmc.LOGWARNING)
                self._stop.set()
                self.token = None
                self.interactive = False
                return False
        if name == "profile":
            self._profile_step_gen = reopened_gen()
        _log("krok %s (%s)" % (name, "držitel" if self.token else "bez dialogů"), xbmc.LOGDEBUG)
        return self.interactive

    def complete(self) -> None:
        """Držitel dokončil POSLEDNÍ krok (dialog už proběhl) → značka „v tomto běhu Kodi hotovo".
        Volá se až PO dialogu, ne před ním (cross-check F17.4): kdyby Kodi/UI spadlo uprostřed
        chooseru, druhý běh by jinak sekvenci považoval za hotovou.
        S24 (cross-check Codex #5): když sekvenci někdo znovu otevřel (`reopen`) PO začátku kroku profilu (účet přešel
        na více profilů, `/auth` na pozadí doběhl uprostřed kroku), krok viděl starý stav → značka se NEzapíše
        a výběr ukáže nejbližší stavba hlavního menu (jinak by vyskočil až po restartu Kodi)."""
        if not self.token:
            return
        if reopened_gen() != self._profile_step_gen:
            _log("sekvence znovu otevřena během kroku profilu → zůstává otevřená (výběr při dalším menu)", xbmc.LOGINFO)
            return
        _winprops.set_prop(PROP_COMPLETED, "1")

    def end(self) -> None:
        """Uvolní claim a zastaví keepalive. Idempotentní."""
        if self._ended:
            return
        self._ended = True
        self._stop.set()
        if self._keepalive is not None:
            try:
                self._keepalive.join(timeout=1.0)
            except Exception:
                pass
        if self.token:
            try:
                _guard.release(GUARD_KEY, self.token)
            except Exception as exc:
                _log("release selhal: %r" % (exc,), xbmc.LOGWARNING)


def begin(*, wait_max_s: float = WAIT_MAX_S, monitor: Optional[object] = None) -> Sequence:
    """Převezme uvítací sekvenci, nebo počká, až ji dokončí jiný proces.

    Vrací `Sequence`: `interactive=True` = tenhle proces smí kreslit dialogy (držitel —
    buď první, nebo převzal po vypršení claimu). `interactive=False` = držitel běžel
    déle než `wait_max_s` nebo Kodi končí (`aborted`) → projít bez dialogů.
    """
    if completed_in_this_run():
        # V tomto běhu Kodi už sekvence doběhla (druhý souběžný root, nebo návrat do menu
        # později) → žádné dialogy, žádný claim.
        return Sequence(None, False)

    token = _guard.claim(GUARD_KEY, GUARD_TTL_S)
    if token:
        return Sequence(token, True)

    mon = monitor or xbmc.Monitor()
    started = time.monotonic()
    _log("uvítací sekvenci drží jiný proces → čekám (max %.0f s)" % wait_max_s, xbmc.LOGINFO)
    # Φ3: čekání s textem (nemodální průběh až po 100 ms — běžné čekání 3 s tak nic neblikne)
    import richmovie_feedback as _fb
    with _fb.working(WAIT_TEXT):
        while _guard.is_claimed(GUARD_KEY):
            if (time.monotonic() - started) >= wait_max_s:
                _log("držitel neskončil do %.0f s → pokračuji bez dialogů" % wait_max_s, xbmc.LOGWARNING)
                return Sequence(None, False, waited_s=time.monotonic() - started)
            if mon.waitForAbort(WAIT_TICK_S):
                return Sequence(None, False, waited_s=time.monotonic() - started, aborted=True)

    waited = time.monotonic() - started
    if completed_in_this_run():
        # Držitel sekvenci dokončil (značka posledního kroku) → projít bez dialogů.
        _log("čekání skončilo po %.1f s → sekvence dokončena jiným procesem, bez dialogů" % waited, xbmc.LOGINFO)
        return Sequence(None, False, waited_s=waited)
    # Držitel spadl (claim vypršel bez značky dokončení): převzít. Markery hotových kroků jsou
    # zapsané, takže dialogy se ukážou jen tam, kde držitel nedoběhl — správně.
    token = _guard.claim(GUARD_KEY, GUARD_TTL_S)
    _log("čekání skončilo po %.1f s bez značky dokončení → %s" % (waited, "přebírám" if token else "bez dialogů"),
         xbmc.LOGWARNING)
    return Sequence(token, token is not None, waited_s=waited)


def completed_in_this_run() -> bool:
    """Sekvenci v tomto běhu Kodi už někdo dokončil (Window prop zaniká s restartem Kodi)."""
    return _winprops.get_prop(PROP_COMPLETED, "") == "1"


PROP_REOPEN_GEN = "richmovie.onboarding.reopen_gen"   # počítadlo `reopen` v tomto běhu Kodi (S24)


def reopened_gen() -> int:
    """Kolikrát byla sekvence v tomto běhu Kodi znovu otevřena (Window prop zaniká s restartem); 0 = nikdy."""
    try:
        return int(_winprops.get_prop(PROP_REOPEN_GEN, "") or 0)
    except (TypeError, ValueError):
        return 0


def reopen(reason: str) -> None:
    """Znovu otevřít sekvenci pro tento běh Kodi (S24, 15.10.2026): další stavba hlavního menu ji projde znovu pod
    claimem (jeden proces kreslí, druhý čeká). Hotové kroky jsou idempotentní (markery) a nic nezobrazí; ukáže se jen
    to, co je potřeba znovu — dnes výběr profilu po přepnutí účtu na více profilů nebo po smazání aktivního profilu
    (`richmovie_profile.request_chooser`). Generace se zvýší VŽDY (`PROP_REOPEN_GEN`): běžící krok profilu, který
    viděl starý stav, pak sekvenci za hotovou neoznačí (`Sequence.complete`, Codex #5). Dva souběžné `reopen` můžou
    zapsat stejné číslo — i tak se liší od generace běžícího kroku, takže se nic neztratí. Nikdy nevyhazuje."""
    try:
        _winprops.set_prop(PROP_REOPEN_GEN, str(reopened_gen() + 1))
        if completed_in_this_run():
            _winprops.clear_prop(PROP_COMPLETED)
        _log("sekvence znovu otevřena (%s)" % reason, xbmc.LOGINFO)
    except Exception as exc:
        _log("reopen(%s) selhal: %r" % (reason, exc), xbmc.LOGWARNING)


# ── Vedlejší práce root menu jen jednou (3.5.147, Φ3 / D4) ───────────────────────────────
# Kodi spouští root při startu 2× (a uživatel se do něj vrací): hlášení stavu, flush pádů,
# plán instalátoru kolekcí a sync katalogu NASu nemají smysl dvakrát během pár sekund.
# Krátký claim bez release = „nejvýš jednou za `SIDE_WORK_TTL_S`" napříč procesy.
SIDE_WORK_KEY = "root_side_work"
SIDE_WORK_TTL_S = 30.0


def claim_side_work(ttl_s: float = SIDE_WORK_TTL_S) -> bool:
    """True = tenhle běh root menu má udělat vedlejší síťovou práci; False = udělal ji
    (nebo právě dělá) jiný běh v posledních `ttl_s` sekundách."""
    try:
        return _guard.claim(SIDE_WORK_KEY, ttl_s) is not None
    except Exception as exc:
        _log("claim_side_work selhal → práce se udělá (%r)" % (exc,), xbmc.LOGWARNING)
        return True


# ── Životní cyklus hlavního menu (Φ3, 29.09.2026) ───────────────────────────────────────
# Fronta obnov výpisu (`richmovie_playback_dispatch.flush_refresh_queue`) smí hlavní menu překreslit jen když se právě
# NEstaví: `Container.Refresh` uprostřed rootu spustil druhý root, který čekal na claim prvního (s otevřeným
# „Kdo se dívá?“) — 2× 15 min, 7 z 12 nedokončených rootů za 60 dní (audit A07 F1). Že menu mezitím samo vykreslilo
# čerstvá data, pozná fronta ze značky stavby výpisu (`note_listing_build`, S18 — dřív vlastní značka „root ukázán“).
PROP_ROOT_BUILDING = "richmovie.root.building"      # "<token>|<monotonic začátku>" během stavění
#: (monotonic je v Kodi sdílený všemi interprety — jeden proces; stejný předpoklad jako `richmovie_guard`)
# Pojistka proti značce po nativním pádu interpretu: stejný význam jako TTL claimu sekvence
# („proces rootu žije“); dialogy během stavění stejně blokuje `modal` v bráně obnovy.
ROOT_BUILDING_MAX_S = GUARD_TTL_S


def note_root_begin() -> Tuple[str, float]:
    """Začátek akce root (plugin `main`). Vrací (token, time.time() začátku) pro `note_root_end`."""
    import uuid
    token, began_wall = uuid.uuid4().hex[:12], time.time()
    # přesná hodnota (repr), ne zaokrouhlená: zaokrouhlení nahoru dávalo `now - began < 0`
    _winprops.set_prop(PROP_ROOT_BUILDING, "%s|%r" % (token, time.monotonic()))
    return token, began_wall


def note_root_end(handle: Tuple[str, float]) -> None:
    """Konec akce root. Značku stavění smaže jen její vlastník (dva souběžné rooty: pozdější drží
    značku, dokud sám neskončí)."""
    token, _began_wall = handle
    parts = _winprops.get_prop(PROP_ROOT_BUILDING, "").split("|")
    if len(parts) == 2 and parts[0] == token:
        _winprops.clear_prop(PROP_ROOT_BUILDING)


def root_building(now_monotonic: Optional[float] = None) -> bool:
    """Staví se právě hlavní menu? (značka ne starší než `ROOT_BUILDING_MAX_S`)"""
    parts = _winprops.get_prop(PROP_ROOT_BUILDING, "").split("|")
    if len(parts) != 2:
        return False
    try:
        began = float(parts[1])
    except ValueError:
        return False
    now = time.monotonic() if now_monotonic is None else float(now_monotonic)
    return 0.0 <= now - began < ROOT_BUILDING_MAX_S


__all__ = ["begin", "completed_in_this_run", "reopen", "reopened_gen", "PROP_REOPEN_GEN", "Sequence", "STEPS", "GUARD_KEY", "GUARD_TTL_S", "KEEPALIVE_S",
           "WAIT_MAX_S", "MAX_HOLD_S", "WAIT_TEXT", "PROP_COMPLETED", "note_root_begin", "note_root_end", "root_building",
           "ROOT_BUILDING_MAX_S"]
