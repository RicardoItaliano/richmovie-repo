# -*- coding: utf-8 -*-
"""
RichMovie — SSOT přístup k `Window(10000)` properties (meziprocesová nástěnka).

PROČ EXISTUJE (3.5.118, 21.08.2026)
-----------------------------------
Kodi spouští každou invokaci pluginu jako NOVÝ interpret (viz `plugin.py` sekce
USER LOGS PIPELINE). Jediný stav, který přežije mezi invokacemi a mezi pluginem
a službami (`service_nextup`, `service_warm`), jsou properties Home okna
`Window(10000)`. Do 3.5.117 měl každý modul, který je potřeboval, vlastní kopii
trojice `_win / _get_prop / _set_prop` (`richmovie_netstate`, `richmovie_diag`,
`richmovie_mi2` inflight lock). Tři kopie téhož = tři místa, kde se může rozejít
chování mimo Kodi (harness) nebo ošetření výjimek.

Tenhle modul je jediná implementace. `richmovie_netstate` a nový
`richmovie_identity_state` ji používají; ostatní moduly migrují opportunisticky
(stejná politika jako `richmovie_settings`).

CHOVÁNÍ MIMO KODI
-----------------
Když `xbmcgui` chybí nebo `Window()` selže (offline harness), padá se na procesní
slovník `_MEMORY`. V produkci se nepoužije — tam je autoritou `Window(10000)`.
Harness ho mezi scénáři čistí přes `reset()`.

Window properties NEJSOU atomické. Modul nedává žádnou meziprocesovou atomicitu —
volající, kteří ji potřebují (claim/release), ji řeší na své úrovni
(`richmovie_guard`: TTL + token, dokumentovaná tolerance k závodu).

Python 3.8 (Kodi runtime) — typy jen v komentářích.
"""
from __future__ import annotations


from typing import Dict, Optional

try:
    import xbmcgui  # type: ignore
except Exception:  # pragma: no cover — běh mimo Kodi (harness)
    xbmcgui = None  # type: ignore

_HOME_WINDOW_ID = 10000

# Fallback úložiště mimo Kodi. Definováno u modulového stavu, ne pod funkcemi.
_MEMORY = {}  # type: Dict[str, str]


def window():
    # type: () -> Optional[object]
    """Vrátí Home window (10000), nebo None mimo Kodi / při selhání."""
    try:
        if xbmcgui is None:
            return None
        return xbmcgui.Window(_HOME_WINDOW_ID)
    except Exception:
        return None


def get_prop(name, default=""):
    # type: (str, str) -> str
    """Přečte property. Nikdy nevyhodí — mimo Kodi vrací hodnotu z `_MEMORY`
    nebo `default`. Prázdný řetězec se považuje za „nenastaveno" (Kodi vrací ""
    pro neexistující property, takže rozlišit to ani nejde)."""
    win = window()
    if win is None:
        return _MEMORY.get(name, default)
    try:
        value = win.getProperty(name)
        return value if value else default
    except Exception:
        return default


def set_prop(name, value):
    # type: (str, str) -> None
    """Zapíše property (hodnota se ukládá jako str). Mimo Kodi do `_MEMORY`."""
    text = "" if value is None else str(value)
    win = window()
    if win is None:
        _MEMORY[name] = text
        return
    try:
        win.setProperty(name, text)
    except Exception:
        pass


def clear_prop(name):
    # type: (str) -> None
    """Smaže property. Preferuje `clearProperty`; když není k dispozici
    (starší stub), zapíše prázdný řetězec — pro `get_prop` je to totéž."""
    win = window()
    if win is None:
        _MEMORY.pop(name, None)
        return
    try:
        win.clearProperty(name)
    except Exception:
        try:
            win.setProperty(name, "")
        except Exception:
            pass


def reset_memory():
    # type: () -> None
    """Vyčistí procesní fallback. Jen pro harness (mezi scénáři)."""
    _MEMORY.clear()
