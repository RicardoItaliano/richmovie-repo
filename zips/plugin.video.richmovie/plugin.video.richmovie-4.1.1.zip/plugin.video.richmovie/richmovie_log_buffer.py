# -*- coding: utf-8 -*-
"""SQLite WAL log buffer pro RichMovie addon.

Per-user log events queue + persist + drainer source. Vyresava architektonicky
problem ze logy musi prezit force-kill (Kodi 5s shutdown timeout, async-abort
pres PyThreadState_SetAsyncExc).

Architektura (per Agent A + Agent B research consolidation):
- SQLite WAL mode + synchronous=FULL
- Multi-writer safe pres BEGIN IMMEDIATE + busy_timeout=5000
- Plugin procesy (short-lived) zapisuji direct via krátký connection
- Service.py drainer (persistent) cte unsent rows + uploaduje + marks sent
- 50k row / 10 MB hard cap, drainer pruner stareje sent rows

Plan: RichMovie-nas/Handoff/session_2026-04-27_user_logs_audit.md (Phase 3)
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Iterator

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_SCHEMA_VERSION = 1
_DEFAULT_BUFFER_FILENAME = "log_buffer.db"
_DEFAULT_MAX_ROWS = 50_000           # hard cap, drainer prunes nad ramec
_DEFAULT_MAX_BYTES = 10 * 1024 * 1024  # 10 MB hard cap
_BUSY_TIMEOUT_MS = 5000

# Level mapping (matches Python logging + server CHECK constraint)
LEVEL_NAMES = {
    10: "DEBUG",
    20: "INFO",
    30: "WARNING",
    40: "ERROR",
    50: "CRITICAL",
}


# ---------------------------------------------------------------------------
# Schema (idempotent CREATE IF NOT EXISTS)
# ---------------------------------------------------------------------------
_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS log_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_unix         REAL NOT NULL,
    level           TEXT NOT NULL,
    source          TEXT NOT NULL,
    message         TEXT NOT NULL,
    context_json    TEXT,
    addon_version   TEXT,
    session_id      TEXT NOT NULL,
    client_event_id TEXT NOT NULL UNIQUE,
    sent            INTEGER NOT NULL DEFAULT 0,
    sent_ts_unix    REAL,
    retry_count     INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_unsent
    ON log_events(sent, ts_unix)
    WHERE sent = 0;

CREATE INDEX IF NOT EXISTS idx_sent_old
    ON log_events(sent, ts_unix)
    WHERE sent = 1;

CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY
);
"""

# PRAGMAs aplikovane na kazde nove pripojeni (per-connection settings v SQLite)
_PRAGMAS = (
    "PRAGMA journal_mode=WAL",
    "PRAGMA synchronous=FULL",       # max durability, accepts ~10-30% write cost
    f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}",
    "PRAGMA temp_store=MEMORY",
    "PRAGMA foreign_keys=ON",
)


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------
def _open_connection(db_path: Path) -> sqlite3.Connection:
    """Otevri novy SQLite connection s Pragma settings + schema init.

    Volajici je odpovedny za .close(). Multi-writer safe pres busy_timeout +
    BEGIN IMMEDIATE pri zapisu (viz LogBuffer.insert).
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(
        str(db_path),
        timeout=_BUSY_TIMEOUT_MS / 1000,
        isolation_level=None,        # autocommit; explicit BEGIN IMMEDIATE for writes
        check_same_thread=False,     # we manage thread safety via Lock per connection
    )
    for pragma in _PRAGMAS:
        conn.execute(pragma)
    conn.executescript(_SCHEMA_SQL)
    # Persist schema version for future migration check
    conn.execute(
        "INSERT OR IGNORE INTO schema_version (version) VALUES (?)",
        (_SCHEMA_VERSION,),
    )
    return conn


# ---------------------------------------------------------------------------
# LogBuffer — main API (used by RichLogHandler in richmovie_logging.py)
# ---------------------------------------------------------------------------
class LogBuffer:
    """Per-process SQLite buffer abstraction.

    Plugin process: krátkozivá instance, otevre + insert + close per-call.
      (or one persistent instance per process if many calls expected)
    Service process: jedna persistent instance, drainer cte/marks/prunes.

    Thread-safe: vsechny operace pres self._lock. SQLite WAL handles
    multi-process concurrency via filesystem locks (BEGIN IMMEDIATE +
    busy_timeout).
    """

    def __init__(self, db_path: Path | str) -> None:
        self._db_path = Path(db_path)
        self._lock = threading.RLock()
        self._conn: sqlite3.Connection | None = None

    # ---- connection lifecycle ----

    def _get_conn(self) -> sqlite3.Connection:
        with self._lock:
            if self._conn is None:
                self._conn = _open_connection(self._db_path)
            return self._conn

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                finally:
                    self._conn = None

    def __enter__(self) -> "LogBuffer":
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()

    # ---- write path ----

    def insert(
        self,
        *,
        level: str,
        source: str,
        message: str,
        context: dict[str, Any] | None = None,
        addon_version: str = "",
        session_id: str = "",
        client_event_id: str | None = None,
        ts_unix: float | None = None,
    ) -> int:
        """Insert one log event. Returns rowid.

        Idempotent na client_event_id (UNIQUE constraint). Pokud klient retry
        se stejnym ID, second insert returns existing rowid (nehodi exception).
        """
        if level not in ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"):
            raise ValueError(f"invalid level: {level!r}")
        ts = ts_unix if ts_unix is not None else time.time()
        ceid = client_event_id or str(uuid.uuid4())
        ctx_json = json.dumps(context, ensure_ascii=False, default=str) if context else None

        conn = self._get_conn()
        with self._lock:
            try:
                # BEGIN IMMEDIATE acquires write lock immediately (vs DEFERRED which
                # upgrades on first write). Multi-process safe pres busy_timeout.
                conn.execute("BEGIN IMMEDIATE")
                cur = conn.execute(
                    """INSERT OR IGNORE INTO log_events
                           (ts_unix, level, source, message, context_json,
                            addon_version, session_id, client_event_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (ts, level, source, message[:4000], ctx_json,
                     addon_version[:50], session_id[:64], ceid[:64]),
                )
                conn.execute("COMMIT")
                return cur.lastrowid or 0
            except Exception:
                try:
                    conn.execute("ROLLBACK")
                except Exception:
                    pass
                raise

    # ---- read path (drainer uses these) ----

    def fetch_unsent(self, limit: int = 100) -> list[dict[str, Any]]:
        """Fetch oldest unsent rows. Drainer batch source."""
        conn = self._get_conn()
        with self._lock:
            cur = conn.execute(
                """SELECT id, ts_unix, level, source, message, context_json,
                          addon_version, session_id, client_event_id
                   FROM log_events
                   WHERE sent = 0
                   ORDER BY ts_unix ASC
                   LIMIT ?""",
                (limit,),
            )
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]

    def mark_sent(self, ids: list[int]) -> int:
        """Marks rows as sent. Atomicke per id-batch."""
        if not ids:
            return 0
        conn = self._get_conn()
        with self._lock:
            placeholders = ",".join("?" * len(ids))
            now = time.time()
            try:
                conn.execute("BEGIN IMMEDIATE")
                cur = conn.execute(
                    f"""UPDATE log_events
                        SET sent = 1, sent_ts_unix = ?
                        WHERE id IN ({placeholders})""",
                    (now, *ids),
                )
                conn.execute("COMMIT")
                return cur.rowcount
            except Exception:
                try:
                    conn.execute("ROLLBACK")
                except Exception:
                    pass
                raise

    def increment_retry(self, ids: list[int]) -> None:
        """Bump retry_count po neuspesnem upload pokusu (pro debug + cap)."""
        if not ids:
            return
        conn = self._get_conn()
        with self._lock:
            placeholders = ",".join("?" * len(ids))
            try:
                conn.execute("BEGIN IMMEDIATE")
                conn.execute(
                    f"""UPDATE log_events
                        SET retry_count = retry_count + 1
                        WHERE id IN ({placeholders})""",
                    ids,
                )
                conn.execute("COMMIT")
            except Exception:
                try:
                    conn.execute("ROLLBACK")
                except Exception:
                    pass

    # ---- maintenance ----

    def prune(
        self,
        max_rows: int = _DEFAULT_MAX_ROWS,
        max_bytes: int = _DEFAULT_MAX_BYTES,
        sent_retention_seconds: float = 24 * 3600,
    ) -> int:
        """Drainer volá nightly. Smaze:
        - Sent rows starsi nez sent_retention_seconds (default 24h)
        - Pokud row count > max_rows: DROP nejstarsi sent rows + nejstarsi DEBUG unsent
        - Pokud DB > max_bytes: VACUUM
        """
        conn = self._get_conn()
        with self._lock:
            cutoff = time.time() - sent_retention_seconds
            try:
                conn.execute("BEGIN IMMEDIATE")
                cur = conn.execute(
                    "DELETE FROM log_events WHERE sent = 1 AND sent_ts_unix < ?",
                    (cutoff,),
                )
                deleted = cur.rowcount

                # Hard cap enforcement
                row_count = conn.execute(
                    "SELECT COUNT(*) FROM log_events"
                ).fetchone()[0]
                if row_count > max_rows:
                    excess = row_count - max_rows
                    # Smaz nejstarsi sent rows nejdriv (ty vidi server), pak
                    # nejstarsi DEBUG unsent (lossy degradation per Agent A)
                    cur2 = conn.execute(
                        """DELETE FROM log_events WHERE id IN (
                               SELECT id FROM log_events
                               ORDER BY sent DESC, ts_unix ASC
                               LIMIT ?
                           )""",
                        (excess,),
                    )
                    deleted += cur2.rowcount
                conn.execute("COMMIT")

                # VACUUM mimo transaction
                if self._db_path.exists() and self._db_path.stat().st_size > max_bytes:
                    conn.execute("VACUUM")
                return deleted
            except Exception:
                try:
                    conn.execute("ROLLBACK")
                except Exception:
                    pass
                raise

    def stats(self) -> dict[str, Any]:
        """Diagnostics + dashboard counter source."""
        conn = self._get_conn()
        with self._lock:
            cur = conn.execute(
                """SELECT
                       COUNT(*) AS total,
                       COUNT(*) FILTER (WHERE sent = 0) AS unsent,
                       COUNT(*) FILTER (WHERE sent = 1) AS sent,
                       MAX(retry_count) AS max_retries
                   FROM log_events"""
            )
            row = cur.fetchone()
            db_size = self._db_path.stat().st_size if self._db_path.exists() else 0
            return {
                "total": row[0] or 0,
                "unsent": row[1] or 0,
                "sent": row[2] or 0,
                "max_retries": row[3] or 0,
                "db_size_bytes": db_size,
            }


# ---------------------------------------------------------------------------
# Convenience: singleton holder per process
# ---------------------------------------------------------------------------
_singleton_lock = threading.Lock()
_singleton: LogBuffer | None = None


def get_buffer(db_path: Path | str | None = None) -> LogBuffer:
    """Returns process-singleton LogBuffer.

    Plugin process: kazdy invocation = novy interpreter = nove singleton.
    Service process: persistent singleton po dobu zivota service.
    """
    global _singleton
    with _singleton_lock:
        if _singleton is None:
            if db_path is None:
                raise RuntimeError(
                    "First get_buffer() call must provide db_path"
                )
            _singleton = LogBuffer(db_path)
        return _singleton


def reset_buffer() -> None:
    """Test helper. Closes singleton."""
    global _singleton
    with _singleton_lock:
        if _singleton is not None:
            _singleton.close()
            _singleton = None
