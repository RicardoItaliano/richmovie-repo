# -*- coding: utf-8 -*-
"""
RichMovie – Kolekce (offline playlisty) – modul

Tento modul poskytuje UI a I/O pro načítání a zobrazování **kolekcí**
(z JSON souborů ve složce `resources/collections/`) a jejich obsahu.

• Automaticky načítá **všechny** `.json` soubory ve složce a robustně je validuje.
• Podporuje položky typu `movie` (film) a `tv` (seriál) s volitelným polem `episodes`.
• U `movie` vyhledá TMDb ID a přesměruje přímo na workflow `action=auto&tmdb=<id>`.
• U `tv` s `episodes` zobrazí **jen vybrané** epizody jako pod-složku a na klik zavolá `action=tv_play`.

Pozn.: Soubor je úmyslně pojmenován **richmovie_collections.py**.
Název `collections.py` by kolidoval se standardní knihovnou Pythonu
(`from collections import deque` atd.) a rozbil by importy ve zbytku projektu.
"""

# ──────────────  FUTURE  ──────────────
from __future__ import annotations

# ──────────────  STANDARD LIBRARY  ──────────────
import datetime
import json
import math
import os
import re
import unicodedata
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlencode

# ──────────────  KODI API  ──────────────
import xbmc

import richmovie_routes as _routes
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# ──────────────  LOKÁLNÍ MODULY  ──────────────
from tmdb_client import TMDb  # TMDbError od 3.5.118 nepolykáme → import nepotřeba
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)

# 3.4.x Phase 9: log helper routes via richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.collections", "RichMovie/Collections")
except Exception:
    def _log(msg, level=1, *, context=None):
        try:
            xbmc.log(f"[RichMovie/Collections] {msg}", level)
        except Exception:
            pass


# 3.4.6 (2026-05-07): Czech-friendly sort key. Python str.lower()/casefold()
# does NOT fold diacritics — `'č' (U+010D) > 'z' (U+007A)` in default Unicode
# ordering, so titles starting with Č/Š/Ž etc. would sink below the entire
# A–Z range. NFKD decomposition splits 'č' → 'c' + combining caron, then we
# strip combining marks. This is not a true Czech collation (CH should sort
# after H) but is a massive UX improvement and avoids dependency on system
# locale data which Kodi runtimes (especially Android) often lack.
def _czech_sort_key(s: str) -> str:
    nfkd = unicodedata.normalize("NFKD", (s or "").casefold())
    return "".join(c for c in nfkd if not unicodedata.combining(c))


class CollectionsUI:




    #  2025-08-16 22:46 CEST (Europe/Prague)
    @staticmethod
    def show_collections_root(addon: xbmcaddon.Addon, handle: int) -> None:
        """
        Zobrazí seznam všech dostupných kolekcí (JSON soubory ve `resources/collections/`).

        Novinky (08/2025):
        ------------------
        • `subtitle` z JSONu se nyní zobrazuje jako *popis* (InfoTag → plot) vlevo pod logem.
        • V textu položky je pouze `title` (bez `subtitle`).
        • Vpravo se jako mini‑logo používá `clearlogo` (stejné PNG jako vlevo).
        • Řazení: nejprve kolekce s číselným prefixem „NN - “ (01–, 02–, …) podle čísla,
        poté ostatní kolekce abecedně (case‑insensitive).

        Původní logika výběru loga:
        • 1) Preferuj PNG se stejným stemem vedle JSON (…/collections/<stem>.png)
        • 2) Fallback: …/resources/media/lists/<id>.png
        """
        import richmovie_rmdir
        rmdir = richmovie_rmdir.RmDir(handle, "Kolekce")
        xbmcplugin.setPluginCategory(handle, "Kolekce")
        xbmcplugin.setContent(handle, "videos")

        # Předpřipravíme položky i s klíčem pro řazení
        # (url, li, is_folder, sort_key)
        items: List[tuple[str, xbmcgui.ListItem, bool, tuple]] = []

        def _num_prefix(title: str) -> Optional[int]:
            """
            Detekuje číselný prefix ve tvaru 'NN - ' (povolen 1–4 číslice).
            Vrací integer (bez ohledu na nuly) nebo None.
            """
            m = re.match(r"^\s*(\d{1,4})\s*-\s*", title)
            if not m:
                return None
            try:
                return int(m.group(1))
            except Exception:
                return None

        for file_path, meta in CollectionsUI._iter_collections(addon):
            # Titulek a podtitulek z JSON (fallback na název souboru)
            title    = (meta.get("title") or os.path.splitext(os.path.basename(file_path))[0]).strip()
            subtitle = (meta.get("subtitle") or "").strip()

            # Label v seznamu je nyní *pouze* title
            li = xbmcgui.ListItem(title)

            # Info panel (vlevo): plot = subtitle (pokud existuje)
            # mediatype 'video' kvůli skinům, které dle typu zobrazují plot
            li.setInfo("video", {
                "title":     title,
                "plot":      subtitle,
                "mediatype": "video",
            })

            # ── ARTWORK: PNG vedle JSON se shodným stemem ────────────────
            # Příklad: collections/cz_vanoce.json → collections/cz_vanoce.png
            # 3.4.6 (2026-05-07): odstraněn dead `resources/media/lists/<id>.png`
            # fallback — adresář v repu neexistuje, větev nikdy neuspěla.
            art_icon = "DefaultFolder.png"
            try:
                png_candidate = os.path.splitext(file_path)[0] + ".png"
                if xbmcvfs.exists(png_candidate):
                    art_icon = png_candidate
            except Exception as e:
                _log(f"Chyba při detekci loga: {e}", xbmc.LOGWARNING)

            # Artwork: vlevo i náhled + vpravo (mini logo) stejný PNG
            try:
                li.setArt({
                    "icon":      art_icon,
                    "thumb":     art_icon,
                    "clearlogo": art_icon,   # → mini logo vpravo v infotabulce
                })
            except Exception:
                pass

            url = CollectionsUI._url(addon, action="collections_browse", file=file_path)

            # Řazení: 1) ságy nahoře  2) prefixované číslem  3) ostatní abecedně
            # 3.4.6 (2026-05-07): používáme _czech_sort_key místo title.lower(),
            # jinak titulky začínající Č/Š/Ž padají až za Z (Unicode codepoint
            # ordering). Viz docstring _czech_sort_key na vrcholu modulu.
            is_tree = isinstance(meta.get("tree"), list) and len(meta.get("tree", [])) > 0
            is_saga = is_tree and "sagy_master" in os.path.basename(file_path)
            num = _num_prefix(title)
            _tk = _czech_sort_key(title)
            if is_saga:
                sort_key = (0, 0, _tk)
            elif num is not None:
                sort_key = (1, num, _tk)
            else:
                sort_key = (2, 0, _tk)
            items.append((url, li, True, sort_key))

        if not items:
            _rm_notif("Zadne kolekce nenalezeny", xbmcgui.NOTIFICATION_WARNING, 4000, "RichMovie")
            rmdir.finish(succeeded=False)
            return

        # Seřadit dle composite klíče
        items.sort(key=lambda tup: tup[3])

        for url, li, is_folder, _ in items:
            rmdir.add(url, li, is_folder)

        rmdir.finish()









    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_collections.py › class CollectionsUI
    # browse_collection (upraveno: 23.12.2025 18:42 CET, Europe/Prague – podpora stromových kolekcí `tree/children/items` + parametr `node`)
    # ---------------------------------------------------------------------------- #
    @staticmethod
    def browse_collection(file_vfs_path: str, addon: xbmcaddon.Addon, handle: int, node: str = "") -> None:
        """
        Otevře jednu konkrétní kolekci (dle VFS cesty na JSON) a vypíše její obsah.

        NOVĚ (offline kolekce):
        -----------------------
        • Při otevření kolekce se **NEVOLÁ TMDb** (žádné API dotazy).
        • Metadata (název/plot/rating/art path/ID) se berou z lokálního souboru:
              `<profile>/collections_meta_cache.json`
          který plní instalátor `richmovie_collections_install.run()` (do 3.5.117
          `plugin.py::_install_collections_blocking`).

        NOVĚ (12/2025 – stromové kolekce):
        ----------------------------------
        • Kolekce může být buď:
            - „flat“:  root → `items`
            - „tree“:  root → `tree` → `children` → … → `items`
        • Navigace ve stromu se řídí parametrem `node` (řetězec `id/id/id`).
        • Staré (flat) kolekce fungují beze změny.

        Chování UI:
        • Řazení napříč typy (filmy i seriály) zůstává dle ratingu (desc).
        • Artwork/plot/rating do InfoTagů – zachováno.
        • Pokud pro položku chybí offline meta (nebo TMDb ID), použije se fallback:
            - film → `movie_search`
            - seriál → `tv_search`
        """
        data = CollectionsUI._load_json(file_vfs_path)
        if not isinstance(data, dict) or ("items" not in data and "tree" not in data):
            xbmcgui.Dialog().ok("Kolekce", "Soubor kolekce je neplatný nebo chybí položky.")
            return

        coll_title = (data.get("title") or os.path.basename(file_vfs_path)).strip() or "Kolekce"
        import richmovie_rmdir
        rmdir = richmovie_rmdir.RmDir(handle, coll_title)
        xbmcplugin.setContent(handle, "videos")

        # ───────────────── Urči, zda jde o stromovou kolekci + vyřeš aktuální uzel ─────────────────
        is_tree = isinstance(data.get("tree"), list)

        node_titles: List[str] = []
        node_ids: List[str] = [x for x in (node or "").split("/") if x.strip() and x.strip() != "show_all"]
        current_children: List[Dict[str, Any]] = []
        current_items: List[Dict[str, Any]] = []

        if is_tree:
            # root
            current_children = list(data.get("tree") or [])
            current_items = list(data.get("items") or []) if isinstance(data.get("items"), list) else []

            # projdi cestu node/id/id…
            cur_children = current_children
            cur_node: Optional[Dict[str, Any]] = None

            for seg in node_ids:
                found = None
                for ch in (cur_children or []):
                    if not isinstance(ch, dict):
                        continue
                    if (ch.get("id") or "").strip() == seg:
                        found = ch
                        break

                if not found:
                    _log(f"Neplatná cesta node='{node}' v kolekci: {file_vfs_path}", xbmc.LOGWARNING)
                    xbmcgui.Dialog().ok("Kolekce", "Neplatná cesta ve stromu kolekce (node).")
                    return

                node_titles.append((found.get("title") or found.get("name") or seg).strip() or seg)
                cur_node = found
                cur_children = found.get("children") if isinstance(found.get("children"), list) else []

            # pokud jsme v pod-uzlu, přepni children/items na obsah uzlu
            if cur_node is not None:
                current_children = list(cur_node.get("children") or []) if isinstance(cur_node.get("children"), list) else []
                current_items = list(cur_node.get("items") or []) if isinstance(cur_node.get("items"), list) else []

            # Kategorie: „Kolekce / Složka / Podsložka“
            if node_titles:
                rmdir.title = f"{coll_title} / " + " / ".join(node_titles)
                xbmcplugin.setPluginCategory(handle, rmdir.title)
            else:
                xbmcplugin.setPluginCategory(handle, coll_title)

        else:
            # flat kolekce (původní chování)
            xbmcplugin.setPluginCategory(handle, coll_title)
            current_items = list(data.get("items") or []) if isinstance(data.get("items"), list) else []

        # ───────────────── Načti offline meta cache pro kolekce ─────────────────
        meta_items: Dict[str, Dict[str, Any]] = {}
        try:
            profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
            meta_path   = os.path.join(profile_dir, "collections_meta_cache.json")
            if xbmcvfs.exists(meta_path):
                f = xbmcvfs.File(meta_path, "r")
                try:
                    raw = f.read()
                finally:
                    f.close()
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8", errors="ignore")
                meta_doc = json.loads(raw or "{}")
                if isinstance(meta_doc, dict) and isinstance(meta_doc.get("items"), dict):
                    meta_items = meta_doc["items"]
        except Exception as e:
            _log(f"offline meta load failed: {e}", xbmc.LOGWARNING)
            meta_items = {}

        # ───────────────── Nejprve vypiš podsložky (jen pro tree kolekce) ─────────────────
        # Artwork: top-level uzly mají vlastní tmdb_collection_id,
        # pod-uzly (watch orders) dědí artwork od rodiče.
        parent_coll_id = None
        if is_tree and node_ids:
            # Najdi tmdb_collection_id rodiče (aktuálního uzlu)
            cur = data.get("tree") or []
            for seg in node_ids:
                for ch in (cur if isinstance(cur, list) else []):
                    if isinstance(ch, dict) and (ch.get("id") or "").strip() == seg:
                        parent_coll_id = ch.get("tmdb_collection_id")
                        cur = ch.get("children") if isinstance(ch.get("children"), list) else []
                        break

        # Na root úrovni tree kolekce (ságy) řadíme podle popularity.
        # Popularity = součet hlasů filmů v dané ságě (z offline cache).
        # Uvnitř ságy (watch orders) zachováváme pořadí z JSON.
        if is_tree and current_children and not node_ids:
            def _saga_popularity(ch_node: Dict[str, Any]) -> int:
                """Spočítá celkové votes všech filmů v ságě (z meta cache)."""
                total_votes = 0
                def _collect(node: Dict[str, Any]) -> None:
                    nonlocal total_votes
                    for it in (node.get("items") or []):
                        if isinstance(it, dict):
                            name = (it.get("title") or it.get("name") or "").strip()
                            year = it.get("year")
                            typ = (it.get("type") or "movie").strip().lower()
                            if typ == "movie":
                                key = f"movie|{name}|{int(year) if str(year or '').strip().isdigit() else ''}"
                            else:
                                key = f"tv|{name}"
                            m = meta_items.get(key)
                            if isinstance(m, dict):
                                total_votes += int(m.get("votes") or 0)
                    for child in (node.get("children") or []):
                        if isinstance(child, dict):
                            _collect(child)
                _collect(ch_node)
                return total_votes
            current_children = sorted(current_children, key=_saga_popularity, reverse=True)

        if is_tree and current_children:
            # Pre-compute addon path once for image resolution (cheap, but pulled
            # out of the per-child loop for clarity).
            _addon_base_path = addon.getAddonInfo("path") or ""

            for ch in current_children:
                if not isinstance(ch, dict):
                    continue
                ch_title = (ch.get("title") or ch.get("name") or ch.get("id") or "").strip()
                if not ch_title:
                    continue

                li = xbmcgui.ListItem(ch_title)

                # ── Resolve overview + artwork with priority chain ──────────────
                # 1) TMDb Collection metadata (tmdb_collection_id → offline cache)
                # 2) JSON-defined `description` / `subtitle` field on the node
                # 3) JSON-defined `image` field (relative path under addon root)
                #
                # 3.4.6 (2026-05-07): added priority #2 + #3 fallbacks. Collections
                # without TMDb collection IDs (vanoce_master, cz_velikonoce,
                # kldr_north_korea_master) previously rendered as bare DefaultFolder.png
                # with no plot. Curators can now author per-node text + optional PNG
                # alongside the collection JSON.
                coll_id = ch.get("tmdb_collection_id") or parent_coll_id
                art: Dict[str, str] = {"icon": "DefaultFolder.png"}
                overview: str = ""

                if coll_id:
                    cache_key = f"coll|{coll_id}"
                    coll_meta = meta_items.get(cache_key)
                    if isinstance(coll_meta, dict):
                        if coll_meta.get("poster_path"):
                            art["poster"] = f"https://image.tmdb.org/t/p/w342{coll_meta['poster_path']}"
                            art["thumb"] = f"https://image.tmdb.org/t/p/w185{coll_meta['poster_path']}"
                            art["icon"] = art["thumb"]
                        if coll_meta.get("backdrop_path"):
                            art["fanart"] = f"https://image.tmdb.org/t/p/original{coll_meta['backdrop_path']}"
                        overview = (coll_meta.get("overview") or "").strip()

                # JSON fallback for overview (always tried when TMDb path didn't yield one)
                if not overview:
                    overview = (ch.get("description") or ch.get("subtitle") or "").strip()

                # JSON fallback for artwork: optional `image` field, relative to addon path.
                # Curator example: "image": "resources/collections/vanoce_master/01_pohadky_cz.png"
                if not art.get("poster"):
                    img_rel = (ch.get("image") or "").strip()
                    if img_rel and _addon_base_path:
                        # Normalise leading separators so curator path style is forgiving.
                        img_full = os.path.join(_addon_base_path, img_rel.lstrip("/\\"))
                        try:
                            if xbmcvfs.exists(img_full):
                                art["poster"] = img_full
                                art["thumb"] = img_full
                                art["icon"] = img_full
                        except Exception:
                            pass

                if overview:
                    li.setInfo("video", {"plot": overview, "mediatype": "set"})
                li.setArt(art)

                ch_id = (ch.get("id") or "").strip()
                if not ch_id:
                    ch_id = re.sub(r"\s+", "_", ch_title.lower())[:80] or "node"

                new_node = "/".join(node_ids + [ch_id]) if node_ids else ch_id
                url = CollectionsUI._url(addon, action="collections_browse", file=file_vfs_path, node=new_node)
                rmdir.add(url, li, True)

        # ───────────────── Položky (filmy + seriály) ─────────────────
        # (rating, votes, url, li, is_folder)
        rows: List[Tuple[float, int, str, xbmcgui.ListItem, bool]] = []

        for idx, it in enumerate(current_items):
            if not isinstance(it, dict):
                _log(f"Přeskakuji invalidní položku (není dict) #{idx}: {it!r}", xbmc.LOGWARNING)
                continue

            typ  = (it.get("type") or it.get("kind") or "").strip().lower()
            name = (it.get("title") or it.get("name") or "").strip()

            try:
                year = int(it.get("year") or 0) if str(it.get("year") or "").strip().isdigit() else None
            except Exception:
                year = None

            if not name or typ not in {"movie", "tv"}:
                _log(f"Přeskakuji invalidní položku #{idx}: {it!r}", xbmc.LOGWARNING)
                continue

            if typ == "movie":
                key = f"movie|{name}|{int(year) if year else ''}"
                meta = meta_items.get(key) if isinstance(meta_items.get(key), dict) else {}

                # Preferovaný (lokální) zobrazovaný název
                display_name = (meta.get("title") or name).strip()
                try:
                    display_year = int(meta.get("year") or (year or 0))
                except Exception:
                    display_year = year or 0

                # Rating + label
                try:
                    rating = float(meta.get("rating") or 0.0)
                except Exception:
                    rating = 0.0
                rating_txt = f"[B][COLOR gold]★ {rating}[/COLOR][/B]\t" if rating else ""
                title_core = f"{display_name} ({display_year})" if display_year else display_name
                li = xbmcgui.ListItem(f"{rating_txt}{title_core}")

                # Artwork
                art: Dict[str, str] = {"icon": "DefaultVideo.png"}
                if meta.get("poster_path"):
                    art["poster"] = f"https://image.tmdb.org/t/p/w342{meta['poster_path']}"
                    art["thumb"]  = f"https://image.tmdb.org/t/p/w185{meta['poster_path']}"
                if meta.get("backdrop_path"):
                    art["fanart"] = f"https://image.tmdb.org/t/p/original{meta['backdrop_path']}"
                li.setArt(art)

                # InfoTag
                info = {
                    "title":     display_name,
                    "plot":      (meta.get("overview") or "").strip(),
                    "year":      display_year,
                    "mediatype": "movie",
                }
                if rating:
                    info["rating"] = rating
                    try:
                        info["votes"] = int(meta.get("votes") or 0)
                    except Exception:
                        info["votes"] = 0
                li.setInfo("video", info)
                if rating:
                    try:
                        li.setRating("tmdb", rating, int(meta.get("votes", 0)))
                    except Exception:
                        pass

                # Klik URL – preferuj auto podle TMDb, jinak vyhledej film (použijeme display_name)
                try:
                    tmdb_id = int(meta.get("id") or 0)
                except Exception:
                    tmdb_id = 0
                if tmdb_id:
                    url = CollectionsUI._url(addon, action="auto", tmdb=str(tmdb_id))
                else:
                    url = CollectionsUI._url(addon, action="movie_search", q=display_name)

                try:
                    votes = int(meta.get("votes") or 0)
                except Exception:
                    votes = 0
                rows.append((rating, votes, url, li, True))

            elif typ == "tv":
                episodes = it.get("episodes") or []
                key_tv   = f"tv|{name}"
                tv_meta  = meta_items.get(key_tv) if isinstance(meta_items.get(key_tv), dict) else {}

                try:
                    tv_id = int(tv_meta.get("id") or 0)
                except Exception:
                    tv_id = 0

                try:
                    rating = float(tv_meta.get("rating") or 0.0)
                except Exception:
                    rating = 0.0
                rating_txt = f"[B][COLOR gold]★ {rating}[/COLOR][/B]\t" if rating else ""

                # ListItem + artwork (offline)
                label_suffix = " (Pouze vybrané epizody)" if episodes else ""
                li = xbmcgui.ListItem(f"{rating_txt}{name}{label_suffix}")

                art: Dict[str, str] = {"icon": "DefaultTVShows.png"}
                if tv_meta.get("poster_path"):
                    art["poster"] = f"https://image.tmdb.org/t/p/w342{tv_meta['poster_path']}"
                    art["thumb"]  = f"https://image.tmdb.org/t/p/w185{tv_meta['poster_path']}"
                if tv_meta.get("backdrop_path"):
                    art["fanart"] = f"https://image.tmdb.org/t/p/original{tv_meta['backdrop_path']}"
                li.setArt(art)

                li.setInfo("video", {
                    "title":        name,
                    "tvshowtitle":  name,
                    "plot":         (tv_meta.get("overview") or "").strip(),
                    "year":         int(tv_meta.get("year") or 0),
                    "mediatype":    "tvshow",
                })

                try:
                    tv_votes = int(tv_meta.get("votes") or 0)
                except Exception:
                    tv_votes = 0

                # URL (offline) – pokud chybí tv_id, padáme na plnotextové hledání
                if not tv_id:
                    url = CollectionsUI._url(addon, action="tv_search", q=name)
                    rows.append((rating, tv_votes, url, li, True))
                else:
                    if episodes:
                        tv_kwargs = {
                            "action": "collections_tv",
                            "file": file_vfs_path,
                            "tv_id": str(tv_id),
                            "tv_name": name,
                        }
                        # `node` posíláme jen u stromových kolekcí a pouze když jsme skutečně uvnitř uzlu.
                        if is_tree and node_ids:
                            tv_kwargs["node"] = "/".join(node_ids)
                        url = CollectionsUI._url(addon, **tv_kwargs)
                    else:
                        url = CollectionsUI._url(addon, action="tv_seasons", tv_id=str(tv_id), tv_name=name)
                    rows.append((rating, tv_votes, url, li, True))

        # ───── Řazení: záleží na typu kolekce ─────
        # Tree kolekce (ságy) uvnitř uzlu → zachovat pořadí z JSON
        #   (autor JSON definoval doporučené pořadí sledování)
        # Flat kolekce → smart sort: rating × log₁₀(votes + 1)
        #   (zohledňuje kvalitu i popularitu)
        preserve_order = is_tree and bool(node_ids)

        if not preserve_order:
            _POPULAR_VOTES = 500  # hranice pro "známý" titul
            _TOP_LIMIT = 50       # max položek v "Nejznámější" pohledu

            def _weighted_score(rating: float, votes: int) -> float:
                return rating * math.log10(max(votes, 1) + 1) if rating > 0 else 0.0

            rows.sort(key=lambda t: _weighted_score(t[0], t[1]), reverse=True)

            # Dvouúrovňový pohled pro velké kolekce:
            # - výchozí: top N populárních + odkaz na zbytek
            # - show_all: kompletní seznam
            total = len(rows)
            popular_rows = [r for r in rows if r[1] >= _POPULAR_VOTES] if total > _TOP_LIMIT else rows
            show_all = "show_all" in (node or "")

            if show_all or total <= _TOP_LIMIT or len(popular_rows) < 5:
                for _, _, url, li, is_folder in rows:
                    rmdir.add(url, li, is_folder)
            else:
                display_rows = popular_rows[:_TOP_LIMIT] if len(popular_rows) > _TOP_LIMIT else popular_rows
                for _, _, url, li, is_folder in display_rows:
                    rmdir.add(url, li, is_folder)

                remaining = total - len(display_rows)
                if remaining > 0:
                    all_node = (node + "/show_all") if node else "show_all"
                    li_all = xbmcgui.ListItem(
                        f"[COLOR gray]Zobrazit všech {total} položek ({remaining} dalších)...[/COLOR]"
                    )
                    li_all.setArt({"icon": "DefaultAddSource.png"})
                    url_all = CollectionsUI._url(
                        addon, action="collections_browse", file=file_vfs_path, node=all_node,
                    )
                    rmdir.add(url_all, li_all, True)
        else:
            # Tree kolekce uvnitř uzlu – zachovat pořadí z JSON (doporučené sledování)
            for _, _, url, li, is_folder in rows:
                rmdir.add(url, li, is_folder)

        rmdir.finish()






    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_collections.py › class CollectionsUI
    # browse_tv (upraveno: 23.12.2025 18:42 CET, Europe/Prague – vyhledávání seriálu i ve stromových kolekcích `tree/children/items`)
    # ---------------------------------------------------------------------------- #
    @staticmethod
    def browse_tv(file_vfs_path: str, tv_id: str, tv_name: str, addon: xbmcaddon.Addon, handle: int, node: str = "") -> None:
        """
        Vypíše „vybrané epizody“ seriálu definované v JSON kolekci.

        NOVĚ (offline):
        • Žádné TMDb API volání.
        • Epizodní metadata (název/plot/air_date/still) se berou z `collections_meta_cache.json`.

        NOVĚ (12/2025):
        • Seriál se hledá i ve stromové kolekci (`tree/children/items`).
        • Pokud je předán parametr `node`, preferuje se hledání v daném uzlu.
          (Když se nenajde, provede se fallback prohledání celé kolekce.)

        Pozn.: Pokud v offline cache epizoda chybí, doplněk ji stále zobrazí, ale s minimem informací.
        """
        data = CollectionsUI._load_json(file_vfs_path)
        if not isinstance(data, dict):
            xbmcgui.Dialog().ok("Kolekce", "Soubor kolekce je neplatný.")
            return

        tv_name = (tv_name or "").strip()
        if not tv_name:
            xbmcgui.Dialog().ok("Kolekce", "Chybí název seriálu.")
            return

        import richmovie_rmdir
        rmdir = richmovie_rmdir.RmDir(handle, tv_name or "Epizody")

        # ───────────────── Najdi TV položku (flat i tree) ─────────────────
        def _iter_node_items(n: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
            """Rekurzivně projde `children` a vrátí `items`."""
            if isinstance(n.get("items"), list):
                for it2 in n.get("items") or []:
                    if isinstance(it2, dict):
                        yield it2
            if isinstance(n.get("children"), list):
                for ch in n.get("children") or []:
                    if isinstance(ch, dict):
                        yield from _iter_node_items(ch)

        def _iter_all_items(src: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
            """Vrátí všechny položky z `items` (flat) i z `tree` (tree)."""
            if isinstance(src.get("items"), list):
                for it2 in src.get("items") or []:
                    if isinstance(it2, dict):
                        yield it2
            if isinstance(src.get("tree"), list):
                for top in src.get("tree") or []:
                    if isinstance(top, dict):
                        yield from _iter_node_items(top)

        def _find_node_by_path(src: Dict[str, Any], node_path: str) -> Optional[Dict[str, Any]]:
            """Najde uzel ve `tree` podle cesty id/id/id. Vrací dict uzlu nebo None."""
            if not isinstance(src.get("tree"), list):
                return None
            segs = [x for x in (node_path or "").split("/") if x.strip()]
            if not segs:
                return None
            cur_children = list(src.get("tree") or [])
            cur_node = None
            for seg in segs:
                found = None
                for ch in cur_children:
                    if not isinstance(ch, dict):
                        continue
                    if (ch.get("id") or "").strip() == seg:
                        found = ch
                        break
                if not found:
                    return None
                cur_node = found
                cur_children = found.get("children") if isinstance(found.get("children"), list) else []
            return cur_node

        tv_item = None

        # 1) pokud máme node, zkus nejdřív v daném uzlu (když jde o tree kolekci)
        preferred_node = _find_node_by_path(data, node)
        if preferred_node is not None:
            for it in _iter_node_items(preferred_node):
                if (it.get("type") or it.get("kind") or "").strip().lower() == "tv" and (it.get("title") or it.get("name") or "").strip() == tv_name:
                    tv_item = it
                    break

        # 2) fallback: prohledej celou kolekci
        if tv_item is None:
            for it in _iter_all_items(data):
                if (it.get("type") or it.get("kind") or "").strip().lower() == "tv" and (it.get("title") or it.get("name") or "").strip() == tv_name:
                    tv_item = it
                    break

        if not tv_item:
            xbmcgui.Dialog().ok("Kolekce", "Seriál nebyl v kolekci nalezen.")
            return

        episodes = tv_item.get("episodes") or []
        if not episodes:
            xbmcgui.Dialog().ok("Kolekce", "V této kolekci nejsou vybrané epizody.")
            return

        # ───────────────── Načti offline meta cache pro kolekce ─────────────────
        meta_items: Dict[str, Dict[str, Any]] = {}
        tv_meta: Dict[str, Any] = {}
        try:
            profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
            meta_path   = os.path.join(profile_dir, "collections_meta_cache.json")
            if xbmcvfs.exists(meta_path):
                f = xbmcvfs.File(meta_path, "r")
                try:
                    raw = f.read()
                finally:
                    f.close()
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8", errors="ignore")
                meta_doc = json.loads(raw or "{}")
                if isinstance(meta_doc, dict) and isinstance(meta_doc.get("items"), dict):
                    meta_items = meta_doc["items"]
                    key_tv = f"tv|{tv_name}"
                    if isinstance(meta_items.get(key_tv), dict):
                        tv_meta = meta_items[key_tv]
        except Exception as e:
            _log(f"offline meta load failed (browse_tv): {e}", xbmc.LOGWARNING)
            meta_items = {}
            tv_meta = {}

        # Fanart pro celý seznam epizod (pokud máme)
        tv_fanart = ""
        if tv_meta.get("backdrop_path"):
            tv_fanart = f"https://image.tmdb.org/t/p/original{tv_meta['backdrop_path']}"

        # Tv_id musí být číslo – tv_play uvnitř pluginu dělá int(tv_id)
        tv_id_num = 0
        try:
            tv_id_num = int(tv_id)
        except Exception:
            tv_id_num = 0

        today = datetime.datetime.now().date()

        # Vypiš epizody ve stejném pořadí, jak jsou v JSON
        for ep in episodes:
            s_raw = ep.get("season") or ep.get("s") or ep.get("season_number")
            e_raw = ep.get("episode") or ep.get("e") or ep.get("episode_number")
            try:
                s_no = int(s_raw); e_no = int(e_raw)
            except Exception:
                continue

            # Offline meta klíč
            key_ep = f"ep|{tv_name}|{s_no}|{e_no}"
            meta_ep = meta_items.get(key_ep) if isinstance(meta_items.get(key_ep), dict) else {}

            ep_title = (meta_ep.get("name") or ep.get("title") or ep.get("name") or f"Epizoda {e_no}").strip()
            plot_txt = (meta_ep.get("overview") or "").strip()
            air_iso  = (meta_ep.get("air_date") or "").strip()
            still    = (meta_ep.get("still_path") or "").strip()

            prefix = f"S{s_no:02d}E{e_no:02d}"

            # Premiéra (pokud je v budoucnu)
            is_future = False
            if air_iso:
                try:
                    premiere_dt = datetime.datetime.strptime(air_iso, "%Y-%m-%d").date()
                    is_future = premiere_dt > today
                except Exception:
                    pass

            if is_future:
                label = f"[COLOR orange]{prefix} • {ep_title} (Premiéra: {air_iso})[/COLOR]"
            else:
                label = f"{prefix} • {ep_title}"

            li = xbmcgui.ListItem(label)

            art: Dict[str, str] = {"icon": "DefaultEpisode.png"}
            if still:
                art["thumb"] = f"https://image.tmdb.org/t/p/w300{still}"
            if tv_fanart:
                art["fanart"] = tv_fanart
            li.setArt(art)

            info: Dict[str, Any] = {
                "title":        ep_title,
                "tvshowtitle":  tv_name,
                "plot":         plot_txt,
                "season":       s_no,
                "episode":      e_no,
                "mediatype":    "episode",
            }
            if air_iso:
                info["aired"] = air_iso
            li.setInfo("video", info)

            if tv_id_num:
                ep_action = "tv_play"
                url = CollectionsUI._url(
                    addon,
                    action=ep_action,
                    tv_id=str(tv_id_num),
                    tv_name=tv_name,
                    season=str(s_no),
                    episode=str(e_no),
                    ep_title=ep_title,
                )
            else:
                ep_action = "tv_search"
                url = CollectionsUI._url(addon, action=ep_action, q=tv_name)

            # `tv_play` i `tv_search` staví ADRESÁŘ streamů → položka MUSÍ být složka.
            # Do 3.5.152 tu bylo `False`: klik na díl v seriálové kolekci hledal a nic
            # nezobrazil — třetí výskyt root cause z 19.09.2026 (hlavní výpis epizod
            # v plugin.py přidává tutéž akci jako složku). Hodnota jde z registru rout.
            rmdir.add(url, li, _routes.is_folder(ep_action))

        rmdir.finish()





    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_collections.py › class CollectionsUI
    # _iter_collections (upraveno: 23.12.2025 18:42 CET, Europe/Prague – akceptuj i stromové kolekce s `tree` místo `items`)
    # ---------------------------------------------------------------------------- #
    @staticmethod
    def _iter_collections(addon: xbmcaddon.Addon) -> Iterable[tuple[str, Dict[str, Any]]]:
        """
        Vrátí (VFS_cesta, metadata) pro každý validní kolekční JSON.

        • Vynechá soubory bez validního JSONu nebo bez povinného obsahu:
            - buď `items` (flat kolekce), nebo `tree` (stromová kolekce)
        • `id` se derivuje z JSONu; pokud chybí, použije se název souboru bez přípony.
        """
        base = addon.getAddonInfo("path")
        coll_dir = os.path.join(base, "resources", "collections")
        try:
            _, files = xbmcvfs.listdir(coll_dir)
        except Exception:
            files = []
        for name in files:
            if not name.lower().endswith(".json"):
                continue
            vfs_path = os.path.join(coll_dir, name)
            data = CollectionsUI._load_json(vfs_path)

            if not isinstance(data, dict):
                _log(f"Přeskakuji neplatný soubor (není dict): {name}", xbmc.LOGWARNING)
                continue

            has_items = isinstance(data.get("items"), list) and len(data.get("items") or []) > 0
            has_tree  = isinstance(data.get("tree"), list) and len(data.get("tree") or []) > 0

            if not has_items and not has_tree:
                _log(f"Přeskakuji neplatný soubor: {name}", xbmc.LOGWARNING)
                continue

            # zaruč `id`
            if not data.get("id"):
                data["id"] = os.path.splitext(name)[0]
            yield vfs_path, data






    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _load_json(vfs_path: str) -> Any:
        """
        Načte JSON z VFS cesty s robustním dekódováním (UTF-8/UTF-8-SIG).
        """
        try:
            f = xbmcvfs.File(vfs_path, 'r')
            try:
                raw = f.read()
            finally:
                f.close()
            if isinstance(raw, bytes):
                try:
                    txt = raw.decode("utf-8-sig")
                except Exception:
                    txt = raw.decode("utf-8", "replace")
            else:
                txt = raw
            return json.loads(txt)
        except Exception as e:
            _log(f"Chyba při čtení JSON: {vfs_path} – {e}", xbmc.LOGERROR)
            return None


    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _find_movie_tmdb(tmdb: Optional[TMDb], title: str, year: Optional[int]) -> tuple[Optional[int], Dict[str, Any]]:
        """
        Najde TMDb ID pro film (preferuje shodu roku). Vrací (tmdb_id, metadata).
        """
        if not tmdb:
            return None, {}
        # 3.5.118: chyby volání PROPAGUJÍ (TMDbTransientError / TMDbAuthError /
        # TMDbNotFoundError / TMDbError). Do 3.5.117 se tu polykaly na `(None, {})`,
        # což je tvar „TMDb nic nemá" — instalátor kolekcí pak 403 před authem
        # uložil jako 7denní negativní cache (incident gunžik 21.08.2026).
        # `(None, {})` od teď znamená VÝHRADNĚ „hledání proběhlo a nic nenašlo".
        cands = tmdb.search(title, limit=10)
        # preferuj shodu roku
        best = None
        if year:
            for c in cands:
                if int(c.get("year") or 0) == int(year):
                    best = c; break
        best = best or (cands[0] if cands else None)
        return (best.get("id"), best) if best else (None, {})


    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _find_tv_tmdb(tmdb: Optional[TMDb], title: str) -> tuple[Optional[int], Dict[str, Any]]:
        """
        Najde TMDb ID pro seriál podle názvu. Vrací (tmdb_id, metadata).
        """
        if not tmdb:
            return None, {}
        # 3.5.118: propaguje chyby volání — viz `_find_movie_tmdb`.
        cands = tmdb.search_tv(title, limit=10)
        best = cands[0] if cands else None
        return (best.get("id"), best) if best else (None, {})


    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _url(addon: xbmcaddon.Addon, **qs: str) -> str:
        """
        Postaví URL volání vlastního pluginu (lokální utilita).
        """
        return f"plugin://{addon.getAddonInfo('id')}/?{urlencode(qs)}"
