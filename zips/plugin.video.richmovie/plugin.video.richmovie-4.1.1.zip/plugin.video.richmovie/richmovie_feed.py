# -*- coding: utf-8 -*-
"""RichMovie 4.0 — feed provider (SSOT) pro custom Browse grid.

Mapuje typ feedu → TMDb metodu → NORMALIZOVANÉ položky pro grid okno.
DRY: jedno místo, kde se ví, jak feed naplnit. Best-effort (chyba → []).

Položka: {title, tmdb_id, kind ('movie'|'tv'), poster_path, year, rating}.
"""
from __future__ import annotations

import xbmc
import xbmcaddon

_ADDON_ID = "plugin.video.richmovie"

# 2026-07-01 (observability program): Feed WARNING logy (chyby TMDb/CW/historie/AI
# na Home) přepnuty z přímého xbmc.log na ROUTOVANÝ logger → tečou na NAS (Gate).
try:
    from richmovie_logging import make_legacy_logger as _feed_make_legacy_logger
    _log = _feed_make_legacy_logger("richmovie.feed", "RichMovie/Feed")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log(f"[RichMovie/Feed] {msg}", level)
        except Exception:
            pass


def _tmdb():
    try:
        from tmdb_client import TMDb
        from richmovie_settings import get_tmdb_api_key
        # SSOT 3.5.69 (bandog vzor): lokální setting je jen cache plněná při
        # WS-loginu — accessor padá na klíč z Gate lease cache.
        key = get_tmdb_api_key()
        if not key:
            return None
        return TMDb(key, lang="cs-CZ")
    except Exception as exc:
        _log(f"TMDb init: {exc}", xbmc.LOGWARNING)
        return None


# ─── Φ5 (2026-07-06, audit A09): AI rail SWR writer — SSOT ──────────────────
# rail_ai_cache.json měl JEDINÉHO writera: legacy widget endpoint action=rail_ai
# (plugin.py), volaný jen ze skin.richmovie widgetu → uživatel custom UI bez
# skin widgetů měl AI tipy zamrzlé NAVŽDY (cache jen četla Home/feed).
# Vzor stale-while-revalidate: čtenáři renderují cache hned; při stale/prázdné
# spustí background refresh (non-daemon — feedback_daemon_threads_kodi),
# zápis bumpne data rev "ai" → otevřená okna se samy refreshnou (Φ5 kontrakt).

AI_RAIL_CACHE = "rail_ai_cache.json"
AI_RAIL_TTL_S = 6 * 3600
_AI_REFRESH_PROP = "richmovie.ai_rail.refreshing"
_AI_FAIL_PROP = "richmovie.ai_rail.last_fail"
AI_RAIL_FAIL_BACKOFF_S = 600  # R3-P2-4: negative TTL — Gate down ≠ retry na každé čtení


def ai_rail_fetch_and_store():
    """Sync fetch AI doporučení (Gate) → dedup → atomický zápis cache → rev
    bump. Vrací True při úspěšném zápisu. Volá background worker (SWR) i
    legacy endpoint action=rail_ai (plugin.py — DRY, logika žije jen tady)."""
    import os as _os
    import time as _time
    try:
        from richmovie_recommendations import fetch_recommendations
        data = fetch_recommendations(limit=12, offset=0) or {}
        fresh = data.get("items") or []
        if not fresh:
            return False
        import richmovie_ui_common as _uc
        try:
            # RCAI vrací stejný titul i vícekrát (napříč generacemi/personami)
            fresh = _uc.dedup_media(fresh)
        except Exception:
            pass
        path = _uc.data_path(AI_RAIL_CACHE)   # osobní (profily 3.5.134)
        import richmovie_atomic as _atomic
        if not _atomic.write_json(path, {"ts": _time.time(), "items": fresh}):
            return False
        try:
            _uc.data_rev_bump("ai")
        except Exception:
            pass
        return True
    except Exception as exc:
        _log(f"ai_rail_fetch_and_store: {exc}", xbmc.LOGDEBUG)
        return False


def ai_rail_refresh_if_stale():
    """SWR: čerstvá cache → no-op; stale/prázdná → background refresh (jednou —
    inflight guard přes Window prop s TTL 120 s proti stádu vláken). Vrací
    True = refresh spuštěn. Volají čtenáři cache (Home _fill_ai, feed ai_recs)."""
    import threading
    import time as _time
    import xbmcgui
    try:
        import richmovie_ui_common as _uc
        cache = _uc.load_json(AI_RAIL_CACHE)
        ts = float(cache.get("ts") or 0)
        if (cache.get("items") or []) and (_time.time() - ts) <= AI_RAIL_TTL_S:
            return False
        win = xbmcgui.Window(10000)
        # R3-P2-4: negative backoff — po neúspěšném fetchi (Gate down / prázdná
        # odpověď) 10 min žádný další pokus (jinak nové vlákno + request při
        # KAŽDÉM čtení railu po celou dobu výpadku)
        _fail_raw = (win.getProperty(_AI_FAIL_PROP) or "").strip()
        if _fail_raw:
            try:
                if (_time.time() - float(_fail_raw)) < AI_RAIL_FAIL_BACKOFF_S:
                    return False
            except Exception:
                pass
        raw = (win.getProperty(_AI_REFRESH_PROP) or "").strip()
        if raw:
            try:
                if (_time.time() - float(raw)) < 120:
                    return False  # refresh už běží
            except Exception:
                pass
        win.setProperty(_AI_REFRESH_PROP, str(_time.time()))

        def _worker():
            ok = False
            try:
                ok = ai_rail_fetch_and_store()
            finally:
                try:
                    _w = xbmcgui.Window(10000)
                    _w.clearProperty(_AI_REFRESH_PROP)
                    if ok:
                        _w.clearProperty(_AI_FAIL_PROP)
                    else:
                        import time as _t2
                        _w.setProperty(_AI_FAIL_PROP, str(_t2.time()))
                except Exception:
                    pass

        threading.Thread(target=_worker, name="RMAiRailRefresh",
                         daemon=False).start()
        return True
    except Exception as exc:
        _log(f"ai_rail_refresh_if_stale: {exc}", xbmc.LOGDEBUG)
        return False


def _norm(it, kind):
    return {
        "title": (it.get("title") or it.get("name") or "").strip(),
        "tmdb_id": it.get("id") or it.get("tmdb_id") or "",
        "kind": kind,
        "poster_path": it.get("poster_path") or "",
        "year": it.get("year") or "",
        "rating": it.get("rating") or 0,
    }


def get_feed(feed: str, q: str = "", genre_id: str = "", ref_id: str = "",
             raise_on_error: bool = False) -> list:
    """Vrátí normalizované položky pro daný feed. Best-effort.

    ref_id: TMDb id referenčního titulu (similar_movies / similar_tv feedy).
    raise_on_error: když True, síťová/TMDb chyba se PROPAGUJE (volající okno tak
      rozliší „chyba spojení" od „prázdného výsledku" a ukáže retry stav místo
      matoucího „Nic tu není"). Default False = legacy best-effort ([]).
    """
    feed = (feed or "").strip()

    # ── Lokální feedy (bez TMDb) ──
    # Položky můžou mít click_url + click_kind ("play" = zavřít dialog stack
    # před spuštěním, "win" = custom okno NAD gridem). Bez click_url → rm_detail.
    if feed == "cw":
        try:
            import richmovie_history as _hist_feed
            import richmovie_ui_common as _uc
            out = []
            # 4.0.3: POHLED Pokračovat (za seriál jeden řádek); index v odkazu = index pohledu (`plugin._cw_locate`)
            for idx, it in enumerate(_hist_feed.cw_view_load().get("items") or []):
                if it.get("type") == "episode":
                    tv = it.get("tv_name") or it.get("title") or "Seriál"
                    title = f"{tv} S{int(it.get('season') or 0):02d}E{int(it.get('episode') or 0):02d}"
                else:
                    title = it.get("title") or "Bez názvu"
                out.append({"title": title, "tmdb_id": it.get("tmdb_id") or "",
                            "kind": "tv" if it.get("type") == "episode" else "movie",
                            "poster_path": it.get("poster_path") or "",
                            "year": it.get("year") or "", "rating": 0,
                            "click_url": _uc.cw_link(idx, _uc.cw_key_of(it)),
                            "click_kind": "play"})
            return out
        except Exception as exc:
            _log(f"cw: {exc}", xbmc.LOGWARNING)
            return []

    if feed == "recent_series":
        try:
            import richmovie_ui_common as _uc
            eps = _uc.load_json("watch_history.json").get("episodes") or []
            pcache = _uc.load_json("rail_series_posters.json")
            out, seen = [], set()
            for it in eps:
                tid = str(it.get("tv_id") or "")
                if not tid or tid in seen:
                    continue
                seen.add(tid)
                name = (it.get("tv_name") or "Seriál").strip()
                out.append({"title": name, "tmdb_id": tid, "kind": "tv",
                            "poster_path": (pcache.get(tid) or {}).get("p") or "",
                            "year": "", "rating": 0,
                            "click_url": _uc.url(action="rm_episodes", tv_id=tid, tv_name=name),
                            "click_kind": "win"})
            return out
        except Exception as exc:
            _log(f"recent_series: {exc}", xbmc.LOGWARNING)
            return []

    if feed == "my_list":
        try:
            import richmovie_history as _hist
            out = []
            for it in (_hist.my_list_load().get("items") or []):
                if not it.get("tmdb_id"):
                    continue
                out.append({"title": it.get("title") or "", "tmdb_id": it.get("tmdb_id"),
                            "kind": it.get("kind") or "movie",
                            "poster_path": it.get("poster_path") or "",
                            "year": it.get("year") or "", "rating": 0})
            return out
        except Exception as exc:
            _log(f"my_list: {exc}", xbmc.LOGWARNING)
            return []

    if feed == "watch_history_movies":
        try:
            import richmovie_history as _hist
            movies = (_hist.watch_load().get("movies") or [])[:20]
            tc_local = _tmdb()
            out = []
            for m in movies:
                tid = m.get("tmdb") or ""
                poster = ""
                if tid and tc_local is not None:
                    # poster best-effort (Gate TMDb proxy má shared cache)
                    try:
                        poster = (tc_local.details(int(tid)) or {}).get("poster_path") or ""
                    except Exception:
                        poster = ""
                out.append({"title": m.get("title") or "Bez názvu", "tmdb_id": tid,
                            "kind": "movie", "poster_path": poster,
                            "year": m.get("year") or "", "rating": 0})
            return out
        except Exception as exc:
            _log(f"watch_history_movies: {exc}", xbmc.LOGWARNING)
            return []

    if feed in ("csfd_ratings", "csfd_watchlist", "csfd_top"):
        # Live Gate data (/v1/csfd/my/*) — chyba se propaguje (error stav v gridu)
        import richmovie_csfd_browser as _csfd
        which = {"csfd_ratings": "ratings", "csfd_watchlist": "watchlist",
                 "csfd_top": "top"}[feed]
        out = []
        for it in _csfd.get_my_feed(which):
            tid = it.get("tmdb_id")
            if not tid:
                continue  # bez TMDb mapování není detail (resolve doplní později)
            tm = it.get("tmdb") or {}
            pct = it.get("rating_pct")
            title = it.get("title") or ""
            if feed != "csfd_watchlist" and pct is not None:
                title = f"{title}  [COLOR FF3E9BF0]{int(pct)}%[/COLOR]"
            out.append({"title": title, "tmdb_id": tid,
                        "kind": it.get("kind") or "movie",
                        "poster_path": tm.get("poster_path") or "",
                        "year": it.get("year") or "",
                        "rating": (tm.get("vote_average") or 0)})
        return out

    if feed == "ai_recs":
        try:
            ai_rail_refresh_if_stale()  # Φ5 SWR — stale cache se obnoví na pozadí
            import richmovie_ui_common as _uc
            try:
                import richmovie_history as _hist
                _dismissed = _hist.ai_dismissed_ids()
            except Exception:
                _dismissed = set()
            out = []
            # dedup_media: starší cache může obsahovat duplicity (před fixem
            # 2026-06-12 se dedup při zápisu nedělal, TTL 6 h je konzervuje)
            for r in _uc.dedup_media(_uc.load_json("rail_ai_cache.json").get("items") or []):
                _rk = (r.get("kind") or r.get("media_type") or "movie").lower()
                if "{}:{}".format(_rk, r.get("tmdb_id")) in _dismissed:
                    continue  # „už jsem viděl" — skryto
                tid = r.get("tmdb_id")
                if not tid:
                    continue
                out.append({"title": r.get("title_cs") or r.get("title") or r.get("name") or "",
                            "tmdb_id": tid, "kind": (r.get("kind") or r.get("media_type") or "movie"),
                            "poster_path": r.get("poster_path") or "", "year": r.get("year") or "",
                            "rating": r.get("rating") or 0})
            return out
        except Exception as exc:
            _log(f"ai_recs: {exc}", xbmc.LOGWARNING)
            return []

    tc = _tmdb()
    if tc is None:
        return []
    try:
        if feed == "search_all":     # kombinované hledání film + seriál
            out = []
            for it in (tc.search(q) or []):
                if it.get("id"):
                    out.append(_norm(it, "movie"))
            for it in (tc.search_tv(q) or []):
                if it.get("id"):
                    out.append(_norm(it, "tv"))
            return out
        if feed == "trending_movies":
            raw, kind = tc.trending(media_type="movie"), "movie"
        elif feed == "top_movies":
            raw, kind = tc.top_rated(), "movie"
        elif feed == "trending_tv":
            raw, kind = tc.trending_tv(), "tv"
        elif feed == "top_tv":
            raw, kind = tc.top_rated_tv(), "tv"
        elif feed == "genre_movies":
            raw, kind = tc.discover_by_genre(int(genre_id or 0)), "movie"
        elif feed == "search_movies":
            raw, kind = tc.search(q), "movie"
        elif feed == "search_tv":
            raw, kind = tc.search_tv(q), "tv"
        elif feed == "similar_movies":
            raw, kind = tc.similar_movies(int(ref_id or 0)), "movie"
        elif feed == "similar_tv":
            raw, kind = tc.similar_tv(int(ref_id or 0)), "tv"
        else:
            raw, kind = [], "movie"
        return [_norm(it, kind) for it in (raw or []) if (it.get("id") or it.get("tmdb_id"))]
    except Exception as exc:
        _log(f"get_feed({feed}): {exc}", xbmc.LOGWARNING)
        if raise_on_error:
            raise
        return []


def get_genres() -> list:
    """Seznam žánrů [{id, name}]. Best-effort."""
    tc = _tmdb()
    if tc is None:
        return []
    try:
        return tc.genres() or []
    except Exception as exc:
        _log(f"get_genres: {exc}", xbmc.LOGWARNING)
        return []
