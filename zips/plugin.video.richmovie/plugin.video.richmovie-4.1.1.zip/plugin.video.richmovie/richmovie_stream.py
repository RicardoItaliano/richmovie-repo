# -*- coding: utf-8 -*-
"""
richmovie_stream.py  --  Gate-only klient pro Stream.cz
=======================================================

GraphQL operace + SPL resolve jdou **výhradně přes Gate**
(`/v1/sources/stream/*`). Addon drží pouze orchestraci + statický seznam
kategorií. Při Gate selhání vyhodíme `StreamError` — plugin.py to
chytá v try/except a zobrazí modal. Žádný legacy direct-GraphQL fallback.

Veřejné API
-----------
get_categories()                      → list[dict]             (statická data)
get_shows(channel_id, first, after)   → (list_shows, page_info)
get_seasons(show_url_name)            → list[dict]
get_episodes(tag_id | url_name+category, first, after) → (eps, page_info)
search(query)                         → dict {"tags": [...], "episodes": [...]}
get_episode_detail(episode_id)        → dict
resolve_streams(spl_url)              → dict {hls, formats, subtitles}  (BYOC)
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
from urllib.request import Request, urlopen

from richmovie_gate_transport import GATE_URL as _GATE_URL
from richmovie_gate_transport import get_identity as _gate_get_identity


# ---------------------------------------------------------------------------
#  KONSTANTY
# ---------------------------------------------------------------------------
_TIMEOUT = 15

# 8 hlavních kategorií (hardcoded dle frontendu stream.cz — statická metadata)
CATEGORIES = [
    {"id": "VGFnOjI",         "name": "Stream Originals", "urlName": "stream",                      "category": "service"},
    {"id": "VGFnOjEyNTE1MTY", "name": "Premiery",         "urlName": "nove-porady",                 "category": "channel"},
    {"id": "VGFnOjg4MTI",     "name": "Zabava",           "urlName": "zabava",                      "category": "channel"},
    {"id": "VGFnOjEyNDA3MDg", "name": "Zpravy",           "urlName": "zpravodajstvi",               "category": "channel"},
    {"id": "VGFnOjEyNDQyNTc", "name": "Magazin",          "urlName": "magazin",                     "category": "channel"},
    {"id": "VGFnOjEyNTE4NDE", "name": "Recepty",          "urlName": "varime-jednoduse-a-chutne",   "category": "channel"},
    {"id": "VGFnOjkwNTI",     "name": "Pohadky",          "urlName": "pohadky",                     "category": "channel"},
    {"id": "VGFnOjg3NTc",     "name": "Serialy",          "urlName": "serial",                      "category": "channel"},
]


# ---------------------------------------------------------------------------
#  Exception
# ---------------------------------------------------------------------------

class StreamError(Exception):
    """Gate-side Stream.cz operace selhala. Fail-fast, žádný fallback."""


# ---------------------------------------------------------------------------
#  LOG
# ---------------------------------------------------------------------------
# 3.4.x Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log_router = _make_legacy_logger("richmovie.stream", "RichMovie/Stream")
    def _log(msg: str) -> None:
        _log_router(msg)
except Exception:
    def _log(msg: str) -> None:
        try:
            import xbmc
            xbmc.log(f"[RichMovie/Stream] {msg}", xbmc.LOGINFO)
        except Exception:
            pass


# ---------------------------------------------------------------------------
#  GATE PROXY HELPERS
# ---------------------------------------------------------------------------
def _gate_headers() -> dict:
    """Společné headers pro Gate calls — auth + version UA. Raises StreamError
    pokud identita není k dispozici (chybí Webshare login v nastavení)."""
    try:
        ws_username, ws_proof = _gate_get_identity()
    except Exception as exc:
        raise StreamError(f"Chybí RichMovie Gate identita: {exc}") from exc
    if not ws_username or not ws_proof:
        raise StreamError(
            "RichMovie Gate identita není nakonfigurovaná "
            "(chybí Webshare login v nastavení)."
        )
    try:
        import xbmcaddon
        av = xbmcaddon.Addon().getAddonInfo("version") or "dev"
    except Exception:
        av = "dev"
    return {
        "User-Agent":    f"RichMovie/{av} (+plugin.video.richmovie)",
        "Accept":        "application/json",
        "X-WS-Username": ws_username,
        "X-WS-Proof":    ws_proof,
    }


def _gate_request(method: str, path: str,
                  params: dict | None = None,
                  body: dict | None = None) -> dict:
    """Unified Gate request (GET/POST). Returns parsed dict; raises StreamError
    na libovolnou chybu."""
    qs = urllib.parse.urlencode(
        {k: v for k, v in (params or {}).items() if v is not None}
    ) if params else ""
    url = f"{_GATE_URL}{path}" + (f"?{qs}" if qs else "")

    headers = _gate_headers()
    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode("utf-8")

    # Φ3b (2026-08-08): transport přes SSOT retry vrstvu.
    # POST se tu používá pro GraphQL dotazy Stream.cz — jsou to ČTECÍ operace
    # (výpis pořadů, resolve SPL), takže se smí opakovat; proto `idempotent=True`
    # navzdory metodě POST.
    try:
        import richmovie_http as _rm_http
    except Exception as _imp_exc:  # pragma: no cover
        raise StreamError("richmovie_http neni k dispozici") from _imp_exc

    try:
        profile = _rm_http.profile_foreground().replace(timeout_s=float(_TIMEOUT))
        status, raw, _hdrs = _rm_http.request(
            url, method=method, headers=headers, data=data,
            profile=profile, idempotent=True, tag="stream",
        )
        if status != 200:
            raise StreamError(f"Gate {path} vrátil HTTP {status}.")
    except StreamError:
        raise
    except _rm_http.TransientError as exc:
        raise StreamError(f"Nelze se připojit k RichMovie Gate: {exc}") from exc
    except Exception as exc:
        raise StreamError(f"Gate fetch error {path}: {exc}") from exc

    try:
        parsed = json.loads(raw.decode("utf-8", errors="replace"))
    except Exception as exc:
        raise StreamError(
            f"Gate {path} vrátil nevalidní JSON: {exc}"
        ) from exc
    if not isinstance(parsed, dict):
        raise StreamError(
            f"Gate {path} vrátil nečekaný typ: {type(parsed).__name__}"
        )
    if parsed.get("status") != "ok":
        err = parsed.get("error") or {}
        msg = err.get("message") if isinstance(err, dict) else str(err)
        raise StreamError(msg or f"Gate {path} status={parsed.get('status')!r}")
    return parsed


def _gate_get(path: str, params: dict | None = None) -> dict:
    return _gate_request("GET", path, params=params)


def _gate_post(path: str, body: dict) -> dict:
    return _gate_request("POST", path, body=body)


# ---------------------------------------------------------------------------
#  BROWSING API (Gate-only)
# ---------------------------------------------------------------------------
def get_categories() -> list[dict]:
    """Hardcoded seznam hlavních kategorií (statická data, beze změn)."""
    return list(CATEGORIES)


def get_shows(channel_id: str, *,
              first: int = 20,
              after: str | None = None) -> tuple[list[dict], dict]:
    """Pořady v kategorii/channelu. Returns (shows, page_info)."""
    data = _gate_get(
        "/v1/sources/stream/shows",
        {"channel_id": channel_id, "first": first, "after": after},
    )
    shows = data.get("shows") or []
    page_info = data.get("page_info") or {}
    _log(f"get_shows: {channel_id} → {len(shows)} shows")
    return shows, page_info


def get_seasons(show_url_name: str) -> list[dict]:
    """Sezóny pořadu. Vrátí prázdný list, pokud pořad sezóny nemá."""
    data = _gate_get(
        "/v1/sources/stream/seasons",
        {"show_url_name": show_url_name},
    )
    seasons = data.get("seasons") or []
    _log(f"get_seasons: {show_url_name} → {len(seasons)} seasons")
    return seasons


def get_episodes(*,
                 tag_id: str | None = None,
                 url_name: str | None = None,
                 category: str | None = None,
                 first: int = 20,
                 after: str | None = None) -> tuple[list[dict], dict]:
    """Epizody tagu (show/season). Identifikace buď tag_id, nebo url_name+category."""
    data = _gate_get(
        "/v1/sources/stream/episodes",
        {"tag_id": tag_id, "url_name": url_name, "category": category,
         "first": first, "after": after},
    )
    episodes = data.get("episodes") or []
    page_info = data.get("page_info") or {}
    _log(f"get_episodes: → {len(episodes)} eps")
    return episodes, page_info


def search(query: str) -> dict:
    """Vyhledávání. Returns dict {"tags": [...], "episodes": [...]}."""
    data = _gate_get("/v1/sources/stream/search", {"q": query})
    tags = data.get("tags") or []
    episodes = data.get("episodes") or []
    _log(f"search: {query!r} → {len(tags)} tags, {len(episodes)} eps")
    return {"tags": tags, "episodes": episodes}


def get_episode_detail(episode_id: str) -> dict:
    """Detail epizody. episode_id je dotId (číselné ID)."""
    data = _gate_get(
        f"/v1/sources/stream/episode/{urllib.parse.quote(str(episode_id), safe='')}"
    )
    ep = data.get("episode") or {}
    _log(f"get_episode_detail: {episode_id} → {ep.get('name')!r}")
    return ep


# ---------------------------------------------------------------------------
#  PLAYBACK: SPL -> stream URLs
# ---------------------------------------------------------------------------
def resolve_streams(spl_url: str) -> dict:
    """Rozloží SPL URL na přehratelné streamy. BYOC streaming (klient↔CDN).

    Returns {"hls": str, "formats": [...], "subtitles": [...]}.
    POST kvůli délce SPL URL (může obsahovat dlouhý hash + parametry).
    """
    data = _gate_post("/v1/sources/stream/resolve", {"spl_url": spl_url})
    result = {
        "hls":       data.get("hls") or "",
        "formats":   data.get("formats") or [],
        "subtitles": data.get("subtitles") or [],
    }
    _log(
        f"resolve_streams: hls={'yes' if result['hls'] else 'no'}, "
        f"{len(result['formats'])} mp4, {len(result['subtitles'])} subs"
    )
    return result
