# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_sync_queue — sdílené primitivum kanálů synchronizace s Gate
 (plán PLAN_profile_data_sync_20260905, DP4; extrakce z richmovie_state_sync 3.5.134)
═══════════════════════════════════════════════════════════════════════════════

Dva kanály sdílejí jeden protokol: stav Pokračovat/✔ (`richmovie_state_sync`,
`/v1/profiles/state`) a osobní kolekce profilu (`richmovie_profile_items`,
`/v1/profiles/items`). Tady je všechno, co je pro oba stejné:

  • `SyncQueue`  – trvanlivá odchozí fronta v osobním adresáři profilu (soubor pod
    `FileLock`, LWW podle klíče položky = novější lokální změna přepíše starší ve
    frontě, strop položek, karanténa autoritativně odmítnutých položek).
  • `flush_queue` – jeden push: tělo VŽDY s identitou (`gate_transport.build_common_fields`,
    incident 3.5.142: tělo bez identity = 422 a stav se nikdy nesdílel), klasifikace
    odpovědi (2xx s `accepted` → fronta pryč + `newer` se aplikuje; 404 `profile_not_found`
    → fronta zahozena; 422 per položka (Pydantic `loc` = body.items[i]) → karanténa
    JEN těch položek; 2xx/422 bez kontraktního tvaru → CONTRACT = chyba NAŠE, volající
    dá backoff; transport/5xx/429/401-403 → FAILED, fronta zůstává — R2/R2b).
  • `SyncCursor` + `pull_since` + `pull_pages` – deltový pull s kurzorem `version`,
    překryvem (`PULL_OVERLAP`) a plnou rekonciliací jednou za `FULL_RECONCILE_S`
    (sekvence verzí na Gate není commit-ordered).

Kanál dodá jen: klíč položky, čas položky, mapování lokálních souborů ↔ položky a
aplikaci `newer`/pull výsledků. Žádný kanál nesmí mít vlastní kopii téhle logiky.
Bez Kodi (harness) funguje beze změny — cesty přes `richmovie_paths`, zápisy přes
`richmovie_atomic`.
"""
from __future__ import annotations

import datetime as _dt
import os
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

LOCK_STALE_S = 10.0             # krádež zámku fronty až po 10 s (pomalé TV boxy)
FULL_RECONCILE_S = 6 * 3600     # verze ze sekvence ≠ pořadí commitů: jednou za 6 h pull od 0 (LWW = idempotentní)
PUSH_BATCH_MAX = 200            # = Gate PUSH_MAX_ITEMS (oba kanály)
# Překryv pullu MUSÍ být větší než dávka pushe (cross-check Pro A P4 / C P4, 05.09.2026): jiný klient
# si alokuje 200 verzí ze sekvence a commitne později — pull mezitím posune kurzor za ně a s překryvem
# 50 by 150 položek minul až do plné rekonciliace. Cena: 250 řádků navíc per pull; sloučení je no-op
# pro shodné položky (`_same` / LWW), takže jen síť.
PULL_OVERLAP = PUSH_BATCH_MAX + 50
PULL_PAGES_MAX = 5

OUTCOME_SENT = "sent"
OUTCOME_EMPTY = "empty"
OUTCOME_SKIPPED = "skipped"
OUTCOME_FAILED = "failed"          # transport / 5xx / 429 — fronta zůstává
OUTCOME_CONTRACT = "contract"      # odpověď bez kontraktního tvaru — fronta zůstává, volající dá backoff
OUTCOME_DROPPED = "dropped"        # profil v Gate neexistuje — fronta zahozena
OUTCOME_APPLIED = "applied"
OUTCOME_UNCHANGED = "unchanged"

LogFn = Callable[..., None]


def _noop_log(msg: str, level: int = 1) -> None:   # pragma: no cover
    return None


# ── čas ──────────────────────────────────────────────────────────────────────

def to_iso(ts: float) -> str:
    return _dt.datetime.fromtimestamp(float(ts), _dt.timezone.utc).isoformat()


def to_epoch(value: Any) -> float:
    """ISO 8601 (`Z` i `+00:00`, naivní = UTC) nebo číslo → epoch; nevalidní = 0.0."""
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    try:
        from richmovie_helpers import parse_server_datetime   # SSOT formátů času Gate
        d = parse_server_datetime(str(value))
        if d is not None:
            if d.tzinfo is None:
                d = d.replace(tzinfo=_dt.timezone.utc)
            return d.timestamp()
    except Exception:
        pass
    try:
        text = str(value).strip()
        if not text:
            return 0.0
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        parsed = _dt.datetime.fromisoformat(text)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=_dt.timezone.utc)
        return parsed.timestamp()
    except (TypeError, ValueError):
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0


# ── fronta ───────────────────────────────────────────────────────────────────

class SyncQueue:
    """Trvanlivá odchozí fronta jednoho kanálu. `key_fn(item)` = klíč pro LWW ve
    frontě, `ts_fn(item)` = epoch změny položky."""

    def __init__(self, filename: str, key_fn: Callable[[Dict[str, Any]], str],
                 ts_fn: Callable[[Dict[str, Any]], float], *, max_items: int, quarantine_max: int,
                 name: str, log: Optional[LogFn] = None) -> None:
        self.filename = filename
        self.key_fn = key_fn
        self.ts_fn = ts_fn
        self.max_items = int(max_items)
        self.quarantine_max = int(quarantine_max)
        self.name = name
        self.log = log or _noop_log
        self._count_cache = {"path": "", "mtime": None, "size": None, "count": 0}

    # -- soubor --------------------------------------------------------------
    def path(self) -> str:
        import richmovie_paths
        return str(richmovie_paths.personal_path(self.filename))

    def lock(self, path: Optional[str] = None):
        import richmovie_atomic as _atomic
        return _atomic.FileLock((path or self.path()) + ".lock", stale_s=LOCK_STALE_S)

    @staticmethod
    def empty() -> Dict[str, Any]:
        return {"schema": 1, "items": {}, "quarantine": []}

    def load(self, path: Optional[str] = None) -> Dict[str, Any]:
        import richmovie_atomic as _atomic
        data, _state = _atomic.read_json(path or self.path(), None, name=self.name, expected_type=dict)
        if not isinstance(data, dict) or not isinstance(data.get("items"), dict):
            return self.empty()
        data.setdefault("quarantine", [])
        data["items"] = self.rekey(data["items"])
        return data

    def rekey(self, items: Dict[str, Any]) -> Dict[str, Any]:
        """Položky pod klíčem AKTUÁLNÍ `key_fn` (čisté). Fronta uložená starší verzí doplňku mohla mít jiný
        tvar klíče (mig 0038: klíč fronty stavu nese osu) — bez překlíčování by `ack` odeslanou položku nikdy
        nenašel a posílala by se navěky. Při kolizi vyhrává novější (`ts_fn`)."""
        out: Dict[str, Any] = {}
        for it in items.values():
            if not isinstance(it, dict):
                continue
            try:
                self.put(out, it)
            except Exception:
                continue
        return out

    def save(self, data: Dict[str, Any], path: Optional[str] = None) -> bool:
        import richmovie_atomic as _atomic
        return bool(_atomic.write_json(path or self.path(), data))

    # -- položky --------------------------------------------------------------
    def put(self, items: Dict[str, Any], it: Dict[str, Any]) -> bool:
        """LWW ve frontě: starší změna téhož klíče se nezařadí. True = zapsáno."""
        key = self.key_fn(it)
        old = items.get(key)
        if old and self.ts_fn(old) > self.ts_fn(it):
            return False
        items[key] = it
        return True

    def enqueue(self, it: Dict[str, Any]) -> bool:
        try:
            path = self.path()
            with self.lock(path):
                q = self.load(path)
                self.put(q["items"], it)
                if len(q["items"]) > self.max_items:
                    oldest = sorted(q["items"].items(), key=lambda kv: self.ts_fn(kv[1]))
                    for k, _v in oldest[:len(q["items"]) - self.max_items]:
                        q["items"].pop(k, None)
                return self.save(q, path)
        except Exception as exc:
            self.log("%s enqueue failed: %r" % (self.name, exc), 3)
            return False

    def enqueue_many(self, items: List[Dict[str, Any]], path: Optional[str] = None) -> int:
        """Hromadné zařazení pod jedním zámkem (seed lokálních souborů, tombstony při „smazat vše").
        `path` = fronta JINÉHO profilu (import archivu majiteli, když je aktivní jiný profil — DP3)."""
        if not items:
            return 0
        try:
            path = path or self.path()
            with self.lock(path):
                q = self.load(path)
                n = sum(1 for it in items if self.put(q["items"], it))
                dropped = max(0, len(q["items"]) - self.max_items)
                if dropped:
                    oldest = sorted(q["items"].items(), key=lambda kv: self.ts_fn(kv[1]))
                    for k, _v in oldest[:dropped]:
                        q["items"].pop(k, None)
                    self.log("%s: fronta nad strop %d → %d nejstarších položek zahozeno" % (self.name, self.max_items, dropped), 2)
                if not self.save(q, path):
                    self.log("%s enqueue_many: zápis fronty selhal" % self.name, 3)
                    return -1   # volající NESMÍ považovat položky za zařazené (Fable P1-2)
                return n - dropped
        except Exception as exc:
            self.log("%s enqueue_many failed: %r" % (self.name, exc), 3)
            return -1

    def snapshot(self, n: int, path: Optional[str] = None) -> List[Dict[str, Any]]:
        path = path or self.path()
        with self.lock(path):
            q = self.load(path)
            items = sorted(q["items"].values(), key=self.ts_fn)
        return items[:max(0, int(n))]

    def ack(self, batch: List[Dict[str, Any]], *, done: Optional[Set[int]], rejected: Dict[int, str],
            path: Optional[str] = None) -> None:
        """Po odpovědi Gate: `done` indexy (None = všechny) z fronty pryč, pokud mezitím
        nepřibyla novější změna téhož klíče; `rejected` {index: kód} → karanténa
        (autoritativní odmítnutí položky = dohledatelná, fronta se odblokuje).
        `path` = fronta, ze které dávka VZEŠLA (Fable P1-1: po přepnutí profilu během POSTu
        by se jinak popnuly neodeslané položky NOVÉHO profilu se stejným klíčem)."""
        path = path or self.path()
        with self.lock(path):
            q = self.load(path)
            for i, it in enumerate(batch):
                if done is not None and i not in done and i not in rejected:
                    continue
                key = self.key_fn(it)
                cur = q["items"].get(key)
                if cur is None or self.ts_fn(cur) > self.ts_fn(it):
                    continue  # mezitím přibyl novější stav — zůstává
                q["items"].pop(key, None)
                if i in rejected:
                    q["quarantine"].append({"item": cur, "at": to_iso(time.time()), "code": rejected[i]})
            q["quarantine"] = q["quarantine"][-self.quarantine_max:]
            self.save(q, path)

    def requeue_quarantined(self, fix_fn: Callable[[Dict[str, Any]], Optional[Dict[str, Any]]],
                            path: Optional[str] = None) -> int:
        """Vrátí do fronty položky karantény, které `fix_fn` umí opravit (vrací opravenou položku, None = ne).
        Pro vady, které byly NAŠE a nová verze je u zdroje odstranila (mig 0038: `completion > 1`). Ostatní
        zůstávají v karanténě (dohledatelné). Novější položka téhož klíče ve frontě vyhrává (`put`)."""
        path = path or self.path()
        try:
            with self.lock(path):
                q = self.load(path)
                kept, back = [], 0
                for entry in q.get("quarantine") or []:
                    item = entry.get("item") if isinstance(entry, dict) else None
                    fixed = fix_fn(item) if isinstance(item, dict) else None
                    if fixed is None:
                        kept.append(entry)
                        continue
                    self.put(q["items"], fixed)
                    back += 1
                if not back:
                    return 0
                q["quarantine"] = kept
                return back if self.save(q, path) else 0
        except Exception as exc:
            self.log("%s requeue_quarantined failed: %r" % (self.name, exc), 3)
            return 0

    def drop_all(self, path: Optional[str] = None) -> None:
        path = path or self.path()
        with self.lock(path):
            self.save(self.empty(), path)

    def pending_count(self) -> int:
        """Počet položek ve frontě; parsuje JSON jen když se soubor změnil (tik služby každých 5 s)."""
        try:
            path = self.path()
            try:
                st = os.stat(path)
            except OSError:
                return 0
            c = self._count_cache
            if c["path"] == path and c["mtime"] == st.st_mtime_ns and c["size"] == st.st_size:
                return int(c["count"])
            count = len(self.load(path).get("items") or {})
            self._count_cache = {"path": path, "mtime": st.st_mtime_ns, "size": st.st_size, "count": count}
            return count
        except Exception:
            return 0


# ── klasifikace odpovědi Gate ────────────────────────────────────────────────

def error_code(parsed: Any) -> str:
    if not isinstance(parsed, dict):
        return ""
    err = parsed.get("detail", parsed.get("error"))
    if isinstance(err, dict):
        err = err.get("error", err)
    if isinstance(err, dict):
        return str(err.get("code") or "")
    return ""


def rejection_reasons(status: int, parsed: Any) -> Optional[Dict[int, str]]:
    """{index položky: důvod}, které Gate autoritativně odmítl: 2xx `errors[{index, code, message}]` nebo
    422 s Pydantic `loc` = ["body","items",<i>,<pole>…] (+ `msg`). None = odmítnutí není per položka.
    Důvod jde do karantény i do logu — do 10.10.2026 zněl log jen „422 → 1 položek v karanténě“ a nešlo
    dohledat, CO Gate odmítl (✔ s `completion > 1`, nález M3)."""
    if not isinstance(parsed, dict):
        return None
    out: Dict[int, str] = {}
    if 200 <= int(status) < 300:
        for e in parsed.get("errors") or []:
            if isinstance(e, dict) and isinstance(e.get("index"), int):
                out[int(e["index"])] = ("%s: %s" % (e.get("code") or "rejected", e.get("message") or "")).strip(": ")[:160]
        return out
    if int(status) == 422:
        detail = parsed.get("detail")
        if not isinstance(detail, list):
            return None
        for e in detail:
            loc = e.get("loc") if isinstance(e, dict) else None
            if isinstance(loc, list) and len(loc) >= 3 and loc[1] == "items" and isinstance(loc[2], int):
                field_name = ".".join(str(x) for x in loc[3:]) or "item"
                out[int(loc[2])] = ("http_422 %s: %s" % (field_name, e.get("msg") or ""))[:160]
        return out or None   # jen chyby mimo položky (schema_version, identita) = kontrakt
    return None


def rejected_indexes(status: int, parsed: Any) -> Optional[List[int]]:
    """Indexy autoritativně odmítnutých položek (viz `rejection_reasons`)."""
    reasons = rejection_reasons(status, parsed)
    return None if reasons is None else sorted(reasons)


def describe_rejections(batch: List[Dict[str, Any]], reasons: Dict[int, str], key_fn: Callable[[Dict[str, Any]], str],
                        limit: int = 3) -> str:
    """Čitelný výčet „klíč — důvod“ pro log karantény (prvních `limit`)."""
    parts = []
    for i in sorted(reasons)[:max(1, int(limit))]:
        try:
            key = key_fn(batch[i]) if 0 <= i < len(batch) else "#%d" % i
        except Exception:
            key = "#%d" % i
        parts.append("%s — %s" % (key, reasons[i]))
    more = len(reasons) - len(parts)
    return "; ".join(parts) + ((" (+%d)" % more) if more > 0 else "")


def identity_body(extra: Dict[str, Any]) -> Dict[str, Any]:
    """Tělo POST s identitou z SSOT `gate_transport.build_common_fields()` (3.5.143)."""
    from richmovie_gate_transport import build_common_fields
    body = dict(build_common_fields())
    body.update(extra)
    return body


def flush_queue(queue: SyncQueue, *, endpoint: str, body_builder: Callable[[List[Dict[str, Any]]], Dict[str, Any]],
                transport_post: Callable[[str, Dict[str, Any], float], Tuple[int, Any]], timeout: float,
                reason: str, batch_max: int, on_newer: Callable[[List[Dict[str, Any]]], int],
                log: LogFn, flush_lock: threading.Lock) -> str:
    """Jeden push dávky z fronty. Vrací OUTCOME_*. Tělo staví `body_builder(batch)` (přes
    `identity_body`), odpověď klasifikuje jednotně pro oba kanály."""
    if not flush_lock.acquire(blocking=False):
        return OUTCOME_SKIPPED
    try:
        # Fable P1-1: fronta i tělo patří profilu aktivnímu TEĎ; po síťovém I/O (až 20 s) může být
        # aktivní jiný profil → ack/apply by šly do cizího adresáře. Cesta se váže na začátku a po
        # I/O se porovná; při změně se výsledek zahodí (Gate je idempotentní, příště znovu).
        path = queue.path()
        snapshot = queue.snapshot(batch_max, path)
        if not snapshot:
            return OUTCOME_EMPTY
        batch = snapshot
        body = body_builder(batch)
        try:
            status, parsed = transport_post(endpoint, body, timeout)
        except Exception as exc:
            log("push %s: transport %r → fronta zůstává (%d položek)" % (reason, exc, len(batch)), 2)
            return OUTCOME_FAILED
        if queue.path() != path:
            log("push %s: profil se během odesílání změnil → výsledek zahozen, fronta původního profilu zůstává" % reason, 2)
            return OUTCOME_SKIPPED
        status = int(status or 0)
        if 200 <= status < 300 and isinstance(parsed, dict) and "accepted" in parsed:
            rejected = rejection_reasons(status, parsed) or {}
            queue.ack(batch, done=None, rejected=rejected, path=path)
            newer = [n for n in (parsed.get("newer") or []) if isinstance(n, dict)]
            applied = on_newer(newer) if newer else 0
            log("push %s: %d přijato%s%s" % (
                reason, int(parsed.get("accepted") or 0),
                (", %d starších než Gate → %d sloučeno" % (len(newer), applied)) if newer else "",
                (", %d v karanténě: %s" % (len(rejected), describe_rejections(batch, rejected, queue.key_fn)))
                if rejected else ""), 2 if rejected else 1)
            return OUTCOME_SENT
        if status == 404 and error_code(parsed) == "profile_not_found":
            queue.drop_all(path)
            log("push %s: profil v Gate neexistuje → fronta zahozena" % reason, 2)
            return OUTCOME_DROPPED
        if status == 422:
            reasons = rejection_reasons(status, parsed)
            if reasons:
                queue.ack(batch, done=set(), rejected=reasons, path=path)
                log("push %s: 422 → %d položek v karanténě: %s" % (
                    reason, len(reasons), describe_rejections(batch, reasons, queue.key_fn)), 2)
                return OUTCOME_SENT
            log("push %s: 422 bez tvaru per položka (kontrakt) → fronta zůstává: %s" % (reason, str(parsed)[:200]), 4)
            return OUTCOME_CONTRACT
        if 200 <= status < 300:
            log("push %s: 2xx bez klíče accepted (kontrakt) → fronta zůstává" % reason, 4)
            return OUTCOME_CONTRACT
        if 400 <= status < 500 and status not in (408, 429):
            # 400/401/403/409 (profile_required, setup_required, identita) = náš kontrakt/stav, ne
            # infrastruktura — bez backoffu by se totéž opakovalo každých 15 s (Fable P3)
            log("push %s: HTTP %s (%s) → kontrakt, backoff; fronta zůstává" % (reason, status, error_code(parsed) or "-"), 3)
            return OUTCOME_CONTRACT
        log("push %s: HTTP %s → fronta zůstává" % (reason, status), 2)
        return OUTCOME_FAILED
    except Exception as exc:
        log("push %s failed: %r" % (reason, exc), 3)
        return OUTCOME_FAILED
    finally:
        flush_lock.release()


# ── kurzor deltového pullu ───────────────────────────────────────────────────

def pull_since(cursor: Dict[str, Any], profile_id: Optional[int], now: Optional[float] = None,
               *, full_reconcile_s: float = FULL_RECONCILE_S, overlap: int = PULL_OVERLAP) -> int:
    """Odkud pullovat (čisté): 0 při změně profilu nebo když od poslední plné
    rekonciliace uplynulo ≥ `full_reconcile_s`; jinak uložený kurzor − překryv."""
    now = time.time() if now is None else now
    if cursor.get("profile_id") != profile_id:
        return 0
    if now - float(cursor.get("full_at") or 0) >= full_reconcile_s:
        return 0
    return max(0, int(cursor.get("version") or 0) - overlap)


class SyncCursor:
    def __init__(self, filename: str, *, name: str) -> None:
        self.filename = filename
        self.name = name

    def path(self) -> str:
        import richmovie_paths
        return str(richmovie_paths.personal_path(self.filename))

    def load(self, path: Optional[str] = None) -> Dict[str, Any]:
        import richmovie_atomic as _atomic
        data, _state = _atomic.read_json(path or self.path(), None, name=self.name, expected_type=dict)
        return data if isinstance(data, dict) else {}

    def save(self, version: int, profile_id: Optional[int], *, full_at: Optional[float] = None,
             extra: Optional[Dict[str, Any]] = None, touch_pull: bool = True,
             path: Optional[str] = None) -> None:
        """`touch_pull=False` = jen značka (seed) — `pulled_at` zůstává; čerstvé zařízení se pozná
        právě podle chybějícího `pulled_at` (plná rekonciliace bez tombstonů). `path` = kurzor
        profilu, pro který pull začal (Fable P1-1)."""
        import richmovie_atomic as _atomic
        path = path or self.path()
        prev = self.load(path)
        pulled_at = time.time() if touch_pull else float(prev.get("pulled_at") or 0)
        data = {"schema": 1, "version": int(version), "profile_id": profile_id, "pulled_at": pulled_at,
                "full_at": float(full_at if full_at is not None else prev.get("full_at") or 0)}
        for k, v in (prev.get("extra") or {}).items():
            data.setdefault("extra", {})[k] = v
        if extra:
            data.setdefault("extra", {}).update(extra)
        _atomic.write_json(path, data)

    def since(self, profile_id: Optional[int], now: Optional[float] = None) -> int:
        return pull_since(self.load(), profile_id, now)

    def last_pull_age_s(self) -> float:
        try:
            return max(0.0, time.time() - float(self.load().get("pulled_at") or 0))
        except Exception:
            return 1e9


PULL_APPLY_BUDGET_S = 90.0      # horní odhad sloučení dávky na pomalém TV boxu (5 stránek × 200 položek, dávkové RMW)


def apply_error_blocks_cursor(exc: BaseException) -> bool:
    """Výjimka při slučování stažené dávky: má kurzor pullu stát? (SSOT pro oba kanály, Fable F4 17.09.2026)

    ANO = chyba prostředí (I/O, paměť): data se nezapsala, dávka se musí zopakovat (R2).
    NE  = logická chyba nad konkrétní položkou (neočekávaný tvar, parsování): položka se přeskočí
          s ERROR logem a kurzor jde dál (R2b). Data zůstávají na Gate (zdroj pravdy) a nabídne je
          plná rekonciliace. Jinak by jedna vadná položka zastavila pull zařízení navždy."""
    return isinstance(exc, (OSError, MemoryError))


def pull_claim_ttl(timeout: float, max_pages: int) -> float:
    """TTL meziprocesového claimu pullu: stažení všech stránek (timeout × stránky) + sloučení.
    Claim je pojistka proti souběhu, ne zámek dat — sirotek (proces zabit) vyprší sám."""
    return max(1, int(max_pages)) * max(1.0, float(timeout)) + PULL_APPLY_BUDGET_S


def pull_queue(*, endpoint: str, cursor: "SyncCursor", profile_id: Optional[int],
               transport_get: Callable[..., Dict[str, Any]],
               on_apply: Callable[[List[Dict[str, Any]]], Tuple[int, bool]], log: LogFn,
               pull_lock: threading.Lock, reason: str, timeout: float, max_pages: int = PULL_PAGES_MAX,
               include_param: Optional[str] = None, quick: bool = False,
               claim_name: Optional[str] = None) -> Tuple[int, str]:
    """Jeden deltový pull + sloučení — SSOT orchestrace pro oba kanály (cross-check Pro C P15):
    kurzor → `since` (překryv / plná rekonciliace) → stránky NAJEDNOU → `on_apply(items)` →
    (počet změn, ok) → kurzor se posune JEN po úspěšném sloučení (Pro B P16.1: vadná dávka by
    jinak zmizela do další plné rekonciliace). Zařízení s cache si při plné rekonciliaci vyžádá
    i tombstony/`removed` (`include_param`). Transport/5xx: kurzor beze změny (R2).

    `claim_name` (3.5.151): meziprocesový claim (`richmovie_guard`) — `pull_lock` je jen
    `threading.Lock` jednoho procesu, přitom pulluje služba i každé spuštění hlavního menu.
    Obsazený claim = přeskočit (jiný proces právě slučuje totéž)."""
    if not pull_lock.acquire(blocking=False):
        return 0, OUTCOME_SKIPPED
    claim_token = None
    if claim_name:
        try:
            import richmovie_guard as _guard
            claim_token = _guard.claim(claim_name, pull_claim_ttl(timeout, max_pages))
        except Exception as exc:
            log("pull %s: claim %s nedostupný (%r) → pokračuji bez něj" % (reason, claim_name, exc), 2)
            claim_token = ""
        if claim_token is None:
            pull_lock.release()
            log("pull %s: %s právě slučuje jiný proces → přeskočeno" % (reason, claim_name), 0)
            return 0, OUTCOME_SKIPPED
    try:
        cur_path = cursor.path()   # Fable P1-1: kurzor a apply patří profilu aktivnímu na začátku
        cur = cursor.load(cur_path)
        since = pull_since(cur, profile_id)
        full = since == 0
        cached = bool(cur.get("pulled_at")) and cur.get("profile_id") == profile_id
        extra = {include_param: 1} if (full and cached and include_param) else None
        try:
            collected, version = pull_pages(endpoint, since, profile_id, transport_get, timeout=timeout,
                                            quick=quick, max_pages=max_pages, extra_params=extra)
        except Exception as exc:
            log("pull %s: %r" % (reason, exc), 2)   # transport / 403 / 5xx: kurzor zůstává (R2)
            return 0, OUTCOME_FAILED
        if cursor.path() != cur_path:
            log("pull %s: profil se během stahování změnil → data zahozena (kurzor původního profilu beze změny)" % reason, 2)
            return 0, OUTCOME_SKIPPED
        applied, ok = on_apply(collected) if collected else (0, True)
        if not ok:
            log("pull %s: sloučení selhalo → kurzor zůstává (verze %d), příště znovu" % (reason, version), 3)
            return applied, OUTCOME_FAILED
        cursor.save(version, profile_id, full_at=(time.time() if full else None), path=cur_path)
        if applied:
            log("pull %s: %d změn z jiných zařízení sloučeno (version %d)" % (reason, applied, version))
        return applied, (OUTCOME_APPLIED if applied else OUTCOME_UNCHANGED)
    finally:
        if claim_name and claim_token:
            try:
                import richmovie_guard as _guard
                _guard.release(claim_name, claim_token)
            except Exception:
                pass
        pull_lock.release()


def pull_pages(endpoint: str, since: int, profile_id: Optional[int],
               transport_get: Callable[..., Dict[str, Any]], *, timeout: float, quick: bool,
               max_pages: int = PULL_PAGES_MAX, extra_params: Optional[Dict[str, Any]] = None
               ) -> Tuple[List[Dict[str, Any]], int]:
    """Stáhne všechny stránky od `since` (vyhazuje při transportní chybě — kurzor
    volající nechá beze změny, R2). Vrací (položky, nová verze)."""
    collected: List[Dict[str, Any]] = []
    version = int(since)
    for _page in range(max(1, int(max_pages))):
        params: Dict[str, Any] = {"since": version}
        if profile_id:
            params["profile_id"] = profile_id
        if extra_params:
            params.update(extra_params)
        data = transport_get(endpoint, params, timeout, quick=quick)
        collected.extend(i for i in (data.get("items") or []) if isinstance(i, dict))
        version = int(data.get("version") or version)
        if not data.get("has_more"):
            break
    return collected, version
