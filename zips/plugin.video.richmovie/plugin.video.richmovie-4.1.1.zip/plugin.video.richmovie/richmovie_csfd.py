# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – ČSFD.cz (Gate-only thin client, beta.6)
───────────────────────────────────────────────────────────────────────────────
Scraping + TMDb enrichment probíhá výhradně na Gate NAS. Addon je pure
konzument pre-enriched dat:

  • GET /tv-tips → vrátí tipy už s `tmdb_id`, `poster_path`, `rating`,
                   `overview`, `runtime`, atd. Scraper běží 1× denně,
                   enrichment se provádí tam.

Addon drží jen:
  • Gate call + clean error propagation (CSFDError)
  • 24h lokální disk cache jako performance optimization
  • Adapter Gate-response → Kodi ListItem-compatibile dict

Nedělá:
  • žádný per-user TMDb matching (to je Gate work)
  • žádný alt-titles fetch (to je Gate work)
  • žádný HTML scraping (to je Gate work)
  • žádný legacy direct fallback (fail-fast dle CLAUDE.md)

Historie:
  beta.4: thin-client migrace, tipy fetchovány z Gate jednou denně
  beta.5: fail-fast, legacy fallback odstraněn, multi-day (dnes+zítra+pozítří)
  beta.6: TMDb enrichment přesunut na Gate, addon = pure adapter (−237 LOC)
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

import xbmc
try:
    import xbmcaddon as _xbmcaddon
    _ADDON_VERSION = _xbmcaddon.Addon().getAddonInfo("version") or "dev"
except Exception:
    _ADDON_VERSION = "dev"

from richmovie_gate_transport import GATE_URL as _GATE_URL


# =========================
# KONSTANTY
# =========================
_CACHE_FILE = "csfd_tv_tips_cache.json"
_DEFAULT_TTL_SECONDS = 24 * 3600
_HTTP_TIMEOUT = 15


# =========================
# EXCEPTION
# =========================

class CSFDError(Exception):
    """Gate-side ČSFD operace selhala. Fail-fast, žádný fallback."""


# =========================
# LOG
# =========================
# 3.4.0 Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.csfd", "RichMovie/CSFD")
except Exception:
    def _log(msg: str, level: int = xbmc.LOGINFO, *, context: dict | None = None) -> None:
        try:
            xbmc.log(f"[RichMovie/CSFD] {msg}", level)
        except Exception:
            pass


# =========================
# GATE CLIENT (public /tv-tips)
# =========================

def _gate_get_tv_tips(*, background: bool = False) -> Dict[str, Any]:
    """GET /tv-tips (public endpoint, no auth needed).

    `background=True` = volání ze služby (`richmovie_warm`): profil
    `profile_background()` místo UI profilu (3.5.131, cross-check Pro PB7).
    Raises CSFDError on any transport/parse/upstream failure.
    """
    headers = {
        "User-Agent": f"RichMovie/{_ADDON_VERSION} (+plugin.video.richmovie)",
        "Accept": "application/json",
        "Accept-Encoding": "identity",
    }
    url = f"{_GATE_URL}/tv-tips"

    # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. GET na public endpoint
    # je čistě idempotentní, takže se smí opakovat bez jakýchkoli výhrad.
    # Timeout zůstává na `_HTTP_TIMEOUT` — profil se jen doplní o rozpočet.
    try:
        import richmovie_http as _rm_http
    except Exception as _imp_exc:  # pragma: no cover
        raise CSFDError("richmovie_http neni k dispozici") from _imp_exc

    try:
        base_profile = _rm_http.profile_background() if background else _rm_http.profile_foreground()
        profile = base_profile.replace(timeout_s=float(_HTTP_TIMEOUT))
        status, body, _hdrs = _rm_http.request(
            url, headers=headers, profile=profile, tag="csfd_tips",
        )
        if status != 200:
            raise CSFDError(f"Gate /tv-tips vrátil HTTP {status}.")
    except CSFDError:
        raise
    except _rm_http.TransientError as exc:
        raise CSFDError(f"Nelze se připojit k RichMovie Gate: {exc}") from exc
    except Exception as exc:
        raise CSFDError(f"Gate /tv-tips error: {exc}") from exc

    try:
        data = json.loads(body.decode("utf-8", errors="replace"))
    except Exception as exc:
        raise CSFDError(f"Gate /tv-tips vrátil nevalidní JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise CSFDError(
            f"Gate /tv-tips vrátil nečekaný typ: {type(data).__name__}"
        )
    return data


# =========================
# CACHE (performance optimization)
# =========================
def _cache_path(profile_dir: Path) -> Path:
    return Path(profile_dir) / _CACHE_FILE


def _load_cache(profile_dir: Path) -> Optional[Dict[str, Any]]:
    p = _cache_path(profile_dir)
    try:
        if not p.exists():
            return None
        raw = p.read_text(encoding="utf-8", errors="replace")
        data = json.loads(raw or "{}")
        if isinstance(data, dict):
            return data
    except Exception as e:
        _log(f"CACHE_READ_WARN: {e}", xbmc.LOGWARNING)
    return None


def _save_cache(profile_dir: Path, data: Dict[str, Any]) -> None:
    """Trvanlivý atomický zápis (SSOT `richmovie_atomic`, 3.5.131 — dřív
    `write_text`, tj. při pádu Kodi uprostřed zápisu půlka JSONu)."""
    p = _cache_path(profile_dir)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        import richmovie_atomic as _atomic
        if not _atomic.write_json(str(p), data):
            _log("CACHE_WRITE_WARN: atomic write failed", xbmc.LOGWARNING)
    except Exception as e:
        _log(f"CACHE_WRITE_WARN: {e}", xbmc.LOGWARNING)


def get_cached_tv_tips(profile_dir: Path, *, max_age_s: int) -> List[Dict[str, Any]]:
    """Raw TV tipy POUZE z lokální cache — 0 síťových volání (3.5.131, hlášky při
    hledání). Prázdný seznam, když cache chybí, je poškozená nebo starší než
    `max_age_s` (stale je pro hlášku v pořádku, proto volající posílá dny, ne hodiny)."""
    cache = _load_cache(Path(profile_dir))
    if not isinstance(cache, dict):
        return []
    ts = cache.get("ts")
    tips = cache.get("tips")
    if not isinstance(ts, (int, float)) or not isinstance(tips, list) or not tips:
        return []
    age_s = time.time() - float(ts)
    if age_s > max(0, int(max_age_s)):
        return []
    return age_adjusted_tips([t for t in tips if isinstance(t, dict)], age_s)


def age_adjusted_tips(tips: List[Dict[str, Any]], age_s: float) -> List[Dict[str, Any]]:
    """`day_offset` je relativní k datu scrapu — u 2 dny staré cache je „dnes“
    už minulost. Posune offset o stáří cache (celé dny) a vypustí tipy, jejichž
    den už proběhl (3.5.131, cross-check Pro PB6). Čistá funkce (harness)."""
    shift = int(max(0.0, age_s) // 86400)
    out: List[Dict[str, Any]] = []
    for t in tips:
        try:
            off = int(t.get("day_offset") or 0) - shift
        except (TypeError, ValueError):
            off = -shift
        if off < 0:
            continue
        adj = dict(t)
        adj["day_offset"] = off
        out.append(adj)
    return out


def refresh_tv_tips_cache(profile_dir: Path, *, ttl_seconds: int = _DEFAULT_TTL_SECONDS) -> int:
    """Doplní/obnoví cache TV tipů (volá služba `richmovie_warm`). Když je cache
    čerstvá (< ttl), neproběhne žádné HTTP. Vrací počet tipů v cache."""
    tips = get_tv_tips(profile_dir=Path(profile_dir), ttl_seconds=ttl_seconds, background=True)
    return len(tips)


_DAY_LABELS = {0: "Dnes v TV", 1: "Zítra v TV", 2: "Pozítří v TV"}


def format_tip_line(tip: Dict[str, Any]) -> str:
    """SSOT textu ČSFD TV tipu pro dialog hledání (3.5.131):
    `📺 Dnes v TV: Sedm životů (2008) · ★ 7.6 · 123 min`.
    Vrací "" pro tip bez názvu."""
    # ČSFD název = jméno, pod kterým to TV vysílá (cross-check Pro PB13); TMDb
    # název jen když ČSFD chybí.
    title = (tip.get("title") or tip.get("title_tmdb") or "").strip()
    if not title:
        return ""
    try:
        day_offset = int(tip.get("day_offset") or 0)
    except (TypeError, ValueError):
        day_offset = 0
    day = _DAY_LABELS.get(day_offset, "V TV")
    parts = [title]
    try:
        year = int(tip.get("year") or 0)
    except (TypeError, ValueError):
        year = 0
    if year > 0:
        parts[0] = f"{title} ({year})"
    try:
        rating = float(tip.get("rating") or 0)
    except (TypeError, ValueError):
        rating = 0.0
    if rating > 0:
        parts.append(f"★ {rating:.1f}")
    try:
        runtime = int(tip.get("runtime") or 0)
    except (TypeError, ValueError):
        runtime = 0
    if runtime > 0:
        parts.append(f"{runtime} min")
    return f"📺 {day}: " + " · ".join(parts)


# =========================
# ADAPTER — Gate response → Kodi item dict
# =========================
def _gate_tip_to_item(tip: Dict[str, Any]) -> Dict[str, Any]:
    """Převede pre-enriched Gate tip na Kodi ListItem-compatible dict.

    Mapuje:
      - `tmdb_id` → `id` (Kodi konvence)
      - `title_tmdb` preferovaný pro display (pokud Gate namatchoval),
        fallback na CSFD CZ title
      - runtime/poster/backdrop/rating/votes/overview ponechány

    Pro tipy bez TMDb matche (tmdb_id=0) vrací placeholder s CSFD title,
    addon pak klik vede na movie_search (viz plugin.py:_list_csfd_tv_tips).
    """
    tmdb_id = int(tip.get("tmdb_id") or 0)
    csfd_title = (tip.get("title") or "").strip()
    tmdb_title = (tip.get("title_tmdb") or "").strip()
    display_title = tmdb_title or csfd_title

    return {
        "id":            tmdb_id,
        "title":         display_title,
        "year":          int(tip.get("year") or 0),
        "poster_path":   tip.get("poster_path") or "",
        "backdrop_path": tip.get("backdrop_path") or "",
        "overview":      (tip.get("overview") or "").strip(),
        "rating":        float(tip.get("rating") or 0),
        "votes":         int(tip.get("votes") or 0),
        "runtime":       int(tip.get("runtime") or 0),
        "csfd_url":      tip.get("csfd_url") or "",
        "day_offset":    int(tip.get("day_offset") or 0),
    }


# =========================
# PUBLIC API
# =========================
def get_tv_tips(
    *,
    profile_dir: Path,
    ttl_seconds: int = _DEFAULT_TTL_SECONDS,
    force_refresh: bool = False,
    background: bool = False,
) -> List[Dict[str, Any]]:
    """Vrátí raw TV tipy z Gate (nebo z čerstvé 24h cache).

    Raw tipy = Gate response pole `tv_tips`, beze změny shape. Pro Kodi
    rendering použij `get_tv_tips_tmdb_items` (volá adapter).

    Raises CSFDError když Gate selže a cache je prázdná/prošlá.
    """
    now = time.time()
    cache = _load_cache(profile_dir)

    if (
        not force_refresh
        and isinstance(cache, dict)
        and isinstance(cache.get("ts"), (int, float))
        and (now - float(cache["ts"])) <= max(0, int(ttl_seconds))
        and isinstance(cache.get("tips"), list)
        and len(cache.get("tips") or []) > 0
    ):
        _log("CACHE_HIT: tips")
        return cache["tips"]  # type: ignore[return-value]

    data = _gate_get_tv_tips(background=background)
    tips = data.get("tv_tips") or []
    if not isinstance(tips, list):
        raise CSFDError("Gate /tv-tips: 'tv_tips' není list.")
    if not tips:
        raise CSFDError("Gate /tv-tips vrátil prázdný seznam.")

    _save_cache(profile_dir, {"ts": int(now), "tips": tips})
    _log(f"GATE_TV_TIPS: {len(tips)} tips → cache")
    return tips


def get_tv_tips_tmdb_items(
    *,
    profile_dir: Path,
    tmdb: Any = None,  # kept for backward-compat signature; unused in beta.6+
    ttl_seconds: int = _DEFAULT_TTL_SECONDS,
) -> List[Dict[str, Any]]:
    """Vrátí tipy připravené pro Kodi rendering (beta.6+ thin adapter).

    `tmdb` parametr je ignorován — enrichment probíhá na Gate při scrape
    (viz `csfd_tv_tips.scrape_and_store` na NAS). Adapter pouze přemapuje
    field names (`tmdb_id` → `id`) a nastaví rozumné defaulty.

    Raises CSFDError pokud selže `get_tv_tips` (Gate nedostupný + cache prázdná).
    """
    _ = tmdb  # legacy signature compat; no per-item TMDb calls anymore
    tips = get_tv_tips(profile_dir=profile_dir, ttl_seconds=ttl_seconds)
    items = [_gate_tip_to_item(t) for t in tips]
    matched = sum(1 for it in items if it["id"] > 0)
    _log(
        f"TV_TIPS_ADAPTER: total={len(items)} matched={matched} "
        f"miss={len(items) - matched}"
    )
    return items
