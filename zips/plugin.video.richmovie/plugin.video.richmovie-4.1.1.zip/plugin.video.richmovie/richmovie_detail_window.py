# -*- coding: utf-8 -*-
"""RichMovie 4.0 — custom Detail / title page (WindowXMLDialog) — Φ1.

Fullscreen backdrop + titul + rating/meta + plot + [▶ Přehrát]/[Podobné].

Φ-R1+R2 (2026-06-12):
  • TMDb + ČSFD fetch běží v pozadí (uc.fetch_async) — okno se otevře <300 ms,
    skeleton stav místo zamrzlé obrazovky, chyba = viditelná inline hláška.
  • [▶ Přehrát] (film) = PICKER-FIRST: okamžitě otevře Stream-picker („Hledám
    streamy…") NAD Detailem, search běží v jiném invokeru (token párování).
    Back z pickeru vrací do Detailu — žádné slepé čekání, žádný mrtvý klik.
  • [Podobné] otevírá custom Grid (similar feed) NAD Detailem — žádný
    Container.Update (ten by aktualizoval directory schované POD okny).

SSOT: richmovie_ui_common. XML: RichMovieDetail.xml. Best-effort, neshodí addon.
"""
from __future__ import annotations

import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

import richmovie_ui_common as uc
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/Detail] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.detail", "RichMovie/Detail")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "Detail] " + str(msg), level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"
_XML = "RichMovieDetail.xml"
_RES = "1080i"
_BASE = f"plugin://{_ADDON_ID}/"

_PLAY = 8001
_SIMILAR = 8002
_MYLIST = 8003
_BACK = 9000


class RichMovieDetailWindow(uc.RMNavMixin, xbmcgui.WindowXMLDialog):

    def __init__(self, *a, tmdb_id="", kind="movie", title="", **kw):
        super().__init__(*a, **kw)
        self._tmdb_id = str(tmdb_id or "")
        self._kind = (kind or "movie").lower()
        self._title = title or ""
        self._rm_closed = False
        self._resume_cw_index = None  # P1-g: rozkoukaná epizoda seriálu (smart-resume)
        self._resume_cw_key = ""      # její stabilní klíč (Codex C3)

    def onInit(self) -> None:
        # okamžitý placeholder — okno nikdy není prázdné/zamrzlé
        self.setProperty("rm_d_title", self._title)
        self.setProperty("rm_d_play_label", "▶ Epizody" if self._kind == "tv" else "▶ Přehrát")
        if self._kind == "tv":
            self._check_resume()  # P1-g: nabídni „Pokračovat SxEy" rovnou
        self._refresh_list_label()
        try:
            self.setFocusId(_PLAY)
        except Exception:
            pass
        # TMDb data (plot/backdrop/rating/meta) na pozadí — VŽDY (film i seriál)
        if self._tmdb_id:
            uc.fetch_async(self, self._fetch_data, self._apply_data, tag="detail",
                           on_error=self._fetch_failed)

    def _check_resume(self) -> None:
        """Pokud je seriál rozkoukaný (continue_watching), [Přehrát] = rovnou další
        epizoda místo procházení sezón (P1-g smart-resume, Netflix vzor)."""
        try:
            import richmovie_history as hist
            items = hist.cw_view_load().get("items") or []   # 4.0.3: index = index POHLEDU Pokračovat
            for idx, it in enumerate(items):
                if it.get("type") != "episode":
                    continue
                if str(it.get("tmdb_id") or it.get("tv_id") or "") != self._tmdb_id:
                    continue
                s = int(it.get("season") or 0)
                e = int(it.get("episode") or 0)
                if s > 0 and e > 0:
                    self._resume_cw_index = idx
                    self._resume_cw_key = uc.cw_key_of(it)
                    self.setProperty("rm_d_play_label", f"▶ Pokračovat S{s:02d}E{e:02d}")
                return
        except Exception:
            pass

    # ------------------------------------------------------------------ data
    def _fetch_data(self):
        """Běží v pozadí (non-daemon thread) — žádné HTTP na UI vlákně."""
        from tmdb_client import TMDb
        from richmovie_settings import get_tmdb_api_key
        # SSOT 3.5.69 (bandog vzor): lokální setting je jen cache plněná při
        # WS-loginu — accessor padá na klíč z Gate lease cache.
        key = get_tmdb_api_key()
        if not key:
            raise RuntimeError("TMDb klíč není k dispozici (Gate je SSOT)")
        tc = TMDb(key, lang="cs-CZ")
        d = (tc.tv_details(int(self._tmdb_id)) if self._kind == "tv"
             else tc.details(int(self._tmdb_id))) or {}
        return {"details": d, "csfd": self._csfd_rating()}

    def _apply_data(self, data) -> None:
        d = data.get("details") or {}
        title = d.get("title") or d.get("name") or self._title
        self.setProperty("rm_d_title", title)
        self._title = title
        self.setProperty("rm_d_plot", (d.get("overview") or "").strip())
        # w1280 (ne original) — Chromecast/2GB: original backdropy = velká textura
        # + 12s KenBurns scale = výkonový žrout (P1-l)
        self.setProperty("rm_d_backdrop", uc.img(d.get("backdrop_path"), "w1280"))
        self.setProperty("rm_d_poster", uc.img(d.get("poster_path"), "w500"))
        self.setProperty("rm_d_poster_raw", d.get("poster_path") or "")  # pro Můj seznam

        # meta: ★TMDb · (ČSFD) · rok · délka · žánry
        parts = []
        try:
            rating = round(float(d.get("vote_average") or 0), 1)
        except Exception:
            rating = 0
        if rating:
            parts.append(f"★ {rating} TMDb")
        csfd = data.get("csfd")
        if csfd:
            parts.append(f"ČSFD {csfd}%")
        year = (d.get("release_date") or d.get("first_air_date") or "")[:4]
        if year:
            parts.append(year)
            self.setProperty("rm_d_year", year)
        rt = d.get("runtime") or 0
        if not rt:
            ert = d.get("episode_run_time") or []
            rt = ert[0] if ert else 0
        if rt:
            parts.append(f"{int(rt)} min")
        genres = ", ".join(g.get("name", "") for g in (d.get("genres") or [])[:3] if g.get("name"))
        if genres:
            parts.append(genres)
        self.setProperty("rm_d_meta", "   ·   ".join(parts))

    def _fetch_failed(self, exc) -> None:
        _log(f"fetch: {exc}", xbmc.LOGWARNING)
        self.setProperty("rm_d_meta", "Detail se nepodařilo načíst — zkontroluj připojení.")

    def _csfd_rating(self):
        try:
            import richmovie_csfd_client as cc
            fn = getattr(cc, "get_csfd_rating_for_tmdb", None)
            if callable(fn):
                r = fn(int(self._tmdb_id), self._kind)
                if r:
                    return r
        except Exception:
            pass
        return None

    # ------------------------------------------------------------------ input
    def _refresh_list_label(self) -> None:
        """Label tlačítka Můj seznam podle aktuálního stavu (✔ v seznamu / +)."""
        try:
            import richmovie_history as hist
            inlist = hist.my_list_contains(self._tmdb_id, self._kind) if self._tmdb_id else False
            self.setProperty("rm_d_list_label", "✔ V seznamu" if inlist else "+ Můj seznam")
        except Exception:
            self.setProperty("rm_d_list_label", "+ Můj seznam")

    def _context_menu(self) -> None:
        """Long-press/C/pravý klik na Detailu — Můj seznam + (film) watched."""
        try:
            opts = ["+ Můj seznam / odebrat"]
            acts = ["mylist"]
            if self._kind == "movie" and self._tmdb_id:
                import richmovie_history as hist
                seen = hist.watched_movie_contains(self._tmdb_id)
                opts.append("Označit jako nezhlédnutý" if seen else "Označit jako zhlédnutý ✔")
                acts.append("watched")
            import xbmcgui as _g
            sel = _g.Dialog().contextmenu(opts)
            if sel < 0:
                return
            if acts[sel] == "mylist":
                self._toggle_my_list()
            elif acts[sel] == "watched":
                import richmovie_history as hist
                now_seen = hist.watched_movie_toggle(self._tmdb_id)
                _rm_notif(
                    "Označeno jako zhlédnuté ✔" if now_seen else "Označeno jako nezhlédnuté",
                    _g.NOTIFICATION_INFO,
                    2000,
                    "RichMovie",
                    sound=False,
                )
        except Exception as exc:
            uc.notify_error("Akce se nepodařila.", log_tag="Detail")
            _log(f"context: {exc}", xbmc.LOGWARNING)

    def _toggle_my_list(self) -> None:
        try:
            import richmovie_history as hist
            now_in = hist.my_list_toggle(
                tmdb_id=self._tmdb_id, kind=self._kind, title=self._title,
                year=(self.getProperty("rm_d_year") or ""),
                poster_path=(self.getProperty("rm_d_poster_raw") or ""))
            self._refresh_list_label()
            import xbmcgui
            _rm_notif(
                "Přidáno do Mého seznamu" if now_in else "Odebráno z Mého seznamu",
                xbmcgui.NOTIFICATION_INFO,
                2500,
                "RichMovie",
                sound=False,
            )
        except Exception as exc:
            uc.notify_error("Můj seznam se nepodařilo upravit.", log_tag="Detail")
            _log(f"my_list: {exc}", xbmc.LOGWARNING)

    def onClick(self, controlId: int) -> None:
        try:
            if controlId == _BACK:
                self.close()
            elif controlId == _MYLIST:
                self._toggle_my_list()
            elif controlId == _PLAY:
                if self._kind == "tv":
                    if self._resume_cw_index is not None:
                        # P1-g smart-resume: rovnou další epizoda (1 klik)
                        if not uc.play_debounce():
                            return
                        # Φ2: descriptor PŘED close (snapshot integrita —
                        # návrat vede zpět do TOHOTO Detailu, ne jen na Home)
                        uc.mark_play_from_ui()
                        self.close()
                        xbmc.executebuiltin(
                            f"RunPlugin({uc.cw_link(self._resume_cw_index, self._resume_cw_key)})")
                    else:
                        # custom Episodes okno NAD Detailem (Back vrací do Detailu)
                        q = urllib.parse.urlencode({"action": "rm_episodes", "tv_id": self._tmdb_id,
                                                    "tv_name": self._title})
                        xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
                else:
                    self._play_movie_picker_first()
            elif controlId == _SIMILAR:
                # custom Grid NAD Detailem (NE Container.Update — pod okny je
                # schovaná directory, uživatel by změnu nikdy neviděl)
                feed = "similar_tv" if self._kind == "tv" else "similar_movies"
                q = urllib.parse.urlencode({"action": "rm_grid", "feed": feed,
                                            "ref_id": self._tmdb_id,
                                            "title": f"Podobné: {self._title}"})
                xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
        except Exception as exc:
            uc.notify_error("Akce se nepodařila spustit.", log_tag="Detail")
            _log(f"onClick {controlId}: {exc}", xbmc.LOGWARNING)

    def _play_movie_picker_first(self) -> None:
        """Okamžitá odezva: picker se otevře HNED, search běží na pozadí (SSOT helper)."""
        uc.play_picker_first(
            xbmcaddon.Addon(_ADDON_ID), action="auto",
            poster=self.getProperty("rm_d_poster_raw"), title=self._title,
            tmdb=self._tmdb_id)

    def on_window_action(self, action) -> None:
        # Back/Stop/device latch řeší uc.RMNavMixin.onAction (Φ1 DRY)
        if action.getId() == xbmcgui.ACTION_CONTEXT_MENU:
            self._context_menu()

    def close(self):  # noqa: A003 — Kodi API jméno
        self._rm_closed = True
        super().close()


def open_detail(addon, tmdb_id="", kind="movie", title="") -> None:
    """Otevře custom Detail. Best-effort."""
    try:
        w = RichMovieDetailWindow(_XML, addon.getAddonInfo("path"), "default", _RES,
                                  tmdb_id=tmdb_id, kind=kind, title=title)
        _nav_id = uc.nav_push("rm_detail", {"tmdb_id": tmdb_id, "kind": kind,
                                            "title": title})  # Φ1 NavStack
        try:
            w.doModal()
        finally:
            uc.nav_remove(_nav_id)
        w._rm_closed = True
        del w
    except Exception as exc:
        _log(f"open_detail: {exc}", xbmc.LOGWARNING)
