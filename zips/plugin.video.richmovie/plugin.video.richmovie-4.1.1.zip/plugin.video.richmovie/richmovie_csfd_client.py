# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_csfd_client.py
# Addon-side CSFD profile management — Apple-like seamless UX.
# Phase B8 (RichMovie 3.2.0, 2026-04-26).
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie 3.2.0 — Addon-side CSFD client

API:
    connect_csfd(username, password) -> dict
        POST /v1/csfd/auth — initial OAuth login. Server stores encrypted
        password vault + tokens. NO consent dialog (Apple-like per Richie).

    sync_csfd_now() -> dict
        POST /v1/csfd/sync — manual sync trigger.

    csfd_status() -> dict
        GET /v1/csfd/status — connection state, last sync info.

    disconnect_csfd() -> dict
        POST /v1/csfd/disconnect — wipe vault + tokens (GDPR).

    get_csfd_rating_for_tmdb(tmdb_id) -> int | None
        GET /v1/csfd/film/by-tmdb/<tmdb_id> — central cache lookup.
        Returns 0-100% rating or None if no CSFD mapping.
        Used by UI info panel display (Q1 decision: jen CSFD).

UI handlers (called from plugin.py router):
    show_csfd_settings_dialog()     — connect/disconnect via Kodi dialog
    show_csfd_sync_now_action()     — manual sync trigger + notification

Author: Richie (autonomous Phase B8 implementation 2026-04-26)
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import json
import urllib.parse
from typing import Any

import xbmc
import xbmcaddon
import xbmcgui
import richmovie_helpers as _rh
import richmovie_feedback as _fb  # Φ2 (29.09.2026): SSOT okamžité odezvy

_LOG_PREFIX = "[RichMovie/CSFD/Client]"

# 3.4.0 Phase 9: Migrated to richmovie_logging pipeline.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.csfd_client", "RichMovie/CSFD/Client")
except Exception:
    def _log(msg: str, level: int = xbmc.LOGINFO, *, context: dict | None = None) -> None:
        """Centralized logger fallback. Always uses LOGINFO so it shows in
        default Kodi log level — debugging this flow needs visibility, the
        volume is low."""
        try:
            xbmc.log("{} {}".format(_LOG_PREFIX, msg), level)
        except Exception:
            pass


_GUEST = object()   # sentinel: aktivní profil je Host
_NO_PROFILE = object()   # sentinel: účet multi bez zvoleného profilu (Fable P3-2) — ČSFD je per profil


def _csfd_profile_id():
    """Profil pro ČSFD požadavek (SSOT `richmovie_profile`): None = účet bez profilů (single/unset),
    int = profil, `_GUEST` = Host. Nikdy nevyhodí (bez profilového modulu = účet)."""
    try:
        import richmovie_profile as _rp
        if _rp.is_guest():
            return _GUEST
        if _rp.is_multi() and not _rp.has_active_profile():
            return _NO_PROFILE
        return _rp.telemetry_profile_id()
    except Exception as exc:
        _log("profile lookup failed: {!r} → účet".format(exc), xbmc.LOGWARNING)
        return None


def csfd_profile_label() -> str:
    """Jméno aktivního profilu pro nadpisy („ČSFD · Sněhurka"); "" u účtu bez profilů."""
    try:
        import richmovie_profile as _rp
        if not _rp.is_multi() or _rp.is_guest():
            return ""
        return str((_rp.current() or {}).get("name") or "").strip()
    except Exception:
        return ""


def _gate_call(method: str, path: str, *,
                body: dict[str, Any] | None = None,
                params: dict[str, Any] | None = None,
                timeout: float = 60.0) -> tuple[int, dict[str, Any]]:
    """Wrapper around richmovie_gate_transport for /v1/csfd/* endpoints."""
    _log("call {} {} (body keys={})".format(
        method, path, list((body or {}).keys()) if body else []))
    try:
        from richmovie_gate_transport import (
            post_json, get_identity, build_common_fields, GATE_URL,
        )
    except ImportError as exc:
        _log("transport ImportError: {!r}".format(exc), xbmc.LOGERROR)
        return 503, {"error": "transport_unavailable", "detail": repr(exc)}

    # 3.5.152 (ČSFD per profil, Gate mig 0032): každý požadavek nese profil, který ho dělá.
    # Host nemá ČSFD (nic se mu neukládá) → bez requestu, kód jako od Gate (`profile_required`).
    profile_id = _csfd_profile_id()
    if profile_id is _GUEST:
        _log("guest profile — ČSFD není k dispozici, bez requestu", xbmc.LOGINFO)
        return 403, {"error": "guest_no_csfd"}
    if profile_id is _NO_PROFILE:
        _log("multi bez zvoleného profilu — ČSFD je per profil, bez requestu", xbmc.LOGINFO)
        return 400, {"error": "profile_required"}

    if method == "POST":
        username, _ = get_identity()
        if not username:
            _log("no_identity (Gate not authed?) — abort", xbmc.LOGERROR)
            return 401, {"error": "no_identity"}
        full_body = dict(body or {})
        full_body.update(build_common_fields())
        if profile_id is not None:
            full_body["profile_id"] = int(profile_id)
        try:
            status, resp_body = post_json(path, full_body, timeout=timeout)
            _log("POST {} -> HTTP {} body keys={}".format(
                path, status,
                list(resp_body.keys()) if isinstance(resp_body, dict) else type(resp_body).__name__,
            ))
            return status, resp_body
        except Exception as exc:
            _log("POST {} transport_fail: {!r}".format(path, exc), xbmc.LOGERROR)
            return 599, {"error": "transport_fail", "detail": repr(exc)}

    if method == "GET":
        username, proof = get_identity()
        if not username:
            _log("no_identity (Gate not authed?) — abort", xbmc.LOGERROR)
            return 401, {"error": "no_identity"}
        # Φ7 (29.09.2026): identita v hlavičce `Authorization: RM-Proof`, ne v URL (viz richmovie_recommendations)
        qp = dict(params or {})
        if profile_id is not None:
            qp["profile_id"] = int(profile_id)
        # Φ3b (2026-08-08): transport přes SSOT retry vrstvu. Retry dostává JEN
        # GET větev (stav profilu, hodnocení) — POST větev výše provádí connect
        # a sync, tedy zápisy, a ta zůstává bez opakování.
        try:
            import richmovie_http as _rm_http
            url = "{}{}?{}".format(GATE_URL, path, urllib.parse.urlencode(qp))
            profile = _rm_http.profile_foreground().replace(timeout_s=float(timeout))
            from richmovie_gate_transport import auth_header as _auth_header, gate_headers as _gate_headers
            _hdrs_out = _gate_headers()
            _hdrs_out.update(_auth_header(username, proof))
            code, raw, _hdrs = _rm_http.request(
                url, headers=_hdrs_out, profile=profile, tag="csfd",
            )
            try:
                text = raw.decode("utf-8") if raw else ""
                body_obj = json.loads(text) if text else {}
            except Exception:
                return code, {"error": "http_{}".format(code)}
            _log("GET {} -> HTTP {} body keys={}".format(
                path, code,
                list(body_obj.keys()) if isinstance(body_obj, dict) else type(body_obj).__name__,
            ))
            return code, body_obj
        except Exception as exc:
            _log("GET {} transport_fail: {!r}".format(path, exc), xbmc.LOGERROR)
            return 599, {"error": "transport_fail", "detail": repr(exc)}

    return 405, {"error": "method_not_allowed"}


# ─────────────────────────────────────────────────────────────────────────────
#  Public API
# ─────────────────────────────────────────────────────────────────────────────

def connect_csfd(username: str, password: str) -> dict[str, Any]:
    """Initial OAuth login. Server stores encrypted password + tokens."""
    status, body = _gate_call("POST", "/v1/csfd/auth", body={
        "csfd_username": username,
        "csfd_password": password,
    })
    if status == 200:
        return body
    # 3.5.131: chyba VŽDY jako řetězec přes SSOT `_extract_error` (dřív mohl být dict →
    # `err[:60]` v dialogu spadlo; s csfd v2 503 `csfd_unreachable` je to pravděpodobnější).
    return {"ok": False, "error": "{}: {}".format(status, _extract_error(body))}


def _extract_error(body: dict[str, Any]) -> str:
    """Strojový KÓD chyby z odpovědi Gate/csfd (`{"detail": {"error": kód, "detail": text}}`).

    Φ2 (29.09.2026): dřív se bral nejdřív lidský `detail` — u odmítnutého hesla (`invalid_credentials`)
    nebo selhaného syncu (`csfd_transport`) tak do `friendly_error` / `_friendly_sync_error` došel
    anglický text místo kódu a na obrazovce byla obecná hláška. Rozhoduje kód; text jde jen do logu."""
    if not isinstance(body, dict):
        return "non_dict_body"
    detail = body.get("detail")
    if isinstance(detail, dict):
        if detail.get("error") and detail.get("detail"):
            _log("gate error detail [{}]: {}".format(detail.get("error"), str(detail.get("detail"))[:200]),
                 xbmc.LOGWARNING)
        return detail.get("error") or detail.get("detail") or str(detail)[:120]
    if isinstance(detail, str):
        return detail
    return body.get("error") or body.get("message") or "unknown"


# Kódy, které mají lidskou větu (3.5.152); ostatní se ukazují jako „kód" (technický text do UI nepatří)
_ERROR_TEXT = {
    "guest_no_csfd": "Host profil nemá ČSFD — vyber svůj profil v hlavním menu (Dívá se: …).",
    "profile_required": "ČSFD je per profil — vyber svůj profil v hlavním menu (Dívá se: …).",
    "csfd_not_enabled_for_user": "ČSFD není pro tento účet zapnuté — napiš správci.",
    "no_identity": "Nejdřív se přihlas k Webshare (Nastavení).",
    # kódy služby csfd u připojení (`services/csfd/app/main.py` `/v1/csfd/auth`, csfd_oauth)
    "invalid_credentials": "ČSFD odmítlo jméno nebo heslo — zkontroluj je a zkus to znovu.",
    "csfd_unreachable": "ČSFD teď neodpovídá — zkus to prosím za chvilku.",
    "csfd_identity_failed": "ČSFD přihlášení nedokončilo — zkus to prosím za chvilku.",
    # Φ2 (29.09.2026): selhání cesty k Gate (`_gate_call` 503/599) — dřív „Server ČSFD odpověděl
    # chybou (transport_fail)“, přitom ČSFD za nic nemohlo
    "transport_fail": "Server RichMovie teď neodpovídá — zkus to prosím za chvilku.",
    "transport_unavailable": "Server RichMovie teď neodpovídá — zkus to prosím za chvilku.",
}

# Φ2: HTTP stavy, kterými Gate AUTORITATIVNĚ říká „pro tenhle profil/účet ČSFD nejde“ (Host, profil
# nevybraný, účet bez ČSFD, identita). Cokoli jiného = cesta k serveru selhala → „zkus za chvilku“,
# NIKDY průvodce připojením (dřív výpadek Gate vypadal jako „nepřipojeno“ a chtěl heslo znovu).
_AUTHORITATIVE_STATUS = (400, 401, 403, 404)


def friendly_error(err: Any) -> str:
    """`"403: guest_no_csfd"` → lidská věta. Neznámý kód jen do logu, na obrazovku obecná věta."""
    text = str(err or "neznámá chyba")
    code = text.split(":", 1)[-1].strip()
    known = _ERROR_TEXT.get(code) or _ERROR_TEXT.get(text)
    if known:
        return known
    _log("csfd error without friendly text: %s" % text[:200], xbmc.LOGWARNING)
    return "ČSFD teď nejde — zkus to později."


def sync_csfd_now() -> dict[str, Any]:
    status, body = _gate_call("POST", "/v1/csfd/sync")
    if status == 200:
        return body
    return {"ok": False, "error": "{}: {}".format(status, _extract_error(body))}


def csfd_status() -> dict[str, Any]:
    """Gate `/v1/csfd/status`. Při selhání vrací `status` (HTTP) + `error` zvlášť,
    aby UI rozlišilo „ČSFD není pro účet aktivní" (401/403/404 = autoritativní
    odpověď Gate) od „Gate nedostupný" (transport/5xx) — Fable audit P1-1."""
    status, body = _gate_call("GET", "/v1/csfd/status")
    if status == 200:
        return body
    return {"connected": False, "status": int(status),
            "error": "{}: {}".format(status, _extract_error(body))}


def disconnect_csfd() -> dict[str, Any]:
    status, body = _gate_call("POST", "/v1/csfd/disconnect")
    if status == 200:
        return body
    return {"ok": False, "error": "{}: {}".format(status, _extract_error(body))}


def get_csfd_rating_for_tmdb(tmdb_id: int) -> int | None:
    """Returns CSFD rating 0-100% for TMDb id, or None if no mapping."""
    status, body = _gate_call("GET", f"/v1/csfd/film/by-tmdb/{tmdb_id}")
    if status == 200 and isinstance(body, dict):
        return body.get("rating_pct")
    return None


# ─────────────────────────────────────────────────────────────────────────────
#  UI handlers — Apple-like (no scary dialogs, simple flow)
# ─────────────────────────────────────────────────────────────────────────────

def show_csfd_settings_dialog() -> None:
    """Single Kodi dialog flow — connect or disconnect based on current state."""
    _log("show_csfd_settings_dialog: enter")
    dlg = xbmcgui.Dialog()
    # Φ2 (29.09.2026): akce z nastavení nemá kolečko Kodi — bez průběhu to bylo 1–3 s ticha
    with _fb.working("Načítám stav ČSFD…"):
        state = csfd_status()
    # 3.5.152: ČSFD je per profil — nadpisy nesou jméno profilu, autoritativní chyba (Host,
    # starý addon vs. Gate, účet bez ČSFD) se řekne lidsky místo přihlašovacího dialogu
    profile_label = csfd_profile_label()
    who = " · {}".format(profile_label) if profile_label else ""
    failed_status = int(state.get("status") or 0) if "error" in state else 0
    if not state.get("connected") and failed_status in _AUTHORITATIVE_STATUS:
        dlg.ok("ČSFD profil{}".format(who), friendly_error(state.get("error")))
        return
    if failed_status:
        _log("status unavailable ({}) — no connect flow".format(state.get("error")), xbmc.LOGWARNING)
        _fb.warn(friendly_error(state.get("error")), heading="ČSFD")
        return
    _log("status payload: connected={} username={} ratings={} watchlist={} "
         "last_sync={} last_err={}".format(
             state.get("connected"),
             state.get("csfd_username"),
             state.get("total_ratings"),
             state.get("total_watchlist"),
             state.get("last_sync_finished_at"),
             (state.get("last_sync_error") or "")[:80],
         ))

    if state.get("connected"):
        # Kodi's xbmcgui.Dialog().select() does NOT render body text — status
        # info has to be embedded in the heading and option labels themselves.
        # 3.5.133 (Richie: „last: 2026-09-05T05:00 je neintuitivní"): lokální čas
        # lidsky (SSOT richmovie_helpers), stav syncu slovy, delta po syncu.
        nick = state.get("csfd_username", "?")
        ratings = int(state.get("total_ratings") or 0)
        watchlist = int(state.get("total_watchlist") or 0)
        health = state.get("sync_health") or {}
        h_state = str(health.get("state") or "")
        last_ok = _rh.format_local_datetime(
            health.get("last_success_at") or state.get("last_sync_finished_at"), default="")
        err_code = str(health.get("last_error_code") or state.get("last_sync_error") or "")

        status_line = "{} hodnocení · {} v Chci vidět".format(ratings, watchlist)
        if h_state == "failing":
            status_line += " · poslední pokus selhal ({})".format(_friendly_sync_error(err_code, short=True))
            if last_ok:
                status_line += ", data z {}".format(last_ok)
        elif last_ok:
            status_line += " · synchronizováno {}".format(last_ok)
        else:
            status_line += " · zatím nesynchronizováno"

        heading = "ČSFD{} — {}".format(who, nick)
        choice = dlg.select(heading, [
            "Synchronizovat teď  ·  {}".format(status_line),
            "Otevřít Moje ČSFD (hodnocení, Chci vidět)",
            "Odpojit ČSFD profil",
            "Zavřít",
        ])
        _log("connected-state user choice = {}".format(choice))
        if choice == 0:
            _do_sync_with_progress(before=(ratings, watchlist))
        elif choice == 1:
            xbmc.executebuiltin("Container.Update(plugin://{}/?action=csfd_my_root)".format(
                xbmcaddon.Addon().getAddonInfo("id")))
        elif choice == 2:
            if dlg.yesno("Odpojit ČSFD{}?".format(who), "Opravdu odpojit ČSFD profil? "
                         "Hodnocení v RichMovie zůstanou."):
                _log("user confirmed disconnect")
                with _fb.working("Odpojuji ČSFD…"):
                    result = disconnect_csfd()
                _log("disconnect result: {}".format(result))
                if result.get("ok"):
                    _fb.info("ČSFD profil odpojen", heading="ČSFD")
                else:
                    _fb.warn("Odpojit se nepodařilo. " + friendly_error(result.get("error")),
                             heading="ČSFD")
    else:
        # Not connected — show connect dialog (Apple-like: no warnings)
        _log("not connected — entering connect flow")
        dlg.ok("Připojit ČSFD{}".format(who),
               ("Profil {} dostane vlastní ČSFD: RichMovie použije jeho hodnocení a „Chci vidět“ "
                "pro doporučení jen tohoto profilu. ".format(profile_label) if profile_label else
                "RichMovie použije tvá hodnocení z ČSFD pro lepší AI doporučení. ")
               + "Heslo se ukládá šifrovaně na serveru RichMovie.")
        username = dlg.input("CSFD nick", "", xbmcgui.INPUT_ALPHANUM)
        if not username:
            _log("user cancelled at username prompt")
            return
        password = dlg.input("CSFD heslo", "", xbmcgui.INPUT_ALPHANUM,
                              option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password:
            _log("user cancelled at password prompt")
            return

        with _fb.working("Připojuji ČSFD profil…"):
            result = connect_csfd(username, password)
        _log("connect_csfd result: {}".format(
            {k: v for k, v in result.items() if k != "csfd_password"}))

        if result.get("ok"):
            _fb.info("ČSFD propojeno{} ({})".format(who, result.get("csfd_nickname") or username),
                     heading="ČSFD")
            # Trigger initial sync immediately
            _do_sync_with_progress()
        else:
            _fb.warn("Připojit se nepodařilo. " + friendly_error(result.get("error")), heading="ČSFD")


_SYNC_ERROR_TEXT = {
    # strojové kódy csfd služby (sync_engine._classify_exception, 3.5.131+)
    "csfd_transport": ("ČSFD neodpovídá", "ČSFD právě neodpovídá, zkus to za chvíli."),
    "csfd_auth_rejected": ("přihlášení vypršelo", "ČSFD odmítlo přihlášení — odpoj a znovu připoj profil."),
    "csfd_credentials_rejected": ("špatné heslo", "ČSFD odmítlo heslo — odpoj profil a připoj ho se správným heslem."),
    "csfd_vault": ("chyba trezoru hesel", "Uložené heslo nejde přečíst — odpoj a znovu připoj profil."),
    "csfd_api_changed": ("ČSFD změnilo API", "ČSFD změnilo rozhraní; správce dostal hlášení v logu."),
}


def _friendly_sync_error(code: str, *, short: bool = False) -> str:
    """Strojový kód chyby syncu → česká věta pro UI (technický text patří do logu)."""
    base = (code or "").split(":")[0].strip()
    short_txt, long_txt = _SYNC_ERROR_TEXT.get(base, ("chyba", "Synchronizace selhala ({})."
                                                      .format(base or "neznámá chyba")))
    return short_txt if short else long_txt


def _do_sync_with_progress(before: tuple[int, int] | None = None) -> None:
    """Ruční sync s progress dialogem. `before` = (hodnocení, watchlist) před
    syncem → notifikace ukáže, co přibylo (3.5.133)."""
    _log("_do_sync_with_progress: start")
    with _fb.working("Synchronizuji ČSFD…"):
        result = sync_csfd_now()
    _log("_do_sync_with_progress: sync_csfd_now returned: {}".format(result))
    if result.get("ok"):
        ratings = int(result.get("ratings") or 0)
        watchlist = int(result.get("watchlist") or 0)
        parts = ["{} hodnocení".format(ratings), "{} v Chci vidět".format(watchlist)]
        if before is not None:
            d_r, d_w = ratings - before[0], watchlist - before[1]
            new_bits = []
            if d_r > 0:
                new_bits.append("+{} hodnocení".format(d_r))
            if d_w > 0:
                new_bits.append("+{} Chci vidět".format(d_w))
            parts.append("nově " + ", ".join(new_bits) if new_bits else "beze změn")
        _fb.info(" · ".join(parts), heading="ČSFD synchronizováno")
    else:
        err = str(result.get("error") or "")
        code = err.split(": ", 1)[1] if ": " in err else err
        _log("sync failed: {}".format(err), xbmc.LOGWARNING)
        _fb.warn(_friendly_sync_error(code), heading="ČSFD synchronizace selhala")


def show_csfd_sync_now_action() -> None:
    """Standalone action handler for direct sync trigger from plugin.py."""
    _do_sync_with_progress()
