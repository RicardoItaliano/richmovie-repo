# -*- coding: utf-8 -*-
"""
RichMovie MediaInfo Client — thin HTTP client for Gate /v1/mediainfo/* endpoints.

Purpose:
    Crowdsourced stream metadata cache (MI2 per-ident canonical payload).
    First user who probes a Webshare/FastShare file publishes the canonical
    MediaInfo shape; every subsequent user short-circuits their probe and
    pulls from Gate's shared cache.

Architecture (see
S:\\test\\richmovie\\Handoff\\session_2026-04-19_phase3_search_proxy_plus_mediainfo_cache.md):

    richmovie_mi2.MediaInfoSecondEdition worker
          |
          | bulk_lookup([(src, ident), ...]) at start of batch  → skip probes for hits
          | publish(src, ident, canonical_payload) after probe  → fire-and-forget
          v
    POST https://gate.svcnode.org/v1/mediainfo/{bulk_lookup,publish}
    Body: {schema_version, ws_username, ws_proof, source, source_ident, payload}

Best-effort semantics:
    Both `publish` and `bulk_lookup` swallow all errors (transport, HTTP, JSON)
    and fall back to the caller's legacy path (local probe / local cache).
    The MI2 worker must never fail because Gate is unreachable — that would
    regress feature parity from the 2.5.x baseline where everything was local.

Python 3.8 compat (Kodi bundled): typing.Optional/Tuple/Dict/List/Any,
no PEP 604 union syntax in runtime code.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple

import xbmc

from richmovie_gate_transport import (
    build_common_fields,
    has_identity,
    is_media_payload as _is_media_payload,
    post_json,
)


# --------------------------------------------------------------------------- #
# Constants
# --------------------------------------------------------------------------- #
# MI endpoints: POST /v1/mediainfo/ (publish), POST /v1/mediainfo/bulk_lookup.
# Canonical path uses trailing slash (CF tunnel ingress regex matches `v1/mediainfo/`).
_PATH_PUBLISH = "/v1/mediainfo/"
_PATH_BULK_LOOKUP = "/v1/mediainfo/bulk_lookup"

# Lightweight cache — DB insert / indexed SELECT on ~200-byte JSON rows.
# 30s is plenty; anything slower is a Gate-side incident we should not hide
# behind retries (the worker has already waited, user sees stale metadata).
_MI_TIMEOUT_SECONDS = 30.0

# Max keys per bulk_lookup request — matches Gate schema `max_length=100`.
# MI2 worker typically scans 8-32 releases; batching all in one call is trivial.
_BULK_LOOKUP_MAX_KEYS = 100

# Allowed sources — mirrors Gate schemas.ALLOWED_SOURCES. Used to reject
# garbage early (typos like 'webshare' instead of 'ws') before the POST.
_ALLOWED_SOURCES = ("ws", "fs", "sktorrent", "stream", "sosac", "youtube")


# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
# 3.4.0 Phase 9: Migrated to richmovie_logging pipeline. Prefix slightly
# changed [RichMovie/MI-Gate] -> [RichMovie/MI/Gate] (clearer hierarchy).
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.mi_gate", "RichMovie/MI/Gate")
except Exception:
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        # type: (str, int, dict | None) -> None
        try:
            xbmc.log("[RichMovie/MI-Gate] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Availability — cheap (no network)
# --------------------------------------------------------------------------- #
def is_available():
    # type: () -> bool
    """True if addon has Webshare credentials configured.

    MI cache does NOT require the AI permission flag — any authenticated
    user can publish/query. The only gate is valid ws_username + ws_proof.
    """
    return has_identity()


# --------------------------------------------------------------------------- #
# Public: bulk_lookup — batch pre-fetch before probing
# --------------------------------------------------------------------------- #
def bulk_lookup(keys):
    # type: (List[Tuple[str, str]]) -> Dict[str, Dict[str, Any]]
    """Look up multiple (source, source_ident) pairs in one request.

    Returns dict `{"source:ident": payload_dict, ...}` for cache hits.
    Misses are silently dropped — callers decide to probe those themselves.

    Best-effort:
      - Empty input           → {} (no call made)
      - No identity           → {} (logged, no call made)
      - Transport failure     → {} (logged)
      - HTTP 4xx/5xx          → {} (logged with code)
      - Invalid JSON response → {} (logged)

    >100 keys are truncated to the first 100 (Gate cap). Caller should batch
    beforehand if it has more; in practice MI2 never exceeds ~32 per batch.
    """
    if not keys:
        return {}
    if not is_available():
        _log("bulk_lookup skipped — no WS credentials", xbmc.LOGWARNING)
        return {}

    # Normalize + enforce cap.
    clean_keys = []  # type: List[Dict[str, str]]
    for src, ident in keys:
        src_s = str(src or "").strip()
        ident_s = str(ident or "").strip()
        if not src_s or not ident_s or src_s not in _ALLOWED_SOURCES:
            continue
        clean_keys.append({"source": src_s, "source_ident": ident_s})
        if len(clean_keys) >= _BULK_LOOKUP_MAX_KEYS:
            break

    if not clean_keys:
        return {}

    body = build_common_fields()
    body["keys"] = clean_keys

    try:
        status, response = post_json(
            _PATH_BULK_LOOKUP, body, timeout=_MI_TIMEOUT_SECONDS,
        )
    except Exception as exc:
        _log("bulk_lookup transport error: %r" % exc, xbmc.LOGWARNING)
        return {}

    if status != 200 or not isinstance(response, dict) or response.get("status") != "ok":
        err = (response or {}).get("error") or {}
        _log(
            "bulk_lookup FAIL status=%d code=%s msg=%s"
            % (status, err.get("code", ""), (err.get("message") or "")[:120]),
            xbmc.LOGWARNING,
        )
        return {}

    hits = response.get("hits")
    if not isinstance(hits, dict):
        return {}

    # Defensive copy: drop anything non-dict to protect downstream callers.
    clean_hits = {}  # type: Dict[str, Dict[str, Any]]
    for k, v in hits.items():
        if isinstance(v, dict):
            clean_hits[str(k)] = v

    _log(
        "bulk_lookup OK req=%d hits=%d misses=%d"
        % (len(clean_keys), len(clean_hits), len(clean_keys) - len(clean_hits))
    )
    return clean_hits


# --------------------------------------------------------------------------- #
# Public: publish — fire-and-forget after successful local probe
# --------------------------------------------------------------------------- #
def publish(source, source_ident, payload):
    # type: (str, str, Dict[str, Any]) -> bool
    """POST one stream's canonical MediaInfo payload to Gate.

    Returns True on HTTP 200 + status=ok, else False. Never raises.

    Contract:
      `payload` must match Gate's MediaInfoPayload schema:
        {
          "container": "mkv"|"mp4"|...,
          "duration_sec": int|None,
          "size_bytes": int|None,
          "video": {"codec": str, "width": int, "height": int, ...} | None,
          "audio":   [{"codec": str, "lang": str, ...}, ...],
          "subtitles": [{"codec": str, "lang": str, ...}, ...],
        }
      Extra keys are dropped by server-side Pydantic (exclude_none on response).

    Rate limit: Gate enforces 100/hour per user. 429 is logged and ignored —
    MI2 worker continues probing, just without crowd-sourcing this one.
    """
    src_s = str(source or "").strip()
    ident_s = str(source_ident or "").strip()

    if not src_s or src_s not in _ALLOWED_SOURCES:
        _log("publish REJECT source=%r (unknown)" % source, xbmc.LOGWARNING)
        return False
    if not ident_s:
        _log("publish REJECT empty source_ident", xbmc.LOGWARNING)
        return False
    if not isinstance(payload, dict) or not payload.get("container"):
        _log("publish REJECT payload (missing container) for %s:%s"
             % (src_s, ident_s), xbmc.LOGWARNING)
        return False
    # 3.5.130: payload bez video/audio tracku a bez délky = otisk ne-média (HTML
    # stránka, useknutý soubor). Sdílená cache ho od 3.5.129 odmítá (brána
    # `upsert_mi`) — neposílat vůbec, ať Gate nedostává 422 a log neplave.
    # Rozhoduje totéž zrcadlo jako pro hity: `gate_transport.is_media_payload`.
    if not _is_media_payload(payload):
        # DEBUG: u Free účtu by to bylo za každou probu (Pro PB11); počty jsou v PROBE_NOT_MEDIA.
        _log("publish SKIP not_media payload for %s:%s (container=%r, bez tracků a délky)"
             % (src_s, ident_s, payload.get("container")), xbmc.LOGDEBUG)
        return False
    if not is_available():
        _log("publish skipped — no WS credentials", xbmc.LOGWARNING)
        return False

    body = build_common_fields()
    body["source"] = src_s
    body["source_ident"] = ident_s
    body["payload"] = payload

    try:
        status, response = post_json(
            _PATH_PUBLISH, body, timeout=_MI_TIMEOUT_SECONDS,
        )
    except Exception as exc:
        _log("publish transport error for %s:%s: %r"
             % (src_s, ident_s, exc), xbmc.LOGWARNING)
        return False

    if status == 200 and isinstance(response, dict) and response.get("status") == "ok":
        action = response.get("action", "?")
        _log("publish OK %s:%s action=%s" % (src_s, ident_s, action))
        return True

    err = (response or {}).get("error") or {}
    _log(
        "publish FAIL %s:%s status=%d code=%s msg=%s"
        % (src_s, ident_s, status, err.get("code", ""),
           (err.get("message") or "")[:120]),
        xbmc.LOGWARNING,
    )
    return False


# --------------------------------------------------------------------------- #
# Key helpers — unify ident → (source, source_ident) mapping
# --------------------------------------------------------------------------- #
def ident_to_key(ident):
    # type: (str) -> Optional[Tuple[str, str]]
    """Map addon's internal ident string to Gate's (source, source_ident) pair.

    Addon conventions:
      - `"fs:<hash>"`  → FastShare   → ('fs', hash)
      - `"sk:<id>"`    → SkTorrent   → ('sktorrent', id)   (prefix from phase 3f)
      - everything else → Webshare   → ('ws', ident)

    Returns None for empty / garbage inputs so callers can filter cleanly.
    """
    s = str(ident or "").strip()
    if not s:
        return None
    if s.startswith("fs:"):
        tail = s[3:]
        return ("fs", tail) if tail else None
    if s.startswith("sk:"):
        tail = s[3:]
        return ("sktorrent", tail) if tail else None
    return ("ws", s)


def key_to_ident(source, source_ident):
    # type: (str, str) -> str
    """Inverse of `ident_to_key` — reconstruct addon ident from Gate key pair.

    Used when mapping bulk_lookup hits back to the original ident strings the
    MI2 worker + engine cache key on.
    """
    src_s = str(source or "").strip()
    ident_s = str(source_ident or "").strip()
    if not ident_s:
        return ""
    if src_s == "fs":
        return "fs:" + ident_s
    if src_s == "sktorrent":
        return "sk:" + ident_s
    # ws and others → passthrough (ws is the addon's default, unprefixed)
    return ident_s
