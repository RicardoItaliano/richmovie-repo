# -*- coding: utf-8 -*-
"""RichMovie logging pipeline — always-on per-user telemetry.

Architektura (per Handoff plan + 3-agent research consolidation):

    Application code: log = get_logger(__name__); log.info("...", extra={"context": {...}})
        |
        v
    logging.Logger (Python stdlib)
        |
        +-- XBMCHandler              -> kodi.log + profile-dir richmovie.log (existing)
        +-- RedactingFilter          -> scrub secrets BEFORE storage
        +-- RichLogHandler           -> SQLite WAL buffer (richmovie_log_buffer.LogBuffer)
                                          (drainer in service_nextup.py uploads + marks sent)

Phase 9 migrace DOKONČENA (observability program, 3.5.85 / 2026-07-02):
VŠECHNY primary-path `[RichMovie*]` call sites v addonu jdou přes tuto
pipeline (make_legacy_logger per modul). Přímý xbmc.log zůstává JEN ve
fallback větvích helperů (pipeline nedostupná) — kodi.log formát je díky
XBMCFormatteru identický, lokální grepy fungují beze změny.

Privacy:
- RedactingFilter aplikuje ws_token/FASTSHARE/Bearer/email/password patterns
  PRED zaslanim do queue → secrets nikdy nedosáhnou disku ani kodi.log.
- Server-side defense-in-depth via log_redaction.py (defense-in-depth).

Plan: RichMovie-nas/Handoff/session_2026-04-27_user_logs_audit.md (Phase 3)
"""
from __future__ import annotations

import logging
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Optional

# Kodi API (modul musi prezit i mimo Kodi pro testovani)
try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except ImportError:
    xbmc = None  # type: ignore
    xbmcaddon = None  # type: ignore
    xbmcvfs = None  # type: ignore

from richmovie_log_buffer import LogBuffer, get_buffer


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_ADDON_ID = "plugin.video.richmovie"
_DEFAULT_BUFFER_FILENAME = "log_buffer.db"
_LOGGER_NAME_PREFIX = "richmovie"

# Kodi log level mapping — SSOT jsou konstanty `xbmc.LOG*`, ne čísla.
#
# 3.5.123 (nález F12, 30.08.2026): tabulky tu byly z Kodi 18 (LOGNOTICE=2,
# LOGWARNING=3, LOGERROR=4). Kodi 19+ číslování posunulo: LOGDEBUG=0, LOGINFO=1,
# LOGWARNING=2, LOGERROR=3, LOGFATAL=4. Důsledek přes ~120 modulových `_log(…,
# xbmc.LOGWARNING)`: WARNING se routovalo jako INFO a ERROR jako WARNING —
# v `user_logs` za 7 dní 28 594 INFO, 8 WARNING, 0 ERROR; retence WARN+ 90 d
# a dashboardové filtry chyb neměly co ukazovat. Odvození z konstant modulu
# `xbmc` to nemůže zopakovat (harness scénář 42 hlídá roundtrip).
def _build_level_maps():
    if xbmc is not None:
        kodi = {
            logging.DEBUG: xbmc.LOGDEBUG,
            logging.INFO: xbmc.LOGINFO,
            logging.WARNING: xbmc.LOGWARNING,
            logging.ERROR: xbmc.LOGERROR,
            logging.CRITICAL: xbmc.LOGFATAL,
        }
    else:  # mimo Kodi — číslování Kodi 19+ (Matrix a novější)
        kodi = {logging.DEBUG: 0, logging.INFO: 1, logging.WARNING: 2,
                logging.ERROR: 3, logging.CRITICAL: 4}
    py = {kodi_level: py_level for py_level, kodi_level in kodi.items()}
    return kodi, py


_KODI_LEVEL_MAP, _XBMC_TO_PY_LEVEL = _build_level_maps()

# Per-process session ID (volane v init_logging, jeden per Python interpreter)
_SESSION_ID: Optional[str] = None


# ---------------------------------------------------------------------------
# Redaction filter — secrets MUST NOT reach disk
# ---------------------------------------------------------------------------
class RedactingFilter(logging.Filter):
    """Scrub passwords, tokens, cookies, emails before record persists.

    Applies to record.msg AND record.args. After this filter runs, record.msg
    contains the formatted message with all secrets replaced by [REDACTED].

    Patterns ground-truth:
    - ws_token / wst = Webshare login token (richmovie_webshare.py)
    - FASTSHARE / fs_hash = Fastshare cookie (richmovie_fastshare.py)
    - Bearer = OAuth/API tokens (richmovie_csfd_client.py)
    - password / api_key = generic credentials
    - email = PII
    - 16-digit card-like = paranoid PCI
    - GitHub PAT = paranoid (deploy scripts only, but defense-in-depth)
    """
    _PATTERNS: list[tuple[re.Pattern[str], str]] = [
        # Φ7 (29.09.2026): oddělovač i URL-kódovaný (`%3D`, dvojitě `%253D`) — Kodi loguje URL streamu
        # s `|Cookie=FASTSHARE%3D…` a doslovné `=` ho nechytilo (27× v archivu kodi.logu).
        (re.compile(r"\b(ws[_]?token|wst)(=|%3D|%253D)[A-Za-z0-9]+", re.IGNORECASE),
         r"\1\2[REDACTED]"),
        (re.compile(r"\b(FASTSHARE|fs_hash)(=|%3D|%253D)[A-Za-z0-9]+", re.IGNORECASE),
         r"\1\2[REDACTED]"),
        # Kodi volba hlavičky v URL streamu `url|Cookie=…&User-Agent=…` — celá hodnota (parita s diag uploadem a Gate)
        (re.compile(r"([|&?]cookie=)[^&\s\"'<>|]+", re.IGNORECASE),
         r"\1[REDACTED]"),
        (re.compile(r"\bBearer\s+[A-Za-z0-9._\-]+"),
         "Bearer [REDACTED]"),
        (re.compile(r"(password|passwd|pwd|secret|api[_]?key)\s*[:=]\s*['\"]?[^\s'\",}]+",
                    re.IGNORECASE),
         r"\1=[REDACTED]"),
        (re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"),
         "[REDACTED-EMAIL]"),
        (re.compile(r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b"),
         "[REDACTED-CARD]"),
        (re.compile(r"\b(ghp_|github_pat_)[A-Za-z0-9_]+"),
         r"\1[REDACTED]"),
        (re.compile(r"(_cookies\s*=\s*)<[^>]+>"),  # requests.Session._cookies repr
         r"\1[REDACTED]"),
        # Televizní kanály (07.11.2026, plán F2/F3, S6/S13 — parita s Gate `services/log_redaction.py`): tiket a relace
        # v cestě datové roviny (`/tv/t/<tiket>/…`, `/tv/s/<sid>/…`; Kodi loguje plnou URL streamu), tiket mimo cestu,
        # tajemství poskytovatele a podpisy CDN. Písmeno t/s a `rmtv1.` zůstanou kvůli diagnostice.
        # i URL-kódovaně (`%2Ftv%2Fs%2F…` v parametru plugin:// URL) a bez hranice slova (cross-check A3b-Q10)
        (re.compile(r"((?:/|%2F|%252F)tv(?:/|%2F|%252F)[ts](?:/|%2F|%252F))[A-Za-z0-9_.-]+", re.IGNORECASE),
         r"\1[REDACTED]"),
        (re.compile(r"(rmtv1\.)[A-Za-z0-9_.-]+"),
         r"\1[REDACTED]"),
        (re.compile(r"(PHPSESSID|signature-hash|signature-ip|_cdn_token|_cdn_session)(=|%3D|%253D)(?:(?!%26|%2526)[^&\s\"'<>|])+"),
         r"\1\2[REDACTED]"),
    ]

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            # Format msg + args into final string, then scrub
            msg = record.getMessage()
            for pat, repl in self._PATTERNS:
                msg = pat.sub(repl, msg)
            # Replace msg + clear args (formatter must not re-substitute)
            record.msg = msg
            record.args = ()

            # Also scrub any 'context' extra dict
            ctx = getattr(record, "context", None)
            if isinstance(ctx, dict):
                record.context = self._scrub_dict(ctx)
        except Exception:
            # Never let filter raise — would lose the log entirely
            pass
        return True

    def _scrub_dict(self, d: dict[str, Any], depth: int = 0) -> dict[str, Any]:
        if depth > 8:
            return {"__truncated__": True}
        out: dict[str, Any] = {}
        for k, v in d.items():
            if isinstance(v, str):
                for pat, repl in self._PATTERNS:
                    v = pat.sub(repl, v)
                out[k] = v
            elif isinstance(v, dict):
                out[k] = self._scrub_dict(v, depth + 1)
            elif isinstance(v, list):
                out[k] = [self._scrub_value(item, depth + 1) for item in v]
            else:
                out[k] = v
        return out

    def _scrub_value(self, v: Any, depth: int) -> Any:
        if isinstance(v, str):
            for pat, repl in self._PATTERNS:
                v = pat.sub(repl, v)
            return v
        if isinstance(v, dict):
            return self._scrub_dict(v, depth)
        if isinstance(v, list):
            return [self._scrub_value(x, depth + 1) for x in v]
        return v


# ---------------------------------------------------------------------------
# RateLimitingFilter — guardrail proti floodu na NAS (hot-path sampling)
# ---------------------------------------------------------------------------
# PROČ (2026-07-01, iniciativa „DEBUG always-on"): aby jedna rozjetá smyčka
# (per-frame / per-item ×1000 / tight poll) NIKDY nezaplavila sdílený Postgres na
# NASu. Aplikuje se JEN na buffer handler (upload cesta) → lokální kodi.log zůstává
# KOMPLETNÍ pro ladění, na NAS jde vše kromě pathologických záplav.
#
# Mechanismus: token-bucket per „tvar zprávy". Tvar = (logger, level, normalizovaná
# zpráva bez čísel/hexů) → „probe 123 selhal" i „probe 456 selhal" spadnou do stejného
# bucketu. Max _RL_RATE záznamů za _RL_WINDOW s; přebytek se zahodí, ale spočítá.
# Při dalším okně první propuštěný záznam nese souhrn „[rate-limited +N/Ws]".
# Best-effort: filtr NIKDY nevyhodí (chyba → propustí record). Paměť ohraničená.
_RL_RATE = 30              # max identických záznamů za okno
_RL_WINDOW = 60.0         # délka okna [s]
_RL_MAX_KEYS = 2000       # strop sledovaných tvarů (ochrana paměti)
_RL_DIGITS = re.compile(r"\d+")
_RL_LONGHEX = re.compile(r"\b[0-9a-fA-F]{12,}\b")


class RateLimitingFilter(logging.Filter):
    """Per-shape token-bucket rate limiter. Chrání NAS před hot-path floodem."""

    def __init__(self) -> None:
        super().__init__()
        self._lock = threading.Lock()
        # key -> [window_start_ts, count_in_window, suppressed_in_window]
        self._buckets: dict[str, list[float]] = {}

    @staticmethod
    def _shape(record: logging.LogRecord) -> str:
        try:
            msg = record.getMessage()
        except Exception:
            msg = str(getattr(record, "msg", ""))
        msg = _RL_LONGHEX.sub("X", msg)
        msg = _RL_DIGITS.sub("#", msg)
        return "%s|%s|%s" % (record.name, record.levelno, msg[:80])

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            now = time.time()
            key = self._shape(record)
            with self._lock:
                # Ochrana paměti: když přeteče, vyhoď expirované, pak případně vyprázdni.
                if len(self._buckets) > _RL_MAX_KEYS:
                    for k in [k for k, b in self._buckets.items()
                              if now - b[0] >= _RL_WINDOW]:
                        self._buckets.pop(k, None)
                    if len(self._buckets) > _RL_MAX_KEYS:
                        self._buckets.clear()

                b = self._buckets.get(key)
                if b is None or (now - b[0]) >= _RL_WINDOW:
                    # Nové okno. Pokud minulé okno něco potlačilo, propusť tento
                    # záznam a připni souhrn (jede na prvním propuštěném).
                    suppressed = int(b[2]) if b else 0
                    self._buckets[key] = [now, 1.0, 0.0]
                    if suppressed > 0:
                        try:
                            record.msg = "[rate-limited +%d/%ds] %s" % (
                                suppressed, int(_RL_WINDOW), record.getMessage())
                            record.args = ()
                        except Exception:
                            pass
                    return True

                if b[1] < _RL_RATE:
                    b[1] += 1
                    return True

                # Limit v okně vyčerpán → potlač (počítej).
                b[2] += 1
                return False
        except Exception:
            # Filtr nesmí nikdy zabít logování — na chybu propusť.
            return True


# ---------------------------------------------------------------------------
# XBMCFormatter — backwards-compat kodi.log prefix for migrated modules
# ---------------------------------------------------------------------------
# Maps logger name `richmovie.X.Y` -> kodi.log prefix `[RichMovie/X/Y]`.
# Preserves legacy grep patterns like `grep "[RichMovie/Gate]" kodi.log`
# so memory entries + ad-hoc admin scripts keep working.
class XBMCFormatter(logging.Formatter):
    """Format records as `[RichMovie/Capitalized/Path] message`.

    Acronym preservation — known abbreviations stay UPPER (CSFD, AI, MI, etc.)
    so kodi.log greps for legacy prefixes like `[RichMovie/CSFD]` continue
    working after migration.

    Underscore-segments split on `_` for sub-path: `csfd_browser` ->
    `CSFD/Browser`. Acronyms still apply per segment.

    Examples:
        richmovie               -> [RichMovie]
        richmovie.gate          -> [RichMovie/Gate]
        richmovie.csfd          -> [RichMovie/CSFD]
        richmovie.csfd_browser  -> [RichMovie/CSFD/Browser]
        richmovie.ai            -> [RichMovie/AI]
        richmovie.mi_gate       -> [RichMovie/MI/Gate]
        richmovie.tmdb_proxy    -> [RichMovie/TMDb/Proxy]
    """
    # Known acronyms — preserved verbatim (case-sensitive lookup on lowercased seg)
    _ACRONYMS = {
        "ai": "AI", "csfd": "CSFD", "tmdb": "TMDb", "mi": "MI",
        "ws": "WS", "fs": "FS", "yt": "YT", "rcai": "RCAI",
        "url": "URL", "api": "API", "http": "HTTP", "ssl": "SSL",
        "ui": "UI", "id": "ID", "io": "IO", "os": "OS",
        "smb": "SMB", "imdb": "IMDb", "vip": "VIP",
    }

    @classmethod
    def _display_segment(cls, seg: str) -> str:
        seg_low = seg.lower()
        if seg_low in cls._ACRONYMS:
            return cls._ACRONYMS[seg_low]
        # Compound segment with underscore: csfd_browser -> CSFD/Browser
        if "_" in seg_low:
            parts = seg_low.split("_")
            return "/".join(cls._display_segment(p) for p in parts if p)
        return seg.capitalize()

    def format(self, record: logging.LogRecord) -> str:
        name = record.name or ""
        if name == _LOGGER_NAME_PREFIX:
            display = "RichMovie"
        elif name.startswith(_LOGGER_NAME_PREFIX + "."):
            suffix = name[len(_LOGGER_NAME_PREFIX) + 1:]
            parts = [self._display_segment(seg) for seg in suffix.split(".")]
            display = "RichMovie/" + "/".join(parts)
        else:
            display = name
        return "[%s] %s" % (display, record.getMessage())


# ---------------------------------------------------------------------------
# XBMCHandler — bridge to xbmc.log() (Elementum-style pattern)
# ---------------------------------------------------------------------------
class XBMCHandler(logging.Handler):
    """Forward Python logging records to xbmc.log() so existing kodi.log
    consumers + richmovie.log mirror still work.

    Maps logging level -> xbmc.LOG* constant. Idempotent — multiple init
    calls don't double-log.
    """

    def __init__(self, level: int = logging.DEBUG) -> None:
        super().__init__(level)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            if xbmc is None:
                return  # Out-of-Kodi context (testing) — skip
            msg = self.format(record)
            kodi_level = _KODI_LEVEL_MAP.get(record.levelno, 1)  # default LOGINFO
            xbmc.log(msg, kodi_level)
        except Exception:
            self.handleError(record)


# ---------------------------------------------------------------------------
# RichLogHandler — persists to SQLite buffer
# ---------------------------------------------------------------------------
class RichLogHandler(logging.Handler):
    """Persists each log record to SQLite WAL buffer.

    Drainer thread (in service_warm.py) reads unsent rows from the same DB
    and uploads to Gate /v1/user_logs/batch.

    Per-process buffer instance — plugin processes use short-lived connection,
    service process uses persistent connection (SQLite WAL handles both via
    BEGIN IMMEDIATE + busy_timeout=5000).
    """

    def __init__(self, buffer: LogBuffer, addon_version: str = "") -> None:
        super().__init__()
        self._buffer = buffer
        self._addon_version = addon_version
        self.addFilter(RedactingFilter())

    def emit(self, record: logging.LogRecord) -> None:
        try:
            level_name = logging.getLevelName(record.levelno)
            if level_name not in ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"):
                return  # Custom levels not supported by server schema
            msg = record.getMessage()  # Already redacted by RedactingFilter
            ctx = getattr(record, "context", None)
            if not isinstance(ctx, dict):
                ctx = None
            # Add traceback to context for ERROR/CRITICAL
            if record.exc_info:
                import traceback
                ctx = dict(ctx or {})
                tb_str = "".join(traceback.format_exception(*record.exc_info))
                # Apply redaction to traceback (filter doesn't touch exc_info)
                for pat, repl in RedactingFilter._PATTERNS:
                    tb_str = pat.sub(repl, tb_str)
                ctx["traceback"] = tb_str[-2000:]  # last 2KB

            self._buffer.insert(
                level=level_name,
                source=record.name,
                message=msg,
                context=ctx,
                addon_version=self._addon_version,
                session_id=_SESSION_ID or "",
                ts_unix=record.created,
            )
        except Exception:
            self.handleError(record)


# ---------------------------------------------------------------------------
# Bootstrap — call once per Python interpreter (plugin.py + service_*.py)
# ---------------------------------------------------------------------------
_init_lock = threading.Lock()
_initialized = False


def init_logging(
    addon: Any | None = None,
    profile_dir: Path | str | None = None,
    *,
    root_level: int = logging.INFO,
    enable_xbmc: bool = True,
    enable_buffer: bool = True,
) -> None:
    """Initialize RichMovie logging pipeline.

    Audit Ω3 (2026-05-17): default root_level changed from DEBUG to INFO.
    Memory `project_user_logs_pipeline.md`: "DEBUG default OFF, admin enable
    per-user via users.debug_logs_enabled". Previously DEBUG flood was
    ingested unconditionally — ~10x bandwidth/disk vs design intent.

    Admin can opt a user into DEBUG via `set_debug(True)` helper below or
    by setting Kodi addon setting (Phase 2 wiring). Server-side
    `/v1/user_logs/batch` should also drop DEBUG rows when flag is FALSE
    (defense-in-depth — separate ticket).
    """
    """Initialize RichMovie logging pipeline.

    Idempotent — multiple calls per interpreter no-op after first success.
    Adds XBMCHandler + RichLogHandler to root logger under
    `richmovie.*` namespace.

    Args:
        addon: xbmcaddon.Addon instance (optional, auto-detect)
        profile_dir: Path to addon_data dir (auto-detect if None)
        root_level: minimum level captured (default DEBUG = capture all,
                    upload threshold filtered server-side or by drainer)
        enable_xbmc: bridge to xbmc.log (default True)
        enable_buffer: persist to SQLite buffer for upload (default True)
    """
    global _initialized, _SESSION_ID
    with _init_lock:
        if _initialized:
            return

        # Resolve addon + profile dir
        if addon is None and xbmcaddon is not None:
            try:
                addon = xbmcaddon.Addon(_ADDON_ID)
            except Exception:
                addon = None
        if profile_dir is None and addon is not None and xbmcvfs is not None:
            try:
                profile_dir = Path(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
            except Exception:
                profile_dir = None

        addon_version = ""
        if addon is not None:
            try:
                addon_version = addon.getAddonInfo("version") or ""
            except Exception:
                pass

        _SESSION_ID = str(uuid.uuid4())

        # Configure root richmovie logger
        rm_logger = logging.getLogger(_LOGGER_NAME_PREFIX)
        rm_logger.setLevel(root_level)
        rm_logger.propagate = False  # Don't propagate to root (avoid Kodi default handler)

        # Clear any stale handlers (idempotent re-init defensive)
        for h in list(rm_logger.handlers):
            rm_logger.removeHandler(h)

        # XBMCFormatter preserves legacy [RichMovie/X] prefixes for kodi.log
        # so existing grep patterns / memory references continue to work.
        fmt = XBMCFormatter()

        if enable_xbmc:
            xbmc_h = XBMCHandler()
            xbmc_h.setFormatter(fmt)
            xbmc_h.addFilter(RedactingFilter())
            rm_logger.addHandler(xbmc_h)

        if enable_buffer and profile_dir is not None:
            try:
                profile_dir = Path(profile_dir)
                buffer_path = profile_dir / _DEFAULT_BUFFER_FILENAME
                buffer = get_buffer(buffer_path)
                buf_h = RichLogHandler(buffer, addon_version=addon_version)
                # Guardrail: rate-limit JEN na upload cestu (NAS). Lokální kodi.log
                # (XBMCHandler) zůstává kompletní. RedactingFilter už je v RichLogHandler
                # __init__ (běží první → rate-limit vidí redigovanou zprávu).
                buf_h.addFilter(RateLimitingFilter())
                rm_logger.addHandler(buf_h)
            except Exception as exc:
                # Buffer failure must not kill addon — log via xbmc only
                if xbmc is not None:
                    xbmc.log(
                        "[RichMovie/Logging] Buffer init failed: %s" % exc,
                        2,  # LOGNOTICE
                    )

        _initialized = True


def set_debug(enabled: bool) -> None:
    """Toggle DEBUG-level capture on the richmovie.* logger tree.

    Audit Ω3 (2026-05-17): allows runtime opt-in to verbose logging without
    re-running init_logging. Should be called when addon sees
    `users.debug_logs_enabled = TRUE` from /auth response (Phase 2 wiring).

    No-op safe: if init_logging() hasn't run yet, just sets level on the
    logger object (next init_logging will overwrite per its kwarg).
    """
    rm_logger = logging.getLogger(_LOGGER_NAME_PREFIX)
    rm_logger.setLevel(logging.DEBUG if enabled else logging.INFO)


# ---------------------------------------------------------------------------
# Public API: get_logger(name)
# ---------------------------------------------------------------------------
def get_logger(name: str) -> logging.Logger:
    """Returns logging.Logger pod richmovie.* namespace.

    Pouziti:
        from richmovie_logging import get_logger
        log = get_logger(__name__)
        log.info("Search started", extra={"context": {"query": "Pán prstenů"}})
        log.error("Failed to fetch", exc_info=True)

    Pokud init_logging() jeste nebezel, vrati standard logger bez handlers
    (no-op safety) — bootstrap z plugin.py / service.py bezi pri prvni
    invokaci.
    """
    if not name.startswith(_LOGGER_NAME_PREFIX):
        # Auto-prefix custom names so vse pod richmovie.* hierarchy
        if name == "__main__" or name == _LOGGER_NAME_PREFIX:
            name = _LOGGER_NAME_PREFIX
        else:
            # plugin module names like "richmovie_engine" -> "richmovie.engine"
            short = name.replace(_LOGGER_NAME_PREFIX + "_", "").replace(
                _LOGGER_NAME_PREFIX, "")
            name = f"{_LOGGER_NAME_PREFIX}.{short.lstrip('.')}"
    return logging.getLogger(name)


def get_session_id() -> str:
    """Returns current process session ID (UUID4). Empty if not initialized."""
    return _SESSION_ID or ""


# ---------------------------------------------------------------------------
# Phase 9 migration helper — drop-in replacement for legacy `_log` helpers
# ---------------------------------------------------------------------------
# Map xbmc.LOG* constants -> Python logging levels
# `_XBMC_TO_PY_LEVEL` — inverzní tabulka k `_KODI_LEVEL_MAP`, viz `_build_level_maps()`
# nahoře (3.5.123: jedna definice, odvozená z konstant `xbmc`).


def make_legacy_logger(logger_name: str, fallback_prefix: str):
    """Drop-in replacement for legacy `_log(msg, level)` helpers.

    Usage in any RichMovie module:
        from richmovie_logging import make_legacy_logger
        _log = make_legacy_logger("richmovie.gate", "RichMovie/Gate")
        # ... existing call sites work unchanged ...
        _log("Auth OK")
        _log("Token rejected", xbmc.LOGWARNING)
        _log("Search done", context={"q": "foo", "n": 42})  # NEW: structured

    Behavior:
    - If init_logging() ran, routes through richmovie_logging pipeline:
      kodi.log via XBMCHandler (preserves [RichMovie/X] prefix via XBMCFormatter)
      + SQLite buffer via RichLogHandler (uploaded to Gate /v1/user_logs/batch)
    - If pipeline not init'd, falls back to direct xbmc.log with fallback_prefix.
    - context kwarg adds JSONB structured data for admin filtering / forensics.

    Args:
        logger_name: Python logger namespace (e.g. "richmovie.gate")
        fallback_prefix: Used only as kodi.log prefix if logging pipeline
                          unavailable (e.g. "RichMovie/Gate")
    """
    try:
        log = get_logger(logger_name)
    except Exception:
        log = None

    def _log(msg, level=1, *, context=None):
        # 2026-07-01 (observability program): CELÉ tělo best-effort. `_log` se volá
        # i UVNITŘ `except` bloků (náhrada za tiché `except: pass`) — nesmí NIKDY
        # propagovat výjimku (jinak by nahradil původní chybu a mohl shodit tok).
        try:
            # 3.5.123: routovat JEN když pipeline opravdu běží. Bez handlerů
            # `log.log()` tiše uspěje (Python nemá kam psát) a fallback níže se
            # nikdy nespustí → zprávy z doby PŘED `init_logging()` (importy,
            # rané guardy, procesy bez inicializace) mizely beze stopy — přesně
            # ten typ tichého selhání, který diagnostika nesmí mít
            # (`feedback_diagnostic_channel_independence`; odhaleno harness
            # scénářem 40, kde `richmovie_atomic` hlásil WRITE_FAILED do prázdna).
            if log is not None and _initialized:
                py_level = _XBMC_TO_PY_LEVEL.get(level, logging.INFO)
                if context:
                    log.log(py_level, msg, extra={"context": context})
                else:
                    log.log(py_level, msg)
                return
        except Exception:
            # Routing selhalo → zkus aspoň kodi.log fallback níže (nikdy neshoď).
            pass
        # Fallback: pipeline neinicializovaná (nebo routing spadl) → kodi.log.
        if xbmc is not None:
            try:
                xbmc.log("[%s] %s" % (fallback_prefix, msg), level)
            except Exception:
                pass

    return _log
