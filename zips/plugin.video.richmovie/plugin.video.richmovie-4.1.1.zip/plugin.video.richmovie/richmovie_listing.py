# -*- coding: utf-8 -*-
"""
richmovie_listing — SSOT identity listingu + rozhodovací brána MI2 (3.5.153).

PROČ EXISTUJE (incident Petra / Sony obývák 19.09.2026)
------------------------------------------------------
`_list_releases()` i `richmovie_mi2.start()` si braly klíč listingu z
`xbmc.getInfoLabel("Container.FolderPath")`. Jenže obojí běží UVNITŘ stavby
adresáře, tedy PŘED `endOfDirectory()` — a v tu chvíli je `Container.FolderPath`
pořád cesta, ze které ODCHÁZÍME, ne listing, který stavíme.

Runtime důkaz (Sony BRAVIA, 19.09.2026 16:35:59, kodi.log):

    [RichMovie/Mi2] SKIP: all cached (32/32)
      key=plugin://plugin.video.richmovie/?action=show_recommendations

…v okamžiku, kdy se vypisovalo 127 streamů Terminátora 2. Klíč tedy ukazoval na
obrazovku doporučení, ze které uživatel klikl.

Následky špatného klíče:
  • `richmovie.mi2.refresh_key` mířil na cizí kontejner → `MI2_REFRESH_KEY_MISMATCH`
    při každém refreshi,
  • mezi-invokerový dedup MI2 (`running_key`) byl klíčovaný na předchozí obrazovku →
    dvě různá hledání spuštěná z TÉŽE rodičovské obrazovky se navzájem blokovala
    (`SKIP_GLOBAL: MI2 running for other key`),
  • `updateListing` se odvozoval z „marker existuje vůbec" místo „marker patří TOMUTO
    listingu", takže čerstvá navigace se chovala jako in-place refresh.

SPRÁVNÝ KLÍČ = URL INVOKACE (`sys.argv[0] + sys.argv[2]`). To je přesně ta cesta,
kterou kontejner BUDE mít po `endOfDirectory()` — Kodi ji zná už při volání pluginu.

Modul je ZÁMĚRNĚ čistý (bez importu `xbmc*` na úrovni modulu), aby šel celý
otestovat v `_tools/net_resilience_sim/` bez Kodi. Jediné místo, kde se sahá na
Kodi, je `listing_key_from_kodi()` — a i to je jen fallback.

Pravidla projektu, která se tu drží:
  • Kodi 21.2 Windows = Python 3.8.15 → `from __future__ import annotations` je POVINNÉ.
  • Rozhodnutí je čistá funkce, vedlejší efekty zůstávají volajícímu (vzor
    `richmovie_playback_end.classify_end`, `richmovie_attention.should_ask`).
"""

from __future__ import annotations

import sys
import urllib.parse
from typing import Any, Dict, Optional, Sequence, Tuple

# --------------------------------------------------------------------------- #
# Konstanty
# --------------------------------------------------------------------------- #

#: Důvody MI2 refresh markeru (`richmovie.mi2.refresh_reason`).
REFRESH_REASONS: Tuple[str, ...] = ("first", "final", "deferred")

#: Strop čekání na MI2 před zobrazením seznamu streamů.
#:
#: Historie: Beta.7 (25.04.2026) zvedla okno z 5 s na 60 s na Richieho přání —
#: „raw výsledky bez kvality/audio/subs jsou matoucí". Záměr platí dál, ale 60 s
#: se na pomalém zařízení s chladnou MI cache projevilo jako 36 s od kliku
#: k seznamu (Sony 19.09.2026). Richieho rozhodnutí 19.09.2026: strop 12 s,
#: zbytek dojede automatickým `Container.Refresh` s badge.
MI2_WAIT_CAP_S: float = 12.0

#: Strop čekání tam, kde NENÍ otevřený průběhový dialog (cache-hit, reentry).
#: Bez dialogu nemá uživatel zpětnou vazbu ani tlačítko Zrušit — držet mu obraz
#: 12 sekund jen s točítkem Kodi je horší než ukázat seznam a doplnit odznaky
#: refreshem (audit Fable P1 #4). Na teplé MI cache stejně vlákno skončí dřív.
MI2_WAIT_NODIALOG_CAP_S: float = 3.0

#: Neznámý klíč — nikdy se neshoduje sám se sebou v rozhodování (viz `_usable`).
UNKNOWN_KEY: str = "unknown"


# --------------------------------------------------------------------------- #
# Kanonizace a odvození klíče
# --------------------------------------------------------------------------- #

def canon_key(raw: Any) -> str:
    """
    Kanonický tvar plugin URL: seřazené query parametry, bez fragmentu,
    bez koncového lomítka v cestě.

    Kodi vrací `Container.FolderPath` s libovolným pořadím parametrů, takže
    porovnávat syrové řetězce nelze. Vrací `UNKNOWN_KEY` pro prázdný vstup —
    NIKDY nevyhazuje (klíč listingu nesmí shodit výpis).
    """
    s = str(raw or "").strip()
    if not s:
        return UNKNOWN_KEY
    try:
        u = urllib.parse.urlparse(s)
        qsl = urllib.parse.parse_qsl(u.query, keep_blank_values=True)
        query = urllib.parse.urlencode(sorted(qsl, key=lambda kv: (kv[0], kv[1])), doseq=True)

        path = u.path or ""
        if path.endswith("/") and path != "/":
            path = path.rstrip("/")

        out = urllib.parse.urlunparse(u._replace(query=query, fragment="", path=path))
        return out or s
    except Exception:
        return s or UNKNOWN_KEY


def listing_key_from_argv(argv: Optional[Sequence[str]] = None) -> str:
    """
    Klíč listingu z URL invokace pluginu: `argv[0]` (base) + `argv[2]` (query).

    Tohle je JEDINÝ správný zdroj — Kodi nám předává přesně tu cestu, kterou bude
    mít kontejner po `endOfDirectory()`. `Container.FolderPath` je v tu chvíli
    ještě cesta, ze které odcházíme (viz hlavička modulu).

    Vrací `UNKNOWN_KEY`, když argv nemá tvar plugin invokace (např. běh ve službě
    nebo v harnessu) — volající pak smí sáhnout po `listing_key_from_kodi()`.
    """
    av = list(argv) if argv is not None else list(sys.argv)
    if len(av) < 1:
        return UNKNOWN_KEY

    base = str(av[0] or "").strip()
    if not base.startswith("plugin://"):
        return UNKNOWN_KEY

    query = str(av[2] or "").strip() if len(av) >= 3 else ""
    if query and not query.startswith("?"):
        query = "?" + query

    return canon_key(base + query)


def listing_key_from_kodi() -> str:
    """
    Fallback: klíč z `Container.FolderPath`.

    POUŽÍVAT JEN tam, kde `sys.argv` není invokace pluginu (služba, kontextové
    akce bez handle). V renderovací cestě je to ŠPATNĚ — právě tenhle fallback
    způsobil incident 19.09.2026.
    """
    try:
        import xbmc  # lokální import: modul musí zůstat importovatelný bez Kodi
        return canon_key(xbmc.getInfoLabel("Container.FolderPath") or "")
    except Exception:
        return UNKNOWN_KEY


def current_listing_key(argv: Optional[Sequence[str]] = None) -> str:
    """Klíč tohoto listingu: argv (autorita) → `Container.FolderPath` (nouze)."""
    key = listing_key_from_argv(argv)
    if _usable(key):
        return key
    return listing_key_from_kodi()


def _usable(key: Any) -> bool:
    """Klíč je použitelný pro porovnání (není prázdný ani `unknown`)."""
    s = str(key or "").strip()
    return bool(s) and s != UNKNOWN_KEY


# --------------------------------------------------------------------------- #
# Porovnání cíle (best-effort, když se liší jen `action=`)
# --------------------------------------------------------------------------- #

def _query_params(url: Any) -> Dict[str, str]:
    try:
        q = urllib.parse.urlparse(str(url or "")).query
        parsed = urllib.parse.parse_qs(q, keep_blank_values=True)
        return {k: (v[0] if isinstance(v, list) and v else "") for k, v in parsed.items()}
    except Exception:
        return {}


def targets_match(key_a: Any, key_b: Any) -> bool:
    """
    Míří oba klíče na TÝŽ titul, i když se liší `action=`?

    Týž film může být vypsaný z různých akcí (`auto`, `open_recommendation`,
    `movie_search`), týž díl seriálu z `tv_episodes` i `tv_play`. Pro rozhodnutí
    „je tenhle MI2 refresh můj?" je rozhodující CÍL, ne cesta, kterou se tam šlo.
    """
    if not (_usable(key_a) and _usable(key_b)):
        return False

    p1 = _query_params(key_a)
    p2 = _query_params(key_b)
    if not p1 or not p2:
        return False

    # Díl seriálu: tv_id + sezóna + epizoda (názvy parametrů se historicky liší)
    if "tv_id" in p1 and "tv_id" in p2:
        s1 = p1.get("season") or p1.get("season_no") or ""
        s2 = p2.get("season") or p2.get("season_no") or ""
        e1 = p1.get("ep_no") or p1.get("episode") or p1.get("ep") or ""
        e2 = p2.get("ep_no") or p2.get("episode") or p2.get("ep") or ""
        if s1 and s2 and e1 and e2:
            return p1.get("tv_id") == p2.get("tv_id") and s1 == s2 and e1 == e2

    # Film: tmdb_id (v obou tvarech, které plugin historicky posílá)
    t1 = p1.get("tmdb_id") or p1.get("tmdb") or ""
    t2 = p2.get("tmdb_id") or p2.get("tmdb") or ""
    if t1 and t2:
        # TMDb id filmu a seriálu si mohou být rovna — když je druh k dispozici,
        # musí sedět taky (audit Fable). Když chybí u jednoho, nerozhoduje.
        k1 = (p1.get("kind") or "").strip().lower()
        k2 = (p2.get("kind") or "").strip().lower()
        if k1 and k2 and k1 != k2:
            return False
        return t1 == t2

    return False


# --------------------------------------------------------------------------- #
# Rozhodovací brána listingu (čistá)
# --------------------------------------------------------------------------- #

class ListingPlan(object):
    """
    Výsledek `plan_listing()` — co má renderovací cesta udělat.

    Záměrně obyčejná třída (ne dataclass): Kodi 21.2 na Windows jede Python 3.8
    a modul se importuje i v harnessu.
    """

    __slots__ = ("is_refresh_any", "is_refresh_call", "kick_mi2",
                 "update_listing", "mismatch")

    def __init__(
        self,
        is_refresh_any: bool,
        is_refresh_call: bool,
        kick_mi2: bool,
        update_listing: bool,
        mismatch: bool,
    ) -> None:
        self.is_refresh_any = bool(is_refresh_any)
        self.is_refresh_call = bool(is_refresh_call)
        self.kick_mi2 = bool(kick_mi2)
        self.update_listing = bool(update_listing)
        self.mismatch = bool(mismatch)

    def __repr__(self) -> str:  # pragma: no cover — jen pro ladění
        return (
            "ListingPlan(refresh_any=%r, refresh_call=%r, kick=%r, update=%r, mismatch=%r)"
            % (self.is_refresh_any, self.is_refresh_call, self.kick_mi2,
               self.update_listing, self.mismatch)
        )

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, ListingPlan):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self.__slots__)


def same_listing(key_a: Any, key_b: Any) -> bool:
    """JEDINÁ definice „tyhle dva klíče jsou tentýž listing".

    Shodný kanonický tvar, nebo týž cíl (`targets_match`). Používá ji brána
    `plan_listing`, smyčka dopadu v `_list_releases` i `dropped_verdict` —
    dřív měla každá vlastní variantu (audit Fable F-B).
    """
    a, b = canon_key(key_a), canon_key(key_b)
    if not (_usable(a) and _usable(b)):
        return False
    return a == b or targets_match(a, b)


def marker_present(marker_reason: Any, marker_key: Any) -> bool:
    """Existuje MI2 refresh marker (ať míří kamkoli)?

    SSOT pro rozhodnutí smaze se marker. Volají to jak `plan_listing`, tak
    obě místa v `plugin.py`, která marker po renderu uklízejí — dřív si každé
    z nich vedlo vlastní žebříček podmínek včetně kopie `targets_match`
    (audit Fable P1 #5, 19.09.2026).
    """
    reason = str(marker_reason or "").strip().lower()
    return bool(reason in REFRESH_REASONS and str(marker_key or "").strip())


def plan_listing(
    *,
    cur_key: Any,
    marker_reason: Any,
    marker_key: Any,
    has_releases: bool,
    mi2_running_here: bool,
    mi2_thread_alive: bool,
) -> ListingPlan:
    """
    Jediné místo, kde se rozhoduje, co renderovací cesta udělá s MI2.

    Vstupy jsou hodnoty PŘEČTENÉ volajícím (Window props, stav MI2 vlákna),
    výstup je rozhodnutí. Žádný vedlejší efekt, žádný Kodi — proto je to
    celé testovatelné v harnessu.

    Sémantika:
      • `is_refresh_any`  – marker existuje (ať míří kamkoli)
      • `is_refresh_call` – marker patří TOMUTO listingu (shodný klíč nebo týž cíl)
      • `kick_mi2`        – spustit novou MI2 dávku
      • `wait_mi2`        – počkat na MI2 před renderem (strop `MI2_WAIT_CAP_S`)
      • `update_listing`  – `endOfDirectory(updateListing=…)`
      • `clear_marker`    – smazat marker, ať nevisí mezi obrazovkami
      • `mismatch`        – marker existuje, ale patří jinam (po opravě klíče
                            už by nemělo nastávat → hlídá to harness)

    ZMĚNA 3.5.153 oproti 3.5.152: `update_listing` se odvozuje z `is_refresh_call`,
    ne z `is_refresh_any`. Marker patřící CIZÍMU kontejneru nesmí z čerstvé
    navigace udělat in-place update — přesně to dělal rozbitý klíč.
    """
    reason = str(marker_reason or "").strip().lower()
    mkey = str(marker_key or "").strip()
    ckey = str(cur_key or "").strip()

    is_refresh_any = marker_present(reason, mkey)

    is_refresh_call = bool(
        is_refresh_any
        and _usable(ckey)
        and same_listing(mkey, ckey)
    )

    # Když klíč TOHOTO listingu neznáme, nelze tvrdit, že marker patří jinam —
    # `mismatch` je nález, ne nejistota (audit Fable).
    mismatch = bool(is_refresh_any and _usable(ckey) and not is_refresh_call)

    kick_mi2 = bool(
        has_releases
        and not is_refresh_any
        and not mi2_running_here
        and not mi2_thread_alive
    )

    return ListingPlan(
        is_refresh_any=is_refresh_any,
        is_refresh_call=is_refresh_call,
        kick_mi2=kick_mi2,
        update_listing=is_refresh_call,
        mismatch=mismatch,
    )


# --------------------------------------------------------------------------- #
# Rozpočet čekání na MI2
# --------------------------------------------------------------------------- #

def wait_budget_s(elapsed_s: float, cap_s: float = MI2_WAIT_CAP_S) -> float:
    """
    Kolik sekund ještě smí čekání na MI2 trvat.

    Strop je na CELOU invokaci, ne na jednotlivé čekání: když už hledání
    spotřebovalo `elapsed_s`, MI2 dostane jen zbytek. Nikdy záporné číslo.
    """
    try:
        cap = float(cap_s)
    except Exception:
        cap = MI2_WAIT_CAP_S
    try:
        spent = float(elapsed_s)
    except Exception:
        spent = 0.0
    if spent < 0.0:
        spent = 0.0
    return max(0.0, cap - spent)


def encode_published(key: Any, count: int, ts: float) -> str:
    """Otisk vydaneho listingu do Window property: `ts|count|key`."""
    try:
        ts_f = float(ts)
    except (TypeError, ValueError):
        ts_f = 0.0
    try:
        count_i = int(count)
    except (TypeError, ValueError):
        count_i = 0
    return "%.3f|%d|%s" % (ts_f, count_i, canon_key(key))


def decode_published(raw: Any) -> Optional[Tuple[float, int, str]]:
    """Zpet na (ts, count, key); None kdyz je zaznam necitelny."""
    try:
        ts_text, count_text, key = str(raw or "").split("|", 2)
        return float(ts_text), int(count_text), key
    except Exception:
        return None


def dropped_verdict(
    published: Any,
    container_key: Any,
    now_ts: float,
    max_age_s: float = 180.0,
) -> Optional[Dict[str, Any]]:
    """Zahodilo Kodi posledni vydany listing?

    `published` je hodnota zapsana `encode_published()` po `endOfDirectory`.
    Verdikt je None, kdyz zaznam neexistuje, je necitelny, uz je stary
    (jina navigace mezitim) NEBO kdyz se kontejner opravdu stal tim listingem.

    Vraci dict pro `LISTING_DROPPED`, kdyz plugin vydal NEPRAZDNY listing,
    ale kontejner zustal jinde - presne symptom „hledalo to streamy a pak nic"
    (Petra / Sony 19.09.2026). Prazdny listing se nehlasi: tam je zustat na
    miste spravne chovani.
    """
    rec = decode_published(published)
    if rec is None:
        return None

    ts, count, key = rec
    if count <= 0:
        return None
    if not _usable(key):
        return None

    try:
        age = float(now_ts) - ts
        limit = float(max_age_s)
    except (TypeError, ValueError):
        return None
    if age < 0.0 or age > limit:
        return None

    ckey = canon_key(container_key)
    if not _usable(ckey):
        return None
    if same_listing(ckey, key):
        return None

    return {
        "published_key": key,
        "container_key": ckey,
        "items": count,
        "age_s": round(age, 2),
    }


#: Kolik položek MI2 v jedné dávce probuje (`MI2.start(max_items=…)`).
#: Early-exit čekání musí koukat na TÝŽ výřez — u 127 streamů by jinak čekal na
#: výšku u položek, které MI2 nikdy nesáhne, a nikdy by se nespustil (audit Fable).
MI2_BATCH_ITEMS: int = 32


#: Kolik řádků výpisu uživatel uvidí bez posouvání — na TOLIK se čeká na MediaInfo (Φ5A, rozhodnutí D3
#: 29.09.2026: „hned prvních ~10 řádků se známými údaji, zbytek tiše“; Estuary „Seznam“ na 1080p = 10 řádků).
#: Dřív se čekalo na všech 32 → strop 12 s vyčerpaly 3 ze 4 hledání filmu na PC (audit A06 F01).
FIRST_SCREEN_ITEMS: int = 10

#: Window property: kolik řádků první obrazovky bylo při vykreslení NEvyřízených (`<klíč>|<počet>`).
#: Závěrečný refresh MI2 má smysl jen tehdy, když > 0 (jinak by jen přeskládal to, co už uživatel vidí).
PROP_TOP_UNSETTLED: str = "richmovie.listing.top_unsettled"


def item_settled(it: Any, flags_for: Any) -> bool:
    """Je u položky rozhodnuto o kvalitě? Výška známá (Webshare nebo MI2), nebo sonda definitivně
    selhala (`fail` marker — nic dalšího už nepřijde, čekat na ni nemá smysl)."""
    try:
        if getattr(it, "ws_height", None):
            return True
    except Exception:
        pass
    try:
        flags = flags_for(getattr(it, "ident", "")) or {}
    except Exception:
        return False
    vh = flags.get("video_h", None)
    if isinstance(vh, (int, float)) and not isinstance(vh, bool) and int(vh) > 0:
        return True
    return bool(flags.get("fail"))


def first_screen_settled(items: Sequence[Any], flags_for: Any,
                         limit: int = FIRST_SCREEN_ITEMS) -> Tuple[int, int]:
    """(vyřízeno, celkem) z prvních `limit` položek v pořadí výpisu. Čistá."""
    head = list(items or ())[:max(0, int(limit))]
    return sum(1 for it in head if item_settled(it, flags_for)), len(head)


def encode_top_marker(key: Any, unsettled: int) -> str:
    return "%s|%d" % (canon_key(key), max(0, int(unsettled)))


def final_refresh_needed(marker_raw: Any, run_key: Any) -> bool:
    """Má MI2 po doběhnutí překreslit výpis? Čistá.

    Ne, když marker patří TOMUTO výpisu a první obrazovka byla při vykreslení celá vyřízená — výpis by se
    jen přeskládal pod rukama (D3: „zbytek tiše“). Ano, když chybí marker nebo patří jinému výpisu
    (bezpečná strana = dnešní chování) anebo když první obrazovka zůstala neúplná (vyčerpaný strop)."""
    raw = str(marker_raw or "")
    key, sep, cnt = raw.rpartition("|")
    if not sep or not same_listing(key, run_key):
        return True
    try:
        return int(cnt) > 0
    except ValueError:
        return True
