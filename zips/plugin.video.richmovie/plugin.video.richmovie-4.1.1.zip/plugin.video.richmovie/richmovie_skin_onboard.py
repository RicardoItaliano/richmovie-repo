# -*- coding: utf-8 -*-
"""RichMovie 4.0 — skin onboarding (NABÍDNI, NEVYNUCUJ).

Nabídne přepnutí na ``skin.richmovie`` přes ``Skin.SetSkin`` builtin. Kodi pak
sám zobrazí potvrzovací dialog „Ponechat tento vzhled?" s ~15s auto-revertem
(= brick-safe záchranná brzda). ŽÁDNÝ tichý zápis ``guisettings.xml``.

Bezpečnostní brány (vše musí projít, jinak se nic neukáže):
  1) běžící skin už NENÍ skin.richmovie,
  2) killswitch ``skin_onboard_enabled`` (bool, default FALSE — rodina) NEBO
     per-user ``skin_onboard_owner`` == aktuální ws_username (richiefm testuje hned),
  3) skin.richmovie je nainstalovaný,
  4) max 1× za session (Window(10000) property),
  5) po odmítnutí už nenabízet ve STEJNÉ verzi addonu (settings text flag).

Volá se na ZAČÁTKU action=root (PŘED endOfDirectory) — modal z běžícího skriptu
je spolehlivý; po endOfDirectory ne. Diagnostika přes LOGINFO (viditelné i bez
debug módu), aby šlo dohledat, kterou branou to prošlo.

Best-effort: jakákoli chyba se zaloguje (LOGWARNING) a spolkne — nikdy neshodí addon.
"""
from __future__ import annotations

import xbmc
import xbmcgui
import richmovie_settings  # SSOT čtení i ověřeného zápisu nastavení (3.5.124)

_SKIN_ID = "skin.richmovie"
_SESSION_PROP = "richmovie.skin_onboard.shown"
_TAG = "[RichMovie/SkinOnboard]"


def _log(msg: str, level: int = xbmc.LOGINFO) -> None:
    try:
        xbmc.log(f"{_TAG} {msg}", level)
    except Exception:
        pass


def _skin_installed(skin_id: str) -> bool:
    try:
        return xbmc.getCondVisibility(f"System.HasAddon({skin_id})") == 1
    except Exception:
        return False


def apply_skin() -> None:
    """Přímé přepnutí na skin.richmovie (volá settings action tlačítko)."""
    _log("apply_skin() → Skin.SetSkin(skin.richmovie)")
    xbmc.executebuiltin(f"Skin.SetSkin({_SKIN_ID})")


def maybe_offer(addon) -> bool:
    """Best-effort nabídka skin.richmovie. Volat na ZAČÁTKU action=root.

    Vrací True, pokud bylo spuštěno přepnutí skinu (volající MUSÍ pak skip
    těžkého renderu — plugin musí hned skončit, jinak Kodi přepnutí nezpracuje;
    SetSkin z běžícího pluginu se provede až když invoker doběhne)."""
    try:
        cur = xbmc.getSkinDir()
        if cur == _SKIN_ID:
            _log(f"už běží {_SKIN_ID} — nenabízím")
            return False
        enabled = (richmovie_settings.get_str("skin_onboard_enabled") or "false").strip().lower() == "true"
        owner = (richmovie_settings.get_str("skin_onboard_owner") or "").strip().lower()
        ws_user = (richmovie_settings.get_str("username") or "").strip().lower()
        is_owner = bool(owner) and ws_user == owner
        if not (enabled or is_owner):
            _log(f"brána neprošla (enabled={enabled}, owner='{owner}', ws='{ws_user}') — spím")
            return False
        win = xbmcgui.Window(10000)
        if win.getProperty(_SESSION_PROP) == "1":
            _log("už nabídnuto v této session — přeskakuji")
            return False
        ver = addon.getAddonInfo("version") or ""
        if (richmovie_settings.get_str("skin_onboard_declined_ver") or "") == ver:
            _log(f"odmítnuto ve verzi {ver} — přeskakuji")
            return False
        win.setProperty(_SESSION_PROP, "1")
        _log(f"brána OK (enabled={enabled}, is_owner={is_owner}, cur_skin={cur}) — zobrazuji dialog")

        yes = xbmcgui.Dialog().yesno(
            "RichMovie 4.0",
            "Zapnout nový RichMovie vzhled (Estoril Blau)?\n\n"
            "Kodi se ještě jednou zeptá na potvrzení. Kdykoli se vrátíš zpět "
            "v Nastavení → Rozhraní → Vzhled.",
            nolabel="Teď ne",
            yeslabel="Zapnout",
        )
        _log(f"uživatel zvolil: {'ANO' if yes else 'NE'}")
        if yes:
            apply_skin()
            return True
        try:
            richmovie_settings.write("skin_onboard_declined_ver", ver)
        except Exception:
            pass
        return False
    except Exception as exc:  # best-effort — neshodit addon
        _log(f"výjimka: {exc}", xbmc.LOGWARNING)
        return False
