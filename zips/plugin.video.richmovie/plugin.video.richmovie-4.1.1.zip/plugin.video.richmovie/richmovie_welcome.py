# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Welcome / Jednorázový pozdrav (fullscreen dialog)
───────────────────────────────────────────────────────────────────────────────
Cíl:
    • Zobrazit povinný "VÁNOČNÍ POZDRAV OD RICHIEHO" 1× (navždy),
      s minimální dobou zobrazení (default 30 s).
    • Po zobrazení uložit marker do profilu doplňku → už nikdy znovu,
      dokud uživatel nesmaže addon_data / nepřeinstaluje doplněk.
    • Volitelně přehrát MP3 (pokud existuje). Pokud chybí → ticho.

Poznámka:
    Tento modul je navržený pro výchozí skin Kodi (Estuary).
    XML okno je v: resources/skins/default/1080i/RichMovieWelcome.xml

Autor: Richie / úpravy: ChatGPT
═══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

# =========================
# STANDARDNÍ KNIHOVNY
# =========================
import json
import os
import textwrap
import threading
import time
from pathlib import Path
from typing import Optional, Tuple

# =========================
# KODI API
# =========================
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


# =========================
# DEFAULTY (fallback, když chybí JSON v resources)
# =========================
_DEFAULT_TITLE = "VZKAZ OD RICHIEHO"

_DEFAULT_MESSAGE = (
    "Zdravím všechny své blízké – uživatele RichMovie.\n\n"
    "RichMovie je můj volnočasový projekt – jeden člověk, volný čas, nulový rozpočet. "
    "Pracuji na tom od dubna 2025 a mám v tom přes 350 hodin času. Nemůže mít stejné zázemí "
    "jako Netflix nebo Disney+, kde na tom denně pracují velké týmy. Berte to prosím jako "
    "komunitní projekt pro rodinu a přátele.\n\n"
    "── CO JE RICHMOVIE ──\n\n"
    "RichMovie nehostuje žádný obsah. Je to pokročilý vyhledávač, který hledá soubory na "
    "Webshare.cz a Fastshare.cz podle toho, co tam někdo z internetu nasdílel. To, že vidíte "
    "film s plakátem a popisem, neznamená, že se na hostingu vždy najde funkční soubor. Někdy "
    "probíhají čistky – soubor může být vidět, ale nejde přehrát, protože je na straně hostingu "
    "blokovaný.\n\n"
    "── FASTSHARE – DRUHÝ ZDROJ ──\n\n"
    "RichMovie prohledává dva zdroje najednou: Webshare i Fastshare. Víc zdrojů = víc šancí "
    "najít to, co hledáte. Fastshare soubory poznáte podle značky [FS] u názvu.\n\n"
    "── KOLEKCE A SÁGY ──\n\n"
    "V hlavním menu najdete Kolekce – ručně sestavené seznamy filmů podle témat (horory, "
    "romantika, české filmy, animované, historické a další). Součástí je 56 filmových ság "
    "s doporučeným pořadím sledování – od Star Wars a MCU přes Harryho Pottera až po "
    "Paranormal Activity.\n\n"
    "O Vánocích a Velikonocích se v menu automaticky objeví sezónní kolekce a mění se i ikona "
    "doplňku.\n\n"
    "── DALŠÍ FUNKCE ──\n\n"
    "• ČSFD TV tipy – co dnes dávají v televizi\n"
    "• Doporučení od RichMovie A.I. – umělá inteligence navrhne, co sledovat\n"
    "• Next-Up – po dokoukání epizody seriálu se automaticky spustí další díl\n"
    "• Stahování – můžete si film stáhnout pro offline sledování\n"
    "• Historie sledování – RichMovie si pamatuje, co jste viděli\n\n"
    "── KDYŽ NĚCO NEFUNGUJE ──\n\n"
    "Když nemůžete najít film, zkuste v hlavním menu 'Reset cache vyhledávání'. "
    "Když narazíte na chybu, vyfoťte to a pošlete mi na WhatsApp – moc mi to pomáhá.\n\n"
    "Děkuji, že RichMovie používáte. Je to pro mě motivace pokračovat.\n"
    "Richie"
)

_DEFAULT_MIN_SECONDS = 30

# JSON s konfigurací pozdravu (pokud existuje)
# Doporučená cesta v addonu:
#   resources/data/richmovie_welcome.json
_DEFAULT_RESOURCE_JSON = os.path.join("resources", "data", "richmovie_welcome.json")

# Marker v addon_data (pokud existuje, welcome se nikdy znovu neukáže)
_DEFAULT_MARKER_FILENAME = "welcome_seen_v2.json"
# 4.0.0: KAMPAŇ — JSON nese `campaign` (např. "4.0.0"); značka „viděno“ je per kampaň (`welcome_seen_<kampaň>.json`),
# takže nová zpráva po aktualizaci se ukáže jednou i tomu, kdo viděl starší, a staré stránky se už nikomu nevrací
# (JSON má vždy JEN aktuální kampaň). Bez `campaign` platí původní značka v2.


def marker_filename(campaign: str) -> str:
    c = "".join(ch for ch in str(campaign or "").strip() if ch.isalnum() or ch in "._-")
    return ("welcome_seen_%s.json" % c) if c else _DEFAULT_MARKER_FILENAME

# Volitelná MP3 (pokud existuje, přehraje se spolu s oknem)
# Pokud nebude existovat → ticho.
_DEFAULT_AUDIO_REL = os.path.join("resources", "media", "richmovie_welcome.mp3")

# XML okno
_DEFAULT_XML = "RichMovieWelcome.xml"
_DEFAULT_SKIN = "default"
_DEFAULT_RES = "1080i"


# ============================================================================ #
#  INTERNÍ – načtení JSON konfigurace z resources
# ============================================================================ #
# 2025-12-23 16:43 CET (Europe/Prague)
def _load_welcome_payload(addon_path: str):
    """
    Nacte konfiguraci pozdravu z resources JSON (pokud existuje).

    Podporuje dva formaty:
      A) pages (nove):  {"pages": [{"title": "...", "message": "..."}, ...], "min_seconds": 30}
      B) single (legacy): {"title": "...", "message": "...", "min_seconds": 30}

    Vraci: (pages_list, min_seconds, audio_rel, campaign)
      pages_list = [{"title": str, "message": str}, ...]; campaign = "" (značka v2) | "<kampaň>"
    """
    try:
        cfg_path = os.path.join(addon_path, _DEFAULT_RESOURCE_JSON)
        cfg_path = xbmcvfs.translatePath(cfg_path)
        if not xbmcvfs.exists(cfg_path):
            return [{"title": _DEFAULT_TITLE, "message": _DEFAULT_MESSAGE}], int(_DEFAULT_MIN_SECONDS), _DEFAULT_AUDIO_REL, ""

        f = xbmcvfs.File(cfg_path, "r")
        try:
            raw = f.read()
        finally:
            f.close()

        data = json.loads(raw) if raw else {}

        try:
            min_s = int(data.get("min_seconds") or _DEFAULT_MIN_SECONDS)
        except Exception:
            min_s = int(_DEFAULT_MIN_SECONDS)

        audio = data.get("audio")
        if audio is None or str(audio).strip() == "":
            audio = _DEFAULT_AUDIO_REL
        campaign = str(data.get("campaign") or "").strip()

        # Format A: pages
        pages_raw = data.get("pages")
        if isinstance(pages_raw, list) and len(pages_raw) > 0:
            pages = []
            for p in pages_raw:
                pages.append({
                    "title": str(p.get("title") or _DEFAULT_TITLE),
                    "message": str(p.get("message") or ""),
                })
            return pages, max(0, min_s), str(audio) if audio else None, campaign

        # Format B: single message (legacy)
        title = str(data.get("title") or _DEFAULT_TITLE)
        msg = str(data.get("message") or _DEFAULT_MESSAGE)
        return [{"title": title, "message": msg}], max(0, min_s), str(audio) if audio else None, campaign

    except Exception as exc:
        xbmc.log("[RichMovie/Welcome] payload load failed: %r" % (exc,), xbmc.LOGWARNING)
        return [{"title": _DEFAULT_TITLE, "message": _DEFAULT_MESSAGE}], int(_DEFAULT_MIN_SECONDS), _DEFAULT_AUDIO_REL, ""


# ============================================================================ #
#  FULLSCREEN DIALOG (WindowXMLDialog)
# ============================================================================ #
class RichMovieWelcomeDialog(xbmcgui.WindowXMLDialog):
    """
    Fullscreen dialog se scroll textem a povinným odpočtem.

    Poznámka:
        Pokud uživatel stiskne BACK / ESC během odpočtu,
        akci ignorujeme (dialog se nezavře).
    """

    # ID kontrol v XML (musí sedět s resources/skins/default/1080i/RichMovieWelcome.xml)
    CTRL_TITLE = 101
    CTRL_TEXT  = 102
    CTRL_OK    = 201

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self._pages: list = []
        self._current_page: int = 0
        self._min_seconds: int = int(_DEFAULT_MIN_SECONDS)
        self._audio_path: Optional[str] = None

        self._allow_close: bool = False
        self._acknowledged: bool = False
        self._stop_event = threading.Event()

        self._timer_thread: Optional[threading.Thread] = None

        self._audio_started: bool = False
        self._audio_player_mode: str = ""

        self._back_action_ids = {9, 10, 92, 216, 247}
        try:
            self._back_action_ids.update({
                int(getattr(xbmcgui, "ACTION_PREVIOUS_MENU")),
                int(getattr(xbmcgui, "ACTION_NAV_BACK")),
            })
        except Exception:
            pass

    def set_payload(self, *, pages: list, min_seconds: int, audio_path: Optional[str]) -> None:
        """Nastavi data do dialogu pred volanim doModal()."""
        self._pages = pages if pages else [{"title": _DEFAULT_TITLE, "message": _DEFAULT_MESSAGE}]
        self._current_page = 0
        try:
            self._min_seconds = max(0, int(min_seconds))
        except Exception:
            self._min_seconds = int(_DEFAULT_MIN_SECONDS)
        self._audio_path = audio_path if (audio_path and str(audio_path).strip()) else None




    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_welcome.py › class RichMovieWelcomeDialog › onInit
    # (upraveno: 2025-12-23 17:17 CET (Europe/Prague) – FIX: list render + zalomení textu do řádků pro ovladač/šipky)
    # ---------------------------------------------------------------------------- #
    def _render_page(self) -> None:
        """Vykresli aktualni stranku do list controlu a nastav titulek + tlacitko."""
        page = self._pages[self._current_page]
        is_last = self._current_page >= len(self._pages) - 1

        # Titulek
        try:
            page_num = f" ({self._current_page + 1}/{len(self._pages)})" if len(self._pages) > 1 else ""
            self.getControl(self.CTRL_TITLE).setLabel(page.get("title", "") + page_num)
        except Exception:
            pass

        # Naplnit LIST radky
        try:
            lst = self.getControl(self.CTRL_TEXT)
            try:
                lst.reset()
            except Exception:
                pass

            msg = (page.get("message") or "").strip()
            wrap_width = 96
            lines: list[str] = []
            for para in msg.split("\n\n"):
                p = para.strip()
                if not p:
                    continue
                wrapped = textwrap.wrap(p, width=wrap_width, break_long_words=False, break_on_hyphens=False)
                if not wrapped:
                    wrapped = [""]
                lines.extend(wrapped)
                lines.append("")
            if lines and lines[-1] == "":
                lines.pop()

            for line in lines:
                try:
                    lst.addItem(xbmcgui.ListItem(label=line))
                except Exception:
                    pass
        except Exception:
            pass

        # Tlacitko — countdown worker ridi enabled/label
        try:
            btn = self.getControl(self.CTRL_OK)
            btn.setEnabled(False)
            if is_last:
                btn.setLabel("Rozumim (...)")
            else:
                btn.setLabel("Dalsi (...)")
        except Exception:
            pass

        # Instrukce
        try:
            hint = self.getControl(104)
            if is_last:
                hint.setLabel("Na tlacitko prejdete sipkou Vpravo. Odemkne se po odpoctu.")
            else:
                hint.setLabel("Na dalsi stranku prejdete sipkou Vpravo a stisknete OK.")
        except Exception:
            pass

        # Fokus na LIST
        try:
            self.setFocusId(self.CTRL_TEXT)
        except Exception:
            pass

    def onInit(self) -> None:
        """Kodi callback - okno je nactene, kontrolky existuji."""
        self._current_page = 0
        self._render_page()
        self._start_audio_best_effort()

        self._timer_thread = threading.Thread(
            target=self._countdown_worker,
            name="RichMovieWelcomeCountdown",
            daemon=True
        )
        self._timer_thread.start()




    # 2025-12-23 16:43 CET (Europe/Prague)
    def onClick(self, controlId: int) -> None:
        """Kodi callback - klik na control."""
        if controlId != self.CTRL_OK:
            return

        is_last = self._current_page >= len(self._pages) - 1

        if not is_last:
            self._current_page += 1
            self._render_page()
            return

        if not self._allow_close:
            return

        self._acknowledged = True
        self._stop_event.set()
        self._stop_audio_best_effort()
        self.close()

    # 2025-12-23 16:43 CET (Europe/Prague)
    def onAction(self, action: xbmcgui.Action) -> None:
        """
        Kodi callback – klávesy/ovladač.
        Během odpočtu blokujeme BACK/ESC.
        """
        try:
            aid = int(action.getId())
        except Exception:
            aid = -1

        if aid in self._back_action_ids:
            if self._allow_close:
                self._acknowledged = True
                self._stop_event.set()
                self._stop_audio_best_effort()
                self.close()
            # jinak ignorovat
            return

        # ostatní akce ponecháme defaultnímu chování (scroll atd.)
        try:
            super().onAction(action)
        except Exception:
            pass

    # 2025-12-23 16:43 CET (Europe/Prague)
    def was_acknowledged(self) -> bool:
        """
        Vrací True pokud uživatel potvrdil po vypršení odpočtu.
        """
        return bool(self._acknowledged)



    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_welcome.py › class RichMovieWelcomeDialog › _countdown_worker
    # (upraveno: 2025-12-23 17:12 CET (Europe/Prague) – FIX: OK odemknout, ale nebrat fokus textového listu)
    # ---------------------------------------------------------------------------- #
    def _countdown_worker(self) -> None:
        """Odpocet - bezi na kazde strance zvlast (min_seconds / pocet_stranek)."""
        total_pages = max(1, len(self._pages))
        per_page = max(5, self._min_seconds // total_pages)
        last_page_seen = -1

        while not self._stop_event.is_set():
            cur = self._current_page
            is_last = cur >= total_pages - 1

            # Nova stranka — reset odpoctu
            if cur != last_page_seen:
                last_page_seen = cur
                self._allow_close = False
                end_ts = time.time() + float(per_page)
                try:
                    btn = self.getControl(self.CTRL_OK)
                    btn.setEnabled(False)
                except Exception:
                    pass

            remaining = int(round(end_ts - time.time()))
            if remaining <= 0:
                # Odpocet dobehl — odemkni tlacitko
                self._allow_close = True
                try:
                    btn = self.getControl(self.CTRL_OK)
                    btn.setEnabled(True)
                    if is_last:
                        btn.setLabel("Rozumim")
                    else:
                        btn.setLabel("Dalsi  >>>")
                except Exception:
                    pass
                # Cekej na zmenu stranky nebo zavreni
                while not self._stop_event.is_set() and self._current_page == cur:
                    xbmc.sleep(250)
                continue

            # Zobraz odpocet na tlacitku
            try:
                btn = self.getControl(self.CTRL_OK)
                if is_last:
                    btn.setLabel(f"Rozumim (za: {remaining} s)")
                else:
                    btn.setLabel(f"Dalsi (za: {remaining} s)")
            except Exception:
                pass
            xbmc.sleep(250)










    # 2025-12-23 16:43 CET (Europe/Prague)
    def _start_audio_best_effort(self) -> None:
        """
        Spustí audio pouze pokud:
            • remember: audio_path existuje
            • soubor existuje
            • NIC už nehraje (abychom nerušili přehrávání uživatele)
        """
        try:
            if not self._audio_path:
                return
            if not xbmcvfs.exists(self._audio_path):
                return

            # Nerušit přehrávání uživatele
            try:
                if xbmc.Player().isPlaying():
                    return
            except Exception:
                pass

            # Pusť audio přes Player, ať se dá stopnout při zavření okna
            try:
                xbmc.Player().play(self._audio_path)
                self._audio_started = True
                self._audio_player_mode = "player"
            except Exception:
                self._audio_started = False
                self._audio_player_mode = ""
        except Exception:
            pass

    # 2025-12-23 16:43 CET (Europe/Prague)
    def _stop_audio_best_effort(self) -> None:
        """
        Stopne audio jen pokud jsme ho sami spustili (player mode).
        """
        try:
            if not self._audio_started:
                return
            if self._audio_player_mode != "player":
                return
            try:
                xbmc.Player().stop()
            except Exception:
                pass
        finally:
            self._audio_started = False
            self._audio_player_mode = ""


# ============================================================================ #
#  VEŘEJNÉ API – zavolat z plugin.py (typicky v _root() po instalacích a loginu)
# ============================================================================ #
# 2025-12-23 16:43 CET (Europe/Prague)
def maybe_show_welcome(addon: xbmcaddon.Addon, profile_dir: Path) -> None:
    """
    Zobrazí pozdrav, pokud ještě nebyl nikdy zobrazen.

    Logika:
        • Pokud existuje marker v addon_data → návrat (nic se neděje).
        • Jinak načti payload z resources JSON (fallback na konstanty).
        • Otevři fullscreen dialog a vyžádej potvrzení po X sekundách.
        • Po potvrzení ulož marker.

    Fail‑safe:
        • Jakákoliv chyba v UI / IO nesmí shodit plugin.
    """
    try:
        # 1) marker
        try:
            prof = Path(profile_dir)
        except Exception:
            prof = Path(str(profile_dir))

        # 2) addon path
        try:
            addon_path = xbmcvfs.translatePath(addon.getAddonInfo("path"))
        except Exception:
            addon_path = addon.getAddonInfo("path")

        # 3) payload (kampaň určuje značku „viděno“)
        pages, min_s, audio_rel, campaign = _load_welcome_payload(addon_path)
        marker_path = prof / marker_filename(campaign)
        if xbmcvfs.exists(str(marker_path)):
            return

        # 4) audio absolutni cesta (volitelne)
        audio_abs: Optional[str] = None
        try:
            if audio_rel:
                if os.path.isabs(str(audio_rel)):
                    audio_abs = xbmcvfs.translatePath(str(audio_rel))
                else:
                    audio_abs = xbmcvfs.translatePath(os.path.join(addon_path, str(audio_rel)))
                if not xbmcvfs.exists(audio_abs):
                    audio_abs = None
        except Exception:
            audio_abs = None

        # 5) dialog
        dlg = RichMovieWelcomeDialog(_DEFAULT_XML, addon_path, _DEFAULT_SKIN, _DEFAULT_RES)
        dlg.set_payload(pages=pages, min_seconds=min_s, audio_path=audio_abs)
        dlg.doModal()

        acknowledged = False
        try:
            acknowledged = bool(dlg.was_acknowledged())
        except Exception:
            acknowledged = False

        try:
            del dlg
        except Exception:
            pass

        # 6) ulož marker jen pokud uživatel potvrdil (po odpočtu)
        if not acknowledged:
            return

        # atomic write marker json
        payload = json.dumps({"shown": True, "campaign": campaign, "ts": int(time.time())}, ensure_ascii=False, indent=2)
        tmp = str(marker_path) + ".tmp"
        f = xbmcvfs.File(tmp, "w")
        try:
            f.write(bytearray(payload, "utf-8"))
        finally:
            f.close()
        try:
            if xbmcvfs.exists(str(marker_path)):
                xbmcvfs.delete(str(marker_path))
        except Exception:
            pass
        xbmcvfs.rename(tmp, str(marker_path))

    except Exception:
        # nikdy neshodit plugin
        return
