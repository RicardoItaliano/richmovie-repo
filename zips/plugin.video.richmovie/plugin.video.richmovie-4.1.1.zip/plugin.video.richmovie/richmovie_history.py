# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_history.py
# Historie vyhledávání a sledování – CRUD operace  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ⚠️ KODI PLUGIN: Proces-based architektura, lazy init pro session!
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Historie vyhledávání a sledování
───────────────────────────────────────────────────────────────────────────────
Tento modul obsahuje CRUD operace pro:

  • **Search History**  – Historie vyhledávacích dotazů (movie, tv, ws, other)
  • **Watch History**   – Historie sledovaných filmů a epizod

API:
    # Search History
    load_history() -> Dict[str, List[str]]
    save_history(hist) -> None
    add_to_history(term, category) -> None
    history_clear() -> None

    # Watch History
    watch_load() -> dict
    watch_save(data) -> None
    watch_add_movie(tmdb_id, title, year) -> None
    watch_add_episode(tv_id, tv_name, season, episode, ep_title) -> None
    watch_history_clear() -> None

UI funkce (_show_history, _watch_history_movies, _watch_history_tv) zůstávají
v plugin.py, protože jsou silně navázané na Kodi GUI (xbmcplugin, HANDLE).

Autor: Richie – extrahováno 24-01-2026
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

# — Standardní knihovna —
import inspect
import json
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# Routovaný logger (user_logs). Φ5A (29.09.2026): `cw_upsert` volal `_log`/`xbmc`, které modul
# nedefinoval — nečitelný soubor Pokračovat tak místo varování a `False` vyhodil `NameError`, a při
# sloučení z Gate (`strict=True`) ho volající vyhodnotil jako vadnou POLOŽKU → kurzor se posunul a
# položka se tiše ztratila (pravidlo R2b: chyba prostředí má kurzor zastavit).
try:
    from richmovie_logging import make_legacy_logger as _mk_hist_logger
    _log = _mk_hist_logger("richmovie.history", "RichMovie/History")
except Exception:  # pragma: no cover — fallback mimo pipeline
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log("[RichMovie/History] " + str(msg), level)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  MODUL-LEVEL PROMĚNNÉ – LAZY INIT
# ─────────────────────────────────────────────────────────────────────────────
_ADDON: xbmcaddon.Addon | None = None
_PROFILE_DIR: Path | None = None

# Callback pro modální dialog – nastaví se z plugin.py
_modal_callback: Callable[[str], None] | None = None


def _get_addon() -> xbmcaddon.Addon:
    """Lazy init pro ADDON instanci."""
    global _ADDON
    if _ADDON is None:
        _ADDON = xbmcaddon.Addon()
    return _ADDON


def _get_profile_dir() -> Path:
    """Adresář OSOBNÍCH dat aktuálního profilu (3.5.134, profily „Kdo se dívá?").

    SSOT = `richmovie_paths.personal_dir()`; záměrně BEZ cache — služba
    (`service_nextup`) žije dlouho a přepnutí profilu v pluginu se musí projevit
    při dalším volání. single/unset účty → kořen jako do 3.5.133."""
    import richmovie_paths
    return richmovie_paths.personal_dir()


def set_modal_callback(callback: Callable[[str], None]) -> None:
    """Nastaví callback pro modální dialog (voláno z plugin.py)."""
    global _modal_callback
    _modal_callback = callback


def _modal(msg: str) -> None:
    """Wrapper pro modální dialog – deleguje na callback nebo Kodi dialog."""
    if _modal_callback:
        try:
            _modal_callback(msg)
            return
        except Exception:
            pass
    # Fallback na přímé volání Kodi
    xbmcgui.Dialog().ok("RichMovie", msg)




# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
# Tyto se inicializují lazy při prvním použití
def _get_hist_path() -> Path:
    return _get_profile_dir() / "history.json"

def _get_watch_path() -> Path:
    return _get_profile_dir() / "watch_history.json"


def _locked_personal(name: str):
    """Dekorátor mutátorů osobního souboru (3.5.144): celé read-modify-write pod
    `richmovie_paths.personal_lock(name)` — služba nově do history/watch/my_list/ai_dismissed
    zapisuje při sloučení z Gate, plugin při akci uživatele (jiný proces). Zámek není
    reentrantní: dekorované funkce se navzájem nevolají (toggle volá add/remove postupně)."""
    import functools

    def _deco(fn):
        @functools.wraps(fn)
        def _inner(*args, **kwargs):
            import richmovie_paths as _rp
            with _rp.personal_lock(name):
                return fn(*args, **kwargs)
        return _inner
    return _deco

# Limity
WATCH_MAX_ITEMS = 200  # maximální počet položek v každé větvi (movies/episodes)
WATCH_UI_MAX_MOVIES = 20  # kolik filmů maximálně zobrazit v GUI
WATCH_UI_MAX_EPISODES = 20  # kolik epizod maximálně zobrazit v GUI




# ═══════════════════════════════════════════════════════════════════════════════
#  SEARCH HISTORY – CRUD
# ═══════════════════════════════════════════════════════════════════════════════


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# load_history  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def load_history() -> Dict[str, List[str]]:
    """
    Načte historii vyhledávání z JSON souboru a vždy vrací
    strukturu ``{"movie": [...], "tv": [...], "ws": [...], "other": [...]}``.

    • **Migrace** – pokud najde starý formát (list řetězců),
      považuje jej za filmové dotazy a automaticky převádí.
    • Případné chybné / poškozené soubory ignoruje → vrací čistou strukturu.
    """
    blank = {"movie": [], "tv": [], "ws": [], "other": [], "collections": []}
    hist_path = _get_hist_path()

    try:
        with open(hist_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return blank

    # – starý formát: prostý seznam řetězců
    if isinstance(data, list):
        return {"movie": data[:50], "tv": [], "ws": [], "other": [], "collections": []}

    # – nový formát – zajistíme, že nechybí žádný klíč
    if isinstance(data, dict):
        out = {k: list(v)[:50] for k, v in data.items() if isinstance(v, list)}
        for key in blank:
            out.setdefault(key, [])
        return out

    return blank


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# save_history  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def save_history(hist: Dict[str, List[str]]) -> None:
    """
    Uloží strukturu historie do JSON souboru.

    • Zapisuje atomicky – nejprve na temp soubor, potom `os.replace`
    • Nikdy nepropaguje výjimku, aby nepadal doplněk
    """
    hist_path = _get_hist_path()

    try:
        import richmovie_atomic as _atomic
        _atomic.write_json(str(hist_path), hist, indent=2)  # 3.5.123: tmp → fsync → replace
        _data_rev_bump("search")  # Φ5 invalidace (3.5.144: historie hledání se mění i sloučením z Gate)
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# add_to_history  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _history_entry_query(entry) -> str:
    """Extrahuje vyhledavaci dotaz z polozky historie (dict nebo string)."""
    if isinstance(entry, dict):
        return (entry.get("query") or "").strip()
    return (entry or "").strip()


@_locked_personal("history.json")
def add_to_history(term: str, category: str | None = None, *,
                   meta: dict | None = None) -> None:
    """
    Prida `term` do historie vyhledavani dane *kategorie*
    (`"movie"`, `"tv"`, `"ws"`, nebo `"other"`).

    • Pokud `category` neni predano, urci se heuristicky podle toho,
      ktera funkce (_movie_search / _tv_search / _ws_search) zaznam vlozila.
    • Duplikaty odsouvaji dolu (nejnovejsi hledani je vzdy na indexu 0).
    • Kazda kategorie drzi max 50 polozek.

    NOVE: parametr `meta` (dict) – pokud je predany, ulozi se obohaceny
    zaznam s TMDb metadaty:
      {"query": term, "tmdb_id": ..., "title": ..., "year": ...,
       "poster_path": ..., "rating": ..., "ts": ...}
    Pokud meta neni, ulozi se jako prosty string (zpetna kompatibilita).
    """
    # — 1) auto-detekce volajici funkce (fallback)
    if category is None:
        frame = inspect.currentframe()
        caller = frame.f_back.f_code.co_name if frame and frame.f_back else ""
        category = {
            "_movie_search": "movie",
            "_tv_search":    "tv",
            "_ws_search":    "ws",
        }.get(caller, "other")

    category = category.lower()
    if category not in {"movie", "tv", "ws", "other", "collections"}:
        category = "other"

    # — 2) sestavit zaznam
    if meta and isinstance(meta, dict):
        record = {
            "query": term,
            "tmdb_id": meta.get("tmdb_id"),
            "title": meta.get("title", term),
            "year": meta.get("year"),
            "poster_path": meta.get("poster_path", ""),
            "backdrop_path": meta.get("backdrop_path", ""),
            "overview": meta.get("overview", ""),
            "rating": meta.get("rating", 0),
            "ts": int(time.time()),
        }
    else:
        record = term

    # — 3) nacist, upravit, ulozit
    hist = load_history()

    # odstraneni duplicit (porovnavame query text)
    term_norm = term.strip().lower()
    existing = hist.get(category, [])
    deduped = [
        t for t in existing
        if _history_entry_query(t).lower() != term_norm
    ]

    # dopredne poradi (nejnovejsi prvni)
    items = [record] + deduped
    hist[category] = items[:50]

    save_history(hist)
    _items_note("note_search", category, record)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# history_clear  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
@_locked_personal("history.json")
def history_clear() -> None:
    """
    Vymaže obsah `history.json` a založí prázdnou strukturu:
      {"movie": [], "tv": [], "ws": [], "other": []}

    • Používá xbmcvfs kvůli kompatibilitě napříč platformami.
    • Nikdy nevyhazuje výjimku směrem do GUI (fail-safe).
    • Po úspěchu zobrazí krátké potvrzení.
    """
    try:
        profile_dir = _get_profile_dir()
        hist_path = _get_hist_path()
        before = load_history()   # tombstony pro Gate (smazání se šíří na ostatní zařízení)

        # zajisti existenci profilu (pro případ, že neexistuje)
        try:
            xbmcvfs.mkdirs(str(profile_dir))
        except Exception:
            pass

        empty = {"movie": [], "tv": [], "ws": [], "other": []}

        # zkus smazat starý soubor (ignore errors)
        try:
            if xbmcvfs.exists(str(hist_path)):
                xbmcvfs.delete(str(hist_path))
        except Exception:
            pass

        # ihned zapiš čistý JSON (atomicky přes tmp → rename)
        import richmovie_atomic as _atomic   # 3.5.140: SSOT trvanlivého zápisu (fsync, binární režim)
        _atomic.write_json(str(hist_path), empty, indent=2)
        _items_note("note_search_clear", before)

        _modal("Historie hledání byla vymazána.")
    except Exception:
        # potichu selhat – historie nikdy nesmí shodit doplněk
        pass




# ═══════════════════════════════════════════════════════════════════════════════
#  WATCH HISTORY – CRUD
# ═══════════════════════════════════════════════════════════════════════════════


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# watch_load  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def watch_load() -> dict:
    """
    Načte obsah `watch_history.json` z uživatelského profilu doplňku.

    Vždy vrací slovník se dvěma klíči:
      {
        "movies":   [ { "tmdb": int|None, "title": str, "year": int|None, "ts": int }, ... ],
        "episodes": [ { "tv_id": Any, "tv_name": str, "season": int, "episode": int,
                        "ep_title": str, "ts": int }, ... ]
      }

    Při chybě (soubor neexistuje / je poškozen) vrací prázdné struktury.
    """
    watch_path = _get_watch_path()

    try:
        # pokud soubor neexistuje, vrátíme default
        if not xbmcvfs.exists(str(watch_path)):
            return {"movies": [], "episodes": []}

        # xbmcvfs pro kompatibilitu napříč platformami
        with xbmcvfs.File(str(watch_path), "r") as fh:
            raw = fh.read()
        if not raw:
            return {"movies": [], "episodes": []}

        data = json.loads(raw)
        return {
            "movies":   list(data.get("movies", [])),
            "episodes": list(data.get("episodes", [])),
        }
    except Exception:
        # nikdy nesmí shodit GUI
        return {"movies": [], "episodes": []}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# watch_save  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def watch_save(data: dict) -> None:
    """
    Uloží celý obsah historie sledování do `watch_history.json` atomicky.
    Při chybě potichu selže (historie nikdy nesmí shodit doplněk).
    """
    try:
        profile_dir = _get_profile_dir()
        watch_path = _get_watch_path()

        # zajisti existenci profilu
        try:
            xbmcvfs.mkdirs(str(profile_dir))
        except Exception:
            pass

        import richmovie_atomic as _atomic   # 3.5.140: SSOT trvanlivého zápisu (fsync, binární režim)
        _atomic.write_json(str(watch_path), data, indent=2)
        _data_rev_bump("watch")  # Φ5 invalidace: rail Naposledy sledované (3.5.144, Fable P2-2)
    except Exception:
        # žádné výjimky navenek
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# watch_add_movie  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
@_locked_personal("watch_history.json")
def watch_add_movie(*, tmdb_id: Optional[int], title: str, year: Optional[int]) -> None:
    """
    Přidá nebo aktualizuje film v historii sledování (větev "movies").

    • Deduplikace:
        – primárně podle TMDb ID (pokud je k dispozici a je platné číslo),
        – jinak podle dvojice (title, year) s ořezanými mezerami.
    • Nový/aktualizovaný záznam se vkládá na začátek seznamu ("nejnovější nahoře").
    • Zachováváme maximálně `WATCH_MAX_ITEMS` položek.
    • Metoda je "best effort": při chybě potichu skončí (historie nesmí shodit doplněk).
    """
    try:
        # normalize vstupu
        t = (title or "").strip()
        y = int(year) if (year or 0) else None

        # TMDb ID bereme jen pokud je validní číslo
        tmdb = None
        if tmdb_id is not None:
            try:
                tmdb = int(tmdb_id)
            except Exception:
                tmdb = None

        rec = {
            "tmdb": tmdb,
            "title": t,
            "year": y,
            "ts": int(time.time()),
        }

        data = watch_load()
        items = list(data.get("movies", []))

        def _key(it: dict) -> tuple:
            return (
                it.get("tmdb") if (it.get("tmdb") is not None) else None,
                (it.get("title") or "").strip(),
                it.get("year") if (it.get("year") or 0) else None,
            )

        # odstranit případnou starou instanci stejného filmu
        items = [it for it in items if _key(it) != _key(rec)]

        # vložit na začátek
        items.insert(0, rec)

        # ořez na maximální velikost
        if WATCH_MAX_ITEMS > 0:
            items = items[:WATCH_MAX_ITEMS]

        data["movies"] = items
        watch_save(data)
        _items_note("note_watch", "movies", rec)
    except Exception:
        # nepropagovat výjimky – historie je pomocná funkce
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# watch_add_episode  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
@_locked_personal("watch_history.json")
def watch_add_episode(*, tv_id: Any, tv_name: str, season: int, episode: int, ep_title: str) -> None:
    """
    Přidá nebo aktualizuje epizodu seriálu v historii (větev "episodes").

    • Deduplikace podle klíče (tv_id, season, episode).
      – tv_id převádíme na string při porovnání, protože může být int/str.
    • Nový/aktualizovaný záznam se vkládá na začátek ("nejnovější nahoře").
    • Zachováváme maximálně `WATCH_MAX_ITEMS` položek.
    • Metoda je "best effort": při chybě potichu skončí.
    """
    try:
        tvn = (tv_name or "").strip()
        s   = int(season) if season is not None else 0
        e   = int(episode) if episode is not None else 0
        ept = (ep_title or "").strip()

        rec = {
            "tv_id": tv_id,          # ukládáme jak je; pro klíč převádíme na str
            "tv_name": tvn,
            "season": s,
            "episode": e,
            "ep_title": ept,
            "ts": int(time.time()),
        }

        data = watch_load()
        items = list(data.get("episodes", []))

        def _key(it: dict) -> tuple:
            return (str(it.get("tv_id")), int(it.get("season") or 0), int(it.get("episode") or 0))

        # odstranit případnou starou instanci stejné epizody
        items = [it for it in items if _key(it) != (str(tv_id), s, e)]

        # vložit na začátek
        items.insert(0, rec)

        # ořez na maximální velikost
        if WATCH_MAX_ITEMS > 0:
            items = items[:WATCH_MAX_ITEMS]

        data["episodes"] = items
        watch_save(data)
        _items_note("note_watch", "episodes", rec)
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════════
#  WATCHED EPISODES – CRUD (dokoukané epizody, completion-based SSOT)
# ═══════════════════════════════════════════════════════════════════════════════
# Oddělený store od watch_history.json. DŮVOD (enterprise, ne hotfix):
#   • watch_history.json se zapisuje při STARTU přehrávání (= „spustil jsem epizodu")
#     — viz plugin._play(). NELZE z něj odvodit „dokoukáno do konce".
#   • Tento store drží JEN epizody dokoukané (completion >= prahu / natural end),
#     zapisované z bodu dokončení (player_hook._finalize + service_nextup).
#   • Single-writer sémantika (watched_mark_episode) + jeden tvar záznamu →
#     vyhýbá se cache-shape-ambiguity (feedback_cache_partial_shape_ambiguity).
# Slouží pro „fajfku" u názvů epizod v seznamu (plugin._tv_episodes).

WATCHED_MAX_ITEMS = 5000           # strop (~250 seriálů × 20 epizod), FIFO ořez


def _get_watched_path() -> Path:
    return _get_profile_dir() / "watched_episodes.json"


def watched_load() -> dict:
    """Načte `watched_episodes.json`. Vždy vrací {"episodes": [...]}.
    Při chybě/neexistenci vrací prázdnou strukturu (nikdy neshodí GUI)."""
    watched_path = _get_watched_path()
    try:
        if not xbmcvfs.exists(str(watched_path)):
            return {"episodes": []}
        with xbmcvfs.File(str(watched_path), "r") as fh:
            raw = fh.read()
        if not raw:
            return {"episodes": []}
        data = json.loads(raw)
        return {"episodes": list(data.get("episodes", []))}
    except Exception:
        return {"episodes": []}


def watched_save(data: dict) -> bool:
    """Atomický zápis `watched_episodes.json` (SSOT `richmovie_atomic`). True = na disku.
    3.5.151: vrací výsledek — sloučení z Gate podle něj nechá kurzor stát (R2)."""
    try:
        profile_dir = _get_profile_dir()
        watched_path = _get_watched_path()
        try:
            xbmcvfs.mkdirs(str(profile_dir))
        except Exception:
            pass
        import richmovie_atomic as _atomic   # 3.5.140: SSOT trvanlivého zápisu (fsync, binární režim)
        ok = bool(_atomic.write_json(str(watched_path), data, indent=2))
        if ok:
            _data_rev_bump("watched")  # Φ5 invalidation kontrakt
        return ok
    except Exception:
        return False


def _load_for_update(path: Path, name: str) -> Optional[dict]:
    """Čtení PŘED zápisem (read-modify-write) — přísnější než UI loadery.

    UI loadery (`watched_load`, `watched_movie_ids`) vrací při JAKÉKOLI chybě prázdno; pro
    zobrazení je to správně, pro zápis ne: I/O chyba čtení (soubor držený jiným procesem,
    antivir) by prázdnou strukturu uložila a smazala všechny ✔ (3.5.151, plán Φ3).
      OK       → data
      NO_FILE  → {} (čerstvý profil)
      EMPTY / CORRUPT → {} (`read_json` soubor přesunul do karantény — důkaz zůstává)
      UNREADABLE → None = zápis se NEPROVEDE."""
    import richmovie_atomic as _atomic
    data, state = _atomic.read_json(str(path), None, name=name, expected_type=dict)
    if state == _atomic.STATE_UNREADABLE:
        return None
    return data if isinstance(data, dict) else {}


def _watched_episode_key(it: dict) -> tuple:
    return (str(it.get("tv_id")), int(it.get("season") or 0), int(it.get("episode") or 0))


def _watched_merge_mark(items: list, rec: dict) -> tuple:
    """Vloží/aktualizuje záznam dílu (čisté). Vrací (nový seznam, ULOŽENÝ záznam).
    `unattended` nesmí sebrat ✔ dílu, který uživatel kdysi viděl nebo ručně odškrtl
    (cross-check Flash D / Pro A P2, 3.5.149)."""
    key = _watched_episode_key(rec)
    prev = next((it for it in items if _watched_episode_key(it) == key), None)
    rec = dict(rec)
    # mig 0038: druh ze SLOUČENÉ pravdy Gate (monotónní spojení + verdikt spánku) a lokální verdikt spánku
    # se přebírají tak, jak jsou; každý jiný zápis ✔ dál nesmí díl zhoršit (⏾ nesebere ✔).
    authoritative = bool(rec.pop("authoritative", False))
    if not authoritative and rec.get("kind") == "unattended" and prev is not None \
            and (prev.get("kind") or "attended") in ("attended", "manual"):
        rec["kind"] = prev.get("kind") or "attended"
    # 3.5.156 (cross-check Pro B 2): starší záznam (✔ z Gate s časem klienta) nesmí přepsat
    # NOVĚJŠÍ čas a zařízení lokálního ✔ — druh se přebírá (změna unattended→manual je legitimní),
    # „kdy/odkud" zůstává novější.
    if prev is not None and int(prev.get("watched_at") or 0) > int(rec.get("watched_at") or 0):
        rec["watched_at"] = int(prev.get("watched_at") or 0)
        if prev.get("device"):
            rec["device"] = prev.get("device")
    out = [it for it in items if _watched_episode_key(it) != key]
    out.insert(0, rec)
    if WATCHED_MAX_ITEMS > 0:
        out = out[:WATCHED_MAX_ITEMS]
    return out, rec


WATCHED_LOCK_WAIT_S = 8.0   # dávka ✔ s fsync na pomalém TV boxu (< LOCK_STALE_S 10 s; cross-check Pro B PB2a)


def watched_episodes_apply(marks: List[dict], unmarks: List[tuple]) -> bool:
    """Dávková změna `watched_episodes.json` — JEDEN read-modify-write pod meziprocesovým
    zámkem (3.5.151, plán Φ3). `marks` = záznamy {tv_id, season, episode, completion,
    watched_at, kind}, `unmarks` = (tv_id, season, episode). True = zapsáno (nebo nic k zápisu).

    PROČ: do 3.5.150 dělal každý ✔ vlastní RMW bez zámku. Sloučení 267 změn z Gate na
    čerstvém zařízení tak běželo ve třech procesech naráz (služba + 2× hlavní menu):
    ztracené zápisy, 30× WRITE_FAILED a 40 s práce (notebook 16.09.2026)."""
    if not marks and not unmarks:
        return True
    stored = []
    note_times = {}   # klíč dílu → čas ✔ pro Gate, když volající dal vlastní (`watched_mark_episode(watched_at=…)`)
    try:
        import richmovie_paths as _rp
        with _rp.personal_lock("watched_episodes.json", wait_s=WATCHED_LOCK_WAIT_S):
            data = _load_for_update(_get_watched_path(), "watched_episodes")
            if data is None:
                return False
            items = list(data.get("episodes") or [])
            for rec in marks or []:
                note_at = rec.pop("note_at", None) if isinstance(rec, dict) else None
                items, saved = _watched_merge_mark(items, rec)
                if note_at and int(saved.get("watched_at") or 0) == int(note_at):
                    note_times[_watched_episode_key(saved)] = float(note_at)
                stored.append(saved)
            for tv_id, season, episode in unmarks or []:
                key = (str(tv_id), int(season or 0), int(episode or 0))
                items = [it for it in items if _watched_episode_key(it) != key]
            data["episodes"] = items
            if not watched_save(data):
                return False
    except Exception:
        return False
    try:
        # Notifikace nese ULOŽENÝ druh (cross-check Pro B PB3a): lokálně zachované `attended` by jinak
        # na Gate odešlo jako `unattended` a LWW by ✔ sebralo všem ostatním zařízením profilu.
        for rec in stored:
            _sync_note("watched_episode", tv_id=rec.get("tv_id"), season=rec.get("season"),
                       episode=rec.get("episode"), completion=rec.get("completion"),
                       kind=rec.get("kind") or "attended", at=note_times.get(_watched_episode_key(rec)))
        for tv_id, season, episode in unmarks or []:
            _sync_note("unwatched_episode", tv_id=tv_id, season=int(season or 0), episode=int(episode or 0))
    except Exception:
        pass   # zápis na disku už je; fronta pro Gate je best-effort (plná rekonciliace dorovná)
    return True


def watched_sleep_verdict(tv_id: Any, episodes: List[tuple]) -> int:
    """Verdikt spánku (mig 0038, plán §3.3): dotaz „Díváš se ještě?“ vypršel → díly řetězu od posledního vstupu
    (`episodes` = [(season, episode)]), které jsou lokálně ✔ `attended`, se sníží na `unattended` („⏾ usnul jsi?“)
    a do fronty jde verdikt (Gate ho přijme jen jako compare-and-set téhož zařízení). Ručně potvrzené (`manual`)
    se nemění. Vrací počet změněných dílů. JEDINÁ cesta, kterou smí ✔ ztratit druh mimo sloučení z Gate."""
    wanted = {(int(s_), int(e_)) for s_, e_ in (episodes or []) if int(s_ or 0) > 0 and int(e_ or 0) > 0}
    if not tv_id or not wanted:
        return 0
    changed: List[tuple] = []
    try:
        import richmovie_paths as _rp
        with _rp.personal_lock("watched_episodes.json", wait_s=WATCHED_LOCK_WAIT_S):
            data = _load_for_update(_get_watched_path(), "watched_episodes")
            if data is None:
                return 0
            items = list(data.get("episodes") or [])
            for it in items:
                key = (int(it.get("season") or 0), int(it.get("episode") or 0))
                if str(it.get("tv_id")) == str(tv_id) and key in wanted \
                        and (it.get("kind") or "attended") == "attended":
                    it["kind"] = "unattended"
                    changed.append(key)
            if not changed:
                return 0
            data["episodes"] = items
            if not watched_save(data):
                return 0
    except Exception:
        return 0
    for s_, e_ in changed:
        _sync_note("sleep_verdict", tv_id=tv_id, season=s_, episode=e_)
    return len(changed)


def watched_mark_episode(*, tv_id: Any, season: int, episode: int,
                         completion: Optional[float] = None, kind: str = "attended",
                         watched_at: Optional[float] = None) -> None:
    """Označí epizodu jako DOKOUKANOU (idempotentně).

    `kind` (3.5.149, SSOT `richmovie_attention`; význam od 4.0.3 / mig 0038): `attended` = dokoukáno
    (i tichý divák u autoplaye — D1 10.10.2026), `unattended` = PROKÁZANÝ spánek (dotaz „Díváš se ještě?“
    vypršel; zapisuje ho jen `watched_sleep_verdict`, v UI „⏾ usnul jsi?“), `manual` = ruční „Viděl jsem to".

    Volá se z bodu dokončení přehrávání:
      • player_hook._finalize  (natural end nebo completion >= 0.95)
      • service_nextup._save_cw_position  (pct > 0.93)
    Dedup podle (tv_id, season, episode); opakované dokoukání jen aktualizuje
    záznam (přesune na začátek + obnoví completion/watched_at). Best-effort —
    nikdy nepropaguje výjimku (nesmí shodit playback).
    `watched_at` (4.0.3, cross-check C1): čas dokoukání, když není „teď“ (úklid po startu = čas posledního
    checkpointu) — jde i na Gate, takže pozdější výslovné odznačení ✔ nevrátí."""
    try:
        s = int(season) if season is not None else 0
        e = int(episode) if episode is not None else 0
        if not tv_id or s <= 0 or e <= 0:
            return
        try:
            comp = round(float(completion), 3) if completion is not None else None
        except Exception:
            comp = None

        try:
            import richmovie_attention as _att
            kind = _att.normalize_kind(kind)
        except Exception:
            kind = kind if kind in ("attended", "unattended", "manual") else "attended"

        rec = {
            "tv_id": tv_id,
            "season": s,
            "episode": e,
            "completion": comp,
            "watched_at": int(watched_at) if watched_at else int(time.time()),
            "kind": kind,
            # 3.5.156: odkud ✔ přišel — v seznamu epizod „✔ · včera · TV obývák" (Richie 20.09.2026)
            "device": own_device_label(),
        }
        # 3.5.151: RMW pod zámkem + přísné čtení (SSOT `watched_episodes_apply`); přednost druhu
        # ✔ (díl kdysi viděný nesmí ztratit ✔ nočním autoplayem) řeší `_watched_merge_mark`.
        if watched_at:
            rec["note_at"] = float(watched_at)   # přechodné pole: čas pro Gate (nezapisuje se)
        watched_episodes_apply([rec], [])
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
#  WATCHED FILMY — „dokoukáno" stav pro filmy (RM 4.0 P0-1, 2026-06-14)
#  watched_movies.json: {"ids": ["123", "456", …]} (TMDb id filmů).
#  Protějšek watched_episodes pro filmy → zelený ✔ konzistentně i u filmů.
#  Auto-mark při dokoukání (service_nextup) + ruční toggle z context menu.
# ═══════════════════════════════════════════════════════════════════════════

WATCHED_MOVIES_MAX = 5000


def _get_watched_movies_path() -> Path:
    return _get_profile_dir() / "watched_movies.json"


def watched_movie_ids() -> set:
    try:
        p = _get_watched_movies_path()
        if not xbmcvfs.exists(str(p)):
            return set()
        with xbmcvfs.File(str(p), "r") as fh:
            raw = fh.read()
        return set(str(x) for x in json.loads(raw).get("ids", [])) if raw else set()
    except Exception:
        return set()


def _watched_movies_save(ids) -> bool:
    try:
        p = _get_watched_movies_path()
        try:
            xbmcvfs.mkdirs(str(_get_profile_dir()))
        except Exception:
            pass
        import richmovie_atomic as _atomic   # 3.5.140: SSOT trvanlivého zápisu (fsync, binární režim)
        ok = bool(_atomic.write_json(str(p), {"ids": list(ids)[:WATCHED_MOVIES_MAX]}, indent=None))
        if ok:
            _data_rev_bump("watched")  # Φ5 invalidation kontrakt (R3-P2-3: chyběl)
        return ok
    except Exception:
        return False


def watched_movies_apply(add: List[Any], remove: List[Any], note_at: Optional[float] = None) -> bool:
    """Dávková změna `watched_movies.json` — jeden RMW pod meziprocesovým zámkem, přísné
    čtení (protějšek `watched_episodes_apply`, 3.5.151). Notifikace pro Gate jen za
    skutečné změny (parita s dřívějšími `watched_movie_mark/unmark`). True = OK."""
    add_keys = [str(x) for x in (add or []) if x]
    remove_keys = [str(x) for x in (remove or []) if x]
    if not add_keys and not remove_keys:
        return True
    try:
        import richmovie_paths as _rp
        with _rp.personal_lock("watched_movies.json", wait_s=WATCHED_LOCK_WAIT_S):
            data = _load_for_update(_get_watched_movies_path(), "watched_movies")
            if data is None:
                return False
            ids = [str(x) for x in (data.get("ids") or [])]
            present = set(ids)
            added = [k for k in dict.fromkeys(add_keys) if k not in present]
            removed = [k for k in dict.fromkeys(remove_keys) if k in present or k in added]
            if not added and not removed:
                return True
            removed_set = set(removed)
            # nové první: strop WATCHED_MOVIES_MAX ořezává konec seznamu, nejnovější ✔ nesmí vypadnout
            result = [k for k in added if k not in removed_set] + [k for k in ids if k not in removed_set]
            if not _watched_movies_save(result):
                return False
        for key in added:
            if key not in removed_set:
                # `note_at` = čas dokoukání pro Gate, když není „teď“ (úklid po startu — audit Fable A-V3)
                _sync_note("watched_movie", key, at=note_at)
        for key in removed:
            _sync_note("unwatched_movie", key)
        return True
    except Exception:
        return False


def watched_movie_contains(tmdb_id: Any) -> bool:
    return str(tmdb_id or "") in watched_movie_ids() if tmdb_id else False


def watched_movie_mark(tmdb_id: Any, watched_at: Optional[float] = None) -> bool:
    """Označí film jako dokoukaný (idempotentní). Auto z service_nextup + ruční.
    Vrací, zda se ✔ opravdu zapsal (UNREADABLE / chyba zápisu = False; Fable P2-1 19.09.2026).
    `watched_at` = čas dokoukání pro Gate, když není „teď“ (úklid po startu — pozdější odznačení ho přebije)."""
    try:
        if not tmdb_id:
            return False
        return bool(watched_movies_apply([tmdb_id], [], note_at=watched_at))
    except Exception:
        return False


def watched_movie_unmark(tmdb_id: Any) -> None:
    try:
        if not tmdb_id:
            return
        watched_movies_apply([], [tmdb_id])
    except Exception:
        pass


def watched_movie_toggle(tmdb_id: Any) -> bool:
    """Přepne watched stav filmu. Vrací True = teď je dokoukaný."""
    if watched_movie_contains(tmdb_id):
        watched_movie_unmark(tmdb_id)
        return False
    watched_movie_mark(tmdb_id)
    return True


# ═══════════════════════════════════════════════════════════════════════════
#  AI TIPY — „Už jsem viděl / nezajímá" (RM 4.0, 2026-06-14)
#  ai_dismissed.json: {"ids": ["movie:123", "tv:456", …]} — skryté AI tipy.
#  Filtruje se při čtení railu/gridu; RCAI to navíc dostane jako signál (TODO).
# ═══════════════════════════════════════════════════════════════════════════

def _get_ai_dismissed_path() -> Path:
    return _get_profile_dir() / "ai_dismissed.json"


def ai_dismissed_ids() -> set:
    try:
        p = _get_ai_dismissed_path()
        if not xbmcvfs.exists(str(p)):
            return set()
        with xbmcvfs.File(str(p), "r") as fh:
            raw = fh.read()
        return set(json.loads(raw).get("ids", [])) if raw else set()
    except Exception:
        return set()


@_locked_personal("ai_dismissed.json")
def ai_dismiss(tmdb_id: Any, kind: str = "movie") -> None:
    """Skryje AI tip (uživatel „už viděl / nezajímá"). Idempotentní, strop 2000."""
    try:
        if not tmdb_id:
            return
        key = "{}:{}".format((kind or "movie").lower(), tmdb_id)
        ids = list(ai_dismissed_ids())
        if key in ids:
            return
        ids.insert(0, key)
        ids = ids[:2000]
        _ai_dismissed_save(ids)
        _items_note("note_ai_dismiss", key)
    except Exception:
        pass


def _ai_dismissed_save(ids: list) -> None:
    """Jediný zapisovač `ai_dismissed.json` (lokální i vzdálené změny)."""
    try:
        p = _get_ai_dismissed_path()
        try:
            xbmcvfs.mkdirs(str(_get_profile_dir()))
        except Exception:
            pass
        import richmovie_atomic as _atomic   # 3.5.140: SSOT trvanlivého zápisu (fsync, binární režim)
        _atomic.write_json(str(p), {"ids": list(ids)[:2000]}, indent=None)
        _data_rev_bump("ai")  # Φ5 invalidation kontrakt
    except Exception:
        pass


def ai_is_dismissed(tmdb_id: Any, kind: str = "movie") -> bool:
    return "{}:{}".format((kind or "movie").lower(), tmdb_id) in ai_dismissed_ids()


# ═══════════════════════════════════════════════════════════════════════════
#  MŮJ SEZNAM (watchlist) — RM 4.0 Φ-U3 (návykovost, Netflix „My List")
#  my_list.json: {"items": [{tmdb_id, kind, title, year, poster_path, ts}, …]}
#  Append-newest, dedup (tmdb_id,kind), strop 500. Best-effort, neshodí GUI.
# ═══════════════════════════════════════════════════════════════════════════

MY_LIST_MAX_ITEMS = 500


def _get_my_list_path() -> Path:
    return _get_profile_dir() / "my_list.json"


def my_list_load() -> dict:
    p = _get_my_list_path()
    try:
        if not xbmcvfs.exists(str(p)):
            return {"items": []}
        with xbmcvfs.File(str(p), "r") as fh:
            raw = fh.read()
        if not raw:
            return {"items": []}
        return {"items": list(json.loads(raw).get("items", []))}
    except Exception:
        return {"items": []}


def _my_list_save(data: dict) -> None:
    try:
        profile_dir = _get_profile_dir()
        path = _get_my_list_path()
        try:
            xbmcvfs.mkdirs(str(profile_dir))
        except Exception:
            pass
        import richmovie_atomic as _atomic   # 3.5.140: SSOT trvanlivého zápisu (fsync, binární režim)
        _atomic.write_json(str(path), data, indent=2)
        _data_rev_bump("my_list")  # Φ5 invalidation kontrakt
    except Exception:
        pass


def _my_list_key(tmdb_id: Any, kind: str):
    return (str(tmdb_id or ""), (kind or "movie").lower())


def my_list_contains(tmdb_id: Any, kind: str = "movie") -> bool:
    key = _my_list_key(tmdb_id, kind)
    for it in my_list_load().get("items", []):
        if _my_list_key(it.get("tmdb_id"), it.get("kind")) == key:
            return True
    return False


@_locked_personal("my_list.json")
def my_list_add(*, tmdb_id: Any, kind: str = "movie", title: str = "",
                year: Any = "", poster_path: str = "") -> bool:
    """Přidá do Mého seznamu (idempotentně, newest-first). Vrací True = přidáno."""
    try:
        if not tmdb_id:
            return False
        data = my_list_load()
        key = _my_list_key(tmdb_id, kind)
        items = [it for it in data.get("items", [])
                 if _my_list_key(it.get("tmdb_id"), it.get("kind")) != key]
        items.insert(0, {"tmdb_id": str(tmdb_id), "kind": (kind or "movie").lower(),
                         "title": title or "", "year": year or "",
                         "poster_path": poster_path or "", "ts": int(time.time())})
        if MY_LIST_MAX_ITEMS > 0:
            items = items[:MY_LIST_MAX_ITEMS]
        data["items"] = items
        _my_list_save(data)
        _items_note("note_my_list", items[0])
        return True
    except Exception:
        return False


@_locked_personal("my_list.json")
def my_list_remove(*, tmdb_id: Any, kind: str = "movie") -> None:
    try:
        data = my_list_load()
        key = _my_list_key(tmdb_id, kind)
        data["items"] = [it for it in data.get("items", [])
                         if _my_list_key(it.get("tmdb_id"), it.get("kind")) != key]
        _my_list_save(data)
        _items_note("note_my_list_remove", tmdb_id, kind)
    except Exception:
        pass


def my_list_toggle(*, tmdb_id: Any, kind: str = "movie", title: str = "",
                   year: Any = "", poster_path: str = "") -> bool:
    """Přepne přítomnost v Mém seznamu. Vrací True = teď je v seznamu."""
    if my_list_contains(tmdb_id, kind):
        my_list_remove(tmdb_id=tmdb_id, kind=kind)
        return False
    my_list_add(tmdb_id=tmdb_id, kind=kind, title=title, year=year,
                poster_path=poster_path)
    return True


def watched_unmark_episode(*, tv_id: Any, season: int, episode: int) -> None:
    """Odebere ruční/auto ✔ marker epizody (idempotentně) — RM 4.0 Φ-C.

    Protějšek watched_mark_episode pro manuální toggle v custom Episodes okně.
    Best-effort — nikdy nepropaguje výjimku."""
    try:
        s = int(season) if season is not None else 0
        e = int(episode) if episode is not None else 0
        if not tv_id or s <= 0 or e <= 0:
            return
        # 3.5.151: RMW pod zámkem + přísné čtení (SSOT `watched_episodes_apply`)
        watched_episodes_apply([], [(tv_id, s, e)])
    except Exception:
        pass


def own_device_label() -> str:
    """Jméno TOHOTO zařízení pro záznam ✔ (SSOT `richmovie_state_sync.device_label`; lazy import —
    state_sync importuje history). Fail-safe ''."""
    try:
        from richmovie_state_sync import device_label as _dl
        return str(_dl() or "")
    except Exception:
        return ""


def _watched_info_of(it: dict) -> dict:
    """Čistá projekce záznamu ✔ → {kind, watched_at, device} (bez `kind` do 3.5.148 = attended)."""
    return {
        "kind": str(it.get("kind") or "attended"),
        "watched_at": int(it.get("watched_at") or 0),
        "device": str(it.get("device") or ""),
    }


def watched_info_index(episodes: Optional[list] = None) -> dict:
    """{(tv_id, season, episode): info} nad CELÝM `watched_episodes.json` jedním průchodem
    (newest-first → první výskyt vyhrává). `episodes` = už načtený seznam (volající s více seriály
    čte soubor jednou — cross-check Pro B 3, 27.09.2026)."""
    out: dict = {}
    try:
        for it in (episodes if episodes is not None else watched_load().get("episodes", [])):
            try:
                key = (str(it.get("tv_id")), int(it.get("season") or 0), int(it.get("episode") or 0))
            except Exception:
                continue
            if key in out:
                continue
            out[key] = _watched_info_of(it)
    except Exception:
        pass
    return out


def watched_info_for_series(tv_id: Any) -> dict:
    """{(season, episode): {"kind", "watched_at", "device"}} pro daný seriál (3.5.156, SSOT čtení
    `watched_episodes.json` per seriál; `watched_kinds_for_series` je projekce). O(n), jednou per
    render seznamu epizod. Fail-safe."""
    tid = str(tv_id)
    return {(s, e): info for (t, s, e), info in watched_info_index().items() if t == tid}


def watched_when_text(watched_at: int, now: Optional[float] = None) -> str:
    """Čistá: čas ✔ pro UI — „dnes" / „včera" / „před N dny" (≤ 6) / „12.09." / „12.09.2025" (jiný rok)."""
    try:
        ts = int(watched_at or 0)
    except (TypeError, ValueError):
        ts = 0
    if ts <= 0:
        return ""
    now_f = float(now if now is not None else time.time())
    import datetime as _dt
    d_then = _dt.datetime.fromtimestamp(ts).date()
    d_now = _dt.datetime.fromtimestamp(now_f).date()
    days = (d_now - d_then).days
    if days <= 0:
        return "dnes"
    if days == 1:
        return "včera"
    if days <= 6:
        return "před %d dny" % days
    if d_then.year == d_now.year:
        return d_then.strftime("%d.%m.")
    return d_then.strftime("%d.%m.%Y")


def watched_suffix(info: Optional[dict], now: Optional[float] = None) -> str:
    """Čistá: „ · včera · TV obývák" (kdy + odkud) za popiskem epizody; prázdné = nic."""
    if not info:
        return ""
    parts = []
    when = watched_when_text(info.get("watched_at") or 0, now)
    if when:
        parts.append(when)
    dev = str(info.get("device") or "").strip()
    if dev:
        parts.append(dev)
    return (" · " + " · ".join(parts)) if parts else ""


EP_COLOR_WATCHED = "FF00C853"   # zelené ✔ (beze změny od 3.4.10)
EP_COLOR_PROGRESS = "FF4FA3FF"  # modrý ◐ rozkoukaného dílu (4.0.3)
EP_COLOR_ASLEEP = "FF9E9E9E"    # šedý ⏾ prokázaného spánku


def episode_badge(w_info: Optional[dict], p_info: Optional[dict], now: Optional[float] = None) -> dict:
    """SSOT stavu dílu v seznamech (4.0.3, plán A5 — starý vzhled, nový vzhled, sezóny). Čisté (harness 90).
    `w_info` = `watched_info_for_series()[(s, e)]`, `p_info` = `progress_for_series()[(s, e)]`. Vrací
    {"state", "symbol", "color", "text", "watched", "position", "duration"}:
      watched  ✔  „ · včera · TV obývák"
      rewatch  ✔  „ · znovu rozkoukáno 12 z 45 min"              (viděno + znovu rozkoukáno)
      progress ◐  „ · rozkoukáno 23 z 45 min · Telefon · dnes"  (postup profilu — z kteréhokoli zařízení)
      asleep   ⏾  „ · běželo bez tebe · včera"                    (prokázaný spánek; klik / menu = „Viděl jsem to")
      ""          bez značky"""
    kind = str((w_info or {}).get("kind") or "") if w_info else ""
    watched = kind in ("attended", "manual")
    pos = float((p_info or {}).get("position") or 0) if p_info else 0.0
    dur = float((p_info or {}).get("duration") or 0) if p_info else 0.0
    out = {"state": "", "symbol": "", "color": "", "text": "", "watched": watched, "position": pos, "duration": dur}
    if pos > 0:
        mins = "%d z %d min" % (int(pos // 60), max(1, int(round(dur / 60.0)))) if dur > 0 else "%d min" % int(pos // 60)
        if watched:
            out.update({"state": "rewatch", "symbol": "✔", "color": EP_COLOR_WATCHED,
                        "text": " · znovu rozkoukáno %s" % mins})
            return out
        parts = ["rozkoukáno %s" % mins]
        dev = str((p_info or {}).get("device") or "").strip()
        if dev:
            parts.append(dev)
        when = watched_when_text(int((p_info or {}).get("ts") or 0), now)
        if when:
            parts.append(when)
        out.update({"state": "progress", "symbol": "◐", "color": EP_COLOR_PROGRESS, "text": " · " + " · ".join(parts)})
        return out
    if watched:
        out.update({"state": "watched", "symbol": "✔", "color": EP_COLOR_WATCHED, "text": watched_suffix(w_info, now)})
    elif kind == "unattended":
        when = watched_when_text(int((w_info or {}).get("watched_at") or 0), now)
        out.update({"state": "asleep", "symbol": "⏾", "color": EP_COLOR_ASLEEP,
                    "text": " · běželo bez tebe" + ((" · " + when) if when else "")})
    return out


def season_summary(season: int, episode_count: int, w_index: dict, p_index: dict) -> str:
    """„6/10 ✔ · rozkoukaný díl 7" pro řádek sezóny (4.0.3, A5). Čisté; prázdné = nic k ukázání.
    `w_index` / `p_index` = indexy seriálu klíčované (season, episode)."""
    if episode_count <= 0:
        return ""
    done = sum(1 for (s_, _e), info in (w_index or {}).items()
               if s_ == season and str((info or {}).get("kind") or "") in ("attended", "manual"))
    progress = sorted(e_ for (s_, e_), info in (p_index or {}).items()
                      if s_ == season and float((info or {}).get("position") or 0) > 0)
    parts = []
    if done:
        parts.append("✔ vše" if done >= episode_count else "%d/%d ✔" % (done, episode_count))
    if progress:
        e_last = progress[-1]
        seen = str(((w_index or {}).get((season, e_last)) or {}).get("kind") or "") in ("attended", "manual")
        parts.append(("díl %d znovu rozkoukaný" if seen else "rozkoukaný díl %d") % e_last)
    return " · ".join(parts)


def watched_kinds_for_series(tv_id: Any) -> dict:
    """{(season, episode): kind} — projekce `watched_info_for_series` (3.5.149 API zachováno)."""
    return {k: v["kind"] for k, v in watched_info_for_series(tv_id).items()}


def _watched_kinds_for_series_legacy(tv_id: Any) -> dict:
    out: dict = {}
    try:
        tid = str(tv_id)
        for it in watched_load().get("episodes", []):
            if str(it.get("tv_id")) != tid:
                continue
            try:
                key = (int(it.get("season") or 0), int(it.get("episode") or 0))
            except Exception:
                continue
            if key in out:
                continue      # seznam je řazený od nejnovějšího → první výskyt je platný stav
            kind = it.get("kind") or "attended"
            out[key] = kind if kind in ("attended", "unattended", "manual") else "attended"
    except Exception:
        pass
    return out


def watched_set_for_series(tv_id: Any) -> set:
    """Set dvojic (season, episode) epizod se zeleným ✔ — tedy jen `attended`/`manual`.
    Díly přehrané bez diváka (`unattended`, 3.5.149) se ✔ NEoznačují: uživatel u nich
    nebyl a musí je mít pořád „k vidění" (plán PLAN_binge_attention_20260914, A3)."""
    return {k for k, kind in watched_kinds_for_series(tv_id).items() if kind != "unattended"}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# get_recently_watched_series  (2026-05-30, TV UX Goal 1)
# ---------------------------------------------------------------------------- #
def get_recently_watched_series(limit: int = 8) -> list:
    """Naposledy sledované UNIKÁTNÍ seriály (dedup podle tv_id, newest-first).

    Zdroj = `watch_history.json` (epizody, start-based). Pro „seriály, které teď
    řešíš" je start-based recency správně (na rozdíl od completion-based markerů).
    watch_history je už řazena newest-first (insert na index 0), takže dedup podle
    tv_id ponechá nejnovější epizodu každého seriálu.

    Vrací list: [{tv_id, tv_name, last_season, last_episode, ts}, ...]."""
    out: list = []
    try:
        seen: set = set()
        _index = watched_info_index()   # jeden průchod pro všechny seriály (ne per seriál)
        for it in watch_load().get("episodes", []):
            tid = str(it.get("tv_id") or "")
            if not tid or tid in seen:
                continue
            seen.add(tid)
            _s, _e = int(it.get("season") or 0), int(it.get("episode") or 0)
            _w = _index.get((tid, _s, _e)) or {}
            out.append({
                "tv_id": it.get("tv_id"),
                "tv_name": (it.get("tv_name") or "").strip(),
                "last_season": _s,
                "last_episode": _e,
                "ts": int(it.get("ts") or 0),
                # 3.5.156: kdy/odkud byl díl DOKOUKÁN (✔); rozehraný díl bez ✔ = jen čas startu, bez zařízení
                "watched_at": int(_w.get("watched_at") or 0),
                "device": str(_w.get("device") or ""),
            })
            if limit > 0 and len(out) >= limit:
                break
    except Exception:
        pass
    return out


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_history.py
# watch_history_clear  (vytvořeno: 24.01.2026 20:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
@_locked_personal("watch_history.json")
def watch_history_clear() -> None:
    """
    Vymaže obsah `watch_history.json` a založí prázdnou strukturu:
      {"movies": [], "episodes": []}

    • Používá xbmcvfs kvůli kompatibilitě napříč platformami.
    • Nikdy nevyhazuje výjimku směrem do GUI (fail‑safe).
    • Po úspěchu zobrazí krátké potvrzení.
    """
    try:
        profile_dir = _get_profile_dir()
        watch_path = _get_watch_path()
        before = watch_load()   # tombstony pro Gate

        # zajisti existenci profilu (pro případ, že neexistuje)
        try:
            xbmcvfs.mkdirs(str(profile_dir))
        except Exception:
            pass

        # prázdná struktura
        empty = {"movies": [], "episodes": []}

        # zkus smazat starý soubor (ignore errors)
        try:
            if xbmcvfs.exists(str(watch_path)):
                xbmcvfs.delete(str(watch_path))
        except Exception:
            pass

        # ihned zapiš čistý JSON (atomicky přes tmp → rename)
        import richmovie_atomic as _atomic   # 3.5.140: SSOT trvanlivého zápisu (fsync, binární režim)
        _atomic.write_json(str(watch_path), empty, indent=2)
        _items_note("note_watch_clear", before)

        # Konzistence: vymazat i completion-based store dokoukaných epizod
        # (jinak by „fajfky" u epizod zůstaly i po vymazání historie). Gate = zdroj pravdy ✔
        # (3.5.134) → každý díl dostane tombstone scope=watched, jinak se ✔ do 30 s vrátí z Gate
        # a na ostatních zařízeních nikdy nezmizí (Fable P2-5).
        try:
            for ep in (watched_load() or {}).get("episodes") or []:
                if isinstance(ep, dict):
                    _sync_note("unwatched_episode", tv_id=ep.get("tv_id"), season=int(ep.get("season") or 0),
                               episode=int(ep.get("episode") or 0))
            watched_path = _get_watched_path()
            if xbmcvfs.exists(str(watched_path)):
                xbmcvfs.delete(str(watched_path))
        except Exception:
            pass

        _modal("Historie sledování byla vymazána.")
    except Exception:
        # potichu selhat – historie nikdy nesmí shodit doplněk
        pass




# ═══════════════════════════════════════════════════════════════════════════════
#  CONTINUE WATCHING – sledovani s pozici zastaveni
# ═══════════════════════════════════════════════════════════════════════════════

# 4.0.3 / mig 0038 (plán PLAN_watched_progress_integrity_20261010 §3.2): `continue_watching.json` drží POSTUP
# PER TITUL (každý rozkoukaný díl) — lokální cache osy postupu z Gate. „Pokračovat“ je jen POHLED `cw_view`
# (jeden titul per seriál, nejnovější první, prvních CW_VIEW_MAX). Dřív strop 10 položek a mazání ostatních
# dílů seriálu ztrácely rozkoukanost, kterou pak seznam dílů neměl odkud ukázat (nález M5).
CW_MAX_ITEMS = 500     # úložiště postupu (titulů)
CW_VIEW_MAX = 10       # kolik titulů ukazuje Pokračovat
CW_EXPIRE_DAYS = 180   # = Gate PROGRESS_RETENTION_DAYS (rozkoukanost vyprší stejně na zařízení i na Gate)


def _get_cw_path() -> Path:
    return _get_profile_dir() / "continue_watching.json"


def _cw_lock():
    """3.5.134: CW soubor mění tři cesty naráz — player vlákno služby (`_save_cw_position`),
    vlákno RMStateSync (sloučení z Gate) a plugin (jiný proces, ruční odebrání).
    Read-modify-write bez zámku = lost update. SSOT zámek `richmovie_atomic.FileLock`
    (best-effort: po timeoutu pokračuje bez zámku, zápis samotný je atomický)."""
    import richmovie_paths as _rp
    return _rp.personal_lock("continue_watching.json")   # SSOT zámku osobních souborů (3.5.144)


def _locked_cw(fn):
    """Dekorátor CW mutátorů (cw_upsert / cw_advance_episode / cw_remove /
    cw_remove_by_index): celé read-modify-write pod `_cw_lock()`. Zámek není
    reentrantní — mutátory se navzájem nevolají (volající je řadí za sebou)."""
    import functools

    @functools.wraps(fn)
    def _inner(*args, **kwargs):
        with _cw_lock():
            return fn(*args, **kwargs)
    return _inner


def _cw_playable(it) -> bool:
    """Záznam je přehratelný, pokud má jak ho spustit. Film bez identu, TMDb
    i lokální cesty = mrtvá dlaždice (incident „Bez názvu" → fallback hledání)
    → odfiltrovat. Epizody mají vždy tv_id kontext."""
    if not isinstance(it, dict):
        return False
    if it.get("type") == "episode":
        return bool(it.get("tv_id") or it.get("tmdb_id") or it.get("ident"))
    return bool(it.get("ident") or it.get("tmdb_id") or it.get("path"))


def _hidden_map(data: Any) -> dict:
    raw = data.get("hidden_series") if isinstance(data, dict) else None
    out = {}
    for k, v in (raw or {}).items() if isinstance(raw, dict) else []:
        try:
            out[str(k)] = float(v)
        except (TypeError, ValueError):
            continue
    return out


def cw_load() -> dict:
    """Nacte continue_watching.json. Vraci {"items": [...], "hidden_series": {tv_id: ts}} — VŠECHNY tituly
    s postupem (úložiště). Pro zobrazení „Pokračovat“ vždy `cw_view_load()`.
    Odfiltruje nepřehratelné záznamy (sanitace starých poškozených dat)."""
    cw_path = _get_cw_path()
    try:
        if not cw_path.exists():
            return {"items": [], "hidden_series": {}}
        with open(cw_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict) and "items" in data:
            items = data.get("items") or []
            hidden = _hidden_map(data)
            clean = [it for it in items if _cw_playable(it)]
            # pokud sanitace něco odebrala, přepiš soubor (jednorázová migrace)
            if len(clean) != len(items):
                try:
                    cw_save({"items": clean, "hidden_series": hidden})
                except Exception:
                    pass
            return {"items": clean, "hidden_series": hidden}
        return {"items": [], "hidden_series": {}}
    except Exception:
        return {"items": [], "hidden_series": {}}


def _cw_group(it: dict) -> str:
    """Skupina pohledu Pokračovat: seriál = jeden řádek, film/soubor = sám za sebe."""
    if it.get("type") == "episode":
        return "tv:%s" % str(it.get("tv_id") or it.get("tmdb_id") or "")
    if it.get("tmdb_id"):
        return "movie:%s" % str(it.get("tmdb_id"))
    if it.get("path"):
        return "path:%s" % str(it.get("path"))
    return "title:%s:%s" % ((it.get("title") or "").strip().lower(), str(it.get("year") or ""))


def cw_view(items: list, hidden_series: Optional[dict] = None, limit: int = CW_VIEW_MAX) -> list:
    """POHLED „Pokračovat“ nad úložištěm postupu (čisté, harness 90): za každý seriál jen NEJNOVĚJŠÍ titul
    (rozkoukaný díl nebo nabídnutý další díl), filmy samostatně, seřazeno podle času změny, prvních `limit`.
    Seriál skrytý „Odebrat z Pokračovat“ (`hidden_series`) se ukáže znovu až s postupem NOVĚJŠÍM než skrytí."""
    hidden = hidden_series or {}
    best: dict = {}
    for it in items or []:
        if not isinstance(it, dict):
            continue
        ts = float(it.get("ts") or 0)
        if it.get("type") == "episode":
            hid = float(hidden.get(str(it.get("tv_id") or it.get("tmdb_id") or ""), 0) or 0)
            if hid and ts <= hid:
                continue
        g = _cw_group(it)
        cur = best.get(g)
        if cur is None or ts > float(cur.get("ts") or 0):
            best[g] = it
    view = sorted(best.values(), key=lambda it: float(it.get("ts") or 0), reverse=True)
    return view[:max(0, int(limit))]


def progress_for_movie(tmdb_id: Any, items: Optional[list] = None) -> Optional[dict]:
    """Rozkoukaný film profilu {"position", "duration", "ts", "device", "ident"} nebo None (čisté nad úložištěm)."""
    if not tmdb_id:
        return None
    best = None
    for it in (items if items is not None else cw_load().get("items") or []):
        if not isinstance(it, dict) or it.get("type") == "episode" or str(it.get("tmdb_id")) != str(tmdb_id):
            continue
        try:
            pos = float(it.get("position") or 0)
        except (TypeError, ValueError):
            continue
        if pos <= 0 or (best is not None and float(best["ts"]) >= float(it.get("ts") or 0)):
            continue
        best = {"position": pos, "duration": float(it.get("duration") or 0), "ts": float(it.get("ts") or 0),
                "device": str(it.get("remote_device_label") or ""), "ident": str(it.get("ident") or "")}
    return best


def progress_mark(progress: Optional[dict]) -> str:
    """Značka streamu, na kterém se skončilo (A5): „◐ pokračuj od 23:10“; prázdné = nic. Čisté."""
    if not progress or float(progress.get("position") or 0) <= 0:
        return ""
    pos = int(float(progress.get("position") or 0))
    h, m, s_ = pos // 3600, (pos % 3600) // 60, pos % 60
    return "◐ pokračuj od %s" % ("%d:%02d:%02d" % (h, m, s_) if h else "%d:%02d" % (m, s_))


def progress_rev(progress: Optional[dict]) -> str:
    """Revize postupu do adresy streamu (vzor `cw_play rev`): mění se jen se změnou postupu — Kodi pod adresou
    s revizí nikdy nenajde vlastní záložku a neukáže druhý dialog „Pokračovat od…“; navázání řídí RichMovie."""
    if not progress:
        return ""
    return "%d-%d" % (int(float(progress.get("position") or 0)), int(float(progress.get("ts") or 0)))


def cw_view_load() -> dict:
    """{"items": pohled Pokračovat} — JEDINÉ čtení pro všechna místa, která Pokračovat ukazují nebo podle
    něj klikají (seznam, řádek menu, raily, hero, detail, hub). Index v odkazu = index v TOMTO pohledu."""
    data = cw_load()
    return {"items": cw_view(data.get("items") or [], data.get("hidden_series") or {})}


def progress_for_series(tv_id: Any, items: Optional[list] = None) -> dict:
    """{(season, episode): {"position", "duration", "ts", "device", "activity", "ident"}} rozkoukaných dílů
    seriálu (pozice > 0; nabídnutý další díl na 0 není rozkoukaný). SSOT pro seznam dílů, sezóny a výpis
    streamů (◐, „tady jsi skončila“). Čisté nad úložištěm; `items` = už načtený seznam."""
    out: dict = {}
    tid = str(tv_id)
    for it in (items if items is not None else cw_load().get("items") or []):
        if not isinstance(it, dict) or it.get("type") != "episode" or str(it.get("tv_id")) != tid:
            continue
        try:
            key = (int(it.get("season") or 0), int(it.get("episode") or 0))
            pos = float(it.get("position") or 0)
        except (TypeError, ValueError):
            continue
        if pos <= 0 or key[0] < 0 or key[1] <= 0:
            continue
        prev = out.get(key)
        if prev is not None and float(prev.get("ts") or 0) >= float(it.get("ts") or 0):
            continue
        out[key] = {"position": pos, "duration": float(it.get("duration") or 0), "ts": float(it.get("ts") or 0),
                    "device": str(it.get("remote_device_label") or ""), "activity": str(it.get("activity") or ""),
                    "ident": str(it.get("ident") or "")}
    return out


def _cw_load_for_update() -> Optional[dict]:
    """Čtení PŘED zápisem Pokračovat (3.5.152, backlog 3.5.151): parita s `_load_for_update` u ✔.
    `cw_load` (UI) vrací při JAKÉKOLI chybě prázdno — mutátor by pak uložil Pokračovat s jedinou
    položkou a smazal ostatní. UNREADABLE (I/O chyba) → None = zápis se NEPROVEDE; ostatní stavy
    = sanitovaný seznam jako `cw_load` (+ mapa skrytých seriálů, kterou žádný mutátor nesmí ztratit)."""
    import richmovie_atomic as _atomic
    data, state = _atomic.read_json(str(_get_cw_path()), None, name="continue_watching", expected_type=dict)
    if state == _atomic.STATE_UNREADABLE:
        return None
    items = (data.get("items") if isinstance(data, dict) else None) or []
    return {"items": [it for it in items if _cw_playable(it)], "hidden_series": _hidden_map(data)}


def cw_save(data: dict) -> bool:
    """Trvanlivě a atomicky uloží continue_watching.json (SSOT `richmovie_atomic`,
    3.5.123). Pozice v Pokračovat ve sledování jsou přesně ta data, o která
    uživatel přijde při vytržení boxu ze zásuvky — proto fsync před replace.
    3.5.151: vrací True = na disku (sloučení z Gate podle toho drží kurzor, R2)."""
    cw_path = _get_cw_path()
    try:
        import richmovie_atomic as _atomic
        if _atomic.write_json(str(cw_path), data, indent=2):
            _data_rev_bump("cw")  # Φ5 invalidation kontrakt (otevřená okna refreshnou)
            return True
        return False
    except Exception:
        return False


def _data_rev_bump(domain: str) -> None:
    """Φ5 (2026-07-06, audit A09): bump revision counteru domény — SSOT mutátory
    (cw_save/watched_save/_my_list_save/ai_dismiss) tím říkají otevřeným custom
    oknům „tvoje raily jsou stale". Lazy import (history běží i v service
    procesu). Best-effort — nikdy neshodí zápis."""
    try:
        import richmovie_ui_common as _uc
        _uc.data_rev_bump(domain)
    except Exception:
        pass


def _sync_note(op: str, payload=None, **kw) -> None:
    """Φ3b (3.5.134): lokální změna stavu → fronta pro Gate (`richmovie_state_sync`,
    SSOT mapování). Lazy import (history běží i v service procesu), best-effort —
    nikdy neshodí zápis. Při aplikaci vzdáleného stavu se nic nezařadí (echo)."""
    try:
        import richmovie_state_sync as _ss
        _ss.note_local_change(op, payload, **kw)
    except Exception:
        pass


def _items_note(fn: str, *args) -> None:
    """3.5.144 (plán PLAN_profile_data_sync_20260905): osobní kolekce → Gate per profil.
    `richmovie_profile_items` je SSOT mapování (klíče, payload); tady jen lazy volání
    (history běží i ve službě), best-effort — nikdy neshodí zápis. Při aplikaci
    vzdálených položek (`applying_remote`) se nic nezařadí (echo)."""
    try:
        import richmovie_profile_items as _pi
        getattr(_pi, fn)(*args)
    except Exception:
        pass


def _cw_purge_expired(items: list) -> list:
    """Odstrani zaznamy starsi nez CW_EXPIRE_DAYS. Nečíselné `ts` (poškozený záznam) = prošlý
    záznam s WARNING — dřív `float()` shodil celý `cw_upsert` a Pokračovat se přestalo ukládat
    (3.5.152, backlog 3.5.151)."""
    import time as _time
    cutoff = _time.time() - CW_EXPIRE_DAYS * 86400
    keep = []
    for it in items:
        try:
            ts = float(it.get("ts") or 0)
        except (TypeError, ValueError):
            try:
                import xbmc as _xbmc_cw
                _xbmc_cw.log("[RichMovie/History] CW_TS_INVALID ts=%r title=%r → záznam vyřazen"
                             % (it.get("ts"), it.get("title")), _xbmc_cw.LOGWARNING)
            except Exception:
                pass
            continue
        if ts > cutoff:
            keep.append(it)
    return keep


@_locked_cw
def cw_upsert(item: dict, *, strict: bool = False) -> bool:
    """
    Prida nebo aktualizuje polozku v continue_watching.
    Deduplikace:
      - film: dle tmdb_id; fallback dle (title + year)
      - epizoda: dle (tv_id, season, episode)
    Expirace: zaznamy starsi nez CW_EXPIRE_DAYS se automaticky smazi.
    Nejnovejsi polozka je vzdy na indexu 0.
    Vrací True = zapsáno. `strict=True` (sloučení z Gate, Fable F4): výjimka projde k volajícímu,
    který rozliší vadnou položku od chyby prostředí (`richmovie_sync_queue.apply_error_blocks_cursor`);
    False pak znamená jen nezapsaný soubor.
    """
    try:
        data = _cw_load_for_update()
        if data is None:
            _log("CW_WRITE_SKIPPED cw_upsert: soubor nečitelný", xbmc.LOGWARNING)
            return False
        items = list(data.get("items", []))

        item_type = item.get("type", "movie")

        def _is_same(a: dict) -> bool:
            if item_type == "episode":
                return (str(a.get("tv_id")) == str(item.get("tv_id"))
                        and int(a.get("season") or 0) == int(item.get("season") or 0)
                        and int(a.get("episode") or 0) == int(item.get("episode") or 0))
            else:
                # Film: preferovat TMDb ID, fallback na title+year
                tid = item.get("tmdb_id")
                if tid and a.get("tmdb_id"):
                    return str(a.get("tmdb_id")) == str(tid)
                return ((a.get("title") or "").strip().lower() ==
                        (item.get("title") or "").strip().lower()
                        and str(a.get("year") or 0) == str(item.get("year") or 0))

        # expirace starych zaznamu
        items = _cw_purge_expired(items)

        # odstranit starou verzi
        items = [it for it in items if not _is_same(it)]

        # vlozit na zacatek
        items.insert(0, item)

        # 13.09.2026 (3.5.148): pořadí = čas POSTUPU (`ts` DESC), ne pořadí vložení. Vzdálený stav
        # nese `ts` zařízení, které ho vytvořilo; stabilní sort nechá při shodě nový záznam první.
        # Titulní strana (`cw_items[0]`) tak ukazuje skutečně poslední postup profilu (nález N1).
        items.sort(key=lambda it: float(it.get("ts") or 0), reverse=True)

        # orez
        items = items[:CW_MAX_ITEMS]

        data["items"] = items
        ok = cw_save(data)
        _sync_note("cw_upsert", item)
        return ok
    except Exception:
        # 3.5.151 (cross-check Pro B PB1a): chyba bez zápisu nesmí sloučení z Gate vypadat jako úspěch
        if strict:
            raise
        return False


def cw_contains_episode(*, tv_id, season: int, episode: int) -> bool:
    """Φ8 (R3-P2-1): True, pokud CW obsahuje PŘESNĚ tento díl. Start guard
    v service_nextup propouští update <30 s jen pro existující záznam TÉHOŽ
    dílu (autoplay chain po cw_advance) — celoseriálový test propouštěl i
    omylem kliknutý JINÝ díl → duplicitní řádek seriálu nad reálným postupem."""
    if tv_id in (None, ""):
        return False
    try:
        for it in cw_load().get("items", []):
            if (it.get("type") == "episode"
                    and str(it.get("tv_id")) == str(tv_id)
                    and int(it.get("season") or 0) == int(season)
                    and int(it.get("episode") or 0) == int(episode)):
                return True
    except Exception:
        pass
    return False


def cw_contains_series(tv_id) -> bool:
    """Φ3 (2026-07-06): True, pokud CW obsahuje JAKOUKOLI epizodu seriálu.
    Session-aware start guard v service_nextup podle toho pozná, že jde
    o pokračování rozkoukaného seriálu (autoplay chain), ne omylem kliknuté
    video — a pozici uloží i pod 30 s."""
    if tv_id in (None, ""):
        return False
    try:
        for it in cw_load().get("items", []):
            if it.get("type") == "episode" and str(it.get("tv_id")) == str(tv_id):
                return True
    except Exception:
        pass
    return False


@_locked_cw
def cw_advance_episode(*, tv_id, season: int, episode: int,
                       next_season: int, next_episode: int,
                       next_ep_title: str = "") -> bool:
    """Φ3 (2026-07-06, UX audit A02 — „Netflix sémantika"): dokoukaná epizoda
    NAHRADÍ záznam seriálu v CW dalším dílem (position=0), místo aby seriál
    z CW úplně zmizel (root cause „měsíc stará Planeta opic": cw_remove bez
    náhrady + start guard zahodil autoplay díl stopnutý do 30 s).

    Kopíruje metadata dokoukané epizody (tv_name, plakáty…), maže per-episode
    pole (ident/fs_*/ep_title — patří STARÉMU dílu; klik bez identu jde
    korektně picker-first cestou přes tv kontext, viz _cw_playable). Nový
    záznam jde na index 0 (nejčerstvější aktivita). Vrací True při náhradě,
    False = záznam nenalezen (volající řeší fallback cw_remove)."""
    import time as _time
    try:
        if tv_id in (None, "") or int(next_season) <= 0 or int(next_episode) <= 0:
            return False
        data = _cw_load_for_update()
        if data is None:
            return False
        items = list(data.get("items", []))

        def _match(it: dict) -> bool:
            return (it.get("type") == "episode"
                    and str(it.get("tv_id")) == str(tv_id)
                    and int(it.get("season") or 0) == int(season)
                    and int(it.get("episode") or 0) == int(episode))

        old = next((it for it in items if _match(it)), None)
        if old is None:
            # fallback: nejčerstvější záznam téhož seriálu (autoplay chain mohl
            # mezitím CW posunout jinam) — nikdy nesahat na cizí seriály.
            # R3-P1-1 (re-audit 2026-07-06): POUZE VPŘED — rewatch STARŠÍHO
            # dílu (dokoukaná epizoda < záznam v CW) nesmí zničit reálný
            # postup (S03E07 @ 60 % by se přepsal na position=0). V tom
            # případě False → volající udělá exact cw_remove (no-op) a
            # rozkoukaný postup zůstává nedotčen.
            cand = next((it for it in items
                         if it.get("type") == "episode"
                         and str(it.get("tv_id")) == str(tv_id)), None)
            if cand is not None:
                cand_pos = (int(cand.get("season") or 0), int(cand.get("episode") or 0))
                if (int(season), int(episode)) >= cand_pos:
                    old = cand
        if old is None:
            return False

        new_item = dict(old)
        new_item.pop("remote_device_label", None)   # posun dílu je LOKÁLNÍ akce (Fable P3-4)
        new_item.pop("remote_updated_at", None)
        new_item.pop("activity", None)              # nový díl ještě nikdo nehraje (= stopped)
        new_item.pop("client_time", None)           # posun = změna TEĎ, ne čas posledního postupu starého dílu
        new_item.update({
            "season": int(next_season),
            "episode": int(next_episode),
            "ep_title": next_ep_title or "",
            "position": 0,
            "ts": int(_time.time()),
            "ident": "",       # per-episode — ident starého dílu je k ničemu
            "fs_url": "",
            "fs_hash": "",
            "source": "webshare",  # R3-P3-2: source patřil starému dílu (fs_* smazané)
        })
        # mig 0038: z úložiště odchází jen DOKOUKANÝ díl (a starý nabídnutý další díl téže pozice); jiné rozkoukané
        # díly seriálu zůstávají (◐ v seznamu dílů) — Pokračovat ukáže nejnovější (`cw_view`). ✔ na Gate postup
        # dokoukaného dílu uzavře sám (osa postupu se zavírá dokoukáním).
        finished = (str(tv_id), int(season), int(episode))
        nxt = (str(tv_id), int(next_season), int(next_episode))
        # + staré NABÍDKY dílu téhož seriálu (pozice 0, cross-check Flash C F5): platí jen nejnovější nabídka;
        # rozkoukané díly (pozice > 0) zůstávají
        items = [it for it in items
                 if not (it.get("type") == "episode"
                         and ((str(it.get("tv_id")), int(it.get("season") or 0), int(it.get("episode") or 0)) in (finished, nxt)
                              or (str(it.get("tv_id")) == str(tv_id) and float(it.get("position") or 0) <= 0)))]
        items.insert(0, new_item)
        data["items"] = items[:CW_MAX_ITEMS]
        cw_save(data)
        _sync_note("cw_upsert", new_item)
        return True
    except Exception:
        return False


@_locked_cw
def cw_remove(*, tmdb_id: int | str | None = None,
              tv_id: int | str | None = None,
              season: int | None = None,
              episode: int | None = None,
              strict: bool = False) -> bool:
    """
    Odstrani polozku z continue_watching.
    Pro filmy: dle tmdb_id. Pro epizody: dle (tv_id, season, episode).
    Vrací True = zapsáno; `strict` viz `cw_upsert`.
    """
    try:
        data = _cw_load_for_update()
        if data is None:
            return False
        items = list(data.get("items", []))

        def _should_remove(it: dict) -> bool:
            if tv_id is not None and season is not None and episode is not None:
                return (str(it.get("tv_id")) == str(tv_id)
                        and int(it.get("season") or 0) == int(season)
                        and int(it.get("episode") or 0) == int(episode))
            elif tmdb_id is not None:
                return str(it.get("tmdb_id")) == str(tmdb_id)
            return False

        removed = [it for it in items if _should_remove(it)]
        items = [it for it in items if not _should_remove(it)]
        data["items"] = items
        ok = cw_save(data)
        for _it in removed:
            _sync_note("cw_remove", _it)
        return ok
    except Exception:
        if strict:     # 3.5.151 (PB1a, Fable F4): viz cw_upsert
            raise
        return False


@_locked_cw
def cw_rewind_series(item: dict, asleep_since: float = 0.0) -> bool:
    """Vrátí „Pokračovat" daného seriálu na KONKRÉTNÍ díl od začátku (3.5.149, D2).

    Používá se, když řetěz autoplay dílů skončil dotazem „Díváš se ještě?" bez odpovědi:
    díly za místem usnutí jsou `unattended` a v Pokračovat má být PRVNÍ z nich od začátku.
    Stejná sémantika jako `cw_advance_episode` (nahradí JEDINÝ řádek seriálu), jen opačným
    směrem a s pozicí 0. Vrací True, když se zapsalo.

    `asleep_since` = kdy divák naposledy reagoval (usnul): záznamy seriálu změněné OD té chvíle jsou artefakty
    řetězu a jdou pryč. Zápis sám nese čas „teď“ (cross-check Pro B PB1 10.10.2026): s časem usnutí byl na Gate
    STARŠÍ než uzavření prvního prospaného dílu (✔ na jeho konci), Gate ho zahodil a ostatní zařízení seriál
    v Pokračovat neměla (ani volbu „už ho mám za sebou“). Řádky jsou per díl — čas „teď“ nepřebije postup
    jiného dílu na jiném zařízení."""
    import time as _time
    try:
        tv_id = item.get("tv_id")
        if not tv_id or int(item.get("season") or 0) <= 0 or int(item.get("episode") or 0) <= 0:
            return False
        data = _cw_load_for_update()
        if data is None:
            return False
        now = _time.time()
        ts = float(asleep_since) if asleep_since and asleep_since > 0 else now
        target_key = (int(item.get("season") or 0), int(item.get("episode") or 0))
        # mig 0038 (postup per titul): pryč jdou jen ARTEFAKTY řetězu — díly seriálu změněné po místě usnutí
        # (nabídnutý další díl, rozehraný díl za ním) a starý záznam cílového dílu; starší rozkoukané díly zůstávají.
        dropped = [it for it in list(data.get("items", []))
                   if it.get("type") == "episode" and str(it.get("tv_id")) == str(tv_id)
                   and ((int(it.get("season") or 0), int(it.get("episode") or 0)) == target_key
                        or float(it.get("ts") or 0) >= ts)]
        items = [it for it in list(data.get("items", [])) if it not in dropped]
        new_item = dict(item)
        new_item.update({"type": "episode", "position": 0, "ts": int(now)})
        for _k in ("remote_device_label", "remote_updated_at", "activity"):
            new_item.pop(_k, None)
        new_item["client_time"] = now
        items.insert(0, new_item)
        items.sort(key=lambda it: float(it.get("ts") or 0), reverse=True)
        data["items"] = items[:CW_MAX_ITEMS]
        cw_save(data)
        target = (int(new_item.get("season") or 0), int(new_item.get("episode") or 0))
        for it in dropped:
            # rozehraný díl ZA místem usnutí (autoplay ho stihl spustit) jde z Pokračovat pryč i na Gate
            # (Fable audit F1 14.09.2026: bez `removed` by ho ostatní zařízení ukazovala dál)
            if (int(it.get("season") or 0), int(it.get("episode") or 0)) != target:
                _sync_note("cw_remove", it)
        _sync_note("cw_upsert", new_item)
        return True
    except Exception:
        return False


@_locked_cw
def cw_hide_series(*, tv_id: Any, ts: Optional[float] = None, strict: bool = False) -> bool:
    """„Odebrat z Pokračovat“ u seriálu (mig 0038): skryje CELÝ seriál v pohledu, dokud nevznikne novější postup.
    Rozkoukanost dílů (◐ v seznamu) zůstává. Na Gate jde značka `removed` scope `cw_series` (řádek season 0/ep 0).
    `ts` = čas skrytí (z Gate při sloučení; jinak teď). True = zapsáno."""
    import time as _time
    try:
        if not tv_id:
            return False
        data = _cw_load_for_update()
        if data is None:
            return False
        hidden = dict(data.get("hidden_series") or {})
        when = float(ts) if ts else _time.time()
        if float(hidden.get(str(tv_id), 0) or 0) >= when:
            return True   # novější skrytí už platí
        hidden[str(tv_id)] = when
        data["hidden_series"] = hidden
        ok = cw_save(data)
        if ts is None:
            _sync_note("cw_hide_series", None, tv_id=tv_id)
        return ok
    except Exception:
        if strict:
            raise
        return False


def cw_dismiss(item: dict) -> bool:
    """„Odebrat z Pokračovat“ pro položku POHLEDU: seriál se skryje celý (`cw_hide_series`), film / soubor se
    odebere (`cw_remove`). True = zapsáno."""
    if not isinstance(item, dict):
        return False
    if item.get("type") == "episode":
        return cw_hide_series(tv_id=item.get("tv_id") or item.get("tmdb_id"))
    if item.get("tmdb_id"):
        return cw_remove(tmdb_id=item.get("tmdb_id"))
    return cw_remove_matching(item)


@_locked_cw
def cw_remove_matching(item: dict) -> bool:
    """Odebere záznam bez TMDb id (lokální soubor z NAS) podle cesty / názvu+roku."""
    try:
        data = _cw_load_for_update()
        if data is None:
            return False
        g = _cw_group(item)
        removed = [it for it in data.get("items", []) if _cw_group(it) == g]
        if not removed:
            return False
        data["items"] = [it for it in data.get("items", []) if _cw_group(it) != g]
        ok = cw_save(data)
        for _it in removed:
            _sync_note("cw_remove", _it)
        return ok
    except Exception:
        return False


@_locked_cw
def cw_remove_by_index(index: int) -> bool:
    """
    Odstrani polozku z continue_watching dle indexu.
    Vraci True pokud byla polozka odstranena.
    """
    try:
        data = _cw_load_for_update()
        if data is None:
            return False
        items = list(data.get("items", []))
        if 0 <= index < len(items):
            removed = items.pop(index)
            data["items"] = items
            cw_save(data)
            _sync_note("cw_remove", removed)
            return True
    except Exception:
        pass
    return False


@_locked_cw
def cw_clear() -> None:
    """Smaze vsechny polozky z continue_watching (a ohlásí každou jako odebranou
    ostatním zařízením — jinak by se při dalším pullu vrátily)."""
    try:
        data = _cw_load_for_update()
        if data is None:
            return   # nečitelný soubor: nevíme, co odebrat → nic nemazat (ohlásí se až po dalším pokusu)
        items = list(data.get("items") or [])
        cw_save({"items": [], "hidden_series": data.get("hidden_series") or {}})
        for _it in items:
            _sync_note("cw_remove", _it)
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════════
#  ALIASY PRO ZPĚTNOU KOMPATIBILITU
# ═══════════════════════════════════════════════════════════════════════════════
# Tyto aliasy umožňují použít funkce s původními názvy z plugin.py

_load_history = load_history
_save_history = save_history
_add_to_history = add_to_history
_history_clear = history_clear

_watch_load = watch_load
_watch_save = watch_save
_watch_add_movie = watch_add_movie
_watch_add_episode = watch_add_episode
_watch_history_clear = watch_history_clear

# Konstanty s původními názvy
_WATCH_MAX_ITEMS = WATCH_MAX_ITEMS
_WATCH_UI_MAX_MOVIES = WATCH_UI_MAX_MOVIES
_WATCH_UI_MAX_EPISODES = WATCH_UI_MAX_EPISODES
