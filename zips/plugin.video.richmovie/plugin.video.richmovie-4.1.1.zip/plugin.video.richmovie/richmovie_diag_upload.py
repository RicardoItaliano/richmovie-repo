# -*- coding: utf-8 -*-
"""richmovie_diag_upload.py — odeslání vyžádaného výřezu kodi.logu (3.5.120)

Proč to existuje
----------------
Na NAS tečou jen zprávy, které si addon sám vyrobí. Kodi jádro — VFS chyby,
`CFileCache`, `CCurlFile`, pády přehrávače, tracebacky mimo naši pipeline — tam
nebylo nikdy vidět. Incident bandog (27.08.2026) se proto nedal uzavřít: chyběl
`kodi.log` ze zařízení a jediná cesta k němu vedla přes telefonát a hledání
souboru na Android TV. Plán: `Handoff/PLAN_3_5_120_observability_hardening_20260827.md`.

Nepřekročitelné pravidlo tohohle modulu
---------------------------------------
**Diagnostický kanál nesmí sdílet příčinu selhání s tím, co diagnostikuje.**
Když se rozbije čtení nastavení, umlkne s ním všechno, co z nastavení bere
identitu. Proto:
  • identita pro upload = `device_hash` ze **souboru** `addon_data/device_id`,
    ne `username`/`password` z nastavení (Gate si uživatele dohledá sám),
  • spustit to jde i ručně — položkou v menu addonu; pověření (`log_pull_id`) je ale
    VŽDY serverové (Gate jiný upload neautorizuje), bere se z posledního úspěšného
    `/auth`. Bez vyžádání správcem se nic neposílá a uživatel se to dozví (3.5.145;
    do té doby ruční cesta posílala prázdný id a Gate ji odmítal 400),
  • killswitch se vyhodnocuje jen tehdy, když se nastavení prokazatelně čte;
    porucha čtení nesmí vypnout diagnostiku poruchy.

Co se posílá
------------
Od 3.5.145 **celý konec obou logů** (`kodi.log` + `kodi.old.log`, posledních
`RAW_TAIL_BYTES` z každého) — po redakci tajemství (`redact`). Do 3.5.144 se posílal
jen allowlist (naše řádky, ERROR/WARNING jádra, klíčová slova ±3 řádky); rozhodnutí
Richie 09.09.2026 („log bychom měli mít vždy celý"): výběr schovával přesně ty řádky,
které byly při vyšetřování potřeba (INFO jádra — `VideoPlayer::OpenFile`, načítání
nastavení, `CPluginDirectory`), a incident bandog se bez nich nedal uzavřít. Uživatel
upload potvrzuje dialogem (souhlas se ukládá), redakce zůstává povinná první linií
na zařízení a Gate ji opakuje jako druhou.

Kontrakt částí (Gate `/v1/diag/kodi_log`)
-----------------------------------------
Gate každou část **rozbaluje samostatně** (`_decompress_bounded` per část) — část je
proto vždy **samostatný gzip** kousku textu (`pack_parts`), NE bajtový výřez jednoho
velkého gzipu. Do 3.5.144 se jeden gzip krájel po bajtech, takže druhá a další část
byly pro Gate nečitelné (`gzip_decode_failed`) a fungoval jen upload do 512 KiB.
"""

from __future__ import annotations

import gzip
import hashlib
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

import xbmc
import xbmcgui
import xbmcvfs

import richmovie_settings as _rm_settings

try:
    from richmovie_logging import make_legacy_logger as _du_make_logger
    _log = _du_make_logger("richmovie.diag_upload", "RichMovie/DiagUpload")
except Exception:  # pragma: no cover — fallback mimo pipeline
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log("[RichMovie/DiagUpload] " + str(msg), level)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────

# Kolik syrového textu vzít z konce každého souboru.
# Jiná rovina než `CHUNK_BYTES`/`MAX_PARTS` níže: tohle je vstup, ty jsou výstup
# po kompresi. Pojmenováno schválně odlišně, ať se to neplete.
RAW_TAIL_BYTES = 3 * 1024 * 1024        # 3 MiB syrového textu na soubor

CHUNK_BYTES = 512 * 1024                # 512 KiB gzip na část (musí ≤ Gate DIAG_MAX_CHUNK_BYTES)
# Kolik textu jde do jedné části PŘED kompresí. Musí být < Gate strop rozbalené části
# (DIAG_MAX_CHUNK_BYTES × DIAG_DECOMPRESSED_FACTOR = 4 MiB); log se běžně komprimuje
# 8–15×, takže 1 MiB textu ≈ 70–130 KiB gzip — hluboko pod CHUNK_BYTES. Když by se
# výjimečně nevešel, `pack_parts` výřez půlí.
RAW_SLICE_BYTES = 1024 * 1024
MAX_PARTS = 12                          # strop Gate (2 soubory × 3 MiB / 1 MiB = nejvýš 6 částí)

LOG_FILENAMES = ("kodi.log", "kodi.old.log")
CONSENT_REASK_S = 7 * 86400             # odmítnutý souhlas platí týden, pak se ptáme znovu (D2, 3.5.147)

STATE_FILE = "diag_upload_state.json"
STATE_SCHEMA_VERSION = 1

GUARD_KEY = "diag_upload"
GUARD_TTL_S = 300

# Výsledky `run_pull()` — jediné místo, kde jsou vyjmenované.
RESULT_DONE = "done"
RESULT_NOTHING_REQUESTED = "nothing_requested"
RESULT_ALREADY_DONE = "already_done"
RESULT_DECLINED = "declined"
RESULT_DISABLED = "disabled"
RESULT_NO_DEVICE_ID = "no_device_id"
RESULT_NO_LOG = "no_log"
RESULT_BUSY = "busy"
RESULT_FAILED = "failed"

# ── Redakce (první linie na zařízení, Gate opakuje jako druhou) ─────────────
# Vzory z `richmovie_logging` míří na naše zprávy; tady je text z cizí produkce
# (od 3.5.145 celý log včetně cizích doplňků), takže se přidávají obecné tvary
# tajemství v URL a hlavičkách.
_EXTRA_REDACTIONS = [
    # Přihlašovací údaje vestavěné do URL: `smb://user:heslo@host/...`,
    # `ftp://`, `http(s)://`, `nfs://`. Kodi je loguje běžně při otevírání
    # souboru ze síťového disku (`VideoPlayer::OpenFile`).
    # Bez tohohle vzoru by šlo heslo k domácímu NASu ven v čitelné podobě;
    # dosud ho zachytával jen náhodně e-mailový vzor a jméno zůstávalo.
    # (Nalezeno cross-checkem 27.08.2026, bod P5.)
    (re.compile(r"(?i)\b([a-z][a-z0-9+.\-]*://)[^\s/:@\"'<>]+:[^\s/@\"'<>]+@"),
     r"\1[REDACTED-CREDENTIALS]@"),
    (re.compile(r"(?i)\b(wst|token|auth|api[_-]?key|session|sid|password|passwd|pwd)"
                r"(=|%3D|%253D)[^\s&\"'<>]+"), r"\1\2[REDACTED]"),
    # Kodi volba hlavičky v URL streamu: `url|Cookie=…&User-Agent=…` (Φ7, 29.09.2026 — Fastshare cookie
    # v archivu kodi.logu). Hlavičkový tvar `Cookie: …` chytá vzor níže; tady celá hodnota do dalšího `&`.
    (re.compile(r"(?i)([|&?]cookie=)[^&\s\"'<>|]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)\b(authorization|cookie|set-cookie)\s*:\s*[^\s].*"),
     r"\1: [REDACTED]"),
    (re.compile(r"(?i)https?://[^\s\"'<>]*[?&](wst|token|auth|api[_-]?key|password)"
                r"=[^\s&\"'<>]+"), "[REDACTED-URL]"),
]


# ─────────────────────────────────────────────────────────────────────────────
#  ČISTÁ LOGIKA (testovatelná bez Kodi)
# ─────────────────────────────────────────────────────────────────────────────

class RedactionFailed(Exception):
    """Redakci se nepodařilo dokončit → nesmí se odeslat NIC.

    Selhání redakce je jediné místo v tomhle modulu, kde je správná reakce
    „raději neposlat vůbec". Tiše pustit neredigovaný text ven by znamenalo
    odeslat cizí tokeny a hesla — a nikdo by se to nedozvěděl.
    """


def redact(text: str) -> str:
    """Redakce tajemství. Nejdřív vzory addonu, pak obecné tvary z cizího logu.

    Vyhazuje `RedactionFailed`, když kterýkoli vzor selže. Fail-safe je tady
    obrácený než jinde v addonu: nedokončená redakce = žádné odeslání.
    """
    try:
        from richmovie_logging import RedactingFilter as _RF
        patterns = list(_RF._PATTERNS)
    except Exception as exc:
        # Vzory addonu jsou POVINNÉ — bez nich by ven šly ws_token, FASTSHARE
        # cookie a Bearer hlavičky z našich vlastních zpráv.
        raise RedactionFailed("vzory addonu nedostupné: %r" % (exc,))

    # POŘADÍ JE PODSTATNÉ: nejdřív obecné tvary z cizího logu, teprve pak vzory
    # addonu. Obráceně e-mailový vzor addonu ukousne z `smb://user:heslo@host`
    # část `heslo@host` a URL-credentials vzor už nemá co chytit — uživatelské
    # jméno by zůstalo čitelné. (Nalezeno při ověřování cross-checku 27.08.2026.)
    for index, (pattern, repl) in enumerate(_EXTRA_REDACTIONS + list(patterns)):
        try:
            text = pattern.sub(repl, text)
        except Exception as exc:
            raise RedactionFailed("vzor #%d selhal: %r" % (index, exc))
    return text


def _gzip(text: str) -> bytes:
    return gzip.compress(text.encode("utf-8"))


def pack_parts(text: str, chunk_bytes: int = CHUNK_BYTES,
               raw_slice_bytes: int = RAW_SLICE_BYTES) -> List[bytes]:
    """Text → seznam částí, každá = SAMOSTATNÝ gzip kousku textu ≤ `chunk_bytes`.

    Gate rozbaluje každou část zvlášť, takže bajtový výřez jednoho gzipu by u
    druhé a další části skončil `gzip_decode_failed`. Řeže se na hranici řádků
    (`\\n` zůstává na konci každého kousku, takže spojení rozbalených částí dá
    přesně původní text). Výřez, který se po kompresi nevejde, se půlí; jediný
    řádek delší než limit (v praxi nemožné) se zkrátí se značkou, aby upload
    nikdy nevisel na jedné anomálii. Prázdný vstup → prázdný seznam.
    """
    if not text:
        return []
    lines = text.splitlines(keepends=True)
    parts: List[bytes] = []
    pos = 0
    while pos < len(lines):
        # 1) vezmi řádky do `raw_slice_bytes` (aspoň jeden)
        take = 0
        size = 0
        # velikost v BAJTECH utf-8 (Fable audit 09.09.: strop Gate na rozbalenou část je v bajtech;
        # znaky by u ne-ASCII textu dovolily až 4× víc)
        while pos + take < len(lines) and (take == 0 or size + len(lines[pos + take].encode("utf-8")) <= raw_slice_bytes):
            size += len(lines[pos + take].encode("utf-8"))
            take += 1
        # 2) půl, dokud se komprimovaný výřez nevejde do limitu Gate
        while True:
            blob = _gzip("".join(lines[pos:pos + take]))
            if len(blob) <= chunk_bytes or take == 1:
                break
            take = max(1, take // 2)
        if len(blob) > chunk_bytes:
            # jediný řádek nad limit — zkrátit, ale poslat (R2: upload nesmí uvíznout).
            # Řez podle BAJTŮ utf-8, ne znaků (Pro P2 09.09.2026): 4bajtové znaky by jinak
            # dali až 2× limit; nestlačitelný text se gzipem prakticky nezmenší, takže
            # čtvrtina limitu v bajtech se do části vejde vždy.
            cut_bytes = lines[pos].encode("utf-8")[:chunk_bytes // 4]
            cut = cut_bytes.decode("utf-8", errors="ignore") + " ...[RADEK ZKRACEN]\n"
            blob = _gzip(cut)
        parts.append(blob)
        pos += take
    return parts


# ─────────────────────────────────────────────────────────────────────────────
#  STAV
# ─────────────────────────────────────────────────────────────────────────────

def _state_path() -> str:
    base = xbmcvfs.translatePath(
        "special://profile/addon_data/%s/" % _rm_settings.ADDON_ID
    )
    return os.path.join(base, STATE_FILE)


def _load_state() -> Dict[str, Any]:
    """Stav uploadu přes SSOT `richmovie_atomic` (3.5.123): chybějící soubor je
    legitimní (nic se ještě neposílalo), poškozený jde do karantény + ERROR."""
    import richmovie_atomic as _atomic
    data, _state = _atomic.read_json(_state_path(), {}, name="diag_upload_state",
                                     expected_type=dict)
    return data if isinstance(data, dict) else {}


def _save_state(state: Dict[str, Any]) -> None:
    import richmovie_atomic as _atomic
    if not _atomic.write_json(_state_path(), state, indent=1):
        _log("state write failed", xbmc.LOGWARNING)


# ─────────────────────────────────────────────────────────────────────────────
#  ČTENÍ LOGU
# ─────────────────────────────────────────────────────────────────────────────

def _log_path(filename: str) -> str:
    return os.path.join(xbmcvfs.translatePath("special://logpath/"), filename)


def read_tail(filename: str) -> Tuple[Optional[List[str]], Dict[str, Any]]:
    """Přečte konec logu. Vrací (řádky | None, metadata).

    Kodi může log kdykoli rotovat (`kodi.log` → `kodi.old.log`), klidně uprostřed
    našeho čtení — výsledkem by byl slepenec ze dvou souborů. Proto se před i po
    čtení kontroluje velikost a `mtime`; při změně se pokus zopakuje a nakonec
    označí `rotated`. Poslední řádek běžícího logu bývá neúplný → ořízne se.
    """
    path = _log_path(filename)
    meta: Dict[str, Any] = {"filename": filename, "rotated": False,
                            "bytes_total": 0, "truncated_from_bytes": 0}
    for _attempt in range(2):
        try:
            if not os.path.isfile(path):
                return None, meta
            stat_before = os.stat(path)
            size = stat_before.st_size
            meta["bytes_total"] = int(size)
            with open(path, "rb") as fh:
                if size > RAW_TAIL_BYTES:
                    fh.seek(size - RAW_TAIL_BYTES)
                    meta["truncated_from_bytes"] = int(size - RAW_TAIL_BYTES)
                raw = fh.read()
            stat_after = os.stat(path)
            if (stat_after.st_size, int(stat_after.st_mtime)) != (
                    size, int(stat_before.st_mtime)):
                meta["rotated"] = True
                continue  # jeden opakovaný pokus
            text = raw.decode("utf-8", errors="replace")
            lines = text.splitlines()
            if meta["truncated_from_bytes"] and lines:
                lines = lines[1:]        # první řádek je uříznutý v půli
            if lines and not text.endswith("\n"):
                lines = lines[:-1]       # poslední se právě dopisuje
            # `rotated` z prvního pokusu zůstává True — je to informace „log se během čtení
            # otočil, tohle je druhý, konzistentní pokus" (cross-check 09.09.2026 F15.5).
            return lines, meta
        except Exception as exc:
            _log("read_tail(%s) failed: %r" % (filename, exc), xbmc.LOGWARNING)
            return None, meta
    return None, meta


# ─────────────────────────────────────────────────────────────────────────────
#  SOUHLAS UŽIVATELE
# ─────────────────────────────────────────────────────────────────────────────

def _consent_granted(state: Dict[str, Any], *, interactive: bool) -> Optional[bool]:
    """Vrací True/False (souhlas). Kodi `yesno` nerozliší „Neodesílat" od zavření
    dialogu (Back) — obojí je False a pamatuje se jako odmítnutí; ruční spuštění z menu
    (`interactive=True`) se zeptá znovu a smí ho přebít.

    Odesílá se konec logu o tom, co člověk sledoval a co mu na zařízení běží.
    Toast, který zmizí za tři vteřiny, není souhlas — proto při prvním odeslání
    na zařízení `yesno` s jasným textem. Odpověď se pamatuje, aby se člověk
    nemusel rozhodovat pokaždé znovu.
    """
    if state.get("consent") is True:
        return True
    if state.get("consent") is False and not interactive:
        # Dřívější odmítnutí platí `CONSENT_REASK_S`; pak se ptáme znovu (Kodi `yesno`
        # nerozliší „Neodesílat" od Back, takže omylem zavřený dialog nesmí být navždy —
        # cross-check F15.3 09.09.2026, D2). Ruční spuštění z menu se ptá vždy.
        ts = int(state.get("consent_ts") or 0)
        if ts and (time.time() - ts) < CONSENT_REASK_S:
            return False
        _log("souhlas odmítnut před > %d dny → ptám se znovu" % (CONSENT_REASK_S // 86400), xbmc.LOGINFO)
    # Text musí říkat pravdu o rozsahu (3.5.145: celý konec logu, cross-check 09.09.2026 F15.4):
    # v logu jsou i záznamy jiných doplňků a přehrávaných souborů; hesla a tokeny se
    # odstraní ještě na zařízení (`redact`) a znovu na serveru.
    answer = xbmcgui.Dialog().yesno(
        "RichMovie — odeslat diagnostiku?",
        "Odešle se konec technického logu Kodi (posledních pár MB, včetně záznamů "
        "ostatních doplňků a přehrávaných souborů), aby šlo vyřešit potíže.\n\n"
        "Hesla a přihlašovací tokeny se před odesláním odstraní.",
        yeslabel="Odeslat", nolabel="Neodesílat",
    )
    state["consent"] = bool(answer)
    state["consent_ts"] = int(time.time())
    _save_state(state)
    return bool(answer)


# ─────────────────────────────────────────────────────────────────────────────
#  HLAVNÍ BĚH
# ─────────────────────────────────────────────────────────────────────────────

def _enabled_or_unknown() -> bool:
    """Killswitch `diag_upload_enabled` — vypne se JEN na prokazatelné „false".

    Setting má default `true`, takže dokud s ním uživatel nepohne, v
    `settings.xml` VŮBEC NENÍ. Původní implementace se v takovém případě
    zeptala Kodi API — a když bylo právě rozbité (přesně stav, který má tenhle
    modul vyšetřit), dostala prázdno, vyhodnotila ho jako `False` a diagnostiku
    vypnula. Porucha by si tak sama odřízla kanál, kterým se má nahlásit.
    (Nalezeno cross-checkem 27.08.2026, body P1/P6.)

    Nově se zakazuje jen tehdy, když je hodnota `false` PROKAZATELNĚ přečtená —
    buď z Kodi API při funkčním čtení, nebo přímo ze souboru. Cokoli nejistého
    → povolit, protože default je „zapnuto".
    """
    # POŘADÍ: explicitní volba uživatele v souboru je NEJVYŠŠÍ autorita — i když
    # je Kodi API rozbité. Vypnutá diagnostika se nesmí zapnout „protože je
    # porucha"; kdo si ji vypnul, ten ji chce mít vypnutou tím spíš.
    try:
        state, value = _rm_settings.read_key_from_file("diag_upload_enabled")
        if state == _rm_settings.FILE_HAS_VALUE:
            return str(value).strip().lower() not in ("false", "0", "no")
    except Exception:
        pass

    try:
        verdict = _rm_settings.diagnose_read("diag_upload_enabled").get("verdict")
    except Exception:
        return True

    if verdict == _rm_settings.VERDICT_READ_FAILURE:
        _log("killswitch nelze přečíst (porucha čtení) → pokračuji",
             xbmc.LOGWARNING)
        return True

    # Klíč v souboru není (uživatel s ním nikdy nehnul) → platí default `true`.
    # Ptát se API by tady bylo nebezpečné: při poruše vrátí prázdno = False.
    if verdict == _rm_settings.VERDICT_NOT_CONFIGURED:
        return True

    try:
        return _rm_settings.get_bool("diag_upload_enabled")
    except Exception:
        return True


def run_pull(log_pull_id: str = "", *, interactive: bool = False) -> str:
    """Odešle vyžádaný konec logu. Vrací jeden z `RESULT_*`. Nikdy nevyhazuje.

    `interactive=True` = spuštěno ručně z menu. Gate přijme upload JEN s platným
    `log_pull_id` (jednorázové pověření vydané serverem — `diag/router._authorize`
    ho porovnává s uloženým), takže ruční běh bez id si ho vezme z posledního
    `/auth`; bez vyžádání správcem vrací `RESULT_NOTHING_REQUESTED`. Do 3.5.144 se
    posílal prázdný id a Gate odpověděl 400 `missing_pull_id` — ruční cesta nikdy
    nefungovala (cross-check 09.09.2026 F15.1).
    """
    try:
        import richmovie_gate_transport as _gt
        import richmovie_guard as _guard
    except Exception as exc:
        _log("moduly nedostupné: %r" % (exc,), xbmc.LOGWARNING)
        return RESULT_FAILED

    if not _enabled_or_unknown():
        return RESULT_DISABLED

    if not log_pull_id:
        try:
            import richmovie_gate as _gate
            _requested, log_pull_id = _gate.get_log_pull_request()
        except Exception as exc:
            _log("log_pull_id z /auth nedostupné: %r" % (exc,), xbmc.LOGWARNING)
            log_pull_id = ""
        if not log_pull_id:
            _log("ruční upload bez vyžádání správcem → nic se neposílá", xbmc.LOGINFO)
            return RESULT_NOTHING_REQUESTED

    device_hash = ""
    try:
        device_hash = _gt.get_device_hash() or ""
    except Exception:
        device_hash = ""
    if not device_hash:
        # Bez identity zařízení nemá upload komu patřit. Nezapisuje se žádný
        # stav — příště to může vyjít (R2: selhání se neperzistuje).
        _log("device_id nedostupné → upload se nespouští", xbmc.LOGWARNING)
        return RESULT_NO_DEVICE_ID

    state = _load_state()
    if log_pull_id and state.get("last_done_pull_id") == log_pull_id:
        return RESULT_ALREADY_DONE

    # Meziprocesový claim: `/auth` se volá 2× při každém otevření root menu
    # (známý jev), takže bez guardu by se upload rozjel dvakrát během pár sekund.
    # `claim` vrací token, který `release` vyžaduje — bez něj by šlo shodit cizí
    # (novější) claim.
    guard_token = _guard.claim(GUARD_KEY, GUARD_TTL_S)
    if not guard_token:
        return RESULT_BUSY
    try:
        consent = _consent_granted(state, interactive=interactive)
        if consent is not True:
            _report_decline(log_pull_id, device_hash)
            return RESULT_DECLINED

        # Φ2 (29.09.2026): ruční odeslání z menu nemá kolečko Kodi — čtení 6 MiB logu, redakce a upload
        # po částech byly desítky sekund ticha. Běh ze služby (neinteraktivní) zůstává bez UI.
        import contextlib
        import richmovie_feedback as _fb
        with (_fb.working("Odesílám diagnostiku…") if interactive else contextlib.nullcontext()):
            parts, meta = _build_payload()
            if not parts:
                _log("v logu nezbylo nic k odeslání", xbmc.LOGINFO)
                return RESULT_NO_LOG

            ok = _send_parts(parts, meta, log_pull_id, device_hash,
                             guard_token=guard_token)
        if not ok:
            # Příznak na serveru zůstává → zkusí se při dalším startu.
            return RESULT_FAILED

        # Marker AŽ po potvrzeném odeslání všech částí (All-or-Nothing).
        if log_pull_id:
            state["last_done_pull_id"] = log_pull_id
        state["schema_version"] = STATE_SCHEMA_VERSION
        state["last_done_ts"] = int(time.time())
        _save_state(state)
        _log("diagnostika odeslána (%d částí, %d/%d řádků)"
             % (len(parts), meta.get("lines_kept", 0), meta.get("lines_total", 0)),
             xbmc.LOGINFO)
        return RESULT_DONE
    except RedactionFailed as exc:
        # Nahlas: znamená to, že diagnostika je dočasně nepoužitelná, a je lepší
        # to vědět, než se divit, proč log nikdy nedorazil.
        _log("REDAKCE SELHALA → neodesílám nic: %s" % (exc,), xbmc.LOGERROR)
        return RESULT_FAILED
    except Exception as exc:
        _log("run_pull selhalo: %r" % (exc,), xbmc.LOGWARNING)
        return RESULT_FAILED
    finally:
        try:
            _guard.release(GUARD_KEY, guard_token)
        except Exception as _rel_exc:
            # Guard má TTL, takže se uvolní i sám — ale tichý neúspěch by při
            # ladění „proč se upload nespustil" stál hodiny.
            _log("guard release selhal: %r" % (_rel_exc,), xbmc.LOGWARNING)


def _build_payload() -> Tuple[List[bytes], Dict[str, Any]]:
    """Přečte konce logů, zrediguje je a zabalí do samostatně gzipovaných částí."""
    chunks: List[str] = []
    lines_total = 0
    rotated = False
    for filename in LOG_FILENAMES:
        lines, meta = read_tail(filename)
        if not lines:
            continue
        rotated = rotated or bool(meta.get("rotated"))
        lines_total += len(lines)
        # Hlavička výřezu říká, zda jde o celý soubor, nebo jen jeho konec.
        skipped = int(meta.get("truncated_from_bytes") or 0)
        chunks.append("===== %s (%d radku%s) =====" % (
            filename, len(lines),
            (", preskoceno %d B ze zacatku" % skipped) if skipped else ", cely soubor"))
        chunks.extend(lines)

    if not chunks:
        return [], {"lines_kept": 0, "lines_total": 0, "rotated": rotated}

    # `RedactionFailed` se ZÁMĚRNĚ nechytá — propadne do `run_pull`, kde skončí
    # jako RESULT_FAILED. Neodeslat nic je správná reakce; požadavek na serveru
    # zůstane a zkusí se znovu, až bude redakce funkční.
    text = redact("\n".join(chunks)) + "\n"
    parts = pack_parts(text)
    meta = {"lines_kept": lines_total, "lines_total": lines_total,
            "rotated": rotated, "bytes_gzip": sum(len(p) for p in parts)}

    if len(parts) > MAX_PARTS:
        # Radši pošli konec (nejčerstvější dění) než nic. Gate by víc částí
        # stejně odmítl — strop je i v DB.
        parts = parts[-MAX_PARTS:]
        meta["parts_dropped"] = True
        # `lines_kept` musí odpovídat tomu, co skutečně odchází (cross-check 09.09.2026 F3).
        meta["lines_kept"] = sum(gzip.decompress(p).count(b"\n") for p in parts)
        _log("výběr přesáhl %d částí → odesílám jen konec" % MAX_PARTS,
             xbmc.LOGWARNING)
    return parts, meta


def _send_parts(parts: List[bytes], meta: Dict[str, Any],
                log_pull_id: str, device_hash: str,
                guard_token: str = "") -> bool:
    """Odešle části. True jen když prošly VŠECHNY.

    Guard se po každé části PRODLUŽUJE. Profil `bulk` má rozpočet 50–75 s na
    jeden pokus, takže 12 částí na pomalé lince může běžet déle než 5minutové
    TTL zámku — ten by mezitím vypršel, druhý běh by si ho zabral a nahrávaly
    by se dva uploady současně. TTL je signál živosti, ne stopky.
    (Nalezeno předdeployovým auditem 27.08.2026.)
    """
    import richmovie_http as _rm_http
    import richmovie_gate_transport as _gt
    import richmovie_guard as _guard

    profile = _rm_http.profile_bulk()
    total = len(parts)
    for index, part in enumerate(parts, start=1):
        if guard_token:
            try:
                # `renew` vrací False, když claim mezitím převzal někdo jiný.
                # Pokračovat by znamenalo dva souběžné uploady téhož požadavku —
                # proto se práce ukončí a příznak na serveru zůstane (zkusí se
                # znovu). R2: nic se neoznačí jako hotové.
                if not _guard.renew(GUARD_KEY, guard_token, GUARD_TTL_S):
                    _log("guard převzal jiný proces → končím upload u části %d/%d"
                         % (index, total), xbmc.LOGWARNING)
                    return False
            except Exception as _rn_exc:
                _log("guard renew selhal: %r" % (_rn_exc,), xbmc.LOGWARNING)
        headers = {
            "Content-Type": "application/gzip",
            "User-Agent": "RichMovie/%s (+plugin.video.richmovie)" % _addon_version(),
            "X-Device-Hash": device_hash,
            "X-Log-Pull-Id": log_pull_id or "",
            "X-Part": str(index),
            "X-Parts-Total": str(total),
            "X-Filename": "kodi.log",
            "X-Sha256": hashlib.sha256(part).hexdigest(),
            "X-Lines-Kept": str(meta.get("lines_kept", 0)),
            "X-Lines-Total": str(meta.get("lines_total", 0)),
            "X-Addon-Version": _addon_version(),
            "X-Platform": _platform(),
        }
        # Plnou identitu přiložíme, JEN když je po ruce — upload na ní nestojí.
        try:
            username, proof = _gt.get_identity()
            if username and proof:
                headers["X-WS-Username"] = username
                headers["X-WS-Proof"] = proof
        except Exception:
            pass

        try:
            # `idempotent=True` je tu DOLOŽENÉ, ne pohodlné: Gate má
            # UNIQUE (user_id, device_hash, log_pull_id, part) + `ON CONFLICT
            # DO NOTHING`, takže zopakovaná část nevyrobí duplicitní řádek.
            # Bez té UNIQUE by tady musela být False (viz kritérium zařazení
            # v `richmovie_gate_transport._IDEMPOTENT_POST_PATHS`).
            status, body, _hdrs = _rm_http.request(
                "%s/v1/diag/kodi_log" % _gt.GATE_URL,
                method="POST", headers=headers, data=part,
                profile=profile, idempotent=True, tag="diag_upload",
            )
        except Exception as exc:
            _log("část %d/%d neodeslána: %r" % (index, total, exc), xbmc.LOGWARNING)
            return False
        if status not in (200, 202):
            _log("část %d/%d odmítnuta Gate (HTTP %s)" % (index, total, status),
                 xbmc.LOGWARNING)
            return False
    return True


def _report_decline(log_pull_id: str, device_hash: str) -> None:
    """Dá serveru vědět, že uživatel odmítl — ať admin nečeká naslepo."""
    if not log_pull_id:
        return
    try:
        import richmovie_http as _rm_http
        import richmovie_gate_transport as _gt
        # `idempotent=True`: endpoint jen nastaví příznak na FALSE a stav na
        # `declined` — poslední zápis vyhrává, opakování nic nezdvojí.
        _rm_http.request(
            "%s/v1/diag/decline" % _gt.GATE_URL,
            method="POST",
            headers={"X-Device-Hash": device_hash, "X-Log-Pull-Id": log_pull_id,
                     "User-Agent": "RichMovie/%s (+plugin.video.richmovie)"
                                   % _addon_version()},
            data=b"",
            profile=_rm_http.profile_background(), idempotent=True,
            tag="diag_decline",
        )
    except Exception as exc:
        # Best-effort: neúspěch znamená jen to, že admin uvidí `pending` místo
        # `declined` (a po 48 h `expired`). Tiše ale ne — jinak by se ta drobná
        # nekonzistence v dashboardu nedala vysvětlit.
        _log("hlášení odmítnutí neprošlo: %r" % (exc,), xbmc.LOGWARNING)


def _addon_version() -> str:
    try:
        import xbmcaddon
        return xbmcaddon.Addon(_rm_settings.ADDON_ID).getAddonInfo("version") or "dev"
    except Exception:
        return "dev"


def _platform() -> str:
    try:
        import richmovie_gate_transport as _gt
        return _gt.detect_platform()
    except Exception:
        return "unknown"


def start_if_requested() -> str:
    """Zavolat po úspěšném `gate_auth`. Sám si zjistí, jestli je co dělat."""
    try:
        import richmovie_gate as _gate
        requested, pull_id = _gate.get_log_pull_request()
        if not requested or not pull_id:
            return RESULT_NOTHING_REQUESTED
        return run_pull(pull_id, interactive=False)
    except Exception as exc:
        _log("start_if_requested selhalo: %r" % (exc,), xbmc.LOGWARNING)
        return RESULT_FAILED
