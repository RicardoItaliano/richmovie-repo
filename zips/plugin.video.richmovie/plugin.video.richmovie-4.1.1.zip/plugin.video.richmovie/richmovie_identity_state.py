# -*- coding: utf-8 -*-
"""
RichMovie — SSOT stavu identity vůči Gate (3.5.118, 21.08.2026).

PROČ TŘETÍ STAVOVÝ MODUL
------------------------
Addon už má dvě „jedno místo pro jeden stav" vrstvy: `richmovie_http` (retry)
a `richmovie_netstate` (konektivita ONLINE/DEGRADED/OFFLINE). Incident gunžik
21.08.2026 ukázal třetí doménu, kterou ani jedna z nich z principu nevidí:

    HTTP 403 z Gate = „síť je v pořádku, server běží, ale ty nejsi autorizovaný".

`richmovie_http.classify()` řadí 403 mezi trvalé chyby a `request()` ho do
netstate hlásí jako ÚSPĚCH (spojení fungovalo — správně). Netstate tedy nikdy
nepřepne do OFFLINE a smyčka na pozadí (instalátor kolekcí) vypálila 2629
requestů, na každý dostala 403 a každou položku si uložila jako „neexistuje".

Tenhle modul drží stav identity: UNKNOWN → AUTHENTICATED / REJECTED. Kdo dělá
práci na pozadí proti `/v1/*`, ptá se `allow_gate_request()` a při REJECTED
nic neposílá. Jeden autoritativní 403 je důkaz — žádné počítání „N po sobě".

CO JE AUTORITATIVNÍ ZAMÍTNUTÍ (a co ne)
---------------------------------------
Do REJECTED přepíná JEN odpověď 401/403 s JSON tělem, ve kterém Gate vrací jeden
ze známých kódů (`_REJECT_CODES`). Oba tvary obálky Gate:

    /auth (routes/api.py):   {"status": "error", "error": "proof_mismatch"}
    /v1/* (tmdb/router.py):  {"status": "error", "error": {"code": "proof_mismatch", …}}

Co REJECTED NESMÍ vyvolat:
  • 403 s HTML tělem — Cloudflare Bot Fight Mode (`richmovie_http.py`, UA guard).
    Při CF incidentu by se jinak „odhlásilo" všech 16 uživatelů najednou.
  • 403 na request, který identitu vůbec neposlal (`identity_sent=False`) —
    není co zamítat; to je stav „bez přihlášení", ne „zamítnut".
  • 429, 5xx, transport — to jsou domény `richmovie_http` / `netstate`.

ZOTAVENÍ
--------
Jediná cesta z REJECTED je důkaz opaku: úspěšný `/auth` (`note_authenticated`)
nebo 200 na požadavek, který identitu nesl (`observe_gate_response`). Žádný
timer — identita se sama neopraví, opraví ji uživatel (nové heslo) a Gate.
`/auth` proto NIKDY nepodléhá fail-fastu (`allow_gate_request` se na něj neptá).

ÚLOŽIŠTĚ
--------
`Window(10000)` přes `richmovie_winprops` (každá invokace pluginu = nový
interpret; stav musí přežít mezi plugin procesy a službami v rámci jedné Kodi
session). Po restartu Kodi začíná UNKNOWN — to je správně, `/auth` běží při
prvním otevření addonu.

Python 3.8 (Kodi runtime) — typy jen v komentářích.
"""
from __future__ import annotations


import json
import threading
import time
from typing import Any, Dict, Optional, Tuple

try:
    import xbmc  # type: ignore
except Exception:  # pragma: no cover
    xbmc = None  # type: ignore

from richmovie_winprops import clear_prop as _clear_prop
from richmovie_winprops import get_prop as _get_prop
from richmovie_winprops import set_prop as _set_prop

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.identity", "RichMovie/Identity")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):
        # type: (str, int, Optional[Dict[str, Any]]) -> None
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/Identity] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Stavy
# --------------------------------------------------------------------------- #
STATE_UNKNOWN = "unknown"              # v této Kodi session ještě neproběhl /auth
STATE_AUTHENTICATED = "authenticated"  # Gate (nebo platná lease) identitu potvrdil
STATE_REJECTED = "rejected"            # dostupný Gate identitu autoritativně odmítl

# Zdroje potvrzení — pro diagnostiku a pro rozhodnutí „smí běžet síťová práce?"
SOURCE_ONLINE = "online"   # čerstvá 200 z /auth
SOURCE_LEASE = "lease"     # Gate nedostupný, lease ≤72 h platí
SOURCE_GRACE = "grace"     # Gate nedostupný, offline-grace ≤30 dní
SOURCE_GATE_200 = "gate_200"  # 200 na identitu nesoucí /v1/* request (důkaz opaku)
SOURCE_LEASE_FIRST = "lease_first"  # Φ3 D5: menu z platné lease online ověření, /auth běží na pozadí

# Kódy, kterými Gate autoritativně odmítá IDENTITU. Cokoli jiného (bad_slug,
# path_not_allowed, http_403 bez JSON…) identitu nezpochybňuje.
_REJECT_CODES = frozenset((
    "not_authorized",   # routes/api.py: not_whitelisted / inactive / proof_mismatch
    "proof_mismatch",   # tmdb/router.py + ostatní /v1/* routery
    "proof_missing",
    "proof_required",   # routes/api.py: chybějící ws_proof
    "inactive",
))

# --------------------------------------------------------------------------- #
# Window(10000) properties
# --------------------------------------------------------------------------- #
_PROP_STATE = "richmovie.identity.state"
_PROP_SINCE = "richmovie.identity.since"
_PROP_SOURCE = "richmovie.identity.source"
_PROP_REASON = "richmovie.identity.reason"

# In-process zámek — Window properties nejsou atomické; tohle drží konzistenci
# aspoň uvnitř jednoho procesu (MI2 workery jedou v 5 vláknech).
_lock = threading.Lock()


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_identity_state.py
# get_state / state_since  (vytvořeno: 21.08.2026 23:10 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def get_state():
    # type: () -> str
    """Aktuální stav identity. Výchozí je UNKNOWN (ne REJECTED — pesimistický
    start by po každém restartu Kodi blokoval služby, dokud by plugin neproběhl)."""
    value = _get_prop(_PROP_STATE, STATE_UNKNOWN)
    if value in (STATE_UNKNOWN, STATE_AUTHENTICATED, STATE_REJECTED):
        return value
    return STATE_UNKNOWN


def state_since():
    # type: () -> float
    """Unixový čas vstupu do aktuálního stavu (0 = neznámo)."""
    try:
        return float(_get_prop(_PROP_SINCE, "0") or 0)
    except Exception:
        return 0.0


def is_authenticated():
    # type: () -> bool
    return get_state() == STATE_AUTHENTICATED


def is_rejected():
    # type: () -> bool
    return get_state() == STATE_REJECTED


def rejection_reason():
    # type: () -> str
    """Gate kód posledního zamítnutí ("" mimo REJECTED)."""
    return _get_prop(_PROP_REASON, "") if is_rejected() else ""


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_identity_state.py
# allow_gate_request  (vytvořeno: 21.08.2026 23:10 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def allow_gate_request():
    # type: () -> bool
    """Smí práce na pozadí poslat identitu nesoucí request na `/v1/*`?

    False ve dvou případech, které jsou pro Gate k nerozeznání (obojí skončí 403),
    ale pro addon znamenají různou věc:
      • REJECTED — Gate identitu odmítl; další request je jen hluk v logu.
      • bez identity — addon nemá Webshare údaje (čerstvá instalace před
        onboardingem); request by odešel bez hlaviček a dostal 403 „not_authorized".
        Přesně tohle byl proud 2629 requestů z incidentu gunžik.

    UNKNOWN s identitou vrací True — lease cache může být platná a `/auth` ještě
    v téhle session neproběhl (služba po bootu). Gate si to rozhodne sám a
    případný 403 nás přepne do REJECTED.

    `/auth` se touhle funkcí NIKDY neřídí (je to cesta zotavení).
    """
    if is_rejected():
        return False
    try:
        # Lazy import: gate_transport importuje tento modul (observe hook),
        # přímý import na úrovni modulu by byl cyklus.
        import richmovie_gate_transport as _gt
        return bool(_gt.has_identity())
    except Exception:
        # Bez transportní vrstvy nemáme jak identitu ověřit — neblokovat
        # (fail-open je tu bezpečný: Gate odmítne sám).
        return True


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_identity_state.py
# note_authenticated / note_rejected  (vytvořeno: 21.08.2026 23:10 CEST)
# ---------------------------------------------------------------------------- #
def note_authenticated(source=SOURCE_ONLINE):
    # type: (str) -> None
    """Zaznamená potvrzenou identitu. Volá `richmovie_gate.gate_auth` pro každý
    úspěšný výsledek (online / lease / grace) a `observe_gate_response` pro 200
    na identitu nesoucí request (důkaz opaku po REJECTED)."""
    src = str(source or SOURCE_ONLINE)
    with _lock:
        previous = get_state()
        _set_prop(_PROP_STATE, STATE_AUTHENTICATED)
        _set_prop(_PROP_SOURCE, src)
        _clear_prop(_PROP_REASON)
        if previous != STATE_AUTHENTICATED:
            _set_prop(_PROP_SINCE, str(time.time()))
            _log("IDENTITY_STATE %s -> %s source=%s" % (previous, STATE_AUTHENTICATED, src),
                 context={"from": previous, "to": STATE_AUTHENTICATED, "source": src})


def note_rejected(reason=""):
    # type: (str) -> None
    """Zaznamená autoritativní zamítnutí identity dostupným Gate.

    Volá se s Gate kódem (`proof_mismatch`, `not_authorized`, …). Nevolat pro
    transportní chyby ani pro 403 bez JSON — na to je `observe_gate_response`,
    které filtruje."""
    code = str(reason or "unspecified")
    with _lock:
        previous = get_state()
        _set_prop(_PROP_STATE, STATE_REJECTED)
        _set_prop(_PROP_REASON, code)
        _clear_prop(_PROP_SOURCE)
        if previous != STATE_REJECTED:
            _set_prop(_PROP_SINCE, str(time.time()))
            # WARNING: tohle je přesně ta událost, kterou chceme vidět v user_logs
            # na NASu (per device) — „proof_mismatch" v auth_logs je jen půlka obrazu.
            _log("IDENTITY_STATE %s -> %s reason=%s" % (previous, STATE_REJECTED, code),
                 2, context={"from": previous, "to": STATE_REJECTED, "reason": code})


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_identity_state.py
# extract_gate_error_code  (vytvořeno: 21.08.2026 23:10 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def extract_gate_error_code(body):
    # type: (Any) -> str
    """Vytáhne Gate chybový kód z těla odpovědi; "" když tam není.

    Přijímá bytes / str (syrové tělo) i už naparsovaný dict. Oba tvary obálky
    (viz docstring modulu). HTML, prázdné tělo, nevalidní JSON → "".
    """
    parsed = body
    if isinstance(body, (bytes, bytearray)):
        try:
            parsed = json.loads(bytes(body).decode("utf-8")) if body else None
        except Exception:
            return ""
    elif isinstance(body, str):
        try:
            parsed = json.loads(body) if body.strip() else None
        except Exception:
            return ""
    if not isinstance(parsed, dict):
        return ""
    err = parsed.get("error")
    if isinstance(err, str):
        return err.strip()
    if isinstance(err, dict):
        code = err.get("code")
        return str(code).strip() if isinstance(code, str) else ""
    return ""


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_identity_state.py
# observe_gate_response  (vytvořeno: 21.08.2026 23:10 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def observe_gate_response(status, body, identity_sent):
    # type: (Optional[int], Any, bool) -> str
    """Jediný hook pro transportní vrstvy (`gate_transport.post_json`,
    `tmdb_client._get_json`, bundle fetch). Vrací rozpoznaný Gate kód
    zamítnutí ("" když odpověď identitu nezpochybňuje).

    Pravidla (viz docstring modulu):
      • 401/403 + JSON + kód v `_REJECT_CODES` + `identity_sent` → REJECTED
      • 200 + `identity_sent` + aktuálně REJECTED → AUTHENTICATED (důkaz opaku)
      • vše ostatní → beze změny

    Nikdy nevyhazuje — volá se uvnitř transportu, kde výjimka = falešný výpadek.
    """
    try:
        if not identity_sent:
            return ""
        if status in (401, 403):
            code = extract_gate_error_code(body)
            if code in _REJECT_CODES:
                note_rejected(code)
                return code
            return ""
        if status == 200 and is_rejected():
            note_authenticated(SOURCE_GATE_200)
        return ""
    except Exception:
        return ""


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_identity_state.py
# user_message  (vytvořeno: 21.08.2026 23:10 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def user_message():
    # type: () -> Tuple[str, bool]
    """Česká hláška pro UI, když je identita zamítnutá. `(text, je_přechodná)`
    ve stejném tvaru jako `richmovie_helpers.net_error_message`, aby volající
    nemuseli rozlišovat zdroj. Technický kód patří do logu, ne na obrazovku."""
    reason = rejection_reason()
    if reason in ("proof_mismatch", "proof_missing", "proof_required"):
        text = ("Přihlášení k serveru RichMovie neplatí — nejspíš se změnilo heslo "
                "k Webshare. Otevři RichMovie znovu a přihlas se.")
    elif reason == "inactive":
        text = "Tvůj účet RichMovie je pozastavený. Ozvi se Richiemu."
    else:
        # `not_authorized` je na `/auth` souhrnný kód (routes/api.py) — kryje
        # špatné heslo i účet mimo whitelist. Hláška nesmí tvrdit jedno ani druhé.
        text = ("Server RichMovie odmítl přihlášení tohoto účtu — zkontroluj heslo "
                "k Webshare a otevři RichMovie znovu. Když to nepomůže, ozvi se Richiemu.")
    return text, False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_identity_state.py
# snapshot / reset  (vytvořeno: 21.08.2026 23:10 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def snapshot():
    # type: () -> Dict[str, Any]
    """Kompletní stav pro diagnostiku (SESSION_ENV, harness). Čte tytéž
    properties jako zbytek modulu — žádný paralelní zdroj pravdy."""
    since = state_since()
    return {
        "state": get_state(),
        "since": since,
        "age_s": round(time.time() - since, 1) if since else None,
        "source": _get_prop(_PROP_SOURCE, ""),
        "reason": _get_prop(_PROP_REASON, ""),
    }


def reset():
    # type: () -> None
    """Vrátí stav do UNKNOWN. Pro harness (mezi scénáři); v produkci se nevolá."""
    with _lock:
        _clear_prop(_PROP_STATE)
        _clear_prop(_PROP_SINCE)
        _clear_prop(_PROP_SOURCE)
        _clear_prop(_PROP_REASON)
