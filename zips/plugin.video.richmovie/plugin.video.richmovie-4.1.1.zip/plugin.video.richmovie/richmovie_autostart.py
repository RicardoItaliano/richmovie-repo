# -*- coding: utf-8 -*-
"""
RichMovie — spuštění RichMovie po zapnutí Kodi (per ZAŘÍZENÍ), noc 03.11.2026 (4.0.6, plán Φ4).

ZADÁNÍ (Richie 03.11.2026 20:14, doslova)
-----------------------------------------
„chci i možnost nastavit spuštění richmovie po startu kodi, většina lidí má v kodi jen richmovie, takže se je to po
aktualizaci zeptá, jestli chtějí po startu kodi automaticky spustit richmovie, ať se rozhodnou. Že pokud používají
v kodi i jiné doplňky, tak doporučujete tuto volbu neaktivovat. Toto bude per zařízení, ne per účet ani per profil.“

PER ZAŘÍZENÍ = nastavení doplňku (`autostart_richmovie`, `settings.xml` kategorie „Zařízení“): Kodi ho drží pro jednu
instalaci, nesynchronizuje se s Gate ani s profilem. Gate volbu jen zobrazí správci (`/status`, mig 0044).

JEDNA OTÁZKA (`ask_once`) = krok uvítací sekvence `autostart` (`richmovie_onboarding.STEPS`, před profilem). Po
odpovědi `autostart_asked = true` → už nikdy, změna jen v Nastavení.

SLUŽBA (`run_service`) otevře RichMovie JEN když (čisté rozhodnutí `decide`, D4 plánu):
    • je to zapnuté,
    • Kodi právě nastartovalo (`richmovie_log_archive.kodi_started_at`, okno `KODI_START_WINDOW_S`) — služba
      restartovaná aktualizací doplňku za běhu Kodi NIKDY nenaviguje (divák může být v jiném doplňku),
    • je vidět Domů, není otevřený dialog a nic nehraje (`richmovie_playback_dispatch.player_present`, i pauza),
    • RichMovie už není otevřený a v tomto běhu Kodi se to ještě nezkoušelo (Window prop).
Divák, který mezitím odejde z Domů jinam, má přednost — služba to vzdá (`WAIT_HOME_S`).

Python 3.8 kompat; čistá logika bez Kodi (harness scénář 95).
"""
from __future__ import annotations

import time
from typing import Optional

try:
    import xbmc  # type: ignore
except Exception:  # pragma: no cover — harness
    xbmc = None  # type: ignore

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.autostart", "RichMovie/Autostart")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):  # type: ignore
        pass


SETTING_ENABLED = "autostart_richmovie"
SETTING_ASKED = "autostart_asked"
KODI_START_WINDOW_S = 180.0      # služba nastartovaná později než 3 min po Kodi = aktualizace za běhu → nic
WAIT_HOME_S = 60.0               # jak dlouho čekat, než se ukáže Domů (načítání skinu, výběr profilu Kodi)
TICK_S = 0.5
PROP_DONE = "richmovie.autostart.done"   # Window prop: v tomto běhu Kodi už rozhodnuto
LAUNCH_BUILTIN = "ActivateWindow(Videos,plugin://plugin.video.richmovie/,return)"
ADDON_ID = "plugin.video.richmovie"

LAUNCH = "launch"
WAIT = "wait"
SKIP_DISABLED = "skip:disabled"
SKIP_DONE = "skip:done"
SKIP_LATE = "skip:kodi_running"      # Kodi neběží chvíli (aktualizace doplňku za běhu) nebo start neznámý
SKIP_PLAYING = "skip:playing"
SKIP_OPEN = "skip:already_open"
SKIP_AWAY = "skip:viewer_elsewhere"

ASK_HEADING = "Otevírat RichMovie hned po zapnutí Kodi?"
ASK_TEXT = ("Většina z vás má v Kodi jen RichMovie. Mám ho po zapnutí Kodi rovnou otevřít?\n\n"
            "Pokud v Kodi používáte i jiné doplňky, doporučujeme nechat vypnuté.\n"
            "Změníte to kdykoli v Nastavení RichMovie → Zařízení.")
ASK_YES = "Ano, otevírat"
ASK_NO = "Ne, díky"
TOAST_ON = "Hotovo – po zapnutí Kodi se RichMovie otevře sám."
TOAST_OFF = "Dobře – RichMovie se sám otevírat nebude."


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_autostart.py
# decide  (vytvořeno: 03.11.2026 21:45 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def decide(*, enabled: bool, done: bool, kodi_age_s: Optional[float], waited_s: float, home_active: bool,
           modal: bool, player: bool, richmovie_open: bool) -> str:
    """Čisté rozhodnutí jednoho tiku služby (D4). Pořadí = priorita důvodů."""
    if not enabled:
        return SKIP_DISABLED
    if done:
        return SKIP_DONE
    if kodi_age_s is None or kodi_age_s < -60.0 or kodi_age_s > KODI_START_WINDOW_S + WAIT_HOME_S:
        return SKIP_LATE
    if player:
        return SKIP_PLAYING
    if richmovie_open:
        return SKIP_OPEN
    if home_active and not modal:
        return LAUNCH
    if waited_s >= WAIT_HOME_S:
        return SKIP_AWAY
    return WAIT


def first_check_allowed(kodi_age_s: Optional[float]) -> bool:
    """Služba smí vůbec začít čekat jen hned po startu Kodi (okno `KODI_START_WINDOW_S`)."""
    return kodi_age_s is not None and -60.0 <= kodi_age_s <= KODI_START_WINDOW_S


# --------------------------------------------------------------------------- #
# Nastavení (per zařízení)
# --------------------------------------------------------------------------- #
def enabled() -> bool:
    try:
        import richmovie_settings as _s
        return bool(_s.get_bool(SETTING_ENABLED))
    except Exception:
        return False


def asked() -> bool:
    try:
        import richmovie_settings as _s
        return bool(_s.get_bool(SETTING_ASKED))
    except Exception:
        return True     # nečitelné nastavení = neptat se (nikdy neotravovat dvakrát)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_autostart.py
# ask_once  (vytvořeno: 03.11.2026 21:45 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def ask_once() -> Optional[bool]:
    """Krok uvítací sekvence `autostart`: jednou za život zařízení. Vrací volbu, nebo None (už se ptalo / chyba).
    `autostart_asked` se zapíše až po zápisu volby (All-or-Nothing: nezapsaná volba = zeptat se příště znovu)."""
    if asked():
        return None
    try:
        import xbmcgui  # type: ignore
        import richmovie_settings as _s
        from richmovie_helpers import notif as _notif
    except Exception:
        return None
    choice = bool(xbmcgui.Dialog().yesno(ASK_HEADING, ASK_TEXT, nolabel=ASK_NO, yeslabel=ASK_YES))
    if not _s.write_bool(SETTING_ENABLED, choice):
        _log("AUTOSTART_CHOICE nezapsána (%s) → zeptám se příště" % choice, 2)
        return None
    _s.write_bool(SETTING_ASKED, True)
    _log("AUTOSTART_CHOICE %s" % ("on" if choice else "off"), 1, context={"autostart": choice})
    try:
        _notif(TOAST_ON if choice else TOAST_OFF, xbmcgui.NOTIFICATION_INFO, None, "RichMovie")
    except Exception:
        pass
    return choice


# --------------------------------------------------------------------------- #
# Služba
# --------------------------------------------------------------------------- #
def _cond(expr: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(expr)) if xbmc is not None else False
    except Exception:
        return False


def _player_present() -> bool:
    """Existuje přehrávač (hraje i pauza)? JEDINÁ definice `richmovie_playback_dispatch.player_present` (lint 89);
    nečitelný stav = ano (radši neotevřít)."""
    try:
        import richmovie_playback_dispatch as _dispatch
        return bool(_dispatch.player_present(on_error=True))
    except Exception:
        return True


def _richmovie_open() -> bool:
    try:
        if xbmc is None:
            return False
        name = xbmc.getInfoLabel("Container.PluginName") or ""
        path = xbmc.getInfoLabel("Container.FolderPath") or ""
        return name == ADDON_ID or ("plugin://%s" % ADDON_ID) in path
    except Exception:
        return False


def proc_age_from(stat_text: str, uptime_text: str, clk_tck: float) -> Optional[float]:
    """Stáří procesu z Linuxového `/proc/self/stat` (22. pole = start v ticích od bootu) a `/proc/uptime`. Čistá funkce
    (harness). Obojí je monotonní čas od startu jádra — posun hodin po NTP ho nerozhodí (cross-check Argon P6: Android
    box bez RTC zapíše do hlavičky kodi.log čas před synchronizací a pak by se autostart nikdy nespustil)."""
    try:
        rest = stat_text[stat_text.rindex(")") + 2:].split()   # jméno procesu v závorce smí obsahovat mezery
        start_ticks = float(rest[19])                          # pole 22 = index 19 za „pid (comm) “
        uptime = float(uptime_text.split()[0])
        if clk_tck <= 0:
            return None
        age = uptime - start_ticks / clk_tck
        return age if age >= 0 else None
    except (ValueError, IndexError):
        return None


def _proc_age_s() -> Optional[float]:
    """Linux / Android: stáří procesu Kodi (Python služby běží uvnitř procesu Kodi). Jinde None."""
    try:
        import os
        with open("/proc/self/stat", encoding="utf-8", errors="replace") as fh:
            stat_text = fh.read()
        with open("/proc/uptime", encoding="utf-8", errors="replace") as fh:
            uptime_text = fh.read()
        return proc_age_from(stat_text, uptime_text, float(os.sysconf("SC_CLK_TCK")))
    except Exception:
        return None


def _kodi_age_s() -> Optional[float]:
    """Jak dlouho běží Kodi. Linux / Android z `/proc` (monotonní), jinde z hlavičky `kodi.log` (Windows a macOS mají
    hodiny reálného času, NTP je při startu neposouvá o desítky let)."""
    age = _proc_age_s()
    if age is not None:
        return age
    try:
        import richmovie_log_archive as _la
        started = _la.kodi_started_at()
    except Exception:
        started = None
    return None if started is None else (time.time() - float(started))


def _done_prop() -> bool:
    try:
        import richmovie_winprops as _wp
        return _wp.get_prop(PROP_DONE, "") == "1"
    except Exception:
        return False


def _mark_done(outcome: str) -> None:
    try:
        import richmovie_winprops as _wp
        _wp.set_prop(PROP_DONE, "1")
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_autostart.py
# run_service  (vytvořeno: 03.11.2026 21:45 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def run_service(monitor) -> str:
    """Tělo vlákna služby (jednou za start služby). Čeká nejvýš `WAIT_HOME_S` (abort-safe) a vrací výsledek."""
    if not enabled():
        return SKIP_DISABLED
    if _done_prop():
        return SKIP_DONE
    age = _kodi_age_s()
    if not first_check_allowed(age):
        _mark_done(SKIP_LATE)
        _log("AUTOSTART skip: Kodi neběží chvíli (start před %s s) — služba nastartovala za běhu Kodi"
             % (("%.0f" % age) if age is not None else "?"), 1)
        return SKIP_LATE
    started = time.monotonic()
    while True:
        outcome = decide(enabled=enabled(), done=_done_prop(), kodi_age_s=_kodi_age_s(),
                         waited_s=time.monotonic() - started, home_active=_cond("Window.IsActive(home)"),
                         modal=_cond("System.HasActiveModalDialog"), player=_player_present(),
                         richmovie_open=_richmovie_open())
        if outcome == LAUNCH:
            _mark_done(outcome)
            _log("AUTOSTART launch (Kodi běží %.0f s, čekáno %.1f s)" % (_kodi_age_s() or -1,
                                                                        time.monotonic() - started), 1)
            try:
                xbmc.executebuiltin(LAUNCH_BUILTIN)
            except Exception as exc:
                _log("AUTOSTART launch selhal: %r" % (exc,), 2)
            return outcome
        if outcome != WAIT:
            _mark_done(outcome)
            _log("AUTOSTART %s" % outcome, 1)
            return outcome
        try:
            if monitor.waitForAbort(TICK_S):
                return "abort"
        except Exception:
            return "abort"
