# -*- coding: utf-8 -*-
"""
richmovie_warm.py — TMDb warm-up jako vlákno běžící služby (3.5.130)
====================================================================
PROČ (dluh z 3.5.118, ověřeno 21.08.2026)
------------------------------------------
`service_warm.py` byl druhý `xbmc.service` extension point doplňku a Kodi spouští
jen JEDEN per addon → warm-up TMDb (Trendy/TOP/žánry + enrich filmů) fakticky
nikdy neběžel (changelog 3.4.14 to zjistil u telemetrie a draineru; ty se
přesunuly do `service_nextup`, warm-up ne). Tenhle modul je totéž jako
`_warm_tmdb` ze `service_warm.py`, ale jako vlákno spouštěné z `service_nextup`.

KONTRAKT
--------
• Trigger = soubor `tmdb_warm_trigger.json` (`{"ts": <epoch>}`), který píše
  plugin při otevření root menu (`plugin._root`). Stav běhů = `tmdb_warm_state.json`
  (`last_seen_ts`, `last_run_started`, `last_run_done`).
• Brzdy (nové oproti službě z 2025 — incident TMDb 429 12.07.2026: Gate limiter
  je PER ÚČET 600/h a Richie má 8 zařízení na jednom účtu):
    – nejvýš jeden běh za `MIN_RUN_INTERVAL_S` (12 h) na zařízení,
    – jen když je `richmovie_netstate` ONLINE a identita vůči Gate není REJECTED,
    – jen když TMDb klient nemá aktivní 429 cooldown (`TMDb._RL_COOLDOWN_UNTIL`),
    – enrich filmů s yieldem přes `Monitor.waitForAbort` (žádný `time.sleep`).
• Vlákno je non-daemon s abort-checkem v každém kroku (Kodi 5s kill okno);
  služba ho startuje po bootu, smyčka čeká přes `Monitor.waitForAbort`.
• Best-effort: chyba se zaloguje, nikdy neshodí službu; žádné dialogy.
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any, Optional

import xbmc
import richmovie_activity as _activity  # Φ4 (29.09.2026): pozadí ustoupí, když uživatel kliká
import xbmcaddon
import xbmcvfs

import richmovie_atomic as _atomic
from richmovie_settings import get_tmdb_api_key
from tmdb_client import TMDb

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.warm", "RichMovie/Warm")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):
        try:
            xbmc.log("[RichMovie/Warm] %s" % msg, level)
        except Exception:
            pass

_LOGDEBUG = getattr(xbmc, "LOGDEBUG", 0)
_LOGINFO = getattr(xbmc, "LOGINFO", 1)
_LOGWARNING = getattr(xbmc, "LOGWARNING", 2)

# ---------------------------------- KONSTANTY ---------------------------------- #
ADDON_ID = "plugin.video.richmovie"
TRIGGER_FILE = "tmdb_warm_trigger.json"
STATE_FILE = "tmdb_warm_state.json"
MOVIE_LIMIT = 40
TV_LIMIT = 40
MIN_RUN_INTERVAL_S = 12 * 3600      # brzda per zařízení (TMDb limiter je per účet)
# Strop enrich volání na jeden běh (Pro PB8): 80 unikátních filmů × 8 zařízení
# na účtu = 640 req/12 h proti limitu 600/h při souběžném startu; 20 = první
# obrazovka Trendy/TOP, zbytek se doplní lazy při prohlížení.
# Φ6 (29.09.2026): obohacení jde JEDNÍM hromadným dotazem (`TMDb.movie_enrich_many`), strop zůstává —
# Gate za něj stahuje z TMDb každý chybějící film zvlášť.
ENRICH_LIMIT = 20
POLL_INTERVAL_S = 30.0              # jak často se kouká na trigger
BOOT_GRACE_S = 60.0                 # po startu Kodi nechat síť/službu naběhnout


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_warm.py
# _profile_dir  (vytvořeno: 03.09.2026 00:40 CEST, Europe/Prague – 3.5.130, port ze service_warm)
# ---------------------------------------------------------------------------- #
def _profile_dir() -> Path:
    try:
        p = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    except Exception:
        p = os.path.join(os.path.expanduser("~"), ADDON_ID)
    return Path(p)


def _json_load(path: Path) -> dict:
    data, _state = _atomic.read_json(str(path), None, name=path.name, expected_type=dict)
    return data if isinstance(data, dict) else {}


def _json_save(path: Path, data: dict) -> bool:
    return bool(_atomic.write_json(str(path), data, indent=1))


def read_trigger_ts(trigger_path: Path) -> int:
    try:
        return int(_json_load(trigger_path).get("ts") or 0)
    except (TypeError, ValueError):
        return 0


def run_due(trigger_ts: int, state: dict, now: Optional[float] = None) -> bool:
    """Čistá logika: má běh smysl? Trigger novější než poslední zpracovaný
    a od posledního běhu uplynulo aspoň MIN_RUN_INTERVAL_S (testováno v harnessu)."""
    now = time.time() if now is None else float(now)
    try:
        last_seen = int(state.get("last_seen_ts") or 0)
        last_run = int(state.get("last_run_started") or 0)
    except (TypeError, ValueError):
        last_seen, last_run = 0, 0
    if not trigger_ts or trigger_ts <= last_seen:
        return False
    return (now - last_run) >= MIN_RUN_INTERVAL_S


def _network_ok() -> bool:
    """ONLINE podle netstate a identita vůči Gate není zamítnutá — jinak by warm
    jen množil fail-fast chyby (R2: bez důkazu nic neperzistovat, tady nic nevolat)."""
    try:
        import richmovie_netstate as _ns
        if _ns.is_offline():
            return False
    except Exception:
        pass
    try:
        import richmovie_identity_state as _ident
        if _ident.is_rejected():
            return False
    except Exception:
        pass
    return True


def _make_tmdb_client(profile_dir: Path) -> Optional[TMDb]:
    tmdb_key = get_tmdb_api_key()   # SSOT 3.5.69: Gate fallback, uživatel klíč nezadává
    if not tmdb_key:
        _log("TMDb API key není k dispozici → warm-up přeskočen", _LOGWARNING)
        return None
    try:
        TMDb._CACHE_PATH = profile_dir / "tmdb_meta_cache.json"  # type: ignore[attr-defined]
    except Exception:
        pass

    def _tmdb_logger(code: str, *args: Any) -> None:
        _log("%s: %s" % (code, " ".join(str(a) for a in args)), _LOGDEBUG)

    try:
        return TMDb(tmdb_key, lang="cs-CZ", logger=_tmdb_logger)
    except Exception as exc:
        _log("TMDb init error: %r" % (exc,), _LOGWARNING)
        return None


def _rate_limited(tmdb: TMDb) -> bool:
    """Aktivní 429 cooldown TMDb klienta (incident 12.07.2026) → nezačínat."""
    try:
        return float(getattr(tmdb, "_RL_COOLDOWN_UNTIL", 0.0) or 0.0) > time.time()
    except Exception:
        return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_warm.py
# warm_tmdb  (port `_warm_tmdb` ze service_warm.py z 23.12.2025; 3.5.130: yield přes Monitor)
# ---------------------------------------------------------------------------- #
def warm_tmdb(tmdb: TMDb, monitor: xbmc.Monitor) -> dict:
    """Best-effort warm-up kategorií + enrich filmů; respektuje abortRequested().
    Vrací statistiku pro log (počty; -1 = krok selhal)."""
    stats = {"trending": -1, "top": -1, "trending_tv": -1, "top_tv": -1,
             "genres": -1, "enriched": 0, "aborted": False}
    movie_ids: list = []

    def _abort() -> bool:
        return monitor.abortRequested()

    steps = (
        ("trending", lambda: tmdb.trending(limit=MOVIE_LIMIT), True),
        ("top", lambda: tmdb.top_rated(limit=MOVIE_LIMIT), True),
        ("trending_tv", lambda: tmdb.trending_tv(limit=TV_LIMIT), False),
        ("top_tv", lambda: tmdb.top_rated_tv(limit=TV_LIMIT), False),
        ("genres", lambda: tmdb.genres(), False),
    )
    for name, call, collect in steps:
        # Φ4: uživatel právě kliká → krok počká (sdílený GIL, audit A08 F6: warm-up běžel přes oba kliky
        # na Pokračovat při pádu 29.09. 12:59)
        if _abort() or not _activity.wait_while_busy(monitor):
            stats["aborted"] = True
            return stats
        try:
            items = call() or []
            stats[name] = len(items)
            if collect:
                for m in items:
                    try:
                        movie_ids.append(int(m.get("id") or 0))
                    except Exception:
                        pass
        except Exception as exc:
            _log("WARM %s error: %r" % (name, exc), _LOGWARNING)
        if _rate_limited(tmdb):
            _log("WARM: TMDb 429 cooldown aktivní → warm-up ukončen předčasně", _LOGWARNING)
            return stats

    uniq: list = []
    seen: set = set()
    for mid in movie_ids:
        if mid > 0 and mid not in seen:
            seen.add(mid)
            uniq.append(mid)
    uniq = uniq[:ENRICH_LIMIT]
    if not uniq:
        return stats
    if _abort() or not _activity.wait_while_busy(monitor):
        stats["aborted"] = True
        return stats
    if _rate_limited(tmdb):
        _log("WARM: TMDb 429 cooldown před enrich → konec", _LOGWARNING)
        return stats
    if not _network_ok():
        # Identita zamítnuta / síť pryč (Pro PB10): dotaz by skončil fail-fast chybou
        _log("WARM: offline/identita zamítnuta před enrich → konec", _LOGWARNING)
        return stats
    try:
        # Φ6 (D10): jeden hromadný dotaz místo `ENRICH_LIMIT` dotazů po jednom
        stats["enriched"] = len(tmdb.movie_enrich_many(uniq, region="CZ", fallback_region="US"))
    except Exception as exc:
        _log("WARM movie_enrich_many fail: %r" % (exc,), _LOGDEBUG)
    return stats


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_warm.py
# run_once  (vytvořeno: 03.09.2026 00:40 CEST, Europe/Prague – 3.5.130)
# ---------------------------------------------------------------------------- #
def run_once(monitor: xbmc.Monitor, *, force: bool = False) -> bool:
    """Jeden pokus: zkontroluje trigger, brzdy a případně provede warm-up.
    Vrací True, když běh proběhl (i částečně). Stav se zapisuje trvanlivě."""
    prof = _profile_dir()
    trigger_path = prof / TRIGGER_FILE
    state_path = prof / STATE_FILE
    state = _json_load(state_path)
    trig_ts = read_trigger_ts(trigger_path)
    if not force and not run_due(trig_ts, state):
        return False
    if not _network_ok():
        _log("WARM: offline nebo identita zamítnuta → odloženo", _LOGINFO)
        return False
    tmdb = _make_tmdb_client(prof)
    if tmdb is None:
        return False
    if _rate_limited(tmdb):
        _log("WARM: TMDb 429 cooldown aktivní → odloženo", _LOGINFO)
        return False
    state["last_run_started"] = int(time.time())
    _json_save(state_path, state)
    t0 = time.monotonic()
    stats = warm_tmdb(tmdb, monitor)
    if stats.get("aborted"):
        # Přerušený běh trigger NESPOTŘEBUJE (Pro PB7): `last_run_started` zůstává
        # → brzda 12 h platí, ale po ní se stejný trigger dokončí.
        _log("WARM aborted after %.1fs: %s" % (time.monotonic() - t0, stats), _LOGINFO)
        return True
    if not monitor.abortRequested():
        stats["tv_tips"] = warm_tv_tips(prof)
    if not monitor.abortRequested():
        # Φ3 (29.09.2026): velikost cache (text/pozadí/loga) se loguje tady — nejvýš 1× za 12 h,
        # mimo UI. Do 3.5.161 ji počítal root při KAŽDÉM otevření menu (0,6–2,5 s, audit A07 F4).
        try:
            tmdb.log_cache_footprint()
        except Exception as exc:
            _log("WARM cache footprint failed: %r" % (exc,), _LOGWARNING)
    state["last_seen_ts"] = trig_ts or int(time.time())
    state["last_run_done"] = int(time.time())
    _json_save(state_path, state)
    _log("WARM done in %.1fs: %s" % (time.monotonic() - t0, stats), _LOGINFO,
         context={"trigger_ts": trig_ts, "stats": stats})
    return True


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_warm.py
# warm_tv_tips  (vytvořeno: 05.09.2026 06:40 CEST, Europe/Prague – 3.5.131)
# ---------------------------------------------------------------------------- #
def warm_tv_tips(profile_dir: Path) -> int:
    """Doplní lokální cache ČSFD TV tipů (zdroj hlášek v dialogu hledání pro
    uživatele bez vlastních hlášek — `richmovie_search_tips`). Když je cache
    mladší než 24 h, neproběhne žádné HTTP. Best-effort: chyba = 0 a WARNING,
    warm-up jako celek se nepřeruší. Vrací počet tipů v cache."""
    try:
        import richmovie_csfd
        return int(richmovie_csfd.refresh_tv_tips_cache(profile_dir))
    except Exception as exc:
        _log("WARM tv_tips failed: %r" % (exc,), _LOGWARNING)
        return 0


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_warm.py
# start_worker  (vytvořeno: 03.09.2026 00:40 CEST, Europe/Prague – 3.5.130)
# ---------------------------------------------------------------------------- #
def start_worker(monitor: xbmc.Monitor) -> threading.Thread:
    """Spustí smyčku warm-upu jako non-daemon vlákno služby (abort-safe:
    každé čekání je `Monitor.waitForAbort`, běh kontroluje abort po každém kroku)."""

    def _loop() -> None:
        if monitor.waitForAbort(BOOT_GRACE_S):
            return
        while not monitor.abortRequested():
            try:
                run_once(monitor)
            except Exception as exc:
                _log("WARM loop error: %r" % (exc,), _LOGWARNING)
            if monitor.waitForAbort(POLL_INTERVAL_S):
                return

    thr = threading.Thread(target=_loop, name="RichMovie-Warm", daemon=False)
    thr.start()
    return thr
