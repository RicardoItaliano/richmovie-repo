# -*- coding: utf-8 -*-
"""
richmovie_account_state.py — SSOT stavu Webshare účtu (VIP) — stale-first (3.5.125)
=================================================================================

PROČ (audit 29.08.2026, nálezy F1/F2/F6)
----------------------------------------
Do 3.5.124 se stav VIP zjišťoval při KAŽDÉM vykreslení root menu — a to až
třikrát za sebou (`update_vip_status`, dotaz na `days_left`, znovu
`_update_vip_status`), blokujícím dotazem v UI vlákně s timeoutem 15 s. Když
Webshare mlčel, uživatel koukal 34 s na prázdnou obrazovku a pak ho doplněk
vyhodil z menu s toastem „Offline" — přestože Gate odpovídal a `netstate`
hlásil jen pomalý Webshare. Navíc se přechodný stav sítě zapsal do nastavení
jako DATA o účtu (`vip_active=0`), čímž se porušilo pravidlo R2.

KONTRAKT
--------
• Stav účtu je JSON soubor v addon_data (`account_state.json`), zapisovaný přes
  `richmovie_atomic` (trvanlivě), NE nastavení Kodi. Nastavení `vip_info` zůstává
  jen jako zobrazovací pole na stránce nastavení (prostý text, bez emoji).
• Vykreslení (plugin) stav JEN ČTE — nula síťových volání v UI cestě. Když je
  obnova na řadě, plugin ji VYŽÁDÁ Window property; provede ji služba
  (`service_nextup`) mimo 5s okno invokace pluginu a bez dialogů.
• Interval obnovy řídí STAV, ne pevné TTL (rozhodnutí Richie 30.08.2026):
      VIP aktivní, končí za > 1 den   → nejvýš 1× za 24 h
      VIP končí do 1 dne              → při každém otevření (okamžik, kdy člověk platí)
      Free / propadlé / bez záznamu   → při každém otevření (platbu poznat co nejdřív)
• R2: selhání obnovy (timeout, transport, 5xx) stav NEMĚNÍ — zůstane poslední
  známý se stářím. „Free" smí vzniknout JEN z autoritativní odpovědi Webshare.
• Konektivita má jeden zdroj pravdy (`richmovie_netstate`); tenhle modul si
  z jednoho timeoutu „offline" nikdy neodvozuje.

Python 3.8 (Kodi runtime). Čistá logika (`refresh_due`, `title`, `toast_text`)
bez Kodi závislostí — testovaná v `_tools/net_resilience_sim` (scénář 44).
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict, Optional, Tuple

try:
    import xbmc
    import xbmcvfs
except Exception:  # pragma: no cover — mimo Kodi
    xbmc = None  # type: ignore
    xbmcvfs = None  # type: ignore

import richmovie_atomic as _atomic
import richmovie_settings as _rm_settings
import richmovie_winprops as _winprops

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.account", "RichMovie/Account")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/Account] %s" % msg, level)
        except Exception:
            pass

_LOGINFO = getattr(xbmc, "LOGINFO", 1)
_LOGWARNING = getattr(xbmc, "LOGWARNING", 2)

# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
ADDON_ID = "plugin.video.richmovie"
STATE_FILE = "account_state.json"
SCHEMA_VERSION = 1

# Obnova při aktivním VIP: nejvýš jednou za tento interval.
ACTIVE_REFRESH_INTERVAL_S = 24 * 3600
# „Končí brzy" = méně než tolik dní; pak se obnovuje při každém otevření.
ENDING_SOON_DAYS = 1
# Po tomhle stáří se v titulku ukazuje čas posledního úspěšného stavu.
STALE_LABEL_AFTER_S = ACTIVE_REFRESH_INTERVAL_S

# Window property, kterou plugin žádá službu o obnovu (hodnota = důvod).
PROP_REFRESH_REQUEST = "richmovie.account.refresh"

# Důvody obnovy — jediné místo, kde jsou vyjmenované (log + harness).
REASON_NO_STATE = "no_state"
REASON_FREE = "free"
REASON_ENDING_SOON = "ending_soon"
REASON_ACTIVE_INTERVAL = "active_interval"
REASON_LOGIN = "login"
REASON_MANUAL = "manual"

# Výsledky `refresh_now()`.
OUTCOME_OK = "ok"
OUTCOME_UNCHANGED = "unchanged"
OUTCOME_FAILED = "failed"          # transport / timeout / 5xx → stav zachován (R2)
OUTCOME_NO_CREDENTIALS = "no_credentials"
OUTCOME_REJECTED = "rejected"      # Webshare autoritativně odmítl přihlášení
OUTCOME_THROTTLED = "throttled"    # brzda: poslední pokus je moc čerstvý

# Brzda obnovy (cross-check Pro 31.08., P2): Free/propadlý stav žádá obnovu při
# KAŽDÉM otevření menu — bez brzdy by rychlé klikání (a neúspěšné pokusy) bušily
# do Webshare API. Mezi dvěma POKUSY (i neúspěšnými) musí uplynout aspoň tohle.
# Drží se v paměti procesu služby — jediného místa, které obnovy provádí.
MIN_REFRESH_INTERVAL_S = 120
_last_refresh_attempt = {"ts": 0.0}

# 3.5.129 (incident PeterFM 02.09.2026): Webshare Free účet = `file_link` vrátí
# odkaz, ale ten servíruje HTML stránku (a Free má strop 100 kB/s) → Kodi hlásí
# „Přehrávání selhalo". Rozhodnutí „smí se Webshare stream vůbec přehrát" je
# JEDNO a bydlí tady; `_play`, výpis streamů i custom picker se ptají sem.
PLAY_BLOCK_WS_FREE = "ws_free"

# Přechod VIP → Free zjištěný službou čeká na JEDNORÁZOVÝ dialog v UI (plugin
# ho spotřebuje). Razítko žije ve VLASTNÍM souboru (`account_notice.json`), ne
# ve stavu účtu ani v nastavení Kodi: stav účtu zapisuje jen služba, razítko
# maže jen plugin → žádný read-modify-write souboj dvou procesů nad API daty
# (cross-check Pro 02.09.2026, PB3). Přežije restart, síť ho nikdy nepřepíše.
NOTICE_FILE = "account_notice.json"
KEY_VIP_LAPSE_NOTICE = "vip_lapse_pending"

# Texty pro uživatele — SSOT, žádné duplikáty v plugin.py / oknech.
FREE_BLOCK_HEADING = "Webshare VIP vypršel"
# Prefix položky výpisu streamů, kterou Free účet nepřehraje (legacy výpis i
# custom picker). Kodi značky, žádné emoji (legacy skiny bez emoji fontu
# ukazují čtverečky). Jedno místo pro oba UI (Fable audit 03.09.2026, F-05).
WS_BLOCKED_LABEL_PREFIX = "[COLOR FFE05050]VIP vypršel[/COLOR] · "


# ─────────────────────────────────────────────────────────────────────────────
#  ČISTÁ LOGIKA (bez Kodi)
# ─────────────────────────────────────────────────────────────────────────────
def normalize(info: Dict[str, Any], *, now: Optional[float] = None,
              source: str = "webshare") -> Dict[str, Any]:
    """Odpověď `WebshareClient.account_info()` → stav. Jediné místo, kde se
    tvar Webshare odpovědi překládá; zbytek addonu zná jen tenhle slovník."""
    now = time.time() if now is None else float(now)
    try:
        vip_days = int(info.get("vip_days") or 0)
    except (TypeError, ValueError):
        vip_days = 0
    return {
        "schema_version": SCHEMA_VERSION,
        "username": (info.get("username") or "").strip(),
        "vip": bool(info.get("vip")),
        "vip_days": vip_days,
        "vip_until": (info.get("vip_until") or "").strip(),
        "credit": _safe_int(info.get("credit")),
        "fetched_at": int(now),
        "source": source,
    }


def _safe_int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def is_valid(state: Any) -> bool:
    return (isinstance(state, dict)
            and int(state.get("schema_version") or 0) == SCHEMA_VERSION
            and isinstance(state.get("fetched_at"), int)
            and "vip" in state)


def days_left(state: Optional[Dict[str, Any]]) -> Optional[int]:
    if not is_valid(state) or not state.get("vip"):
        return None
    return int(state.get("vip_days") or 0)


def age_s(state: Optional[Dict[str, Any]], now: Optional[float] = None) -> Optional[float]:
    if not is_valid(state):
        return None
    now = time.time() if now is None else float(now)
    return max(0.0, now - float(state.get("fetched_at") or 0))


def refresh_due(state: Optional[Dict[str, Any]], now: Optional[float] = None) -> Tuple[bool, str]:
    """Má se stav obnovit? Vrací (ano/ne, důvod) — rozhoduje STAV, ne pevné TTL."""
    if not is_valid(state):
        return True, REASON_NO_STATE
    if not state.get("vip"):
        return True, REASON_FREE
    if int(state.get("vip_days") or 0) < ENDING_SOON_DAYS:
        return True, REASON_ENDING_SOON
    if (age_s(state, now) or 0.0) >= ACTIVE_REFRESH_INTERVAL_S:
        return True, REASON_ACTIVE_INTERVAL
    return False, ""


# Pole stavu účtu, která hlavní menu SKUTEČNĚ ukazuje: jméno a VIP/Free (štítek blokace přehrávání,
# `WS_BLOCKED_LABEL_PREFIX`). Počet dnů VIP (`vip_days`, `vip_until`) v menu vidět není — titulek
# `setPluginCategory` na konci `_root` přepíše `_header` — a mění se každý den, takže každá denní obnova
# účtu dřív překreslila menu: 141 ze 187 dvojitých rootů za 60 dní, 2× 15 min čekání (audit A07 F1).
VISIBLE_KEYS = ("username", "vip")


def changed(old: Optional[Dict[str, Any]], new: Optional[Dict[str, Any]]) -> bool:
    """Změnilo se něco, co je v hlavním menu vidět (`VISIBLE_KEYS`)? Dny ani `fetched_at` ne."""
    if not is_valid(old) or not is_valid(new):
        return True
    return any(old.get(k) != new.get(k) for k in VISIBLE_KEYS)


def _fmt_time(ts: float) -> str:
    try:
        return time.strftime("%H:%M", time.localtime(ts))
    except Exception:
        return "?"


def title(state: Optional[Dict[str, Any]], *, offline: bool = False,
          now: Optional[float] = None) -> str:
    """Titulek root menu (setPluginCategory). Offline = pilulka z netstate, ne
    z tohohle modulu — sem přichází jako vstup."""
    if offline:
        return "RichMovie (offline)"
    if not is_valid(state):
        return "RichMovie"
    stale = (age_s(state, now) or 0.0) >= STALE_LABEL_AFTER_S
    suffix = " – stav z %s" % _fmt_time(state.get("fetched_at") or 0) if stale else ""
    if state.get("vip"):
        return "RichMovie (VIP %d dní%s)" % (int(state.get("vip_days") or 0), suffix)
    return "RichMovie (Free%s)" % suffix


def toast_text(state: Optional[Dict[str, Any]]) -> str:
    """Text denního informačního toastu (a stránky nastavení). Prostý text —
    bez emoji: hodnota se zapisuje i do nastavení `vip_info` (nález F3)."""
    if not is_valid(state):
        return ""
    user = state.get("username") or ""
    if state.get("vip"):
        return "%s – VIP ještě %d dní (do %s)" % (
            user, int(state.get("vip_days") or 0), state.get("vip_until") or "?")
    return "%s – Free účet" % user


def playback_allowed(state: Optional[Dict[str, Any]], *, source: str = "webshare") -> Tuple[bool, str]:
    """Smí se stream z `source` přehrát? Vrací (ano/ne, důvod blokace nebo "").

    Blokuje se JEN z AUTORITATIVNÍHO stavu: platný záznam z Webshare `user_data`
    s `vip=False`. Neznámý / poškozený / chybějící stav = povolit (fail-open) —
    o odkazu pak rozhodne kontrola na zařízení (`richmovie_webshare.validate_stream_link`).
    Stáří stavu tu NEhraje roli: Free stav se obnovuje při každém otevření menu a
    R2 zaručuje, že „Free" nikdy nevzniklo z výpadku sítě.
    Fastshare a lokální soubory se Webshare účtu netýkají → vždy povoleno.
    """
    if (source or "webshare").strip().lower() != "webshare":
        return True, ""
    if not is_valid(state):
        return True, ""
    if state.get("vip"):
        return True, ""
    return False, PLAY_BLOCK_WS_FREE


def free_block_message(state: Optional[Dict[str, Any]]) -> Tuple[str, str]:
    """(nadpis, text) dialogu pro zablokované Webshare přehrání. Prostý text,
    bez znaků mimo BMP (Kodi fonty) a bez technických detailů."""
    user = (state or {}).get("username") or "" if is_valid(state) else ""
    who = " (%s)" % user if user else ""
    text = ("Webshare účet%s je Free – streamy z Webshare nejdou přehrát "
            "(Free má strop 100 kB/s a místo videa vrací stránku).\n"
            "Obnov VIP na webshare.cz, nebo vyber stream označený Fastshare." % who)
    return FREE_BLOCK_HEADING, text


def vip_lapse_pending(previous: Optional[Dict[str, Any]], state: Dict[str, Any],
                      already_pending: bool = False) -> bool:
    """Čistá logika přechodu VIP → Free: má po obnově čekat jednorázový dialog?
      • PŘEDCHOZÍ platný stav měl VIP a nový ho nemá → ano (přechod),
      • `already_pending` (nevyřízené razítko) se přenáší, dokud Free trvá,
      • nový stav s VIP ruší cokoli (dialog o vypršení by byl lež),
      • čerstvá instalace Free účtu (bez předchozího stavu) → ne, nic nevypršelo.
    """
    if state.get("vip"):
        return False
    if is_valid(previous) and previous.get("vip"):
        return True
    return bool(already_pending)


# ─────────────────────────────────────────────────────────────────────────────
#  PERSISTENCE
# ─────────────────────────────────────────────────────────────────────────────
def _state_path() -> str:
    if xbmcvfs is None:
        return os.path.join(os.path.expanduser("~"), STATE_FILE)
    profile = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    return os.path.join(profile, STATE_FILE)


def load() -> Optional[Dict[str, Any]]:
    """Poslední známý stav, nebo None. Poškozený soubor → karanténa + ERROR
    (richmovie_atomic) a None — čtení nikdy nevyhazuje."""
    data, _file_state = _atomic.read_json(_state_path(), None, name=STATE_FILE,
                                          expected_type=dict)
    return data if is_valid(data) else None


def save(state: Dict[str, Any]) -> bool:
    """Uloží stav (trvanlivě) a zrcadlí prostý text do nastavení `vip_info`
    (zobrazovací pole na stránce nastavení). Návrat = zápis stavu uspěl."""
    if not is_valid(state):
        return False
    ok = _atomic.write_json(_state_path(), state, indent=1)
    if ok:
        # Best-effort zrcadlo pro stránku nastavení; selhání hlásí richmovie_settings.
        _rm_settings.write("vip_info", toast_text(state))
    return ok


def _notice_path() -> str:
    return os.path.join(os.path.dirname(_state_path()), NOTICE_FILE)


def _load_notice() -> Dict[str, Any]:
    data, _file_state = _atomic.read_json(_notice_path(), None, name=NOTICE_FILE,
                                          expected_type=dict)
    return data if isinstance(data, dict) else {}


def notice_pending() -> bool:
    """Čeká nevyřízené razítko VIP → Free? (čte jen soubor razítka)"""
    return bool(_load_notice().get(KEY_VIP_LAPSE_NOTICE))


def set_vip_lapse_notice(state: Dict[str, Any]) -> bool:
    """Služba: zapíše razítko (idempotentně) + snímek účtu pro text dialogu."""
    payload = {
        KEY_VIP_LAPSE_NOTICE: True,
        "username": (state or {}).get("username") or "",
        "fetched_at": int((state or {}).get("fetched_at") or 0),
    }
    return _atomic.write_json(_notice_path(), payload, indent=1)


def clear_vip_lapse_notice() -> bool:
    """Zruší razítko (trvanlivě). Prázdný objekt místo mazání souboru — zápis
    přes `richmovie_atomic` je jediná cesta, kterou tenhle modul mění disk."""
    if not os.path.exists(_notice_path()):
        return True
    return _atomic.write_json(_notice_path(), {KEY_VIP_LAPSE_NOTICE: False}, indent=1)


def consume_vip_lapse_notice() -> Optional[Dict[str, Any]]:
    """Plugin (UI): je-li nevyřízené razítko přechodu VIP → Free, smaže ho
    (trvanlivě) a vrátí snímek účtu pro dialog; jinak None. Když se razítko
    nepodaří smazat, dialog se NEukáže — jinak by se opakoval při každém
    otevření menu. Sahá JEN na soubor razítka, nikdy na stav účtu (PB3)."""
    notice = _load_notice()
    if not notice.get(KEY_VIP_LAPSE_NOTICE):
        return None
    if not clear_vip_lapse_notice():
        _log("vip lapse notice: razítko se nepodařilo smazat → dialog odložen", _LOGWARNING)
        return None
    snapshot = {"schema_version": SCHEMA_VERSION, "vip": False,
                "username": notice.get("username") or "",
                "fetched_at": int(notice.get("fetched_at") or 0)}
    return snapshot


# ─────────────────────────────────────────────────────────────────────────────
#  ŽÁDOST O OBNOVU (plugin → služba přes Window property)
# ─────────────────────────────────────────────────────────────────────────────
def request_refresh(reason: str) -> None:
    """Plugin: požádej službu o obnovu. Idempotentní (druhá žádost přepíše důvod)."""
    try:
        _winprops.set_prop(PROP_REFRESH_REQUEST, reason or REASON_MANUAL)
    except Exception as exc:
        _log("request_refresh failed: %r" % (exc,), _LOGWARNING)


def consume_refresh_request() -> str:
    """Služba: vyzvedni a smaž žádost. "" = nic nečeká."""
    try:
        reason = (_winprops.get_prop(PROP_REFRESH_REQUEST, "") or "").strip()
        if reason:
            _winprops.clear_prop(PROP_REFRESH_REQUEST)
        return reason
    except Exception:
        return ""


# ─────────────────────────────────────────────────────────────────────────────
#  OBNOVA (běží ve službě — nikdy v UI cestě, nikdy s dialogem)
# ─────────────────────────────────────────────────────────────────────────────
def refresh_now(client: Any, *, reason: str = REASON_MANUAL,
                previous: Optional[Dict[str, Any]] = None) -> Tuple[Optional[Dict[str, Any]], str]:
    """Zeptá se Webshare na stav účtu a uloží ho. Vrací (stav, výsledek).

    `client` = `richmovie_webshare.WebshareClient` s tokenem. Expirovaný token
    → tichý login z uložených údajů (bez dialogu; ten patří jen pluginu) →
    jeden opakovaný dotaz. Jakékoli selhání = stav se NEMĚNÍ (R2).
    """
    from richmovie_webshare import APIError, TokenExpired  # lazy: webshare importuje settings

    previous = previous if previous is not None else load()

    # Brzda: mezi dvěma pokusy (i neúspěšnými) musí uplynout MIN_REFRESH_INTERVAL_S.
    # Značka se zapisuje PŘED pokusem — selhání tedy taky drží odstup (Pro P2).
    now = time.time()
    if now - float(_last_refresh_attempt["ts"]) < MIN_REFRESH_INTERVAL_S:
        return previous, OUTCOME_THROTTLED
    _last_refresh_attempt["ts"] = now

    try:
        info = client.account_info()
    except TokenExpired:
        outcome = _silent_relogin(client)
        if outcome != OUTCOME_OK:
            _log("refresh reason=%s: token expired, relogin=%s → state kept" % (reason, outcome),
                 _LOGWARNING, context={"reason": reason, "relogin": outcome})
            return previous, outcome
        try:
            info = client.account_info()
        except (APIError, TokenExpired) as exc:
            _log("refresh reason=%s failed after relogin: %s → state kept" % (reason, exc),
                 _LOGWARNING, context={"reason": reason})
            return previous, OUTCOME_FAILED
    except APIError as exc:
        _log("refresh reason=%s failed: %s → state kept" % (reason, exc), _LOGWARNING,
             context={"reason": reason, "age_s": age_s(previous)})
        return previous, OUTCOME_FAILED

    state = normalize(info)
    if not save(state):
        return previous, OUTCOME_FAILED
    # Razítko VIP → Free žije ve VLASTNÍM souboru (PB3): stav účtu už je uložený,
    # tady se jen rozhodne o dialogu. Selhání zápisu razítka stav nemění.
    was_pending = notice_pending()
    pending = vip_lapse_pending(previous, state, already_pending=was_pending)
    if pending and not was_pending:
        _log("VIP_LAPSED user=%s: účet přešel na Free → dialog čeká na otevření menu"
             % state["username"], _LOGWARNING,
             context={"reason": reason, "username": state["username"]})
    if pending:
        set_vip_lapse_notice(state)
    elif was_pending:
        clear_vip_lapse_notice()
    # Free → VIP: lokální MI2 markery `not_media` byly vlastností ÚČTU, ne souborů
    # → smazat, ať výpis dostane dabing/titulky/délku hned, ne po 7 dnech backoffu
    # (Fable audit 03.09.2026, F-06). Best-effort, stav účtu je už uložený.
    if state.get("vip") and is_valid(previous) and not previous.get("vip"):
        try:
            import richmovie_engine as _engine
            cleared = _engine.mi2_clear_fail_reason("not_media")
            _log("VIP_RENEWED user=%s: smazáno %d MI2 markerů not_media"
                 % (state["username"], cleared), _LOGINFO,
                 context={"username": state["username"], "cleared": cleared})
        except Exception as exc:
            _log("VIP_RENEWED: výmaz markerů not_media selhal: %r" % (exc,), _LOGWARNING)
    outcome = OUTCOME_OK if changed(previous, state) else OUTCOME_UNCHANGED
    _log("refresh reason=%s → %s vip=%s days=%d" % (
        reason, outcome, state["vip"], state["vip_days"]), _LOGINFO,
        context={"reason": reason, "outcome": outcome, "vip": state["vip"],
                 "vip_days": state["vip_days"], "username": state["username"]})
    return state, outcome


def _silent_relogin(client: Any) -> str:
    """Tichý login z uložených údajů. Nikdy neotevírá dialog."""
    from richmovie_webshare import APIError
    user = _rm_settings.get_ws_username() or ""
    pw = _rm_settings.get_ws_password() or ""
    if not user or not pw:
        return OUTCOME_NO_CREDENTIALS
    try:
        client.login(user, pw)
    except APIError as exc:
        # Rozhoduje KÓD odpovědi Webshare (`APIError.code`), ne text zprávy:
        # LOGIN_FATAL_* = autoritativní odmítnutí, cokoli jiného = selhání.
        return OUTCOME_REJECTED if exc.is_authoritative_login_failure else OUTCOME_FAILED
    except Exception:
        return OUTCOME_FAILED
    _rm_settings.set_ws_token(client.token or "")
    return OUTCOME_OK
