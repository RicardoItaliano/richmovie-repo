# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – tipy v dialogu hledání (SSOT výběru režimu, 3.5.131)
───────────────────────────────────────────────────────────────────────────────
Richie 05.09.2026: „Hlášky při hledání streamu chci zanechat jen těm, co mají
nastavené unikátní hlášky. U ostatních chci, ať se tam objevují ČSFD TV tipy
nějak náhodně, ale asi tam musíme zpomalit střídání hlášek — dvakrát tolik."

Režimy (rozhoduje `choose_mode`, jediné místo):
  • PERSONAL – existuje `resources/search_tips/<ws_username>.json` (bandog, gunzik):
               chování z 3.4.x beze změny — osobní + obecné hlášky 2:1, persistence
               `tip_state.json` (žádná hláška se neopakuje, dokud neproběhly všechny),
               střídání `TIP_SWITCH_S`.
  • CSFD     – všichni ostatní: náhodné ČSFD TV tipy z lokální cache
               (`richmovie_csfd.get_cached_tv_tips`, plní ji služba `richmovie_warm`),
               střídání `CSFD_TIP_SWITCH_S` = 2× pomalejší. **0 síťových volání** v cestě
               hledání — tip je jen text z disku.
  • DEFAULT  – záchranná síť: cache TV tipů neexistuje / je starší než
               `CSFD_TIPS_MAX_AGE_S` (čistá instalace offline) → obecné hlášky
               `default.json`, aby dialog nikdy nebyl prázdný.

Dřív byla logika sestavení rotátoru 3× zkopírovaná v plugin.py (film, MI2 wait,
seriál) — teď je jediný vstup `build_rotator()`.
═══════════════════════════════════════════════════════════════════════════════
"""
from __future__ import annotations

import os
import random
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

import xbmc

# ---------------------------------------------------------------------------
# Konstanty (SSOT intervalů)
# ---------------------------------------------------------------------------
TIP_SWITCH_S = 3.0                 # obecné/osobní hlášky (hodnota z 3.4.x)
CSFD_TIP_SWITCH_MULT = 2           # Richie: „jednou tak delší"
CSFD_TIP_SWITCH_S = TIP_SWITCH_S * CSFD_TIP_SWITCH_MULT
CSFD_TIPS_MAX_AGE_S = 7 * 24 * 3600   # stale cache TV tipů je pro hlášku v pořádku

MODE_PERSONAL = "personal"
MODE_CSFD = "csfd"
MODE_DEFAULT = "default"

TIPS_SUBDIR = os.path.join("resources", "search_tips")


def _log(msg: str, level: int = xbmc.LOGINFO) -> None:
    try:
        xbmc.log(f"[RichMovie][tips] {msg}", level)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Rozhodnutí o režimu (čistá funkce – testovatelná bez Kodi)
# ---------------------------------------------------------------------------
def personal_tips_path(addon_dir: str, ws_username: str) -> str:
    """Cesta k osobnímu souboru hlášek (`<username>.json`, malými písmeny)."""
    user = (ws_username or "").strip().lower()
    if not user:
        return ""
    return os.path.join(addon_dir, TIPS_SUBDIR, user + ".json")


def has_personal_tips(addon_dir: str, ws_username: str) -> bool:
    path = personal_tips_path(addon_dir, ws_username)
    return bool(path) and os.path.isfile(path)


def choose_mode(addon_dir: str, ws_username: str, csfd_tip_count: int) -> str:
    """PERSONAL má přednost (unikátní hlášky zůstávají), jinak CSFD, jinak DEFAULT."""
    if has_personal_tips(addon_dir, ws_username):
        return MODE_PERSONAL
    if csfd_tip_count > 0:
        return MODE_CSFD
    return MODE_DEFAULT


def csfd_tip_lines(tips: List[Dict[str, Any]], *, seed: Optional[int] = None) -> List[str]:
    """Náhodně seřazené, deduplikované textové řádky z ČSFD TV tipů (SSOT formát
    `richmovie_csfd.format_tip_line`). Prázdné/duplicitní řádky se vynechají."""
    import richmovie_csfd
    seen: set = set()
    lines: List[str] = []
    for tip in tips or []:
        try:
            line = richmovie_csfd.format_tip_line(tip)
        except Exception:
            continue
        if not line or line in seen:
            continue
        seen.add(line)
        lines.append(line)
    rnd = random.Random(seed if seed is not None else int(time.time() * 1000))
    rnd.shuffle(lines)
    return lines


# ---------------------------------------------------------------------------
# Sestavení rotátoru (jediný vstup pro plugin.py)
# ---------------------------------------------------------------------------
def build_rotator(
    addon_dir: str,
    ws_username: str,
    profile_dir: str,
    *,
    csfd_tips_loader: Optional[Callable[[], List[Dict[str, Any]]]] = None,
    seed: Optional[int] = None,
) -> Tuple[Any, str]:
    """Vrátí `(rotator, mode)`. Rotátor je `richmovie_engine._TipRotator`.

    `csfd_tips_loader` je jen pro testy (harness) — výchozí čte lokální cache TV
    tipů přes `richmovie_csfd.get_cached_tv_tips` (bez sítě).
    """
    from richmovie_engine import _TipRotator, _load_search_tips, _load_tip_persistent_state

    if has_personal_tips(addon_dir, ws_username):
        state = _load_tip_persistent_state(addon_dir, ws_username, profile_dir)
        rotator = _TipRotator([], switch_every=TIP_SWITCH_S, persistent_state=state)
        _log(f"mode={MODE_PERSONAL} user={ws_username} pool={state.get('pool_size', 0)} "
             f"switch={TIP_SWITCH_S}s", xbmc.LOGDEBUG)
        return rotator, MODE_PERSONAL

    tips: List[Dict[str, Any]] = []
    try:
        if csfd_tips_loader is not None:
            tips = list(csfd_tips_loader() or [])
        else:
            import richmovie_csfd
            tips = richmovie_csfd.get_cached_tv_tips(profile_dir, max_age_s=CSFD_TIPS_MAX_AGE_S)
    except Exception as exc:
        _log(f"csfd cache read failed: {exc!r}", xbmc.LOGWARNING)
        tips = []

    lines = csfd_tip_lines(tips, seed=seed)
    if lines:
        rotator = _TipRotator(lines, switch_every=CSFD_TIP_SWITCH_S)
        _log(f"mode={MODE_CSFD} tips={len(lines)} switch={CSFD_TIP_SWITCH_S}s", xbmc.LOGDEBUG)
        return rotator, MODE_CSFD

    fallback = _load_search_tips(addon_dir, "", seed if seed is not None else int(time.time()))
    rotator = _TipRotator(fallback, switch_every=TIP_SWITCH_S)
    _log(f"mode={MODE_DEFAULT} (bez cache TV tipů) tips={len(fallback)} switch={TIP_SWITCH_S}s",
         xbmc.LOGINFO)
    return rotator, MODE_DEFAULT
