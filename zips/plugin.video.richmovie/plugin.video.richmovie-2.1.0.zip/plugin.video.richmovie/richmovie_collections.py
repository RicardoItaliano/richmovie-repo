# -*- coding: utf-8 -*-
"""
RichMovie – Kolekce (offline playlisty) – modul

Tento modul poskytuje UI a I/O pro načítání a zobrazování **kolekcí**
(z JSON souborů ve složce `resources/collections/`) a jejich obsahu.

• Automaticky načítá **všechny** `.json` soubory ve složce a robustně je validuje.
• Podporuje položky typu `movie` (film) a `tv` (seriál) s volitelným polem `episodes`.
• U `movie` vyhledá TMDb ID a přesměruje přímo na workflow `action=auto&tmdb=<id>`.
• U `tv` s `episodes` zobrazí **jen vybrané** epizody jako pod-složku a na klik zavolá `action=tv_play`.

Pozn.: Soubor je úmyslně pojmenován **richmovie_collections.py**.
Název `collections.py` by kolidoval se standardní knihovnou Pythonu
(`from collections import deque` atd.) a rozbil by importy ve zbytku projektu.
"""

# ──────────────  FUTURE  ──────────────
from __future__ import annotations

# ──────────────  STANDARD LIBRARY  ──────────────
import json
import os
import re
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import urlencode

# ──────────────  KODI API  ──────────────
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# ──────────────  LOKÁLNÍ MODULY  ──────────────
from tmdb_client import TMDb, TMDbError


class CollectionsUI:




    #  2025-08-16 22:46 CEST (Europe/Prague)
    @staticmethod
    def show_collections_root(addon: xbmcaddon.Addon, handle: int) -> None:
        """
        Zobrazí seznam všech dostupných kolekcí (JSON soubory ve `resources/collections/`).

        Novinky (08/2025):
        ------------------
        • `subtitle` z JSONu se nyní zobrazuje jako *popis* (InfoTag → plot) vlevo pod logem.
        • V textu položky je pouze `title` (bez `subtitle`).
        • Vpravo se jako mini‑logo používá `clearlogo` (stejné PNG jako vlevo).
        • Řazení: nejprve kolekce s číselným prefixem „NN - “ (01–, 02–, …) podle čísla,
        poté ostatní kolekce abecedně (case‑insensitive).

        Původní logika výběru loga:
        • 1) Preferuj PNG se stejným stemem vedle JSON (…/collections/<stem>.png)
        • 2) Fallback: …/resources/media/lists/<id>.png
        """
        xbmcplugin.setPluginCategory(handle, "Kolekce")
        xbmcplugin.setContent(handle, "videos")

        # Předpřipravíme položky i s klíčem pro řazení
        # (url, li, is_folder, sort_key)
        items: List[tuple[str, xbmcgui.ListItem, bool, tuple]] = []

        def _num_prefix(title: str) -> Optional[int]:
            """
            Detekuje číselný prefix ve tvaru 'NN - ' (povolen 1–4 číslice).
            Vrací integer (bez ohledu na nuly) nebo None.
            """
            m = re.match(r"^\s*(\d{1,4})\s*-\s*", title)
            if not m:
                return None
            try:
                return int(m.group(1))
            except Exception:
                return None

        for file_path, meta in CollectionsUI._iter_collections(addon):
            # Titulek a podtitulek z JSON (fallback na název souboru)
            title    = (meta.get("title") or os.path.splitext(os.path.basename(file_path))[0]).strip()
            subtitle = (meta.get("subtitle") or "").strip()

            # Label v seznamu je nyní *pouze* title
            li = xbmcgui.ListItem(title)

            # Info panel (vlevo): plot = subtitle (pokud existuje)
            # mediatype 'video' kvůli skinům, které dle typu zobrazují plot
            li.setInfo("video", {
                "title":     title,
                "plot":      subtitle,
                "mediatype": "video",
            })

            # ── ARTWORK: preferuj PNG vedle JSON se shodným stemem ────────────────
            # Příklad: collections/cz_vanoce.json → collections/cz_vanoce.png
            art_icon = "DefaultFolder.png"
            try:
                png_candidate = os.path.splitext(file_path)[0] + ".png"
                if xbmcvfs.exists(png_candidate):
                    art_icon = png_candidate
                    xbmc.log(
                        f"[RichMovie/Collections] Logo kolekce: PNG vedle JSON -> {png_candidate}",
                        xbmc.LOGDEBUG
                    )
                else:
                    # Fallback: původní mechanika s ikonami v resources/media/lists/<id>.png
                    base      = addon.getAddonInfo("path")
                    icons_dir = os.path.join(base, "resources", "media", "lists")
                    if meta.get("id"):
                        img = os.path.join(icons_dir, f"{meta.get('id','')}.png")
                        if xbmcvfs.exists(img):
                            art_icon = img
                            xbmc.log(
                                f"[RichMovie/Collections] Logo kolekce: fallback ikona {img}",
                                xbmc.LOGDEBUG
                            )
            except Exception as e:
                xbmc.log(f"[RichMovie/Collections] Chyba při detekci loga: {e}", xbmc.LOGWARNING)

            # Artwork: vlevo i náhled + vpravo (mini logo) stejný PNG
            try:
                li.setArt({
                    "icon":      art_icon,
                    "thumb":     art_icon,
                    "clearlogo": art_icon,   # → mini logo vpravo v infotabulce
                })
            except Exception:
                pass

            url = CollectionsUI._url(addon, action="collections_browse", file=file_path)

            # Řazení: 1) prefixované číslem (0, <num>, label)  2) ostatní (1, 0, label)
            num = _num_prefix(title)
            sort_key = (0, num, title.lower()) if num is not None else (1, 0, title.lower())
            items.append((url, li, True, sort_key))

        # Seřadit dle composite klíče
        items.sort(key=lambda tup: tup[3])

        for url, li, is_folder, _ in items:
            xbmcplugin.addDirectoryItem(handle, url, li, is_folder)

        xbmcplugin.endOfDirectory(handle)









    #  2025-08-16 22:46 CEST (Europe/Prague)
    @staticmethod
    def browse_collection(file_vfs_path: str, addon: xbmcaddon.Addon, handle: int) -> None:
        """
        Otevře jednu konkrétní kolekci (dle VFS cesty na JSON) a vypíše její obsah.

        ZMĚNY (08/2025):
        ---------------
        • FILMY: zobrazujeme primárně český název z TMDb (pokud existuje).
        (TMDb klient je inicializován s lang="cs-CZ", takže `meta['title']`
        je již lokalizovaný titul, pokud je dostupný.)
        • Řazení napříč typy (filmy i seriály) zůstává dle TMDb ratingu (desc).
        • Artwork/plot/rating nastavení – zachováno, doplněno u filmů o votes/rating do InfoTagů.
        """
        data = CollectionsUI._load_json(file_vfs_path)
        if not isinstance(data, dict) or "items" not in data:
            xbmcgui.Dialog().ok("Kolekce", "Soubor kolekce je neplatný nebo chybí položky.")
            return

        title = (data.get("title") or os.path.basename(file_vfs_path)).strip()
        xbmcplugin.setPluginCategory(handle, title)
        xbmcplugin.setContent(handle, "videos")

        tmdb_key = addon.getSetting("tmdb_api_key").strip()
        tmdb     = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

        # (rating, url, li, is_folder)
        rows: List[tuple[float, str, xbmcgui.ListItem, bool]] = []

        for idx, it in enumerate(data.get("items", [])):
            typ  = (it.get("type")  or "").strip().lower()
            name = (it.get("title") or it.get("name") or "").strip()
            try:
                year = int(it.get("year") or 0) if str(it.get("year") or "").strip().isdigit() else None
            except Exception:
                year = None

            if not name or typ not in {"movie", "tv"}:
                xbmc.log(f"[RichMovie/Collections] Přeskakuji invalidní položku #{idx}: {it!r}", xbmc.LOGWARNING)
                continue

            if typ == "movie":
                # — 1) TMDb metadata (preferujeme cs-CZ; _find_movie_tmdb respektuje self.lang) —
                tmdb_id, meta = CollectionsUI._find_movie_tmdb(tmdb, name, year)
                # Preferovaný (český) zobrazovaný název
                display_name = (meta.get("title") or name).strip()
                display_year = 0
                try:
                    display_year = int(meta.get("year") or (year or 0))
                except Exception:
                    display_year = year or 0

                # Rating + label
                rating = float(meta.get("rating") or 0.0)
                rating_txt = f"[B][COLOR gold]★ {rating}[/COLOR][/B]\t" if rating else ""
                title_core = f"{display_name} ({display_year})" if display_year else display_name
                li = xbmcgui.ListItem(f"{rating_txt}{title_core}")

                # Artwork
                art: Dict[str, str] = {"icon": "DefaultVideo.png"}
                if meta.get("poster_path"):
                    art["poster"] = f"https://image.tmdb.org/t/p/w342{meta['poster_path']}"
                    art["thumb"]  = f"https://image.tmdb.org/t/p/w185{meta['poster_path']}"
                if meta.get("backdrop_path"):
                    art["fanart"] = f"https://image.tmdb.org/t/p/original{meta['backdrop_path']}"
                li.setArt(art)

                # InfoTag – doplníme rating/votes, pokud jsou
                info = {
                    "title":     display_name,
                    "plot":      (meta.get("overview") or "").strip(),
                    "year":      display_year,
                    "mediatype": "movie",
                }
                if rating:
                    info["rating"] = rating
                    try:
                        info["votes"] = int(meta.get("votes") or 0)
                    except Exception:
                        info["votes"] = 0
                li.setInfo("video", info)
                if rating:
                    try:
                        li.setRating("tmdb", rating, int(meta.get("votes", 0)))
                    except Exception:
                        pass

                # Klik URL – preferuj auto podle TMDb, jinak vyhledej film (použijeme display_name)
                if tmdb_id:
                    url = CollectionsUI._url(addon, action="auto", tmdb=str(tmdb_id))
                else:
                    url = CollectionsUI._url(addon, action="movie_search", q=display_name)

                rows.append((rating, url, li, True))

            elif typ == "tv":
                episodes = it.get("episodes") or []
                if not episodes:
                    # Otevřít standardní výpis sezón (po dohledání TMDb ID)
                    tv_id, tv_meta = CollectionsUI._find_tv_tmdb(tmdb, name)
                    if not tv_id:
                        # fallback na plnotextové hledání seriálů
                        url = CollectionsUI._url(addon, action="tv_search", q=name)
                        li  = xbmcgui.ListItem(name)
                        rows.append((0.0, url, li, True))
                    else:
                        rating = float(tv_meta.get("rating") or 0.0)
                        rating_txt = f"[B][COLOR gold]★ {rating}[/COLOR][/B]\t" if rating else ""
                        li = xbmcgui.ListItem(f"{rating_txt}{name}")

                        art: Dict[str, str] = {"icon": "DefaultTVShows.png"}
                        if tv_meta.get("poster_path"):
                            art["poster"] = f"https://image.tmdb.org/t/p/w342{tv_meta['poster_path']}"
                            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{tv_meta['poster_path']}"
                        if tv_meta.get("backdrop_path"):
                            art["fanart"] = f"https://image.tmdb.org/t/p/original{tv_meta['backdrop_path']}"
                        li.setArt(art)

                        li.setInfo("video", {
                            "title":        name,
                            "tvshowtitle":  name,
                            "plot":         (tv_meta.get("overview") or "").strip(),
                            "year":         int(tv_meta.get("year") or 0),
                            "mediatype":    "tvshow",
                        })
                        url = CollectionsUI._url(addon, action="tv_seasons", tv_id=str(tv_id), tv_name=name)
                        rows.append((rating, url, li, True))
                else:
                    # Podsložka „Pouze vybrané epizody“
                    tv_id, tv_meta = CollectionsUI._find_tv_tmdb(tmdb, name)
                    if not tv_id:
                        xbmc.log(f"[RichMovie/Collections] TV '{name}' – nepodařilo se najít TMDb ID.", xbmc.LOGWARNING)
                        continue
                    rating = float(tv_meta.get("rating") or 0.0)
                    rating_txt = f"[B][COLOR gold]★ {rating}[/COLOR][/B]\t" if rating else ""
                    li = xbmcgui.ListItem(f"{rating_txt}{name} (Pouze vybrané epizody)")

                    art: Dict[str, str] = {"icon": "DefaultTVShows.png"}
                    if tv_meta.get("poster_path"):
                        art["poster"] = f"https://image.tmdb.org/t/p/w342{tv_meta['poster_path']}"
                        art["thumb"]  = f"https://image.tmdb.org/t/p/w185{tv_meta['poster_path']}"
                    if tv_meta.get("backdrop_path"):
                        art["fanart"] = f"https://image.tmdb.org/t/p/original{tv_meta['backdrop_path']}"
                    li.setArt(art)

                    li.setInfo("video", {
                        "title":        name,
                        "tvshowtitle":  name,
                        "plot":         (tv_meta.get("overview") or "").strip(),
                        "year":         int(tv_meta.get("year") or 0),
                        "mediatype":    "tvshow",
                    })
                    url = CollectionsUI._url(
                        addon,
                        action="collections_tv",
                        file=file_vfs_path,
                        tv_id=str(tv_id),
                        tv_name=name,
                    )
                    rows.append((rating, url, li, True))

        # Seřaď podle ratingu (vyšší první); bez hodnocení jdou dolů.
        rows.sort(key=lambda tup: tup[0], reverse=True)

        for _, url, li, is_folder in rows:
            xbmcplugin.addDirectoryItem(handle, url, li, is_folder)

        xbmcplugin.endOfDirectory(handle)




    #  2025-08-16 09:24 CEST (Europe/Prague)
    @staticmethod
    def browse_tv(file_vfs_path: str, tv_id: str, tv_name: str,
                    addon: xbmcaddon.Addon, handle: int) -> None:
        """
        Vypíše **pouze vybrané epizody** seriálu (definované v JSONu kolekce).

        • Z JSONu načte položku `tv` dle `tv_name` a její `episodes`.
        • U každé epizody (season/episode) se pokusí dohledat český/EN název.
        • NOVĚ: do ListItemu doplňuje **popis epizody** (plot) a **náhledový obrázek**
                (`still_path`) – aby se vlevo zobrazovala miniatura a text jako u běžných seriálů.

        Klik povede na `?action=tv_play&tv_id=…&season=…&episode=…&ep_title=…`.
        """
        data = CollectionsUI._load_json(file_vfs_path)
        if not isinstance(data, dict) or "items" not in data:
            xbmcgui.Dialog().ok("Kolekce", "Soubor kolekce je neplatný nebo chybí položky.")
            return

        # Najdi odpovídající TV položku podle názvu
        tv_item = None
        for it in data.get("items", []):
            if (it.get("type") or "").lower() == "tv" and (it.get("title") or it.get("name") or "").strip() == tv_name:
                tv_item = it; break
        if not tv_item:
            xbmcgui.Dialog().ok("Kolekce", "V kolekci nebyl nalezen odpovídající seriál.")
            return

        episodes = tv_item.get("episodes") or []
        if not episodes:
            xbmcgui.Dialog().ok("Kolekce", "Tato položka nemá definované vybrané epizody.")
            return

        xbmcplugin.setPluginCategory(handle, f"{tv_name} – vybrané epizody")
        xbmcplugin.setContent(handle, "episodes")

        tmdb_key = addon.getSetting("tmdb_api_key").strip()
        tmdb = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

        for ep in episodes:
            try:
                s = int(ep.get("season"))
                e = int(ep.get("episode"))
            except Exception:
                xbmc.log(f"[RichMovie/Collections] Neplatná definice epizody: {ep!r}", xbmc.LOGWARNING)
                continue

            ep_title = ep.get("note") or ""
            plot_txt = ""
            art = {"icon": "DefaultVideo.png"}
            # doplň název + popis + náhled z TMDb (pokud máme klienta)
            if tmdb and tv_id.isdigit():
                try:
                    det = tmdb.episode_details(int(tv_id), s, e)
                    name_cs = (det.get("name") or "").strip()
                    if name_cs:
                        ep_title = name_cs
                    plot_txt = (det.get("overview") or "").strip()
                    still = (det.get("still_path") or "").strip()
                    if still:
                        art["thumb"] = f"https://image.tmdb.org/t/p/w300{still}"
                except TMDbError:
                    pass

            label = f"S{s:02d}E{e:02d}" + (f" – {ep_title}" if ep_title else "")
            li = xbmcgui.ListItem(label)
            li.setArt(art)
            li.setInfo("video", {"title": label, "tvshowtitle": tv_name, "season": s, "episode": e, "plot": plot_txt, "mediatype": "episode"})
            url = CollectionsUI._url(
                addon,
                action="tv_play",
                tv_id=str(tv_id),
                season=str(s),
                episode=str(e),
                ep_title=ep_title,
            )
            xbmcplugin.addDirectoryItem(handle, url, li, True)

        xbmcplugin.endOfDirectory(handle)






    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _iter_collections(addon: xbmcaddon.Addon) -> Iterable[tuple[str, Dict[str, Any]]]:
        """
        Vrátí (VFS_cesta, metadata) pro každý validní kolekční JSON.

        • Vynechá soubory bez validního JSONu nebo bez povinného pole `items`.
        • `id` se derivuje z JSONu; pokud chybí, použije se název souboru bez přípony.
        """
        base = addon.getAddonInfo("path")
        coll_dir = os.path.join(base, "resources", "collections")
        try:
            _, files = xbmcvfs.listdir(coll_dir)
        except Exception:
            files = []
        for name in files:
            if not name.lower().endswith(".json"): 
                continue
            vfs_path = os.path.join(coll_dir, name)
            data = CollectionsUI._load_json(vfs_path)
            if not isinstance(data, dict) or not data.get("items"):
                xbmc.log(f"[RichMovie/Collections] Přeskakuji neplatný soubor: {name}", xbmc.LOGWARNING)
                continue
            # zaruč `id`
            if not data.get("id"):
                data["id"] = os.path.splitext(name)[0]
            yield vfs_path, data


    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _load_json(vfs_path: str) -> Any:
        """
        Načte JSON z VFS cesty s robustním dekódováním (UTF-8/UTF-8-SIG).
        """
        try:
            f = xbmcvfs.File(vfs_path, 'r')
            try:
                raw = f.read()
            finally:
                f.close()
            if isinstance(raw, bytes):
                try:
                    txt = raw.decode("utf-8-sig")
                except Exception:
                    txt = raw.decode("utf-8", "replace")
            else:
                txt = raw
            return json.loads(txt)
        except Exception as e:
            xbmc.log(f"[RichMovie/Collections] Chyba při čtení JSON: {vfs_path} – {e}", xbmc.LOGERROR)
            return None


    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _find_movie_tmdb(tmdb: Optional[TMDb], title: str, year: Optional[int]) -> tuple[Optional[int], Dict[str, Any]]:
        """
        Najde TMDb ID pro film (preferuje shodu roku). Vrací (tmdb_id, metadata).
        """
        if not tmdb:
            return None, {}
        try:
            cands = tmdb.search(title, limit=10)
        except TMDbError:
            return None, {}
        # preferuj shodu roku
        best = None
        if year:
            for c in cands:
                if int(c.get("year") or 0) == int(year):
                    best = c; break
        best = best or (cands[0] if cands else None)
        return (best.get("id"), best) if best else (None, {})


    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _find_tv_tmdb(tmdb: Optional[TMDb], title: str) -> tuple[Optional[int], Dict[str, Any]]:
        """
        Najde TMDb ID pro seriál podle názvu. Vrací (tmdb_id, metadata).
        """
        if not tmdb:
            return None, {}
        try:
            cands = tmdb.search_tv(title, limit=10)
        except TMDbError:
            return None, {}
        best = cands[0] if cands else None
        return (best.get("id"), best) if best else (None, {})


    #  2025-08-16 08:37 CEST (Europe/Prague)
    @staticmethod
    def _url(addon: xbmcaddon.Addon, **qs: str) -> str:
        """
        Postaví URL volání vlastního pluginu (lokální utilita).
        """
        return f"plugin://{addon.getAddonInfo('id')}/?{urlencode(qs)}"
