# -*- coding: utf-8 -*-
"""Lehký TMDb klient (API v3) – hledání filmů, detail a alternativní stopáže."""

from __future__ import annotations        # → typové anotace jako str (Py 3.8)

# ──────────────  STANDARD LIBRARY  ──────────────
import json
import os
from pathlib import Path
import threading
import time
import unicodedata
import urllib.parse
import urllib.request
from typing import Any, Callable, Dict, List, Optional, Sequence




# ───────────────────  VÝJIMKY  ──────────────────
class TMDbError(RuntimeError):
    """Chyba při komunikaci s TMDb."""


# ───────────────────  KLIENT  ────────────────────
class TMDb:
    """Minimalistický wrapper kolem TMDb API v3 (JSON)."""

    BASE_URL = "https://api.themoviedb.org/3"



    #  2025-08-16 09:24 CEST (Europe/Prague)
    def __init__(
        self,
        api_key: str,
        lang: str = "cs-CZ",
        *,
        logger: Optional[Callable[..., None]] = None,
    ):
        """
        Minimalistický wrapper na TMDb API.

        Novinky 07/2025
        ----------------
        • volitelný `logger` – funkce se signaturou `fn(event, *params)`
          (v RichMovie předáváme `plugin._log_event`)
        • pokud není předán, pokusí se najít `plugin._log_event` dynamicky;
          jinak použije „tichou“ lambda – žádné další importy nejsou nutné

        Novinka 08/2025
        ----------------
        • interní **disková cache TMDb odpovědí** (JSON) pro šetření API:
          vybrané metody (`search`, `search_tv`, `episode_details`, `tv_details`)
          čtou/zapisují do souboru `tmdb_meta_cache.json` v profilu doplňku.
        """
        if not api_key:
            raise ValueError("api_key nesmí být prázdné.")
        self.api_key = api_key
        self.lang    = lang

        # – auto‑detekce loggeru –
        if logger is None:
            try:
                import plugin as _plg_mod                     # cyklus nevadí – volá se až po initu pluginu
                logger = getattr(_plg_mod, "_log_event", None)
            except Exception:
                logger = None
        self._log = logger or (lambda *_, **__: None)

        # – inicializace sdílené JSON cache (jen jednou na proces) –
        if not hasattr(TMDb, "_CACHE_LOCK"):
            TMDb._CACHE_LOCK = threading.Lock()

        if not hasattr(TMDb, "_CACHE_PATH"):
            cache_dir: Optional[Path] = None
            try:
                import plugin as _plg_mod  # získáme PROFILE_DIR, pokud běží uvnitř RichMovie
                profile_dir = getattr(_plg_mod, "PROFILE_DIR", None)
                if profile_dir:
                    cache_dir = Path(str(profile_dir))
            except Exception:
                cache_dir = None
            if cache_dir is None:
                # Fallback: ~/.richmovie/
                cache_dir = Path(os.path.expanduser("~/.richmovie"))
            try:
                cache_dir.mkdir(parents=True, exist_ok=True)
            except Exception:
                # Poslední záchrana: aktuální pracovní adresář
                cache_dir = Path(os.getcwd())
                try:
                    cache_dir.mkdir(parents=True, exist_ok=True)
                except Exception:
                    pass
            TMDb._CACHE_PATH = cache_dir / "tmdb_meta_cache.json"

        if not hasattr(TMDb, "_CACHE"):
            # Načti existující cache (tiše ignoruj poškozené)
            data: Dict[str, Any] = {}
            try:
                if TMDb._CACHE_PATH.exists():
                    text = TMDb._CACHE_PATH.read_text("utf-8")
                    data = json.loads(text) if text else {}
            except Exception as e:
                self._log("TMDB_CACHE_LOAD_ERR", str(e))
                data = {}
            TMDb._CACHE = data





    #  2025-08-16 09:24 CEST (Europe/Prague)
    def _cache_get(self, key: str, ttl_seconds: int) -> Optional[Any]:
        """
        Vrátí uložená data z interní TMDb JSON cache, pokud **nevypršel TTL**.

        - `key`        – logický klíč (např. "search:movie:cs-CZ:matrix:10")
        - `ttl_seconds`– doba platnosti v sekundách
        """
        try:
            with TMDb._CACHE_LOCK:
                entry = TMDb._CACHE.get(key)
                if not entry:
                    return None
                ts = float(entry.get("ts") or 0)
                if (time.time() - ts) > max(0, int(ttl_seconds)):
                    # Expirace – smazat a vrátit miss
                    TMDb._CACHE.pop(key, None)
                    return None
                data = entry.get("data", None)
                if data is not None:
                    self._log("TMDB_CACHE_HIT", key)
                return data
        except Exception as e:
            self._log("TMDB_CACHE_ERR", f"get: {e}")
            return None




    #  2025-08-16 09:24 CEST (Europe/Prague)
    def _cache_set(self, key: str, data: Any) -> None:
        """
        Uloží data do interní TMDb JSON cache (na disk atomicky).
        """
        try:
            with TMDb._CACHE_LOCK:
                TMDb._CACHE[key] = {"ts": time.time(), "data": data}
                # Atomic save: zapiš do dočasného souboru a přejmenuj
                path: Path = TMDb._CACHE_PATH
                tmp = path.with_suffix(".tmp")
                tmp.write_text(json.dumps(TMDb._CACHE, ensure_ascii=False), "utf-8")
                try:
                    tmp.replace(path)
                except Exception:
                    # Windows: pokud replace selže, zkus smazat a přejmenovat
                    try:
                        if path.exists():
                            path.unlink()
                    except Exception:
                        pass
                    tmp.rename(path)
            self._log("TMDB_CACHE_SAVE", key)
        except Exception as e:
            self._log("TMDB_CACHE_ERR", f"set: {e}")





    # 16-08-2025 08:43 CEST (Europe/Prague)
    def _is_latin_text(self, text: str) -> bool:
        """
        Zjistí, zda text obsahuje alespoň jedno písmeno a všechna písmena
        patří do rozsahu 'LATIN' (včetně české/SL diakritiky: č, š, ě, ů …).

        - Používáme `unicodedata.name(ch)`, protože `isascii()` by vyřadilo
          i latinku s diakritikou.
        - Nepísmena (čísla, mezery, interpunkci) ignorujeme.
        """
        has_letter = False
        for ch in text or "":
            if ch.isalpha():
                has_letter = True
                # Pokud Unicode jméno znaku neobsahuje "LATIN", není to latinka.
                if "LATIN" not in unicodedata.name(ch, ""):
                    return False
        return has_letter




    def _prefer_latin_title(self, *, media: str, _id: int, primary: str, original: str = "") -> str:
        """
        2025-08-17 00:30 CEST (Europe/Prague)

        Vybere latinkový název podle jasného pořadí:
          1) `primary` (aktuální název) – pokud je latinkou,
          2) `original` (originální titul) – pokud je latinkou,
          3) alternativní tituly (preferujeme země: US, GB, CA, AU),
          4) EN detail (`language=en-US`).

        Nové (mikro-cache – „kosmetika“ pro omezení síťových volání):
          • Alt‑titles (movie/tv) se ukládají do interní JSON cache na ~3 dny.
          • EN detail (movie/tv) se ukládá do interní JSON cache na ~3 dny.
          • Klíče cache: 
              - alt_titles:movie:{id}  /  alt_titles:tv:{id}
              - detail_en:movie:{id}   /  detail_en:tv:{id}
          • Síťové chyby ponechávají původní tichý fallback – logiku neměníme.

        Pozn.: `_cache_get/_cache_set` používají společný `tmdb_meta_cache.json`
        a již řeší atomický zápis a uzamčení. Zbytek logiky metody zůstává beze změny.
        """
        # 1) primární název (už latinkový?)
        if self._is_latin_text(primary):
            return (primary or "").strip()

        # 2) original_name / original_title
        if self._is_latin_text(original):
            return (original or "").strip()

        # 3) alternativní tituly – NOVĚ: krátká disková cache
        try:
            ttl = 3 * 24 * 3600  # ~3 dny
            akind = "movie" if media == "movie" else "tv"
            akey  = f"alt_titles:{akind}:{int(_id)}"

            items = self._cache_get(akey, ttl_seconds=ttl)
            if not isinstance(items, list):
                if media == "movie":
                    data = self._get_json(f"/movie/{_id}/alternative_titles", {"api_key": self.api_key})
                    items = [
                        {"title": (t.get("title") or "").strip(), "country": (t.get("iso_3166_1") or "").strip()}
                        for t in (data.get("titles") or [])
                    ]
                else:
                    data = self._get_json(f"/tv/{_id}/alternative_titles", {"api_key": self.api_key})
                    items = [
                        {"title": (t.get("title") or "").strip(), "country": (t.get("iso_3166_1") or "").strip()}
                        for t in (data.get("results") or [])
                    ]
                self._cache_set(akey, items)

            pref_ctrs   = {"US", "GB", "CA", "AU"}
            first_latin = None
            for rec in items or []:
                t = (rec.get("title") or "").strip()
                if not t:
                    continue
                if self._is_latin_text(t) and (rec.get("country") or "") in pref_ctrs:
                    return t
                if first_latin is None and self._is_latin_text(t):
                    first_latin = t
            if first_latin:
                return first_latin
        except Exception:
            # `_get_json()` už loguje chyby; zachováváme původní tiché fallbacky.
            pass

        # 4) EN detail – NOVĚ: krátká disková cache
        try:
            ttl = 3 * 24 * 3600  # ~3 dny
            dkind = "movie" if media == "movie" else "tv"
            dkey  = f"detail_en:{dkind}:{int(_id)}"

            t = self._cache_get(dkey, ttl_seconds=ttl)
            if not (isinstance(t, str) and t):
                if media == "movie":
                    en = self._get_json(f"/movie/{_id}", {"api_key": self.api_key, "language": "en-US"})
                    t  = (en.get("title") or "").strip()
                else:
                    en = self._get_json(f"/tv/{_id}", {"api_key": self.api_key, "language": "en-US"})
                    t  = (en.get("name") or "").strip()
                self._cache_set(dkey, t)

            if t and self._is_latin_text(t):
                return t
        except Exception:
            pass

        # Nic lepšího – vrať původní (aby se aspoň něco zobrazilo)
        return (primary or original or "").strip()






    #  2025-08-16 09:24 CEST (Europe/Prague)
    def search(self, query: str, limit: int = 10) -> List[Dict]:
        """
        Vyhledání filmů dle `query` s prioritou latinky v titulku.

        Zachováno:
          - volání `/search/movie` s `language=self.lang`, `include_adult=false`
          - struktura položek: {"id","title","year","poster_path","backdrop_path","overview","rating","votes"}
          - zaokrouhlení ratingu na 1 desetinné místo a int `votes`
          - `_get_json()` řeší logování TMDB_REQ / RESP / ERR a timeout

        Nové:
          - jednoduchá **disková cache** výsledků (TTL ≈ 10 dní)
          - pokud `title` není latinkou, nahradíme jej latinkovou variantou
            (alt tituly → EN detail), viz `_prefer_latin_title()`.
        """
        # Cache key: zahrň `lang` a `limit`, ať se neliší výsledky
        _ttl = 10 * 24 * 3600
        _key = f"search:movie:{self.lang}:{(query or '').strip().lower()}:{int(limit or 10)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {
            "api_key":       self.api_key,
            "query":         query,
            "language":      self.lang,
            "include_adult": "false",
            "page":          1,
        }
        data = self._get_json("/search/movie", params)

        out: List[Dict] = []
        for r in data.get("results", [])[:limit]:
            title_primary = (r.get("title") or "").strip()
            if not title_primary:
                continue

            title_final = self._prefer_latin_title(
                media="movie",
                _id=int(r["id"]),
                primary=title_primary,
                original=(r.get("original_title") or "").strip(),
            )

            out.append(
                {
                    "id":            r["id"],
                    "title":         title_final,
                    "year":          int((r.get("release_date") or "0000")[:4] or 0),
                    "poster_path":   r.get("poster_path") or "",
                    "backdrop_path": r.get("backdrop_path") or "",
                    "overview":      (r.get("overview") or "").strip(),
                    "rating":        round(float(r.get("vote_average") or 0), 1),
                    "votes":         int(r.get("vote_count") or 0),
                }
            )
        self._cache_set(_key, out)
        return out




    # 2025‑07‑27 20:07 CEST  — oprava: metoda znovu součástí třídy
    def _get_json(self, path: str, params: Dict) -> Dict:
        """
        Interní helper: provede HTTP GET, zaloguje a vrátí dekódovaný JSON.

            TMDB_REQ   <plná URL>
            TMDB_RESP  <HTTP status> <bytes>
            TMDB_ERR   <str(e)>

        • Při HTTP ≠ 200 vyvolá TMDbError  
        • Timeout 6 s → GUI nezamrzá
        """
        url = f"{self.BASE_URL}{path}?{urllib.parse.urlencode(params)}"
        self._log("TMDB_REQ", url)

        try:
            with urllib.request.urlopen(url, timeout=6) as resp:
                body = resp.read()
                self._log("TMDB_RESP", resp.status, len(body))
                if resp.status != 200:
                    raise TMDbError(f"Status {resp.status}")
                return json.loads(body.decode())
        except Exception as e:
            self._log("TMDB_ERR", str(e))
            raise TMDbError(str(e)) from e


    #  2025-08-16 09:24 CEST (Europe/Prague)
    def search_tv(self, query: str, limit: int = 10) -> List[Dict]:
        """
        Vyhledání TV seriálů dle `query` s prioritou latinky v `name`.

        Výstupní struktura (beze změny):
          [{"id","name","year","poster_path","backdrop_path","overview","rating","votes"}, …]
        """
        _ttl = 10 * 24 * 3600
        _key = f"search:tv:{self.lang}:{(query or '').strip().lower()}:{int(limit or 10)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {
            "api_key":       self.api_key,
            "query":         query,
            "language":      self.lang,
            "include_adult": "false",
            "page":          1,
        }
        data = self._get_json("/search/tv", params)

        out: List[Dict] = []
        for r in data.get("results", [])[:limit]:
            name_primary = (r.get("name") or "").strip()
            if not name_primary:
                continue

            name_final = self._prefer_latin_title(
                media="tv",
                _id=int(r["id"]),
                primary=name_primary,
                original=(r.get("original_name") or "").strip(),
            )

            out.append(
                {
                    "id":            r["id"],
                    "name":          name_final,
                    "year":          int((r.get("first_air_date") or "0000")[:4] or 0),
                    "poster_path":   r.get("poster_path") or "",
                    "backdrop_path": r.get("backdrop_path") or "",
                    "overview":      (r.get("overview") or "").strip(),
                    "rating":        round(float(r.get("vote_average") or 0), 1),
                    "votes":         int(r.get("vote_count") or 0),
                }
            )
        self._cache_set(_key, out)
        return out




    #  2025-08-16 09:24 CEST (Europe/Prague)
    def episode_details(self, tv_id: int, season_no: int, episode_no: int) -> Dict:
        """
        Detail jedné epizody (/tv/{tv_id}/season/{season_no}/episode/{episode_no})
        Vrací např. {"id":..., "name":"...", "overview":"...", "still_path": "..."}.

        Nové:
        -----
        • disková cache s TTL ≈ 30 dní
        """
        params = {"api_key": self.api_key, "language": self.lang}

        _ttl = 30 * 24 * 3600
        _key = f"episode:{int(tv_id)}:{int(season_no)}:{int(episode_no)}:{self.lang}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, dict):
            return cached

        data = self._get_json(
            f"/tv/{tv_id}/season/{season_no}/episode/{episode_no}", params
        )
        self._cache_set(_key, data)
        return data



    def episode_translations(self, tv_id: int, season_no: int, episode_no: int) -> Dict[str, str]:
        """
        Překlady názvu epizody → mapování „jazyk(-země) → name“.

        10-08-2025 16:31 CEST (Europe/Prague)
        -------------------------------------
        • /tv/{tv_id}/season/{sn}/episode/{ep}/translations
        • Klíč volím jako "iso_639_1-iso_3166_1" (pokud je země známa),
          jinak jen "iso_639_1".  Vždy beru nejdelší dostupné jméno
          pro daný klíč (bývá to plný název typu „The One Where …“).

        Vrací:
            {"en-US": "The One Where Monica Gets a Roommate",
             "en-GB": "The One Where Monica Gets a Flatmate",
             "en":    "The One Where Monica Gets a Roommate",
             "cs-CZ": "Zrušená svatba", ...}
        """
        params = {"api_key": self.api_key}
        data: Dict[str, Any] = self._get_json(
            f"/tv/{tv_id}/season/{season_no}/episode/{episode_no}/translations", params
        )  # využívá existující _get_json() s logováním/timeoutem, viz třída výše
        # ^ _get_json() už loguje TMDB_REQ/TMDB_RESP/TMDB_ERR a zvedá TMDbError. 

        out: Dict[str, str] = {}
        for tr in data.get("translations", []) or []:
            lang = (tr.get("iso_639_1") or "").strip()
            ctry = (tr.get("iso_3166_1") or "").strip()
            dat  = tr.get("data") or {}
            name = (dat.get("name") or "").strip()
            if not (lang and name):
                continue
            key = f"{lang}-{ctry}" if ctry else lang
            # Pokud už klíč existuje, preferuj delší název (často plná věta)
            if key not in out or len(name) > len(out[key]):
                out[key] = name
        return out





    #  2025-08-16 09:24 CEST (Europe/Prague)
    def tv_details(self, tv_id: int) -> Dict[str, Any]:
        """
        Detail seriálu – preferujeme latinkový `name` (alt tituly → EN detail).

        Nové:
        -----
        • disková cache s TTL ≈ 14 dní
        """
        params = {"api_key": self.api_key, "language": self.lang}

        _ttl = 14 * 24 * 3600
        _key = f"tv_details:{int(tv_id)}:{self.lang}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, dict):
            data = dict(cached)  # pro jistotu kopie
        else:
            data = self._get_json(f"/tv/{tv_id}", params)

        data["name"] = self._prefer_latin_title(
            media="tv",
            _id=int(tv_id),
            primary=(data.get("name") or "").strip(),
            original=(data.get("original_name") or "").strip(),
        )
        self._cache_set(_key, data)
        return data





    def season_details(self, tv_id: int, season_no: int) -> List[Dict]:
        """
        Vrátí list epizod v dané sezóně:

            [{"episode_number":1, "name":"Winter Is Coming"}, …]
        """
        params = {"api_key": self.api_key, "language": self.lang}
        data   = self._get_json(f"/tv/{tv_id}/season/{season_no}", params)

        eps: List[Dict] = []
        for e in data.get("episodes", []):
            if not e.get("name"):
                continue
            eps.append(
                {
                    "episode_number": e["episode_number"],
                    "name":           e["name"],
                }
            )
        return eps



    # 16-08-2025 08:43 CEST (Europe/Prague)
    def details(self, movie_id: int) -> Dict[str, Any]:
        """
        Detail filmu – rozšířen o preferenci latinky v `title`.
        Další logika beze změny:
          - EN fallback pro `runtime` (pokud chybí v lokalizaci),
          - zajištění klíčů `year` (YYYY z `release_date`) a `original_title`.
        """
        # Lokalizovaný detail (cs-CZ apod.)
        params = {"api_key": self.api_key, "language": self.lang}
        data: Dict[str, Any] = self._get_json(f"/movie/{movie_id}", params)

        # Preferovat latinku v title (alt tituly → EN detail)
        data["title"] = self._prefer_latin_title(
            media="movie",
            _id=int(movie_id),
            primary=(data.get("title") or "").strip(),
            original=(data.get("original_title") or "").strip(),
        )

        # Fallback runtime z EN detailu, pokud chybí
        if not data.get("runtime"):
            try:
                en = self._get_json(f"/movie/{movie_id}", {"api_key": self.api_key, "language": "en-US"})
                if en.get("runtime"):
                    data["runtime"] = en["runtime"]
            except TMDbError:
                pass

        # Zajisti `year` a `original_title` (stejné chování jako původně)
        if not data.get("year"):
            data["year"] = int((data.get("release_date") or "0000")[:4] or 0)
        if not data.get("original_title"):
            data["original_title"] = data.get("title", "")

        return data








    # 16-08-2025 08:43 CEST (Europe/Prague)
    def trending(self, media_type: str = "movie", period: str = "day",
                 limit: int = 20) -> List[Dict]:
        """
        Vrátí trending položky pro zadané období, s preferencí latinky v `title`.

        Pozn.:
          - V praxi používáme `media_type="movie"`.
          - Stránkujeme po 20, dokud nedosáhneme `limit` nebo poslední stránky.
          - Logy: `TMDB_PAGE` (průběh), `TMDB_PAGINATE_ERR` (chyba na další stránce).
        """
        if media_type != "movie" or limit <= 0:
            return []

        out: List[Dict] = []
        page = 1
        max_pages = 500

        while len(out) < limit and page <= max_pages:
            params = {"api_key": self.api_key, "language": self.lang, "page": page}
            try:
                data = self._get_json(f"/trending/{media_type}/{period}", params)
            except TMDbError as e:
                # Pokud první stránka spadne, propustíme výjimku; jinak jen zalogujeme a skončíme.
                if page == 1:
                    raise
                self._log("TMDB_PAGINATE_ERR", "trending", media_type, page, str(e))
                break

            results = data.get("results", []) or []
            if not results:
                break

            for r in results:
                title_primary = (r.get("title") or "").strip()
                if not title_primary:
                    continue

                title_final = self._prefer_latin_title(
                    media="movie",
                    _id=int(r["id"]),
                    primary=title_primary,
                    original=(r.get("original_title") or "").strip(),
                )

                out.append(
                    {
                        "id":            r["id"],
                        "title":         title_final,
                        "year":          int((r.get("release_date") or "0000")[:4] or 0),
                        "poster_path":   r.get("poster_path") or "",
                        "backdrop_path": r.get("backdrop_path") or "",
                        "overview":      (r.get("overview") or "").strip(),
                        "rating":        round(float(r.get("vote_average") or 0), 1),
                        "votes":         int(r.get("vote_count") or 0),
                    }
                )
                if len(out) >= limit:
                    break

            # Průběžné logování stránkování
            self._log("TMDB_PAGE", "trending", media_type, period, page, len(results), len(out))

            # TMDb typicky vrací 20 na stránku; menší počet znamená poslední stránku.
            if len(results) < 20:
                break
            page += 1

        # Původní metoda vracela `out` (zastavujeme při dosažení `limit`).
        return out







    # 16-08-2025 08:43 CEST (Europe/Prague)
    def top_rated(self, page: int = 1, limit: int = 20) -> List[Dict]:
        """
        Nejlépe hodnocené filmy – s preferencí latinkového názvu.
        Stránkujeme od `page` a skládáme výsledky do dosažení `limit`.
        """
        if limit <= 0:
            return []

        out: List[Dict] = []
        cur_page = max(1, int(page or 1))
        max_pages = 500

        while len(out) < limit and cur_page <= max_pages:
            params = {"api_key": self.api_key, "language": self.lang, "page": cur_page}
            try:
                data = self._get_json("/movie/top_rated", params)
            except TMDbError as e:
                if cur_page == page:
                    # První stránka – propouštíme výjimku
                    raise
                # Další stránka – jen zalogujeme a skončíme
                self._log("TMDB_PAGINATE_ERR", "top_rated", cur_page, str(e))
                break

            results = data.get("results", []) or []
            if not results:
                break

            for r in results:
                title_primary = (r.get("title") or "").strip()
                if not title_primary:
                    continue

                title_final = self._prefer_latin_title(
                    media="movie",
                    _id=int(r["id"]),
                    primary=title_primary,
                    original=(r.get("original_title") or "").strip(),
                )

                out.append(
                    {
                        "id":            r["id"],
                        "title":         title_final,
                        "year":          int((r.get("release_date") or "0000")[:4] or 0),
                        "poster_path":   r.get("poster_path") or "",
                        "backdrop_path": r.get("backdrop_path") or "",
                        "overview":      (r.get("overview") or "").strip(),
                        "rating":        round(float(r.get("vote_average") or 0), 1),
                        "votes":         int(r.get("vote_count") or 0),
                    }
                )
                if len(out) >= limit:
                    break

            # přehledné stránkové logování
            self._log("TMDB_PAGE", "top_rated", cur_page, len(results), len(out))

            if len(results) < 20:
                break
            cur_page += 1

        return out[:limit]






    def genres(self) -> List[Dict]:
        """Seznam filmových žánrů (id, name)."""
        params = {"api_key": self.api_key, "language": self.lang}
        data   = self._get_json("/genre/movie/list", params)
        return data.get("genres", [])



    # 16-08-2025 08:43 CEST (Europe/Prague)
    def trending_tv(self, period: str = "day", limit: int = 20) -> List[Dict]:
        """
        Vrátí „trending“ seriály (day/week) – s preferencí latinkového `name`.
        Stránkujeme po 20 záznamech do dosažení `limit`.
        """
        if limit <= 0:
            return []

        out: List[Dict] = []
        page = 1
        max_pages = 500

        while len(out) < limit and page <= max_pages:
            params = {"api_key": self.api_key, "language": self.lang, "page": page}
            path = f"/trending/tv/{period}"
            try:
                data = self._get_json(path, params)
            except TMDbError as e:
                if page == 1:
                    raise
                self._log("TMDB_PAGINATE_ERR", "trending_tv", page, str(e))
                break

            results = data.get("results", []) or []
            if not results:
                break

            for r in results:
                name_primary = (r.get("name") or "").strip()
                if not name_primary:
                    continue

                name_final = self._prefer_latin_title(
                    media="tv",
                    _id=int(r["id"]),
                    primary=name_primary,
                    original=(r.get("original_name") or "").strip(),
                )

                out.append(
                    {
                        "id":            r["id"],
                        "name":          name_final,
                        "year":          int((r.get("first_air_date") or "0000")[:4] or 0),
                        "poster_path":   r.get("poster_path") or "",
                        "backdrop_path": r.get("backdrop_path") or "",
                        "overview":      (r.get("overview") or "").strip(),
                        "rating":        round(float(r.get("vote_average") or 0), 1),
                        "votes":         int(r.get("vote_count") or 0),
                    }
                )
                if len(out) >= limit:
                    break

            self._log("TMDB_PAGE", "trending_tv", period, page, len(results), len(out))

            if len(results) < 20:
                break
            page += 1

        return out[:limit]





    # 16-08-2025 08:43 CEST (Europe/Prague)
    def top_rated_tv(self, page: int = 1, limit: int = 20) -> List[Dict]:
        """
        Globální TOP hodnocené seriály – latinkový `name`, zachováno stránkování.
        """
        if limit <= 0:
            return []

        out: List[Dict] = []
        cur_page = max(1, int(page or 1))
        max_pages = 500

        while len(out) < limit and cur_page <= max_pages:
            params = {
                "api_key":  self.api_key,
                "language": self.lang,
                "page":     cur_page,
            }
            try:
                data = self._get_json("/tv/top_rated", params)
            except TMDbError as e:
                if cur_page == page:
                    raise
                self._log("TMDB_PAGINATE_ERR", "top_rated_tv", cur_page, str(e))
                break

            results = data.get("results", []) or []
            if not results:
                break

            for r in results:
                name_primary = (r.get("name") or "").strip()
                if not name_primary:
                    continue

                name_final = self._prefer_latin_title(
                    media="tv",
                    _id=int(r["id"]),
                    primary=name_primary,
                    original=(r.get("original_name") or "").strip(),
                )

                out.append(
                    {
                        "id":            r["id"],
                        "name":          name_final,
                        "year":          int((r.get("first_air_date") or "0000")[:4] or 0),
                        "poster_path":   r.get("poster_path") or "",
                        "backdrop_path": r.get("backdrop_path") or "",
                        "overview":      (r.get("overview") or "").strip(),
                        "rating":        round(float(r.get("vote_average") or 0), 1),
                        "votes":         int(r.get("vote_count") or 0),
                    }
                )
                if len(out) >= limit:
                    break

            self._log("TMDB_PAGE", "top_rated_tv", cur_page, len(results), len(out))

            if len(results) < 20:
                break
            cur_page += 1

        return out[:limit]




    # 16-08-2025 08:43 CEST (Europe/Prague)
    def discover_by_genre(self, genre_id: int, *,
                          sort_by: str = "vote_average.desc",
                          vote_count_gte: int = 100,
                          page: int = 1, limit: int = 20) -> List[Dict]:
        """
        Výpis filmů pro daný žánr s preferencí latinkového `title`.

        Zachováno: parametry `sort_by`, `vote_count.gte`, stránkování přes `page`,
        struktura výstupu a výpočty rating/votes/year.
        """
        params = {
            "api_key":        self.api_key,
            "language":       self.lang,
            "with_genres":    genre_id,
            "sort_by":        sort_by,
            "vote_count.gte": vote_count_gte,
            "page":           page,
        }
        data = self._get_json("/discover/movie", params)

        out: List[Dict] = []
        for r in data.get("results", [])[:limit]:
            title_primary = (r.get("title") or "").strip()
            if not title_primary:
                continue

            title_final = self._prefer_latin_title(
                media="movie",
                _id=int(r["id"]),
                primary=title_primary,
                original=(r.get("original_title") or "").strip(),
            )

            out.append(
                {
                    "id":            r["id"],
                    "title":         title_final,
                    "year":          int((r.get("release_date") or "0000")[:4] or 0),
                    "poster_path":   r.get("poster_path") or "",
                    "backdrop_path": r.get("backdrop_path") or "",
                    "overview":      (r.get("overview") or "").strip(),
                    "rating":        round(float(r.get("vote_average") or 0), 1),
                    "votes":         int(r.get("vote_count") or 0),
                }
            )
        return out




    # --------------------------------------------------------------- #
    #  CAST – TOP N herců
    # --------------------------------------------------------------- #
    def cast(self, movie_id: int, limit: int = 10) -> List[str]:
        """
        Vrátí seznam jmen herců (podle pořadí „billing order“)
        z endpointu `/movie/{id}/credits`.

        Args:
            movie_id:  TMDb ID filmu
            limit:     kolik jmen vrátit (default 10)

        Raises:
            TMDbError – při síťové chybě nebo HTTP != 200
        """
        params = {"api_key": self.api_key}
        data   = self._get_json(f"/movie/{movie_id}/credits", params)

        cast: List[str] = [
            c["name"] for c in data.get("cast", [])
            if c.get("name")
        ]
        return cast[:limit]




    # --------------------------------------------------------------- #
    #  ALTERNATIVE TITLES  –  vrací i zemi, abychom mohli filtrovat   #
    # --------------------------------------------------------------- #
    def alternative_titles(self, movie_id: int,
                           *, max_items: int | None = None) -> List[Dict[str, str]]:
        """
        Vrátí seznam alternativních názvů + země původu.

        [{"title": "Cosy Dens", "country": "CA"}, …]
        Duplicitní i prázdné názvy jsou odfiltrovány; pořadí zachováno.
        """
        params = {"api_key": self.api_key}
        data   = self._get_json(f"/movie/{movie_id}/alternative_titles", params)

        out: List[Dict[str, str]] = []
        seen: set[str] = set()

        for rec in data.get("titles", []):
            title = (rec.get("title") or "").strip()
            if not title:
                continue

            norm = unicodedata.normalize("NFKC", title).lower()
            if norm in seen:
                continue
            seen.add(norm)

            out.append({"title": title, "country": rec.get("iso_3166_1", "")})
            if max_items and len(out) >= max_items:
                break
        return out



    # --------------------------------------------------------------- #
    #  COLLECTION PARTS – vrací názvy všech filmů v kolekci          #
    # --------------------------------------------------------------- #
    def collection_parts(self, coll_id: int) -> List[str]:
        """
        Načte /collection/{id} a vrátí list titulů jednotlivých dílů.
        """
        params = {"api_key": self.api_key, "language": self.lang}
        data   = self._get_json(f"/collection/{coll_id}", params)
        return [p["title"] for p in data.get("parts", []) if p.get("title")]



    def get_alt_runtimes(self, movie_id: int) -> List[int]:
        """
        Vrátí alternativní délky filmu (kino / director’s cut …) v minutách.

        Endpoint `/movie/{id}/release_dates` obsahuje pole `runtime`
        jen u některých releasů; všechny hodnoty sjednotíme do seřazeného listu.
        """
        params = {"api_key": self.api_key}
        data   = self._get_json(f"/movie/{movie_id}/release_dates", params)

        runtimes: set[int] = set()
        for rel in data.get("results", []):
            for rd in rel.get("release_dates", []):
                if (rt := rd.get("runtime")):
                    try:
                        runtimes.add(int(rt))
                    except (TypeError, ValueError):
                        pass          # ignorujeme neplatné hodnoty
        return sorted(runtimes)





    def allowed_years(  # 10-08-2025 18:26 CEST (Europe/Prague)
        self,
        movie_id: int,
        *,
        primary_year: Optional[int] = None,
        major_markets: Sequence[str] = ("US", "GB", "CA", "DE", "FR", "IT", "ES", "AU", "CZ", "SK"),
        margin: int = 1,
    ) -> List[int]:
        """
        Vrátí „povolené roky vydání“ pro film podle TMDb s následující logikou:
        • země = produkční země z `/movie/{id}`  ∪  pevný seznam hlavních trhů
        • pro každou z těchto zemí vezme nejčasnější rok z `/movie/{id}/release_dates`
        • do výstupu pustí jen roky v toleranci ±margin oproti `primary_year`
        • `primary_year` doplní z detailu, pokud není předán

        Výsledek se použije pouze ve FILTRU releasů (dotazy zůstávají s primárním rokem).
        """
        # 1) detail – získáme produkční země a případně primární rok
        params = {"api_key": self.api_key, "language": self.lang}
        det = self._get_json(f"/movie/{movie_id}", params)  # může vyhodit TMDbError
        prod_codes = {c.get("iso_3166_1", "").upper() for c in det.get("production_countries", []) if c.get("iso_3166_1")}
        if primary_year is None:
            primary_year = int((det.get("release_date") or "0000")[:4] or 0)

        # 2) release_dates – sběr roků pro relevantní země
        data = self._get_json(f"/movie/{movie_id}/release_dates", {"api_key": self.api_key})
        relevant = prod_codes | {c.upper() for c in major_markets}
        years_by_country: dict[str, int] = {}

        for rec in data.get("results", []):
            cc = (rec.get("iso_3166_1") or "").upper()
            if cc not in relevant:
                continue
            # nejčasnější datum v dané zemi
            years = []
            for rd in rec.get("release_dates", []):
                d = (rd.get("release_date") or "")[:4]
                if d.isdigit():
                    years.append(int(d))
            if years:
                years_by_country[cc] = min(years)

        # 3) sestavíme whitelist roků v toleranci ±margin
        allowed: set[int] = set()
        if primary_year:
            allowed.add(primary_year)
        for y in years_by_country.values():
            if primary_year and abs(y - primary_year) <= margin:
                allowed.add(y)

        out = sorted(y for y in allowed if y > 0)

        # log pro ladění
        try:
            self._log(
                "TMDB_ALLOWED_YEARS",
                movie_id,
                json.dumps(
                    {
                        "primary_year": primary_year,
                        "production": sorted(prod_codes),
                        "majors": sorted(relevant - prod_codes),
                        "years_by_country": {k: v for k, v in sorted(years_by_country.items())},
                        "allowed": out,
                    },
                    ensure_ascii=False,
                ),
            )
        except Exception:
            pass

        return out




