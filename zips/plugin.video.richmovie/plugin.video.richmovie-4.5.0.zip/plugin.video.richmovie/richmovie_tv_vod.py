# -*- coding: utf-8 -*-
"""Z Televize na film nebo díl z Webshare / Fastshare (plán `Handoff/PLAN_televize_vod_20261108.md` v2, §10).

Pole `vod` u pořadu posílá Gate jen při jisté shodě s TMDb. Tady je:
  • čistá logika sloupce „Dál na …“ a karty (`vod_of`, `row_fields`, `hero_fields`, `make_handoff`, `first_playable`);
  • JEDINÝ vykonavatel přechodu (`run_handoff`, `run_window_loop`). Hledání jde stávající cestou doplňku (`play_picker_first` /
    detail seriálu) — druhá kopie hledání tu není. Moderní výběr platí pro každého (`tv_origin_*`): všechna zařízení s Televizí mají
    starý vzhled a klasický výpis návrat na kanál neumí.

Okno Televize se před filmem VŽDY zavře (R-V6): druhé kolečko nad oknem = zamrznutí Kodi. Proto `open_window` jen vrátí
handoff a přechod běží až po `doModal`. Návrat (rozhodnutí Richieho O2): zavřený výběr bez přehrání = znovu Televize na tentýž
kanál; po filmu ji vrátí služba z návratové cesty (`nav_push` + `mark_play_from_ui`).
Python 3.8 (Kodi 21 Windows) → `from __future__ import annotations`.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

KINDS = ("movie", "episode", "series")
THUMB_SIZE, HERO_SIZE = "w92", "w342"
CTA_PLAY = "OK · Najít a pustit"
CTA_SERIES = "OK · Vybrat díl"
TV_ONLY = "Jen v televizi"
PENDING_WAIT_S = 0.3             # výběr streamů volá `request` synchronně v kliknutí; rezerva jen na zápis stavu


def _minutes_text(minutes: Any) -> str:
    import richmovie_livetv as tv
    return tv.minutes_text(minutes) if _positive(minutes) else ""


def _img(path: Any, size: str) -> str:
    import richmovie_ui_common as uc
    return uc.img(path, size) if path else ""


def _positive(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def vod_of(event: Any) -> Optional[Dict[str, Any]]:
    """Platné pole `vod` pořadu, jinak None (vadná odpověď = pořad jen v televizi, ne pád)."""
    vod = event.get("vod") if isinstance(event, dict) else None
    if not isinstance(vod, dict) or vod.get("kind") not in KINDS:
        return None
    tmdb = vod.get("tmdb")
    if isinstance(tmdb, bool) or not isinstance(tmdb, int) or tmdb <= 0:
        return None
    if vod["kind"] == "episode" and not (_positive(vod.get("season")) and _positive(vod.get("episode"))):
        return None
    return vod


def row_fields(event: Any) -> Dict[str, str]:
    """Vlastnosti řádku sloupce: `vod` „1“ / „“, mini plakát, plakát karty (ten se přednačítá)."""
    vod = vod_of(event)
    if vod is None:
        return {"vod": "", "thumb": "", "hero": ""}
    return {"vod": "1", "thumb": _img(vod.get("poster"), THUMB_SIZE), "hero": _img(vod.get("poster"), HERO_SIZE)}


def first_playable(events: List[Any]) -> int:
    """Index prvního řádku, který jde pustit; 0 = žádný takový, ale program je; -1 = prázdný program."""
    if not events:
        return -1
    for i, ev in enumerate(events):
        if vod_of(ev) is not None:
            return i
    return 0


def hero_fields(event: Dict[str, Any], when: str, wide_image: str) -> Dict[str, str]:
    """Karta uprostřed při fokusu na řádku: klikací = velký plakát TMDb a co jde udělat; ostatní = obrázek programu, „jen v televizi“."""
    vod = vod_of(event)
    title = str(event.get("title") or "")
    plot = str(event.get("description") or "")
    if vod is None:
        return {"vod": "", "poster": "", "wide": wide_image, "title": title, "sub": when, "plot": plot,
                "rating": "", "year": "", "runtime": "", "cta": TV_ONLY}
    rating = vod.get("rating")
    series_like = vod["kind"] in ("episode", "series")
    sub_parts = [when]
    if vod["kind"] == "episode":
        sub_parts.append("S%d E%d" % (vod["season"], vod["episode"]))
        if vod.get("ep_title"):
            sub_parts.append(str(vod["ep_title"]))
    return {"vod": "1", "poster": _img(vod.get("poster"), HERO_SIZE), "wide": "",
            "title": str((vod.get("tv_name") if series_like else vod.get("title")) or title),
            "sub": " · ".join(p for p in sub_parts if p), "plot": str(vod.get("overview") or plot),
            "rating": ("★ %.1f" % rating) if isinstance(rating, (int, float)) and not isinstance(rating, bool) and rating > 0 else "",
            "year": str(vod.get("year") or ""), "runtime": _minutes_text(vod.get("runtime")),
            "cta": CTA_SERIES if vod["kind"] == "series" else CTA_PLAY}


def make_handoff(event: Any, channel: Optional[str]) -> Optional[Dict[str, Any]]:
    """Co předat po zavření okna; None = pořad nejde pustit."""
    vod = vod_of(event)
    if vod is None or not channel:
        return None
    return {"kind": vod["kind"], "tmdb": vod["tmdb"], "season": vod.get("season"), "episode": vod.get("episode"),
            "title": str(vod.get("title") or event.get("title") or ""), "tv_name": str(vod.get("tv_name") or vod.get("title") or ""),
            "ep_title": str(vod.get("ep_title") or ""), "poster": str(vod.get("poster") or ""),
            "overview": str(vod.get("overview") or ""), "from_channel": str(channel)}


def _log(msg: str) -> None:
    """Stejný kanál jako okno Televize: zprávy dorazí do `user_logs` na NASu (měření zavřených výběrů = signál špatného párování)."""
    import richmovie_logging as rl
    rl.get_logger("richmovie.livetv").info(msg)


def _playback_pending() -> bool:
    """Rozbíhá se po zavření výběru přehrávání? Výběr se zavře dřív, než dispatcher start zapíše, proto krátce počká."""
    import xbmc
    import richmovie_playback_dispatch as dispatch
    monitor = xbmc.Monitor()
    waited = 0.0
    while waited < PENDING_WAIT_S:
        if dispatch.is_starting() or dispatch.player_present(on_error=False):
            return True
        if monitor.waitForAbort(0.1):
            return True                                  # Kodi končí: nic neotevírat
        waited += 0.1
    return False


def picker_route(h: Dict[str, Any]) -> Dict[str, Any]:
    """Parametry stávající routy hledání: film `auto`, díl `tv_play` (stejné klíče jako okno Epizody)."""
    if h["kind"] == "movie":
        return {"action": "auto", "tmdb": h["tmdb"]}
    return {"action": "tv_play", "tv_id": h["tmdb"], "tv_name": h["tv_name"], "season": str(h["season"]), "episode": h["episode"],
            "ep_title": h["ep_title"]}


def run_handoff(h: Dict[str, Any], *, addon: Any) -> bool:
    """Provede přechod z Televize. True = divák nic nepustil, otevřít znovu Televizi; False = hraje film (návrat zařídí služba)."""
    if h.get("type") == "play":
        return _run_play(h)
    import richmovie_ui_common as uc
    channel = h["from_channel"]
    uc.tv_origin_begin()                                  # z Televize vždy moderní výběr, i na účtu ve starém vzhledu (kvůli návratu)
    _log("TV_VOD_HANDOFF kind=%s tmdb=%s ch=%s" % (h["kind"], h["tmdb"], channel))
    nav_id = ""
    try:
        nav_id = uc.nav_push(action="live_home", params={"ch": channel})    # návratová cesta filmu (služba ji přehraje po konci)
        if h["kind"] == "series":
            import richmovie_detail_window
            richmovie_detail_window.open_detail(addon, tmdb_id=str(h["tmdb"]), kind="tv", title=h["tv_name"])
        else:
            route = picker_route(h)
            kind = "tv" if h["kind"] == "episode" else "movie"
            uc.play_picker_first(addon, poster=uc.img(h["poster"], HERO_SIZE), title=h["title"] if kind == "movie" else h["tv_name"],
                                 kind=kind, overview=h["overview"], **route)
    except Exception as exc:                              # každý stav má cestu ven: zpět do Televize
        _log("TV_VOD_HANDOFF failed: %r" % (exc,))
        uc.tv_origin_clear()
        return True
    finally:
        uc.nav_remove(nav_id)
    pending = _playback_pending()
    _log("TV_VOD_RETURN reason=%s ch=%s" % ("after_play" if pending else "picker_closed", channel))
    if pending:                                           # film se rozbíhá: příznak dožije krátce, klasické menu se hned vrací
        uc.tv_origin_begin(uc.TV_ORIGIN_START_S)
    else:
        uc.tv_origin_clear()
    return not pending


def make_play_handoff(offer: Dict[str, Any], resume_s: int, channel: Optional[str]) -> Dict[str, Any]:
    """Přijatá nabídka lepší verze: přehrát tenhle stream, případně od odhadnutého místa."""
    return {"type": "play", "kind": offer["kind"], "tmdb": offer.get("tmdb"), "title": offer["title"], "url": offer["url"],
            "key": offer["key"], "ident": offer["ident"], "resume_s": max(0, int(resume_s or 0)),
            "runtime_s": offer.get("runtime_s") or 0, "from_channel": channel or offer["channel"]}


def _run_play(h: Dict[str, Any]) -> bool:
    """Přehraje přijatou nabídku. True = nespustilo se (zpět do Televize); False = hraje (návrat po filmu zařídí služba)."""
    import richmovie_feedback as fb
    import richmovie_playback_dispatch as dispatch
    import richmovie_resume as resume
    import richmovie_ui_common as uc
    channel, start = h["from_channel"], int(h["resume_s"])
    nav_id = ""
    try:
        nav_id = uc.nav_push(action="live_home", params={"ch": channel})
        uc.mark_play_from_ui()                         # snímek návratu: Televize na tomtéž kanálu
        if start > 0:
            resume.publish_request(start, ident=h["ident"], runtime_s=h["runtime_s"], source=resume.SOURCE_TV, key=h["key"])
        sent = dispatch.request("%s&origin_start=%d" % (h["url"], start), source="tv_offer", key=h["key"], ident=h["ident"], noresume=True)
    except Exception as exc:                           # každý stav má cestu ven: zpět do Televize
        _log("TV_VOD_OFFER_PLAY failed: %r" % (exc,))
        uc.consume_return_route()
        return True
    finally:
        uc.nav_remove(nav_id)
    _log("TV_VOD_OFFER_PLAY sent=%s kind=%s tmdb=%s start=%d ch=%s" % (sent, h["kind"], h["tmdb"], start, channel))
    if not sent:
        if start > 0:
            resume.clear_request()                     # jinak by odhad z vysílání navázal příští přehrání téhož titulu
        uc.consume_return_route()                      # a návratová cesta by po příštím filmu otevřela Televizi
        fb.info("Teď to nejde spustit, vracím tě do Televize.")
    return not sent


def run_window_loop(channel: Optional[str], *, addon: Any) -> None:
    """Okno Televize a přechody z něj. Každý další průchod spustil divák (klik v okně), takže smyčka nemůže běžet sama."""
    import richmovie_tv_window as tv
    import richmovie_ui_common as uc
    while True:
        uc.tv_origin_clear()                              # zpět v Televizi: tok na film skončil
        handoff = tv.open_window(channel=channel)
        if not handoff:
            return
        channel = handoff.get("from_channel") or channel
        if not run_handoff(handoff, addon=addon):
            return
