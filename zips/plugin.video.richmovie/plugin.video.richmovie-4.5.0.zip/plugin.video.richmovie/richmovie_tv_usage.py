# -*- coding: utf-8 -*-
"""Chytré řazení kanálů „Pro tebe“, které se učí — per profil (Televize 4.3.0, plán `Handoff/PLAN_televize_430_20261108.md` P3).

Petra (přes Richieho 08.11.2026): „seznam programů by se měl chytře řadit podle počtu otevření, ale i podle doby sledování
… aby se tam postupně nahoře plnily a realtime posouvaly programy, kde je pravděpodobnost, že to klikne … který se učí a je
per profil.“

MODEL (čistý — bez Kodi, bez sítě; harness scénář 116):
  • signály zná okno Televize přesně: sledování kanálu (sekundy OBRAZU, pauza se nepočítá), otevření = obraz běžel aspoň
    `MIN_WATCH_S` (zapínání kanálů při listování se nepočítá), část dne (ráno / den / večer / noc);
  • pro kanál exponenciálně stárnoucí součty (poločas `HALF_LIFE_DAYS`): minuty, otevření, minuty po částech dne — starý
    zvyk vyprchá, nový se naučí za pár dní;
  • skóre = log1p(minuty) + `OPEN_WEIGHT` · log1p(otevření) + `DAYPART_WEIGHT` · podíl kanálu v aktuální části dne
    (večerní zprávy večer výš, pohádky ráno);
  • pořadí: skóre sestupně, remíza = osobní pořadí (stabilní); HYSTEREZE proti minulému pořadí — dva sousedé se prohodí
    jen při rozdílu skóre ≥ `HYSTERESIS` → seznam neposkakuje; kanály bez historie za nimi v osobním pořadí;
  • výchozí čip „Pro tebe“ až s historií aspoň `MIN_CHANNELS_FOR_DEFAULT` kanálů (jinak „Vše“).
ÚLOŽIŠTĚ: osobní soubor profilu `tv_usage.json` (`richmovie_paths.PERSONAL_FILES`) — per profil na zařízení; zápis jen okno
Televize (jediný zapisovatel), atomicky pod `personal_lock`; nečitelný soubor = NIC nepřepsat (R2), poškozený = karanténa
`richmovie_atomic` a prázdná historie. Synchronizace mezi zařízeními profilu = další krok (sčítaná data nesnesou LWW).
Python 3.8 (Kodi 21 Windows) → `from __future__ import annotations`.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Sequence

FILE_NAME = "tv_usage.json"
VERSION = 1
HALF_LIFE_DAYS = 21.0          # zvyk se „zapomíná“ s poločasem 3 týdny
MIN_WATCH_S = 10.0             # = `richmovie_livetv_prefs.LAST_MIN_WATCH_S` (scénář 116 hlídá paritu)
SESSION_CAP_S = 4 * 3600.0     # jedno sledování se počítá nejvýš 4 h (usnutí u televize nezkreslí pořadí)
OPEN_WEIGHT = 0.5
DAYPART_WEIGHT = 1.0
DAYPART_PRIOR_MIN = 30.0       # bonus části dne roste s množstvím dat: share · m / (m + 30 min) (cross-check N4)
HYSTERESIS = 0.10              # soused se předběhne jen o ≥ 10 % vyšším skóre
MIN_CHANNELS_FOR_DEFAULT = 3   # „Pro tebe“ jako výchozí až s historií aspoň 3 kanálů
MIN_MINUTES_COUNTED = 1.0      # kanál „má historii“ od 1 (stárnoucí) minuty
MAX_CHANNELS = 500             # strop záznamů (175 kanálů dnes); nad ním odpadnou nejslabší
DAYPARTS = ((5, 11), (11, 17), (17, 22), (22, 5))   # ráno, den, večer, noc (hodiny místního času, konec bez)
_DAY_S = 86400.0


def daypart(hour: int) -> int:
    """Index části dne pro hodinu místního času (0–23)."""
    h = int(hour) % 24
    for i, (a, b) in enumerate(DAYPARTS):
        if (a <= h < b) if a < b else (h >= a or h < b):
            return i
    return 0


def _decay_factor(dt_s: float) -> float:
    """Stárnutí za `dt_s` sekund; posun hodin zpět (dt < 0) = beze změny (nikdy „omládnutí“)."""
    if dt_s <= 0:
        return 1.0
    return 0.5 ** (dt_s / (HALF_LIFE_DAYS * _DAY_S))


def _num(value: Any) -> Optional[float]:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        return None
    return float(value)


def normalize(raw: Any) -> Dict[str, Any]:
    """Soubor → platný stav `{"v": 1, "ch": {kanál: {"t", "m", "o", "d": [4]}}}`; vadné záznamy vypadnou (ne celý soubor)."""
    out: Dict[str, Any] = {"v": VERSION, "ch": {}}
    chans = raw.get("ch") if isinstance(raw, dict) and raw.get("v") == VERSION else None
    if not isinstance(chans, dict):
        return out
    for ch, rec in chans.items():
        if not isinstance(ch, str) or not ch or len(ch) > 64 or not isinstance(rec, dict):
            continue
        t, m, o = _num(rec.get("t")), _num(rec.get("m")), _num(rec.get("o"))
        d = rec.get("d")
        if t is None or m is None or o is None or not isinstance(d, list) or len(d) != len(DAYPARTS):
            continue
        parts = [_num(x) for x in d]
        if any(x is None for x in parts):
            continue
        out["ch"][ch] = {"t": t, "m": m, "o": o, "d": parts}
    return out


def _aged(rec: Dict[str, Any], now: float) -> Dict[str, Any]:
    f = _decay_factor(now - rec["t"])
    return {"t": max(now, rec["t"]), "m": rec["m"] * f, "o": rec["o"] * f, "d": [x * f for x in rec["d"]]}


def add_watch(state: Dict[str, Any], ch: str, seconds: float, now: float, hour: int, *, opened: bool) -> Dict[str, Any]:
    """Nový stav se započteným sledováním (vstup se nemění). `seconds` = sekundy OBRAZU od minulého zápisu (strop
    `SESSION_CAP_S`); `opened` = toto sledování se právě stalo „otevřením“ (obraz běžel ≥ `MIN_WATCH_S`)."""
    sec = _num(seconds)
    if not ch or sec is None or (sec <= 0 and not opened):
        return state
    sec = min(sec, SESSION_CAP_S)
    chans = dict(state.get("ch") or {})
    rec = chans.get(ch) or {"t": now, "m": 0.0, "o": 0.0, "d": [0.0] * len(DAYPARTS)}
    rec = _aged(rec, now)
    minutes = sec / 60.0
    rec["m"] += minutes
    rec["d"][daypart(hour)] += minutes
    if opened:
        rec["o"] += 1.0
    chans[ch] = rec
    if len(chans) > MAX_CHANNELS:                     # právě sledovaný kanál se nevyřazuje (cross-check N1)
        others = [c for c in chans if c != ch]
        weakest = sorted(others, key=lambda c: (score(chans[c], now, hour), c))[: len(chans) - MAX_CHANNELS]
        for c in weakest:
            chans.pop(c, None)
    return {"v": VERSION, "ch": chans}


def score(rec: Optional[Dict[str, Any]], now: float, hour: int) -> float:
    """Pravděpodobnost kliknutí (relativní): minuty + otevření + podíl v aktuální části dne; bez historie 0."""
    if not rec:
        return 0.0
    r = _aged(rec, now)
    if r["m"] < MIN_MINUTES_COUNTED and r["o"] < 1.0:
        return 0.0
    share = r["d"][daypart(hour)] / r["m"] if r["m"] > 0 else 0.0
    share *= r["m"] / (r["m"] + DAYPART_PRIOR_MIN)   # málo dat = malý bonus části dne
    return math.log1p(r["m"]) + OPEN_WEIGHT * math.log1p(r["o"]) + DAYPART_WEIGHT * share


def has_history(state: Dict[str, Any], channels: Sequence[str], now: float, hour: int) -> bool:
    """Má profil dost historie pro výchozí „Pro tebe“ (kanály z viditelného seznamu)?"""
    chans = state.get("ch") or {}
    return sum(1 for c in channels if score(chans.get(c), now, hour) > 0) >= MIN_CHANNELS_FOR_DEFAULT


def ranking(state: Dict[str, Any], channels: Sequence[str], now: float, hour: int,
            previous: Optional[Sequence[str]] = None) -> List[str]:
    """Pořadí „Pro tebe“ nad viditelnými kanály (osobní pořadí `channels`, skryté v něm nejsou): kanály s historií podle
    skóre (remíza = osobní pořadí), pak ostatní v osobním pořadí. S `previous` (minulé pořadí) hystereze: soused se
    předběhne jen o ≥ `HYSTERESIS` vyšším skóre — opakované řazení stejných dat je stálé, seznam neposkakuje."""
    chans = state.get("ch") or {}
    pos = {c: i for i, c in enumerate(channels)}
    scored = {c: score(chans.get(c), now, hour) for c in channels}
    learned = [c for c in channels if scored[c] > 0]
    rest = [c for c in channels if scored[c] <= 0]
    if previous:
        prev_pos = {c: i for i, c in enumerate(previous)}
        order = sorted(learned, key=lambda c: (prev_pos.get(c, len(prev_pos) + pos[c]), pos[c]))
        factor = 1.0 + max(0.0, HYSTERESIS)             # práh ≥ 0: prohození vždy předřadí VYŠŠÍ skóre → konečné
        changed = True
        while changed:                                  # vkládací průchody: jen výrazně lepší soused předběhne
            changed = False
            for i in range(len(order) - 1):
                a, b = order[i], order[i + 1]
                if scored[b] > scored[a] * factor:
                    order[i], order[i + 1] = b, a
                    changed = True
    else:
        order = sorted(learned, key=lambda c: (-scored[c], pos[c]))
    return order + rest


# ── soubor profilu (I/O) — zápis jen okno Televize, pod `personal_lock`; nečitelný soubor = nic nepřepsat (R2) ────────
def _path() -> str:
    import richmovie_paths as RP
    return str(RP.personal_path(FILE_NAME))


def load() -> Optional[Dict[str, Any]]:
    """Stav profilu; `None` = soubor nejde přečíst (I/O) → okno se neučí, aby nepřepsalo historii prázdnou (R2).
    Poškozený soubor jde do karantény `richmovie_atomic` → prázdná historie (učení začne znovu)."""
    import richmovie_atomic as _atomic
    data, st = _atomic.read_json(_path(), None, name="tv_usage", expected_type=dict)
    if st == _atomic.STATE_UNREADABLE:
        return None
    return normalize(data)


def save(state: Dict[str, Any]) -> bool:
    """Atomický zápis pod zámkem osobního souboru (stejný zámek jako jiné zápisy profilu)."""
    import richmovie_atomic as _atomic
    import richmovie_paths as RP
    try:
        with RP.personal_lock(FILE_NAME):
            return bool(_atomic.write_json(_path(), state, indent=None))
    except Exception:
        return False
