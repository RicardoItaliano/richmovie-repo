# -*- coding: utf-8 -*-
"""Stavový automat okna Televize (08.11.2026, plán `Handoff/PLAN_televize_F4_20261108.md` §3.4–§3.7, §4, §5).

Čistý modul — žádné importy Kodi, žádné `time.sleep`, čas dostává každá metoda jako parametr (`now`, sekundy monotónních
hodin). Okno (`richmovie_tv_window`) převádí klávesy, myš a události služby na vstupy automatu a provádí jeho POVELY;
všechna rozhodnutí („co znamená ▲ teď“, „kdy naladit“, „co dělá Zpět“, „kdy uvolnit pauzu“) žijí TADY — testuje je
harness (`_tools/net_resilience_sim`, scénář 106) včetně negativních mutací.

Vrstvy (nejvyšší vyhrává pro Zpět): `number` (zadávání čísla) › `reorder` (přesun kanálu v panelu) › `panel` (postranní
panel) › `card` (karta stavu: ladím / chyba / plno) › `bar` (info lišta) › `clean` (čistý obraz).

Povely (`Effect`): `bar_show(ch)` · `bar_hide` · `panel_open(ch)` · `panel_close` · `tune(ch)` (vyhrává poslední stisk — okno
předá dispatcheru) · `number_show(digits)` · `number_hide` · `leave` (odejít z Televize) · `mute(on)` · `pause(on)` ·
`pause_release` (pauza moc dlouhá → zastavit a uvolnit místo na NASu) · `normalize_speed` · `retune(ch, attempt)` ·
`error_card(ch, code)` · `idle_ask` · `reorder_start(ch)` · `reorder_move(ch, delta)` · `reorder_commit(ch)` ·
`reorder_cancel(ch)` · `panel_focus(ch)`.
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

# ── časy (laditelné z jednoho místa; hodnoty z plánu §3.5, §3.6, §4.2, §4.7, §3.7) ──
PRESELECT_S = 0.7          # ▲▼ v obraze: lišta hned, naladění po klidu (OK = hned) — M1 doladí
NUMBER_S = 1.5             # zadávání čísla: potvrzení po klidu
NUMBER_MAX_DIGITS = 3
BAR_S = 5.0                # info lišta sama odjede
PAUSE_RELEASE_S = 120.0    # R-2 (Richie 08.11.): pauza drží obraz nejvýš 2 min, pak uvolní místo na NASu
IDLE_ASK_S = 4 * 3600.0    # „Díváš se ještě?“ po 4 h bez vstupu
RETUNE_DELAYS_S = (1.0, 3.0, 6.0)   # tiché přeladění po chybě / konci relace — nejvýš 3 pokusy
OPENING_TIMEOUT_S = 20.0   # otevírání bez zprávy služby (obraz / chyba) déle než tohle = uvolnit (čekající odejde)
NO_RETRY_CODES = ("slots_full", "rate_limited", "channel_unavailable", "feature_not_allowed", "identity_rejected",
                  "no_identity", "nas_unreachable")   # 409 / 429 / trvalé chyby se automaticky NIKDY neopakují

CLEAN, BAR, PANEL, CARD, REORDER, NUMBER = "clean", "bar", "panel", "card", "reorder", "number"

Effect = Tuple[str, dict]


def _fx(name: str, **kw) -> Effect:
    return (name, kw)


class TvState(object):
    """Jedna instance na otevřené okno Televize. `channels` = viditelné kanály v osobním pořadí (číslo kanálu = index + 1,
    rozhodnutí Richieho R-3)."""

    def __init__(self, channels: Sequence[str], focus: Optional[str], now: float) -> None:
        """`focus` = KURZOR panelu (poslední kanál / první oblíbený / první v seznamu) — NIC se tím nenaladí.
        Naladěný kanál (`current`) vzniká jen `start` / OK / číslem / předvýběrem (oprava 08.11.2026: kurzor brán
        jako naladěný → OK na prvním kanálu nic neudělalo, Richie: „pustil jsem Novu a nic, jen černá obrazovka“)."""
        self.channels: List[str] = [c for c in channels if c]
        self.current: Optional[str] = None     # kanál, který divák zvolil (otevírá se / hraje / naposledy selhal)
        self.on_air = False                    # obraz `current` se otevírá nebo hraje (konečná chyba → False)
        self.previous: Optional[str] = None
        self.playing: Optional[str] = None     # kanál, jehož obraz OPRAVDU naskočil (`playback_started`); konečná chyba,
                                               # uvolněná pauza → None. Odmítnutý tiket se vrací JEN k němu (cross-check H1-a)
        self.layer = CLEAN
        self.preselect: Optional[str] = None
        self.preselect_at = 0.0
        self.panel_focus: Optional[str] = focus if focus in self.channels else (self.channels[0] if self.channels else None)
        self.digits = ""
        self.digits_at = 0.0
        self.bar_until = 0.0
        self.paused_at: Optional[float] = None
        self.released = False             # pauza překročila limit → přehrávač zastaven, místo uvolněno
        self.last_input = now
        self.retune_attempt = 0
        self.retune_due: Optional[float] = None
        self.idle_asked = False
        self.reorder_origin: Optional[int] = None
        self.opening: Optional[str] = None    # kanál, jehož otevírání běží (nejvýš JEDNO — scénář 99)
        self.opening_at = 0.0
        self.offer_ready = False              # visí nabídka lepší verze: ▶ v obraze ji otevře (okno jen zobrazuje)
        self.pending: Optional[str] = None    # naladění během otevírání — vyhrává poslední stisk

    # ── pomocné ────────────────────────────────────────────────────────────────────────────────────────────────
    def set_channels(self, channels: Sequence[str]) -> None:
        """Nový viditelný seznam (osobní pořadí, skryté, data z jiného zařízení) — aktuální kanál zůstává, i když zmizel.
        Kurzor panelu bez platného kanálu (okno otevřené nad prázdným seznamem, kanál zmizel) → první viditelný (4.2.1)."""
        self.channels = [c for c in channels if c]
        keep = self.panel_focus is not None and (self.panel_focus in self.channels or self.panel_focus == self.current)
        if not keep:
            self.panel_focus = self.current or (self.channels[0] if self.channels else None)

    def number_of(self, ch: Optional[str]) -> int:
        return self.channels.index(ch) + 1 if ch in self.channels else 0

    def _neighbour(self, ch: Optional[str], delta: int) -> Optional[str]:
        if not self.channels:
            return None
        if ch not in self.channels:
            return self.channels[0]
        return self.channels[(self.channels.index(ch) + delta) % len(self.channels)]

    def no_picture(self) -> bool:
        """Za panelem / lištou není živý obraz: nic se ještě neladilo, kanál skončil konečnou chybou, nebo první tiket
        odmítnut. (Uvolněná pauza obraz nemá také, ale drží ji vlastní karta okna — `released`.)"""
        return self.current is None or not self.on_air

    def _rest(self) -> List[Effect]:
        """Konec dočasné vrstvy (lišta, karta, číslo): s obrazem čistý obraz, BEZ obrazu panel — nikdy černá plocha
        bez ovládání (slepá ulička 08.11.2026)."""
        if self.no_picture() and not self.released:
            return self._open_panel()
        self.layer = CLEAN
        return []

    def _input(self, now: float) -> None:
        self.last_input = now
        self.idle_asked = False

    def _emit_tune(self, ch: str, now: float) -> List[Effect]:
        """Jediné místo efektu `tune`: běží-li otevírání jiného kanálu, cíl se jen zapamatuje (vyhrává poslední stisk,
        nikdy dvě otevírání naráz — každé = nová relace u poskytovatele a místo ve skupině)."""
        if self.opening is not None and self.opening != ch:
            self.pending = ch
            return []
        if self.opening == ch:
            self.pending = None
            return []
        self.opening, self.opening_at, self.pending = ch, now, None
        return [_fx("tune", ch=ch)]

    def _opening_done(self, ch: Optional[str], now: float) -> List[Effect]:
        """Otevírání skončilo (obraz, chyba, vypršení) → čekající kanál, je-li jiný, odejde jedním naladěním."""
        if ch is not None and self.opening not in (None, ch):
            return []                         # zpráva k jinému (staršímu) otevírání
        self.opening = None
        target, self.pending = self.pending, None
        if target is None or target == ch:
            return []
        return self._emit_tune(target, now)

    def _tune(self, ch: Optional[str], now: float) -> List[Effect]:
        """Naladit `ch` (už naladěný a s obrazem = jen lišta). Zruší předvýběr, pauzu i plán přeladění."""
        self.preselect = None
        if ch is None:
            return []
        out: List[Effect] = []
        if ch != self.current or not self.on_air or self.released or self.paused_at is not None:
            if ch != self.current:
                self.previous = self.current
            self.current = ch
            self.paused_at = None
            self.released = False
            self.retune_attempt = 0
            self.retune_due = None
            self.on_air = True
            out += self._emit_tune(ch, now)
        out.append(_fx("bar_show", ch=ch))
        self.layer = BAR if self.layer in (CLEAN, BAR, CARD) else self.layer
        self.bar_until = now + BAR_S
        return out

    # ── vstupy ─────────────────────────────────────────────────────────────────────────────────────────────────
    def key(self, name: str, now: float, digit: Optional[int] = None) -> List[Effect]:
        """Klávesa / akce: `up` `down` `left` `right` `select` `back` `ch_up` `ch_down` `digit` `mute` `pause` `play`
        `info` `menu` `ff` `rw` `hot_edge` `away` (myš pryč z panelu / klik do videa). Neznámá = nic (žádná přetáčecí
        akce okno nemá — posun vypnutý, §3.4). Bez obrazu (`no_picture`) je domovem panel — nikdy černá plocha."""
        self._input(now)
        if name == "digit" and digit is not None:
            return self._digit(int(digit), now)
        if self.layer == NUMBER:
            return self._key_number(name, now)
        if self.layer == REORDER:
            return self._key_reorder(name, now)
        if self.layer == PANEL:
            return self._key_panel(name, now)
        return self._key_screen(name, now)

    def _key_screen(self, name: str, now: float) -> List[Effect]:
        if name in ("up", "ch_up", "down", "ch_down"):
            base = self.preselect or self.current or self.panel_focus    # bez naladěného kanálu od kurzoru
            target = self._neighbour(base, -1 if name in ("up", "ch_up") else 1)
            if target is None:
                return []
            self.preselect, self.preselect_at = target, now
            self.layer, self.bar_until = BAR, now + BAR_S
            return [_fx("bar_show", ch=target)]
        if name in ("pause", "play") and self.no_picture() and not self.released:
            return []                                     # bez obrazu není co pozastavit ani pustit
        if name == "select":
            if self.preselect:
                return self._tune(self.preselect, now)
            if self.released or self.paused_at is not None:
                return self._tune(self.current, now)      # pokračování = vždy živé vysílání (R-2)
            return self._open_panel()
        if name == "right" and self.offer_ready and not self.preselect:
            return [_fx("offer_open")]             # OK dál otevírá panel: ▶ je volné, omylem se z živého nic nepřepne (O4)
        if name in ("left", "hot_edge", "menu"):
            return self._open_panel()
        if name == "info" and self.no_picture() and not self.released:
            return self._open_panel()              # lišta o ničem by nic neřekla — bez obrazu je domovem panel
        if name == "info":
            self.layer, self.bar_until = BAR, now + BAR_S
            return [_fx("bar_show", ch=self.current)]
        if name == "back":
            if self.preselect:
                self.preselect = None
                return [_fx("bar_hide")] + self._rest()
            if self.layer in (BAR, CARD):
                return [_fx("bar_hide")] + self._rest()
            if self.no_picture() and not self.released:
                return self._open_panel()          # čistý obraz bez obrazu (pojistka) = zpět do panelu
            return [_fx("leave")]
        if name == "mute":
            return [_fx("mute_toggle")]
        if name == "pause":
            if self.paused_at is None and not self.released:
                self.paused_at = now
                return [_fx("pause", on=True), _fx("bar_show", ch=self.current)]
            return self._tune(self.current, now)
        if name == "play":
            if self.paused_at is not None or self.released:
                return self._tune(self.current, now)
            return []
        if name in ("ff", "rw"):
            return [_fx("normalize_speed")]                # přetáčení v živém vysílání neexistuje (§3.4)
        return []

    def _open_panel(self) -> List[Effect]:
        """Panel se otevře na zvoleném kanálu; bez něj na kurzoru (poslední / první oblíbený / první kanál)."""
        self.preselect = None
        self.layer = PANEL
        self.panel_focus = (self.current or self.panel_focus
                            or (self.channels[0] if self.channels else None))
        return [_fx("panel_open", ch=self.panel_focus)]

    def _key_panel(self, name: str, now: float) -> List[Effect]:
        if name in ("up", "down", "ch_up", "ch_down"):
            target = self._neighbour(self.panel_focus or self.current, -1 if name in ("up", "ch_up") else 1)
            self.panel_focus = target
            return [_fx("panel_focus", ch=target)] if target else []
        if name == "select":
            target = self.panel_focus or self.current
            if target is None:
                return []                         # prázdný seznam — panel zůstává (H1-c)
            self.layer = BAR
            return [_fx("panel_close")] + self._tune(target, now)
        if name in ("back", "right", "away"):      # away = myš pryč z panelu / klik do videa (okno)
            if self.released:
                self.layer = CLEAN                # uvolněná pauza: zpět na její kartu (okno ji drží, OK = živě)
                return [_fx("panel_close"), _fx("release_card", ch=self.current)]
            if self.no_picture():
                return [_fx("leave")] if name == "back" else []   # bez obrazu je domovem panel: Zpět = ven
            self.layer = CLEAN
            return [_fx("panel_close")]
        if name == "menu":
            return []           # akce kanálu (★, skrýt, přesunout) řeší okno nad zaměřeným řádkem
        if name == "mute":
            return [_fx("mute_toggle")]
        return []

    def start_reorder(self, now: float) -> List[Effect]:
        """Panel → „Přesunout“ nad zaměřeným kanálem."""
        self._input(now)
        if self.layer != PANEL or not self.panel_focus or self.panel_focus not in self.channels:
            return []
        self.layer = REORDER
        self.reorder_origin = self.channels.index(self.panel_focus)
        return [_fx("reorder_start", ch=self.panel_focus)]

    def _key_reorder(self, name: str, now: float) -> List[Effect]:
        ch = self.panel_focus
        if ch is None or ch not in self.channels:
            self.layer = PANEL
            return []
        if name in ("up", "down", "ch_up", "ch_down"):
            delta = -1 if name in ("up", "ch_up") else 1
            i = self.channels.index(ch)
            j = i + delta
            if not 0 <= j < len(self.channels):
                return []
            self.channels[i], self.channels[j] = self.channels[j], self.channels[i]
            return [_fx("reorder_move", ch=ch, delta=delta)]
        if name == "select":
            self.layer = PANEL
            self.reorder_origin = None
            return [_fx("reorder_commit", ch=ch)]
        if name == "back":
            if self.reorder_origin is not None:
                self.channels.remove(ch)
                self.channels.insert(self.reorder_origin, ch)
            self.layer = PANEL
            self.reorder_origin = None
            return [_fx("reorder_cancel", ch=ch)]
        return []

    def _digit(self, d: int, now: float) -> List[Effect]:
        if self.layer in (PANEL, REORDER):
            return []
        if not self.digits and d == 0:
            # „0“ samotná = předchozí kanál
            return self._tune(self.previous, now) if self.previous else []
        cancel = [_fx("bar_hide")] if self.preselect else []
        self.preselect = None                     # číslo má přednost před předvýběrem šipkou (Fable W-4: dvě naladění)
        self.digits = (self.digits + str(d))[:NUMBER_MAX_DIGITS]
        self.digits_at = now
        self.layer = NUMBER
        out = cancel + [_fx("number_show", digits=self.digits)]
        if len(self.digits) >= NUMBER_MAX_DIGITS or int(self.digits) * 10 > len(self.channels):
            out += self._commit_number(now)       # další číslice by vedla mimo seznam → potvrdit hned
        return out

    def _key_number(self, name: str, now: float) -> List[Effect]:
        if name == "select":
            return self._commit_number(now)
        if name == "back":
            self.digits = ""
            return [_fx("number_hide")] + self._rest()
        return []

    def _commit_number(self, now: float) -> List[Effect]:
        n = int(self.digits) if self.digits else 0
        self.digits = ""
        self.layer = CLEAN
        out = [_fx("number_hide")]
        if 1 <= n <= len(self.channels):
            out += self._tune(self.channels[n - 1], now)
        else:
            out += self._rest()                   # číslo mimo seznam: bez obrazu zpět do panelu
        return out

    # ── čas a události služby ──────────────────────────────────────────────────────────────────────────────────
    def tick(self, now: float, *, paused: bool = False, speed: float = 1.0) -> List[Effect]:
        """Tik okna (à 250 ms): vypršení předvýběru, čísla, lišty, pauzy, přeladění, nečinnosti; politika přehrávání."""
        out: List[Effect] = []
        if self.preselect and now - self.preselect_at >= PRESELECT_S:
            out += self._tune(self.preselect, now)
        if self.layer == NUMBER and self.digits and now - self.digits_at >= NUMBER_S:
            out += self._commit_number(now)
        if self.layer == BAR and now >= self.bar_until and not self.preselect:
            out.append(_fx("bar_hide"))
            out += self._rest()
        if paused and self.paused_at is None and not self.released:
            self.paused_at = now                  # pauza klávesou mimo okno (ovladač, myš Kodi)
        if not paused and self.paused_at is not None and not self.released:
            self.paused_at = None
        if self.paused_at is not None and not self.released and now - self.paused_at >= PAUSE_RELEASE_S:
            self.released = True
            self.playing = None                   # přehrávač zastaven, místo uvolněno
            out.append(_fx("pause_release"))
        if not paused and not self.released and speed not in (0.0, 1.0):
            out.append(_fx("normalize_speed"))    # FF / RW přes klávesu Kodi → zpět na živé
        if self.opening is not None and now - self.opening_at >= OPENING_TIMEOUT_S:
            if self.pending is not None:          # služba se neozvala, divák už chce jiný kanál → naladit ten
                out += self._opening_done(self.opening, now)
            else:                                 # „nenaladil se“ = stav automatu (karta, bez obrazu panel) — Fable W-2
                out += self.tune_rejected(now, "open_timeout")
        if self.retune_due is not None and now >= self.retune_due and self.current:
            self.retune_due = None
            self.opening, self.opening_at = self.current, now   # přeladění = otevírání (přepnutí během něj čeká)
            out.append(_fx("retune", ch=self.current, attempt=self.retune_attempt))
        if not self.idle_asked and now - self.last_input >= IDLE_ASK_S:
            self.idle_asked = True
            out.append(_fx("idle_ask"))
        return out

    def playback_failed(self, now: float, code: str = "") -> List[Effect]:
        """Služba: kanál skončil chybou / koncem relace (404 relay po restartu, výpadek sítě). Přeladění nejvýš 3×
        s odstupem; kódy, které se nesmí opakovat (409, 429, trvalé), = karta s větou hned."""
        self.playing = None                       # přehrávač skončil chybou — obraz už není (H1-a)
        if self.pending is not None:
            return self._opening_done(self.opening, now)    # divák už chce jiný kanál — žádné přeladění starého
        self.opening = None
        if self.released or not self.current or not self.on_air:
            return []                             # obraz už neběží (konečná chyba hlášena) — žádná další karta
        if code in NO_RETRY_CODES or self.retune_attempt >= len(RETUNE_DELAYS_S):
            self.retune_due = None
            self.on_air = False                   # konečná chyba → OK na tentýž kanál = nové naladění
            self.layer = CARD
            return [_fx("error_card", ch=self.current, code=code or "livetv_error")]
        self.retune_due = now + RETUNE_DELAYS_S[self.retune_attempt]
        self.retune_attempt += 1
        return []

    def start(self, ch: Optional[str], now: float) -> List[Effect]:
        """Otevření okna: PRVNÍ naladění (poslední kanál / `live_play&ch=`) — i když je `ch` v automatu už `current`
        (konstruktor naladění nevyvolá). Kanál mimo viditelný seznam (skrytý, z Oblíbených Kodi) se naladí také."""
        target = ch or self.panel_focus or (self.channels[0] if self.channels else None)
        if target is None:
            return []
        if target != self.current:
            self.previous = self.current
        self.current = target
        self.on_air = True
        self.released = False
        self.paused_at = None
        self.retune_attempt = 0
        self.retune_due = None
        self._input(now)
        out = self._emit_tune(target, now)
        out.append(_fx("bar_show", ch=target))
        self.layer = BAR
        self.bar_until = now + BAR_S
        return out

    def tune_rejected(self, now: float, code: str = "") -> List[Effect]:
        """Tiket Gate pro nový kanál selhal (409 plno, kanál nedostupný, NAS mimo dosah…) a STARÝ kanál hraje dál:
        `current` zpět na hrající kanál (číslo, „0“, ▲▼ i „● hraje“ nelžou), karta s větou nemodálně (plán §4.6).
        Chce-li divák mezitím už jiný kanál (čekající), naladí se ten — karta o odmítnutém by jen překážela."""
        rejected = self.current
        self.opening = None
        if self.pending is not None:
            target, self.pending = self.pending, None
            return self._emit_tune(target, now)
        if self.playing is not None:              # obraz, který OPRAVDU hraje, hraje dál (i nový tiket téhož kanálu)
            if self.playing != rejected:
                self.previous = rejected
            self.current, self.on_air = self.playing, True
        else:                                     # nic nehraje (první tiket, jen otevírání, chyba) → nic naladěno,
            self.current, self.on_air, self.panel_focus = None, False, rejected   # kurzor panelu na odmítnutém
        self.layer = CARD
        return [_fx("error_card", ch=rejected, code=code or "livetv_error")]

    def play_sent(self, ch: str) -> List[Effect]:
        """Okno odeslalo kanál přehrávači (`request_live` = „sent“): Kodi dosavadní obraz NAHRADÍ — i když se nový
        neotevře, starý se nevrátí → odmítnutí ani vypršení se k němu už nevrací (audit Fable W-3)."""
        self.playing = None
        return []

    def data_failed(self) -> List[Effect]:
        """Seznam kanálů se nepodařilo načíst a v zařízení žádný není: prázdný panel ustoupí kartě okna s volbami
        (Zkusit znovu / Odejít) — NIKDY tichý odchod (audit Fable W-1; Zpět z panelu bez obrazu = odchod)."""
        if self.layer != PANEL:
            return []
        self.layer = CARD
        return [_fx("panel_close")]

    def set_panel_focus(self, ch: Optional[str]) -> List[Effect]:
        """Panel: ▲▼, kolečko, klik i filtr čipů řídí NATIVNÍ seznam Kodi (plynulý posun, myš, filtrovaný pohled) —
        okno automatu jen hlásí, na kterém kanálu fokus stojí (pro `select` a `start_reorder`). Ve vrstvě přesunu pořadí
        drží automat (▲▼ posouvá kanál) → hlášení se ignoruje."""
        if self.layer == PANEL and ch:
            self.panel_focus = ch
        return []

    def time_jump(self, now: float) -> List[Effect]:
        """Skok pozice mimo okno (SkipNext / SkipPrevious, přetočení klávesou Kodi): Televize je jen živá (posun vypnutý,
        plán §3.4 (2)) → nový tiket téhož kanálu = zpět na živé. Pozastavené / uvolněné / otevírající se = nic."""
        if self.no_picture() or self.released or self.paused_at is not None or self.opening is not None:
            return []
        return self._emit_tune(self.current, now)

    def playback_started(self, ch: str, now: float = 0.0) -> List[Effect]:
        """Služba: obraz naskočil — přeladění uspělo; čekající kanál (divák mezitím přepnul) odejde hned."""
        self.playing = ch                         # obraz naskočil — jediná pravda „co opravdu hraje“
        if self.current is None or not self.on_air:   # obraz po vypršení / odmítnutí přece naskočil → hraje on
            self.current, self.on_air = ch, True
        if ch == self.current:
            self.retune_attempt = 0
            self.retune_due = None
        return self._opening_done(ch, now)
