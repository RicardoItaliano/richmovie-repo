# -*- coding: utf-8 -*-
"""SSOT dat Televize v zařízení — kanály a „teď / potom“ z disku, obnova s ETagem (plán F4 §3.8, scénář 101; 08.11.2026).

Okno Televize startuje Z MEZIPAMĚTI (žádné čekání na síť) a hned obnoví na pozadí. Pravidla:
  * disk = `addon_data/live/channels.json` a `now.json` (data zařízení, ne profilu — co zařízení smí, rozhoduje Gate per
    zařízení); zápis jen `richmovie_atomic.write_json`, čtení `read_json` → DVOJICE (hodnota, stav) s `expected_type`
    (past 4.0.6); poškozený soubor = karanténa (`read_json`), okno jde dál bez dat;
  * paměťová kopie podle otisku souboru `(mtime_ns, size)` — čtou ho okno i služba (past „cache čtené víc procesy“);
  * R2: neúplná / chybná odpověď se NEZAPÍŠE (parsery `richmovie_livetv.parse_*` hodí `bad_response`); 304 jen obnoví čas
    ověření (`checked_at`), data i ETag zůstanou; výpadek sítě = stará data + štítek „Program z 20:31“;
  * průběh pořadu z MÍSTNÍCH hodin s posunem proti serveru z poslední 200 (cross-check P-18: 304 nenese `now`, uložený
    čas odpovědi by průběh zastavil).
Bez Kodi importů na úrovni modulu (cesty přes `richmovie_paths` líně) — harness.
"""
from __future__ import annotations

import datetime as _dt
import os
import time
from typing import Callable, Optional, Tuple

import richmovie_atomic as _atomic
import richmovie_livetv as _tv

SCHEMA = 1
CHANNELS_FILE = "channels.json"
NOW_FILE = "now.json"
NOW_REFRESH_S = 60.0            # /now při otevřeném okně (plán §3.8); okno navíc obnoví v okamžiku konce pořadu
CHANNELS_REFRESH_S = 15 * 60.0  # seznam kanálů se mění zřídka (ETag → většinou 304)
STALE_LABEL_S = 5 * 60.0        # starší data dostanou štítek „Program z HH:MM“
MAX_OFFSET_S = 6 * 3600.0       # posun hodin proti serveru nad tuhle mez = podezřelé → 0 (hodiny zařízení se nemění)

_memo: dict = {}                # cesta → (otisk, obsah) — paměťová kopie podle otisku


def _live_dir() -> str:
    import richmovie_paths as _paths
    d = os.path.join(str(_paths.addon_data_dir()), "live")
    os.makedirs(d, exist_ok=True)
    return d


def _path(name: str, root: Optional[str] = None) -> str:
    return os.path.join(root or _live_dir(), name)


def _fingerprint(path: str) -> Optional[Tuple[int, int]]:
    try:
        st = os.stat(path)
    except OSError:
        return None
    return st.st_mtime_ns, st.st_size


def _valid_record(rec, kind: str) -> bool:
    if not isinstance(rec, dict) or rec.get("v") != SCHEMA or not isinstance(rec.get("data"), dict):
        return False
    data = rec["data"]
    if kind == "channels":
        return isinstance(data.get("channels"), list) and isinstance(data.get("bases"), list)
    return isinstance(data.get("channels"), dict)


def load(kind: str, *, root: Optional[str] = None) -> Optional[dict]:
    """Záznam z disku (`{"v", "data", "etag", "fetched_at", "checked_at", "offset_s"}`) nebo None. Paměťová kopie platí,
    dokud se nezmění otisk souboru (zápis jiným procesem = nové načtení)."""
    path = _path(CHANNELS_FILE if kind == "channels" else NOW_FILE, root)
    fp = _fingerprint(path)
    if fp is None:
        _memo.pop(path, None)
        return None
    hit = _memo.get(path)
    if hit is not None and hit[0] == fp:
        return hit[1]
    rec, _state = _atomic.read_json(path, None, name="livetv_" + kind, expected_type=dict)
    if not _valid_record(rec, kind):
        _memo.pop(path, None)
        return None
    _memo[path] = (fp, rec)
    return rec


def _store(kind: str, rec: dict, root: Optional[str]) -> bool:
    path = _path(CHANNELS_FILE if kind == "channels" else NOW_FILE, root)
    ok = _atomic.write_json(path, rec)
    if ok:
        fp = _fingerprint(path)
        if fp is not None:
            _memo[path] = (fp, rec)
    return ok


def _server_offset(server_now: Optional[str], local_now: float) -> float:
    """Posun hodin serveru proti zařízení (s); neplatný / přehnaný = 0."""
    if not server_now:
        return 0.0
    try:
        srv = _dt.datetime.fromisoformat(server_now.replace("Z", "+00:00"))
    except ValueError:
        return 0.0
    if srv.tzinfo is None:
        return 0.0
    off = srv.timestamp() - local_now
    return off if abs(off) <= MAX_OFFSET_S else 0.0


def refresh(kind: str, *, root: Optional[str] = None, clock: Callable[[], float] = time.time,
            request=None, background: bool = True) -> Tuple[str, Optional[dict]]:
    """Obnova z Gate s ETagem → `(stav, záznam)`: `updated` (nová data zapsána), `not_modified` (jen `checked_at`),
    `failed` (síť / Gate / neúplná odpověď — na disku beze změny, vrací se starý záznam nebo None)."""
    old = load(kind, root=root)
    path = "/v1/livetv/channels" if kind == "channels" else "/v1/livetv/now"
    try:
        verdict, payload, etag = _tv.conditional_get(path, (old or {}).get("etag", ""), background=background,
                                                     request=request)
        now = clock()
        if verdict == "not_modified":
            if old is None:                           # 304 bez vlastních dat (smazaný soubor) = nic k obnově
                return "failed", None
            rec = dict(old, checked_at=now)
            _store(kind, rec, root)
            return "not_modified", rec
        data = _tv.parse_channels(payload) if kind == "channels" else _tv.parse_now(payload)
    except _tv.LiveError:
        return "failed", old
    rec = {"v": SCHEMA, "data": data, "etag": etag or "", "fetched_at": now, "checked_at": now,
           "offset_s": _server_offset(data.get("now"), now) if kind == "now" else 0.0}
    if not _store(kind, rec, root):
        return "failed", old
    return "updated", rec


def due(kind: str, rec: Optional[dict], now: float) -> bool:
    """Je čas obnovit? Bez dat vždy; jinak po `NOW_REFRESH_S` / `CHANNELS_REFRESH_S` od posledního ověření."""
    if rec is None:
        return True
    gap = NOW_REFRESH_S if kind == "now" else CHANNELS_REFRESH_S
    return now - float(rec.get("checked_at") or 0) >= gap


def stale_label(rec: Optional[dict], now: float) -> str:
    """„Program z 20:31“, když poslední úspěšné ověření je starší než `STALE_LABEL_S` (výpadek sítě / NASu); jinak ""."""
    if rec is None:
        return ""
    checked = float(rec.get("checked_at") or 0)
    if now - checked < STALE_LABEL_S:
        return ""
    return "Program z %s" % time.strftime("%H:%M", time.localtime(checked))


def server_now(rec: Optional[dict], local_now: float) -> _dt.datetime:
    """Čas pro průběh pořadu: místní hodiny + posun proti serveru z poslední 200 (P-18 — ne uložený `now` odpovědi)."""
    off = float((rec or {}).get("offset_s") or 0.0)
    return _dt.datetime.fromtimestamp(local_now + off, tz=_dt.timezone.utc)


def now_of(rec: Optional[dict], channel_id: str) -> dict:
    """`{"current": …, "next": …}` kanálu z dat `/now` (prázdné, když kanál v datech není)."""
    return ((rec or {}).get("data") or {}).get("channels", {}).get(channel_id) or {"current": None, "next": None}


def ends_soon(rec: Optional[dict], channel_ids, local_now: float) -> Optional[float]:
    """Nejbližší konec běžícího pořadu mezi `channel_ids` (místní čas, s) — okno obnoví `/now` v tu chvíli (plán §3.8)."""
    best = None
    off = float((rec or {}).get("offset_s") or 0.0)
    for cid in channel_ids:
        cur = now_of(rec, cid).get("current")
        end = _tv.parse_iso(cur.get("end")) if isinstance(cur, dict) else None
        if end is None:
            continue
        t = end.timestamp() - off
        if t > local_now and (best is None or t < best):
            best = t
    return best
