# -*- coding: utf-8 -*-
"""
richmovie_episode_search — SSOT hledání streamů DÍLU seriálu (kontext filtru + kaskáda vln + záchrana).

Proč (výzkum 29.09.2026, nálezy E1-F01 a E3-F03): hledání dílu existovalo DVAKRÁT — `plugin._tv_play_run`
(ruční výpis, co divák vidí) a `plugin._search_episode` (předstažení dalšího dílu ve službě: ~89 % výpisů
dílů a VŠECHNY autoplaye). Docstring druhé kopie sliboval „totožnou kaskádu“, kopie se ale rozešly:
předstažení nepředávalo varianty názvu seriálu, slova názvu dílu, rok premiéry seriálu ani zákaz jiného
dílu, erotiku banovalo bezpodmínečně a nemělo alternativní názvy. Důsledek: autoplay vybíral z JINÉ množiny,
než jakou divák vidí ve výpisu (liší se 750 z 2 117 přijetí), a u seriálů s krátkým názvem („The OA“)
předstažení nenašlo nic → žádný autoplay a ruční hledání 110 s.

Pravda je ruční cesta (`_tv_play_run`, ověřená replayem nad produkčními logy) — tenhle modul je její
přesun 1 : 1 na jedno místo; obě cesty ho volají.

Modul nesmí importovat `plugin` (knihovna). Python 3.8 (Kodi).
"""
from __future__ import annotations

import datetime
import re
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from richmovie_engine import (
    EROTIC_KEYWORDS,
    QueryBuilder,
    Release,
    SearchCancelled,
    _ALT_COUNTRY_WHITELIST,
    _is_adult_title,
    norm as _norm,
    score_sort_key as _score_sort_key,
    spin_tokens,
)
from tmdb_client import TMDb, TMDbError, TMDbNotFoundError

# Prahy vln (13.12.2025): W1 vždy · W2 když po W1 < 10 · W3 když < 5 · WX a WX+ když < 3
THRESH_W2 = 10
THRESH_W3 = 5
THRESH_WX = 3
RESCUE_MIN_BYTES = 120 * 1_048_576     # záchrana číslem: menší soubory jsou klipy
RESCUE_NEAR_WORDS = 3                  # číslo dílu nejvýš tolik slov za názvem seriálu

# Φ-C (30.09.2026, E1-F08/F09/F10): předstažení a výpis se nepředhánějí
PREFETCH_CLAIM_TTL_S = 180.0     # claim = signál živosti; prodlužuje se po každé vlně (nejdelší vlna flotily < 100 s)
PREFETCH_WAIT_MAX_S = 180.0      # výpis čeká na běžící předstažení nejdéle tak dlouho, pak hledá sám
PREFETCH_WAIT_STEP_S = 0.25
EMPTY_MEMO_TTL_S = 6 * 3600      # D5 (Richie 29.09.2026): prázdné předstažení pamatovat do konce běhu Kodi, nejdéle 6 h
PHASE_WAIT_PREFETCH = "Dokončuji hledání dílu z pozadí…"

PHASE_W1 = "Hledám na Webshare a Fastshare…"
PHASE_MORE = "Hledám i pod dalšími názvy…"
PHASE_RESCUE = "Zkouším ještě číselné značení dílu…"

LogFn = Callable[..., None]


class EpisodeBase(object):
    """Údaje o dílu z TMDb, které potřebuje VYKRESLENÍ výpisu i hledání (vše z lokální cache TMDb)."""

    __slots__ = ("tv_id", "tv_name", "season_no", "ep_no", "ep_title", "det", "ep_cs", "ep_en",
                 "tv_names", "ep_names", "tmdb_cs", "tmdb_key", "degraded")


def _note_tmdb_failure(base: "EpisodeBase", exc: BaseException) -> None:
    """Selhání TMDb při stavbě kontextu hledání. „Nenalezeno“ je autoritativní odpověď (titul ten údaj nemá);
    cokoli jiného (síť, 5xx, 429, odmítnutá identita) znamená, že hledání poběží s CHUDŠÍMI dotazy, než by
    mělo → prázdný výsledek pak není autoritativní (R2; audit Fable F1-V3)."""
    if not isinstance(exc, TMDbNotFoundError):
        base.degraded = int(getattr(base, "degraded", 0) or 0) + 1


class EpisodeSearchContext(object):
    """Vstupy hledání dílu: dotazy + parametry filtru. Počítá `build_context` — jednou pro obě cesty."""

    __slots__ = ("base", "tv_names", "ep_names", "queries", "title_norms", "ser_title_variants",
                 "ep_title_variants", "banned_keys", "allowed_years", "ban_removed", "extra_w3", "degraded")


def episode_key(tv_id: Any, season_no: Any, ep_no: Any) -> str:
    """Klíč dílu — stejný tvar jako klíč diskové cache předstažení (`tv_id:řada:díl`)."""
    return "%s:%s:%s" % (str(tv_id or "").strip(), int(season_no), int(ep_no))


def search_key(tv_id: Any, season_no: Any, ep_no: Any) -> str:
    """Klíč MĚŘENÍ hledání dílu (`SEARCH_PHASES`, snímek výpisu, `PLAY_PICK`) — JEDINÁ skladba pro výpis, předstažení
    i přehrání. S10 (10.10.2026): výpis skládal klíč sám jen z parametru `episode`, výpis epizod ale posílá `ep_no` →
    klíč `tv:<id>:<řada>:0`, snímek výpisu se s `PLAY_PICK` nepotkal a ruční klik na díl ztratil pozici, vlnu i původ."""
    return "tv:" + episode_key(tv_id, season_no, ep_no)


def episode_numbers(args: Dict[str, Sequence[str]]) -> Tuple[int, int]:
    """(řada, díl) z parametrů URL ve tvaru `parse_qs`: výpis epizod posílá `ep_no`, starší odkazy `episode`.
    JEDINÉ čtení pro `plugin._tv_play` (klíč měření) i `_tv_play_run` (hledání). Nečíselná hodnota = (0, 0)."""
    def _first(name: str) -> str:
        vals = args.get(name) or [""]
        return str(vals[0] or "").strip()
    try:
        return int(_first("season") or 0), int(_first("ep_no") or _first("episode") or 0)
    except ValueError:
        return 0, 0


def prefetch_claim_name(tv_id: Any, season_no: Any, ep_no: Any) -> str:
    """Jméno claimu „tenhle díl se právě hledá na pozadí“ (`richmovie_guard`, sdílí služba i plugin)."""
    return "episode_search:" + episode_key(tv_id, season_no, ep_no)


def empty_is_authoritative(rels: Any, info: Optional[Dict[str, Any]]) -> bool:
    """Smí se „nic nenalezeno“ zapamatovat? Jen když hledání doběhlo CELÉ a BEZ chyby přenosu (R2: selhání
    se neperzistuje) — tedy ne po zrušení, ne po chybě dotazu, ne když se hledání přeskočilo."""
    if rels or not isinstance(info, dict):
        return False
    return (not info.get("cancelled") and not int(info.get("errors") or 0)
            and not int(info.get("ctx_errors") or 0)
            and not info.get("skipped") and bool(info.get("waves")))


class EmptyMemo(object):
    """Paměť „předstažení tohoto dílu nic nenašlo“. Jen v RAM procesu (služba žije po dobu běhu Kodi),
    platnost `EMPTY_MEMO_TTL_S`. Ruční otevření dílu ji NEČTE — divák hledá vždy."""

    def __init__(self, ttl_s: float = EMPTY_MEMO_TTL_S, clock: Callable[[], float] = None) -> None:
        import time as _time
        self._ttl = float(ttl_s)
        import threading as _threading
        self._clock = clock or _time.monotonic
        self._seen: Dict[str, float] = {}
        self._lock = _threading.Lock()      # předstažení běží ve vláknech služby

    def remember(self, key: str) -> None:
        with self._lock:
            self._seen[str(key)] = self._clock()

    def is_fresh(self, key: str) -> bool:
        with self._lock:
            ts = self._seen.get(str(key))
            if ts is None:
                return False
            if (self._clock() - ts) > self._ttl:
                self._seen.pop(str(key), None)
                return False
            return True

    def forget(self, key: str) -> None:
        with self._lock:
            self._seen.pop(str(key), None)


EMPTY_MEMO = EmptyMemo()


def wait_for_running(is_running: Callable[[], bool], read_result: Callable[[], Any],
                     cancelled: Callable[[], bool], wait_abort: Callable[[float], bool],
                     max_s: float = PREFETCH_WAIT_MAX_S, step_s: float = PREFETCH_WAIT_STEP_S,
                     clock: Callable[[], float] = None) -> Tuple[Any, str]:
    """Výpis dílu čeká na hledání téhož dílu, které už běží na pozadí (služba), místo aby spustil druhé
    stejné. Vrací (výsledek | None, důvod): done (předstažení doběhlo a něco uložilo), empty (doběhlo bez
    výsledku → volající hledá sám), timeout, cancelled, abort, idle (nic neběželo)."""
    import time as _time
    now = clock or _time.monotonic
    if not is_running():
        return None, "idle"
    t0 = now()
    while is_running():
        # Výsledek se čte V KAŽDÉM kroku: služba ho zapíše hned po hledání, ale claim drží ještě při výběru
        # streamu pro automatické přehrání (síť) — na to už výpis nečeká (audit Fable F1-V8).
        early = read_result()
        if early:
            return early, "done"
        if cancelled():
            return None, "cancelled"
        if (now() - t0) >= float(max_s):
            return None, "timeout"
        if wait_abort(float(step_s)):
            return None, "abort"
    res = read_result()
    return (res, "done") if res else (None, "empty")


def _yr(val: Any) -> Optional[int]:
    if not val:
        return None
    m = re.match(r"(\d{4})", str(val))
    return int(m.group(1)) if m else None


def load_base(tv_id: str, tv_name: str, season_no: int, ep_no: int, ep_title: str = "",
              tmdb_key: str = "") -> EpisodeBase:
    """Detail seriálu a dílu (CZ + EN) z TMDb. Selhání TMDb = prázdná pole (hledání běží dál s tím, co má)."""
    b = EpisodeBase()
    b.tv_id, b.tv_name, b.season_no, b.ep_no = str(tv_id or ""), tv_name, int(season_no), int(ep_no)
    b.ep_title = ep_title
    b.det = None
    b.ep_cs = {}
    b.ep_en = {}
    b.tv_names = [tv_name]
    b.ep_names = [ep_title] if ep_title else []
    b.degraded = 0
    b.tmdb_cs = None
    b.tmdb_key = tmdb_key or ""

    if b.tmdb_key and b.tv_id.isdigit():
        b.tmdb_cs = TMDb(b.tmdb_key, lang="cs-CZ")

        # Seriál – detail (lokální cache TMDb)
        try:
            b.det = b.tmdb_cs.tv_details(int(b.tv_id))
            b.tv_names += [b.det.get("original_name", "")]
        except TMDbError as _tmdb_exc:
            _note_tmdb_failure(b, _tmdb_exc)
            b.det = None  # det nemusí být k dispozici

        # Epizoda – CZ/EN detail (lokální cache TMDb)
        try:
            b.ep_cs = b.tmdb_cs.episode_details(int(b.tv_id), b.season_no, b.ep_no)
            nm = (b.ep_cs.get("name") or "").strip()
            if nm:
                b.ep_names.append(nm)
        except TMDbError as _tmdb_exc:
            _note_tmdb_failure(b, _tmdb_exc)
            b.ep_cs = {}

        try:
            b.ep_en = TMDb(b.tmdb_key, lang="en-US").episode_details(int(b.tv_id), b.season_no, b.ep_no)
            nm = (b.ep_en.get("name") or "").strip()
            orig_en = (b.ep_en.get("original_name") or nm).strip()
            if nm:
                b.ep_names.append(nm)
            if orig_en:
                b.ep_names.append(orig_en)
        except TMDbError as _tmdb_exc:
            _note_tmdb_failure(b, _tmdb_exc)
            pass

        if not b.ep_title:
            b.ep_title = (b.ep_cs.get("name", "") or "").strip()
    return b


def air_date(base: EpisodeBase) -> Optional[datetime.date]:
    """Datum premiéry dílu (None = neznámé). Volající rozhoduje, co s budoucí premiérou (dialog × tichý skip)."""
    air_iso = ((base.ep_cs or {}).get("air_date") or (base.ep_en or {}).get("air_date") or "").strip()
    try:
        y, m, d = [int(x) for x in air_iso.split("-", 2)] if air_iso else (0, 0, 0)
        return datetime.date(y, m, d) if y else None
    except Exception:
        return None


def build_context(base: EpisodeBase, log_event: Optional[LogFn] = None) -> EpisodeSearchContext:
    """Dotazy a parametry filtru pro díl. Přesun 1 : 1 z `plugin._tv_play_run` (3.5.170)."""
    log = log_event or (lambda *a: None)
    tv_id, tv_name, season_no, ep_no = base.tv_id, base.tv_name, base.season_no, base.ep_no
    tmdb_cs, tmdb_key, det = base.tmdb_cs, base.tmdb_key, base.det
    tv_names = list(base.tv_names)
    en_added = ""
    ep_names = list(base.ep_names)

    if tmdb_cs is not None:
        # Alt-tituly seriálu (whitelist + latinka) — jen s detailem seriálu
        try:
            if det is None:
                raise TMDbError("tv_details nedostupný → bez alt-titulů")
            alts = tmdb_cs.tv_alternative_titles(int(tv_id))
            tv_names += [
                alt.get("title", "")
                for alt in alts
                if alt.get("title")
                and alt.get("iso_3166_1") in _ALT_COUNTRY_WHITELIST
                and re.search(r"[A-Za-z]", alt.get("title", ""))
            ]
        except TMDbError as _tmdb_exc:
            _note_tmdb_failure(base, _tmdb_exc)
            pass

        # HΦ5 (2026-07-07): oficiální lokalizované názvy seriálu z translations (cs/sk/pl)
        try:
            _tv_tr = tmdb_cs.tv_translations(int(tv_id))
            for _lc in ("cs-CZ", "cs", "sk-SK", "sk", "pl-PL", "pl"):
                _nm = (_tv_tr.get(_lc) or "").strip()
                if _nm and re.search(r"[A-Za-z]", _nm) and _nm not in tv_names:
                    tv_names.append(_nm)
        except TMDbError as _tmdb_exc:
            _note_tmdb_failure(base, _tmdb_exc)
            pass

        # Anglický název seriálu (TMDb en-US). Předstažení ho před sjednocením mělo, výpis ne — a originál
        # bývá neanglický („La casa de papel“ × „Money Heist“). Pravidlo „nikdy méně streamů“: SSOT je
        # NADMNOŽINA obou dřívějších cest. Název jde do filtru a do vlny WX+, ale PLÁN DOTAZŮ vln W1–WX se
        # staví bez něj (jinak by ve W3 vytlačil dotazy s krátkým tokenem do WX, která běží jen pod prahem 3);
        # jeho dotazy se do W3 PŘIDÁVAJÍ navíc (audit Fable F1-V2).
        try:
            _en_name = (TMDb(tmdb_key, lang="en-US").tv_details(int(tv_id)).get("name") or "").strip()
            if (_en_name and re.search(r"[A-Za-z]", _en_name)
                    and _en_name.lower() not in {str(n).lower() for n in tv_names}):
                en_added = _en_name
        except TMDbError as _tmdb_exc:
            _note_tmdb_failure(base, _tmdb_exc)
            pass

        # Translations – jistota plného EN názvu ("The One Where/With …")
        try:
            trs = tmdb_cs.episode_translations(int(tv_id), season_no, ep_no)
            pref_keys = ("en-US", "en-GB", "en", "cs-CZ", "cs")
            seen_lc = {n.lower() for n in ep_names if n}
            for k in pref_keys:
                nm = (trs.get(k) or "").strip()
                if nm and nm.lower() not in seen_lc:
                    ep_names.append(nm)
                    seen_lc.add(nm.lower())
            if not any(re.search(r"\bthe one (where|with)\b", n.lower()) for n in ep_names if n):
                for nm in trs.values():
                    if nm and re.search(r"\bthe one (where|with)\b", nm.lower()):
                        if nm.lower() not in seen_lc:
                            ep_names.append(nm)
                        break
        except TMDbError as _tmdb_exc:
            _note_tmdb_failure(base, _tmdb_exc)
            pass

    c = EpisodeSearchContext()
    c.base = base

    # 3) --- DOTAZY ----------------------------------------------------
    c.queries = QueryBuilder.tv(tv_names, ep_names, season_no, ep_no)
    c.extra_w3 = []
    if en_added:
        _known = set(c.queries)
        c.extra_w3 = [q for q in ("%s %s" % (en_added, code) for code in (
            f"s{season_no:02d}e{ep_no:02d}", f"{season_no}x{ep_no:02d}", f"{season_no:02d}x{ep_no:02d}"))
            if q not in _known]
        tv_names.append(en_added)
    c.tv_names = tv_names
    c.ep_names = ep_names

    # 3b) --- VARIANTY NÁZVU SERIÁLU (OR přes varianty v enginu) -----------------
    ser_title_variants: List[List[str]] = []
    try:
        for nm in tv_names:
            toks = [_norm(w) for w in str(nm).split() if _norm(w)]
            toks = [t for t in toks if t]
            if len(toks) == 1 and len(toks[0]) <= 3:
                continue
            if toks and toks not in ser_title_variants:
                ser_title_variants.append(toks)
    except Exception:
        ser_title_variants = []
    c.ser_title_variants = ser_title_variants

    # 4) --- FILTRAČNÍ TOKENY -----------------------------------------
    title_norms: List[str] = []
    _seen: set = set()

    def _push(tok: str) -> None:
        n = _norm(tok)
        if n and n not in _seen:
            title_norms.append(n)
            _seen.add(n)

    _push(f"s{season_no:02d}e{ep_no:02d}")
    _push(f"{season_no}x{ep_no:02d}")
    _push(f"{season_no:02d}x{ep_no:02d}")
    for nm in tv_names:
        for w in nm.split():
            _push(w)
    for nm in ep_names:
        for w in nm.split():
            _push(w)

    # — erotika (pokud title není adult); zákaz jiného dílu = režim enginu `ban_other_episodes` (Φ5B) —
    banned_keys: set = set()
    if not (_is_adult_title(tv_name) or _is_adult_title(base.ep_title)):
        banned_keys |= {_norm(w) for w in EROTIC_KEYWORDS}

    # — SPIN-OFF tokeny (allow/ban) + **SANITIZACE BAN** —
    allow_tok, ban_tok = (spin_tokens(tv_id, tmdb_key) if (tv_id and tmdb_key) else (set(), set()))
    title_norms += [t for t in allow_tok if t not in _seen]

    _ep_tv_words = {
        _norm(w)
        for nm in (*tv_names, *ep_names)
        for w in nm.split()
        if _norm(w)
    }
    _ban_before = len(ban_tok)
    if _ep_tv_words:
        ban_tok = {t for t in ban_tok if t not in _ep_tv_words}
    c.ban_removed = _ban_before - len(ban_tok)
    if c.ban_removed > 0:
        log("SPIN_BAN_SANITIZE", tv_id, f"removed={c.ban_removed}")
    banned_keys |= ban_tok

    c.title_norms = title_norms
    c.banned_keys = banned_keys
    c.ep_title_variants = [[_norm(w) for w in n.split() if _norm(w)] for n in ep_names if n]

    # allowed_years: roky ze seriálu / série / epizody
    allowed_years: set = set()
    try:
        tv_year = _yr((det or {}).get("first_air_date"))
        if tv_year:
            allowed_years.add(tv_year)
    except Exception:
        pass
    try:
        if tmdb_key and tv_id.isdigit() and season_no:
            season_year = _yr(TMDb(tmdb_key, lang="cs-CZ").season_air_date(int(tv_id), season_no))
            if season_year:
                allowed_years.add(season_year)
    except Exception as exc:
        log("EP_CTX_WARN", "season_air_date", repr(exc)[:160])
    try:
        ep_year = _yr((base.ep_cs or {}).get("air_date")) or _yr((base.ep_en or {}).get("air_date"))
        if ep_year:
            allowed_years.add(ep_year)
    except Exception as exc:
        log("EP_CTX_WARN", "episode_air_date", repr(exc)[:160])
    c.allowed_years = allowed_years
    c.degraded = int(getattr(base, "degraded", 0) or 0)
    return c


def wave_plan(ctx: EpisodeSearchContext) -> List[Tuple[str, List[str], bool, int]]:
    """Plán kaskády: (značka vlny, dotazy, měkký režim, práh „spustit jen když je ve výsledku méně než“).
    W1 běží vždy (prázdný výsledek je pod každým prahem)."""
    b = ctx.base
    codes = [f"s{b.season_no:02d}e{b.ep_no:02d}", f"{b.season_no}x{b.ep_no:02d}", f"{b.season_no:02d}x{b.ep_no:02d}"]
    ser_code_qs = [f"{ser} {code}" for ser in ctx.tv_names for code in codes]
    q = ctx.queries
    return [
        ("W1", list(q[0:6]), False, THRESH_W2),
        ("W2", list(q[6:12]), False, THRESH_W2),
        ("W3", list(q[12:18]) + list(getattr(ctx, "extra_w3", None) or []), False, THRESH_W3),
        ("WX", list(q[18:]), True, THRESH_WX),
        ("WX+", ser_code_qs, True, THRESH_WX),
    ]


def rescue_numeric(engine: Any, tv_name: str, season_no: int, ep_no: int, *, title_norms: Sequence[str],
                   ser_title_variants: Sequence[Sequence[str]] = (), banned_keys: Sequence[str] = (),
                   stats: Optional[Dict[str, Any]] = None) -> List[Release]:
    """Záchrana pro staré seriály s názvy jako „Esmeralda 01.avi“ — jen když kaskáda nenašla NIC.
    `stats["errors"]` = počet dotazů záchrany, které selhaly (prázdný výsledek pak není autoritativní).

      – dotazy „<název> 01“, „<název> 1“, „<název> ep 1“, „… díl 1“, …
      – soubor s běžným kódem dílu (SxxEyy / 1xYY / E##) se tu nebere (ten by našla kaskáda),
      – číslo dílu musí být do 3 slov za názvem seriálu, soubor ≥ 120 MB (klipy pryč).
    """
    base = (tv_name or "").strip()
    if not base or ep_no <= 0:
        return []

    qs = [
        f"{base} {ep_no:02d}",
        f"{base} {ep_no}",
        f"{base} ep {ep_no}",
        f"{base} díl {ep_no}",
        f"{base} dil {ep_no}",
        f"{base} episode {ep_no}",
        f"{base} capitulo {ep_no}",
    ]
    no_epcode = re.compile(
        r"(?:\bs\d{1,2}\s*e\d{1,2}\b|\b\d{1,2}[xX]\d{1,2}\b|\be\d{2,3}\b)",
        re.I,
    )
    tv_words = [_norm(w) for w in base.split() if _norm(w)]

    def _near_enough(n: str) -> bool:
        words = [w for w in n.split() if w]
        L = len(tv_words)
        start = -1
        for i in range(0, len(words) - L + 1):
            if words[i:i + L] == tv_words:
                start = i + L
                break
        if start < 0:
            return False
        window = words[start:start + RESCUE_NEAR_WORDS]
        ep_tokens = {str(ep_no), f"{ep_no:02d}"}
        return any(w in ep_tokens for w in window)

    def _note(event: str, *params: Any) -> None:
        # log hledání (R-B): záchrana nesmí zahazovat kandidáty ani chyby beze stopy
        try:
            engine._log(event, *params)
        except Exception:
            pass

    out: Dict[str, Release] = {}
    for q in qs:
        try:
            found = engine.search_one(
                q,
                title_norms=title_norms,
                ser_title_variants=ser_title_variants,
                banned_keys=banned_keys,
                bad_regex=no_epcode,
                progress_cb=None,
                probe=False,
                ban_other_episodes=True,   # Φ5B: jiný díl (dřív součást 20k banned_keys)
                stats=stats,
            )
        except Exception as exc:
            found = []
            if stats is not None:
                stats["errors"] = int(stats.get("errors", 0) or 0) + 1
            _note("RESCUE_QUERY_ERR", q, repr(exc)[:200])

        for r in found:
            n = _norm(r.name)
            if not _near_enough(n):
                _note("RESCUE_DROP", r.ident, "number_not_near_title", r.name)
                continue
            try:
                if (r.size or 0) < RESCUE_MIN_BYTES:
                    _note("RESCUE_DROP", r.ident, "too_small", r.name)
                    continue
            except Exception as exc:
                _note("RESCUE_SIZE_ERR", r.ident, repr(exc)[:200])
            out.setdefault(str(r.ident), r)

    res = list(out.values())
    try:
        res.sort(key=lambda x: (_score_sort_key(getattr(x, "score", None)), -(getattr(x, "size", 0) or 0)))
    except Exception:
        pass
    return res


def label_for(base: EpisodeBase) -> str:
    return f"{base.tv_name} S{base.season_no:02d}E{base.ep_no:02d}"


def run_cascade(engine: Any, ctx: EpisodeSearchContext, *, ctx_name: str, log_event: LogFn,
                progress: Any = None, top_full_probe: int = 0,
                on_wave_end: Optional[Callable[[], None]] = None,
                kick_mi2: bool = True) -> Tuple[List[Release], Dict[str, Any]]:
    """Kaskáda vln + záchrana číslem. Vrací (streamy, info): info = {waves, cancelled, errors, rescue}.

    `errors` > 0 znamená, že některý dotaz selhal (síť) → prázdný výsledek NENÍ autoritativní (R2).
    `progress` = dialog hledání (nebo None); Zrušit ukončí kaskádu před další vlnou."""
    b = ctx.base
    bucket: Dict[str, Release] = {}
    info: Dict[str, Any] = {"waves": [], "cancelled": False, "errors": 0, "rescue": None,
                            "ctx_errors": int(getattr(ctx, "degraded", 0) or 0)}
    if info["ctx_errors"]:
        log_event("EP_CTX_DEGRADED", label_for(b), info["ctx_errors"])
    fetch_memo: Dict[str, Any] = {}     # Φ-C: tentýž dotaz se v jednom hledání stahuje jen jednou (WX+ bez sítě)
    label = f"{b.tv_name} S{b.season_no:02d}E{b.ep_no:02d}"

    def _cancelled() -> bool:
        try:
            return progress is not None and bool(progress.iscanceled())
        except Exception:
            return False

    for wave_tag, qs, ep_soft, threshold in wave_plan(ctx):
        if len(bucket) >= threshold or _cancelled():
            continue
        if not qs:
            continue
        if progress is not None:
            try:
                progress.set_phase(PHASE_W1 if wave_tag == "W1" else PHASE_MORE)
            except Exception:
                pass
        bucket_before = len(bucket)
        log_event("WAVE_BEGIN", {
            "ctx": ctx_name, "tv_id": b.tv_id, "season": b.season_no, "episode": b.ep_no,
            "wave": wave_tag, "qs_total": len(qs), "qs_preview": qs[:12],
            "ep_soft": bool(ep_soft), "bucket_before": bucket_before,
        })
        stats: Dict[str, Any] = {}
        try:
            found = engine.search_wave(
                qs,
                title_norms=ctx.title_norms,
                ser_title_variants=ctx.ser_title_variants,
                banned_keys=ctx.banned_keys,
                ep_title_variants=ctx.ep_title_variants,
                allowed_years=list(ctx.allowed_years),
                progress_cb=progress,
                top_full_probe=top_full_probe,
                max_quick_probe=0,
                ep_soft=ep_soft,
                ban_other_episodes=True,
                stats=stats,
                fetch_memo=fetch_memo,
                kick_mi2=kick_mi2,
            )
        except SearchCancelled:
            info["cancelled"] = True
            break
        except Exception as e:
            log_event("WAVE_ERR", {
                "ctx": ctx_name, "tv_id": b.tv_id, "season": b.season_no, "episode": b.ep_no,
                "wave": wave_tag, "err": str(e),
            })
            raise
        info["errors"] += int(stats.get("errors") or 0)
        if stats.get("rate_limited"):
            info["rate_limited"] = True
        if stats.get("cancelled"):
            info["cancelled"] = True
        found_count = len(found)
        for r in found:
            if r.ident not in bucket:
                try:
                    if not getattr(r, "wave", ""):
                        r.wave = wave_tag
                except Exception:
                    pass
                bucket[r.ident] = r
        info["waves"].append(wave_tag)
        log_event("WAVE_END", {
            "ctx": ctx_name, "tv_id": b.tv_id, "season": b.season_no, "episode": b.ep_no,
            "wave": wave_tag, "found": found_count,
            "bucket_after": len(bucket), "added": len(bucket) - bucket_before,
        })
        if on_wave_end is not None:
            try:
                on_wave_end()
            except Exception:
                pass

    if _cancelled():
        info["cancelled"] = True
    rels = list(bucket.values())
    if info["cancelled"] or rels:
        return rels, info

    if progress is not None:
        try:
            progress.set_phase(PHASE_RESCUE)
        except Exception:
            pass
    rescue_stats: Dict[str, Any] = {}
    try:
        rescue = rescue_numeric(
            engine, b.tv_name, b.season_no, b.ep_no,
            title_norms=ctx.title_norms, ser_title_variants=ctx.ser_title_variants,
            banned_keys=ctx.banned_keys, stats=rescue_stats,
        )
        info["errors"] += int(rescue_stats.get("errors") or 0)
        if rescue:
            log_event("RESCUE_NUMERIC_OK", label, len(rescue))
            for r in rescue:
                try:
                    r.wave = "RESCUE"
                except Exception:
                    pass
            rels = rescue
            info["rescue"] = len(rescue)
        else:
            log_event("RESCUE_NUMERIC_EMPTY", label)
            info["rescue"] = 0
    except Exception as _e:
        log_event("RESCUE_NUMERIC_ERR", str(_e))
        info["rescue"] = -1
        info["errors"] += 1
    return rels, info
