# -*- coding: utf-8 -*-
"""Přednačítání programu kolem fokusu panelu Televize (F4d-2, 08.11.2026).

Richie: „aby se to preloadovalo na pozadí? po otevření, aby se začaly preloadovat další následující 10 stanic? … jak
půjde uživatel níže, že se to budou preloadovat další“.

Čisté rozhodnutí (bez Kodi, bez sítě — harness): KTERÉ kanály poslat v další dávce `GET /v1/livetv/epg?channels=…`.
Okno drží nejvýš JEDEN běžící dotaz (single-flight) a po jeho konci se ptá znovu podle AKTUÁLNÍHO fokusu — rychlé
listování nestaví frontu starých dávek. Obrázky karet přednačítá Kodi sám (`preloaditems` seznamu, plán F4d-2 P4).
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Set, Tuple

AHEAD = 10            # kanálů PO směru listování (Richie: „dalších 10 stanic“)
BEHIND = 1            # kanál PROTI směru (krok zpět je taky hned; ostatní se doplní při návratu)
BATCH_MAX = 12        # = Gate `LIVETV_EPG_BATCH_MAX` (dávka nad strop Gate = 400); fokus + AHEAD + BEHIND = přesně 12
FRESH_S = 300.0       # program kanálu mladší než tohle se znovu nestahuje (pořady se mění po desítkách minut)
FAIL_BACKOFF_S = 10.0  # po selhání dávky (síť, Gate, neúplná odpověď) další pokus nejdřív za tolik — nikdy smyčka
REFILL_AT = 4         # hystereze: nová dávka až když fokus nebo některý z nejbližších 4 po směru nemá program —
                      # posun o řádek ≠ nový dotaz (cross-check H2-b: držení šipky = až 10 dávek/s nad limit Gate)
MIN_INTERVAL_S = 1.0  # nejmenší rozestup ZAČÁTKŮ dávek (strop 60/min ≪ Gate 120/min na zařízení i při listování)

DOWN, UP = 1, -1


def direction(prev_index: Optional[int], index: int, current: int = DOWN) -> int:
    """Směr listování z posunu fokusu; stejný řádek (nebo první fokus) = směr se nemění (výchozí dolů)."""
    if prev_index is None or index == prev_index:
        return current
    return DOWN if index > prev_index else UP


def plan(ids: Sequence[str], focus: Optional[str], step: int, fetched_at: Dict[str, float],
         inflight: Set[str], now: float) -> List[str]:
    """Kanály do další dávky: fokus PRVNÍ, pak až `AHEAD` po směru `step`, pak až `BEHIND` proti směru — jen ty, jejichž
    program není čerstvý (`fetched_at` < `FRESH_S`, hodiny okna — monotonic) ani právě v dotazu; nejvýš `BATCH_MAX`.
    Hystereze: má-li fokus i nejbližších `REFILL_AT` po směru program, nic (posun o řádek ≠ dotaz). Seznam se přes
    konec NEotáčí (konec seznamu není „další kanál“). Fokus mimo seznam (hledání, filtr) = nic."""
    if not focus or focus not in ids:
        return []
    i = ids.index(focus)
    step = DOWN if step >= 0 else UP

    def ready(ch: str) -> bool:
        t = fetched_at.get(ch)
        return ch in inflight or (t is not None and 0.0 <= now - t < FRESH_S)

    near = [ids[j] for j in range(i + step, i + step * (REFILL_AT + 1), step) if 0 <= j < len(ids)]
    if ready(focus) and all(ready(ch) for ch in near):
        return []                       # rezerva po směru stačí — další dávka, až ubude (hystereze)
    order: List[str] = [focus]
    order += [ids[j] for j in range(i + step, i + step * (AHEAD + 1), step) if 0 <= j < len(ids)]
    order += [ids[j] for j in range(i - step, i - step * (BEHIND + 1), -step) if 0 <= j < len(ids)]
    out: List[str] = []
    for ch in order:
        if ch in out or ch in inflight:
            continue
        t = fetched_at.get(ch)
        if t is not None and 0.0 <= now - t < FRESH_S:
            continue
        out.append(ch)
        if len(out) >= BATCH_MAX:
            break
    return out


def split_batch(body: dict, asked: Sequence[str]) -> Tuple[Dict[str, list], List[str]]:
    """Odpověď dávky → {kanál: události} jen pro DOTÁZANÉ kanály + kanály, které v odpovědi chybí (ty se NEuloží — R2:
    neúplná odpověď není „kanál nemá program“, příští plán se na ně zeptá znovu)."""
    raw = body.get("channels") if isinstance(body, dict) else None
    got: Dict[str, list] = {}
    missing: List[str] = []
    for ch in asked:
        events = raw.get(ch) if isinstance(raw, dict) else None
        if isinstance(events, list):
            got[ch] = [e for e in events if isinstance(e, dict)]
        else:
            missing.append(ch)
    return got, missing
