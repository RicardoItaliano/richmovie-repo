# -*- coding: utf-8 -*-
"""Ztlumení v Televizi — JEDINÉ místo `Mute` / `SetMute` v doplňku (plán F4 §3.11, lint L9 scénář 109; 08.11.2026).

Richie 08.11.2026: „jedním tlačítkem v postranním panelu mute, to by bylo tak fajn.“ Pravidla:
  * zápis = CÍLOVÝ stav přes JSON-RPC `Application.SetMute {"mute": true|false}` — nikdy přepínač (dvojí stisk ani klávesa
    mute na ovladači mezitím stav nerozjedou);
  * čtení VŽDY z Kodi (`Application.GetProperties muted`) — ikona v okně sedí i po klávese mute na ovladači;
  * vlastnictví: ztlumení, které vzniklo během otevřené Televize, Televize při odchodu vrátí; ztlumení, které existovalo
    před vstupem, nechá být (film po Televizi nesmí být potichu, cizí nastavení se nemění).
Kodi se volá líně (`_rpc`) — modul jde testovat bez Kodi (stub `xbmc.executeJSONRPC`).
"""
from __future__ import annotations

import json
from typing import Optional


def _rpc(method: str, params: dict) -> dict:
    import xbmc
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method,
                                                          "params": params})))
    except (ValueError, TypeError):
        return {}


def muted() -> bool:
    """Je Kodi teď ztlumené? (pravda je v Kodi, ne v okně)"""
    res = _rpc("Application.GetProperties", {"properties": ["muted"]}).get("result")
    return bool(res.get("muted")) if isinstance(res, dict) else False


def set_muted(target: bool) -> bool:
    """Nastaví CÍLOVÝ stav ztlumení a vrátí stav, který Kodi skutečně má (pro ikonu)."""
    _rpc("Application.SetMute", {"mute": bool(target)})
    return muted()


def restore_target(before: bool, now: bool) -> Optional[bool]:
    """Co udělat se ztlumením při odchodu z Televize: `False` = zrušit ztlumení vzniklé v Televizi, `None` = nechat být."""
    if not before and now:
        return False
    return None


class MuteOwnership:
    """Stav ztlumení při vstupu do Televize → při odchodu vrátí jen to, co Televize (nebo divák v ní) změnila."""

    def __init__(self) -> None:
        self.before = muted()

    def toggle(self) -> bool:
        """Tlačítko v panelu: přepnout podle AKTUÁLNÍHO stavu Kodi (cílovým zápisem)."""
        return set_muted(not muted())

    def leave(self) -> Optional[bool]:
        """Odchod z Televize: vrátí cílový stav, který nastavil (None = nic)."""
        target = restore_target(self.before, muted())
        if target is not None:
            set_muted(target)
        return target
