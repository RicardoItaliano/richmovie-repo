# -*- coding: utf-8 -*-
"""SSOT „druh média“ přehrávané položky (07.11.2026, plán Televizní kanály F3, rozbor A4 §4).

Proč: celé přehrávání RichMovie (Pokračovat, ✔, autoplay, navázání, zdraví zdroje, stres, telemetrie, Zpět = Stop…)
předpokládá film nebo díl (VOD). Živý kanál nemá konec, pozici ani TMDb — každé místo, které by se zeptalo „je to
film?“ po svém, je další díra (inventář 23 míst, A4 §3). Proto JEDNA tabulka schopností a JEDNA funkce `allows()`;
rozhodování rozeseté po službě je zakázané (lint L1/L2 v harnessu).

Druh nese PŘEHRÁVANÁ POLOŽKA (vlastnost `richmovie.media_kind`, vzniká jen ve staviteli živé položky), ne globální
vlastnost okna (poučení 4.0.3 M6). Bez Kodi importů — testuje `_tools/net_resilience_sim` scénář 97.
"""

from __future__ import annotations

VOD = "vod"
LIVE = "live"
RECORDING = "recording"
FOREIGN = "foreign"
KINDS = (VOD, LIVE, RECORDING, FOREIGN)

#: jméno vlastnosti ListItem (jediné místo literálu — lint L1)
PROP = "richmovie.media_kind"

# značky, podle kterých dnešní položky RichMovie poznáme bez explicitního druhu (VOD vzniká v `plugin._play`:
# `richmovie.tv_id` plugin.py:11712, `richmovie.m_tmdb` :11756, `richmovie.ident` :11763, `richmovie.source` :11768).
# 08.11.2026: dřív tu byly holé `tv_id` / `m_tmdb`, které žádná položka nenese (průzkum F3) — díl seriálu bez identu
# by vyšel jako cizí.
_VOD_MARKERS = ("richmovie.ident", "richmovie.tv_id", "richmovie.m_tmdb", "richmovie.source")

# Matice schopností (A4 §4.1). FOREIGN (knihovna Kodi, PVR, jiný doplněk) nesmí NIC z toho, co dělá RichMovie
# s vlastním přehráváním — dnešní implicitní ochrany (chybí ident/tmdb) tím dostávají jméno.
_MATRIX = {
    #                    vod    live   recording  foreign
    "cw":              (True,  False, True,      False),   # Pokračovat, checkpointy pozice
    "watched":         (True,  False, False,     False),   # ✔, posun Pokračovat na další díl
    "autoplay":        (True,  False, False,     False),   # další díl, předstažení, next-up dialog
    "auto_resume":     (True,  False, True,      False),   # utnutí → navázání (živé: přeladit, `retune`)
    "retune":          (False, True,  False,     False),   # živé: tiché přeladění po výpadku relay / sítě
    "source_health":   (True,  False, False,     False),   # vadný soubor na stejném místě
    "stress":          (True,  False, False,     False),   # continuity D4 (6 h nižší datový tok)
    "cache_meter":     (True,  False, True,      False),
    "watch_event":     (True,  False, False,     False),   # telemetrie zhlédnutí (živé: vlastní událost relace)
    "rating_ask":      (True,  False, False,     False),
    # Zpět z celé obrazovky = Stop. Živé (F4, 08.11.2026): video hraje v okně Televize (`videowindow`), celá obrazovka
    # Kodi se neotevírá a o odchodu i návratu rozhoduje OKNO (služba po konci kanálu nikam nenaviguje — jinak by nad
    # otevřené okno přehrála zásobník oken); invariant „TV hraje jen s oknem“ drží hlídač sirotka služby (plán §3.7).
    "fs_exit_stop":    (True,  False, True,      False),
    "return_to_ui":    (True,  False, True,      False),   # po konci přehrávání zpět do okna RichMovie, odkud se pouštělo
    "resume_point":    (True,  False, True,      False),   # bod navázání v položce, dotaz na vzdálenou pozici
    "idle_ask":        (True,  True,  False,     False),   # „Díváš se ještě?“ (VOD řetěz autoplaye, živé nečinnost)
}
_COL = {VOD: 0, LIVE: 1, RECORDING: 2, FOREIGN: 3}


def capabilities() -> tuple:
    """Všechny schopnosti (harness: úplnost matice — každá × každý druh)."""
    return tuple(_MATRIX)


def allows(kind: str, capability: str) -> bool:
    """Smí přehrávání druhu `kind` schopnost `capability`? Neznámý druh = FOREIGN (nic). Neznámá schopnost = chyba
    programátora → výjimka (tichá odpověď by skryla překlep v místě volání)."""
    row = _MATRIX[capability]
    return row[_COL.get(kind, _COL[FOREIGN])]


def of_item(get_prop) -> str:
    """Druh z vlastností přehrávané položky. `get_prop(jméno) -> str` (ListItem.getProperty / InfoLabel ListItem.Property).
    Explicitní `richmovie.media_kind` vyhrává; jinak značka RichMovie = VOD; jinak FOREIGN."""
    try:
        explicit = (get_prop(PROP) or "").strip()
    except Exception:
        explicit = ""
    if explicit in KINDS:
        return explicit
    for marker in _VOD_MARKERS:
        try:
            if (get_prop(marker) or "").strip():
                return VOD
        except Exception:
            continue
    return FOREIGN
