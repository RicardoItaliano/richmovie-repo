# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – UI profilů: onboarding, chooser „Kdo se dívá?", správa (3.5.134)
───────────────────────────────────────────────────────────────────────────────
Logiku stavu drží `richmovie_profile` (SSOT); tenhle modul jen kreslí a ptá se.
  • `ensure_profile_at_start()`  – volá `_root()` po úspěšném /auth: onboarding
    (jednou per účet) a chooser (při každém startu Kodi, D1); nikdy neblokuje,
    když Gate dole (chooser z cache, jinak jede jako single).
  • `open_chooser(reason)`       – vlastní okno `RichMovieProfiles.xml`
    (fallback `Dialog().select`), Host vždy poslední (D12), pořadí z Gate (D3).
  • `show_manage_dialog()`       – Nastavení → Profily: přepnout, přidat, přejmenovat,
    odebrat, „toto zařízení je moje", vyčistit historii profilu.
═══════════════════════════════════════════════════════════════════════════════
"""
from __future__ import annotations

import os
import shutil
from typing import Any, Dict, List, Optional

import xbmc
import xbmcaddon
import xbmcgui

import richmovie_paths
import richmovie_profile as P
import richmovie_winprops
import richmovie_feedback as _fb  # Φ2 (29.09.2026): SSOT okamžité odezvy (toast, průběh, chyby)
import richmovie_playback_dispatch as _rm_dispatch  # 4.0.1: Container.Refresh jen přes bránu (pád Kodi 09.10.2026)

_XML = "RichMovieProfiles.xml"
_TILE_W = 300          # = itemlayout/focusedlayout width v RichMovieProfiles.xml (jedna pravda: skin)
_TILE_Y = 420          # = posy seznamu 9200 ve skinu
_SCREEN_W = 1920       # 1080i skin — Kodi škáluje
_RES = "1080i"
_LIST = 9200
_BACK = 9000
_MANAGE = 9010
PROP_SESSION_CHOSEN = "RichMovie.Profile.SessionChosen"   # Window prop → jednou per běh Kodi
PROP_FORCE_CHOOSER = P.PROP_FORCE_CHOOSER   # SSOT v richmovie_profile (nastavuje i smazání profilu)


try:
    from richmovie_logging import make_legacy_logger as _mk_logger
    _log = _mk_logger("richmovie.profile_ui", "[RichMovie][profile_ui]")   # → user_logs (Fable P2-5)
except Exception:
    def _log(msg: str, level: int = xbmc.LOGINFO) -> None:
        xbmc.log("[RichMovie][profile_ui] %s" % msg, level)


def _addon() -> xbmcaddon.Addon:
    return xbmcaddon.Addon()


def _media(name: str) -> str:
    return os.path.join(_addon().getAddonInfo("path"), "resources", "skins", "default", "media", name)


def _last_used_label(p: Dict[str, Any]) -> str:
    """„naposledy tady …" = na tomto zařízení (mig 0031), „naposledy jinde …" = jen na jiném."""
    import richmovie_helpers
    here = p.get("last_used_here_at")
    if here:
        return "naposledy tady " + richmovie_helpers.format_local_datetime(here, default="?")
    iso = p.get("last_used_at")
    if not iso:
        return "ještě nepoužit"
    if "last_used_here_at" not in p:
        # Gate před mig 0031 pole vůbec neposílá → nevíme kde, nepíšeme „jinde" (Flash P2)
        return "naposledy " + richmovie_helpers.format_local_datetime(iso, default="?")
    return "naposledy jinde " + richmovie_helpers.format_local_datetime(iso, default="?")


def _avatar_path(p: Dict[str, Any]) -> str:
    """Lokálně stažená fotka profilu; "" = silueta. SSOT = `richmovie_profile.avatar_path`
    (Φ4: cache plní `sync_avatars` při každém načtení seznamu + služba každých 30 s)."""
    return P.avatar_path(p)


def _fallback_avatar(p: Dict[str, Any], *, guest: bool = False) -> str:
    return _media("rm_avatar_guest.png" if guest else "rm_avatar_slot%d.png" % max(1, min(5, int(p.get("slot") or 1))))


# ─────────────────────────────────────────────────────────────────────────────
#  Chooser
# ─────────────────────────────────────────────────────────────────────────────

class RichMovieProfilesWindow(xbmcgui.WindowXMLDialog):
    """Vodorovná řada profilů. Výsledek: `self.result` = profil dict, `{"id": 0}` = Host,
    None = zpět (bez změny). Okno samo nic nepřepíná (D11)."""

    def __init__(self, *args, **kwargs):
        self._profiles: List[Dict[str, Any]] = kwargs.pop("profiles", [])
        self._title: str = kwargs.pop("title", "Kdo se dívá?")
        self._allow_back: bool = kwargs.pop("allow_back", True)
        self._allow_manage: bool = kwargs.pop("allow_manage", True)
        self._focus_id: Optional[int] = kwargs.pop("focus_id", None)
        self.result: Optional[Dict[str, Any]] = None
        self.manage_requested = False
        super().__init__(*args)

    def onInit(self) -> None:
        self.setProperty("rm_pf_title", self._title)
        self.setProperty("rm_pf_subtitle", P.WHY_PROFILE_MATTERS)
        self.setProperty("rm_pf_back", "1" if self._allow_back else "")
        self.setProperty("rm_pf_manage", "1" if self._allow_manage else "")
        lst = self.getControl(_LIST)
        lst.reset()
        focus_pos = 0
        for i, p in enumerate(self._profiles):
            li = xbmcgui.ListItem(str(p.get("name") or "?"))
            li.setProperty("rm_id", str(int(p.get("id"))))
            li.setProperty("rm_color", P.slot_color(int(p.get("slot") or 1)))
            li.setProperty("rm_photo", _avatar_path(p))
            li.setProperty("rm_last", _last_used_label(p))
            lst.addItem(li)
            if self._focus_id is not None and int(p.get("id")) == int(self._focus_id):
                focus_pos = i
        guest = xbmcgui.ListItem(P.GUEST_NAME)
        guest.setProperty("rm_id", str(P.GUEST_ID))
        guest.setProperty("rm_color", P.GUEST_COLOR)
        guest.setProperty("rm_photo", "")
        guest.setProperty("rm_last", "nic se neukládá")
        lst.addItem(guest)
        # Řada dlaždic na střed (Richie 05.09.: „avatary uprostřed, vpravo místo na jeden"):
        # seznam má ve skinu šířku 1920 a řadí zleva → šířka = počet × 300, posun na střed.
        count = len(self._profiles) + 1
        width = min(_SCREEN_W, count * _TILE_W)
        try:
            lst.setWidth(width)
            lst.setPosition((_SCREEN_W - width) // 2, _TILE_Y)
        except Exception as exc:
            _log("chooser centering failed: %r" % (exc,), xbmc.LOGWARNING)
        try:
            lst.selectItem(focus_pos)
        except Exception:
            pass
        self.setFocusId(_LIST)

    def onClick(self, control_id: int) -> None:
        if control_id == _LIST:
            pos = self.getControl(_LIST).getSelectedPosition()
            if 0 <= pos < len(self._profiles):
                self.result = self._profiles[pos]
            else:
                self.result = {"id": P.GUEST_ID, "name": P.GUEST_NAME}
            self.close()
        elif control_id == _MANAGE:
            self.manage_requested = True
            self.close()
        elif control_id == _BACK:
            self.close()

    def onAction(self, action) -> None:
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            if self._allow_back:
                self.close()
            # bez Back (první výběr po startu): nic — uživatel musí vybrat


def _chooser_fallback(profiles: List[Dict[str, Any]], title: str, focus_id: Optional[int]) -> Optional[Dict[str, Any]]:
    """Bez našeho skinu: běžný výběrový dialog s ikonami (předobarvené siluety)."""
    items = []
    for p in profiles:
        li = xbmcgui.ListItem(str(p.get("name") or "?"), _last_used_label(p))
        li.setArt({"icon": _avatar_path(p) or _fallback_avatar(p), "thumb": _avatar_path(p) or _fallback_avatar(p)})
        items.append(li)
    g = xbmcgui.ListItem(P.GUEST_NAME, "nic se neukládá")
    g.setArt({"icon": _fallback_avatar({}, guest=True), "thumb": _fallback_avatar({}, guest=True)})
    items.append(g)
    preselect = 0
    if focus_id is not None:
        for i, p in enumerate(profiles):
            if int(p.get("id")) == int(focus_id):
                preselect = i
    idx = xbmcgui.Dialog().select("%s — %s" % (title, P.WHY_PROFILE_MATTERS), items, useDetails=True, preselect=preselect)
    if idx < 0:
        return None
    if idx < len(profiles):
        return profiles[idx]
    return {"id": P.GUEST_ID, "name": P.GUEST_NAME}


def open_chooser(*, title: str = "Kdo se dívá?", allow_back: bool = True, allow_manage: bool = True) -> Optional[Dict[str, Any]]:
    """Zobrazí chooser, uloží výběr přes SSOT. Vrací vybraný profil nebo None (zpět).

    Φ2 (29.09.2026, audit A10 F8 / A02 N2): okno se otevře HNED z uloženého seznamu profilů
    (služba ho drží čerstvý: ETag každých 30 s při nečinnosti, D14) a Gate se obnoví na pozadí.
    Dřív se na `GET /v1/profiles/` čekalo před oknem (strop 12 s) a 25,8 % kliknutí na
    „Dívá se: …“ byl dvojklik. Bez uloženého seznamu (první start) se čeká s textem.

    Souběh obnovy s výběrem: oba zápisy jdou přes `_mutate` pod zámkem stavu; `current_id` obnova
    nepřepíše (`_apply_list` ho drží, dokud profil v Gate existuje). Nejhorší případ (seznam z Gate
    dorazí až po výběru) = pořadí v chooseru o jedno otevření starší, srovná ho hlášení `/use`."""
    st = P.load_state()
    profiles = P.profiles_cached(st)
    if profiles:
        _refresh_profiles_background()
    else:
        st = _fetch_profiles_with_feedback()
        profiles = P.profiles_cached(st)
    if not profiles:
        _log("chooser: no profiles in cache and Gate unreachable → single behaviour", xbmc.LOGWARNING)
        _fb.warn("Profily teď nejdou načíst — zkus to za chvíli.")
        return None
    focus_id = st.get("current_id")
    result: Optional[Dict[str, Any]] = None
    manage = False
    try:
        try:
            import richmovie_motion as _motion
            _motion.sync_reduced_property()        # dvojčata XML (Méně pohybu = prstenec bez dýchání) — 4.3.0
        except Exception as exc:
            _log("chooser: motion property %r" % (exc,), xbmc.LOGWARNING)
        win = RichMovieProfilesWindow(_XML, _addon().getAddonInfo("path"), "default", _RES,
                                      profiles=profiles, title=title, allow_back=allow_back,
                                      allow_manage=allow_manage, focus_id=focus_id)
        win.doModal()
        result, manage = win.result, win.manage_requested
        del win
    except Exception as exc:
        _log("skin window failed (%r) → fallback dialog" % (exc,), xbmc.LOGWARNING)
        result = _chooser_fallback(profiles, title, focus_id)
    if manage:
        show_manage_dialog()
        return open_chooser(title=title, allow_back=allow_back, allow_manage=allow_manage)
    if result is None:
        return None
    if int(result.get("id")) == P.GUEST_ID:
        P.select_guest()
    else:
        P.select_profile(result)
    richmovie_winprops.set_prop(PROP_SESSION_CHOSEN, "1")
    return result


# ─────────────────────────────────────────────────────────────────────────────
#  Onboarding (jednou per účet)
# ─────────────────────────────────────────────────────────────────────────────

ONBOARDING_TITLE = "Kolik lidí u vás RichMovie používá?"
ONBOARDING_TEXT = (
    "RichMovie umí profily jako Netflix: každý má vlastní historii, Pokračovat na všech zařízeních "
    "a svoje doporučení. Webshare účet zůstává jeden a nikomu se nic nemíchá.\n\n"
    + P.WHY_PROFILE_MATTERS + "\n\n"
    "[B]Jen já[/B] — vše zůstane, jak je. Další lidi přidáš kdykoli v Nastavení → Profily.\n"
    "[B]Více lidí[/B] — založíš 2 až %d profilů (jména zadáš hned) a při každém startu vybereš, kdo se dívá. "
    "Dosavadní historie z tohoto zařízení připadne prvnímu profilu (majiteli účtu).\n"
    "[B]Později[/B] — zeptáme se znovu při příštím spuštění."
) % P.PROFILES_MAX
ONBOARDING_LABELS = ("Jen já (jeden profil)", "Více lidí (až %d profilů)" % P.PROFILES_MAX, "Později")
_ONBOARDING_XML = "RichMovieOnboarding.xml"
_OB_BTN_SINGLE, _OB_BTN_MULTI, _OB_BTN_LATER = 9301, 9302, 9303


class RichMovieOnboardingWindow(xbmcgui.WindowXMLDialog):
    """Velký onboarding dialog (Richie 05.09.: standardní yesnocustom roluje text).
    Výsledek `choice`: 0 = jen já, 1 = více lidí, 2 = později, None = zavřeno."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.choice: Optional[int] = None

    def onInit(self) -> None:
        self.setProperty("rm_ob_title", ONBOARDING_TITLE)
        self.setProperty("rm_ob_text", ONBOARDING_TEXT)
        self.setProperty("rm_ob_btn_single", ONBOARDING_LABELS[0])
        self.setProperty("rm_ob_btn_multi", ONBOARDING_LABELS[1])
        self.setProperty("rm_ob_btn_later", ONBOARDING_LABELS[2])

    def onClick(self, control_id: int) -> None:
        mapping = {_OB_BTN_SINGLE: 0, _OB_BTN_MULTI: 1, _OB_BTN_LATER: 2}
        if control_id in mapping:
            self.choice = mapping[control_id]
            self.close()

    def onAction(self, action) -> None:
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.choice = 2
            self.close()


def _ask_profile_mode() -> int:
    """0 = jen já, 1 = více lidí, 2 = později, −1 = zrušeno. Vlastní okno; když skin
    selže (chybí XML/médium), standardní `yesnocustom`, na Kodi 18 `select`."""
    try:
        win = RichMovieOnboardingWindow(_ONBOARDING_XML, _addon().getAddonInfo("path"), "default", _RES)
        win.doModal()
        choice = win.choice
        del win
        return 2 if choice is None else int(choice)
    except Exception as exc:
        _log("onboarding window failed (%r) → fallback dialog" % (exc,), xbmc.LOGWARNING)
    dlg = xbmcgui.Dialog()
    try:
        return int(dlg.yesnocustom(ONBOARDING_TITLE, ONBOARDING_TEXT, customlabel=ONBOARDING_LABELS[2],
                                   nolabel=ONBOARDING_LABELS[0], yeslabel=ONBOARDING_LABELS[1]))
    except AttributeError:   # Kodi 18: bez yesnocustom → select
        dlg.ok(ONBOARDING_TITLE, ONBOARDING_TEXT)
        return int(dlg.select(ONBOARDING_TITLE, list(ONBOARDING_LABELS)))


SIMPLIFIED_TEXT = ("Rozhodnutí o profilech jsi už několikrát odložil, tak jen krátce:\n"
                   "• Kouká tu jen jeden člověk → „Jen já“ (vše zůstane, jak je).\n"
                   "• Dívá se tu víc lidí (děti, partner) → „Více lidí“ — každý dostane vlastní historii "
                   "a doporučení, jinak se vám to smíchá.")


def _ask_profile_mode_simplified() -> int:
    """Po opakovaném „Později" (D1, 3.5.147): jedna otázka bez předvolby — „Jen já" NENÍ
    doporučená volba pro sdílenou TV (cross-check Pro P7 10.09.: smíchala by se historie dětí s rodičem;
    od S24 jde „Jen já“ → více profilů i později v Nastavení → Profily, historie pak připadne prvnímu profilu).
    0 = jen já, 1 = chce plný dialog (více lidí), 2 = zavřeno/později."""
    dlg = xbmcgui.Dialog()
    try:
        res = int(dlg.yesnocustom("Kdo se dívá?", SIMPLIFIED_TEXT, customlabel="Později",
                                  nolabel="Více lidí…", yeslabel="Jen já"))
        # yesnocustom: 0 = no (více lidí), 1 = yes (jen já), 2 = custom (později), -1 = zavřeno
        return {1: 0, 0: 1, 2: 2}.get(res, 2)
    except AttributeError:   # Kodi 18
        return 0 if dlg.yesno("Kdo se dívá?", SIMPLIFIED_TEXT, nolabel="Více lidí…", yeslabel="Jen já") else 1


def run_onboarding() -> bool:
    """Vrátí True, když je rozhodnuto (single nebo multi hotovo); False = zrušeno
    (Gate zůstává `unset`; kdy se ptát příště, řídí `richmovie_profile.onboarding_should_ask`).
    Každá volba se loguje do user_logs (do 3.5.146 bylo „Později" neviditelné)."""
    dlg = xbmcgui.Dialog()
    st = P.load_state()
    later_count = int(st.get("onboarding_later") or 0)
    simplified = P.onboarding_simplified(st)
    choice = _ask_profile_mode_simplified() if simplified else _ask_profile_mode()
    if simplified and choice == 1:
        choice = _ask_profile_mode()      # chce plný dialog (více lidí)
    label = {0: "single", 1: "multi", 2: "later"}.get(choice, "cancel")
    _log("onboarding_choice=%s later_count=%d simplified=%s" % (label, later_count, simplified), xbmc.LOGINFO)
    if choice == 2 or choice < 0:   # Později / zrušeno
        P.note_onboarding_later()
        return False
    if choice == 0:                  # Jen já
        try:
            with _fb.working("Ukládám…"):
                P.setup_single()
        except P.ProfileGateError as exc:
            _notify_error("Nastavení se neuložilo", exc)
            return False
        _fb.info("Jeden profil — vše zůstává, jak je.")
        return True
    # Více lidí
    names = _ask_names(" (majitel účtu)")   # krátké: titulek klávesnice na TV se ořezává; vysvětlení je v dialogu předtím
    if not names:
        return False
    own = dlg.yesno("Je tohle zařízení jen tvoje?",
                    "Když ano, dosavadní historie z tohoto zařízení připadne profilu „%s“. "
                    "Sdílené zařízení (obývák) nech na Ne — historie se nikomu nepřičte." % names[0],
                    nolabel="Ne, sdílené", yeslabel="Ano, jen moje")
    if not dlg.yesno("Založit profily?", "Profily: " + ", ".join(names) + "\n\n" + P.WHY_PROFILE_MATTERS,
                     nolabel="Zpět", yeslabel="Založit"):
        return False
    try:
        with _fb.working("Zakládám profily…"):
            P.setup_multi(names, own_device=bool(own))
    except P.ProfileGateError as exc:
        _notify_error("Profily se nepodařilo založit", exc)
        return False
    _fb.info("Profily založeny: " + ", ".join(names))
    return True


def _ask_names(owner_hint: str) -> Optional[List[str]]:
    """Kolik profilů (2–max) a jejich jména — JEDEN dialog pro onboarding i převod „Jen já“ → více profilů (S24 D6).
    Kontrola jako na Gate (délka, stejné jméno bez ohledu na velikost písmen, rezervovaný „Host“) hned u vstupu,
    ať se člověk nedozví až po odeslání. None = zrušeno."""
    dlg = xbmcgui.Dialog()
    count_idx = dlg.select("Kolik profilů založit?", ["%d profily" % n if n < 5 else "%d profilů" % n
                                                      for n in range(2, P.PROFILES_MAX + 1)])
    if count_idx < 0:
        return None
    count = count_idx + 2
    names: List[str] = []
    for i in range(1, count + 1):
        hint = owner_hint if i == 1 else ""
        while True:
            name = dlg.input("Jméno %d. profilu%s" % (i, hint), "", xbmcgui.INPUT_ALPHANUM)
            if not name:
                return None
            name = " ".join(name.split())
            if len(name) > P.NAME_MAX:
                dlg.ok("RichMovie", "Jméno může mít nejvýš %d znaků." % P.NAME_MAX)
                continue
            if name.casefold() == P.GUEST_NAME.casefold():
                dlg.ok("RichMovie", "„%s“ je vyhrazený pro návštěvy — zvol jiné jméno." % P.GUEST_NAME)
                continue
            if name.casefold() in {n.casefold() for n in names}:
                dlg.ok("RichMovie", "Tohle jméno už je použité, zvol jiné.")
                continue
            names.append(name)
            break
    return names


CONVERT_TITLE = "Profily pro více lidí"
CONVERT_TEXT = ("Každý dostane vlastní historii, rozkoukané filmy a díly na všech zařízeních a svoje doporučení.\n\n"
                "Všechno dosavadní (rozkoukané, zhlédnuté, historie, seznamy) připadne prvnímu profilu. "
                "Na každém zařízení se pak při spuštění ukáže „Kdo se dívá?“.")


def run_convert_from_single() -> bool:
    """Samoobsluha „Jen já“ → více profilů (S24 D6, 15.10.2026 — do té doby slepá ulička: přechod jen přes správce).
    Stejný dialog jmen jako onboarding, bez otázky na zařízení (vše doby „Jen já“ patří prvnímu profilu, DP3), pak
    rovnou „Kdo se dívá?“ s novými profily. Gate převede účet touž cestou jako admin; ostatní zařízení účtu ukážou
    výběr při nejbližším menu (`apply_auth_block` → `request_chooser`). True = převedeno."""
    dlg = xbmcgui.Dialog()
    names = _ask_names(" (dostane dosavadní historii)")   # krátké: titulek klávesnice na TV se ořezává (Gemini B9)
    if not names:
        return False
    if not dlg.yesno("Založit profily?", "Profily: " + ", ".join(names) + "\n\n" + CONVERT_TEXT,
                     nolabel="Zpět", yeslabel="Založit"):
        return False
    try:
        with _fb.working("Zakládám profily…"):
            st = P.setup_multi(names, own_device=False, from_single=True)
    except P.ProfileGateError as exc:
        _notify_error("Profily se nepodařilo založit", exc)
        return False
    # Audit Fable N2: hlásit, co OPRAVDU vzniklo (Gate při souběhu — účet mezitím převedl někdo jiný — vrátí jeho profily)
    # pořadí slotů (= pořadí zadání; `profiles_cached` řadí podle použití), porovnání jako množina bez velikosti písmen
    created = [str(p.get("name") or "") for p in sorted(st.get("profiles") or [], key=lambda p: int(p.get("slot") or 0))
               if p.get("name")]
    same = sorted(n.casefold() for n in created) == sorted(n.casefold() for n in names)
    head = ("Profily založeny: " if same else "Profily už založil někdo jiný: ") + ", ".join(created or names)
    _log("convert_from_single: %d profiles (as requested: %s)" % (len(created), same), xbmc.LOGINFO)
    if _rm_dispatch.player_present(on_error=False):
        # S24 D5 (cross-check Codex #4): výběr nikdy, dokud existuje přehrávač (ani pozastavený) — rozehraný film
        # by se zapsal profilu vybranému uprostřed; výběr přijde při nejbližším hlavním menu po přehrávání.
        P.request_chooser("convert_from_single")
        _rm_dispatch.request_refresh(_rm_dispatch.ROOT_LISTING, "profile_chooser_postponed",
                                     _rm_dispatch.REFRESH_BLOCK_PLAYER, silent=True)   # spouštěč (audit Fable S1)
        _fb.info(head + ". „Kdo se dívá?“ se ukáže po skončení přehrávání.")
        return True
    _fb.info(head)
    request_chooser_now()
    return True


def _notify_error(head: str, exc: P.ProfileGateError) -> None:
    """Chyba Gate u profilů → věta pro člověka; kód a detail jen do logu (Φ2: dřív „Chyba: http_409“)."""
    msg = ("Server RichMovie právě neodpovídá — zkus to za chvíli." if exc.transient
           else "Nepovedlo se to — zkus to prosím znovu, případně napiš Richiemu.")
    _fb.warn(msg, heading=head)
    _log("%s: %s (%s)" % (head, exc.code, exc.detail[:120]), xbmc.LOGWARNING)


# ─────────────────────────────────────────────────────────────────────────────
#  Start hook
# ─────────────────────────────────────────────────────────────────────────────

def ensure_profile_at_start() -> bool:
    """Krok profilu uvítací sekvence (`_root()` po /auth). Onboarding (unset) → chooser (multi, jednou per běh Kodi
    nebo když si ho někdo vyžádal — `PROP_FORCE_CHOOSER`). Nikdy nevyhodí výjimku.

    Vrací True = krok proběhl (volající smí sekvenci označit za dokončenou), False = výběr ODLOŽEN, protože existuje
    přehrávač (S24 D5: výběr „Kdo se dívá?“ nikdy přes běžící ani pozastavené video — divák by se vrátil do
    modálního okna místo filmu). Sekvence pak zůstane otevřená a výběr přijde při dalším vstupu do hlavního menu."""
    try:
        st = P.load_state()
        forced = richmovie_winprops.get_prop(PROP_FORCE_CHOOSER, "") == "1"
        asked = richmovie_winprops.get_prop(PROP_SESSION_CHOSEN, "") == "1"
        if st.get("mode") == P.MODE_UNSET and st.get("setup_required"):
            if asked and not forced:
                return True   # „Později" = do restartu Kodi neotravovat (Fable P2-1)
            import time as _time
            if not forced and not P.onboarding_should_ask(st, _time.time()):
                # D1 (3.5.147): po opakovaném odložení nejvýš jednou za den — ne při každém startu
                _log("onboarding throttled (later=%s)" % st.get("onboarding_later"), xbmc.LOGDEBUG)
                return True
            richmovie_winprops.set_prop(PROP_SESSION_CHOSEN, "1")
            if run_onboarding():
                st = P.load_state()
        if st.get("mode") != P.MODE_MULTI:
            return True
        if asked and not forced:
            P.reconcile_multi_layout()   # Fable P1-2: data z doby jednoho profilu → majitel (idempotentní)
            return True
        if _rm_dispatch.player_present(on_error=False):
            # S24 D5: odložit VŠE (i přesun souborů — služba právě zapisuje postup přehrávání). Audit Fable S1: odklad
            # MUSÍ mít spouštěč — návrat do hlavního menu po videu Kodi bere z diskové cache BEZ pluginu (`CACHE_IF_SLOW`),
            # takže tichý požadavek do fronty obnov (S18): během přehrávání nestárne, po něm hlavní menu překreslí →
            # `_root` → otevřená sekvence → výběr.
            _rm_dispatch.request_refresh(_rm_dispatch.ROOT_LISTING, "profile_chooser_postponed",
                                         _rm_dispatch.REFRESH_BLOCK_PLAYER, silent=True)
            _log("chooser postponed: player present (forced=%s) — main menu refresh queued" % forced, xbmc.LOGINFO)
            return False
        P.reconcile_multi_layout()   # Fable P1-2: data z doby jednoho profilu → majitel (idempotentní)
        richmovie_winprops.clear_prop(PROP_FORCE_CHOOSER)
        richmovie_winprops.set_prop(PROP_SESSION_CHOSEN, "1")   # i po „Zpět": jednou za běh Kodi
        open_chooser(allow_back=bool(P.current_id() is not None))
        if P.current_id() is None:
            # Uživatel dal Back bez volby a nic nebylo vybráno → poslední profil zařízení nebo nic.
            _log("no profile chosen at start — personal data stay account-level until chosen", xbmc.LOGWARNING)
        return True
    except Exception as exc:
        _log("ensure_profile_at_start failed: %r" % (exc,), xbmc.LOGERROR)
        return True   # chyba se neopakuje dokola při každém menu (zalogováno; další start Kodi zkusí znovu)


def after_background_auth(mode_before: Optional[str]) -> None:
    """Volá vlákno `/auth` na pozadí (`plugin._gate_auth_background`) po ověření (S24 D5, R4). Když účet mezitím
    přešel na více profilů (převod na jiném zařízení / v adminu), `apply_auth_block` už vyžádal výběr — tady se
    stáhne seznam profilů (jména, fotky do výběru i řádku „Dívá se:“) a fronta obnov (S18) dostane tichý požadavek
    na hlavní menu: jakmile divák stojí v hlavním menu bez dialogu a bez přehrávání, menu se překreslí a výběr
    vyskočí. Bez přechodu jen doplní seznam, když chybí jméno aktivního profilu. Nikdy nevyhazuje."""
    try:
        switched = P.became_multi(mode_before, P.mode())
        if switched or P.needs_profile_list():
            try:
                P.fetch_profiles()
            except P.ProfileGateError as exc:
                _log("after_background_auth: profile list failed (%s) — chooser fetches it itself" % exc.code,
                     xbmc.LOGWARNING)
        if switched:
            _rm_dispatch.request_refresh(_rm_dispatch.ROOT_LISTING, "profile_mode_multi", "background_auth",
                                         silent=True)
    except Exception as exc:
        _log("after_background_auth failed: %r" % (exc,), xbmc.LOGWARNING)


def _refresh_profiles_background() -> None:
    """Obnova seznamu profilů z Gate mimo UI (chooser už stojí z cache). Non-daemon: zápis stavu
    profilů je atomický a krátký; invokace na vlákno počká až po zavření chooseru."""
    import threading

    def _work() -> None:
        try:
            P.fetch_profiles()
        except P.ProfileGateError as exc:
            _log("chooser: background refresh failed (%s) — cache platí" % exc.code, xbmc.LOGWARNING)
        except Exception as exc:
            _log("chooser: background refresh failed: %r" % (exc,), xbmc.LOGWARNING)

    threading.Thread(target=_work, name="RMProfilesRefresh").start()


def _fetch_profiles_with_feedback() -> Dict[str, Any]:
    """První načtení bez cache: nemodální průběh s textem (žádné holé čekání), Gate → cache (R2)."""
    with _fb.working("Načítám profily…"):
        try:
            return P.fetch_profiles()
        except P.ProfileGateError as exc:
            _log("chooser from cache (%s)" % exc.code, xbmc.LOGWARNING)
            return P.load_state()


def request_chooser_now() -> None:
    """Root řádek „Dívá se: …" / nastavení → otevřít chooser hned a překreslit menu."""
    richmovie_winprops.set_prop(PROP_FORCE_CHOOSER, "1")
    res = open_chooser()
    richmovie_winprops.clear_prop(PROP_FORCE_CHOOSER)
    if res is not None:
        _rm_dispatch.refresh_container("profile_chooser")


def root_label() -> str:
    """Text řádku v hlavním menu: „Dívá se: Richie ›" (multi) nebo "" (single)."""
    if not P.is_multi():
        return ""
    cur = P.current()
    name = cur.get("name") or "nevybráno"
    return "[COLOR FF3E9BF0]Dívá se:[/COLOR] %s  ›" % name


# ─────────────────────────────────────────────────────────────────────────────
#  Správa (Nastavení → Profily)
# ─────────────────────────────────────────────────────────────────────────────

def show_manage_dialog() -> None:
    dlg = xbmcgui.Dialog()
    st = P.load_state()
    if st.get("mode") != P.MODE_MULTI:
        if dlg.yesno(CONVERT_TITLE, "Teď je tu jeden profil pro všechny. Chceš založit profily pro více lidí?\n\n"
                     + CONVERT_TEXT, nolabel="Ne", yeslabel="Ano, založit"):
            if st.get("mode") == P.MODE_SINGLE:
                run_convert_from_single()   # S24 D6: sám, hned — žádné „napiš správci“
            else:
                run_onboarding()
        return
    try:
        # Správa potřebuje čerstvý seznam z Gate (přidat/odebrat) — tady se čeká, ale s textem (Φ2)
        with _fb.working("Načítám profily…"):
            st = P.fetch_profiles()
    except P.ProfileGateError as exc:
        _notify_error("Profily nejdou načíst", exc)
        st = P.load_state()
    profiles = P.profiles_cached(st)
    cur = P.current()
    options = ["Přepnout profil (teď: %s)" % (cur.get("name") or "nevybráno")]
    options.append("Toto zařízení je moje → přiřadit historii profilu „%s“" % (cur.get("name") or "?"))
    if len(profiles) < P.PROFILES_MAX:
        options.append("Přidat profil (%d/%d)" % (len(profiles), P.PROFILES_MAX))
    options.append("Přejmenovat profil")
    if len(profiles) > 2:
        options.append("Odebrat profil")
    options.append("Vyčistit historii profilu „%s“ na tomto zařízení" % (cur.get("name") or "?"))
    options.append("Zavřít")
    choice = dlg.select("Profily — %s" % ", ".join(str(p.get("name")) for p in profiles), options)
    if choice < 0 or options[choice] == "Zavřít":
        return
    label = options[choice]
    try:
        if label.startswith("Přepnout"):
            request_chooser_now()
        elif label.startswith("Toto zařízení"):
            if not P.has_active_profile():
                dlg.ok("Profily", "Nejdřív vyber profil.")
                return
            with _fb.working("Přiřazuji zařízení…"):
                n = P.claim_this_device(int(cur["id"]))
            _fb.info("Zařízení přiřazeno, %d záznamů historie připsáno." % n, heading="Profily")
        elif label.startswith("Přidat"):
            name = dlg.input("Jméno nového profilu", "", xbmcgui.INPUT_ALPHANUM)
            if name:
                with _fb.working("Zakládám profil…"):
                    p = P.create_profile(" ".join(name.split()))
                _fb.info("Přidán profil %s" % p.get("name", name), heading="Profily")
        elif label.startswith("Přejmenovat"):
            idx = dlg.select("Který profil přejmenovat?", [str(p.get("name")) for p in profiles])
            if idx >= 0:
                name = dlg.input("Nové jméno", str(profiles[idx].get("name") or ""), xbmcgui.INPUT_ALPHANUM)
                if name:
                    with _fb.working("Ukládám…"):
                        P.rename_profile(int(profiles[idx]["id"]), " ".join(name.split()))
                    _fb.info("Přejmenováno.", heading="Profily")
        elif label.startswith("Odebrat"):
            removable = [p for p in profiles if not p.get("is_owner")]
            idx = dlg.select("Který profil odebrat?", [str(p.get("name")) for p in removable])
            if idx >= 0 and dlg.yesno("Odebrat profil „%s“?" % removable[idx].get("name"),
                                      "Historie na tomto zařízení se smaže, na serveru zůstane skrytá. "
                                      "Doporučení profilu zmizí.", nolabel="Zpět", yeslabel="Odebrat"):
                with _fb.working("Odebírám profil…"):
                    P.delete_profile(int(removable[idx]["id"]))
                _fb.info("Profil odebrán.", heading="Profily")
        elif label.startswith("Vyčistit"):
            if P.has_active_profile() and dlg.yesno("Vyčistit historii?",
                                                    "Smaže historii, Pokračovat a zhlédnuté profilu „%s“ na tomto "
                                                    "zařízení. Server a doporučení se nemění." % cur.get("name"),
                                                    nolabel="Zpět", yeslabel="Vyčistit"):
                d = richmovie_paths.personal_dir()
                for name in richmovie_paths.personal_files_present(d):
                    try:
                        os.remove(str(d / name))
                    except Exception:
                        pass
                _fb.info("Historie profilu vyčištěna.", heading="Profily")
    except P.ProfileGateError as exc:
        _notify_error("Akce se nezdařila", exc)
