# -*- coding: utf-8 -*-
"""SSOT pohybu RichMovie — tokeny délek a křivek, animace pro `Control.setAnimations`, „Méně pohybu“ a lint L7.

Plán `Handoff/PLAN_televize_F4_20261108.md` §3.12, globál §9 (Richie 06.11.2026: „nikdy nesmí být nic ráz na ráz … plynulost,
easy in, easy out, všude animace, kde se to hodí“). Tokeny leží v `resources/data/rm_motion.json` (jediné místo čísel);
tenhle modul je čte, ověří a skládá z nich:
  * řetězce efektů pro `Control.setAnimations` (`effect`, `animations`, `morph_from`) — v modulech Televize jinde žádný
    literál `effect=` (lint L7, scénář 111);
  * dvojče „Méně pohybu“: posun / zoom → jen prolnutí (`animations(..., reduced=True)`), XML okna má dvojče s podmínkou
    `String.IsEqual(Window(Home).Property(rm_motion),reduced)`;
  * `lint_xml` — kontrola XML okna (časy z tokenů, `tween` + `easing`, dvojče, `WindowOpen` + `WindowClose`, žádný `pulse`,
    `scrolltime` s křivkou).
Bez Kodi importů na úrovni modulu (harness); Kodi se sahá jen ve `sync_reduced_property` / `reduced_active`.
"""
from __future__ import annotations

import json
import os
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional, Sequence, Tuple

DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "data", "rm_motion.json")
TOKEN_NAMES = ("press", "fade", "panel", "scroll", "morph", "window")
SAME_OUT = ("press", "fade")                    # vratné: odchod = příchod
SCALED_OUT = ("panel", "morph", "window")       # rozložení: odchod = 0,75 × příchod
OUT_RATIO = 0.75
EFFECTS = ("fade", "slide", "zoom")             # povolené typy efektů; `pulse`, `rotate*` ne (blikání / samoúčelné)
MOTION_EFFECTS = ("slide", "zoom")              # efekty s pohybem — v „Méně pohybu“ jen prolnutí
REDUCED_COND = "String.IsEqual(Window(Home).Property(rm_motion),reduced)"
FULL_COND = "!" + REDUCED_COND
SETTING_KEY = "motion_reduced"                  # resources/settings.xml (bool), čtení jen přes richmovie_settings
LOOP_RANGE_MS = (800, 3000)                     # nekonečná animace (`pulse`): klidné dýchání, ne blikání

_cache: Optional[dict] = None


class MotionError(ValueError):
    """Neplatná data tokenů (rm_motion.json) nebo nepovolený efekt."""


# ── tokeny ──────────────────────────────────────────────────────────────────────────────────────────────────────────
def validate(data: dict) -> dict:
    """Ověří data tokenů; vrátí je beze změny, jinak `MotionError` s přesným důvodem."""
    if not isinstance(data, dict) or data.get("v") != 1:
        raise MotionError("verze dat tokenů není 1")
    lo, hi = data.get("range_ms") or (None, None)
    if not (isinstance(lo, int) and isinstance(hi, int) and 0 < lo < hi):
        raise MotionError("range_ms chybí nebo je neplatný")
    tokens = data.get("tokens")
    if not isinstance(tokens, dict) or set(tokens) != set(TOKEN_NAMES):
        raise MotionError("sada tokenů není %s" % (TOKEN_NAMES,))
    for name in TOKEN_NAMES:
        t = tokens[name]
        t_in, t_out = t.get("in"), t.get("out")
        if not isinstance(t_in, int) or not lo <= t_in <= hi:
            raise MotionError("%s.in mimo %d–%d ms" % (name, lo, hi))
        if not t.get("tween") or t.get("easing") != "inout":
            raise MotionError("%s bez křivky tween + easing inout" % name)
        if name in SAME_OUT and t_out != t_in:
            raise MotionError("%s.out musí být = in (vratné)" % name)
        if name in SCALED_OUT and t_out != int(round(t_in * OUT_RATIO)):
            raise MotionError("%s.out musí být 0,75 × in" % name)
        if name == "scroll" and t_out is not None:
            raise MotionError("scroll nemá odchod")
    loops = data.get("loops", {})
    if not isinstance(loops, dict):
        raise MotionError("loops není objekt")
    for name, t in loops.items():
        period = t.get("period") if isinstance(t, dict) else None
        if not isinstance(period, int) or not LOOP_RANGE_MS[0] <= period <= LOOP_RANGE_MS[1]:
            raise MotionError("smyčka %s: perioda mimo %d–%d ms" % ((name,) + LOOP_RANGE_MS))
        if not t.get("tween") or t.get("easing") != "inout":
            raise MotionError("smyčka %s bez křivky tween + easing inout" % name)
        alpha = t.get("alpha")
        if alpha is not None and (not isinstance(alpha, int) or not 10 <= alpha <= 90):
            raise MotionError("smyčka %s: alpha mimo 10–90 (blikání / neviditelný pulz)" % name)
    return data


def load(path: str = DATA_PATH) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        return validate(json.load(fh))


def tokens() -> Dict[str, dict]:
    """Tokeny (soubor doplňku se za běhu nemění → jedno načtení na proces)."""
    global _cache
    if _cache is None:
        _cache = load()
    return _cache["tokens"]


def ms(name: str, direction: str = "in") -> int:
    t = tokens()[name]
    value = t["in"] if direction == "in" else t["out"]
    if value is None:
        raise MotionError("%s nemá %s" % (name, direction))
    return int(value)


def loop_times() -> set:
    """Periody povolených smyček (`loops` v rm_motion.json) — jen pro okna, která smyčku výslovně povolí."""
    if _cache is None:
        tokens()
    return {t["period"] for t in (_cache or {}).get("loops", {}).values()}


def allowed_times() -> set:
    return {v for t in tokens().values() for v in (t["in"], t["out"]) if v is not None}


# ── řetězce pro Control.setAnimations ───────────────────────────────────────────────────────────────────────────────
def effect(name: str, kind: str, direction: str = "in", **attrs) -> str:
    """`effect=<kind> … time=<token> tween=<token> easing=<token>` — jediné místo, kde vzniká řetězec efektu."""
    if kind not in EFFECTS:
        raise MotionError("efekt %s není povolený" % kind)
    t = tokens()[name]
    parts = ["effect=%s" % kind]
    for k in ("start", "end", "center", "delay"):
        if k in attrs and attrs[k] is not None:
            parts.append("%s=%s" % (k, attrs[k]))
    parts += ["time=%d" % ms(name, direction), "tween=%s" % t["tween"], "easing=%s" % t["easing"]]
    return " ".join(parts)


def animations(name: str, event: str, effects: Sequence[Tuple[str, dict]], *, direction: str = "in",
               reduced: bool = False) -> List[Tuple[str, str]]:
    """[(událost, efekt)] pro `setAnimations`; „Méně pohybu“ = jen prolnutí (posun / zoom vypadnou, prolnutí zůstane;
    když žádné nebylo, přidá se prolnutí podle směru)."""
    out = []
    for kind, attrs in effects:
        if reduced and kind in MOTION_EFFECTS:
            continue
        out.append((event, effect(name, kind, direction, **attrs)))
    if reduced and not out:
        # prolnutí se stejnou délkou jako původní animace (dvojče nesmí změnit rytmus rozhraní)
        fade = {"start": 0, "end": 100} if direction == "in" else {"start": 100, "end": 0}
        out.append((event, effect(name, "fade", direction, **fade)))
    return out


def _rect(r: Sequence[float]) -> str:
    x, y, w, h = (int(round(float(v))) for v in r)
    if w <= 0 or h <= 0:
        raise MotionError("obdélník bez plochy")
    return "%d,%d,%d,%d" % (x, y, w, h)


def morph_from(src: Sequence[float], dst: Sequence[float], *, direction: str = "in",
               reduced: bool = False) -> List[Tuple[str, str]]:
    """Karta se rozloží z tvaru prvku (`src` = x, y, w, h zaměřeného řádku) do svého místa (`dst`) a zpět. Zoom Kodi
    s absolutními obdélníky + prolnutí; „Méně pohybu“ = jen prolnutí. Událost Visible / Hidden podle směru."""
    a, b = (_rect(src), _rect(dst)) if direction == "in" else (_rect(dst), _rect(src))
    event = "Visible" if direction == "in" else "Hidden"
    fade = {"start": 0, "end": 100} if direction == "in" else {"start": 100, "end": 0}
    return animations("morph", event, [("zoom", {"start": a, "end": b}), ("fade", fade)], direction=direction,
                      reduced=reduced)


# ── „Méně pohybu“ ───────────────────────────────────────────────────────────────────────────────────────────────────
def sync_reduced_property() -> bool:
    """Nastavení → `Window(10000)` `rm_motion` (XML dvojčata se podle ní řídí); vrátí aktuální stav. Volá okno při otevření."""
    import xbmcgui
    import richmovie_settings as _st
    reduced = bool(_st.get_bool(SETTING_KEY))
    win = xbmcgui.Window(10000)
    if reduced:
        win.setProperty("rm_motion", "reduced")
    else:
        win.clearProperty("rm_motion")
    return reduced


def reduced_active() -> bool:
    import xbmcgui
    return xbmcgui.Window(10000).getProperty("rm_motion") == "reduced"


# ── lint L7 (XML okna) ──────────────────────────────────────────────────────────────────────────────────────────────
def _effects_of(anim: ET.Element) -> List[dict]:
    """Efekty animace: dlouhý tvar (`<effect …/>`) i krátký (`<animation effect="…" …>Událost</animation>`)."""
    if anim.get("effect"):
        return [dict(anim.attrib, type=anim.get("effect"))]
    return [dict(e.attrib) for e in anim.findall("effect")]


def _event(anim: ET.Element) -> str:
    return anim.get("type") or (anim.text or "").strip()


def rule_effect_types(anim: ET.Element, times: set) -> List[str]:
    return ["efekt %s není povolený" % e.get("type") for e in _effects_of(anim) if e.get("type") not in EFFECTS]


def rule_times(anim: ET.Element, times: set) -> List[str]:
    out = []
    for e in _effects_of(anim):
        try:
            t = int(e.get("time", ""))
        except ValueError:
            out.append("efekt %s bez času" % e.get("type"))
            continue
        if t not in times:
            out.append("čas %d ms není token %s" % (t, sorted(times)))
    return out


def rule_curves(anim: ET.Element, times: set) -> List[str]:
    return ["efekt %s bez tween + easing" % e.get("type") for e in _effects_of(anim)
            if not e.get("tween") or not e.get("easing")]


def rule_twin(parent: ET.Element) -> List[str]:
    """Animace s posunem / zoomem: podmínka plného pohybu + sourozenec téže události jen s prolnutím pro „Méně pohybu“."""
    out = []
    anims = parent.findall("animation")
    for anim in anims:
        kinds = {e.get("type") for e in _effects_of(anim)}
        if not kinds & set(MOTION_EFFECTS) or is_loop(anim):   # smyčku hlídá `rule_loop` (FULL_COND = bez pulzu)
            continue
        cond = (anim.get("condition") or "").replace(" ", "")
        if cond != FULL_COND and not cond.startswith(FULL_COND + "+"):     # plný pohyb (+ další podmínky okna)
            out.append("%s s pohybem bez podmínky %s" % (_event(anim), FULL_COND))
        twins = [a for a in anims if a is not anim and _event(a) == _event(anim)
                 and (a.get("condition") or "").replace(" ", "") == REDUCED_COND]
        if not twins or any({e.get("type") for e in _effects_of(t)} - {"fade"} for t in twins):
            out.append("%s s pohybem bez dvojčete jen s prolnutím (Méně pohybu)" % _event(anim))
    return out


def rule_window(root: ET.Element) -> List[str]:
    events = {_event(a) for a in root.findall("animation")}
    return ["okno bez animace %s" % ev for ev in ("WindowOpen", "WindowClose") if ev not in events]


def rule_scrolltime(el: ET.Element, times: set) -> List[str]:
    st = el.find("scrolltime")
    if st is None:
        return []
    out = []
    if not st.get("tween") or not st.get("easing"):
        out.append("scrolltime bez tween + easing")
    try:
        if int((st.text or "").strip()) not in times:
            out.append("scrolltime %s ms není token" % (st.text or "").strip())
    except ValueError:
        out.append("scrolltime bez času")
    return out


def is_loop(anim: ET.Element) -> bool:
    return (anim.get("pulse") or "").lower() == "true" or (anim.get("loop") or "").lower() == "true"


def rule_loop(anim: ET.Element, loops: Optional[set]) -> List[str]:
    """Nekonečná animace (`pulse` / `loop`): bez povolení okna zakázaná; s povolením jen s časem smyčky z tokenů a jen
    pro plný pohyb (podmínka `FULL_COND` na začátku — Méně pohybu = bez smyčky)."""
    if not is_loop(anim):
        return []
    if loops is None:
        return ["nekonečná animace (pulse/loop) není v tomto okně povolená"]
    out = []
    for e in _effects_of(anim):
        if e.get("type") != "fade":             # Kodi kreslí obrázky na celé pixely → pomalý zoom/posun skáče (4.3.1)
            out.append("smyčka smí jen prolínat (%s ve smyčce skáče po celých pixelech)" % e.get("type"))
        try:
            if int(e.get("time", "")) not in loops:
                out.append("smyčka %s ms není token loops %s" % (e.get("time"), sorted(loops)))
        except ValueError:
            out.append("smyčka bez času")
    if not (anim.get("condition") or "").replace(" ", "").startswith(FULL_COND):
        out.append("smyčka bez podmínky plného pohybu %s" % FULL_COND)
    return out


LINT_RULES = {"types": rule_effect_types, "times": rule_times, "curves": rule_curves}


def lint_xml(text: str, times: Optional[set] = None, *, allow_loops: bool = False) -> List[str]:
    """Porušení pravidel pohybu v XML okna (prázdný seznam = v pořádku). `allow_loops` = okno smí smyčku z tokenů
    `loops` (dnes jen „Kdo se dívá?“); jinak je nekonečná animace chyba."""
    times = allowed_times() if times is None else times
    loops = loop_times() if allow_loops else None
    root = ET.fromstring(text)
    out = list(rule_window(root))
    for parent in root.iter():
        if parent.findall("animation"):
            out += rule_twin(parent)
        for anim in parent.findall("animation"):
            out += rule_loop(anim, loops)
            if is_loop(anim):
                out += rule_curves(anim, times) + rule_effect_types(anim, times)   # čas smyčky hlídá rule_loop
                continue
            for rule in LINT_RULES.values():
                out += rule(anim, times)
        if parent.tag == "control":
            out += rule_scrolltime(parent, times)
    return out
