# -*- coding: utf-8 -*-
"""Přehrávač živého vysílání pro Televizi — inputstream.adaptive (08.11.2026, Televize F3 → F4).

Výpis kanálů a spuštění kanálu F3 (RmDir, `live_play` → `setResolvedUrl`) nahradilo okno Televize F4c
(`richmovie_tv_window`, router `live_home` / `live_play` → okno). Tady zůstává jen to, co potřebuje okno i služba:
`ensure_isa` (pojistka při otevření okna) a `ensure_isa_for_device` (služba při startu a à 10 min) — od 4.1.2 přítomnost
přehrávače zajišťuje závislost v `addon.xml`.
"""

from __future__ import annotations

import json

import xbmc

import richmovie_livetv as _tv

HEADING = "Televize"
_ISA_ID = _tv.ISA_ID


def _log(msg: str, warning: bool = False) -> None:
    try:
        import richmovie_logging as _rl
        lg = _rl.get_logger("richmovie.livetv")
        (lg.warning if warning else lg.info)(msg)
    except Exception:
        xbmc.log("[RichMovie/Televize] %s" % msg, xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def isa_available() -> bool:
    try:
        return bool(xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % _ISA_ID))
    except Exception:
        return False


ISA_MISSING_TEXT = ("Přehrávač živého vysílání (InputStream Adaptive) se na tomhle zařízení nepodařilo zapnout — vysílání "
                    "může po chvíli vypadnout.")
_missing_logged = False   # služba žije dny: „chybí“ do logu jednou za proces, ne à 10 min


def ensure_isa() -> bool:
    """Přehrávač živého vysílání (inputstream.adaptive) zapnutý? Bez něj hraje živý kanál vestavěný FFmpeg Kodi a ten
    na Chromecastu Petry 08.11.2026 skončil vždy po 22–31 s jako konec souboru (Nova, HBO, HBO 2: `isa=False`,
    `LIVE_ENDED kind=ended`), hrál jedinou variantu 11 Mbit/s a po přepnutí zvukové stopy ztichl. Relay za konec nemůže:
    FFmpeg 7.1 mimo Kodi hrál tentýž master živě přes 100 s (08.11. 07:53 a 07:58), cesta s ISA hraje na PC hodiny.
    Přítomnost ISA zajišťuje od 4.1.2 závislost v `addon.xml` (Kodi ho při aktualizaci stáhne z oficiálního repozitáře
    a vypnutý zapne — Android ho v balíčku NEMÁ: Chromecast Petry 4.1.1 `System.HasAddon` = False); tahle funkce je
    pojistka pro zařízení, kde ho někdo vypnul později.
    Nainstalovaný a vypnutý → zapnout JSON-RPC `Addons.SetAddonEnabled` (Kodi API k tomu určené, totéž dělá
    inputstreamhelper; vratné v Doplňcích). Vedlejší účinek: YouTube v RichMovie pak hraje DASH přes ISA (jeho zamýšlená
    cesta, `plugin._yt_has_inputstream_adaptive`). Nenainstalovaný → False (FFmpeg záložně + pravdivá věta).
    Rozhoduje stav Kodi po volání, ne text odpovědi. Uživatel nic nenastavuje ani nepotvrzuje (Richie 08.11.2026)."""
    global _missing_logged
    if isa_available():
        return True
    try:
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % _ISA_ID):
            if not _missing_logged:
                _missing_logged = True
                _log("LIVETV ISA missing — FFmpeg záložně", warning=True)
            return False
        raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                              "params": {"addonid": _ISA_ID, "enabled": True}}))
        ok = isa_available()
        _log("LIVETV ISA enable ok=%s rpc=%s" % (ok, str(raw)[:120]), warning=not ok)
        return ok
    except Exception as exc:
        _log("LIVETV ISA enable failed: %r" % (exc,), warning=True)
        return False


def ensure_isa_for_device(source: str) -> bool:
    """Služba — start (= i hned po aktualizaci doplňku) a à 10 min: zařízení s Televizí má přehrávač živého vysílání
    zapnutý dřív, než divák klikne na kanál (Richie 08.11.2026: „toto by se mělo automaticky zapnout s aktualizací, nechci,
    aby uživatel richmovie cokoliv musel nastavovat“). JEN zařízení s oprávněním `live_tv` (SSOT
    `richmovie_gate.is_live_tv_allowed`, fail-closed) — jinde se systémový doplněk Kodi nemění. Zapnutý = bez volání;
    oprávnění přidané později dožene další tik, spuštění kanálu má vlastní pojistku (`play`)."""
    try:
        import richmovie_gate as _gate
        if not _gate.is_live_tv_allowed():
            return False
    except Exception as exc:
        _log("LIVETV ISA ensure: oprávnění nečitelné (%r) — nic neměním" % (exc,), warning=True)
        return False
    if isa_available():
        return True
    ok = ensure_isa()
    _log("LIVETV ISA ensure source=%s ok=%s" % (source, ok))
    return ok
