# -*- coding: utf-8 -*-
"""
richmovie_routes — SSOT kontraktu rout: co akce pluginu UDĚLÁ, a tedy jestli je
klikací položka složka (3.5.153).

PROČ (incident 19.09.2026)
--------------------------
Položka doporučení se přidávala s `isFolder=False`, ale její akce staví ADRESÁŘ
streamů. Kodi pro nesložku navigaci vůbec nezahájí (`CGUIMediaWindow::GetDirectory`
se nezavolá), plugin postaví seznam do handle, který nikdo nekonzumuje, a uživatel
nevidí nic. Pět měsíců, celá flotila, 7 kliků. Tatáž vada žila v Moje ČSFD.

Příčina vady je strukturální: „co akce dělá" (router v `plugin.py`) a „jak se na ni
kliká" (`isFolder` u položky) byly DVĚ nezávislé pravdy na různých místech. Tenhle
modul z nich dělá jednu: stavitel položky se ptá registru, literál `isFolder=` psaný
od ruky u klikací položky je od teď chyba, kterou hlídá harness (scénář 65).

DRUHY
-----
  DIR     akce vykreslí adresář (`endOfDirectory` s položkami)      → isFolder=True
  PLAY    akce přehrává (`setResolvedUrl`)                           → isFolder=False
  ACTION  akce něco provede (dialog, zápis, `RunPlugin`)             → isFolder=False
  WINDOW  akce otevře vlastní okno RM 4.0 a adresář ZÁMĚRNĚ ukončí
          `succeeded=False`, aby Kodi zůstalo na místě. Položka je složka,
          protože jen tak Kodi plugin zavolá jako adresář a „neúspěch"
          tiše spolkne (ověřený vzor od RM 4.0, ne vada)             → isFolder=True

Čistý modul bez `xbmc*` → celý testovatelný v `_tools/net_resilience_sim/`.
"""
from __future__ import annotations

from typing import Dict, FrozenSet

DIR = "dir"
PLAY = "play"
ACTION = "action"
WINDOW = "window"


class UnknownRoute(KeyError):
    """Akce není v registru. Chyba PROGRAMÁTORA — nová akce se musí zapsat sem;
    harness (scénář 65) to vynucuje staticky, takže za běhu by nastat neměla."""


_DIR: FrozenSet[str] = frozenset({
    # kořen a hlavní menu
    "root", "reset_search_caches", "ai_menu", "streaming_home",
    # hledání a výpisy streamů
    "auto", "movie_search", "tv_search", "ws_search", "music_search",
    "tv_seasons", "tv_episodes", "tv_play", "tv_next_episode",
    # TMDb
    "genres", "tmdb_genres", "tmdb_genre", "similar_movies", "similar_tv",
    "tmdb_top", "tmdb_top_tv", "tmdb_trending", "tmdb_trending_tv",
    "tmdb_movie_trending", "tmdb_trending_movie", "tmdb_movie_top_rated", "tmdb_top_movie",
    "tmdb_tv_trending", "tmdb_tv_top", "tmdb_tv_top_rated",
    # AI a doporučení
    "ai_identify", "ai_recommend", "ai_recommend_results",
    "show_recommendations", "open_recommendation",
    # historie, Pokračovat, řady
    "cw_list", "recent_series", "history", "history_category",
    "watch_history", "watch_history_movies", "watch_history_tv",
    "rail_ai", "rail_collections", "rail_cw", "rail_recent_series",
    # kolekce
    "collections", "collections_browse", "collections_tv",
    # ČSFD
    "csfd_home", "csfd_tv_tips", "csfd_trailers", "csfd_top_films",
    "csfd_my_root", "csfd_my_ratings", "csfd_my_watchlist", "csfd_my_top_rated", "my_ratings_local",
    # lokální soubory
    "local_root", "local_browse",
    # alternativní zdroje
    "sktorrent_home", "sktorrent_search", "sktorrent_browse",
    "stream_home", "stream_category", "stream_show", "stream_season", "stream_search",
    "yt_home", "yt_search", "yt_trending", "yt_for_you", "yt_channel",
    "idnestv_home", "idnestv_latest", "idnestv_category",
    "novinky_home", "novinky_latest", "novinky_category",
})

_PLAY: FrozenSet[str] = frozenset({
    "play", "cw_play", "local_play", "sktorrent_play", "stream_play", "stream_quality",
    "yt_play", "idnestv_play", "novinky_play", "csfd_trailer_play", "music_item",
})

_ACTION: FrozenSet[str] = frozenset({
    # přihlášení, profil, diagnostika
    "silent_auth", "ws_login", "fs_login", "fs_login_onboard",
    "profile_choose", "profile_settings", "profile_av_prefs", "diag_upload", "clear_logs", "reset_settings",
    "ws_limit_probe",
    # ČSFD a hodnocení
    "csfd_settings", "csfd_sync_now", "csfd_my_resolve", "clear_rating", "rate_title",
    # doporučení
    "regenerate_recommendations", "dismiss_recommendation", "seen_recommendation", "delete_ai_history",
    # historie a Pokračovat
    "history_clear", "watch_history_clear", "continue_watching", "cw_remove", "cw_clear",
    "ep_mark_watched", "ep_unmark_watched",
    "play_from_start",   # 4.0.3 (A6): kontextové menu streamu rozkoukaného titulu — přehrát od začátku
    # stream: detail a stahování
    "detail", "download",
    # RM 4.0 custom okna a navigace
    "rm_streams", "rm_detail", "rm_grid", "rm_episodes", "rm_hub", "rm_search",
    "rm_nav_debounced", "noop",
})

_WINDOW: FrozenSet[str] = frozenset({
    "home_window",
    # Televize F4c (08.11.2026): vlastní okno s videem v okně; `live_play&ch=` (staré odkazy) = okno na kanálu
    "live_home", "live_play",
})

ROUTES: Dict[str, str] = {}
for _name in _DIR:
    ROUTES[_name] = DIR
for _name in _PLAY:
    ROUTES[_name] = PLAY
for _name in _ACTION:
    ROUTES[_name] = ACTION
for _name in _WINDOW:
    ROUTES[_name] = WINDOW

# Akce smí být jen v jedné množině — překryv by tiše vyhrál poslední zápis.
_OVERLAP = ((_DIR & _PLAY) | (_DIR & _ACTION) | (_PLAY & _ACTION)
            | (_WINDOW & (_DIR | _PLAY | _ACTION)))
if _OVERLAP:  # pragma: no cover — hlídá i harness
    raise RuntimeError("richmovie_routes: akce ve vice druzich: %s" % sorted(_OVERLAP))


# ── Třída ODEZVY (Φ2, 29.09.2026) ──────────────────────────────────────────────────────────────
# Kodi dává vlastní odezvu jen složce (kolečko po 100 ms) a přehratelné položce (kolečko resolve).
# Akce bez handle (ACTION) od Kodi nedostane NIC — odezvu musí dát addon. Do 3.5.160 to u části
# akcí znamenalo 1–12 s ticha před první sítí (audity A02, A07, A10) a dvojkliky.
#   FB_KODI     odezvu dává Kodi (DIR / WINDOW / PLAY; „Pokračovat“ přes dispatcher → resolve Kodi)
#   FB_INSTANT  akce hned ukáže dialog / okno nebo jen lokálně zapíše a potvrdí toastem — žádná síť
#               před první viditelnou věcí
#   FB_ADDON    akce jde na síť dřív, než něco ukáže → KAŽDÉ síťové volání jejího handleru musí ležet
#               uvnitř `with richmovie_feedback.working(…)` (harness scénář 73 to hlídá staticky)
#   FB_SILENT   záměrně bez UI (spouští ji služba, uživatel na ni neklikl)
FB_KODI = "kodi"
FB_INSTANT = "instant"
FB_ADDON = "addon"
FB_SILENT = "silent"

_FB_ADDON: FrozenSet[str] = frozenset({
    "ws_login", "fs_login", "fs_login_onboard",
    "csfd_settings", "csfd_sync_now", "csfd_my_resolve",
    "regenerate_recommendations", "dismiss_recommendation", "seen_recommendation", "delete_ai_history",
    "download", "profile_choose", "profile_settings", "diag_upload",
})

_FB_SILENT: FrozenSet[str] = frozenset({
    "silent_auth",
})

_FB_KODI_ACTIONS: FrozenSet[str] = frozenset({
    "continue_watching",   # Φ1: dispatcher → PlayMedia → kolečko resolve Kodi (souběh = toast „Už to spouštím…“)
})

_FB_INSTANT: FrozenSet[str] = _ACTION - _FB_ADDON - _FB_SILENT - _FB_KODI_ACTIONS

_FB_UNKNOWN = (_FB_ADDON | _FB_SILENT | _FB_KODI_ACTIONS) - _ACTION
if _FB_UNKNOWN:  # pragma: no cover — hlídá i harness
    raise RuntimeError("richmovie_routes: trida odezvy pro akci mimo ACTION: %s" % sorted(_FB_UNKNOWN))


def feedback_class(action: str) -> str:
    """Kdo dává odezvu na kliknutí na `action` (`FB_*`). Neznámá akce → `UnknownRoute`."""
    k = kind(action)
    if k != ACTION:
        return FB_KODI
    name = str(action or "").strip()
    if name in _FB_ADDON:
        return FB_ADDON
    if name in _FB_SILENT:
        return FB_SILENT
    if name in _FB_KODI_ACTIONS:
        return FB_KODI
    return FB_INSTANT


def addon_feedback_actions() -> FrozenSet[str]:
    """Akce, které jdou na síť před první viditelnou věcí (scénář 73 kontroluje jejich handlery)."""
    return _FB_ADDON


def kind(action: str) -> str:
    """Druh akce (`DIR` / `PLAY` / `ACTION` / `WINDOW`). Neznámá akce → `UnknownRoute`."""
    try:
        return ROUTES[str(action or "").strip()]
    except KeyError:
        raise UnknownRoute(action)


def is_folder(action: str) -> bool:
    """Hodnota `isFolder` pro klikací položku mířící na `action`.

    JEDINÝ zdroj té hodnoty. Literál psaný od ruky u klikací položky je vada —
    přesně tak vznikl incident 19.09.2026.
    """
    return kind(action) in (DIR, WINDOW)
