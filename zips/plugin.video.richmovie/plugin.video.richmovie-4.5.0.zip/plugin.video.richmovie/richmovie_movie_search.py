# -*- coding: utf-8 -*-
"""
richmovie_movie_search — SSOT hledání streamů FILMU (kontext filtru + primární a záložní vlna).

Proč (plán `Handoff/PLAN_televize_vod_20261108.md`, F2): tělo hledání filmu žilo v `plugin._auto_search_movie_run`,
provázané s dialogem, výpisem a chybovými hláškami, takže ho bez UI nešlo zavolat. Nabídka lepší verze při
sledování Televize potřebuje PŘESNĚ totéž hledání jako ruční výpis (stejné dotazy, stejný filtr, stejná cache).
Tenhle modul je přesun 1 : 1 — vzor `richmovie_episode_search`; UI (dialog, MediaInfo, výpis, SkTorrent, hlášky)
zůstává v `plugin.py`.

Modul nesmí importovat `plugin` (knihovna). Python 3.8 (Kodi).
"""
from __future__ import annotations

from itertools import permutations
from typing import Any, Callable, Dict, List, Optional, Sequence, Set, Tuple

from richmovie_engine import (
    Release,
    _ALT_COUNTRY_WHITELIST,
    _ALT_MAX_TITLES,
    norm as _norm,
)
from richmovie_webshare import APIError, TokenExpired
from tmdb_client import TMDbError, TMDbNotFoundError

PHASE_PRIMARY = "Hledám na Webshare a Fastshare…"
PHASE_ALT = "Hledám i pod jinými názvy…"

WAVE_PRIMARY = "P"
WAVE_ALT = "ALT"

STAGE_LOGIN = "login"
STAGE_API = "api"

# Jemná ruční doplnění pro známé série (nebo když kolekce chybí)
_MANUAL_BANNED = ("prometheus", "covenant", "resurrection", "aliens", "predator", "avp")

LogFn = Callable[..., None]


class MovieSearchContext(object):
    """Vstupy hledání filmu. Počítá `build_context` — jednou pro výpis i pro hledání bez UI."""

    __slots__ = ("tmdb", "tmdb_id", "det", "runtimes", "year_whitelist", "banned_keys",
                 "primary_q", "primary_norms", "degraded")


class CascadeResult(object):
    """Výsledek `run_cascade`: `rels` = streamy té vlny, která je našla (P, jinak ALT); `alt_titles` = alternativní
    názvy záložní vlny ([] = záložní vlna nebyla z čeho sestavit); `errors` > 0 = některý dotaz selhal (R2)."""

    __slots__ = ("rels", "wave", "cancelled", "alt_titles", "errors", "waves", "rate_limited")

    def __init__(self) -> None:
        self.rels: List[Release] = []
        self.wave = ""
        self.cancelled = False
        self.alt_titles: List[str] = []
        self.errors = 0
        self.waves: List[str] = []
        self.rate_limited = False


class WaveFailed(Exception):
    """Vlna skončila chybou zdroje. `stage` = `login` (obnova přihlášení selhala) | `api` (chyba Webshare),
    `wave` = P | ALT, `cause` = původní výjimka. Kód konce hledání i hlášku určuje volající."""

    def __init__(self, stage: str, wave: str, cause: BaseException) -> None:
        super().__init__("%s/%s: %r" % (stage, wave, cause))
        self.stage = stage
        self.wave = wave
        self.cause = cause


class CancelOnly(object):
    """Náhrada dialogu pro hledání bez UI: jediné, co umí, je říct „zrušeno“ (engine čte `iscanceled`)."""

    def __init__(self, should_cancel: Callable[[], bool]) -> None:
        self._should_cancel = should_cancel

    def __call__(self, *_a: Any, **_k: Any) -> None:
        return None

    def iscanceled(self) -> bool:
        try:
            return bool(self._should_cancel())
        except Exception:
            return False

    def set_phase(self, *_a: Any, **_k: Any) -> None:
        return None


def mark_wave(rels: Optional[List[Release]], tag: str) -> None:
    """Φ-A: vlna, která stream přinesla do výpisu (film P / ALT) — jen u položek bez značky (první vlna vyhrává).
    Nese se v cache až k `PLAY_PICK`."""
    for r in (rels or ()):
        try:
            if not getattr(r, "wave", ""):
                r.wave = tag
        except Exception:
            pass


def query_variants(
    title: str,
    original_title: str,
    year: Optional[int],
    *,
    alt_titles: Sequence[str] = (),
    qualities: Tuple[str, ...] = (),
) -> List[str]:
    """Všechny kombinace dotazů pro film: základní, originální a alternativní názvy, dvojice názvů v obou
    pořadích a pro každý název varianta s rokem + kvalitou a s rokem (bez roku, když rok není)."""
    # ❶ sesbíráme *všechny* relevantní názvy
    names: Set[str] = {title}
    if original_title and original_title.lower() != title.lower():
        names.add(original_title)

    for alt in alt_titles:
        if alt and alt.lower() not in {n.lower() for n in names}:
            names.add(alt)

    # ❷ přidáme obousměrné dvojice ("A B" ↔ "B A")
    for a, b in permutations(list(names), 2):
        names.add(f"{a} {b}")

    # ❸ finalizujeme dotazy
    variants: List[str] = []
    for name in names:
        base = f"{name} {year}" if year else name
        variants.extend(f"{base} {q}" for q in qualities)  # + kvalita
        variants.append(base)                              # bez kvality
    return variants


def _note_tmdb_failure(ctx: MovieSearchContext, exc: BaseException) -> None:
    """„Nenalezeno“ je autoritativní odpověď; cokoli jiného znamená chudší kontext → prázdný výsledek pak není
    autoritativní (R2, stejný výklad jako `richmovie_episode_search`)."""
    if not isinstance(exc, TMDbNotFoundError):
        ctx.degraded += 1


def build_context(tmdb: Any, tmdb_id: int) -> MovieSearchContext:
    """Detail, stopáže, roky, lokalizované názvy, BAN klíče kolekce, dotazy primární vlny.

    `TMDbError` z detailu nebo stopáží propaguje (bez detailu se hledat nedá, hlášku určí volající); selhání
    doplňkových údajů znamená chudší kontext (`degraded`), hledání běží dál. `det["rm_runtimes"]` = referenční
    stopáže pro runtime sanity ve výpisu (parita s TV listem)."""
    ctx = MovieSearchContext()
    ctx.tmdb = tmdb
    ctx.tmdb_id = tmdb_id
    ctx.degraded = 0

    det = tmdb.details(tmdb_id)
    ctx.det = det

    # Stopáže: primární + alternativní
    runtimes = [int(det.get("runtime") or 0)] + tmdb.get_alt_runtimes(tmdb_id)

    # Whitelist povolených roků pro FILTR (produkční + hlavní trhy)
    try:
        ctx.year_whitelist = tmdb.allowed_years(tmdb_id, primary_year=det.get("year"))
    except TMDbError as exc:
        ctx.year_whitelist = []
        _note_tmdb_failure(ctx, exc)

    # vyčistit stopáže (minuty > 0) + dedupe
    runtimes = [rt for rt in runtimes if rt]
    try:
        runtimes = sorted({int(rt) for rt in runtimes if int(rt) > 0})
    except Exception:
        pass
    ctx.runtimes = runtimes

    # NOVĚ: reference stopáže pro runtime sanity ve výpisu streamů (best-effort)
    try:
        det["rm_runtimes"] = list(runtimes)
    except Exception:
        pass

    # BAN klíče z TMDb kolekce (vyřadí Prometheus/Covenant/… i když v názvu není rok)
    # collection_parts() VRACÍ LIST ŘETĚZCŮ (titulů), nikoli dict – proto s nimi pracujeme jako s texty.
    banned_keys: Set[str] = set()
    coll = det.get("belongs_to_collection") or {}
    coll_id = 0
    if isinstance(coll, dict):
        try:
            coll_id = int(coll.get("id") or 0)
        except Exception:
            coll_id = 0

    # Φ-B (30.09.2026, E3-F02): oficiální lokalizované názvy (EN, CS, SK, PL) — JEN pro filtr (shoda názvu,
    # vlastní slova cíle se nebanují). Dotazy se nemění (žádný požadavek navíc na Webshare / Fastshare).
    try:
        loc_titles = [t for t in tmdb.movie_localized_titles(tmdb_id)
                      if _norm(t) and _norm(t) not in (_norm(det.get("title") or ""),
                                                       _norm(det.get("original_title") or ""))]
    except TMDbError as exc:
        loc_titles = []
        _note_tmdb_failure(ctx, exc)
    loc_norms = {_norm(t) for t in loc_titles}

    base_norms = {_norm(det.get("title") or ""), _norm(det.get("original_title") or "")} | loc_norms
    base_norms.discard("")
    base_words = {w for nm in base_norms for w in nm.split() if w}

    if coll_id:
        try:
            # 2025-09-28 FIX: ban-klíče z kolekce nesmí odstřelit aktuální díl
            #  • Jednoslovný kořen, který je součástí názvu aktuálního filmu, NEBANUJEME.
            #  • Víceslovou frázi přidáme jen tehdy, pokud obsahuje aspoň JEDNO slovo mimo aktuální název.
            for title in (tmdb.collection_parts(coll_id) or []):
                nt = _norm(title)
                if not nt or nt in base_norms:
                    # přesný název právě hledaného dílu nebanovat
                    continue

                nt_words = [w for w in nt.split() if w]

                # 1) celá fráze JEN když má ≥2 slova A není čistým subsetem slov aktuálního filmu
                #    – falešné zásahy typu "equalizer" u "equalizer 2" nebo "john wick" u "john wick 2"
                if len(nt_words) >= 2 and not set(nt_words).issubset(base_words):
                    banned_keys.add(nt)

                # 2) výrazná slova (≥4 znaky), která nejsou součástí aktuálního filmu
                for w in nt_words:
                    if len(w) >= 4 and w not in base_words:
                        banned_keys.add(w)

        except TMDbError as exc:
            _note_tmdb_failure(ctx, exc)

    for w in _MANUAL_BANNED:
        if w not in base_words:
            banned_keys.add(w)

    # Sanity: odfiltruj prázdné/čistě číselné tokeny
    ctx.banned_keys = {bk for bk in banned_keys if bk and not bk.isdigit()}

    # primární dotazy (bez alt-titlů)
    ctx.primary_q = query_variants(det["title"], det["original_title"], det["year"])
    primary_norms = {_norm(det["title"]), _norm(det["original_title"])} | loc_norms
    ctx.primary_norms = primary_norms
    return ctx


def alt_titles_of(tmdb: Any, tmdb_id: int) -> List[str]:
    """Alternativní názvy pro záložní vlnu. Selhání TMDb = žádná záložní vlna (vyhodnotí volající)."""
    return [rec["title"]
            for rec in tmdb.alternative_titles(tmdb_id, max_items=_ALT_MAX_TITLES)
            if rec["country"] in _ALT_COUNTRY_WHITELIST]


def run_cascade(engine: Any, ctx: MovieSearchContext, *, log_event: LogFn, progress: Any = None,
                relogin: Optional[Callable[[], None]] = None,
                should_cancel: Optional[Callable[[], bool]] = None,
                kick_mi2: bool = True) -> CascadeResult:
    """Primární vlna, a když nic nenašla, záložní vlna s alternativními názvy.

    `progress` = dialog (nebo `CancelOnly`), `relogin` = obnova přihlášení po `TokenExpired`, po ní vlna běží znovu
    bez dialogu (bez `relogin` výjimka propaguje). `should_cancel` se ptá po každé vlně. `kick_mi2=False` = hledání
    na pozadí nespouští sken MediaInfo. Chyba zdroje = `WaveFailed`; zrušené ani neúplné hledání se neukládá (R2,
    hlídá engine)."""
    det = ctx.det
    banned = list(ctx.banned_keys)
    memo: Dict[str, Any] = {}     # Φ-C: záložní vlna obsahuje i primární dotazy a nestahuje je podruhé
    result = CascadeResult()
    prog = {"cur": progress}

    def _wave(queries: Sequence[str], norms: Any, tag: str) -> List[Release]:
        stats: Dict[str, Any] = {}

        def _call(cb: Any) -> List[Release]:
            return engine.search_movie_wave(
                queries, runtimes=ctx.runtimes, title_norms=norms, banned_keys=banned,
                movie_year=det["year"], allowed_years=ctx.year_whitelist, progress_cb=cb,
                fetch_memo=memo, stats=stats, kick_mi2=kick_mi2,
            )

        try:
            found = _call(prog["cur"])
        except TokenExpired:
            if relogin is None:
                raise
            prog["cur"] = None
            try:
                relogin()
                found = _call(None)
            except Exception as exc:
                raise WaveFailed(STAGE_LOGIN, tag, exc) from exc
        except APIError as exc:
            raise WaveFailed(STAGE_API, tag, exc) from exc
        result.errors += int(stats.get("errors") or 0)
        result.rate_limited = result.rate_limited or bool(stats.get("rate_limited"))
        result.waves.append(tag)
        if should_cancel is not None and should_cancel():
            result.cancelled = True
        if stats.get("cancelled"):
            result.cancelled = True
        return found

    def _phase(text: str) -> None:
        if prog["cur"] is not None:
            prog["cur"].set_phase(text)

    _phase(PHASE_PRIMARY)
    rels = _wave(ctx.primary_q, ctx.primary_norms, WAVE_PRIMARY)
    if result.cancelled:
        return result
    mark_wave(rels, WAVE_PRIMARY)
    if rels:
        result.rels = rels
        result.wave = WAVE_PRIMARY
        return result

    _phase(PHASE_ALT)
    try:
        result.alt_titles = alt_titles_of(ctx.tmdb, ctx.tmdb_id)
    except TMDbError as exc:
        result.alt_titles = []
        _note_tmdb_failure(ctx, exc)
    if not result.alt_titles:
        return result

    log_event("SEARCH_FALLBACK", det["title"], len(result.alt_titles))
    alt_q = query_variants(det["title"], det["original_title"], det["year"],
                           alt_titles=result.alt_titles, qualities=())
    alt_norms = ctx.primary_norms | {_norm(t) for t in result.alt_titles}
    rels_alt = _wave(alt_q, alt_norms, WAVE_ALT)
    if result.cancelled:
        return result
    mark_wave(rels_alt, WAVE_ALT)
    if rels_alt:
        result.rels = rels_alt
        result.wave = WAVE_ALT
    return result


def empty_is_authoritative(result: CascadeResult, ctx: MovieSearchContext) -> bool:
    """Smí se „nic nenalezeno“ zapamatovat? Jen po celé kaskádě bez chyby přenosu a s plným kontextem (R2)."""
    return (not result.rels and not result.cancelled and not result.errors
            and not int(getattr(ctx, "degraded", 0) or 0) and bool(result.waves))
