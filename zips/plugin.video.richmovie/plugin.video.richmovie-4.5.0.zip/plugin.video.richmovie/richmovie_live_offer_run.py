# -*- coding: utf-8 -*-
"""Nabídka lepší verze při sledování Televize — běh ve službě (plán `Handoff/PLAN_televize_vod_20261108.md` v2, §4).

Služba volá `OfferRunner.tick` z hlavní smyčky. Runner je jediný zapisovatel vlastnosti `richmovie.live.offer`, okno Televize je
jediný čtenář (stejný vzor jako `PROP_LIVE_STATE`). Hledání běží ve vlákně TOUTÉŽ kaskádou jako ruční výpis (`plugin._search_movie`,
`plugin._search_episode`), takže výsledek jde do stejné cache; po přepnutí kanálu se zruší a nic neuloží (R2).

Vše z Kodi a pluginu dostává přes `deps`, ať jde testovat bez Kodi (harness 119). Python 3.8.
"""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

import richmovie_live_offer as _lo
import richmovie_play_params as _params
import richmovie_quality as _quality
import richmovie_tv_vod as _vod


COOLDOWN_S = 1800.0        # po 429, chybě nebo neúplném hledání


def verified_class(rel: Any, mediainfo: Optional[Dict[str, Any]]) -> int:
    """Třída kvality, kterou lze SLÍBIT: změřená MediaInfo, jinak rozměry z Webshare. Jen název souboru nestačí (0 = neznámá)."""
    video = (mediainfo or {}).get("video") if isinstance(mediainfo, dict) else None
    info = video if isinstance(video, dict) else {}
    width, height = info.get("width"), info.get("height")
    if not height:
        width, height = getattr(rel, "ws_width", None), getattr(rel, "ws_height", None)
    return int(_quality.resolution_class(width, height) or 0) if height else 0


def live_height(process_height: Any, resolution_label: Any) -> int:
    """Výška živého obrazu z infolabelů Kodi: `Player.Process(videoheight)` („1,080“), jinak `VideoPlayer.VideoResolution` („1080“, „4K“)."""
    digits = "".join(ch for ch in str(process_height or "") if ch.isdigit())
    if digits and int(digits) > 0:
        return int(digits)
    label = str(resolution_label or "").strip().lower()
    if label == "4k":
        return 2160
    digits = "".join(ch for ch in label if ch.isdigit())
    return int(digits) if digits else 0


class OfferRunner(object):
    def __init__(self, deps: Any) -> None:
        self.d = deps
        self._csid, self._channel = "", ""
        self._since = 0.0
        self._next_eval = 0.0
        self._next_video = 0.0
        self._live_h = 0
        self._running: Optional[str] = None     # csid běžícího hledání
        self._gen = 0
        self._cooling_until = 0.0
        self._published = False
        self._published_event = ""

    # ── stav relace ──────────────────────────────────────────────────────────────────────────────────────────────────
    def _clear(self) -> None:
        if self._published:
            self.d.publish("")
            self._published = False

    def _reset(self) -> None:
        self._gen += 1                          # běžící hledání je tím zrušené (`_stale`)
        self._csid, self._channel, self._since, self._next_eval, self._next_video, self._live_h = "", "", 0.0, 0.0, 0.0, 0
        self._clear()

    def tick(self, playing: bool, channel: str, csid: str) -> None:
        now = self.d.mono()
        if not playing or not csid:
            if self._csid:
                self._reset()
            return
        if csid != self._csid:
            self._reset()
            self._csid, self._channel, self._since = csid, channel, now
        if now >= self._next_video:
            self._measure_video(now)
        if now < self._next_eval or self._running is not None:
            return
        self._next_eval = now + _lo.EVAL_S
        self._evaluate(now)

    def _measure_video(self, now: float) -> None:
        self._next_video = now + 15.0
        height = self.d.live_height()
        if height > self._live_h:                # nejvyšší naměřená: adaptivní pokles ani reklama v nižší kvalitě nesmí vyrobit slib
            self._live_h = height
            self.d.log("LIVE_VIDEO h=%d ch=%s" % (height, self._channel))

    # ── rozhodnutí ───────────────────────────────────────────────────────────────────────────────────────────────────
    def _evaluate(self, now: float) -> None:
        current = self.d.current_event(self._channel)
        shown = (current or {}).get("event")
        if self._published and isinstance(shown, dict) and self._event_key(shown) != self._published_event:
            self._clear()                       # pořad skončil a kanál běží dál: nabídka patřila jemu
        vod = _vod.vod_of(shown)
        if vod is None:
            return
        event = current["event"]
        wall = self.d.wall()
        times = self.d.event_times(event)
        left = (times["end_ts"] - wall) if times else None
        until, recent, readable = _lo.checked_state(wall)
        if not readable:
            return
        dwell = now - self._since
        if times:
            dwell = min(dwell, wall - times["start_ts"])    # kulisa: i nový pořad na témže kanálu má své čekání
        block = _lo.check_block(
            kind=vod.get("kind"), dwell_s=dwell, left_s=left, done=_lo.is_done(until, vod),
            dismissed=_lo.is_dismissed(self._event_key(event), wall),
            budget_left=_lo.checks_last_hour(recent, wall) < _lo.MAX_CHECKS_PER_H,
            offline=self.d.offline(), host_down=self.d.host_down(), filtered=self.d.filtered(), cooling=now < self._cooling_until,
        )
        if block:
            if block not in (_lo.SKIP_DWELL, _lo.SKIP_DONE):      # tiše to, co nastává běžně
                self.d.log("LIVE_VOD_CHECK skip=%s ev=%s" % (block, event.get("id") or "-"))
            return
        self._running = self._csid
        job = {"gen": self._gen, "csid": self._csid, "channel": self._channel, "vod": vod, "event": event, "times": times,
               "ads_channel": bool(current.get("ads_channel")), "live_class": self._live_class()}
        self.d.spawn("RMLiveOffer", lambda: self._work(job))

    def _live_class(self) -> int:
        return int(_quality.resolution_class(None, self._live_h) or 0) if self._live_h else 0

    @staticmethod
    def _event_key(event: Dict[str, Any]) -> str:
        return str(event.get("id") or "%s|%s" % (event.get("title"), event.get("start")))

    def _stale(self, job: Dict[str, Any]) -> bool:
        return job["gen"] != self._gen or self.d.aborted()

    # ── hledání ──────────────────────────────────────────────────────────────────────────────────────────────────────
    def _work(self, job: Dict[str, Any]) -> None:
        t0 = self.d.mono()
        vod = job["vod"]
        result = "err"
        try:
            result = self._search_and_offer(job, t0)
        except Exception as exc:
            self._cooling_until = self.d.mono() + COOLDOWN_S    # selhání se neopakuje hned (a nic se o titulu nezapsalo, R2)
            if self.d.rate_limited_error(exc):
                self._permit(_lo.permit_key(vod), "rate_limited")
            self.d.log("LIVE_VOD_CHECK err ev=%s err=%r" % (job["event"].get("id") or "-", exc), warning=True)
        finally:
            self.d.log("LIVE_VOD_CHECK end result=%s ms=%d kind=%s tmdb=%s live=%d" % (
                result, int((self.d.mono() - t0) * 1000), vod.get("kind"), vod.get("tmdb"), job["live_class"]))
            self._running = None

    def _permit(self, key: str, report: Optional[str] = None) -> str:
        try:
            verdict = self.d.permit(key, report)
        except Exception as exc:
            self.d.log("LIVE_VOD_PERMIT failed: %r" % (exc,), warning=True)
            return "unavailable"
        return "ok" if verdict.get("allowed") else str(verdict.get("reason") or "denied")

    def _search_and_offer(self, job: Dict[str, Any], t0: float) -> str:
        vod = job["vod"]
        key = _lo.permit_key(vod)
        verdict = self._permit(key)
        if verdict != "ok":                     # bez odpovědi Gate se nehledá (§10.5)
            if verdict == "duplicate":
                _lo.remember_check(vod, self.d.wall())    # titul už účet prohledal z jiného zařízení
            else:
                self._cooling_until = self.d.mono() + COOLDOWN_S    # jinak by se služba ptala Gate každých 30 s
            return "blocked_" + verdict
        self.d.log("LIVE_VOD_CHECK begin ev=%s kind=%s tmdb=%s" % (job["event"].get("id") or "-", vod["kind"], vod["tmdb"]))
        _lo.note_attempt(self.d.wall())          # rozpočet se počítá i z hledání, které spadne
        should_cancel = lambda: self._stale(job)  # noqa: E731
        stats: Dict[str, Any] = {}
        if vod["kind"] == _lo.KIND_MOVIE:
            rels = self.d.search_movie(int(vod["tmdb"]), should_cancel, stats)
        else:
            rels = self.d.search_episode(str(vod["tmdb"]), vod.get("tv_name") or "", int(vod["season"]), int(vod["episode"]),
                                         vod.get("ep_title") or "", should_cancel, stats)
        if stats.get("rate_limited"):
            self._cooling_until = self.d.mono() + COOLDOWN_S
            self._permit(key, "rate_limited")
        if self._stale(job):
            return "cancelled"
        if not rels and not stats.get("authoritative"):
            self._cooling_until = self.d.mono() + COOLDOWN_S    # neúplné hledání: titul zůstává k dohledání (R2)
            return "incomplete"
        _lo.remember_check(vod, self.d.wall())
        if not rels:
            return "empty"
        return self._offer_from(job, rels, _lo.title_key(vod))

    def _offer_from(self, job: Dict[str, Any], rels: Any, key: str) -> str:
        vod = job["vod"]
        candidates = [r for r in rels if _lo.language_ok(getattr(r, "audios", None))]
        if not candidates:
            return "no_language"
        best = self.d.pick_best(candidates, vod)
        if best is None or not self.d.playable(best):
            return "no_playable"
        vod_class = verified_class(best, self.d.mediainfo(best))
        times = job["times"]
        runtime_s = float(vod.get("runtime") or 0) * 60.0
        slot_s = (times["end_ts"] - times["start_ts"]) if times else 0.0
        ads = _lo.has_ads(job["ads_channel"], slot_s, runtime_s)
        label = _lo.offer_label(vod_class, job["live_class"], ads)
        if not label:
            return "no_better"
        if self._stale(job):
            return "cancelled"
        if vod["kind"] == _lo.KIND_MOVIE:
            qs = _params.for_release(best, movie={"title": vod.get("title"), "year": vod.get("year"), "id": vod["tmdb"]})
            title = str(vod.get("title") or "")
        else:
            qs = _params.for_release(best, episode={"tv_id": str(vod["tmdb"]), "tv_name": vod.get("tv_name"), "season": vod["season"],
                                                    "episode": vod["episode"], "ep_title": vod.get("ep_title")})
            title = "%s · S%02dE%02d" % (vod.get("tv_name") or vod.get("title") or "", int(vod["season"]), int(vod["episode"]))
        qs["origin"] = _lo.ORIGIN_TV
        offer = {
            "csid": job["csid"], "channel": job["channel"], "event": self._event_key(job["event"]), "kind": vod["kind"], "title": title,
            "year": vod.get("year") or 0, "poster": vod.get("poster") or "", "label": label, "ads": ads, "url": self.d.url(qs),
            "key": key, "ident": str(qs.get("ident") or ""), "tmdb": vod["tmdb"], "start_ts": times["start_ts"], "end_ts": times["end_ts"],
            "runtime_s": runtime_s, "slot_s": slot_s,
        }
        self.d.publish(json.dumps(offer, ensure_ascii=False))
        self._published, self._published_event = True, offer["event"]
        self.d.log("LIVE_VOD_OFFER ready ev=%s label=%s vod=%d live=%d" % (offer["event"], label, vod_class, job["live_class"]))
        return "offer"


__all__ = ["OfferRunner", "live_height", "verified_class"]
