# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_livetv_prefs — osobní seznam televizních kanálů per profil (Televize F4 §6, 08.11.2026)
═══════════════════════════════════════════════════════════════════════════════
Plán: `Handoff/PLAN_televize_F4_20261108.md` §6 (R7 „není možné si programy seřadit“). Vlastní pořadí s plynulým
přesunem, ★ oblíbené, skryté, poslední + předchozí kanál — per profil a napříč zařízeními přes SSOT
`richmovie_profile_items` jako JEDNA kolekce `tv_channels` (Gate mig 0050, `app/profiles/tv_channels.py`).

MODEL (§6.1)
  P  = pořadí poskytovatele dostupných kanálů: `(position je None, position, název, id)` — `provider_order`.
  prefix = uložený začátek vlastního pořadí. EFEKTIVNÍ pořadí  E = prefix ∩ P (bez duplicit) + (P − prefix v pořadí P).
       Kanál, který z nabídky zmizel, z E tiše vypadne (v prefixu zůstane do dalšího zápisu); nový kanál poskytovatele
       se objeví na svém místě za prefixem.
  Po přesunu se z nového pořadí D uloží NEJKRATŠÍ prefix k, pro který E(P, D[:k]) == D (`shortest_prefix`):
       Nova nahoru = 1 ID, ČT1 dolů = celý seznam bez posledního.
  Skryté zůstávají v E na svém místě (Vrátit = zpět tam, kde byly), z panelu, čísel a ▲▼ vypadnou.
  Oblíbené = filtr viditelného E (pořadí oblíbených = pořadí v E).
  ČÍSLO KANÁLU = index ve VIDITELNÉM E + 1 (rozhodnutí Richieho R-3, 08.11.2026).
  `last` (poslední + předchozí kanál) se zapisuje až po `LAST_MIN_WATCH_S` sledování — listování nezaplaví frontu.
  „Obnovit výchozí pořadí“ = tombstone `order`; oblíbené a skryté zůstávají.

KOLEKCE (§6.2) — klíč / payload / tombstone
  order        {"v": 1, "n": <počet>, "ids": "nova,ct1,ct2"}      výchozí pořadí
  fav:<kanál>  {"ts": <epoch>}                                    není oblíbený
  hide:<kanál> {"ts": <epoch>}                                    není skrytý
  last         {"ch": "<kanál>", "prev": "<kanál>"|"", "ts": <epoch>}
  Strop drží STAVITEL (`encode_order`, `ORDER_MAX_BYTES` 3 400 B): `shrink_payload` by nad svým stropem useknul ID
  v půlce řetězce. Přetečení = nejdelší prefix, který se vejde, + log `TV_ORDER_TRUNCATED` (zbytek jde v pořadí
  poskytovatele) — nikdy 422, nikdy karanténa. Lokálně se uloží TENTÝŽ zkrácený prefix (všechna zařízení vidí totéž).
  PARITA: `parse_item` je zrcadlo Gate `app/profiles/tv_channels.parse_item`; obě strany čtou sdílenou sadu
  `RichMovie-nas/_tools/fixtures/tv_channels_items.json` (harness scénář 107, test Gate `profile_items_test.py`).

SOUBĚH (vědomá mez): `fav:` / `hide:` jsou per kanál → změny na dvou zařízeních se sloučí (LWW per kanál). `order` je
  JEDNA položka → dva souběžné přesuny na dvou zařízeních během sekund = vyhraje novější. Jeden člověk v jednom profilu
  řadí na jednom místě; sloučení dvou různých pořadí by nemělo pravdivý výsledek.

LOKÁLNÍ SOUBOR profilu `tv_channels.json` (`richmovie_paths.PERSONAL_FILES`):
  {"v": 1, "order": {"ids": [...], "ts": t}, "fav": {"<id>": {"on": bool, "ts": t}}, "hide": {...},
   "last": {"ch": "", "prev": "", "ts": t}}
  LOKÁLNÍ TOMBSTONY s časem (`"on": false`, prázdné `ids`, prázdné `ch`): starší položka z pullu nesmí vzkřísit právě
  zrušenou ★, dokud fronta ještě neodeslala. Úklid po `TOMBSTONE_RETENTION_S` (= Gate `TOMBSTONE_RETENTION_DAYS`).
  Zápis `richmovie_atomic` pod `richmovie_paths.personal_lock(FILE_NAME)`; čtení podle otisku souboru (mtime_ns +
  velikost, okno hrubých časů FS) — okno i služba jsou různé procesy.

BRZDA ZÁPISŮ (§6.3 + globál §15) — `TV_SYNC_PUSH`:
  `SYNC_OFF`   lokální změny jen na disk (náhled F4d, než Gate s mig 0050 prokazatelně běží — STOP S-F4-3);
  `SYNC_PROBE` do fronty jde JEN ★ (`fav:<kanál>`) — „jedna položka ručně → kontrola řádku na Gate“;
  `SYNC_ON`    vše + jednorázový seed lokálního stavu (`richmovie_profile_items._seed_tv_channels`).
  Konstanta, NE nastavení: brzda je vývojová pojistka zavádění (uživatel ji nemá vidět ani přepínat — §9), mění se
  s kódem jednou pro všechny (vydání = `SYNC_ON`, hlídá to brána sestavení `_release/release_manifest.release_invariants`)
  a nepřežije v userdata zařízení.
  Čtení z Gate (pull → `apply_remote`) brzda neomezuje — nic nezapisuje na Gate.
  Host (bez profilu) = jen lokálně: `richmovie_profile_items.note_change` vrací False.

Čistý modul: žádné importy Kodi na úrovni modulu (`richmovie_paths`, `richmovie_atomic`, logování, `richmovie_ui_common`
a `richmovie_profile_items` až za běhu). Python 3.8 (Kodi 21 Windows) → `from __future__ import annotations`.
Harness: `_tools/net_resilience_sim/scenario_livetv_prefs.py` (scénář 107) včetně negativních mutací.
"""
from __future__ import annotations

import json
import math
import os
import re
import threading
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import richmovie_sync_queue as _sq   # jen stdlib — SSOT formátu času Gate (`to_epoch`)

COLLECTION = "tv_channels"
FILE_NAME = "tv_channels.json"
FILE_FORMAT = 1
DATA_REV_DOMAIN = "tv"                 # `richmovie_ui_common.DATA_REV_DOMAINS` → okno se obnoví na místě

ORDER_KEY = "order"
LAST_KEY = "last"
FAV = "fav"
HIDE = "hide"
FAV_PREFIX = FAV + ":"
HIDE_PREFIX = HIDE + ":"
FLAG_KINDS = (FAV, HIDE)
ORDER_FORMAT = 1
ORDER_MAX_BYTES = 3400                 # < `richmovie_profile_items.PAYLOAD_SOFT_MAX` 3 600 < Gate 4 096
CHANNEL_ID_RE = re.compile(r"[A-Za-z0-9_.-]{1,64}")   # = Gate `livetv/router.SessionIn.channel_id` (celý řetězec)

LAST_MIN_WATCH_S = 10.0                # `last` až po 10 s sledování (listování ▲▼ frontu nezaplaví)
TOMBSTONE_RETENTION_S = 90 * 86400.0   # = Gate `items.TOMBSTONE_RETENTION_DAYS`
MTIME_RACY_WINDOW_S = 2.0              # = `richmovie_settings.MTIME_RACY_WINDOW_NS` (hrubé časy FS → necachovat)
TS_STEP_S = 0.001                      # lokální změna je vždy novější než to, co zařízení o položce ví

SYNC_OFF = "off"
SYNC_PROBE = "probe"
SYNC_ON = "on"
SYNC_MODES = (SYNC_OFF, SYNC_PROBE, SYNC_ON)
TV_SYNC_PUSH = SYNC_ON                 # BRZDA ZÁPISŮ — viz hlavička; vydání = SYNC_ON (brána `_release/release_manifest`
                                       # `release_invariants`, audit Fable D-1); Gate s mig 0050 běží od 08.11.2026 09:14

_ORDER_FIELDS = frozenset(("v", "n", "ids"))
_FLAG_FIELDS = frozenset(("ts",))
_LAST_FIELDS = frozenset(("ch", "prev", "ts"))


# ─────────────────────────────────────────────────────────────────────────────
#  Logování (líně — modul zůstává importovatelný bez Kodi)
# ─────────────────────────────────────────────────────────────────────────────
_LOGGER = None


def _log(msg: str, level: int = 1) -> None:
    global _LOGGER
    if _LOGGER is None:
        try:
            from richmovie_logging import make_legacy_logger
            _LOGGER = make_legacy_logger("richmovie.livetv_prefs", "[RichMovie/TvPrefs]")
        except Exception:
            _LOGGER = lambda _m, _l=1: None   # noqa: E731  (mimo Kodi bez logovací pipeline)
    try:
        _LOGGER(msg, level)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  Parser položky kolekce — ZRCADLO Gate `app/profiles/tv_channels.parse_item` (parita přes sdílenou sadu)
# ─────────────────────────────────────────────────────────────────────────────
def is_channel_id(value: Any) -> bool:
    """ID kanálu ve tvaru poskytovatele (`str`, 1–64 znaků `[A-Za-z0-9_.-]`; fullmatch — `$` u match pustí "\\n")."""
    return isinstance(value, str) and CHANNEL_ID_RE.fullmatch(value) is not None


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _is_epoch(value: Any) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return math.isfinite(float(value)) and float(value) >= 0


def payload_size(payload: Any) -> int:
    """Velikost tak, jak ji měří `richmovie_profile_items.shrink_payload` i Gate `items.validate_item`."""
    return len(json.dumps(payload, ensure_ascii=False).encode("utf-8"))


def _parse_order(payload: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(payload, dict) or set(payload) != _ORDER_FIELDS:
        return None
    v, n, ids = payload.get("v"), payload.get("n"), payload.get("ids")
    if not _is_int(v) or v != ORDER_FORMAT or not _is_int(n) or n < 1 or not isinstance(ids, str):
        return None
    parts = ids.split(",")
    if len(parts) != n or len(set(parts)) != len(parts) or not all(is_channel_id(p) for p in parts):
        return None
    if payload_size(payload) > ORDER_MAX_BYTES:
        return None
    return {"kind": ORDER_KEY, "ids": parts}


def _parse_flag(kind: str, channel: str, payload: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(payload, dict) or set(payload) != _FLAG_FIELDS or not _is_epoch(payload.get("ts")):
        return None
    return {"kind": kind, "channel": channel, "on": True}


def _parse_last(payload: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(payload, dict) or set(payload) != _LAST_FIELDS:
        return None
    ch, prev = payload.get("ch"), payload.get("prev")
    if not is_channel_id(ch) or not _is_epoch(payload.get("ts")):
        return None
    if prev != "" and (not is_channel_id(prev) or prev == ch):
        return None
    return {"kind": LAST_KEY, "ch": ch, "prev": prev}


def parse_item(key: Any, payload: Any, deleted: bool) -> Optional[Dict[str, Any]]:
    """Položka kolekce `tv_channels` → kanonický tvar, nebo None (vadná položka z Gate se přeskočí).

        order:    {"kind": "order", "ids": [...]}                tombstone {"kind": "order", "ids": []}
        fav/hide: {"kind": "fav"|"hide", "channel": id, "on": True}  tombstone "on": False
        last:     {"kind": "last", "ch": id, "prev": id|""}       tombstone {"kind": "last", "ch": "", "prev": ""}
    Tombstone potřebuje jen platný klíč (payload se nečte)."""
    if not isinstance(key, str):
        return None
    if key == ORDER_KEY:
        return {"kind": ORDER_KEY, "ids": []} if deleted else _parse_order(payload)
    if key == LAST_KEY:
        return {"kind": LAST_KEY, "ch": "", "prev": ""} if deleted else _parse_last(payload)
    for prefix in (FAV_PREFIX, HIDE_PREFIX):
        if key.startswith(prefix):
            kind, channel = prefix[:-1], key[len(prefix):]
            if not is_channel_id(channel):
                return None
            return {"kind": kind, "channel": channel, "on": False} if deleted else _parse_flag(kind, channel, payload)
    return None


# ─────────────────────────────────────────────────────────────────────────────
#  Pořadí (čisté)
# ─────────────────────────────────────────────────────────────────────────────
def _position(value: Any) -> Optional[float]:
    if value is None or isinstance(value, bool):
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def provider_order(channels: Iterable[Any]) -> List[str]:
    """P = ID dostupných kanálů v pořadí poskytovatele `(position je None, position, název, id)` — `id` jako poslední
    klíč dělá pořadí deterministické. Kanál bez platného ID / duplicita se vynechá. Přijímá řádky Gate
    `/v1/livetv/channels` (slovníky s `id`, `name`, `position`)."""
    rows = []
    seen = set()
    for c in channels or ():
        if not isinstance(c, dict):
            continue
        cid = c.get("id")
        if not is_channel_id(cid) or cid in seen:
            continue
        seen.add(cid)
        pos = _position(c.get("position"))
        rows.append(((pos is None, pos if pos is not None else 0.0, str(c.get("name") or ""), cid), cid))
    rows.sort(key=lambda r: r[0])
    return [cid for _k, cid in rows]


def effective_order(provider_ids: Sequence[str], prefix: Sequence[str]) -> List[str]:
    """E = prefix ∩ P (bez duplicit, v pořadí prefixu) + (P − prefix v pořadí P)."""
    pset = set(provider_ids)
    head: List[str] = []
    seen = set()
    for cid in prefix or ():
        if cid in pset and cid not in seen:
            head.append(cid)
            seen.add(cid)
    return head + [cid for cid in provider_ids if cid not in seen]


def shortest_prefix(provider_ids: Sequence[str], desired: Sequence[str]) -> List[str]:
    """Nejkratší prefix `D[:k]`, pro který `effective_order(P, D[:k]) == D`. `desired` MUSÍ být permutace P
    (jinak ValueError — programátorská chyba volajícího). O(n²), 175² zanedbatelné. Podmínka je monotónní v k
    (platí-li pro k, platí i pro k + 1), takže první nalezené k je nejkratší."""
    p = list(provider_ids)
    d = list(desired)
    if len(set(d)) != len(d) or set(d) != set(p) or len(d) != len(p):
        raise ValueError("shortest_prefix: desired není permutace pořadí poskytovatele")
    for k in range(len(d) + 1):
        head = set(d[:k])
        if d[k:] == [cid for cid in p if cid not in head]:
            return d[:k]
    return d   # nedosažitelné (k = len(d) podmínku splní vždy)


def _order_payload(ids: Sequence[str]) -> Dict[str, Any]:
    return {"v": ORDER_FORMAT, "n": len(ids), "ids": ",".join(ids)}


def encode_order(prefix: Sequence[str]) -> Tuple[Optional[Dict[str, Any]], List[str], bool]:
    """Prefix → `(payload | None, uložený prefix, zkráceno)`. Prázdný prefix = výchozí pořadí → None (tombstone).

    STROP DRŽÍ STAVITEL: payload je vždy ≤ `ORDER_MAX_BYTES` (`shrink_payload(p) == p`). Přetečení (účet s víc než
    ~330 kanály s dlouhými ID) = nejdelší prefix, který se vejde, + `TV_ORDER_TRUNCATED`; zbytek pořadí jde v pořadí
    poskytovatele. Nikdy 422 / karanténa."""
    ids = [cid for cid in prefix if is_channel_id(cid)]
    if not ids:
        return None, [], False
    payload = _order_payload(ids)
    if payload_size(payload) <= ORDER_MAX_BYTES:
        return payload, ids, False
    lo, hi = 0, len(ids)            # největší k s velikostí ≤ strop (velikost s k roste monotónně)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if payload_size(_order_payload(ids[:mid])) <= ORDER_MAX_BYTES:
            lo = mid
        else:
            hi = mid - 1
    kept = ids[:lo]
    _log("TV_ORDER_TRUNCATED prefix=%d kept=%d max_bytes=%d" % (len(ids), len(kept), ORDER_MAX_BYTES), 2)
    if not kept:
        return None, [], True
    return _order_payload(kept), kept, True


# ─────────────────────────────────────────────────────────────────────────────
#  Stav souboru (čisté)
# ─────────────────────────────────────────────────────────────────────────────
def empty_state() -> Dict[str, Any]:
    return {"v": FILE_FORMAT, "order": {"ids": [], "ts": 0.0}, FAV: {}, HIDE: {},
            "last": {"ch": "", "prev": "", "ts": 0.0}}


def _ts(value: Any) -> float:
    return float(value) if _is_epoch(value) else 0.0


def normalize_state(raw: Any) -> Dict[str, Any]:
    """Obsah souboru → kanonický stav; vadné části se zahodí (soubor mohl zapsat starší / poškozený proces)."""
    st = empty_state()
    if not isinstance(raw, dict):
        return st
    order = raw.get("order")
    if isinstance(order, dict):
        ids = order.get("ids")
        clean: List[str] = []
        if isinstance(ids, list):
            seen = set()
            for cid in ids:
                if is_channel_id(cid) and cid not in seen:
                    clean.append(cid)
                    seen.add(cid)
        st["order"] = {"ids": clean, "ts": _ts(order.get("ts"))}
    for kind in FLAG_KINDS:
        flags = raw.get(kind)
        if isinstance(flags, dict):
            for cid, ent in flags.items():
                if is_channel_id(cid) and isinstance(ent, dict) and isinstance(ent.get("on"), bool):
                    st[kind][cid] = {"on": ent["on"], "ts": _ts(ent.get("ts"))}
    last = raw.get("last")
    if isinstance(last, dict):
        ch, prev = last.get("ch"), last.get("prev")
        ch = ch if is_channel_id(ch) else ""
        prev = prev if (is_channel_id(prev) and prev != ch and ch) else ""
        st["last"] = {"ch": ch, "prev": prev, "ts": _ts(last.get("ts"))}
    return st


def flag_on(state: Dict[str, Any], kind: str, cid: str) -> bool:
    ent = (state.get(kind) or {}).get(cid)
    return bool(isinstance(ent, dict) and ent.get("on") is True)


def purge_tombstones(state: Dict[str, Any], now: float) -> int:
    """Lokální tombstony ★ / skrytých starší než `TOMBSTONE_RETENTION_S` pryč (Gate je po stejné době maže taky)."""
    n = 0
    for kind in FLAG_KINDS:
        flags = state.get(kind) or {}
        for cid in [c for c, e in flags.items() if not e.get("on") and now - float(e.get("ts") or 0) > TOMBSTONE_RETENTION_S]:
            flags.pop(cid, None)
            n += 1
    return n


def next_ts(prev_ts: Any, now: float) -> float:
    """Čas lokální změny: nejméně `now`, vždy o krok novější než to, co zařízení o položce ví (hodiny jiného zařízení
    napřed by jinak lokální změnu v LWW porazily)."""
    return max(float(now), _ts(prev_ts) + TS_STEP_S)


def next_last(last: Dict[str, Any], cid: str, ts: float) -> Optional[Dict[str, Any]]:
    """Nový `last` po sledování kanálu `cid`; None = beze změny (týž kanál)."""
    cur = str(last.get("ch") or "")
    if cur == cid:
        return None
    prev = cur if cur else ""
    return {"ch": cid, "prev": prev, "ts": ts}


def merge_remote(state: Dict[str, Any], items: Iterable[Dict[str, Any]]) -> int:
    """Položky z Gate → stav (LWW s LOKÁLNÍM časem). Lokálně novější (i lokální tombstone) zůstává — fronta ho ještě
    odešle; stejný čas = pravda Gate (zrcadlo `items.wins`: stejný čas vyhrává při jiném obsahu). Vrací počet změn."""
    changed = 0
    for it in items or ():
        if not isinstance(it, dict):
            continue
        parsed = parse_item(it.get("item_key"), it.get("payload") or {}, bool(it.get("deleted")))
        if parsed is None:
            continue
        rts = _sq.to_epoch(it.get("client_updated_at"))
        kind = parsed["kind"]
        if kind == ORDER_KEY:
            cur = state["order"]
            if float(cur["ts"]) > rts:
                continue
            if cur["ids"] != parsed["ids"] or float(cur["ts"]) != rts:
                state["order"] = {"ids": list(parsed["ids"]), "ts": rts}
                changed += int(cur["ids"] != parsed["ids"])
        elif kind == LAST_KEY:
            cur = state["last"]
            if float(cur["ts"]) > rts:
                continue
            new = {"ch": parsed["ch"], "prev": parsed["prev"], "ts": rts}
            if (cur["ch"], cur["prev"]) != (new["ch"], new["prev"]) or float(cur["ts"]) != rts:
                state["last"] = new
                changed += int((cur["ch"], cur["prev"]) != (new["ch"], new["prev"]))
        else:
            flags = state[kind]
            cid = parsed["channel"]
            ent = flags.get(cid)
            if ent is not None and float(ent.get("ts") or 0) > rts:
                continue
            was = bool(ent and ent.get("on"))
            if ent is None and not parsed["on"]:
                continue   # tombstone na položku, kterou neznáme = nic (nepřidávat smetí)
            flags[cid] = {"on": bool(parsed["on"]), "ts": rts}
            changed += int(was != bool(parsed["on"]))
    return changed


def state_items(state: Dict[str, Any], now: float) -> List[Tuple[str, Optional[Dict[str, Any]], bool, float]]:
    """Lokální stav → položky kolekce `(klíč, payload, smazáno, čas)` pro seed (`richmovie_profile_items`).
    Tombstony s časem jdou také (LWW opraví starší stav na Gate); položka bez času dostane `now - 1`."""
    out: List[Tuple[str, Optional[Dict[str, Any]], bool, float]] = []
    order = state.get("order") or {}
    o_ts = _ts(order.get("ts"))
    if order.get("ids"):
        payload, _kept, _trunc = encode_order(order["ids"])
        out.append((ORDER_KEY, payload, payload is None, o_ts or now - 1))
    elif o_ts:
        out.append((ORDER_KEY, None, True, o_ts))
    for kind in FLAG_KINDS:
        for cid in sorted(state.get(kind) or {}):
            ent = state[kind][cid]
            ts = _ts(ent.get("ts")) or now - 1
            on = bool(ent.get("on"))
            out.append(("%s:%s" % (kind, cid), {"ts": int(ts)} if on else None, not on, ts))
    last = state.get("last") or {}
    l_ts = _ts(last.get("ts"))
    if last.get("ch"):
        out.append((LAST_KEY, {"ch": last["ch"], "prev": last.get("prev") or "", "ts": int(l_ts or now - 1)}, False,
                    l_ts or now - 1))
    elif l_ts:
        out.append((LAST_KEY, None, True, l_ts))
    return out


class ChannelView(object):
    """Efektivní pohled na kanály pro okno (čistý, jen čtení): `order` (E vč. skrytých), `visible` (čísla, ▲▼, panel),
    `favorites`, `hidden`. Okno ho staví jednou per změna dat (doména `tv` / nový seznam kanálů)."""

    def __init__(self, provider_ids: Sequence[str], state: Dict[str, Any]) -> None:
        self.provider: List[str] = list(provider_ids)
        self.order: List[str] = effective_order(self.provider, (state.get("order") or {}).get("ids") or [])
        self.hidden_set = frozenset(c for c in self.order if flag_on(state, HIDE, c))
        self.fav_set = frozenset(c for c in self.order if flag_on(state, FAV, c))
        self.visible: List[str] = [c for c in self.order if c not in self.hidden_set]
        self.favorites: List[str] = [c for c in self.visible if c in self.fav_set]
        self.hidden: List[str] = [c for c in self.order if c in self.hidden_set]
        self._number = {c: i + 1 for i, c in enumerate(self.visible)}

    def number_of(self, cid: str) -> Optional[int]:
        """Číslo kanálu = index ve viditelném E + 1 (R-3); skrytý / neznámý = None."""
        return self._number.get(cid)

    def channel_by_number(self, number: Any) -> Optional[str]:
        try:
            n = int(number)
        except (TypeError, ValueError):
            return None
        return self.visible[n - 1] if 1 <= n <= len(self.visible) else None

    def is_fav(self, cid: str) -> bool:
        return cid in self.fav_set

    def is_hidden(self, cid: str) -> bool:
        return cid in self.hidden_set

    def moved(self, cid: str, delta: int, view_ids: Optional[Sequence[str]] = None) -> Optional[List[str]]:
        """Nové celé pořadí D po přesunu `cid` o `delta` míst v POHLEDU (`view_ids` = co okno zobrazuje: Vše =
        `visible`, Oblíbené = `favorites`, kategorie…). Přesun = postavení před / za cílového souseda v pohledu;
        kanály mimo pohled (skryté, jiné kategorie) drží své místo. None = beze změny (okraj, neznámý kanál)."""
        order_set = set(self.order)
        view = [c for c in (self.visible if view_ids is None else view_ids) if c in order_set]
        try:
            step = int(delta)
        except (TypeError, ValueError):
            return None
        if cid not in view or step == 0:
            return None
        i = view.index(cid)
        j = max(0, min(len(view) - 1, i + step))
        if i == j:
            return None
        target = view[j]
        d = [c for c in self.order if c != cid]
        t = d.index(target)
        d.insert(t if j < i else t + 1, cid)
        return d


# ─────────────────────────────────────────────────────────────────────────────
#  Soubor profilu (I/O) — zápisy pod `personal_lock`, čtení podle otisku
# ─────────────────────────────────────────────────────────────────────────────
_cache_lock = threading.Lock()
_CACHE: Dict[str, Any] = {"path": None, "sig": None, "state": None}


def _path() -> str:
    import richmovie_paths as RP
    return str(RP.personal_path(FILE_NAME))


def _lock():
    import richmovie_paths as RP
    return RP.personal_lock(FILE_NAME)


def _fingerprint(path: str) -> Optional[Tuple[int, int]]:
    try:
        st = os.stat(path)
    except OSError:
        return None
    return int(st.st_mtime_ns), int(st.st_size)


def invalidate_cache() -> None:
    with _cache_lock:
        _CACHE.update(path=None, sig=None, state=None)


def load_state() -> Dict[str, Any]:
    """Stav profilu pro UI (jen čtení — NEMĚNIT vrácený objekt). Paměť platí, dokud se nezmění otisk souboru
    (jiný proces — služba po pullu — ho přepsal); soubor změněný před < 2 s se necachuje (hrubé časy FS).
    Nečitelný / poškozený soubor = prázdný stav (poškozený jde do karantény `richmovie_atomic`), necachuje se."""
    import richmovie_atomic as _atomic
    path = _path()
    sig = _fingerprint(path)
    with _cache_lock:
        if sig is not None and _CACHE["path"] == path and _CACHE["sig"] == sig and _CACHE["state"] is not None:
            return _CACHE["state"]
    data, state = _atomic.read_json(path, None, name="tv_channels", expected_type=dict)
    st = normalize_state(data)
    if state == _atomic.STATE_OK and sig is not None and time.time() - sig[0] / 1e9 >= MTIME_RACY_WINDOW_S:
        with _cache_lock:
            _CACHE.update(path=path, sig=sig, state=st)
    return st


def _load_for_update() -> Optional[Dict[str, Any]]:
    """Read-modify-write: UNREADABLE (I/O) = nezapisovat (parita `richmovie_ratings._load_for_update`)."""
    import richmovie_atomic as _atomic
    data, state = _atomic.read_json(_path(), None, name="tv_channels", expected_type=dict)
    if state == _atomic.STATE_UNREADABLE:
        return None
    return normalize_state(data)


def _save(state: Dict[str, Any], *, visible_change: bool = True) -> bool:
    """Atomický zápis + zneplatnění paměti. `visible_change` = okno má co překreslit (doména `tv`); sloučení, které
    jen srovná čas položky s Gate, okno neruší."""
    import richmovie_atomic as _atomic
    purge_tombstones(state, time.time())
    state["v"] = FILE_FORMAT
    ok = _atomic.write_json(_path(), state, indent=None)
    invalidate_cache()
    if ok and visible_change:
        try:
            import richmovie_ui_common as _uc
            _uc.data_rev_bump(DATA_REV_DOMAIN)
        except Exception:
            pass
    return ok


def push_allowed(key: str) -> bool:
    """Brzda zápisů (`TV_SYNC_PUSH`): smí položka s tímto klíčem do fronty pro Gate?"""
    if TV_SYNC_PUSH == SYNC_ON:
        return True
    if TV_SYNC_PUSH == SYNC_PROBE:
        return str(key).startswith(FAV_PREFIX)
    return False


def _note(key: str, payload: Optional[Dict[str, Any]], *, deleted: bool, ts: float) -> bool:
    """Změna do fronty kolekce (SSOT `richmovie_profile_items.note_change`; Host / echo / bez profilu = False)."""
    if not push_allowed(key):
        _log("TV_SYNC_HELD key=%s mode=%s (brzda zápisů — jen lokálně)" % (key, TV_SYNC_PUSH), 0)
        return False
    try:
        import richmovie_profile_items as _pi
        return bool(_pi.note_change(COLLECTION, key, payload, deleted=deleted, ts=ts))
    except Exception as exc:
        _log("tv_channels note_change failed key=%s: %r" % (key, exc), 2)
        return False


def view(provider_channels: Iterable[Any]) -> ChannelView:
    """Pohled pro okno nad řádky Gate `/v1/livetv/channels`."""
    return ChannelView(provider_order(provider_channels), load_state())


def visible_channels(provider_channels: Iterable[Any]) -> List[Dict[str, Any]]:
    """Viditelné kanály (řádky Gate) v osobním pořadí — číslo kanálu = pozice + 1."""
    rows: Dict[str, Dict[str, Any]] = {}
    for c in provider_channels or ():
        if isinstance(c, dict) and is_channel_id(c.get("id")):
            rows.setdefault(c["id"], c)   # první výskyt — stejně jako `provider_order`
    return [rows[cid] for cid in view(list(rows.values())).visible]


def number_of(cid: str, provider_channels: Iterable[Any]) -> Optional[int]:
    return view(provider_channels).number_of(cid)


def channel_by_number(number: Any, provider_channels: Iterable[Any]) -> Optional[str]:
    return view(provider_channels).channel_by_number(number)


def last_channel() -> Tuple[str, str]:
    """(poslední kanál, předchozí) — "" když není."""
    last = load_state()["last"]
    return last["ch"], last["prev"]


def move(cid: str, delta: int, provider_channels: Iterable[Any], view_ids: Optional[Sequence[str]] = None,
         now: Optional[float] = None) -> Optional[ChannelView]:
    """Přesun kanálu o `delta` míst v pohledu (viz `ChannelView.moved`) → uloží nejkratší prefix (stavitel se stropem)
    a pošle `order` do fronty. Vrací nový pohled (beze změny = současný), None = zápis selhal / soubor nečitelný."""
    p = provider_order(provider_channels)
    now = time.time() if now is None else float(now)
    with _lock():
        st = _load_for_update()
        if st is None:
            _log("TV_PREFS_WRITE_SKIPPED move %s (soubor nečitelný)" % cid, 2)
            return None
        cur = ChannelView(p, st)
        d = cur.moved(cid, delta, view_ids)
        if d is None:
            return cur
        payload, kept, _truncated = encode_order(shortest_prefix(p, d))
        ts = next_ts(st["order"]["ts"], now)
        st["order"] = {"ids": kept, "ts": ts}
        if not _save(st):
            return None
        result = ChannelView(p, st)
    _note(ORDER_KEY, payload, deleted=payload is None, ts=ts)
    _log("TV_ORDER_MOVED ch=%s delta=%s prefix=%d" % (cid, delta, len(kept)), 1)
    return result


def reset_order(now: Optional[float] = None) -> bool:
    """„Obnovit výchozí pořadí“ = tombstone `order` (★ a skryté zůstávají). True = uloženo (i když už výchozí bylo)."""
    now = time.time() if now is None else float(now)
    with _lock():
        st = _load_for_update()
        if st is None:
            return False
        if not st["order"]["ids"]:
            return True
        ts = next_ts(st["order"]["ts"], now)
        st["order"] = {"ids": [], "ts": ts}
        if not _save(st):
            return False
    _note(ORDER_KEY, None, deleted=True, ts=ts)
    return True


def set_flag(kind: str, cid: str, on: Optional[bool] = None, now: Optional[float] = None) -> Optional[bool]:
    """★ / skrytí kanálu: `on=None` přepne. Vrací nový stav, None = neplatný vstup / zápis selhal."""
    if kind not in FLAG_KINDS or not is_channel_id(cid):
        return None
    now = time.time() if now is None else float(now)
    with _lock():
        st = _load_for_update()
        if st is None:
            return None
        was = flag_on(st, kind, cid)
        new = (not was) if on is None else bool(on)
        if new == was:
            return new
        ts = next_ts((st[kind].get(cid) or {}).get("ts"), now)
        st[kind][cid] = {"on": new, "ts": ts}
        if not _save(st):
            return None
    _note("%s:%s" % (kind, cid), {"ts": int(ts)} if new else None, deleted=not new, ts=ts)
    return new


def toggle_fav(cid: str, now: Optional[float] = None) -> Optional[bool]:
    return set_flag(FAV, cid, None, now)


def toggle_hide(cid: str, now: Optional[float] = None) -> Optional[bool]:
    return set_flag(HIDE, cid, None, now)


def note_watched(cid: str, watched_s: float, now: Optional[float] = None) -> bool:
    """Kanál se sleduje `watched_s` sekund → po `LAST_MIN_WATCH_S` se zapíše jako poslední (předchozí = dosavadní
    poslední). Volá okno jednou per kanál po dosažení prahu. True = zapsáno."""
    try:
        watched = float(watched_s)
    except (TypeError, ValueError):
        return False
    if not is_channel_id(cid) or not watched >= LAST_MIN_WATCH_S:
        return False
    now = time.time() if now is None else float(now)
    with _lock():
        st = _load_for_update()
        if st is None:
            return False
        new = next_last(st["last"], cid, next_ts(st["last"]["ts"], now))
        if new is None:
            return False
        st["last"] = new
        if not _save(st):
            return False
    _note(LAST_KEY, {"ch": new["ch"], "prev": new["prev"], "ts": int(new["ts"])}, deleted=False, ts=new["ts"])
    return True


def apply_remote(items: List[Dict[str, Any]]) -> int:
    """Sloučení z Gate (volá `richmovie_profile_items._apply_tv_channels` pod `personal_lock(FILE_NAME)`,
    `failure_scope` a `applying_remote` — žádné echo do fronty). Nečitelný soubor = OSError → kurzor pullu stojí (R2)."""
    st = _load_for_update()
    if st is None:
        raise OSError("tv_channels.json unreadable")
    before = json.dumps(st, sort_keys=True)
    changed = merge_remote(st, items)
    if json.dumps(st, sort_keys=True) == before:
        return 0
    _save(st, visible_change=changed > 0)   # selhání zápisu zachytí `failure_scope` volajícího → kurzor stojí
    return changed


def queue_items_from_file(path: Any, now: Optional[float] = None) -> List[Tuple[str, Optional[Dict[str, Any]], bool, float]]:
    """Seed / import archivu: soubor `tv_channels.json` v libovolném adresáři → položky `(klíč, payload, smazáno, čas)`.
    Chybějící / nečitelný soubor = []."""
    import richmovie_atomic as _atomic
    data, state = _atomic.read_json(str(path), None, name="tv_channels", expected_type=dict, quarantine_on_corrupt=False)
    if state != _atomic.STATE_OK:
        return []
    return state_items(normalize_state(data), time.time() if now is None else float(now))
