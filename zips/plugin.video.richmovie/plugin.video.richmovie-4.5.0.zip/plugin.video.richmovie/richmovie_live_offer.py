# -*- coding: utf-8 -*-
"""Nabídka lepší verze při sledování Televize — pravidla a paměť (plán `Handoff/PLAN_televize_vod_20261108.md` v2, §4 + §10).

Běží-li v Televizi film nebo díl, který jde pustit z Webshare / Fastshare v lepší kvalitě nebo bez reklam, dole se decentně
ukáže nabídka. Tady je jen ROZHODOVÁNÍ (čisté funkce, harness 119) a osobní paměť profilu; hledání spouští
`richmovie_live_offer_run` ve službě, zobrazení dělá okno Televize.

Pravidla textu (O1): nabídnout při VYŠŠÍ kvalitě NEBO při stejné kvalitě s reklamami; text je vždy pravdivý. „Bez reklam“ jen na
kanálu z pozitivního seznamu Gate (§10.3), výchozí stav je mlčet.
Bez Kodi importů. Python 3.8.
"""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Tuple

# ── kdy se vůbec hledá (šetrnost k Webshare, §10.5) ──
DWELL_S = 300.0                # zapínání kanálů při reklamě se nepočítá
MIN_LEFT_MOVIE_S = 20 * 60.0
MIN_LEFT_EPISODE_S = 15 * 60.0
MAX_CHECKS_PER_H = 3           # na zařízení; rozpočet na účet hlídá Gate (`vod_permit`)
SERIES_GAP_S = 2 * 3600.0      # jeden seriál nejvýš jednou za tolik (maraton dílů)
CHECKED_TTL_S = 24 * 3600.0    # titul se do tolika znovu nehledá (reprízy, kanály +1)
EVAL_S = 30.0                  # jak často se služba ptá, jestli je co hledat

# ── jak se nabídka ukazuje (§4.3) ──
OFFER_SHOW_S = 12.0            # čip sám odjede
CALM_S = 5.0                   # divák chvíli nic nemačkal
LAST_MINUTES_S = 15 * 60.0     # v závěru pořadu už nic

# ── odkud pustit (§4.5, §10.4) ──
SAFETY_S = 60.0                # raději minutu znovu než minutu přijít
MAX_POSITION_RATIO = 0.80      # dál je „Pokračovat“ nesmysl
MIN_ELAPSED_S = 300.0          # prvních 5 minut pořadu = jen „Od začátku“

# ── reklamy (§10.3) ──
ADS_MIN_GAP_S = 300.0
ADS_MIN_RATIO = 0.08

# ── Pokračovat / ✔ po spuštění z nabídky (§10.4) ──
ORIGIN_TV = "tv"
HOLD_PROGRESS_S = 180.0        # dřív se Pokračovat nezapíše (rozkoukaná pozice titulu zůstane)
HOLD_WATCHED_S = 600.0         # ✔ a odebrání z Pokračovat až po tolika skutečně přehraných

KIND_MOVIE, KIND_EPISODE = "movie", "episode"
OFFER_KINDS = (KIND_MOVIE, KIND_EPISODE)

PROP_OFFER = "richmovie.live.offer"
PROP_ORIGIN = "richmovie.origin_tv"     # `<výchozí pozice>|<ident>`: přehrávání spuštěné z nabídky (zapisuje `_play`)
OFFER_FILE = "tv_vod_offer.json"       # zamítnuté nabídky (per profil na zařízení)
CHECKED_FILE = "tv_vod_checked.json"   # co se už hledalo
DISMISS_EXTRA_S = 3600.0               # zamítnutí platí do konce pořadu + 1 h
MEMORY_MAX = 200

# důvody, proč se nehledá (log `LIVE_VOD_CHECK skip=…`)
SKIP_KIND, SKIP_DWELL, SKIP_LEFT, SKIP_DONE, SKIP_DISMISSED, SKIP_BUDGET, SKIP_OFFLINE, SKIP_HOST, SKIP_FILTER, SKIP_COOLDOWN = (
    "kind", "dwell", "left", "done", "dismissed", "budget", "offline", "host", "filter", "cooldown")


def title_key(vod: Dict[str, Any]) -> str:
    """Klíč titulu — stejný tvar jako `richmovie_state_sync.cw_key` (film `movie:<id>:0:0`, díl `tv:<id>:<ř>:<d>`)."""
    if vod.get("kind") == KIND_EPISODE:
        return "tv:%d:%d:%d" % (int(vod["tmdb"]), int(vod["season"]), int(vod["episode"]))
    return "movie:%d:0:0" % int(vod["tmdb"])


def permit_key(vod: Dict[str, Any]) -> str:
    """Klíč rozpočtu na Gate (`POST /v1/livetv/vod_permit`, vzor `VodPermitIn.key`): film `movie:<id>`, díl `tv:<id>:<ř>:<d>`."""
    return title_key(vod) if vod.get("kind") == KIND_EPISODE else "movie:%d" % int(vod["tmdb"])


def series_key(vod: Dict[str, Any]) -> str:
    return "tv:%d" % int(vod["tmdb"]) if vod.get("kind") == KIND_EPISODE else ""


def check_block(*, kind: Any, dwell_s: float, left_s: Optional[float], done: bool, dismissed: bool, budget_left: bool,
                offline: bool, host_down: bool, filtered: bool, cooling: bool) -> str:
    """Proč se teď NEhledá ("" = hledat). První splněný důvod vyhrává; pořadí od nejlevnějších podmínek."""
    if kind not in OFFER_KINDS:
        return SKIP_KIND
    if dwell_s < DWELL_S:
        return SKIP_DWELL
    if left_s is None or left_s < (MIN_LEFT_EPISODE_S if kind == KIND_EPISODE else MIN_LEFT_MOVIE_S):
        return SKIP_LEFT
    if done:
        return SKIP_DONE
    if dismissed:
        return SKIP_DISMISSED
    if not budget_left:
        return SKIP_BUDGET
    if offline:
        return SKIP_OFFLINE
    if host_down:
        return SKIP_HOST
    if filtered:
        return SKIP_FILTER
    if cooling:
        return SKIP_COOLDOWN
    return ""


def language_ok(audios: Any) -> bool:
    """Zvuk verze: česky / slovensky, nebo neznámý. Známá jen cizí stopa se nenabízí (v Televizi běží dabing)."""
    return not audios or any(str(a).upper() in ("CZ", "SK") for a in audios)


def has_ads(ads_channel: Any, slot_s: float, runtime_s: float) -> bool:
    """Reklamy podle dat: kanál z pozitivního seznamu A vysílání je znatelně delší než film (§10.3)."""
    if ads_channel is not True or slot_s <= 0 or runtime_s <= 0:
        return False
    return slot_s - runtime_s >= max(ADS_MIN_GAP_S, ADS_MIN_RATIO * slot_s)


def quality_name(cls: int) -> str:
    return {2160: "4K", 1440: "1440p", 1080: "1080p", 720: "720p"}.get(int(cls or 0), "")


def offer_label(vod_class: int, live_class: int, ads: bool) -> str:
    """Pravdivý text nabídky, "" = nenabízet. Neznámá kvalita (0) se za lepší nepočítá (nesmíme slíbit, co nevíme)."""
    better = int(vod_class or 0) > 0 and int(live_class or 0) > 0 and int(vod_class) > int(live_class)
    name = quality_name(vod_class) if better else ""
    if better and not name:
        better = False
    if better and ads:
        return "%s %s a bez reklam" % ("Ve" if name == "4K" else "V", name)
    if better:
        return "%s %s" % ("Ve" if name == "4K" else "V", name)
    return "Bez reklam" if ads else ""


def estimate_position(elapsed_s: Optional[float], slot_s: float, runtime_s: float, delay_s: float) -> int:
    """Odkud pokračovat (s), 0 = jen „Od začátku“. Reklamy rozložené úměrně, obraz je `delay_s` za živým okrajem,
    minuta rezerva; nikdy za 80 % filmu. Chybějící údaje = 0, žádná výjimka."""
    if elapsed_s is None or slot_s <= 0 or runtime_s <= 0 or elapsed_s < MIN_ELAPSED_S:
        return 0
    content = (float(elapsed_s) - float(delay_s)) * float(runtime_s) / float(slot_s) - SAFETY_S
    if content <= 0 or content > MAX_POSITION_RATIO * float(runtime_s):
        return 0
    return int(content)


def still_relevant(left_s: Optional[float], elapsed_s: Optional[float], slot_s: float, runtime_s: float, delay_s: float) -> bool:
    """Má nabídka pořád smysl? Ne v závěru pořadu a ne, když by odhad přesáhl 80 % filmu (§10.4)."""
    if left_s is None or left_s < LAST_MINUTES_S:
        return False
    if elapsed_s is None or elapsed_s < MIN_ELAPSED_S or runtime_s <= 0 or slot_s <= 0:
        return True                                  # jen „Od začátku“
    return ((float(elapsed_s) - float(delay_s)) * float(runtime_s) / float(slot_s) - SAFETY_S) <= MAX_POSITION_RATIO * float(runtime_s)


def may_show_chip(*, already_shown: bool, clean_screen: bool, calm_s: float) -> bool:
    """Sám se čip objeví nejvýš jednou za pořad, jen v čistém obraze a když divák chvíli nic nemačkal."""
    return not already_shown and clean_screen and calm_s >= CALM_S


def note_origin(set_prop: Any, origin: Any, start: Any, ident: Any) -> None:
    """Každé `_play`, které dojde k přehrání: buď značka spuštění z nabídky, nebo smazání té minulé (páruje se podle identu)."""
    set_prop(PROP_ORIGIN, "%d|%s" % (int(_num(start)), ident) if origin == ORIGIN_TV and ident else "")


def origin_start(get_prop: Any, ident: Any) -> Optional[float]:
    """Výchozí pozice, když TENTO stream spustila nabídka; jinak None."""
    head, sep, tail = str(get_prop(PROP_ORIGIN) or "").partition("|")
    return float(int(head)) if sep and head.isdigit() and ident and tail == str(ident) else None


def cw_gate(origin: Optional[float], played_s: float) -> Tuple[bool, bool]:
    """(zapsat Pokračovat, smí ✔ a odebrání z Pokračovat) pro film spuštěný z nabídky; bez původu z Televize vše smí."""
    if origin is None:
        return True, True
    return progress_allowed(played_s), watched_allowed(played_s)


def progress_allowed(played_s: float) -> bool:
    return float(played_s) >= HOLD_PROGRESS_S


def watched_allowed(played_s: float) -> bool:
    return float(played_s) >= HOLD_WATCHED_S


def _num(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def validate_offer(raw: Any) -> Optional[Dict[str, Any]]:
    """Nabídka z vlastnosti okna → slovník, nebo None (vadná = žádná nabídka, nic se neukáže napůl)."""
    if not isinstance(raw, dict):
        return None
    for key in ("csid", "event", "channel", "title", "label", "url", "key", "ident"):
        if not isinstance(raw.get(key), str) or not raw.get(key):
            return None
    if raw.get("kind") not in OFFER_KINDS or _num(raw.get("end_ts")) <= 0:
        return None
    return raw


# ── osobní paměť profilu ─────────────────────────────────────────────────────────────────────────────────────────────
def prune(items: Dict[str, Any], now: float) -> Dict[str, float]:
    """Jen platné záznamy `{klíč: do_kdy}`, nejvýš `MEMORY_MAX` (nejdřív končící pryč)."""
    live = {str(k): _num(v) for k, v in (items or {}).items() if _num(v) > now}
    if len(live) > MEMORY_MAX:
        live = dict(sorted(live.items(), key=lambda kv: kv[1])[-MEMORY_MAX:])
    return live


def _path(name: str) -> str:
    import richmovie_paths as RP
    return str(RP.personal_path(name))


def _read(name: str, label: str) -> Tuple[Optional[Dict[str, Any]], bool]:
    """(obsah, čitelné). Nečitelný soubor = NIC nepřepsat (R2); poškozený jde do karantény `richmovie_atomic` a začne se znovu."""
    import richmovie_atomic as atomic
    data, st = atomic.read_json(_path(name), None, name=label, expected_type=dict)
    if st == atomic.STATE_UNREADABLE:
        return None, False
    return (data if isinstance(data, dict) else {}), True


def _write(name: str, data: Dict[str, Any]) -> bool:
    import richmovie_atomic as atomic
    import richmovie_profile as prof
    try:
        with prof.personal_lock():
            return bool(atomic.write_json(_path(name), data, indent=None))
    except Exception:
        return False


def is_dismissed(event_key: str, now: Optional[float] = None) -> bool:
    data, ok = _read(OFFER_FILE, "tv_vod_offer")
    if not ok or not data:
        return False
    return prune(data.get("dismissed") or {}, time.time() if now is None else now).get(str(event_key), 0.0) > 0.0


def dismiss(event_key: str, end_ts: float, now: Optional[float] = None) -> bool:
    """„Ne, díky“ platí do konce pořadu + 1 h (O5)."""
    now = time.time() if now is None else now
    data, ok = _read(OFFER_FILE, "tv_vod_offer")
    if not ok:
        return False
    items = prune((data or {}).get("dismissed") or {}, now)
    items[str(event_key)] = float(end_ts) + DISMISS_EXTRA_S
    return _write(OFFER_FILE, {"dismissed": prune(items, now)})


def checked_state(now: Optional[float] = None) -> Tuple[Dict[str, float], List[float], bool]:
    """({klíč: do_kdy}, časy pokusů za poslední hodinu, čitelné). Nečitelné = nehledat (R2: nevíme, co už se hledalo)."""
    now = time.time() if now is None else now
    data, ok = _read(CHECKED_FILE, "tv_vod_checked")
    if not ok:
        return {}, [], False
    recent = [_num(t) for t in ((data or {}).get("recent") or []) if _num(t) > now - 3600.0]
    return prune((data or {}).get("until") or {}, now), recent, True


def checks_last_hour(recent: List[float], now: float) -> int:
    return sum(1 for t in recent if _num(t) > now - 3600.0)


def is_done(until: Dict[str, float], vod: Dict[str, Any]) -> bool:
    series = series_key(vod)
    return title_key(vod) in until or bool(series and ("series:" + series) in until)


def note_attempt(now: Optional[float] = None) -> bool:
    """Pokus se započítá do hodinového rozpočtu PŘED hledáním (i když pak spadne). Titul tím NENÍ vyřízený (R2)."""
    now = time.time() if now is None else now
    until, recent, ok = checked_state(now)
    if not ok:
        return False
    return _write(CHECKED_FILE, {"until": until, "recent": recent + [now]})


def remember_check(vod: Dict[str, Any], now: Optional[float] = None) -> bool:
    """Titul je vyřízený až po ÚPLNÉM hledání; zrušené, neúplné a chybové se nezapisuje (R2, §10.5)."""
    now = time.time() if now is None else now
    until, recent, ok = checked_state(now)
    if not ok:
        return False
    until[title_key(vod)] = now + CHECKED_TTL_S
    series = series_key(vod)
    if series:
        until["series:" + series] = now + SERIES_GAP_S
    return _write(CHECKED_FILE, {"until": prune(until, now), "recent": recent})


__all__: List[str] = []
