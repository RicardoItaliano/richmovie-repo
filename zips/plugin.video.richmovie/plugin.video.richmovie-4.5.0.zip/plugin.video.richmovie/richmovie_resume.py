# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_resume — SSOT navazování přehrávání na pozici (3.5.151)
───────────────────────────────────────────────────────────────────────────────
Plán: `Handoff/PLAN_resume_native_start_sync_integrity_20260916.md` (Φ1, Φ2, Φ3b).

INCIDENT (16.09.2026, notebook ve vlaku)
  Po výpadku sítě toast „Zdroj přerušil stream – navazuji", díl ale jel od začátku.
  `plugin._play` čekal na `xbmc.Player().isPlaying()` a hned volal `seekTime()`.
  Zdrojáky Kodi 21 (Omega):
    • `CVideoPlayer::IsPlaying()` = `!m_bStop` → True od vytvoření přehrávače, dávno
      před otevřením streamu (VideoPlayer.cpp:740),
    • `Player.seekTime` → `CApplication::SeekTime` → `if (!appPlayer->CanSeek()) return;`
      — TICHO, bez výjimky a bez logu (Application.cpp:3467–3475),
    • `CanSeek()` = `m_State.canseek`; `Prepare()` stav maže a zapne ho až po otevření
      streamu a demuxeru (VideoPlayer.cpp:1224, 1357, 4977–4982).
  kodi.log notebooku: `RESUME seekTime=2401s` 23:02:02.819, `Creating Demuxer` až
  23:02:03.133, stream otevřen 23:02:04.422. Seek se zahodil. Flotila za 30 dní:
  zhruba 4 z 10 navázání od nuly; start od nuly navíc checkpointem přepsal
  „Pokračovat" na všech zařízeních profilu.

ŘEŠENÍ — jedna cesta, žádný závod
  1. Producent (klik na Pokračovat, auto-resume, obnova spojení) zveřejní POŽADAVEK
     `publish_request()` (Window props, adresát = ident streamu).
  2. `plugin._play` ho převezme na vstupu (`consume_request`) a PŘED `setResolvedUrl`
     zapíše pozici do resolvované položky (`prepare_resolved_item` →
     `InfoTagVideo.setResumePoint`). Kodi pak v `CPluginDirectory::GetPluginResult`
     nastaví `STARTOFFSET_RESUME` (PluginDirectory.cpp:158–160), `CApplication::PlayFile`
     předá pozici jako `starttime` (Application.cpp:2452–2459) a `CVideoPlayer::Prepare`
     seekne DEMUXER ještě před prvním snímkem (VideoPlayer.cpp:1331–1354).
     `CVideoDatabase::GetFileInfo` nastavený bod nepřepíše (VideoDatabase.cpp:2511).
     `CBookmark::IsSet()` = `totalTimeInSeconds > 0` → délka musí být kladná.
  3. Služba ověří skutečný start (`run_verification`): až je známá délka (= Kodi
     seek přijme), porovná pozici, mimo toleranci opraví seekem (max 2×) a výsledek
     zaloguje `RESUME_NATIVE_OK` / `RESUME_CORRECTED` / `RESUME_FAILED` → měřitelné.
  4. Dokud navázání není ověřené, checkpoint NESMÍ zapsat nižší pozici
     (`hold_checkpoint`). D1 (Richie 16.09.2026): když navázání selže, hraje se dál,
     toast řekne čas a „Pokračovat" zůstane na původním místě.

MRTVÝ ZDROJ (Φ3b)
  kodi.log notebooku 22:32:13: `CCurlFile … Timeout` → `Reconnect, (re)try 1` →
  `Couldn't resolve host name(6)` → 262× `CFileCache … source read returned 0! Will
  retry` až do 23:01:38. Síť byla zpátky ve 22:35, Kodi spojení NEOBNOVILO
  (`CFileCache::Seek` uvnitř bufferu zdroj znovu neotevře — FileCache.cpp:536–573),
  jelo 29 minut z bufferu a skončilo tvrdým EOF. `DeadSourceDetector` to pozná podle
  hranice naplněné cache (`Player.ProgressCache`): za okno skutečného přehrávání se
  neposunula. Služba pak (síť stabilně zpátky a CDN streamu odpovídá) naváže HNED (D3)
  stejnou cestou jako výše. Síť = cesta ke ZDROJI streamu, ne ke Gate (`resume_route`,
  `RouteTracker`, Fable F1).

Čisté funkce a detektor nemají Kodi závislosti → harness scénáře 59 a 61.
Python 3.8 (Kodi runtime).
"""

from __future__ import annotations

import json
import time
from typing import Any, Callable, Dict, Optional, Tuple

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.resume", "RichMovie/Resume")
except Exception:  # pragma: no cover — mimo Kodi bez logovací pipeline
    def _log(msg, level=1, *, context=None):
        try:
            import xbmc
            xbmc.log("[RichMovie/Resume] %s" % msg, level)
        except Exception:
            pass

_LOGDEBUG, _LOGINFO, _LOGWARNING, _LOGERROR = 0, 1, 2, 3


# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY (jediné místo; harness je hlídá)
# ─────────────────────────────────────────────────────────────────────────────
PROP_POSITION = "richmovie.resume_position"     # názvy props z 3.5.119 zůstávají (stejná semantika)
PROP_IDENT = "richmovie.resume_ident"
PROP_RUNTIME = "richmovie.resume_runtime"
PROP_SOURCE = "richmovie.resume_source"
PROP_KEY = "richmovie.resume_key"               # klíč titulu tv:id:s:e / movie:id:0:0 (adresát, když ident chybí)
PROP_CREATED = "richmovie.resume_created"       # epoch zveřejnění
PROP_PENDING = "richmovie.resume_pending"       # plugin → služba: navázání čeká na ověření
REQUEST_PROPS = (PROP_POSITION, PROP_IDENT, PROP_RUNTIME, PROP_SOURCE, PROP_KEY, PROP_CREATED)

SOURCE_CW = "cw"                    # klik na Pokračovat
SOURCE_AUTO_RESUME = "auto_resume"  # zdroj utnul stream (UNEXPECTED_EOF)
SOURCE_REMOTE = "remote"            # přímé spuštění, novější pozice z jiného zařízení (Φ5 13.09.)
SOURCE_RECONNECT = "reconnect"      # mrtvý zdroj, obnova spojení za běhu (Φ3b)
SOURCE_PROFILE = "profile"          # 4.0.3 (A6): přímý klik na rozkoukaný díl/film — postup profilu (kterékoli zařízení)
SOURCE_TV = "tv"                    # Televize F4: přijatá nabídka lepší verze (odhad místa z vysílání)
SOURCES = (SOURCE_CW, SOURCE_AUTO_RESUME, SOURCE_REMOTE, SOURCE_RECONNECT, SOURCE_PROFILE, SOURCE_TV)
# Navázání TÉHOŽ přehrávání systémem (ne nový start člověkem) — bdělost u autoplaye se nenuluje.
RESTART_SOURCES = (SOURCE_AUTO_RESUME, SOURCE_RECONNECT)

MIN_POSITION_S = 10.0       # kratší pozice = „od začátku" (hodnota z 3.5.119: `_resume_sec > 10`)
END_MARGIN_S = 15.0         # pozice v posledních 15 s = konec; navázání by Kodi hned ukončil EOF
VERIFY_TOLERANCE_S = 20.0   # keyframe dosednutí + pár sekund přehrávání mezi startem a měřením
# Otevření streamu přes mobilní síť: Kodi curl connect až 30 s + synchronní seek demuxeru na cíl (HTTP Range)
# + otevření dekodérů. 45 s (první verze) nechávalo pomalé CDN přes mobil jako UNVERIFIED bez opravy (Fable F11).
VERIFY_DEADLINE_S = 60.0
VERIFY_POLL_S = 0.5
VERIFY_SETTLE_S = 1.0       # po prvním čitelném čase ještě 1 s: Kodi hlásí čas dřív, než dosedne seek demuxeru
CORRECTION_MAX = 2          # víc seeků za sebou divákovi nepomůže, jen škube obrazem
CORRECTION_WAIT_S = 10.0    # seek na CDN přes mobilní síť trvá sekundy; do té doby getTime může stát
PENDING_MAX_AGE_S = 180.0   # požadavek, který služba nepřevzala (stream se nerozjel), po 3 min neplatí
# Požadavek bez adresáta (picker-first cesta Pokračovat) čeká, až člověk vybere stream. Cross-check Flash F1:
# bez stáří a klíče titulu by zrušený výběr nechal pozici viset pro PŘÍŠTÍ nesouvisející přehrání.
REQUEST_MAX_AGE_S = 900.0

OUTCOME_NATIVE_OK = "native_ok"
OUTCOME_CORRECTED = "corrected"
OUTCOME_FAILED = "failed"
OUTCOME_UNVERIFIED = "unverified"   # stream se do deadline nerozjel
OUTCOME_IGNORED = "ignored"         # cíl mimo délku (délka se po startu ukázala kratší)
OUTCOME_ABORTED = "aborted"         # přehrávání skončilo / uživatel převzal řízení / Kodi končí

VERDICT_OK = "ok"
VERDICT_CORRECT = "correct"
VERDICT_IGNORE = "ignore"


# ─────────────────────────────────────────────────────────────────────────────
#  ČISTÉ FUNKCE
# ─────────────────────────────────────────────────────────────────────────────
def _num(value: Any) -> float:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return 0.0
    return f if f == f and f > 0 else 0.0   # NaN a záporné = neznámé


def start_point(position_s: Any, runtime_s: Any = 0.0) -> Optional[Tuple[float, float]]:
    """(pozice, délka) pro `setResumePoint`, nebo None = od začátku.

    None pro pozici ≤ `MIN_POSITION_S` a pro pozici v posledních `END_MARGIN_S` známé
    délky. Délka neznámá → `pozice + 1`: `CBookmark::IsSet()` chce jen kladnou délku a
    Kodi ji při startu nepoužívá (jen procenta v knihovně), takže je to přesné i bez ní."""
    pos = _num(position_s)
    runtime = _num(runtime_s)
    if pos <= MIN_POSITION_S:
        return None
    if runtime > 0 and pos >= runtime - END_MARGIN_S:
        return None
    total = runtime if runtime > pos else pos + 1.0
    return round(pos, 1), round(total, 1)


def verdict(target_s: Any, observed_s: Any, total_s: Any = 0.0, *,
            tolerance_s: float = VERIFY_TOLERANCE_S) -> str:
    """Rozhodnutí po skutečném startu: `ok` / `correct` / `ignore` (čisté)."""
    target = _num(target_s)
    observed = _num(observed_s)
    total = _num(total_s)
    if target <= 0 or (total > 0 and target >= total - END_MARGIN_S):
        return VERDICT_IGNORE
    if abs(observed - target) <= float(tolerance_s):
        return VERDICT_OK
    return VERDICT_CORRECT


def hold_checkpoint(hold: Optional[Dict[str, Any]], ident: str, position_s: Any, *,
                    tolerance_s: float = VERIFY_TOLERANCE_S) -> bool:
    """True = checkpoint NESMÍ zapsat tuto pozici (Φ2). Drží se, dokud navázání na
    `hold["target"]` stejného identu není ověřené a pozice je pod cílem."""
    if not hold or not ident or str(hold.get("ident") or "") != str(ident):
        return False
    target = _num(hold.get("target"))
    if target <= 0:
        return False
    return _num(position_s) < target - float(tolerance_s)


def format_time(seconds: Any) -> str:
    """„40:01" / „1:02:03" — jeden formát pro toasty navazování."""
    total = int(_num(seconds))
    mm, ss = divmod(total, 60)
    hh, mm = divmod(mm, 60)
    return "%d:%02d:%02d" % (hh, mm, ss) if hh else "%d:%02d" % (mm, ss)


def pending_valid(pending: Optional[Dict[str, Any]], ident: str, now: Optional[float] = None) -> bool:
    """Patří čekající navázání právě otevřenému streamu? (ident + stáří, čisté)."""
    if not isinstance(pending, dict) or not ident:
        return False
    if str(pending.get("ident") or "") != str(ident):
        return False
    now = time.time() if now is None else float(now)
    created = _num(pending.get("created"))
    return created > 0 and (now - created) <= PENDING_MAX_AGE_S


# ─────────────────────────────────────────────────────────────────────────────
#  POŽADAVEK producent → plugin._play
# ─────────────────────────────────────────────────────────────────────────────
def _props():
    import richmovie_winprops as _wp
    return _wp


def publish_request(position_s: Any, *, ident: str = "", runtime_s: Any = 0.0,
                    source: str = SOURCE_CW, key: str = "") -> bool:
    """Zveřejní požadavek na navázání pro příští `plugin._play`. Pozice ≤ `MIN_POSITION_S`
    = start od začátku: staré props se smažou (nic nesmí viset pro nesouvisející play).
    `ident` = adresát; prázdný = patří dalšímu přehrání TÉHOŽ titulu (`key`, picker-first cesty
    ident předem neznají). Vrací True, když požadavek visí."""
    wp = _props()
    pos = _num(position_s)
    if pos <= MIN_POSITION_S:
        clear_request()
        return False
    wp.set_prop(PROP_POSITION, "%.1f" % pos)
    wp.set_prop(PROP_CREATED, "%.3f" % time.time())
    if key:
        wp.set_prop(PROP_KEY, str(key))
    else:
        wp.clear_prop(PROP_KEY)
    if ident:
        wp.set_prop(PROP_IDENT, str(ident))
    else:
        wp.clear_prop(PROP_IDENT)
    runtime = _num(runtime_s)
    if runtime > 0:
        wp.set_prop(PROP_RUNTIME, "%.1f" % runtime)
    else:
        wp.clear_prop(PROP_RUNTIME)
    wp.set_prop(PROP_SOURCE, source if source in SOURCES else SOURCE_CW)
    return True


def clear_request() -> None:
    wp = _props()
    for name in REQUEST_PROPS:
        wp.clear_prop(name)


def consume_request(ident: str, now: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """Převezme a VŽDY smaže požadavek (3.5.119, audit #4: po selhaném resolve nesmí
    pozice seeknout příští nesouvisející přehrávání). Adresát nesedí nebo je požadavek
    starší než `REQUEST_MAX_AGE_S` → None + log. Shodu KLÍČE titulu ověří volající
    (`request_matches_key`) — klíč zná až po načtení parametrů přehrání."""
    wp = _props()
    try:
        raw_pos = wp.get_prop(PROP_POSITION, "")
        req_ident = wp.get_prop(PROP_IDENT, "")
        raw_runtime = wp.get_prop(PROP_RUNTIME, "")
        source = wp.get_prop(PROP_SOURCE, "") or SOURCE_CW
        req_key = wp.get_prop(PROP_KEY, "")
        created = _num(wp.get_prop(PROP_CREATED, ""))
    finally:
        clear_request()
    pos = _num(raw_pos)
    if pos <= 0:
        return None
    if req_ident and ident and req_ident != ident:
        _log("RESUME_SKIP: pozice patří identu %s, hraje se %s" % (req_ident, ident), _LOGINFO)
        return None
    now = time.time() if now is None else float(now)
    if created <= 0 or (now - created) > REQUEST_MAX_AGE_S:
        _log("RESUME_SKIP: požadavek na navázání je starý %.0f s (strop %.0f s)" % (
            (now - created) if created > 0 else -1, REQUEST_MAX_AGE_S), _LOGINFO)
        return None
    return {"position": pos, "runtime": _num(raw_runtime), "key": req_key,
            "source": source if source in SOURCES else SOURCE_CW}


def request_matches_key(request: Optional[Dict[str, Any]], key: str) -> bool:
    """Patří požadavek přehrávanému titulu? Bez klíče v požadavku nebo neznámý klíč přehrání
    = nelze rozhodnout → ano (ident už ověřil `consume_request`)."""
    if not request:
        return False
    req_key = str(request.get("key") or "")
    if not req_key or not key:
        return True
    return req_key == str(key)


def make_request(position_s: Any, *, runtime_s: Any = 0.0, source: str = SOURCE_REMOTE) -> Optional[Dict[str, Any]]:
    """Požadavek vzniklý přímo v `_play` (Φ5: novější pozice z jiného zařízení)."""
    pos = _num(position_s)
    if pos <= 0:
        return None
    return {"position": pos, "runtime": _num(runtime_s), "source": source if source in SOURCES else SOURCE_CW}


# ─────────────────────────────────────────────────────────────────────────────
#  plugin._play → Kodi (nativní start) + služba (ověření)
# ─────────────────────────────────────────────────────────────────────────────
def set_resume_point(li: Any, position_s: float, total_s: float) -> bool:
    """Zapíše bod navázání do ListItemu. Kodi 20+: `InfoTagVideo.setResumePoint`;
    starší Kodi: vlastnosti `ResumeTime` / `TotalTime` (tentýž CBookmark, viz
    ListItem.cpp:236–255). True = zapsáno."""
    try:
        tag = li.getVideoInfoTag()
        if hasattr(tag, "setResumePoint"):
            tag.setResumePoint(float(position_s), float(total_s))
            return True
    except Exception as exc:
        _log("setResumePoint failed: %r → legacy vlastnosti" % (exc,), _LOGDEBUG)
    try:
        li.setProperty("TotalTime", "%.1f" % float(total_s))
        li.setProperty("ResumeTime", "%.1f" % float(position_s))
        return True
    except Exception as exc:
        _log("RESUME_PREPARE_FAILED: %r" % (exc,), _LOGWARNING)
        return False


def prepare_resolved_item(li: Any, request: Optional[Dict[str, Any]], *, ident: str,
                          runtime_hint_s: Any = 0.0, key: str = "") -> Optional[Dict[str, Any]]:
    """Volá `plugin._play` PŘED `setResolvedUrl`. Zapíše bod navázání do položky a
    zveřejní čekající ověření pro službu. Vrací plán (log/testy) nebo None."""
    if not request:
        clear_pending()
        return None
    runtime = _num(request.get("runtime")) or _num(runtime_hint_s)
    point = start_point(request.get("position"), runtime)
    if point is None:
        clear_pending()
        _log("RESUME_NOT_NEEDED pos=%.0fs runtime=%.0fs source=%s" % (
            _num(request.get("position")), runtime, request.get("source")), _LOGDEBUG)
        return None
    position, total = point
    if not set_resume_point(li, position, total):
        clear_pending()
        return None
    plan = {"ident": str(ident or ""), "key": str(key or ""), "target": position, "total": total,
            "source": request.get("source") or SOURCE_CW, "created": round(time.time(), 3)}
    _props().set_prop(PROP_PENDING, json.dumps(plan, separators=(",", ":")))
    _log("RESUME_PREPARED target=%s source=%s ident=%s (nativní start Kodi)" % (
        format_time(position), plan["source"], plan["ident"] or "?"), _LOGINFO,
        context={"target_s": int(position), "total_s": int(total), "source": plan["source"],
                 "ident": plan["ident"], "key": plan["key"]})
    return plan


def load_pending() -> Optional[Dict[str, Any]]:
    raw = _props().get_prop(PROP_PENDING, "")
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def clear_pending() -> None:
    _props().clear_prop(PROP_PENDING)


def take_pending(ident: str, now: Optional[float] = None) -> Optional[Dict[str, Any]]:
    """Služba v `onAVStarted`: převezme čekající navázání pro právě otevřený stream.
    Cizí nebo prošlý záznam se smaže a vrací se None (nic nevisí do dalšího play)."""
    pending = load_pending()
    if pending is None:
        return None
    clear_pending()
    if pending_valid(pending, ident, now):
        return pending
    _log("RESUME_PENDING_DISCARDED ident=%s pending_ident=%s" % (ident or "?", pending.get("ident")),
         _LOGDEBUG)
    return None


def _read_progress(player: Any) -> Tuple[float, float]:
    """(délka, pozice) z přehrávače; (0, 0) když ještě/už nejde číst."""
    try:
        total = float(player.getTotalTime() or 0.0)
        pos = float(player.getTime() or 0.0)
        return total, pos
    except Exception:
        return 0.0, 0.0


def run_verification(player: Any, monitor: Any, plan: Dict[str, Any], *,
                     alive: Callable[[], bool], seek_own: Callable[[float], None],
                     clock: Callable[[], float] = time.monotonic) -> Dict[str, Any]:
    """Ověří navázání po skutečném startu (služba, vlákno přehrávání). Nikdy nevyhodí.

    `alive()` = generace přehrávání platí a uživatel nepřevzal řízení (vlastní seek).
    `seek_own(target)` = seek označený jako náš (onPlayBackSeek ho nepočítá jako vstup).
    Vrací {"outcome", "observed", "waited", "attempts"}; loguje výsledek."""
    target = _num(plan.get("target"))
    source = plan.get("source") or SOURCE_CW
    started_at = clock()
    result = {"outcome": OUTCOME_ABORTED, "observed": 0.0, "waited": 0.0, "attempts": 0}
    try:
        # 1) skutečný start = délka známá (≈ `canseek`, Kodi seek přijme). Pozice se NEČEKÁ: `CVideoPlayer::Prepare`
        #    po seeku demuxeru nastaví hodiny na `starttime` (`m_clock.Discontinuity`) PŘED prvním `UpdatePlayState`
        #    (VideoPlayer.cpp:1331–1357) → s délkou je čas buď na cíli (nativní start), nebo 0 (start od nuly).
        #    Podmínka „čas > 0" by stream stojící na nule přes pomalé bufferování nechala bez opravy (Fable F11).
        deadline = started_at + VERIFY_DEADLINE_S
        total, pos = 0.0, 0.0
        while True:
            if not alive():
                return _finish(result, plan, started_at, clock)
            total, pos = _read_progress(player)
            if total > 0:
                break
            if clock() >= deadline:
                result["outcome"] = OUTCOME_UNVERIFIED
                return _finish(result, plan, started_at, clock)
            if monitor.waitForAbort(VERIFY_POLL_S):
                return _finish(result, plan, started_at, clock)
        if monitor.waitForAbort(VERIFY_SETTLE_S) or not alive():
            return _finish(result, plan, started_at, clock)

        # 2) porovnání + nejvýš CORRECTION_MAX oprav
        while True:
            total, pos = _read_progress(player)
            result["observed"] = pos
            decision = verdict(target, pos, total)
            if decision == VERDICT_IGNORE:
                result["outcome"] = OUTCOME_IGNORED
                return _finish(result, plan, started_at, clock)
            if decision == VERDICT_OK:
                result["outcome"] = OUTCOME_NATIVE_OK if result["attempts"] == 0 else OUTCOME_CORRECTED
                return _finish(result, plan, started_at, clock)
            if result["attempts"] >= CORRECTION_MAX:
                result["outcome"] = OUTCOME_FAILED
                return _finish(result, plan, started_at, clock)
            if not alive():   # čtení výše a seek níže nesmí překlenout výměnu streamu (cross-check Pro A PA2)
                return _finish(result, plan, started_at, clock)
            result["attempts"] += 1
            _log("RESUME_CORRECTING target=%s observed=%s attempt=%d/%d source=%s" % (
                format_time(target), format_time(pos), result["attempts"], CORRECTION_MAX, source), _LOGWARNING)
            seek_own(target)
            # Počkat, až seek dosedne (nebo vyprší okno) — jinak by druhá oprava přišla
            # dřív, než se první vůbec projevila, a obraz by jen škubal.
            wait_until = clock() + CORRECTION_WAIT_S
            while clock() < wait_until:
                if monitor.waitForAbort(VERIFY_POLL_S) or not alive():
                    return _finish(result, plan, started_at, clock)
                t2, p2 = _read_progress(player)
                if verdict(target, p2, t2) != VERDICT_CORRECT:
                    break
    except Exception as exc:
        _log("RESUME_VERIFY_ERROR: %r" % (exc,), _LOGWARNING)
        result["outcome"] = OUTCOME_UNVERIFIED
        return _finish(result, plan, started_at, clock)


def _finish(result: Dict[str, Any], plan: Dict[str, Any], started_at: float,
            clock: Callable[[], float]) -> Dict[str, Any]:
    result["waited"] = round(max(0.0, clock() - started_at), 1)
    outcome = result["outcome"]
    level = _LOGINFO
    if outcome == OUTCOME_FAILED:
        level = _LOGERROR
    elif outcome in (OUTCOME_CORRECTED, OUTCOME_UNVERIFIED):
        level = _LOGWARNING
    elif outcome == OUTCOME_ABORTED:
        level = _LOGDEBUG
    _log("RESUME_%s target=%s observed=%s source=%s attempts=%d waited=%.1fs" % (
        outcome.upper(), format_time(plan.get("target")), format_time(result["observed"]),
        plan.get("source"), result["attempts"], result["waited"]), level,
        context={"outcome": outcome, "target_s": int(_num(plan.get("target"))),
                 "observed_s": int(_num(result["observed"])), "source": plan.get("source"),
                 "attempts": result["attempts"], "waited_s": result["waited"],
                 "ident": plan.get("ident"), "key": plan.get("key")})
    return result


# ─────────────────────────────────────────────────────────────────────────────
#  MRTVÝ ZDROJ (Φ3b) — čistý detektor, Kodi čte služba
# ─────────────────────────────────────────────────────────────────────────────
DEAD_SOURCE_SOURCES = ("webshare", "fastshare")   # jen streamy přes CFileCache (local/SMB cache nemají)
DEAD_SOURCE_SAMPLE_S = 5.0
DEAD_SOURCE_GRACE_S = 20.0          # po startu: buffer se plní, ProgressCache ještě nic neříká
# Okno = kolik skutečného přehrávání musí hranice cache stát. `Player.ProgressCache` je celé procento
# (PlayerGUIInfo.cpp:181) = krok 1 % délky. Cross-check Flash F6: s oknem 90 s / 2,5 kroku by pomalá,
# ale živá linka (~0,3× datového toku) občas nepřekročila krok a vypadala jako mrtvá. Se 180 s / 4 kroky
# poplach vyžaduje stažení < 1/4 kroku za okno (≈ 0,15× toku u 44min dílu) — taková linka stejně
# nepřehraje a buffer dojde; mrtvý zdroj po výpadku stojí minuty, zpoždění obnovy je přijatelné.
DEAD_SOURCE_MIN_WINDOW_S = 180.0
DEAD_SOURCE_STEP_FACTOR = 4.0
DEAD_SOURCE_PLAYED_RATIO = 0.8      # přehrávání za okno opravdu běželo (ne buffering / pauza)
DEAD_SOURCE_TAIL_PCT = 99.0         # cache už sahá na konec souboru → nic se nestahuje, zdroj není mrtvý
DEAD_SOURCE_SEEK_TOLERANCE_S = 3.0
RECONNECT_ONLINE_STABLE_S = 15.0    # síť ONLINE aspoň 15 s (vlak v tunelu flapuje)

DEAD_OK = "ok"
DEAD_UNKNOWN = "unknown"
DEAD_WAIT_NETWORK = "wait_network"  # zdroj stojí, ale síť ještě není zpátky — buffer je jediné, co divák má
DEAD_SOURCE = "dead"


class DeadSourceDetector:
    """Stavový automat jednoho přehrávání (krmí ho služba 5s vzorky)."""

    def __init__(self, duration_s: Any) -> None:
        self.duration_s = _num(duration_s)
        self._reset()

    def _reset(self) -> None:
        self._end = None           # type: Optional[float]
        self._since = None         # type: Optional[float]
        self._pos0 = 0.0
        self._last_pos = None      # type: Optional[float]
        self._last_at = None       # type: Optional[float]

    def window_s(self) -> float:
        step = self.duration_s / 100.0
        return max(DEAD_SOURCE_MIN_WINDOW_S, DEAD_SOURCE_STEP_FACTOR * step)

    def stalled_s(self, now: float) -> float:
        return 0.0 if self._since is None else max(0.0, float(now) - self._since)

    def feed(self, *, now: float, position_s: Any, cache_pct: Any, paused: bool, online: bool) -> str:
        if self.duration_s <= 0 or paused or position_s is None or cache_pct is None:
            self._reset()
            return DEAD_UNKNOWN
        try:
            pos = float(position_s)
            pct = float(cache_pct)
        except (TypeError, ValueError):
            self._reset()
            return DEAD_UNKNOWN
        if pct != pct or pos < 0:   # NaN
            self._reset()
            return DEAD_UNKNOWN
        if pct >= DEAD_SOURCE_TAIL_PCT:
            self._reset()
            return DEAD_OK
        if self._last_pos is not None and self._last_at is not None:
            wall = float(now) - self._last_at
            jump = pos - self._last_pos
            if jump < -DEAD_SOURCE_SEEK_TOLERANCE_S or jump > wall + DEAD_SOURCE_SEEK_TOLERANCE_S:
                self._reset()   # seek: cache se přeskládá, starý průběh nic neznamená
        self._last_pos, self._last_at = pos, float(now)
        cached_end = pct / 100.0 * self.duration_s
        step = self.duration_s / 100.0
        if self._end is None or cached_end > self._end + 0.5 * step:
            self._end, self._since, self._pos0 = cached_end, float(now), pos
            return DEAD_OK
        stall = float(now) - float(self._since)
        played = pos - self._pos0
        if stall < self.window_s() or played < DEAD_SOURCE_PLAYED_RATIO * stall:
            return DEAD_OK
        return DEAD_SOURCE if online else DEAD_WAIT_NETWORK


def network_ready(state: str, state_since: float, now: Optional[float] = None) -> bool:
    """Síť pro obnovu spojení: ONLINE aspoň `RECONNECT_ONLINE_STABLE_S` (čisté).
    `richmovie_netstate` vidí hlavně provoz na Gate — při výpadku Gate ho doplňuje `RouteTracker`."""
    now = time.time() if now is None else float(now)
    return state == "online" and (now - float(state_since or 0.0)) >= RECONNECT_ONLINE_STABLE_S


# ─────────────────────────────────────────────────────────────────────────────
#  SÍŤ PRO NAVÁZÁNÍ = CESTA KE ZDROJI STREAMU, NE KE GATE (Fable F1, 17.09.2026)
# ─────────────────────────────────────────────────────────────────────────────
# Resolve odkazu jde na API Webshare/Fastshare a stream na jejich CDN — Gate k navázání není potřeba.
# První verze 3.5.151 čekala na sondu Gate `/health`: při výpadku Gate (72h lease, offline-grace) nebo
# pomalé odpovědi Gate hlásila „Síť vypadla" a navázání odložila, ačkoli 3.5.150 navázalo hned.
ROUTE_VIA_CDN = "cdn"      # CDN posledního streamu odpověděla (jakýkoli HTTP stav — i 403 prošlého odkazu)
ROUTE_VIA_GATE = "gate"    # CDN ne, Gate ano: internet jde, nejspíš padl uzel CDN → nový resolve dá jiný odkaz
ROUTE_NONE = ""
DEAD_SOURCE_ROUTE_CHECK_S = 15.0   # rozestup vlastních kontrol CDN, dokud netstate síť nehlásí zpátky


def stream_http_url(url: Any) -> str:
    """HTTP(S) adresa streamu bez Kodi hlaviček (`url|User-Agent=…`); jiný zdroj → ""."""
    base = str(url or "").split("|", 1)[0].strip()
    return base if base.lower().startswith(("http://", "https://")) else ""


def resume_route(stream_url: Any, *, check_cdn: Callable[[str], int],
                 probe_gate: Callable[[], bool]) -> str:
    """Je síť použitelná pro navázání? (čisté, harness 61). Pořadí: CDN streamu → Gate → nic.

    `check_cdn(url)` = HTTP stav kontroly CDN (0 = transportní chyba), `probe_gate()` = sonda Gate.
    Gate se ptá JEN když CDN neodpověděla. Nikdy nevyhodí."""
    url = stream_http_url(stream_url)
    if url:
        try:
            if int(check_cdn(url) or 0) > 0:
                return ROUTE_VIA_CDN
        except Exception:
            pass
    try:
        if probe_gate():
            return ROUTE_VIA_GATE
    except Exception:
        pass
    return ROUTE_NONE


class RouteTracker:
    """Stabilita cesty ke CDN streamu z vlastních kontrol (hlídač mrtvého zdroje, čisté).

    Obnova spojení potřebuje síť stabilní aspoň `RECONNECT_ONLINE_STABLE_S` (vlak v tunelu flapuje).
    Netstate to pozná jen podle provozu na Gate; když Gate neodpovídá, cesta se ověřuje přímo na CDN
    nejvýš jednou za `DEAD_SOURCE_ROUTE_CHECK_S`."""

    def __init__(self) -> None:
        self.ok_since = None      # type: Optional[float]
        self._next_check = 0.0

    def due(self, now: float) -> bool:
        return float(now) >= self._next_check

    def note(self, ok: bool, now: float) -> None:
        now = float(now)
        self._next_check = now + DEAD_SOURCE_ROUTE_CHECK_S
        if not ok:
            self.ok_since = None
        elif self.ok_since is None:
            self.ok_since = now

    def stable(self, now: float) -> bool:
        return self.ok_since is not None and (float(now) - self.ok_since) >= RECONNECT_ONLINE_STABLE_S
