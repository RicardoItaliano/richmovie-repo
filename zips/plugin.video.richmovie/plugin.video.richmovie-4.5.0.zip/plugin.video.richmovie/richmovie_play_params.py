# -*- coding: utf-8 -*-
"""
richmovie_play_params — SSOT parametrů `action=play` (Webshare / Fastshare + kontext titulu).

Proč (plán `Handoff/PLAN_televize_vod_20261108.md`, F2, KI-b): trojice Fastshare (`source`, `fs_url`, `fs_hash`) a kontext
titulu se skládaly na šesti místech. Pořadí klíčů odpovídá dosavadním adresám (Kodi si k adrese pamatuje záložku),
proto film nese zdroj PŘED kontextem a díl ZA ním. Bez Kodi importů. Python 3.8.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

SOURCE_FASTSHARE = "fastshare"


def source_params(source: Any, fs_url: Any = "", fs_hash: Any = "") -> Dict[str, str]:
    """Parametry zdroje streamu: Fastshare = `source` + známé `fs_url` / `fs_hash`, ostatní zdroje nic."""
    if str(source or "").strip() != SOURCE_FASTSHARE:
        return {}
    out = {"source": SOURCE_FASTSHARE}
    if fs_url:
        out["fs_url"] = fs_url
    if fs_hash:
        out["fs_hash"] = fs_hash
    return out


def release_source_params(rel: Any) -> Dict[str, str]:
    """`source_params` nad objektem `Release`."""
    return source_params(getattr(rel, "source", "webshare"), getattr(rel, "fs_download_url", None),
                         getattr(rel, "fs_hash", None))


def for_release(rel: Any, *, movie: Optional[Dict[str, Any]] = None, episode: Optional[Dict[str, Any]] = None,
                autoplay: bool = False) -> Dict[str, str]:
    """Parametry přehrání streamu `Release`.

    `movie` = detail filmu (`title`, `year`, `id`) · `episode` = `tv_id`, `tv_name`, `season`, `episode`, `ep_title` ·
    `autoplay` = přehrání bez diváka (žádné modály ani interaktivní přihlášení)."""
    qs: Dict[str, str] = {"action": "play", "ident": str(getattr(rel, "ident", "") or "")}
    if episode:
        qs["tv_id"] = str(episode.get("tv_id") or "")
        qs["tv_name"] = str(episode.get("tv_name") or "")
        qs["season"] = str(episode.get("season"))
        qs["episode"] = str(episode.get("episode"))
        qs["ep_title"] = str(episode.get("ep_title") or "")
    if autoplay:
        qs["autoplay"] = "1"
    qs.update(release_source_params(rel))
    if movie:
        if movie.get("title"):
            qs["m_title"] = movie["title"]
        if movie.get("year"):
            qs["m_year"] = str(movie["year"])
        if movie.get("id"):
            qs["tmdb"] = str(movie["id"])
    return qs
