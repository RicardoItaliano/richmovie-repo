# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie Kodi plugin  – v1.3 (06 / 2025)
───────────────────────────────────────────────────────────────────────────────
Špičkový vyhledávač filmů / seriálů na Webshare.cz s paralelním dotazováním,
heuristickou filtrací a GUI přívětivým výstupem.  Aktuální architektura:

  • **richmovie_webshare.py**  – HTTP klient + login + stopáž probe  
  • **richmovie_engine.py**    – vyhledávací a filtrační logika ("know‑how")  
  • *plugin.py*                – pouze UI lepidlo / routing / Kodi volání

Díky tomu je hlavní soubor čitelný, snadno se testuje a případný
budoucí refaktor se nedotkne uživatelského rozhraní.

Licence: MIT · Autor: Richie (2025-06 - ???)
═══════════════════════════════════════════════════════════════════════════════
"""
# --------------------------------------------------------------------------- #
#  IMPORTY + zpřístupnění resources/lib       (aktualizováno 14.12.2025 19:32 CET (Europe/Prague))
# --------------------------------------------------------------------------- #
from __future__ import annotations

# Φ0 (29.09.2026): monotónní čas prvního řádku modulu = začátek importu této invokace.
# `main()` z něj počítá `import_ms` do TRACE begin (audit A08: start + import = 0,4 s na PC,
# na TV násobně víc, a do 29.09. to nikdo neměřil). Tenký spouštěč (Φ4) předá vlastní t0.
import time as _rm_time_t0
_RM_T0 = _rm_time_t0.monotonic()

# =========================
# STANDARDNÍ KNIHOVNY
# =========================
import datetime
import functools
import hashlib
import importlib
import json
import os
import re
import shutil
import socket
import sys
import threading
import time
import typing
import urllib.parse
from dataclasses import asdict
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Sequence,
    Tuple,
)
from urllib.parse import parse_qs, quote_plus, urlencode

# =========================
# RESOURCES/LIB PATH SETUP — MUSI BYT PRED 3rd-party importem
# (vendored libs: requests, urllib3, certifi, idna, chardet —
#  resources/lib/vendor/ ma prednost pred system-wide kopiema)
# =========================
ADDON_DIR = Path(__file__).resolve().parent
LIB_DIR = ADDON_DIR / "resources" / "lib"
VENDOR_DIR = LIB_DIR / "vendor"
if VENDOR_DIR.exists() and str(VENDOR_DIR) not in sys.path:
    sys.path.insert(0, str(VENDOR_DIR))
if LIB_DIR.exists() and str(LIB_DIR) not in sys.path:
    sys.path.insert(0, str(LIB_DIR))

# 3RD-PARTY (vendored `requests`) se od Φ4 (29.09.2026) importuje líně jen tam, kde se volá
# (vendor kontrola níže, stahování) — dřív ~155 ms na KAŽDÝ klik (audit A08 F2).

# =========================
# KODI API
# =========================
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)
import richmovie_feedback as _rm_fb  # Φ2 (29.09.2026): SSOT okamžité odezvy (průběh, toast, chyby)


# =========================
# USER LOGS PIPELINE (3.4.0 — always-on per-user telemetry)
# =========================
# Init logging idempotently per plugin process. SQLite WAL buffer multi-writer
# safe (BEGIN IMMEDIATE + busy_timeout) — drainer ve service_nextup.py reads + uploads.
# Per-process: each plugin invocation = fresh interpreter = fresh singleton +
# fresh SQLite connection. Plugin writes log events directly via short-lived conn.
# Plan: RichMovie-nas/Handoff/session_2026-04-27_user_logs_audit.md (Phase 3)
# 3.4.x Phase 9: Plain [RichMovie] log calls route via richmovie_logging
# pipeline. Subsystem-prefix calls (e.g. [RichMovie/Fastshare]) stay as
# direct xbmc.log for now — those should migrate into respective subsystem
# modules in Phase 9 batch 5+.
try:
    import richmovie_logging as _rm_logging
    _rm_logging.init_logging(xbmcaddon.Addon())
    _log = _rm_logging.make_legacy_logger("richmovie", "RichMovie")
    # Observability 2026-07-01 (3.5.79): per-user DEBUG gate ze serveru.
    # Gate /auth → permissions.debug_logs (mig 0018 default TRUE = DEBUG
    # always-on; killswitch = admin toggle). Fail-safe False (INFO) — bez
    # použitelné cache / proti starému Gate se objem nezvyšuje. Guardraily:
    # RateLimitingFilter (3.5.73) + tiered retence (Gate) + server-side
    # per-level drop v /v1/user_logs/batch. Best-effort — pád gate čtení
    # nesmí shodit bootstrap loggingu.
    try:
        import richmovie_gate as _rm_gate_dbg
        _rm_logging.set_debug(_rm_gate_dbg.is_debug_logs_enabled())
        # Self-proving marker: záznam vznikne JEN když DEBUG gate reálně
        # prošel (level=DEBUG se jinak odfiltruje) → v session story na Gate
        # je vidět, že invokace běžela s aktivním DEBUG. Při vypnutém flagu
        # nevzniká nic (nulový objem).
        _rm_logging.get_logger("richmovie.diag").debug(
            "DEBUG_GATE active (server flag debug_logs=true)")
    except Exception:
        pass
except Exception:
    # Fallback _log if richmovie_logging unavailable
    def _log(msg, level=1, *, context=None):
        try:
            xbmc.log(f"[RichMovie] {msg}", level)
        except Exception:
            pass


# =========================
# VENDOR HEALTH DIAGNOSTICS (3.3.0+ — one-shot per Kodi session)
# =========================
# Po startu Kodi (jednou per session) overi, ze vendored libs v
# resources/lib/vendor/ vyhravaji nad system Kodi addons (kdyby Kodi
# mel script.module.requests nainstalovany jako separatni addon).
# Idempotentni pres xbmcgui.Window(10000) IPC property — zalogguje
# se jen prvni invokaci plugin.py po startu Kodi.
def _vendor_health_check() -> None:
    try:
        _w = xbmcgui.Window(10000)
        if _w.getProperty("RichMovie.VendorHealth") == "1":
            return
        _w.setProperty("RichMovie.VendorHealth", "1")
    except Exception:
        return  # best-effort, nikdy nevyhodime exception

    def _slog(msg: str) -> None:
        try:
            _log("[Vendor] " + msg, xbmc.LOGINFO)
        except Exception:
            pass

    try:
        _addon_ver = xbmcaddon.Addon().getAddonInfo("version") or "?"
    except Exception:
        _addon_ver = "?"
    _slog("=== Vendor Health Check (%s) ===" % _addon_ver)
    _slog("VENDOR_DIR: %s (exists=%s)" % (VENDOR_DIR, VENDOR_DIR.exists()))
    _slog("sys.path[0]: %s" % (sys.path[0] if sys.path else "(empty)"))

    # Overit kazdou vendored lib: kde se nacetla + verze
    _libs = []
    try:
        import requests   # Φ4: líně — kontrola běží 1× za běh Kodi, ne při každém kliku
        _libs.append(("requests", requests))
    except Exception as _e:
        _slog("requests import failed: %s" % _e)
        requests = None
    for _name in ("urllib3", "certifi", "idna", "chardet"):
        try:
            _mod = importlib.import_module(_name)
            _libs.append((_name, _mod))
        except Exception as _e:
            _slog("%s IMPORT FAILED: %s" % (_name, _e))

    _vendor_lower = str(VENDOR_DIR).lower().replace("\\", "/")
    for _name, _mod in _libs:
        _path = getattr(_mod, "__file__", "?") or "?"
        _ver = getattr(_mod, "__version__", "?")
        _is_vendor = _vendor_lower in _path.lower().replace("\\", "/")
        _marker = "VENDOR_OK" if _is_vendor else "SYSTEM_FALLBACK"
        _slog("%s | %s %s | %s" % (_marker, _name, _ver, _path))

    # SSL OpenSSL verze (urllib3 2.x vyzaduje >= 1.1.1)
    try:
        import ssl as _ssl
        _slog("OpenSSL: %s" % _ssl.OPENSSL_VERSION)
    except Exception as _e:
        _slog("SSL check failed: %s" % _e)

    # Sanity HTTPS GET pres vendored requests na nas Gate /health
    try:
        if requests is None:
            raise RuntimeError("requests není k dispozici")
        _resp = requests.get("https://gate.svcnode.org/health", timeout=5)
        _slog("Sanity GET gate.svcnode.org/health: HTTP %s" % _resp.status_code)
    except Exception as _e:
        _slog("Sanity GET failed: %s" % _e)

    _slog("=== Health Check DONE ===")


# Spustit ihned (po Kodi API importech, pred lokalnimi moduly)
_vendor_health_check()


# =========================
# LOKÁLNÍ MODULY
# =========================
from tmdb_client import TMDb, TMDbError

from richmovie_collections import CollectionsUI

# — UI utility z centralizovaného modulu (Fáze 1 refaktoringu, 24.01.2026) —
from richmovie_helpers import (
    keyboard_input as _keyboard_input_impl,
    modal as _modal_impl,
    net_error_message as _net_error_message,
    notif as _notif_impl,
    progress as _progress_impl,
    format_int_spaced as _format_int_spaced_impl,
    format_mediainfo as _format_mediainfo_impl,
)

# — Lokalizace streamů (Fáze 2 refaktoringu, 24.01.2026) —
import richmovie_localization as _loc_module

# — Historie vyhledávání a sledování (Fáze 2 refaktoringu, 24.01.2026) —
import richmovie_history as _hist_module

# — AI utility (Fáze 2B refaktoringu, 24.01.2026) —
import richmovie_ai as _ai_module
from richmovie_engine import (
    MAX_WS_RESULTS,
    LabelFormatter,
    Release,
    ReleaseFilter,
    SearchEngine,
    _SearchProgressWithTips,
    _dedupe_multi_source,
    norm as _norm,
    quality as _quality_of_name,
    releases_from_records as _releases_from_records,
    score_sort_key as _score_sort_key,
    score_text as _score_text,
)
# RichMovie 3.000 (2026-04-18): AI volání jdou přes Gate → RichClaudeAI
# (centrální tenant, Claude Opus). `richmovie_ai_client` exportuje
# recommend_titles / identify_titles + AIError. OpenAI se nikde nepoužívá.
# Plán: Handoff/session_2026-04-18_richmovie_3000_rcai_integration.md
import richmovie_ai_client  # noqa: E402  (import-after-main je ok v Kodi addonu)
import richmovie_profile  # noqa: E402  (profily 3.5.134 — SSOT „Kdo se dívá?")
from richmovie_ai_client import (
    AIError,
    identify_titles,
    recommend_titles,
)

from richmovie_welcome import maybe_show_welcome

from richmovie_webshare import (
    APIError,
    SessionManager,
    TokenExpired,
    WebshareClient,
    _JSONCache,
)

import richmovie_local_files
import richmovie_ratings  # hodnocení 1–5★ per profil (3.5.152)
import richmovie_settings  # SSOT settings accessory (TMDb klíč s Gate fallbackem)
import richmovie_listing as _rm_listing  # SSOT klíč listingu + brána MI2 (3.5.153)
import richmovie_breadcrumb as _rm_bc  # Φ0 (29.09.2026): měřené kroky `_rm_bc.step(…)` v cestě kliknutí
import richmovie_playback_dispatch as _rm_dispatch  # Φ1 (29.09.2026): JEDNO spuštění přehrávání (pád Kodi 21.2)
import richmovie_search_log as _rm_search_log      # Φ-A (30.09.2026): zápis logu hledání po dávkách (stejný obsah)
import richmovie_search_telemetry as _rm_stel      # Φ-A: měření hledání a výběru streamu (SEARCH_PHASES, PLAY_PICK)
import richmovie_quality as _rm_quality            # Φ-A/Φ-D: SSOT třídy rozlišení (šířka i výška)
import richmovie_episode_search as _rm_epsearch    # Φ-B (30.09.2026): SSOT hledání dílu (výpis i předstažení)
import richmovie_movie_search as _rm_moviesearch   # F2 (08.11.2026): SSOT hledání filmu (výpis i nabídka v Televizi)
import richmovie_play_params as _rm_play_params    # F2 (08.11.2026): SSOT parametrů action=play
import richmovie_routes as _rm_routes  # SSOT druhu akce (isFolder klikací položky, incident 19.09.2026)
import richmovie_atomic  # SSOT trvanlivých zápisů souborů (3.5.123, incident gunžík)
import richmovie_csfd
import richmovie_stream
import richmovie_sktorrent
import richmovie_youtube
import richmovie_yt_profile

# — Fastshare integrace (21.01.2026) —
from richmovie_fastshare import (
    FastshareClient,
    FastshareSessionManager,
    FastshareError,
    is_fastshare_allowed,
)


# =========================
# TYPE CHECKING ONLY
# =========================
if typing.TYPE_CHECKING:
    import richmovie_webshare  # pouze pro Pylance; za běhu se nevykoná





# `_rescue_numeric_episode` PŘESUNUTA (Φ-B, 30.09.2026) do SSOT `richmovie_episode_search.rescue_numeric`
# — volá ji kaskáda `run_cascade` pro výpis dílu i předstažení.









# ═══════════════════════════════════════════════════════════════════════════════
#  LOKALIZACE STREAMŮ – DELEGACE NA richmovie_localization (Fáze 2 refaktoringu)
# ═══════════════════════════════════════════════════════════════════════════════
# Původní implementace přesunuta do richmovie_localization.py (765 řádků)

def _loc__onboard_version() -> str:
    return _loc_module._onboard_version()

def _ensure_localization_onboarding() -> None:
    _loc_module.ensure_localization_onboarding()

def _loc__jsonrpc(method: str, params: dict) -> dict:
    return _loc_module._jsonrpc(method, params)

def _rm_normalize_lang_list(codes: List[str]) -> Tuple[List[str], List[str]]:
    return _loc_module.rm_normalize_lang_list(codes)

def _rm_build_label_dubbing_subs(aud_codes: List[str], sub_codes: List[str]) -> str:
    return _loc_module.rm_build_label_dubbing_subs(aud_codes, sub_codes)

def _rm_apply_av_streams_to_listitem(li: xbmcgui.ListItem, aud_codes: List[str], sub_codes: List[str]) -> None:
    _loc_module.rm_apply_av_streams_to_listitem(li, aud_codes, sub_codes)

def _loc__norm_lang(val: str) -> str:
    return _loc_module._norm_lang(val)

def _loc__pick_audio_index(audiostreams: list, audio_pref: str, orig_lang: str | None) -> int | None:
    return _loc_module._pick_audio_index(audiostreams, audio_pref, orig_lang)

def _loc__find_forced_sub(subtitles: list, audio_lang: str, current: dict | None = None) -> int | None:
    # 4.0.1: vynucená stopa jen v jazyce zvuku (zrcadlo Kodi) — signatura podle `richmovie_localization`
    return _loc_module._find_forced_sub(subtitles, audio_lang, current)

def _loc__pick_sub_index(subtitles: list, prefer: str, *, fallback_chain: list[str]) -> int | None:
    return _loc_module._pick_sub_index(subtitles, prefer, fallback_chain=fallback_chain)

def _loc__get_tmdb_original_language(m_tmdb: int | None, tv_id: int | None) -> str | None:
    return _loc_module._get_tmdb_original_language(m_tmdb, tv_id)

def _apply_stream_localization_async(
    *, m_tmdb: int | None = None, tv_id: int | None = None,
    m_title: str | None = None, m_year: int | None = None,
) -> None:
    _loc_module.apply_stream_localization_async(
        m_tmdb=m_tmdb, tv_id=tv_id, m_title=m_title, m_year=m_year
    )




# --------------------------------------------------------------------------- #
#  NEXT-UP  – perzistentní disková cache (rychlý pre-fetch)
# --------------------------------------------------------------------------- #
@functools.lru_cache(maxsize=1)
def _disk_nextup_cache() -> _JSONCache:
    """
    Vrátí instanci `_JSONCache` pro Next-Up.

    • Vytvoří se **až při prvním volání**, takže se nikdy
      nespustí dřív, než existuje `PROFILE_DIR`.
    • Díky dekorátoru `lru_cache(1)` držíme v processu jediný
      objekt – další volání jsou už jen rychlý lookup.
    • Pokud soubor ještě neexistuje, vytvoří se prázdný JSON `{}`,
      aby byl cache soubor vždy přítomný na disku.
    """
    import richmovie_paths
    path = richmovie_paths.personal_path("nextup_cache.json")   # osobní (profily 3.5.134)

    # 26.12.2025 – pojistka: když soubor neexistuje, vytvoř prázdný JSON
    # (u _JSONCache by to sice fungovalo i bez toho, ale tohle je UX + stabilita)
    try:
        if not path.exists():
            with open(path, "w", encoding="utf-8") as fh:
                json.dump({}, fh, ensure_ascii=False, indent=2)
    except Exception as exc:
        _log(f"nextup_cache init write failed: {exc}", xbmc.LOGDEBUG)

    return _JSONCache(path)


def _rel_attr(r, name):
    """Φ4 DRY přístup k poli releasu — Release objekt (engine/autoplay) i
    payload dict (custom Stream-picker, _rv_final_sort) jedou stejnou cestou."""
    if isinstance(r, dict):
        return r.get(name)
    return getattr(r, name, None)


def _measured_langs(r, field: str, flag: str):
    """Jazyky streamu pro řazení: stopy ZMĚŘENÉ ze souboru (MediaInfo), jinak údaj streamu (název).
    Jedno pravidlo pro objekt `Release` i slovník nového vzhledu — jinak by automatický výběr a výpis
    hodnotily týž stream různě (cross-check Pro B-P3, 30.09.2026)."""
    fl = _mi2_flags_for(_rel_attr(r, "ident") or "")
    if fl and not fl.get("fail") and fl.get(flag):
        return list(fl.get(flag) or [])
    return list(_rel_attr(r, field) or [])


def _pref_match_terms(r, pref):
    """Vrátí (audio_miss, sub_miss) pro daný release vůči per-title preferenci.

    Φ4 (2026-07-06, audit A03): 3-úrovňové skóre místo binárního —
      0 = potvrzený match (MI data znají preferovaný jazyk),
      1 = MI data NEZNÁMÁ (neprobnutý stream nesmí padat pod potvrzený miss —
          dřív tvrdý miss paradoxně degradoval správný neprobnutý stream),
      2 = potvrzený miss.
    Obě strany se normalizují přes engine `_mi2_norm_code`, takže nedochází ke
    cs↔CZ mismatchi (title_prefs ukládá ISO 'cs'/'en', Release.audios má UI 'CZ'/'EN').
    Funguje pro Release objekty i payload dicty (viz _rel_attr).
    pref=None / prázdná → (0, 0) → žádný vliv na řazení (zpětná kompatibilita).
    Best-effort — jakákoli chyba → (0, 0).
    """
    if not pref:
        return (0, 0)
    try:
        from richmovie_engine import _mi2_norm_code as _nc
    except Exception:
        return (0, 0)
    try:
        audio_miss = 0
        sub_miss = 0
        want_a = _nc(str(pref.get("audio_lang") or ""))
        if want_a:
            rel_a = {_nc(str(a)) for a in _measured_langs(r, "audios", "aud") if str(a).strip()}
            if not rel_a:
                audio_miss = 1
            elif want_a in rel_a:
                audio_miss = 0
            else:
                audio_miss = 2
        # Titulky řešíme jen když je uživatel u titulu reálně používal (sub_enabled).
        if pref.get("sub_enabled") and pref.get("sub_lang"):
            want_s = _nc(str(pref.get("sub_lang")))
            if want_s:
                rel_s = {_nc(str(s)) for s in _measured_langs(r, "subs", "sub") if str(s).strip()}
                if not rel_s:
                    sub_miss = 1
                elif want_s in rel_s:
                    sub_miss = 0
                else:
                    sub_miss = 2
        return (audio_miss, sub_miss)
    except Exception:
        return (0, 0)


def _order_pref(title_pref, profile_rec, device_audio_pref):
    """Čistá: preference zvuku pro ŘAZENÍ výpisu. Priorita jako u výběru stopy při otevření (3.5.155):
    PROFIL („český dabing“) > TITUL (co divák u titulu používal) > ZAŘÍZENÍ. „Původní znění“ jazyk
    neurčuje → rozhoduje záznam titulu, jinak jen kvalita. Vrací {audio_lang, sub_lang, sub_enabled} | None."""
    dub = {"audio_lang": "cs", "sub_lang": None, "sub_enabled": False}
    if isinstance(profile_rec, dict) and str(profile_rec.get("audio_lang") or "").strip().lower() == "cs":
        return dub
    if title_pref:
        return title_pref
    if not profile_rec and device_audio_pref == "cz_dub":
        return dub
    return None


def _lookup_title_pref(*, tv_id=None, m_tmdb=None, m_title=None, m_year=None):
    """Preference zvuku / titulků pro řazení výpisu streamů: záznam titulu (title_prefs, klíč tv:<id> /
    movie:<id>) + preference PROFILU a zařízení (`_order_pref`). Vrátí dict {audio_lang, sub_lang,
    sub_enabled} nebo None. Best-effort.

    Φ-E (30.09.2026, audit Fable F2-V1): dřív se četl jen záznam titulu → u titulu, který divák ještě
    nehrál, preference „český dabing“ z profilu řazení neovlivnila vůbec (D1 s ní počítá)."""
    title_pref = None
    try:
        import richmovie_title_prefs as _tp
        key = _tp.make_title_key(tv_id=tv_id, m_tmdb=m_tmdb, m_title=m_title, m_year=m_year)
        title_pref = _tp.get_pref(key) if key else None
    except Exception as exc:
        _log(f"title pref read failed: {exc!r}", xbmc.LOGDEBUG)
    try:
        import richmovie_localization as _loc
        return _order_pref(title_pref, _loc.profile_pref_record(), _loc.device_prefs().get("audio_pref"))
    except Exception as exc:
        _log(f"profile pref read failed: {exc!r}", xbmc.LOGDEBUG)
        return title_pref


def _release_sort_key(r, pref=None, continuity=None):
    """Sort key pro razeni Release kandidatu (nizsi = lepsi).
    Pouziva se v _pick_best_release i v service_nextup pro fallback razeni.

    Když je předána `pref` (per-title audio/sub preference), dostane PRIORITU:
    streamy s preferovaným dabingem (a typem titulků) jdou první; kvalita/velikost
    pak slouží jako tiebreak uvnitř matchující množiny („super sexy" UX). Bez pref
    se chová identicky jako dřív (CZ-bias fallback).

    `continuity` (3.5.151, `richmovie_continuity.context_for_title`): stejná verze jako
    minulý díl (řada, kodek, výška, podobný datový tok; po výpadcích nižší) jde PŘED
    kvalitu a velikost, ZA dealbreakery. Bez profilu verze je rank pro všechny 0.

    Φ-D (30.09.2026): klíč je SSOT `richmovie_quality.stream_sort_key` — TENTÝŽ pro výpis filmu, výpis
    dílu, výběr streamu v novém vzhledu i automatický výběr dalšího dílu (dřív čtyři různá řazení).
    """
    _flags = _mi2_flags_for(_rel_attr(r, "ident") or "")
    return _rm_quality.stream_sort_key(
        r,
        _flags,
        _pref_match_terms(r, pref),
        _continuity_rank(r, continuity),
        _score_sort_key(_rel_attr(r, "score")),
        dv_rank=_dv_rank(r, _flags),
    )


_DV_SUPPORT_CACHE = {"at": 0.0, "value": False}   # řazení volá klíč pro každý stream — schopnost zařízení 1× za 5 s


def _dv_supported() -> bool:
    """Přehraje tohle zařízení Dolby Vision? SSOT `richmovie_device_env.dv_supported` (služba zjišťuje z Kodi)."""
    now = time.monotonic()
    if now - _DV_SUPPORT_CACHE["at"] < 5.0:
        return bool(_DV_SUPPORT_CACHE["value"])
    try:
        import richmovie_device_env as _denv_dv
        value = bool(_denv_dv.dv_supported())
    except Exception:
        value = False
    _DV_SUPPORT_CACHE.update(at=now, value=value)
    return value


def _dv_rank(r, flags=None) -> int:
    """Noc 03.11.2026 (Φ3): hratelnost obrazu streamu na TOMTO zařízení (SSOT `richmovie_quality.dv_playability`)."""
    try:
        if flags is None:
            flags = _mi2_flags_for(_rel_attr(r, "ident") or "")
        return _rm_quality.dv_playability(flags, _rel_attr(r, "name") or "", _dv_supported())
    except Exception:
        return _rm_quality.DV_OK


class _DictRelease(object):
    """Stream z payloadu nového vzhledu (slovník) jako objekt — pro kód, který čte `getattr`."""

    def __init__(self, data: dict) -> None:
        self.__dict__.update(data or {})


def _continuity_rank(r, continuity) -> int:
    """Rank kontinuity verze (SSOT `richmovie_continuity.rank_release`); bez kontextu 0."""
    if not continuity:
        return 0
    try:
        import richmovie_continuity as _cont
        return _cont.rank_release(_DictRelease(r) if isinstance(r, dict) else r, continuity)
    except Exception:
        return 0


def _listing_sort_key(r, pref=None, continuity=None, ws_blocked=False, broken=None):
    """Úplné pořadí streamu ve výpisu (nižší = výš) — SSOT pro automatický výběr, nový vzhled i záložní
    kandidáty autoplaye: vadný soubor (3.5.158) a nepřehratelný Webshare na Free účtu (3.5.129) jdou za
    ostatní, uvnitř rozhoduje `_release_sort_key`. Klasický výpis dává totéž pořadí dvěma stabilními
    průchody po seřazení (`_order_ws_blocked_last`, `_order_broken_last`). Jen pořadí, nikdy filtr."""
    blocked = _rel_attr(r, "ws_blocked")
    if blocked is None:
        blocked = bool(ws_blocked) and (_rel_attr(r, "source") or "webshare") == "webshare"
    rank = 0
    if broken:
        import richmovie_source_health as _sh_key
        rank = _sh_key.rank(_rel_attr(r, "ident") or "", broken)
    # Noc 03.11.2026 (Φ3): Dolby Vision bez kompatibilní vrstvy na zařízení bez DV = černý obraz → za hratelné.
    # Priorita odsunu (nejsilnější vlevo): vadný soubor > DV „ne“ > Free blokace — totéž dávají stabilní průchody
    # klasického výpisu (`_order_ws_blocked_last` → `_order_dv_unplayable_last` → `_order_broken_last`; poslední průchod
    # = nejsilnější klíč).
    dv_no = 1 if _dv_rank(r) == _rm_quality.DV_NO else 0
    return (rank, dv_no, 1 if blocked else 0, _release_sort_key(r, pref, continuity))


def _pick_best_release(rels, pref=None, ws_blocked=None, continuity=None):
    """Vrati nejlepsi Release pro auto-play (TV epizoda sort logika).
    `pref` (per-title audio/sub preference) upřednostní stream s preferovaným
    dabingem/titulky; bez pref zpětně kompatibilní (kvalita → CZ-bias → velikost).

    3.5.129 (Fable audit F-03): `ws_blocked` (None = zjistit ze stavu účtu) řadí
    Webshare položky Free účtu ZA vše ostatní — Next-Up autoplay tak vybere
    Fastshare, když existuje. Když zbývá jen blokovaný Webshare, vrátí ho
    (volající pozná blokaci přes `richmovie_account_state.playback_allowed`)."""
    if not rels:
        return None
    if ws_blocked is None:
        ws_blocked = _ws_playback_blocked()

    # 3.5.158: soubor vadný od nějaké pozice vybrat až jako poslední možnost (jen pořadí)
    broken = _broken_sources()
    return min(rels, key=lambda r: _listing_sort_key(r, pref, continuity, ws_blocked, broken))





def _await_nav_idle(expected_key: str, nav_key: str, *, max_wait_ms: int = 4000, extra_ms: int = 500) -> None:
    """
    24-08-2025 20:17 CEST (Europe/Prague)

    ÚČEL:
      Bezpečně "počká", až Next‑Up navigace (service) dokončí přepnutí okna
      a uvolní lock `Window(10000).property('richmovie.nextup.nav_inflight')`.
      Poté ještě přidá malou rezervu (výslovně požadovaných ~0,5 s).

    PRAVIDLA:
      • Čekáme POUZE, pokud jde o Next‑Up volání (nav_key == expected_key).
      • Nikdy nepadá; v nejhorším vyprší max_wait_ms a funkce prostě skončí.
    """
    try:
        if not (expected_key and nav_key and expected_key == nav_key):
            return  # nejedná se o Next‑Up handshake → nic nečekáme

        win = xbmcgui.Window(10000)
        mon = xbmc.Monitor()

        waited = 0
        # 1) čekáme max max_wait_ms na shození 'nav_inflight'
        while (win.getProperty("richmovie.nextup.nav_inflight") == "1") and waited < max_wait_ms:
            if mon.waitForAbort(0.1):
                break
            waited += 100

        # 2) rezervní pauza po uvolnění ("můžeš, je volno" + 0,5 s)
        if extra_ms > 0:
            mon.waitForAbort(extra_ms / 1000.0)
    except Exception:
        # best‑effort; jakákoli chyba se ignoruje (nesmí shodit GUI)
        pass




# 2025-08-14 13:16 CEST (Europe/Prague)
def _detect_skin_emoji_support() -> bool:
    """
    Lehká heuristika: projde složku skinu `special://skin/fonts/` a pokud
    najde fonty mající v názvu 'emoji', 'noto', 'color', 'twemoji', 'segoe',
    vyhodnotí, že skin *pravděpodobně* umí emoji.

    Není-li jistota, vrací False (text-only režim).
    """
    try:
        fonts_dir = xbmcvfs.translatePath("special://skin/fonts/")
        # Pokud složka není, většina skinů nepodporuje "barevné" emoji
        try:
            dirs, files = xbmcvfs.listdir(fonts_dir)
        except Exception:
            return False
        look = ("emoji", "color", "noto", "twemoji", "segoe")
        for name in files:
            n = (name or "").lower()
            if any(k in n for k in look):
                return True
        return False
    except Exception:
        return False



# ═══════════════════════════════════════════════════════════════════════════════
#  AI UTILITY – DELEGACE NA richmovie_ai (Fáze 2B refaktoringu)
# ═══════════════════════════════════════════════════════════════════════════════
# Původní implementace přesunuta do richmovie_ai.py (1277 řádků)

def _run_ai_with_progress(kind: str, user_text: str, *, mode: str, worker: Callable[[], Any]) -> Tuple[Any, Any]:
    """Delegováno do richmovie_ai"""
    return _ai_module.run_ai_with_progress(kind, user_text, mode=mode, worker=worker)


def _ensure_internet_async() -> None:
    """
    Načte se **pouze jednou** (idempotentní) a v daemon vlákně ověří, zda
    existuje reálné připojení k internetu.  Při neúspěchu:

        • zobrazí modální dialog,
        • zavře aktuální okno doplňku → `Action(Back)`,
        • zruší výpis adresáře (`endOfDirectory(succeeded=False)`).

    GUI zůstává plně responzivní; maximální čekání je ≈ 4 s.
    """
    if getattr(_ensure_internet_async, "_started", False):
        return
    _ensure_internet_async._started = True

    def _has_internet() -> bool:
        """
        Bleskový test přes raw socket (DNS/ICMP filtry nevadí):

            1) TCP hand‑shake na 1.1.1.1:53 (Cloudflare DNS)
            2) TCP hand‑shake na 8.8.8.8:53 (Google DNS)

        Timeout 1.5 s na každý pokus – celkově < 3 s.
        """
        for host in (("1.1.1.1", 53), ("8.8.8.8", 53)):
            try:
                with socket.create_connection(host, timeout=1.5):
                    return True
            except OSError:
                continue
        return False

    def _worker() -> None:
        if _has_internet():
            return                              # vše OK → nic nedělej

        # ✗ Internet nedostupný – informuj uživatele a ukonči doplněk
        # 3.4.8 (audit Ω1.a, 2026-05-17 post-audit): previously `Dialog().ok(...)`
        # which is MODAL — blocks until user clicks OK. If internet is down
        # at startup AND Kodi is asked to shut down before user dismissal,
        # `_worker.join()` (daemon=False per memory rule) hangs main thread
        # indefinitely → Kodi appears frozen, eventually OS force-closes.
        # Notification is non-blocking: 5s on-screen toast, no user action
        # required, Kodi shutdown not gated on click.
        _rm_notif(
            "Není dostupné připojení k internetu. Doplněk se ukončí.",
            xbmcgui.NOTIFICATION_WARNING,
            5000,
            "RichMovie",
        )
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        except Exception:
            pass

        # Zavře GUI okno doplňku (vrátí se o úroveň zpět / do domovské nabídky)
        xbmc.executebuiltin("Action(Back)")

    # 3.4.7 (audit Ω1, 2026-05-17): daemon=False per memory rule
    # `feedback_daemon_threads_kodi.md`. Worker does socket.create_connection
    # + Kodi UI dialog — if Kodi shuts down mid-syscall, daemon thread is
    # killed without abort listener. _worker already exits quickly (short
    # operation), so non-daemon is safe — main thread waits ≤2s max.
    threading.Thread(target=_worker, name="RMNetCheck", daemon=False).start()






# ――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――
# 🌟  Helper: bezpečné získání Kodi handle
# ――――――――――――――――――――――――――――――――――――――――――――――――――――――――――――
def _safe_handle(argv: list[str]) -> int:
    """
    Vrátí číslo *handle* předané Kodi při standardním spuštění doplňku.

    • Při běžném volání z GUI je `argv[1]` platné celé číslo.  
    • Pokud je modul pouze **importován** (např. `service_nextup.py`),
      `argv` má délku 1 → funkce vrací `‑1`.

    Hodnota ‑1 znamená "žádný GUI handle"; zbytek kódu (vyhledávání,
    RAM‑cache Next‑Up, TMDb volání apod.) může bezpečně běžet dál,
    protože nevolá žádné GUI funkce závislé na `xbmcplugin.*`.
    """
    try:
        return int(argv[1])
    except (IndexError, ValueError):
        return -1



# --------------------------------------------------------------------------- #
#  GLOBÁLNÍ KONTEXT DOPLŇKU
# --------------------------------------------------------------------------- #
ADDON      = xbmcaddon.Addon()
HANDLE     = _safe_handle(sys.argv)      # ⇐ bezpečná varianta
ADDON_ID   = ADDON.getAddonInfo("id")


# – Kodi cesty k profilu a logům –
PROFILE_DIR   = Path(xbmcvfs.translatePath(
    f"special://profile/addon_data/{ADDON_ID}"
))
PROFILE_DIR.mkdir(parents=True, exist_ok=True)

_LOG_PATH         = str(PROFILE_DIR / "richmovie.log")
_SEARCH_LOG_PATH  = ""         # nastaví se dynamicky


# 2025-08-10 21:57 CEST (Europe/Prague)
# VLOŽ hned pod deklarace:
#   PROFILE_DIR = ...
#   _LOG_PATH   = str(PROFILE_DIR / "richmovie.log")
#   _SEARCH_LOG_PATH = ""
_AI_LOG_PATH = str(PROFILE_DIR / "RichMovie_a.i.log")


# – Thread‑safe zámek pro log –
_LOG_LOCK = threading.Lock()

# Φ-A (30.09.2026): SSOT zapisovač událostního logu. Mimo rozsah hledání píše hned (jako dřív), uvnitř
# rozsahu (`_search_scope`) po dávkách — obsah řádků je stejný, mění se jen počet otevření souboru.
_SEARCH_LOG = _rm_search_log.SearchLogWriter(
    rotate_path=_LOG_PATH,
    on_error=lambda _m: _log("SEARCH_LOG_ERR %s" % _m, xbmc.LOGWARNING),
)
_rm_search_log.register_atexit(_SEARCH_LOG)
_TRACE_FLAGS_CACHE: dict = {}     # přepínače trace načtené JEDNOU na rozsah hledání ("flags": (bool, bool, bool))


def _read_trace_flags() -> tuple:
    """Tři přepínače podrobného trace z nastavení (čteno runtime, aby šlo přepnout bez restartu)."""
    return tuple(bool(richmovie_settings.get_bool(key))
                 for key in ("trace_enabled", "trace_ndjson", "trace_log_successes"))


def _log_event_row(path: str, event: str, *params: object, ts: str = "") -> None:
    """Jeden řádek událostního logu do `path` (čas s milisekundami, pole oddělená tabulátorem)."""
    if not ts:
        _now = datetime.datetime.now().astimezone()
        ts = _now.strftime("%Y-%m-%d %H:%M:%S") + ".%03d" % (_now.microsecond // 1000)
    _SEARCH_LOG.write(path, "\t".join([ts, event, *(str(p) for p in params)]))


class _search_scope(object):
    """Rozsah JEDNOHO hledání / výpisu streamů: log po dávkách + sběrač měření + jeden řádek
    `SEARCH_PHASES` do user_logs při opuštění (i výjimkou).

    Řádek se pošle jen když se opravdu hledalo nebo vykreslil výpis (tiché návraty Kodi nic neposílají).
    `kind` = movie | tv, `key` = `movie:<tmdb>` / `tv:<tv_id>:<S>:<E>`, `ctx` = click | reentry | prefetch."""

    def __init__(self, kind: str, key: str, ctx: str) -> None:
        self._args = (kind, key, ctx)
        self.run = None

    def __enter__(self):
        _SEARCH_LOG.begin()
        try:
            _TRACE_FLAGS_CACHE["flags"] = _read_trace_flags()
        except Exception:
            _TRACE_FLAGS_CACHE.pop("flags", None)
        try:
            self.run = _rm_stel.begin(*self._args)
            self.run.mark("tmdb")
        except Exception:
            # `__exit__` se po výjimce v `__enter__` nevolá → dávkování by zůstalo zapnuté do konce procesu
            _rm_stel.end(self.run)
            _TRACE_FLAGS_CACHE.pop("flags", None)
            _SEARCH_LOG.end()
            raise
        return self.run

    def __exit__(self, exc_type, exc, tb) -> bool:
        run = self.run
        try:
            if run is not None and (run.searched or run.n_list or run.outcome):
                outcome = run.outcome or ("error" if exc_type is not None else ("list" if run.n_list else "none"))
                payload = run.payload(run.n_list, outcome)
                _log_event_row(getattr(run, "log_path", "") or _LOG_PATH, "SEARCH_PHASES",
                               _rm_stel.compact(payload))
                # zpráva krátká (Gate ořezává zprávy na 4 000 znaků), celé měření nese `context`
                _log("SEARCH_PHASES sid=%s kind=%s outcome=%s n_list=%s ms=%s" % (
                    payload.get("sid"), payload.get("kind"), payload.get("outcome"), payload.get("n_list"),
                    (payload.get("ms") or {}).get("total")), xbmc.LOGINFO, context=payload)
        except Exception as _sp_exc:
            _log(f"SEARCH_PHASES emit failed: {_sp_exc!r}", xbmc.LOGDEBUG)
        finally:
            _rm_stel.end(run)
            _TRACE_FLAGS_CACHE.pop("flags", None)
            _SEARCH_LOG.end()
        return False

# --------------------------------------------------------------------------- #
#  SESSION  (Webshare login + VIP helpery)
# --------------------------------------------------------------------------- #
_SESSION = SessionManager(ADDON, HANDLE)

# --------------------------------------------------------------------------- #
#  FASTSHARE SESSION  (21.01.2026 – Fastshare integrace)
# --------------------------------------------------------------------------- #
# Inicializuje se lazy v _root() až po ověření whitelistu
_FS_SESSION: FastshareSessionManager | None = None


def _get_fastshare_client() -> FastshareClient | None:
    """
    Callback pro SearchEngine – vrátí přihlášený FastshareClient nebo None.
    Volá se při každém vyhledávání.

    DŮLEŽITÉ: Kodi spouští plugin jako nový proces pro každou akci,
    takže musíme lazy inicializovat session zde, ne spoléhat na _root().

    Priorita credentials:
      1. Lokální (uživatel zadal v nastavení)
      2. Gate (admin přiřadil)
    Tuto logiku řídí ensure_login() v FastshareSessionManager.
    """
    global _FS_SESSION

    # 1) Kontrola přístupu (vlastní credentials NEBO Gate povolení)
    ws_username = richmovie_settings.get_str("username").strip()
    if not is_fastshare_allowed(ws_username):
        return None

    # 2) Lazy inicializace session
    if _FS_SESSION is None:
        _FS_SESSION = FastshareSessionManager(ADDON)

    # 3) ensure_login řeší celý flow: lokální → Gate → (interaktivní ne)
    if not _FS_SESSION.is_logged_in():
        try:
            _FS_SESSION.ensure_login(interactive=False)
        except Exception as e:
            _log(f"[Fastshare] Login failed: {e}", xbmc.LOGWARNING)

    # 4) Vrať klienta pokud je přihlášen
    if _FS_SESSION.is_logged_in():
        return _FS_SESSION.get_client()

    return None


# --------------------------------------------------------------------------- #
#  SEARCH ENGINE  (využívá globální session + logger)
# --------------------------------------------------------------------------- #
# Globální přepínač:  Nastavení → "Podrobná analýza MediaInfo"
try:
    _PROBE_ENABLED = richmovie_settings.get_bool("probe_enabled")
except AttributeError:                          # Kodi &le; v18 fallback
    _PROBE_ENABLED = richmovie_settings.get_str("probe_enabled") == "true"

_ENGINE = SearchEngine(
    lambda: _SESSION.client,
    lambda *p: _log_event(*p),
    enable_probe=_PROBE_ENABLED,                # ⬅️ předáváme do SearchEnginu
    get_fastshare_client=_get_fastshare_client, # ⬅️ Fastshare integrace (21.01.2026)
)


# ─────────────────────────────────────────────────────────────────────────────
#  INICIALIZACE CALLBACKŮ PRO EXTRAHOVANÉ MODULY (Fáze 2 refaktoringu)
# ─────────────────────────────────────────────────────────────────────────────
# Lokalizace potřebuje callback pro logování
_loc_module.set_log_callback(lambda *p: _log_event(*p))
# Φ4 (29.09.2026): knihovní moduly zapisují události přes SSOT registr, ne `import plugin` (A08 F7)
import richmovie_event_log as _rm_event_log
_rm_event_log.register(lambda *p: _log_event(*p), lambda: _SEARCH_LOG_PATH or _LOG_PATH)

# Historie potřebuje callback pro modální dialog
_hist_module.set_modal_callback(lambda msg: _modal(msg))

# AI modul potřebuje callbacky pro keyboard a modal
_ai_module.set_keyboard_callback(lambda heading, hidden: _keyboard_input(heading, hidden=hidden))
_ai_module.set_modal_callback(lambda msg, heading="RichMovie A.I.", block=True: _modal(msg, heading=heading, block=block))











# `_spin_tokens` (obálka nad `richmovie_engine.spin_tokens`) ODSTRANĚNA (Φ-B, 30.09.2026): jediným
# volajícím je SSOT `richmovie_episode_search.build_context`, který volá engine přímo.







# --------------------------------------------------------------------------- #
#  NEXT‑UP  – RAM cache přednačtených dílů + tiché vyhledání
# --------------------------------------------------------------------------- #

# (tv_id, season, episode) → List[Release]   (připravené releasy)
NEXT_CACHE: dict[Tuple[str, int, int], List['Release']] = {}
NEXT_CACHE_LOCK = threading.Lock()




# Výsledek posledního hledání dílu v tomto procesu (klíč `tv_id:řada:díl` → info kaskády). Služba podle
# něj pozná, jestli je „nic nenalezeno“ autoritativní (Φ-C C4).
LAST_EPISODE_SEARCH_INFO: Dict[str, Dict[str, Any]] = {}
LAST_EPISODE_SEARCH_INFO_MAX = 64     # služba žije dny — slovník nesmí růst bez omezení


def _remember_episode_search(key: str, info: Dict[str, Any]) -> None:
    """Výsledek posledního hledání dílu pro předstažení (chyby, vlny, zrušení). Nejstarší záznamy vypadnou."""
    LAST_EPISODE_SEARCH_INFO.pop(key, None)
    LAST_EPISODE_SEARCH_INFO[key] = dict(info)
    while len(LAST_EPISODE_SEARCH_INFO) > LAST_EPISODE_SEARCH_INFO_MAX:
        LAST_EPISODE_SEARCH_INFO.pop(next(iter(LAST_EPISODE_SEARCH_INFO)), None)


def _search_episode(
    tv_id: str,
    tv_name: str,
    season_no: int,
    ep_no: int,
    ep_title: str = "",
    on_wave_end: Optional[Callable[[], Any]] = None,
    should_cancel: Optional[Callable[[], bool]] = None,
    scope_ctx: str = "prefetch",
) -> List['Release']:
    """Předstažení streamů dílu (služba). Φ-A (30.09.2026): obal = rozsah hledání (log po dávkách +
    měření `SEARCH_PHASES ctx=prefetch`); tělo v `_search_episode_run`. `on_wave_end` volá služba po každé
    vlně (prodloužení claimu „díl se hledá“)."""
    with _search_scope("tv", _rm_epsearch.search_key(tv_id, season_no, ep_no), scope_ctx) as _run:
        rels = _search_episode_run(tv_id, tv_name, season_no, ep_no, ep_title, on_wave_end, should_cancel)
        _run.n_list = len(rels or [])
        if _run.searched and not _run.outcome:
            _run.outcome = "prefetch" if rels else "prefetch_empty"
        return rels


def _search_episode_run(
    tv_id: str,
    tv_name: str,
    season_no: int,
    ep_no: int,
    ep_title: str = "",
    on_wave_end: Optional[Callable[[], Any]] = None,
    should_cancel: Optional[Callable[[], bool]] = None,
) -> List['Release']:
    """Předstažení streamů dílu = TOTÉŽ hledání jako ruční výpis (`_tv_play_run`).

    Φ-B (30.09.2026, E1-F01 / E3-F03): kontext filtru i kaskádu vln staví SSOT `richmovie_episode_search`
    — dřív tu žila druhá kopie, která se s výpisem rozešla (bez variant názvu seriálu, slov názvu dílu,
    roku premiéry seriálu a zákazu jiného dílu), takže autoplay vybíral z jiné množiny, než divák vidí.
    Rozdíly proti výpisu jsou jen dva a jsou záměrné: budoucí premiéra = tichý skip (služba nemá koho se
    ptát) a bez dialogu průběhu."""
    base = _rm_epsearch.load_base(str(tv_id or ""), tv_name, season_no, ep_no, ep_title,
                                  richmovie_settings.get_tmdb_api_key())
    _ep_key = _rm_epsearch.episode_key(tv_id, season_no, ep_no)
    air = _rm_epsearch.air_date(base)
    if air and air > datetime.date.today():
        _log_event("PREFETCH_SKIP_FUTURE", tv_name, season_no, ep_no, air.isoformat())
        _remember_episode_search(_ep_key, {"skipped": "future", "waves": [], "errors": 0, "cancelled": False})
        return []

    def _after_wave() -> None:
        _SEARCH_LOG.flush()
        if on_wave_end is not None:
            on_wave_end()

    ctx = _rm_epsearch.build_context(base, log_event=_log_event)
    _log_event("SEARCH_BEGIN", tv_name, season_no, ep_no, "prefetch")
    rels, _info = _rm_epsearch.run_cascade(
        _ENGINE, ctx, ctx_name="search_episode", log_event=_log_event,
        progress=_rm_moviesearch.CancelOnly(should_cancel) if should_cancel is not None else None,
        top_full_probe=15, on_wave_end=_after_wave, kick_mi2=should_cancel is None,
    )
    _info["sid"] = str(getattr(_rm_stel.current(), "sid", "") or "")
    _remember_episode_search(_ep_key, _info)
    _run = _rm_stel.current()
    if _run is not None and int(_info.get("errors") or 0):
        _run.errors = max(int(_run.errors), int(_info["errors"]))
    return rels






# --------------------------------------------------------------------------- #
# 2025‑07‑20 14:11 CEST  _log_event()  – bez závislosti na zoneinfo
#               (plugin.py – nahraďte stávající implementaci 1 : 1)
# --------------------------------------------------------------------------- #
_CTX = threading.local()              # thread‑safe úschovna aktuálního query




# 2025-08-09 18:15 CEST  _log_event() – EXTREME TRACE log (NDJSON) + zachování původních TXT logů
def _src_down_text(*, with_results: bool) -> str:
    """S31 (08.11.2026): věta o výpadku Webshare pro TOTO hledání ("" = nic neříkat), nejvýš jednou za hledání.
    Rozhoduje JEDINÁ funkce `richmovie_search_telemetry.source_down_code` (přes `SearchRun.source_down`)."""
    run = _rm_stel.current()
    if run is None:
        return ""
    code = run.source_down(have_results=with_results)
    if not code or not run.claim_src_down_notice():
        return ""
    import richmovie_feedback as _fb
    _log_event("SOURCE_DOWN_NOTICE", "ws", code)
    return _fb.SOURCE_DOWN_TEXTS[code]


def _src_down_notice(*, with_results: bool) -> bool:
    """Věta o výpadku Webshare jako toast (`_src_down_text`); vrací, jestli zazněla."""
    text = _src_down_text(with_results=with_results)
    if text:
        import richmovie_feedback as _fb
        _fb.warn(text, heading="Hledání")
    return bool(text)


def _no_release_ui(text: str = "") -> None:
    """Prázdný výsledek hledání streamů: výpadek Webshare = pravdivý toast (S31), jinak dnešní dialog. `text` = věta
    už rozhodnutá volajícím (výběr streamu ji dostal do prázdného stavu, divák bez okna výběru ji dostane toastem)."""
    if text:
        import richmovie_feedback as _fb
        _fb.warn(text, heading="Hledání")
        return
    if not _src_down_notice(with_results=False):
        _modal("Nenalezen žádný vyhovující release.")


def _log_event(event: str, *params: object) -> None:
    """
    Zápis do rotačního TXT logu **richmovie.log** a případně i do **NDJSON trace** souboru
    (1 řádek = 1 JSON objekt) pro snadnou následnou analýzu.

    • 100 % zachováno původní chování (TXT logy, rotace, thread‑local query).
    • Přidáno: volitelný NDJSON výstup s detailními poli.
    • U `FILTER_REJECT quick` doplníme i **velikost souboru (z detailu události, bez dotazu na síť), příponu,
      odhad kvality a minimální velikost**, které vedly k odmítnutí.

    Nastavení (v settings.xml):
      - trace_enabled           (zapíná/vypíná extrémní logování)
      - trace_ndjson            (ukládá i NDJSON trace soubor)
      - trace_log_successes     (zapisovat do NDJSON i úspěšné položky)
    """
    # --- 0) Nastavení (čteno runtime, aby šlo přepnout bez restartu) ----------
    # Φ-A: uvnitř rozsahu hledání se přepínače čtou JEDNOU (dřív 3× `os.stat` na každý řádek logu).
    _flags = _TRACE_FLAGS_CACHE.get("flags") if _SEARCH_LOG.buffering else None
    if _flags is None:
        _flags = _read_trace_flags()
    trace_enabled, trace_ndjson, trace_log_successes = _flags

    # Φ-A: měření hledání POSLOUCHÁ tytéž události (parametry v původním tvaru) — žádné další logování
    _rm_stel.observe(event, params)

    # --- 1) Doplň thread‑local query do vybraných událostí --------------------
    # Původní funkce: při RAW_SEARCH uložíme query do _CTX; u dalších eventů je doplníme.
    # Φ-A: `FILTER_SCOPE` = filtr nad sjednocením dotazů vlny (běží ve vlákně volajícího) — řádky
    # FILTER_* nesou označení vlny na místě, kde dřív nesly dotaz (formát pro replay zůstává).
    if event in ("RAW_SEARCH", "FILTER_SCOPE") and params:
        _CTX.query = str(params[0])
    elif event in {"WS_RESULTS", "FILTER_ACCEPT", "FILTER_REJECT"}:
        query = getattr(_CTX, "query", "")
        if query:
            params = (query, *params)

    # --- 2) TXT log: čas události (s milisekundami) + zápis přes SSOT zapisovač ----
    _now = datetime.datetime.now().astimezone()
    ts_txt = _now.strftime("%Y-%m-%d %H:%M:%S") + ".%03d" % (_now.microsecond // 1000)
    _path = _SEARCH_LOG_PATH or _LOG_PATH
    _log_event_row(_path, event, *params, ts=ts_txt)
    if event == "SEARCH_BEGIN":
        _run_sb = _rm_stel.current()
        if _run_sb is not None:
            _run_sb.log_path = _path          # `SEARCH_PHASES` patří do téhož souboru (píše se po SEARCH_END)
            _log_event_row(_path, "SEARCH_SID", _run_sb.sid, _run_sb.kind, _run_sb.key, _run_sb.ctx)

    # --- 3) NDJSON decision‑trace (volitelné) ---------------------------------
    if not (trace_enabled and trace_ndjson):
        return

    # a) Kde bude NDJSON? → stejné jméno jako *_SEARCH_LOG_PATH*, ale složka "traces/" a přípona .ndjson
    try:
        base = _SEARCH_LOG_PATH or _LOG_PATH
        base_dir = os.path.dirname(base)
        trace_dir_root = os.path.dirname(base_dir) if base_dir.endswith("richmovie") else base_dir
        trace_dir = os.path.join(trace_dir_root, "traces")
        if not xbmcvfs.exists(trace_dir):
            xbmcvfs.mkdirs(trace_dir)
        fname = os.path.basename(base)
        if fname.endswith(".log"):
            fname = fname[:-4] + ".ndjson"
        else:
            fname = fname + ".ndjson"
        ndjson_path = os.path.join(trace_dir, fname)
    except Exception:
        # Konzervativně – když se nepovede složka, skončíme jen s TXT logem
        return

    # b) Základní objekt
    ts_iso = datetime.datetime.now().astimezone().isoformat()
    search_id = os.path.splitext(os.path.basename(_SEARCH_LOG_PATH))[0] if _SEARCH_LOG_PATH else ""
    # Rozbalíme parametry – robustně (bez fixních indexů)
    query = getattr(_CTX, "query", "")
    ident = ""
    reason = ""
    name = ""

    details_dict = None
    for p in params:
        if isinstance(p, dict):
            details_dict = p
        elif isinstance(p, str):
            # heuristika: první alfanumerické bez mezer s délkou >= 8 bereme jako ident
            if not ident and p and p.isalnum() and len(p) >= 8:
                ident = p
            # reason kód: krátké slovo s podtržítkem / alfanum (např. token_ser_miss_1/2, quick, other_part, …)
            if not reason and ("_" in p or p.isalpha()) and len(p) <= 32 and p.lower() == p:
                reason = p
            # name: nejdelší text s tečkami/mezerami
            if len(p) > len(name):
                name = p

    obj = {
        "ts": ts_iso,
        "search_id": search_id or None,
        "event": event,
        "query": query or None,
        "ident": ident or None,
        "reason": reason or None,
        "name": name or None,
    }
    if isinstance(details_dict, dict):
        # převeďme na JSON‑serializovatelné hodnoty
        try:
            json.dumps(details_dict)  # test
            # pole záznamu (čas, událost, hledání…) detail NEPŘEPISUJE — stejnojmenný klíč jde pod `detail_<klíč>`
            for _dk, _dv in details_dict.items():
                obj[("detail_%s" % _dk) if _dk in obj else _dk] = _dv
        except Exception:
            # best‑effort: převedeme na str
            obj["details_raw"] = str(details_dict)

    # d) Obohacení pro vybrané kódy (quick) – doplníme velikost/příponu/limity
    #    Pozn.: je to *jen pro logování*; logika vyhledávání se nezmění.
    try:
        if event == "FILTER_REJECT" and ("quick" in (reason or "") or reason == "") and ident:
            # Φ-E (30.09.2026, cross-check Pro C1-P2): log NESMÍ volat síť — dřív tu byl dotaz `file_info`
            # na KAŽDÝ zamítnutý soubor (stovky požadavků na Webshare za hledání se zapnutým trace).
            # Velikost nese detail události, když ji engine zná.
            size_mb = None
            ws_name = name
            try:
                _sz = (details_dict or {}).get("size")
                if _sz:
                    size_mb = float(_sz) / 1_048_576
            except (TypeError, ValueError):
                size_mb = None

            # Odvodíme příponu/kvalitu/min. velikost (stejně jako engine)
            nm = (ws_name or name or "")
            ext = os.path.splitext(nm)[1].lower()
            is_episode = bool(re.search(r"(?:s\d{1,2}e\d{1,2}|\d{1,2}[xX]\d{2})", nm, re.I))
            # hrubý odhad kvality
            nml = nm.lower()
            if "2160p" in nml or "4k" in nml:
                q = "2160p"
            elif "1080p" in nml or "fullhd" in nml:
                q = "1080p"
            elif "720p" in nml or "hd" in nml:
                q = "720p"
            elif "webrip" in nml or "web-dl" in nml or "webdl" in nml:
                q = "webrip"
            elif "cam" in nml:
                q = "cam"
            else:
                q = "other"

            min_map = {"2160p": 2000, "1080p": 700, "720p": 350, "webrip": 300, "other": 250, "cam": 0}
            min_size_mb = 50 if is_episode else min_map.get(q, 250)
            video_ext_ok = ext.lower() in {".mkv", ".mp4", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".webm", ".m4v"}

            obj.setdefault("debug", {}).update({
                "quick": True,
                "ext": ext or None,
                "size_mb": round(size_mb, 1) if isinstance(size_mb, (int, float)) else None,
                "min_size_mb": min_size_mb,
                "quality_guess": q,
                "is_episode": is_episode,
                "video_ext_ok": video_ext_ok,
            })
    except Exception:
        pass

    # e) Pokud je to ACCEPT a uživatel nechce logovat úspěchy, přeskočíme
    if event == "FILTER_ACCEPT" and not trace_log_successes:
        return

    # f) Zápis do NDJSON
    # Φ-E: přes SSOT zapisovač (dávka, opakování nezapsaných řádků, hlášení chyby) — dřív vlastní `open`
    # a chyba zápisu beze stopy
    try:
        _SEARCH_LOG.write(ndjson_path, json.dumps(obj, ensure_ascii=False))
    except Exception as _nd_exc:
        _log(f"trace ndjson row failed: {_nd_exc!r}", xbmc.LOGWARNING)










def _log_search_summary(rels: List[Release], title: str = "") -> None:
    """
    2025-10-12 07:42 CEST (Europe/Prague)
    Vygeneruje a zapíše do per‑search logu přehlednou ASCII tabulku s tím, co
    šlo do GUI, a vedle toho souhrn metadat z Webshare API + heuristiky názvu.
    Současně (pokud je povoleno NDJSON) zapíše i strojově čitelný přehled.

    • Bez dalších API volání (použije data v objektu Release).
    • Žádná změna GUI – čistě diagnostika do logu.
    """
    try:
        # — interní utilitky (bez externích importů) —
        def _clip(s: str, width: int) -> str:
            s = (s or "").replace("\r", " ").replace("\n", " ")
            return s if len(s) <= width else (s[:max(0, width - 1)] + "…")

        def _split_two(s: str) -> tuple[str, str]:
            parts = (s or "").splitlines()
            return (parts[0] if parts else "", parts[1] if len(parts) > 1 else "")

        def _fmt_dur(sec: int | None) -> str:
            try:
                v = int(sec or 0)
            except Exception:
                v = 0
            if v <= 0:
                return "–"
            h, m, s = v // 3600, (v % 3600) // 60, v % 60
            return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

        # — sloupce a hlavičky tabulky —
        n      = len(rels)
        col1w  = 54   # GUI (1. řádek + pravý sloupek GUI)
        col2w  = 32   # WS (W×H, LEN, VOTES) – širší, nezkracuje na "…"
        col3w  = 34   # NAME heuristika (qual, AUD, SUB)
        head   = f"──────────────── SEARCH SUMMARY (GUI → {n} položek) ─────────────────"
        hdr    = f"#  {'GUI (co vidíš v seznamu)':<{col1w}} | {'WS (z API)':<{col2w}} | {'NAME heuristika':<{col3w}}"
        sep    = f"── {'─'*col1w} ┼ {'─'*col2w} ┼ {'─'*col3w}"

        lines: list[str] = [head, hdr, sep]
        items_json: list[dict] = []
        # Klíč v logu (`sort_key`) je bez preference diváka a kontinuity; vadný soubor a nepřehratelný
        # Webshare (řadí se pod ostatní) nese každá položka zvlášť (audit Fable F2-V9).
        _so_broken, _so_blocked = _broken_sources(), _ws_playback_blocked()

        for idx, r in enumerate(rels, 1):
            lab     = LabelFormatter.format(r)
            left    = lab.get("label_left", "")
            right   = (lab.get("label_right") or "").strip()
            l1, l2  = _split_two(left)
            gui_l1  = f"{l1}  {right}" if right else l1

            ws_w    = getattr(r, "ws_width",  None)
            ws_h    = getattr(r, "ws_height", None)
            ws_len  = getattr(r, "ws_len_s",  None)
            ws_pos  = getattr(r, "ws_pos",    None)
            ws_neg  = getattr(r, "ws_neg",    None)

            wh      = f"{ws_w}×{ws_h}" if (ws_w and ws_h) else "–"
            dur     = _fmt_dur(ws_len)
            votes   = (f"+{ws_pos}/{ws_neg}" if (ws_pos is not None or ws_neg is not None) else "–/–")
            ws_col  = f"{wh:<11}  {dur:<8}  {votes:<7}"

            aud_txt = ",".join([a.upper() for a in r.audios]) or "–"
            sub_txt = ",".join([s.upper() for s in r.subs]) or "–"
            namecol = f"qual={r.quality}  AUD={aud_txt}  SUB={sub_txt}"

            lines.append(f"{idx:02d} {_clip(gui_l1, col1w):<{col1w}} | {_clip(ws_col, col2w):<{col2w}} | {_clip(namecol, col3w):<{col3w}}")
            if l2:
                # "druhý řádek" GUI (název release) pod sebe s odsazením
                lines.append(f"   {_clip(l2, col1w):<{col1w}} | {'':<{col2w}} | {'':<{col3w}}")

            # --- Rank factory pro ladění řazení -------------------------- #
            # Zachycujeme ALL pole která jdou do sort key (_list_releases
            # řádek 7256 + _tv_play řádek 9991). Richie může analyzovat
            # proč je release na dané pozici.
            match_flag = bool(getattr(r, "match", False))
            mismatch_flag = bool(getattr(r, "runtime_mismatch", False))
            title_penalty = int(getattr(r, "title_penalty", 0) or 0)
            score = _score_text(getattr(r, "score", None))
            est_min = getattr(r, "est_min", None)
            src = str(getattr(r, "source", "") or "")
            size_bytes = int(getattr(r, "size", 0) or 0)
            size_mb = round(size_bytes / 1_048_576) if size_bytes else 0

            # MI2 hints (best-effort — disk cache read)
            mi2_fl: dict = {}
            try:
                eng_mod = sys.modules.get("richmovie_engine")
                if eng_mod and callable(getattr(eng_mod, "mi2_get_flags", None)):
                    mi2_fl = eng_mod.mi2_get_flags(r.ident) or {}
            except Exception:
                mi2_fl = {}

            # Φ-D (30.09.2026): kvalita a český dabing tak, jak je vidí SSOT řazení (`richmovie_quality`).
            # Klíč v logu je bez preference diváka a kontinuity (ty zná jen volající výpisu).
            _q_rank, _q_label = _rm_quality.quality_of(r, mi2_fl)
            sort_key = list(_rm_quality.stream_sort_key(
                r, mi2_fl, (0, 0), 0, _score_sort_key(getattr(r, "score", None)))[:-1])

            items_json.append({
                "broken": bool(_so_broken and r.ident in _so_broken),
                "ws_blocked": bool(_so_blocked and src == "webshare"),
                "idx": idx,                     # 1-based jako v tabulce
                "ident": r.ident,
                "source": src,
                "name": r.name,
                "gui_left": left,
                "gui_right": right,
                "size_mb": size_mb,
                "size_bytes": size_bytes,
                "ws": {
                    "width": ws_w, "height": ws_h, "length_s": ws_len,
                    "pos": ws_pos, "neg": ws_neg,
                },
                "name_heur": {
                    "quality": r.quality,
                    "audios": list(r.audios or []),
                    "subs": list(r.subs or []),
                    "est_min": est_min,
                },
                "mi2": {
                    "video_h": mi2_fl.get("video_h"),
                    "video_w": mi2_fl.get("video_w"),
                    "duration_s": mi2_fl.get("duration_s"),
                    "aud": mi2_fl.get("aud"),
                    "sub": mi2_fl.get("sub"),
                    "cz_dub": mi2_fl.get("cz_dub"),
                    "cz_sub": mi2_fl.get("cz_sub"),
                    "sub_present": mi2_fl.get("sub_present"),
                    "fail": mi2_fl.get("fail"),
                } if mi2_fl else None,
                "rank": {
                    "match": match_flag,
                    "runtime_mismatch": mismatch_flag,
                    "title_penalty": title_penalty,
                    "score": score,
                    "quality_rank": _q_rank,
                    "quality_label": _q_label,
                    "cz_rank": _rm_quality.cz_rank(mi2_fl, r.audios),
                    "sort_key": sort_key,
                },
            })

        table = "\n".join(lines)

        # — TEXT log (vždy) —
        _log_event("SEARCH_SUMMARY", "\n" + table)

        # — STREAM_ORDER_FINAL — Kompaktní jednořádkový log per release
        # (grep-able, bez nutnosti NDJSON). Loguje se VŽDY, bez ohledu
        # na trace_enabled — Richie potřebuje vidět řazení při každém ladění.
        try:
            for it in items_json:
                rk = it.get("rank") or {}
                mi = it.get("mi2") or {}
                _log_event(
                    "STREAM_ORDER",
                    f"#{it['idx']:02d}",
                    f"src={it.get('source') or '-'}",
                    f"q={it['name_heur']['quality']}",
                    f"size={it['size_mb']}MB",
                    f"match={'Y' if rk.get('match') else 'N'}",
                    f"mismatch={'Y' if rk.get('runtime_mismatch') else 'N'}",
                    f"pen={rk.get('title_penalty')}",
                    f"score={rk.get('score')}",
                    f"qrank={rk.get('quality_rank')}",
                    f"sort_key={rk.get('sort_key')}",
                    f"aud={','.join(it['name_heur']['audios']) or '-'}",
                    f"sub={','.join(it['name_heur']['subs']) or '-'}",
                    f"mi2_h={mi.get('video_h') or '-'}",
                    f"mi2_dur_s={mi.get('duration_s') or '-'}",
                    f"ws_h={it['ws'].get('height') or '-'}",
                    f"ws_len_s={it['ws'].get('length_s') or '-'}",
                    f"ident={it['ident']}",
                    f"name={it['name'][:80]}",
                )
        except Exception:
            pass

        # — NDJSON plné (jen pokud je povoleno v Settings) —
        try:
            _log_event("SEARCH_SUMMARY_JSON", {"title": title, "items": items_json})
        except Exception:
            pass

    except Exception:
        # Souhrn logu nikdy nesmí zablokovat běh doplňku
        pass







@_rm_bc.timed_step("ws_enrich", fields=lambda rels: {"items": len(rels or [])})
def _ws_fileinfo_enrich(rels: List[Release]) -> None:
    """
    2025-10-12 08:54 CEST (Europe/Prague)
    Dotáhne z Webshare `/api/file_info` *pro všechny releasy, které jdou do GUI*
    a doplní jejich `ws_*` pole (šířka, výška, délka v sekundách, hlasy +/−),
    aby je bylo možné elegantně zobrazit v SEARCH SUMMARY tabulce.
    • Bez změny GUI.
    • Bez dalších závislostí; využívá existující login/session (_client()).
    • Odolné vůči chybám – selhání u jedné položky neblokuje ostatní.
    Φ0 (29.09.2026): doba se měří do TRACE (`step=ws_enrich`) — sekvenční POST na každý stream.
    Φ5A (29.09.2026, audit A06 R04): volá se až PO vykreslení (`_after_render_enrich`, jen první obrazovka)
    a MĚŘÍ, kolik polí `/file_info` oproti `/search` opravdu změnil (`WS_ENRICH_EFFECT` do user_logs).
    Když bude po týdnu ≈ 0, enrich se zruší úplně (hypotéza A06: `/search` vrací tatáž pole).
    """
    if not rels:
        return
    _fields = ("ws_width", "ws_height", "ws_len_s", "ws_pos", "ws_neg")
    _changed_by_field = {f: 0 for f in _fields}
    _probed = 0
    _items_changed = 0

    cli = _client()
    # Pokus o tichý refresh přihlášení (nezdržovat GUI)
    try:
        _ensure_login(cli, interactive=False)
    except Exception as exc:
        _log(f"ensure_login (non-interactive) failed: {exc}", xbmc.LOGDEBUG)

    for r in rels:
        # 20.02.2026 – Fastshare identy přeskočit (Webshare API je nezná → FILE_INFO_FATAL_1)
        if str(getattr(r, "ident", "") or "").startswith("fs:"):
            continue
        try:
            info = cli.file_info(r.ident)
        except TokenExpired:
            # Jednorázový interaktivní retry (token expiroval)
            try:
                _ensure_login(cli, interactive=True)
                info = cli.file_info(r.ident)
            except Exception as exc:
                _log_event("FILE_INFO_ENRICH_FAIL", r.ident, str(exc))
                continue
        except Exception as exc:
            _log_event("FILE_INFO_ENRICH_FAIL", r.ident, str(exc))
            continue

        # Bezpečný převod na int/None
        def _i(x):
            try:
                v = int(x or 0)
                return v or None
            except Exception:
                return None

        _before = {f: getattr(r, f, None) for f in _fields}
        try:
            # Doplň JEN známé hodnoty. Noc 03.11.2026 (analýza Φ-F S5, `Handoff/ANALYZA_phi_f_search_20261103.md`):
            # `/file_info` hlasy nevrací → `_i(0)` = None přepsalo hlasy z `/search` a souhrn hledání ukazoval „–/–“
            # (log ztrácel detail — pravidlo Richieho 29.09.2026). „Nevím“ nesmí přepsat známé.
            for _attr, _key in (("ws_width", "video_width"), ("ws_height", "video_height"),
                                ("ws_len_s", "video_length"), ("ws_pos", "positive_votes"),
                                ("ws_neg", "negative_votes")):
                _val = _i(info.get(_key))
                if _val is not None:
                    setattr(r, _attr, _val)
        except Exception as exc:
            # Logovací summary si s None poradí; nechceme shodit běh
            _log_event("FILE_INFO_ENRICH_SET_FAIL", r.ident, str(exc))
            continue
        _probed += 1
        _diff = [f for f in _fields if getattr(r, f, None) != _before[f]]
        if _diff:
            _items_changed += 1
            for f in _diff:
                _changed_by_field[f] += 1

    # Φ5A: měření přínosu (bez identů a tokenů) — podklad pro rozhodnutí enrich zrušit
    _log("WS_ENRICH_EFFECT items=%d changed_items=%d fields=%s"
         % (_probed, _items_changed, ",".join("%s:%d" % (f, n) for f, n in _changed_by_field.items() if n) or "-"),
         xbmc.LOGINFO)








# 2025‑07‑27 23:59 CEST  – kompatibilní wrapper pro starší workflow
def _start_search_log(title: str, year: int | str = "") -> None:
    """
    START per‑search logu (starý alias).
    Vytvoří unikátní *.log soubor ↔ `_SEARCH_LOG_PATH`
    a zapíše úvodní řádek SEARCH_BEGIN.

    Args:
        title: Název hledaného díla.
        year:  Rok premiéry (může být prázdný).
    """
    global _SEARCH_LOG_PATH

    # 1) Adresář pro dočasné logy
    log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
    if not xbmcvfs.exists(log_dir):
        xbmcvfs.mkdirs(log_dir)

    # 2) Bezpečný název souboru
    ts   = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    safe = re.sub(r"[^0-9A-Za-z]+", "_", f"{title}_{year}")[:50]
    _SEARCH_LOG_PATH = os.path.join(log_dir, f"{ts}_{safe}.log")

    # 3) Úvodní záznam
    _log_event("SEARCH_BEGIN", title, year)






# 2025‑07‑27 23:59 CEST  – kompatibilní wrapper pro starší workflow
def _end_search_log(title: str, result: object) -> None:
    """
    END per‑search logu (starý alias).
    Zapíše výsledkový řádek SEARCH_END a uvolní `_SEARCH_LOG_PATH`.

    Args:
        title:  Titulek hledání (kvůli konzistenci s BEGIN).
        result: Počet nalezených releasů nebo řetězec `'ERR'`.
    """
    _log_event("SEARCH_END", title, result)

    # Reset, aby další hledání začínalo s čistou cestou
    global _SEARCH_LOG_PATH
    _SEARCH_LOG_PATH = ""







# --------------------------------------------------------------------------- #
#  MALÉ GUI POMOCNÍCI
# --------------------------------------------------------------------------- #

def _format_int_spaced(n: int) -> str:
    """Formátuje číslo s mezerami pro tisíce – delegováno do helpers"""
    return _format_int_spaced_impl(n)




def _format_mediainfo(mi: dict) -> str:
    """Převod MediaInfo slovníku na čitelný text – delegováno do helpers"""
    return _format_mediainfo_impl(mi)





def _keyboard_input(heading: str, hidden: bool = False) -> str | None:
    """Zobrazí Kodi klávesnici – delegováno do helpers"""
    return _keyboard_input_impl(heading, hidden)





def _modal(msg: str, heading: str = "RichMovie", block: bool = True) -> None:
    """Zobrazí modální dialog nebo toast – delegováno do helpers"""
    _modal_impl(msg, heading, block)






# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _notif  (refaktor: 24.01.2026 19:45 CET – delegováno do richmovie_helpers)
# ---------------------------------------------------------------------------- #
def _notif(msg: str, icon: int = xbmcgui.NOTIFICATION_INFO, ms: Optional[int] = None,
           heading: str = "RichMovie") -> None:
    """Jednotný helper pro toast notifikace – delegováno do helpers (Φ2: délka bez `ms` podle textu)"""
    _notif_impl(msg, icon, ms, heading)




# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _http_get_json  (vytvořeno: 08.08.2026 14:05 CEST, Europe/Prague – Φ3b)
# ---------------------------------------------------------------------------- #
def _http_get_json(url: str, *, timeout: float = 10.0,
                   headers: dict | None = None, tag: str = "plugin") -> dict:
    """GET + JSON přes SSOT retry vrstvu (`richmovie_http`).

    PROČ VZNIKL: tenhle blok byl v `plugin.py` zkopírovaný **devětkrát** —
    pokaždé `Request(...)` + `urlopen(req, timeout=10)` + `json.loads(read())`,
    pokaždé bez retry. Devět kopií = devět míst, kde se dá zapomenout na opravu
    (DRY je v Rich* projektech povinné). Zároveň jde o cesty na Gate, které při
    výpadku sítě selhávaly na první pokus stejně jako TMDb.

    User-Agent je povinný — bez něj Cloudflare Bot Fight Mode blokuje
    `Python-urllib` s HTTP 403 (error 1010, bugfix 2026-04-19).

    Args:
        url:     Absolutní URL.
        timeout: Timeout jednoho pokusu (zachovává původní hodnoty call-sites).
        headers: Doplňkové hlavičky; User-Agent se doplní, pokud chybí.
        tag:     Štítek do logu retry vrstvy.

    Returns:
        Rozparsovaný JSON jako dict (prázdné tělo → prázdný dict).

    Raises:
        Cokoli z `richmovie_http` (TransientError / PermanentError / OfflineError)
        nebo `ValueError` při nevalidním JSON — volající to řeší svým `except`.
    """
    import richmovie_http as _rm_http

    hdrs = dict(headers or {})
    hdrs.setdefault(
        "User-Agent",
        "RichMovie/%s (+plugin.video.richmovie)" % (ADDON.getAddonInfo("version") or "dev"),
    )
    hdrs.setdefault("Accept", "application/json")

    profile = _rm_http.profile_foreground().replace(timeout_s=float(timeout))
    status, raw, _hdrs = _rm_http.request(url, headers=hdrs, profile=profile, tag=tag)
    if status != 200:
        raise RuntimeError("HTTP %s" % status)
    text = raw.decode("utf-8") if raw else ""
    return json.loads(text) if text else {}




# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _net_error_ui  (vytvořeno: 08.08.2026 13:15 CEST, Europe/Prague – Φ5)
# ---------------------------------------------------------------------------- #
def _net_error_ui(exc: BaseException, *, heading: str = "RichMovie") -> bool:
    """Zobrazí síťovou chybu tak, jak si zaslouží — a vrátí, jestli byla přechodná.

    PROČ TO NENÍ JEN `_modal(str(exc))`:
    do 08.08.2026 skončila každá chyba jako blokující dialog s doslovným výpisem
    z urllib (`<urlopen error [Errno 101] Network is unreachable>`). Uživatel
    musel kliknout OK, aby mohl pokračovat, a z hlášky se nedozvěděl nic. Přitom
    drtivá většina těch chyb je přechodná a stačí je zmínit a jet dál.

    Nové chování:
        • přechodná chyba (výpadek sítě, timeout, 5xx) → **nenápadná notifikace**,
          žádné blokování; addon mezitím často stihne nabídnout data z cache (Φ4),
        • trvalá chyba (chybí oprávnění, neexistující položka) → modální dialog,
          protože ta si pozornost opravdu zaslouží.

    Technický detail se do UI nedostane NIKDY — od Φ0 je i s errnem a časováním
    v `user_logs` na NASu, což je jediné místo, kde je k něčemu.

    Returns:
        True, když šlo o přechodnou chybu (volající může např. nechat obrazovku
        na uložených datech místo vyprázdnění).

    Φ2 (29.09.2026): rozhodnutí toast × dialog i log `UI_ERROR` žijí v SSOT `richmovie_feedback.error`
    (používají ho i moduly mimo plugin) — tady jen jméno, pod kterým to plugin volá na 40 místech.
    """
    return _rm_fb.error(exc, heading=heading)








# 2025‑07‑23 10:45 CEST  – NOVÁ
# _ensure_stream_resolver() smazana 2026-04-27 — dead code (nikdy nevolana).
# stream.resolver je GPL licensed, nelze vendorovat do MIT addonu.
# Pripadny budouci resolver bude vlastni implementace (viz Handoff zero_external_deps).







# Toast „MediaInfo knihovna načtena“ ODSTRANĚN (Φ3, 29.09.2026): od thin-clientu (3.2) probe běží na Gate
# a `MEDIAINFO_AVAILABLE` je vždy True, takže zpráva nic nesdělovala — a před ní stálo
# `xbmc.sleep(4500)` přímo v cestě hlavního menu (audit A07 R3).






def _progress(total: int) -> xbmcgui.DialogProgress:
    """Vytvoří progress dialog pro vyhledávání – delegováno do helpers"""
    return _progress_impl(total)


# --------------------------------------------------------------------------- #
# ═══════════════════════════════════════════════════════════════════════════════
#  HISTORIE VYHLEDÁVÁNÍ – DELEGACE NA richmovie_history (Fáze 2 refaktoringu)
# ═══════════════════════════════════════════════════════════════════════════════
# Původní CRUD implementace přesunuta do richmovie_history.py (543 řádků)
# UI funkce (_show_history, _watch_history_*) zůstávají zde

# Konstanty (zachovány pro zpětnou kompatibilitu v UI funkcích)
# 3.5.134: cesty osobních souborů drží richmovie_paths (profily) — konstanty
# _HIST_PATH/_WATCH_PATH (nepoužívané od 3.5.x) odstraněny.
_WATCH_MAX_ITEMS = _hist_module.WATCH_MAX_ITEMS
_WATCH_UI_MAX_MOVIES = _hist_module.WATCH_UI_MAX_MOVIES
_WATCH_UI_MAX_EPISODES = _hist_module.WATCH_UI_MAX_EPISODES


def _load_history() -> Dict[str, List[str]]:
    """Delegováno do richmovie_history"""
    return _hist_module.load_history()


def _save_history(hist: Dict[str, List[str]]) -> None:
    """Delegováno do richmovie_history"""
    _hist_module.save_history(hist)


def _history_clear() -> None:
    """Delegováno do richmovie_history"""
    _hist_module.history_clear()


def _add_to_history(term: str, category: str | None = None, *,
                    meta: dict | None = None) -> None:
    """Delegovano do richmovie_history (s podporou TMDb metadat)"""
    _hist_module.add_to_history(term, category, meta=meta)




# ═══════════════════════════════════════════════════════════════════════════════
#  CONTINUE WATCHING – obsluzna akce
# ═══════════════════════════════════════════════════════════════════════════════

def _rm_play_failed_return() -> None:
    """Φ2 (2026-07-06, audit A04/A06): selhání resolve/startu přehrávání z RM 4.0
    UI nechávalo uživatele v holém Kodi — dialog stack už je složený a origin
    descriptor visel → falešný reopen u příštího videa. Konzumuj descriptor HNED
    a reopni origin okna (chybový modal zůstává viditelný NAD nimi). Best-effort;
    v legacy režimu descriptor neexistuje → no-op."""
    try:
        import richmovie_ui_common as _uc_fail
        desc = _uc_fail.consume_return_route()
        if desc is None:
            return
        _uc_fail.replay_return_routes(desc)
    except Exception as _fr_e:
        _log(f"play_failed_return: {_fr_e}", xbmc.LOGWARNING)


# Φ5: strop dotazu na Gate v cestě přehrání (Flash J P1). Od Φ6 (29.09.2026) běží souběžně s resolve
# streamu (`_RemoteResumeLookup`) a stejný strop platí pro čekání na jeho výsledek.
REMOTE_RESUME_TIMEOUT_S = 1.5


def _remote_resume_lookup(item: dict, position: float) -> Optional[dict]:
    """Novější `watching` TÉHOŽ titulu z jiného zařízení (Gate), nebo None. Jen čtení: nic neaplikuje,
    kurzor neposouvá; offline / bez profilu / transport → None."""
    try:
        import richmovie_state_sync as _ss
        key = _ss.cw_key(item)
        if not key:
            return None
        # 1 stránka: postup z jiných zařízení je v posledních verzích (since = kurzor − překryv),
        # víc stránek by chytalo jen prehistorii
        with _rm_bc.step("gate_resume") as _st:
            remote = _ss.remote_resume_position(key, position, timeout=REMOTE_RESUME_TIMEOUT_S, max_pages=1)
            _st["hit"] = bool(remote)
        return dict(remote, _key=key) if remote else None
    except Exception as exc:
        _log(f"CW_RESUME_REMOTE failed: {exc!r}", xbmc.LOGDEBUG)
        return None


class _RemoteResumeLookup(object):
    """Φ6 (A05 R4/F3): `_remote_resume_lookup` ve vlákně spuštěném na vstupu `_play` — resolve streamu
    (Webshare API / Fastshare URL) a dotaz na Gate jdou naráz; dřív dotaz čekal za resolve a přidával
    0,17–0,35 s p50 (strop 1,5 s) ke KAŽDÉMU startu bez navázání. Výsledek se převezme těsně před
    `prepare_resolved_item`; pozdní odpověď se zahodí (start nečeká déle, než čekal dřív).
    Non-daemon (HTTP vlákno v Kodi — feedback_daemon_threads_kodi): skončí nejpozději s timeoutem dotazu."""

    def __init__(self, item: dict) -> None:
        self._item = item
        self._done = threading.Event()
        self._result: Optional[dict] = None
        self._thread = threading.Thread(target=self._run, name="RMRemoteResume", daemon=False)
        self._thread.start()

    def _run(self) -> None:
        try:
            self._result = _remote_resume_lookup(self._item, 0.0)
        finally:
            self._done.set()

    def result(self) -> Optional[dict]:
        if not self._done.wait(REMOTE_RESUME_TIMEOUT_S):
            _log("CW_RESUME_REMOTE: odpověď Gate nepřišla včas → start bez ní", xbmc.LOGINFO)
            return None
        return self._result


def _announce_remote_resume(remote: dict, position: float) -> float:
    """Převezme pozici z jiného zařízení: log + toast „Navazuji od … · zařízení“. Vrací pozici."""
    try:
        import richmovie_state_sync as _ss
        remote_pos = float(remote.get("position_s") or 0)
        key = remote.get("_key") or "?"
        label = _ss.safe_label(remote.get("updated_device_label")) or "jiné zařízení"
        _log(f"CW_RESUME_REMOTE key={key} local={position:.0f}s remote={remote_pos:.0f}s from={label!r}",
             xbmc.LOGINFO)
        import richmovie_resume as _rres_fmt   # SSOT formátu času v toastech navazování
        _rm_notif(f"Navazuji od {_rres_fmt.format_time(remote_pos)} \xb7 {label}", xbmcgui.NOTIFICATION_INFO, 3500, "RichMovie", sound=False)
        return remote_pos
    except Exception as exc:
        _log(f"CW_RESUME_REMOTE announce failed: {exc!r}", xbmc.LOGDEBUG)
        return position


def _resume_position_from_gate(item: dict, position: float) -> float:
    """Φ5 (13.09.2026): pozice pro navázání = max(lokální, novější `watching` jiného zařízení z Gate).
    Toast říká, odkud pozice je. Blokující varianta (Pokračovat — pozice je potřeba pro výběr)."""
    remote = _remote_resume_lookup(item, position)
    return _announce_remote_resume(remote, position) if remote else position


def _cw_url_params(item: dict, idx: int) -> dict:
    """Parametry odkazu na položku Pokračovat: KLÍČ (`cw_key`, 13.09.2026) + index jako fallback.
    Realtime sloučení z jiných zařízení mění pořadí souboru kdykoli mezi vykreslením a klikem —
    index by pak spustil / odebral jiný titul. Lokální NAS soubory bez TMDb id klíč nemají → index."""
    out = {"cw_index": str(idx)}
    try:
        import richmovie_state_sync as _ss
        key = _ss.cw_key(item)
        if key:
            out["cw_key"] = key
    except Exception:
        pass
    return out


def _cw_locate(items: list) -> int:
    """Index položky Pokračovat podle `cw_key` (přesně); `cw_index` jen bez klíče (položka bez TMDb, starý odkaz);
    -1 = nenalezeno."""
    key = (params.get("cw_key", [""])[0] or "").strip()
    if key:
        try:
            import richmovie_state_sync as _ss
            for i, it in enumerate(items):
                if _ss.cw_key(it) == key:
                    return i
        except Exception:
            pass
        # 4.0.3 (cross-check Codex C3): klíč nenalezen = položka mezitím zmizela nebo se pohled přeřadil — index by
        # ukázal na JINÝ titul (spustit / odebrat cizí); akce se neprovede
        _log(f"CW_KEY_MISS key={key} (položka mezitím zmizela) → akce se neprovede", xbmc.LOGINFO)
        return -1
    try:
        idx = int((params.get("cw_index", ["0"])[0]))
    except (ValueError, IndexError):
        return -1
    return idx if 0 <= idx < len(items) else -1


# Φ1 (29.09.2026): druhy cíle položky Pokračovat — SSOT pro seznam, přehratelnou akci i starou akci.
CW_KIND_PLAY = "play"      # známý stream → přehrát rovnou (položka IsPlayable, Kodi ukáže kolečko za 0,22 s)
CW_KIND_LOCAL = "local"    # soubor z NAS (smb://) → přehrát cestu
CW_KIND_PICK = "pick"      # bez streamu / čerstvý díl s preferencí zvuku → výběr streamu
#: Díl s pozicí pod touhle hranicí je „čerstvý“: uložený stream mohl být vybrán bez preference zvuku
#: (incident Kravaťáci 07.07.2026) → výběr podle preference. Pravidlo beze změny od 3.5.90, jen pojmenované.
CW_FRESH_EPISODE_S = 30


def _cw_kind(item: dict, position: float) -> str:
    """Kam vede položka Pokračovat (čisté rozhodnutí nad záznamem, bez sítě).
    4.0.3 (D3): díl po prokázaném spánku (`asleep_eps`) jde přes akci `continue_watching` (volba „od začátku /
    už ho mám za sebou“), nikdy rovnou přehráním."""
    if item.get("asleep_eps"):
        return CW_KIND_PICK
    if (item.get("source") or "") == "local" and (item.get("path") or "").strip():
        return CW_KIND_LOCAL
    if not (item.get("ident") or "").strip():
        return CW_KIND_PICK
    if item.get("type") == "episode" and float(position or 0) < CW_FRESH_EPISODE_S:
        try:
            _cw_pref = _lookup_title_pref(tv_id=item.get("tv_id"))
            if _cw_pref and (_cw_pref.get("audio_lang") or "").strip():
                _log_event("CW_RESELECT_PREF", str(item.get("tv_id") or ""), _cw_pref.get("audio_lang"))
                return CW_KIND_PICK
        except Exception:
            pass
    return CW_KIND_PLAY


def _cw_asleep_choice(item: dict) -> Optional[dict]:
    """D3 (4.0.3): díl, u kterého dotaz „Díváš se ještě?“ vypršel. Jedno klepnutí místo hledání po sezónách
    (incident 07.10.2026): „Pustit od začátku“ → tentýž záznam; „Už ho mám za sebou“ → díly s ⏾ = ✔ ručně,
    Pokračovat posunuto a vrací se záznam DALŠÍHO dílu; zrušení → None (nic)."""
    try:
        s_, e_ = int(item.get("season") or 0), int(item.get("episode") or 0)
        eps = sorted((int(a), int(b)) for a, b in (item.get("asleep_eps") or []))
    except (TypeError, ValueError):
        return item
    tv_id = item.get("tv_id")
    last = eps[-1] if eps else (s_, e_)
    nxt = None
    try:
        import richmovie_series_nav as _nav_a
        _k = richmovie_settings.get_tmdb_api_key()
        if _k:
            nxt = _nav_a.next_coords(TMDb(_k, lang="cs-CZ"), int(tv_id), last[0], last[1])
    except Exception as exc:
        _log(f"asleep choice: next coords failed {exc!r}", xbmc.LOGDEBUG)
    span = ("S%02dE%02d" % (s_, e_)) if len(eps) <= 1 else ("S%02dE%02d–E%02d" % (eps[0][0], eps[0][1], last[1]))
    # audit Fable A-V8: stejné okno jako dotaz „Díváš se ještě?“ (fotka, plakát, dvě velká tlačítka), ne systémový seznam
    import richmovie_still_watching as _sw_c
    import richmovie_ui_common as _uc_c
    choice = _sw_c.ask_choice(
        question="⏾  Běželo to bez tebe",
        series=item.get("tv_name") or "Seriál",
        detail="%s · %s" % (span, "díly, které běžely bez odpovědi na dotaz" if len(eps) > 1 else "díl, který běžel bez odpovědi na dotaz"),
        why="Na „Díváš se ještě?“ nikdo neodpověděl, tak jsem je nepočítal jako viděné.",
        promise=("Máš je za sebou? Pak pokračuj dílem S%02dE%02d." % nxt) if nxt else "Máš je za sebou? Pak máš seriál dokoukaný.",
        primary="▶  Od začátku S%02dE%02d" % (s_, e_),
        secondary="✔  Mám to za sebou",
        poster=_uc_c.img(item.get("poster_path"), "w500"),
        fanart=_uc_c.img(item.get("backdrop_path"), "w1280"))
    if choice == _sw_c.CHOICE_PRIMARY:
        return item
    if choice != _sw_c.CHOICE_SECONDARY:
        return None
    for a, b in eps or [(s_, e_)]:
        _hist_module.watched_mark_episode(tv_id=tv_id, season=a, episode=b, kind="manual")
    _log(f"ASLEEP_CONFIRMED tv={tv_id} {span} → ✔ ručně", xbmc.LOGINFO)
    if not nxt:
        _hist_module.cw_remove(tv_id=tv_id, season=s_, episode=e_)
        _notif("✔ %s · seriál máš dokoukaný" % span, xbmcgui.NOTIFICATION_INFO, 4000)
        _rm_dispatch.refresh_container("asleep_confirmed")
        return None
    _hist_module.cw_advance_episode(tv_id=tv_id, season=s_, episode=e_, next_season=nxt[0], next_episode=nxt[1])
    try:
        import richmovie_state_sync as _ss_a
        _ss_a.request_push()
    except Exception:
        pass
    nxt_item = dict(item)
    nxt_item.pop("asleep_eps", None)
    nxt_item.update({"season": nxt[0], "episode": nxt[1], "ep_title": "", "position": 0, "ident": ""})
    return nxt_item


def _cw_play_args(item: dict) -> dict:
    """Parametry přehrání záznamu Pokračovat pro `_play` (tvar `parse_qs`: hodnoty jsou seznamy)."""
    qs: dict = {"action": "play", "ident": (item.get("ident") or "").strip()}
    qs.update(_rm_play_params.source_params(item.get("source"), item.get("fs_url"), item.get("fs_hash")))
    # Movie/TV kontext pro historii a lokalizaci
    if item.get("type") == "episode":
        qs["tv_id"] = str(item.get("tv_id") or "")
        qs["tv_name"] = item.get("tv_name") or ""
        qs["season"] = str(int(item.get("season") or 0))
        qs["episode"] = str(int(item.get("episode") or 0))
        qs["ep_title"] = item.get("ep_title") or ""
    else:
        if item.get("title"):
            qs["m_title"] = item["title"]
        if item.get("year"):
            qs["m_year"] = str(item["year"])
        if item.get("tmdb_id"):
            qs["tmdb"] = str(item["tmdb_id"])
    return {k: [v] for k, v in qs.items()}


def _cw_publish_position(item: dict, position: float, ident: str) -> None:
    """Zveřejni bod navázání pro příští `_play` (SSOT `richmovie_resume`; adresát = ident, u výběru
    streamu prázdný → pozice patří dalšímu přehrání TÉHOŽ titulu)."""
    import richmovie_resume as _rm_resume_cw
    try:
        import richmovie_state_sync as _ss_cwkey
        _cw_req_key = _ss_cwkey.cw_key(item) or ""
    except Exception:
        _cw_req_key = ""
    _rm_resume_cw.publish_request(position, ident=ident, runtime_s=item.get("duration") or 0,
                                  source=_rm_resume_cw.SOURCE_CW, key=_cw_req_key)


def _cw_navigate_pick(item: dict) -> None:
    """Výběr streamu pro položku bez použitelného streamu (dřív fallback `_continue_watching_action`).

    RM 4.0 (2026-06-12): v novém UI Container.Update aktualizuje directory NEVIDITELNĚ → picker-first
    (RunPlugin; debounce=False — klik na Home už play_debounce provedl). Klasika (rodina, custom_ui=false)
    = Container.Update na výpis streamů. Title-search (bez tmdb) jde dál legacy.
    """
    _new_ui_cw = _rm_new_ui()
    if item.get("type") == "episode":
        tv_id = item.get("tv_id") or ""
        tv_name = item.get("tv_name") or ""
        season = int(item.get("season") or 0)
        episode_no = int(item.get("episode") or 0)
        ep_title = item.get("ep_title") or ""
        if _new_ui_cw:
            import richmovie_ui_common as _uc_cw
            _uc_cw.play_picker_first(
                ADDON, action="tv_play", poster=(item.get("poster_path") or ""),
                title=(tv_name or ""), debounce=False,
                tv_id=str(tv_id), tv_name=tv_name, season=str(season),
                episode=str(episode_no), ep_title=ep_title)
        else:
            xbmc.executebuiltin(
                f"Container.Update({_url(action='tv_play', tv_id=str(tv_id), tv_name=tv_name, season=str(season), episode=str(episode_no), ep_title=ep_title)})"
            )
        return
    tmdb_id = item.get("tmdb_id")
    if tmdb_id and _new_ui_cw:
        import richmovie_ui_common as _uc_cw
        _uc_cw.play_picker_first(
            ADDON, action="auto", poster=(item.get("poster_path") or ""),
            title=(item.get("title") or ""), debounce=False, tmdb=str(tmdb_id))
    elif tmdb_id:
        xbmc.executebuiltin(f"Container.Update({_url(action='auto', tmdb=str(tmdb_id))})")
    else:
        title = item.get("title") or ""
        _cw_nav = "RunPlugin" if _new_ui_cw else "Container.Update"
        xbmc.executebuiltin(f"{_cw_nav}({_url(action='movie_search', q=title)})")


def _cw_resolve_item() -> Tuple[Optional[dict], float]:
    """Záznam Pokračovat této invokace (klíč, fallback index) a pozice navázání.
    (None, 0) = záznam mezitím zmizel. `restart=1` („Přehrát od začátku“) = pozice 0.
    4.0.3: index v odkazu = index v POHLEDU Pokračovat (`cw_view_load`), stejně jako při vykreslení."""
    data = _hist_module.cw_view_load()
    items = data.get("items", [])
    idx = _cw_locate(items)
    if idx < 0:
        return None, 0.0
    item = items[idx]
    position = float(item.get("position") or 0)
    if params.get("restart", [""])[0] == "1":
        return item, 0.0
    # Φ5 (13.09.2026): navázat z NEJNOVĚJŠÍ pozice profilu, i když lokální pull ještě neproběhl.
    # Read-only dotaz, strop 1,5 s, selhání = lokální pozice. Práh 120 s dopředu (D1).
    return item, _resume_position_from_gate(item, position)


# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _continue_watching_action  (upraveno: 29.09.2026 18:50 CEST — Φ1 dispatcher + SSOT _cw_kind)
# ---------------------------------------------------------------------------- #
def _continue_watching_action() -> None:
    """Stará AKCE „Pokračovat“ (handle −1): widgety skinu, kontextové menu „Přehrát od začátku“,
    oblíbené, nový vzhled a lokální NAS soubory. Seznam `cw_list` od 3.5.160 vede známé streamy
    přímo na přehratelnou `cw_play` (kolečko Kodi hned, druhý klik se spolkne).

    Φ1: přehrání jde VÝHRADNĚ přes `richmovie_playback_dispatch.request` — druhý klik během startu
    dostane „Už to spouštím…“ a žádné druhé `PlayMedia` (pád Kodi 21.2, 29.09.2026)."""
    item, position = _cw_resolve_item()
    if item is None:
        _notif("Tahle položka už v Pokračovat není.", xbmcgui.NOTIFICATION_INFO, 3000)
        # Φ2: klik z Home už okno zavřel — bez návratu by uživatel zůstal koukat na holé Kodi.
        _rm_play_failed_return()
        return
    if item.get("asleep_eps") and params.get("restart", [""])[0] != "1":
        item = _cw_asleep_choice(item)
        if item is None:
            return

    kind = _cw_kind(item, position)
    try:
        import richmovie_state_sync as _ss_k
        _cw_key_s = _ss_k.cw_key(item) or ""
    except Exception:
        _cw_key_s = ""

    # Po skončení/zastavení vrátit do RM UI (P0-3 → Φ2 origin descriptor). overwrite=False: click-site
    # (Home/Grid) už zapsal descriptor s plným NavStackem PŘED zavřením oken.
    if _rm_new_ui():
        try:
            import richmovie_ui_common as _rm_uc_cw
            _rm_uc_cw.mark_play_from_ui(overwrite=False)
        except Exception:
            pass

    if kind == CW_KIND_LOCAL:
        # Soubor z NAS: přímá cesta, bez resolve pluginu (požadavek na navázání se NEzveřejňuje — `_play`
        # neběží a pozici by převzalo příští nesouvisející přehrání; A#2 Fable audit).
        _rm_dispatch.request((item.get("path") or "").strip(), source="cw_local", key=_cw_key_s,
                             noresume=False)
        return

    if kind == CW_KIND_PLAY:
        ident = (item.get("ident") or "").strip()
        _cw_publish_position(item, position, ident)
        args = _cw_play_args(item)
        # `noresume` (3.5.151): pozici určuje RichMovie (bod v resolvované položce), ne záložka Kodi.
        _rm_dispatch.request(_url(**{k: v[0] for k, v in args.items()}), source="cw", key=_cw_key_s,
                             ident=ident)
        return

    _cw_publish_position(item, position, "")
    _cw_navigate_pick(item)


# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _cw_play_action  (vytvořeno: 29.09.2026 15:02 CEST, Europe/Prague — Φ1)
# ---------------------------------------------------------------------------- #
def _cw_play_action() -> None:
    """PŘEHRATELNÁ položka Pokračovat (`cw_play`, handle ≥ 0, IsPlayable).

    Kodi ji resolvuje samo s vlastním modálním kolečkem (za 0,22 s) — druhý klik se spolkne a žádná
    druhá invokace nevznikne. Dotaz na novější pozici z Gate běží už pod kolečkem. Přehrání jde
    stejnou cestou jako každý stream (`_play` → pojistka jednoho startu → `prepare_resolved_item`)."""
    item, position = _cw_resolve_item()
    if item is None:
        _notif("Tahle položka už v Pokračovat není.", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    kind = _cw_kind(item, position)
    if kind == CW_KIND_PLAY:
        ident = (item.get("ident") or "").strip()
        _cw_publish_position(item, position, ident)
        _play(ident, _cw_play_args(item))
        return
    # Záznam se od vykreslení seznamu změnil (sync z jiného zařízení): přehrávat tu nejde →
    # resolve odmítnout a pokračovat jako výběr streamu / NAS (stejně jako stará akce).
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    if kind == CW_KIND_LOCAL:
        _rm_dispatch.request((item.get("path") or "").strip(), source="cw_local", noresume=False)
        return
    _cw_publish_position(item, position, "")
    _cw_navigate_pick(item)


def _cw_list_url(item: dict, idx: int, position: float) -> Tuple[str, bool]:
    """URL a `isFolder` položky v seznamu Pokračovat (SSOT `_cw_kind`, registr `richmovie_routes`).

    Přehratelná položka nese `rev` = revize záznamu (pozice + čas změny). Kodi ukládá záložku pod URL
    položky (MyVideos: bookmark pro `plugin://…`) — bez revize by po dalším kliknutí nabídlo vlastní
    „Pokračovat od…“ s jinou pozicí, než drží RichMovie (D2). Revize se mění s každým posunem pozice,
    takže stará záložka nikdy nesedí."""
    _cwp = _cw_url_params(item, idx)
    if _cw_kind(item, position) == CW_KIND_PLAY:
        rev = "%d-%d" % (int(position), int(float(item.get("ts") or 0)))
        return _url(action="cw_play", rev=rev, **_cwp), False
    return _url(action="continue_watching", **_cwp), _rm_routes.is_folder("continue_watching")


def _continue_watching_list() -> None:
    """
    Plný listing všech položek Continue Watching s metadaty, artworkem
    a context menu pro odebrání jednotlivých položek nebo smazání všech.
    4.0.3: pohled `cw_view_load` (za seriál jeden řádek — nejnovější rozkoukaný / nabídnutý díl).
    """
    data = _hist_module.cw_view_load()
    items = data.get("items") or []

    if not items:
        _modal("Žádné rozpracované filmy ani seriály.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, "Pokračovat ve sledování")
    xbmcplugin.setContent(HANDLE, "videos")

    for idx, it in enumerate(items):
        pos = float(it.get("position") or 0)
        dur = float(it.get("duration") or 1)
        pct = int((pos / dur) * 100) if dur > 0 else 0

        h = int(pos) // 3600
        m = (int(pos) % 3600) // 60
        s = int(pos) % 60
        time_str = f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

        # Label
        if it.get("type") == "episode":
            tv = it.get("tv_name") or it.get("title") or "Seriál"
            se = int(it.get("season") or 0)
            ep = int(it.get("episode") or 0)
            ep_t = it.get("ep_title") or ""
            name_part = f"{tv} S{se:02d}E{ep:02d}"
            if ep_t:
                name_part += f" – {ep_t}"
        else:
            title = it.get("title") or "Bez názvu"
            yr = it.get("year") or ""
            name_part = f"{title} ({yr})" if yr else title

        label = f"{name_part}  [COLOR FF87CEFA]\xb7 {time_str} ({pct}%)[/COLOR]"
        # 13.09.2026: zařízení + stav + stáří (SSOT `origin_text`, stejný text jako na titulní straně)
        try:
            import richmovie_state_sync as _ss_cw
            _origin = _ss_cw.origin_text(it)
        except Exception:
            _origin = ""
        if _origin:
            label += f" [COLOR FF9E9E9E]\xb7 {_origin}[/COLOR]"

        # 3.5.154: vlastní hodnocení i v Pokračovat.
        try:
            _cw_kind = "tv" if it.get("type") == "episode" else "movie"
            _cw_id = it.get("tv_id") if _cw_kind == "tv" else (it.get("tmdb_id") or it.get("id"))
            label = richmovie_ratings.decorate_label(label, _cw_kind, _cw_id)
        except Exception:
            pass
        li = xbmcgui.ListItem(label)

        # Info tags
        info = {
            "title": it.get("title") or it.get("tv_name") or "",
            "plot": f"Pokračovat od {time_str} ({pct}%)" + (f" \xb7 {_origin}" if _origin else ""),
            "mediatype": "episode" if it.get("type") == "episode" else "movie",
        }
        if it.get("type") == "episode":
            info["tvshowtitle"] = it.get("tv_name") or ""
            info["season"] = int(it.get("season") or 0)
            info["episode"] = int(it.get("episode") or 0)
        else:
            if it.get("year"):
                info["year"] = int(it["year"])
        li.setInfo("video", info)

        # Artwork (poster_path/backdrop_path uložené v CW záznamu)
        pp = it.get("poster_path") or ""
        bp = it.get("backdrop_path") or ""
        if not pp and it.get("tmdb_id"):
            try:
                _k = richmovie_settings.get_tmdb_api_key()
                if _k:
                    _tc = TMDb(_k, lang="cs-CZ")
                    if it.get("type") == "episode":
                        _d = _tc.tv_details(int(it["tmdb_id"])) or {}
                    else:
                        _d = _tc.details(int(it["tmdb_id"])) or {}
                    pp = _d.get("poster_path") or ""
                    bp = bp or _d.get("backdrop_path") or ""
            except Exception:
                pass
        art: dict[str, str] = {}
        if pp:
            art["poster"] = f"https://image.tmdb.org/t/p/w342{pp}" if pp.startswith("/") else pp
            art["thumb"] = art["poster"]
            art["icon"] = art["poster"]
        if bp:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{bp}" if bp.startswith("/") else bp
        if art:
            li.setArt(art)

        # Context menu — odebrat položku (podle klíče, 13.09.2026) + přehrát od začátku (Φ1)
        _cwp = _cw_url_params(it, idx)
        li.addContextMenuItems([
            ("Přehrát od začátku",
             f"RunPlugin({_url(action='continue_watching', restart='1', **_cwp)})"),
            ("Odebrat z Pokračovat",
             f"RunPlugin({_url(action='cw_remove', **_cwp)})"),
        ])

        # Φ1 (29.09.2026): známý stream = PŘEHRATELNÁ položka (Kodi kolečko hned, druhý klik se spolkne,
        # žádná druhá invokace = žádný pád Kodi 21.2). Ostatní zůstávají akcí (výběr streamu, NAS).
        _cw_item_url, _cw_is_folder = _cw_list_url(it, idx, pos)
        if not _cw_is_folder and "action=cw_play" in _cw_item_url:
            li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _cw_item_url,
            li,
            isFolder=_cw_is_folder,
        )

    # "Smazat vše" na konci seznamu
    li_clear = xbmcgui.ListItem("[COLOR FFFF6666]Smazat vše[/COLOR]")
    li_clear.setArt({"icon": "DefaultAddonNone.png"})
    xbmcplugin.addDirectoryItem(
        HANDLE,
        _url(action="cw_clear"),
        li_clear,
        isFolder=False,
    )

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)


def _gate_auth_full(cli: WebshareClient, user: str, pw: str) -> Tuple[str, Optional[dict]]:
    """SSOT `/auth` s obnovou WS tokenu (Φ3, 29.09.2026 — dřív jen inline v `_root`).

    Gate ověřuje i WS token; expirovaný (`AUTH_TOKEN_INVALID`) = čerstvý login z uložených údajů
    a jeden další pokus. Volá ho popředí (menu bez platné lease) i ověření na pozadí (D5)."""
    import richmovie_gate
    code, data = richmovie_gate.gate_auth(user, cli.token or "", ADDON, ws_password=pw)
    if code == richmovie_gate.AUTH_TOKEN_INVALID:
        _log("[Gate] Token expired, re-login", xbmc.LOGINFO)
        richmovie_settings.write("token", "")
        if user and pw:
            try:
                cli.login(user, pw)
                richmovie_settings.write("token", cli.token)
                code, data = richmovie_gate.gate_auth(user, cli.token, ADDON, ws_password=pw)
            except Exception as _e:
                _log("[Gate] WS re-login failed: %s" % _e, xbmc.LOGWARNING)
    return code, data


# Ověření na pozadí nejvýš jedno napříč procesy (Kodi spouští root při startu 2×). TTL pokrývá
# nejdelší naměřený `/auth` včetně výpadku DNS (41 s, audit A07 F5); konec běhu claim uvolní hned.
_GATE_AUTH_BG_GUARD = "gate_auth_background"
_GATE_AUTH_BG_TTL_S = 60.0


def _gate_auth_background(cli: WebshareClient, user: str, pw: str) -> None:
    """Tělo vlákna ověření na pozadí (D5). Výsledek zapíše `gate_auth` sám (cache, stav identity,
    blok profilů); zamítnutí se projeví fail-fastem `/v1/*` hned a v menu při dalším otevření."""
    import richmovie_guard as _guard
    token = _guard.claim(_GATE_AUTH_BG_GUARD, _GATE_AUTH_BG_TTL_S)
    if not token:
        return
    try:
        mode_before = richmovie_profile.mode()   # S24: přechod účtu na více profilů zjistí až tahle odpověď
        with _rm_bc.background_steps():   # S15: krok `gate_auth_bg` — menu na něj nečeká, do součtu rootu nepatří
            code, _data = _gate_auth_full(cli, user, pw)
        _log(f"[Gate] ověření na pozadí → {code}", xbmc.LOGINFO)
        # S24 D5: menu se postavilo z lease ještě v režimu „Jen já“ → výběr „Kdo se dívá?“ hned (fronta obnov
        # překreslí hlavní menu, krok profilu znovu otevřené sekvence ho ukáže), ne až po restartu Kodi.
        import richmovie_profile_ui as _pf_ui_bg
        _pf_ui_bg.after_background_auth(mode_before)
    except Exception as exc:
        _log(f"[Gate] ověření na pozadí selhalo: {exc!r}", xbmc.LOGWARNING)
    finally:
        _guard.release(_GATE_AUTH_BG_GUARD, token)


def _gate_auth_menu(cli: WebshareClient, user: str, pw: str) -> Tuple[str, Optional[dict]]:
    """`/auth` pro vykreslení menu (D5, Φ3 29.09.2026): s platnou lease z online ověření téhož
    uživatele a tokenu (`richmovie_gate.lease_first`) se menu staví HNED z ní a `/auth` běží
    vláknem (non-daemon: HTTP se nesmí utnout; invokace na něj počká až po `endOfDirectory`).
    Bez lease, se zamítnutou identitou nebo po změně tokenu se čeká jako dřív."""
    import richmovie_gate
    cached = richmovie_gate.lease_first(user, cli.token or "")
    if cached is None:
        return _gate_auth_full(cli, user, pw)
    _log("[Gate] menu z lease (do %s), ověření na pozadí" % cached.get("lease_expires", "?"), xbmc.LOGINFO)
    threading.Thread(target=_gate_auth_background, args=(cli, user, pw),
                     name="RMGateAuthBg", daemon=False).start()
    return richmovie_gate.AUTH_OK, cached


def _gate_auth_silent() -> None:
    """Tichý `/auth` z uložených údajů (bez dialogů) — cesta zotavení identity pro službu.
    Používá stejný SSOT `richmovie_gate.gate_auth` jako root menu; výsledek jen zaloguje."""
    import richmovie_gate
    user = richmovie_settings.get_ws_username() or ""
    pw = richmovie_settings.get_ws_password() or ""
    token = richmovie_settings.get_ws_token() or ""
    if not user or not pw:
        _log("silent_auth: no credentials", xbmc.LOGINFO)
        return
    mode_before = richmovie_profile.mode()
    code, _data = richmovie_gate.gate_auth(user, token, ADDON, ws_password=pw, reuse_within_s=0)
    _log(f"silent_auth: gate_auth → {code}", xbmc.LOGINFO)
    import richmovie_profile_ui as _pf_ui_silent
    _pf_ui_silent.after_background_auth(mode_before)   # S24: i tichá cesta zotavení může přinést přechod na multi


def _ep_watched_action(*, mark: bool) -> None:
    """Ruční korekce zeleného ✔ u epizody (3.5.149): `mark` = „Viděl jsem to" (kind `manual`),
    jinak odznačení. Obojí se přes `richmovie_history` propíše na Gate (`_sync_note`) a
    ostatní zařízení si to stáhnou běžným pullem."""
    try:
        tv_id = (params.get("tv_id", [""])[0] or "").strip()
        season = int((params.get("season", ["0"])[0]) or 0)
        episode = int((params.get("episode", ["0"])[0]) or 0)
    except (ValueError, IndexError):
        return
    if not tv_id or season <= 0 or episode <= 0:
        return
    if mark:
        _hist_module.watched_mark_episode(tv_id=tv_id, season=season, episode=episode,
                                          completion=1.0, kind="manual")
    else:
        _hist_module.watched_unmark_episode(tv_id=tv_id, season=season, episode=episode)
    _log(f"EP_WATCHED_{'MARK' if mark else 'UNMARK'}: {tv_id} S{season:02d}E{episode:02d}",
         xbmc.LOGINFO)
    try:
        import richmovie_state_sync as _ss_ep
        _ss_ep.request_push()
    except Exception:
        pass
    _rm_dispatch.refresh_container("ep_watched")


def _cw_remove_action() -> None:
    """„Odebrat z Pokračovat“ (klíč, fallback index v pohledu). 4.0.3: seriál se skryje CELÝ (rozkoukanost dílů
    v seznamu zůstává), film se odebere — SSOT `richmovie_history.cw_dismiss`."""
    items = (_hist_module.cw_view_load() or {}).get("items") or []
    idx = _cw_locate(items)
    if idx >= 0:
        _hist_module.cw_dismiss(items[idx])
    _rm_dispatch.refresh_container("cw_remove")


def _cw_clear_action() -> None:
    """Smaže všechny položky z CW po potvrzení dialogem."""
    if xbmcgui.Dialog().yesno("Pokračovat ve sledování",
                               "Opravdu smazat všechny rozpracované položky?"):
        _hist_module.cw_clear()
        _rm_dispatch.refresh_container("cw_clear")


# ═══════════════════════════════════════════════════════════════════════════════
#  HISTORIE VYHLEDÁVÁNÍ – UI FUNKCE (zůstávají v plugin.py)
# ═══════════════════════════════════════════════════════════════════════════════

def _show_history() -> None:
    """
    Zobrazuje kategorie historie hledani jako directory listing (slozky).
    Kliknuti na kategorii otevre obohaceny seznam s postery a metadaty.
    """
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "Historie hledání")
    hist = _load_history()
    if not any(hist.values()):
        if not rmdir.custom:
            _modal("Historie je prazdna.")
        rmdir.finish(succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, "Historie hledani")

    cats = [
        ("movie",       "Filmy",     len(hist.get("movie", []))),
        ("tv",          "Serialy",   len(hist.get("tv", []))),
        ("ws",          "Webshare",  len(hist.get("ws", []))),
        ("collections", "Kolekce",   len(hist.get("collections", []))),
        ("other",       "Ostatni",   len(hist.get("other", []))),
    ]

    try:
        _addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
    except Exception:
        _addon_path = ADDON.getAddonInfo("path")
    _icons_dir = os.path.join(_addon_path, "resources", "media", "icons")
    _icon_search = os.path.join(_icons_dir, "historie_hledani.png")

    for key, label, cnt in cats:
        if cnt:
            li = xbmcgui.ListItem(f"{label} ({cnt})")
            li.setArt({"icon": _icon_search, "thumb": _icon_search})
            rmdir.add(_url(action="history_category", cat=key), li, isFolder=True)

    # Vymazat historii
    try:
        li_clear = xbmcgui.ListItem("[COLOR red]Vymazat historii[/COLOR]")
    except Exception:
        li_clear = xbmcgui.ListItem("Vymazat historii")
    rmdir.add(_url(action="history_clear"), li_clear, isFolder=False)

    rmdir.finish()


def _show_history_category() -> None:
    """
    Zobrazuje polozky konkretni kategorie historie s TMDb obohacenim.
    Obohacene zaznamy (dict) maji poster, rating, rok.
    Stare zaznamy (string) se zobrazi jako prosty text.
    """
    import richmovie_rmdir
    cat = (params.get("cat", ["movie"])[0] or "movie").strip()
    hist = _load_history()
    items = hist.get(cat, [])

    cat_labels = {"movie": "Filmy", "tv": "Serialy", "ws": "Webshare",
                  "collections": "Kolekce", "other": "Ostatni"}
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"Historie – {cat_labels.get(cat, cat)}")

    if not items:
        if not rmdir.custom:
            _modal("Tato kategorie je prazdna.")
        rmdir.finish(succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, f"Historie - {cat_labels.get(cat, cat)}")
    if cat == "movie":
        xbmcplugin.setContent(HANDLE, "movies")
    elif cat == "tv":
        xbmcplugin.setContent(HANDLE, "tvshows")

    # Pre-load watch history pro TV kontextove menu (posledni zhlednuty dil na serial)
    _wh_last_ep = {}  # tv_id_str -> {"season": int, "episode": int}
    if cat == "tv":
        try:
            for _wh_it in _watch_load().get("episodes", []):
                _wh_tid = str(_wh_it.get("tv_id") or "").strip()
                if _wh_tid and _wh_tid not in _wh_last_ep:
                    _wh_last_ep[_wh_tid] = {
                        "season": int(_wh_it.get("season") or 0),
                        "episode": int(_wh_it.get("episode") or 0),
                    }
        except Exception:
            _wh_last_ep = {}

    for entry in items:
        if isinstance(entry, dict):
            # Obohaceny zaznam s TMDb metadaty
            query = (entry.get("query") or "").strip()
            title = (entry.get("title") or query).strip()
            year = entry.get("year") or 0
            rating = entry.get("rating") or 0
            poster_path = entry.get("poster_path") or ""

            # Label: "* 8.4  Pocatek (2010)"
            label_parts = []
            if rating:
                label_parts.append(f"[B][COLOR gold]* {rating}[/COLOR][/B]")
            title_txt = f"{title} ({year})" if year else title
            label_parts.append(title_txt)
            label = "  ".join(label_parts)

            li = xbmcgui.ListItem(label)

            # Artwork
            backdrop_path = entry.get("backdrop_path") or ""
            art = {}
            if poster_path:
                poster_url = f"https://image.tmdb.org/t/p/w342{poster_path}"
                art["poster"] = poster_url
                art["thumb"] = poster_url
            if backdrop_path:
                art["fanart"] = f"https://image.tmdb.org/t/p/w1280{backdrop_path}"
            li.setArt(art)

            # InfoTag
            overview = (entry.get("overview") or "").strip()
            info = {"title": title}
            if year:
                info["year"] = int(year)
            if rating:
                info["rating"] = float(rating)
            if overview:
                info["plot"] = overview
            if cat == "movie":
                info["mediatype"] = "movie"
            elif cat == "tv":
                info["mediatype"] = "tvshow"
            li.setInfo("video", info)

            # Kontextove menu: Podobne filmy/serialy + TV navigace
            tmdb_id = entry.get("tmdb_id")
            if tmdb_id:
                if cat == "movie":
                    li.addContextMenuItems([
                        ("Podobne filmy", f"Container.Update({_url(action='similar_movies', tmdb_id=str(tmdb_id))})"),
                    ])
                elif cat == "tv":
                    _tv_ctx = []
                    _tv_ctx.append((
                        "Dalsi dil",
                        f"Container.Update({_url(action='tv_next_episode', tv_id=str(tmdb_id), tv_name=title)})",
                    ))
                    _tv_ctx.append((
                        "Sezony serialu",
                        f"Container.Update({_url(action='tv_seasons', tv_id=str(tmdb_id), tv_name=title)})",
                    ))
                    _wh_info = _wh_last_ep.get(str(tmdb_id))
                    if _wh_info and _wh_info["season"] > 0:
                        _tv_ctx.append((
                            f"Epizody sezony {_wh_info['season']}",
                            f"Container.Update({_url(action='tv_episodes', tv_id=str(tmdb_id), tv_name=title, season=str(_wh_info['season']))})",
                        ))
                    _tv_ctx.append((
                        "Podobne serialy",
                        f"Container.Update({_url(action='similar_tv', tmdb_id=str(tmdb_id))})",
                    ))
                    li.addContextMenuItems(_tv_ctx)

                # Custom UI context menu (RichMovieListWindow čte rm_ctx_json):
                # míří na EXISTUJÍCÍ custom okna (rm_grid/rm_episodes) místo
                # Kodi Container.Update → žádné Kodi directory okno.
                try:
                    if cat == "movie":
                        _cctx = [["Podobné filmy",
                                  _url(action="rm_grid", feed="similar_movies",
                                       ref_id=str(tmdb_id), title=f"Podobné: {title}")]]
                    else:  # tv
                        _cctx = [
                            ["Sezóny a epizody",
                             _url(action="rm_episodes", tv_id=str(tmdb_id), tv_name=title)],
                            ["Další díl",
                             _url(action="tv_next_episode", tv_id=str(tmdb_id), tv_name=title)],
                            ["Podobné seriály",
                             _url(action="rm_grid", feed="similar_tv",
                                  ref_id=str(tmdb_id), title=f"Podobné: {title}")],
                        ]
                    li.setProperty("rm_ctx_json", json.dumps(_cctx))
                except Exception:
                    pass

        elif cat == "collections":
            # Kolekce: format "nazev||cesta"
            display_name = entry.split("||")[0] if isinstance(entry, str) else str(entry)
            li = xbmcgui.ListItem(display_name)
        else:
            # Stary string zaznam
            li = xbmcgui.ListItem(str(entry))

        # Klik -> spustit hledani nebo navigaci
        if cat == "movie":
            q = (entry.get("query") if isinstance(entry, dict) else entry) or ""
            url = _url(action="movie_search", q=q)
        elif cat == "tv":
            q = (entry.get("query") if isinstance(entry, dict) else entry) or ""
            url = _url(action="tv_search", q=q)
        elif cat == "ws":
            q = (entry.get("query") if isinstance(entry, dict) else entry) or ""
            url = _url(action="ws_search", q=q)
        elif cat == "collections":
            coll_parts = entry.split("||", 1) if isinstance(entry, str) else ["", ""]
            if len(coll_parts) == 2 and coll_parts[1]:
                url = _url(action="collections_browse", file=coll_parts[1])
            else:
                continue
        else:
            q = (entry.get("query") if isinstance(entry, dict) else entry) or ""
            url = _url(action="movie_search", q=q)

        rmdir.add(url, li, isFolder=True)

    rmdir.finish()








# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _watch_history
# (upraveno: 23.12.2025 15:11 CET (Europe/Prague) – UX: bez emoji + počty jako "Historie hledání"; volby Filmy/Seriály/Vymazat)
# ---------------------------------------------------------------------------- #
def _watch_history() -> None:
    """
    23.12.2025 15:11 CET (Europe/Prague)

    Entry point pro menu "Historie sledování".

    CÍL / FIX:
      • odstranění emoji z labelů (některé skiny je nezobrazují → "čtverečky"),
      • zobrazení počtů jako v "Historii hledání" (Filmy (X), Seriály (Y)),
      • zachování původní logiky: volba Filmy / Seriály / Vymazat historii.
    """
    dlg = xbmcgui.Dialog()

    try:
        data = _watch_load() or {}
        cnt_movies = len(data.get("movies", []) or [])
        cnt_tv = len(data.get("episodes", []) or [])
    except Exception:
        cnt_movies = 0
        cnt_tv = 0

    choice = dlg.select(
        "Historie sledování – vyberte kategorii",
        [
            f"Filmy ({cnt_movies})",
            f"Seriály ({cnt_tv})",
            "Vymazat historii",
        ],
    )
    if choice < 0:
        return

    if choice == 0:
        _watch_history_movies()
        return

    if choice == 1:
        _watch_history_tv()
        return

    if choice == 2:
        if dlg.yesno("Vymazat historii", "Opravdu chceš vymazat historii sledování?"):
            _watch_history_clear()
            # Po smazání je fajn UI "nakopnout" (ať se projeví hned) — brána nikdy nevyhazuje
            _rm_dispatch.refresh_container("watch_history_clear_menu")
        return





# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _watch_history_movies
# (upraveno: 23.12.2025 15:11 CET (Europe/Prague) – UI: bez emoji u "Vymazat historii…" + přímé volání action=watch_history_clear)
# ---------------------------------------------------------------------------- #
def _watch_history_movies() -> None:
    """
    14.12.2025 18:52 CET (Europe/Prague)

    Zobrazí seznam naposledy sledovaných filmů.
    • Stylově stejné jako naše TMDb výpisy (poster, fanart, plot, rating/votes).
    • Kliknutí:
        – pokud je k dispozici TMDb ID → `action="auto"` (rychlé dohledání releasů),
        – jinak fallback na `action="movie_search"` s názvem filmu.
    • V horní části je položka "Vymazat historii…", která provede smazání
      watch_history_clear (a vrátí tě na výběr kategorií).

    NOVĚ:
    ------
    • Do labelu přidána stopáž (min) v modré. Pokud TMDb vrátí více stopáží
      (release_dates runtime), zobrazíme je jako seznam (např. 123, 158, 162).
    """
    hist = _watch_load().get("movies", [])
    # 2025-09-27 13:34 CEST (Europe/Prague) – UI limit pro rychlé načtení
    if _WATCH_UI_MAX_MOVIES > 0:
        hist = hist[:_WATCH_UI_MAX_MOVIES]

    if not hist:
        _modal("Historie filmů je prázdná.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # TMDb detail použijeme pro hezčí kartičky, když máme klíč i ID
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    tmdb = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    xbmcplugin.setPluginCategory(HANDLE, "Historie sledování – Filmy")
    xbmcplugin.setContent(HANDLE, "movies")

    # ──────────────────────────────────────────────────────────────────
    # HORNÍ POMOCNÁ POLOŽKA: "Vymazat historii…" (vymaže historii)
    # ──────────────────────────────────────────────────────────────────
    try:
        li_clear = xbmcgui.ListItem("[COLOR red]Vymazat historii…[/COLOR]")
    except Exception:
        li_clear = xbmcgui.ListItem("Vymazat historii…")
    xbmcplugin.addDirectoryItem(
        HANDLE,
        _url(action="watch_history_clear"),
        li_clear,
        isFolder=False,
    )

    # VÝPIS POLOŽEK
    for m in hist:
        title = (m.get("title") or "").strip()
        year = int(m.get("year") or 0) if str(m.get("year") or "").isdigit() else (m.get("year") or 0)
        tmdb_id = m.get("id") or m.get("tmdb")

        # TMDb detail – poster, fanart, rating, overview, runtime
        _det = None
        if tmdb and tmdb_id:
            try:
                _det = tmdb.details(int(tmdb_id))
            except Exception:
                _det = None

        # Stopáž – preferuj TMDb detail, pak movie_runtimes, pak uložené
        runtime_list = []
        if _det and _det.get("runtime"):
            runtime_list = [int(_det["runtime"])]
        if not runtime_list:
            try:
                if tmdb and tmdb_id:
                    runtime_list = tmdb.get_alt_runtimes(int(tmdb_id)) or []
            except Exception:
                runtime_list = []
        if not runtime_list:
            try:
                rt = int(m.get("runtime") or 0)
                if rt > 0:
                    runtime_list = [rt]
            except Exception:
                runtime_list = []

        # Label + stopáž modře
        label = title or "Bez názvu"
        if year:
            label = f"{label} ({year})"
        if runtime_list:
            try:
                runtimes = sorted({int(x) for x in runtime_list if int(x) > 0})
            except Exception:
                runtimes = runtime_list
            rt_txt = ", ".join(str(x) for x in runtimes)
            label = f"{label}  [COLOR deepskyblue]{rt_txt} min[/COLOR]"

        li = xbmcgui.ListItem(label)

        # Artwork – z TMDb detailu
        _poster_url = ""
        _fanart_url = ""
        if _det:
            if _det.get("poster_path"):
                _poster_url = f"https://image.tmdb.org/t/p/w342{_det['poster_path']}"
            if _det.get("backdrop_path"):
                _fanart_url = f"https://image.tmdb.org/t/p/w1280{_det['backdrop_path']}"
        try:
            li.setArt({
                "poster": _poster_url,
                "fanart": _fanart_url,
                "thumb": _poster_url,
            })
        except Exception:
            pass

        # InfoTag – z TMDb detailu
        try:
            info = {
                "title": title,
                "year": year or 0,
            }
            if _det:
                _rating = float(_det.get("vote_average") or 0)
                if _rating > 0:
                    info["rating"] = round(_rating, 1)
                    info["votes"] = int(_det.get("vote_count") or 0)
                _plot = (_det.get("overview") or "").strip()
                if _plot:
                    info["plot"] = _plot
            elif m.get("rating"):
                info["rating"] = m["rating"]
                info["votes"] = m.get("votes", 0)
            li.setInfo("video", info)
        except Exception:
            pass

        # Kontextove menu: Podobne filmy (pokud mame TMDb ID) + Ohodnotit ★ (3.5.152)
        _ctx_tmdb = m.get("id") or tmdb_id
        if _ctx_tmdb:
            try:
                _own = richmovie_ratings.get("movie", _ctx_tmdb)
                if _own:
                    li.setLabel(richmovie_ratings.decorate_label(label, "movie", _ctx_tmdb))
                    _ur = richmovie_ratings.kodi_userrating("movie", _ctx_tmdb)
                    if _ur:
                        li.setInfo("video", {"userrating": _ur})
                li.addContextMenuItems([
                    ("Ohodnotit ★" if not _own else "Změnit hodnocení ★",
                     f"RunPlugin({_url(action='rate_title', kind='movie', tmdb_id=str(_ctx_tmdb), title=title)})"),
                    ("Podobne filmy", f"Container.Update({_url(action='similar_movies', tmdb_id=str(_ctx_tmdb))})"),
                ])
            except Exception:
                pass

        # Klik – preferuj auto podle TMDb, jinak plnotextové hledání
        if (m.get("id") or tmdb_id):
            url = _url(action="auto", tmdb=str(m.get("id") or tmdb_id))
            is_folder = True
        else:
            url = _url(action="movie_search", q=(m["title"] or title))
            is_folder = True

        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(HANDLE)










# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _watch_history_tv
# (upraveno: 23.12.2025 15:11 CET (Europe/Prague) – UI: bez emoji u "Vymazat historii…" + přímé volání action=watch_history_clear)
# ---------------------------------------------------------------------------- #
def _watch_history_tv() -> None:
    """
    Zobrazí "mix" posledních epizod napříč seriály z naší watch-historie.
    • Label položky:  "<SERIÁL> SxxEyy – <název epizody>"
    • InfoTagy (nově): title (ep_title), tvshowtitle, season, episode, mediatype=episode, plot (popis epizody)
    • Artwork (nově): thumb/landscape = still z epizody, poster/fanart = ze seriálu, clearlogo = logo seriálu
    • Pravý panel (nově): ListItem.Property("richmovie.series_title"/"richmovie.series_plot"/"richmovie.series_logo")

    15-08-2025 21:52 CEST (Europe/Prague) – DOPLNĚNO: TMDb dotazy pro epizodu/seriál a nastavení artworku + pravého panelu.
    05-09-2025 19:30 CEST (Europe/Prague) – PŘIDÁNO: Kontextové menu "jít na seriál" (rychlý skok na výpis sezón z Historie → Seriály).

    DŮLEŽITÉ: Žádná jiná logika (řazení, klikací URL) se nemění.
    """
    hist = _watch_load().get("episodes", [])
    # 2025-09-27 13:34 CEST (Europe/Prague) – UI limit pro rychlé načtení
    if _WATCH_UI_MAX_EPISODES > 0:
        hist = hist[:_WATCH_UI_MAX_EPISODES]

    if not hist:
        _modal("Historie seriálů je prázdná.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, "Historie sledování – Seriály")
    xbmcplugin.setContent(HANDLE, "episodes")

    # HORNÍ POMOCNÁ POLOŽKA – "Vymazat historii…"
    try:
        li_clear = xbmcgui.ListItem("[COLOR red]Vymazat historii…[/COLOR]")
    except Exception:
        li_clear = xbmcgui.ListItem("Vymazat historii…")
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="watch_history_clear"), li_clear, isFolder=False)

    # TMDb klient (pokud máme klíč)
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    tmdb = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    # VÝPIS POLOŽEK
    for it in hist:
        tv_id = it.get("tv_id")
        tv_name = (it.get("tv_name") or "").strip()

        try:
            season = int(it.get("season") or 0)
        except Exception:
            season = 0
        try:
            episode = int(it.get("episode") or 0)
        except Exception:
            episode = 0

        ep_title = (it.get("ep_title") or "").strip()

        # label
        s_txt = f"{season:02d}" if season >= 0 else "00"
        e_txt = f"{episode:02d}" if episode >= 0 else "00"
        label = f"{tv_name} S{s_txt}E{e_txt}"
        if ep_title:
            label += f" – {ep_title}"

        # 3.5.154: vlastní hodnocení seriálu i v Historii sledování.
        try:
            label = richmovie_ratings.decorate_label(label, "tv", tv_id)
        except Exception:
            pass
        li = xbmcgui.ListItem(label)

        # default artwork z uložených dat (pokud existuje)
        try:
            li.setArt({
                "poster": it.get("poster") or "",
                "fanart": it.get("fanart") or "",
                "thumb": it.get("still") or it.get("thumb") or "",
                "landscape": it.get("still") or it.get("thumb") or "",
                "clearlogo": it.get("logo") or "",
            })
        except Exception:
            pass

        # Info
        try:
            info = {
                "title": ep_title or label,
                "tvshowtitle": tv_name,
                "season": season,
                "episode": episode,
                "mediatype": "episode",
                "plot": (it.get("ep_plot") or it.get("plot") or ""),
            }
            li.setInfo("video", info)
        except Exception:
            pass

        # Pravý panel – props (pokud používáš ve skinech)
        try:
            li.setProperty("richmovie.series_title", tv_name)
            li.setProperty("richmovie.series_plot", (it.get("tv_plot") or ""))
            li.setProperty("richmovie.series_logo", (it.get("logo") or ""))
        except Exception:
            pass

        # TMDb enrichment (pokud máme klíč + id)
        if tmdb and tv_id and str(tv_id).isdigit():
            try:
                _tid = int(tv_id)
                # série
                s = tmdb.tv_details(_tid) or {}
                tv_plot = (s.get("overview") or "").strip()
                _pp = s.get("poster_path") or ""
                _bp = s.get("backdrop_path") or ""
                poster = f"https://image.tmdb.org/t/p/w342{_pp}" if _pp else ""
                fanart = f"https://image.tmdb.org/t/p/w1280{_bp}" if _bp else ""

                # epizoda
                ep = tmdb.episode_details(_tid, int(season), int(episode)) or {}
                ep_plot = (ep.get("overview") or "").strip()
                _sp = ep.get("still_path") or ""
                still = f"https://image.tmdb.org/t/p/w780{_sp}" if _sp else ""

                # logo
                logo = ""
                try:
                    logos = tmdb.tv_logos(_tid) or []
                    if logos:
                        _lp = logos[0].get("file_path") or ""
                        logo = f"https://image.tmdb.org/t/p/w500{_lp}" if _lp else ""
                except Exception:
                    logo = ""

                # aplikuj
                try:
                    li.setArt({
                        "poster": poster or (it.get("poster") or ""),
                        "fanart": fanart or (it.get("fanart") or ""),
                        "thumb": still or (it.get("still") or it.get("thumb") or ""),
                        "landscape": still or (it.get("still") or it.get("thumb") or ""),
                        "clearlogo": logo or (it.get("logo") or ""),
                    })
                except Exception:
                    pass

                _ep_info = {
                    "title": ep_title or label,
                    "tvshowtitle": tv_name,
                    "season": season,
                    "episode": episode,
                    "mediatype": "episode",
                    "plot": ep_plot or (it.get("ep_plot") or it.get("plot") or ""),
                }
                _tv_rating = float(s.get("vote_average") or 0)
                if _tv_rating > 0:
                    _ep_info["rating"] = round(_tv_rating, 1)
                    _ep_info["votes"] = int(s.get("vote_count") or 0)
                try:
                    li.setInfo("video", _ep_info)
                except Exception:
                    pass

                try:
                    li.setProperty("richmovie.series_title", tv_name)
                    li.setProperty("richmovie.series_plot", tv_plot or (it.get("tv_plot") or ""))
                    li.setProperty("richmovie.series_logo", logo or (it.get("logo") or ""))
                except Exception:
                    pass

            except Exception:
                pass

        # Kontextové menu – rychlý skok na další díl / sezóny / epizody + podobné seriály
        ctx = []
        if tv_id and str(tv_id).isdigit():
            ctx.append((
                "Dalsi dil",
                f"Container.Update({_url(action='tv_next_episode', tv_id=str(tv_id), tv_name=tv_name)})",
            ))
            ctx.append((
                "Sezony serialu",
                f"Container.Update({_url(action='tv_seasons', tv_id=str(tv_id), tv_name=tv_name)})",
            ))
            if season:
                ctx.append((
                    f"Epizody sezony {season}",
                    f"Container.Update({_url(action='tv_episodes', tv_id=str(tv_id), tv_name=tv_name, season=str(season))})",
                ))
            ctx.append((
                "Podobne serialy",
                f"Container.Update({_url(action='similar_tv', tmdb_id=str(tv_id))})",
            ))
            # 3.5.152: hodnocení seriálu ★ z kontextového menu. Od 3.5.154 se služba ptá i sama
            # (po polovině 1. řady a po dokoukání — `service_nextup._maybe_ask_rating_series`).
            try:
                _own_tv = richmovie_ratings.get("tv", tv_id)
                if _own_tv:
                    # 3.5.154: hvězdičky i u seriálu (dřív se vlastní hodnocení seriálu
                    # nikde v seznamu neukazovalo, jen v kontextovém menu).
                    li.setLabel(richmovie_ratings.decorate_label(li.getLabel(), "tv", tv_id))
                    _ur_tv = richmovie_ratings.kodi_userrating("tv", tv_id)
                    if _ur_tv:
                        li.setInfo("video", {"userrating": _ur_tv})
                ctx.insert(0, ("Ohodnotit seriál ★" if not _own_tv else "Změnit hodnocení ★",
                               f"RunPlugin({_url(action='rate_title', kind='tv', tmdb_id=str(tv_id), title=tv_name)})"))
            except Exception:
                pass
        if ctx:
            li.addContextMenuItems(ctx)

        # Klik – stejné chování jako dřív (navigace na přehrání epizody)
        url = _url(
            action="tv_play",
            tv_id=str(tv_id or ""),
            tv_name=tv_name,
            season=str(season),
            episode=str(episode),
            ep_title=ep_title,
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)



# ═══════════════════════════════════════════════════════════════════════════════
#  WATCH HISTORY – CRUD DELEGACE NA richmovie_history (Fáze 2 refaktoringu)
# ═══════════════════════════════════════════════════════════════════════════════

def _watch_load() -> dict:
    """Delegováno do richmovie_history"""
    return _hist_module.watch_load()


def _watch_save(data: dict) -> None:
    """Delegováno do richmovie_history"""
    _hist_module.watch_save(data)


def _watch_add_movie(*, tmdb_id: Optional[int], title: str, year: Optional[int]) -> None:
    """Delegováno do richmovie_history"""
    _hist_module.watch_add_movie(tmdb_id=tmdb_id, title=title, year=year)


def _watch_history_clear() -> None:
    """Delegováno do richmovie_history"""
    _hist_module.watch_history_clear()


def _watch_add_episode(*, tv_id: Any, tv_name: str, season: int, episode: int, ep_title: str) -> None:
    """Delegováno do richmovie_history"""
    _hist_module.watch_add_episode(tv_id=tv_id, tv_name=tv_name, season=season, episode=episode, ep_title=ep_title)


def _recent_series() -> None:
    """Seznam naposledy sledovaných seriálů (dedup per seriál, newest-first).

    TV UX Goal 1: rychlý přístup. Klik na seriál vede ROVNOU do seznamu epizod
    poslední sledované sezóny (action=tv_episodes) — 2 kliky z home do epizod
    (dnes 4+ přes hledání). Komplementární k „Pokračovat" (to resume-přehrává,
    tohle otevírá seznam epizod, kde uvidíš i ✓ dokoukaných).
    """
    series = _hist_module.get_recently_watched_series(limit=12)
    if not series:
        _modal("Zatím žádné sledované seriály.", heading="RichMovie")
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        except Exception:
            pass
        return

    # Best-effort poster mapa z continue_watching cache (bez síťového TMDb fetche)
    _poster_by_tv: dict[str, str] = {}
    try:
        for _it in (_hist_module.cw_load().get("items") or []):
            _tid = str(_it.get("tv_id") or "")
            _pp = _it.get("poster_path") or ""
            if _tid and _pp and _tid not in _poster_by_tv:
                _poster_by_tv[_tid] = _pp
    except Exception:
        pass

    for s in series:
        tv_id = s.get("tv_id")
        tv_name = (s.get("tv_name") or "Seriál").strip()
        last_s = int(s.get("last_season") or 0)
        last_e = int(s.get("last_episode") or 0)

        # 3.5.156: ŘADA + KDY + ODKUD („naposledy S05E04 · včera · TV obývák"); bez ✔ jen čas startu
        _meta = _hist_module.watched_suffix(
            {"watched_at": s.get("watched_at") or s.get("ts"), "device": s.get("device")})
        suffix = (f"  [COLOR FF9E9E9E](naposledy S{last_s:02d}E{last_e:02d}{_meta})[/COLOR]"
                  if last_s and last_e else "")
        li = xbmcgui.ListItem(f"{tv_name}{suffix}")

        _pp = _poster_by_tv.get(str(tv_id) or "")
        if _pp:
            _poster = f"https://image.tmdb.org/t/p/w342{_pp}" if _pp.startswith("/") else _pp
            li.setArt({"poster": _poster, "thumb": _poster, "icon": _poster})
        else:
            li.setArt({"icon": "DefaultTVShows.png", "thumb": "DefaultTVShows.png"})

        li.setInfo("video", {
            "title": tv_name,
            "tvshowtitle": tv_name,
            "mediatype": "tvshow",
        })
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tv_episodes", tv_id=tv_id, tv_name=tv_name, season=last_s or 1),
            li,
            isFolder=True,
        )

    try:
        xbmcplugin.setContent(HANDLE, "tvshows")
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    except Exception:
        pass




# ─────────────────────────────────────────────────────────────────────
# RichMovie 4.0 — Home rails (widget-safe directory endpointy pro skin.richmovie)
# DRY: sdílí data-loadery s foreground akcemi (cw_load, get_recently_watched_series);
# renderují TIŠE — žádný modal, vždy succeeded=True i prázdné → vhodné jako
# Container content na Home.xml (plugin://plugin.video.richmovie/?action=rail_*).
# Best-effort: jakákoli chyba položky se zaloguje a přeskočí, rail nikdy neshodí home.
# ─────────────────────────────────────────────────────────────────────

def _tmdb_img(path: str, size: str = "w342") -> str:
    """SSOT konstrukce TMDb image URL. Prázdné → ''; plné http URL beze změny."""
    if not path:
        return ""
    if path.startswith("http"):
        return path
    if path.startswith("/"):
        return f"https://image.tmdb.org/t/p/{size}{path}"
    return path


def _rail_end(content: str = "videos") -> None:
    """Widget-safe konec directory: nastav content + VŽDY succeeded=True (žádný modal)."""
    try:
        xbmcplugin.setContent(HANDLE, content)
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
    except Exception:
        pass


def _rail_continue_watching() -> None:
    """Rail 'Pokračovat ve sledování' — pohled Pokračovat (lokální, bez sítě)."""
    try:
        items = (_hist_module.cw_view_load().get("items") or [])
    except Exception:
        items = []
    for idx, it in enumerate(items):
        try:
            pos = float(it.get("position") or 0)
            dur = float(it.get("duration") or 1)
            pct = int((pos / dur) * 100) if dur > 0 else 0
            if it.get("type") == "episode":
                tv = it.get("tv_name") or it.get("title") or "Seriál"
                se = int(it.get("season") or 0)
                ep = int(it.get("episode") or 0)
                label = f"{tv} S{se:02d}E{ep:02d}"
                mtype = "episode"
            else:
                title = it.get("title") or "Bez názvu"
                yr = it.get("year") or ""
                label = f"{title} ({yr})" if yr else title
                mtype = "movie"
            li = xbmcgui.ListItem(label)
            info = {"title": it.get("title") or it.get("tv_name") or "", "mediatype": mtype}
            if mtype == "episode":
                info["tvshowtitle"] = it.get("tv_name") or ""
                info["season"] = int(it.get("season") or 0)
                info["episode"] = int(it.get("episode") or 0)
            elif it.get("year"):
                info["year"] = int(it["year"])
            li.setInfo("video", info)
            poster = _tmdb_img(it.get("poster_path") or "")
            fan = _tmdb_img(it.get("backdrop_path") or "", "original")
            art: dict[str, str] = {}
            thumb16 = fan or poster  # 16:9 backdrop preferováno pro landscape CW rail
            if thumb16:
                art["thumb"] = thumb16
                art["icon"] = thumb16
            if poster:
                art["poster"] = poster
            if fan:
                art["fanart"] = fan
                art["landscape"] = fan
            if art:
                li.setArt(art)
            try:  # progress bar v railu (Kodi resume point)
                if dur > 0 and pos > 0:
                    li.getVideoInfoTag().setResumePoint(pos, dur)
            except Exception:
                pass
            li.setProperty("rm_progress", str(pct))
            xbmcplugin.addDirectoryItem(
                HANDLE, _url(action="continue_watching", **_cw_url_params(it, idx)), li, isFolder=False)
        except Exception as exc:
            _log(f"[Rail] cw item skip: {exc}", xbmc.LOGDEBUG)
    _rail_end("movies")


def _rail_recent_series() -> None:
    """Rail 'Naposledy sledované seriály' — dedup per seriál (lokální, bez sítě).
    Klik vede rovnou do epizod poslední sledované sezóny (DRY s _recent_series)."""
    import json as _json
    try:
        series = _hist_module.get_recently_watched_series(limit=12)
    except Exception:
        series = []

    # Poster cache (tv_id → {p:poster, b:backdrop}). watch_history NEukládá poster,
    # tv_id je TMDb id → doplníme přes TMDb tv_details (jednou, pak z disku).
    import richmovie_paths
    pcache_path = str(richmovie_paths.personal_path("rail_series_posters.json"))
    pcache: dict = {}
    try:
        with open(pcache_path, encoding="utf-8") as fh:
            pcache = _json.load(fh) or {}
    except Exception:
        pcache = {}
    # seed z continue_watching (rychlé, lokální)
    try:
        for _it in (_hist_module.cw_load().get("items") or []):
            _tid = str(_it.get("tv_id") or "")
            _pp = _it.get("poster_path") or ""
            if _tid and _pp and not (pcache.get(_tid) or {}).get("p"):
                pcache[_tid] = {"p": _pp, "b": _it.get("backdrop_path") or ""}
    except Exception:
        pass
    # TMDb backfill pro seriály bez posteru v cache
    _missing = [s for s in series
                if not (pcache.get(str(s.get("tv_id") or "")) or {}).get("p") and s.get("tv_id")]
    _filled = 0
    if _missing:
        try:
            _k = richmovie_settings.get_tmdb_api_key()
            if _k:
                _tc = TMDb(_k, lang="cs-CZ")
                for s in _missing:
                    _tid = str(s.get("tv_id") or "")
                    try:
                        det = _tc.tv_details(int(_tid)) or {}
                        if det.get("poster_path"):
                            pcache[_tid] = {"p": det["poster_path"], "b": det.get("backdrop_path") or ""}
                            _filled += 1
                    except Exception as _e:
                        _log(f"[Rail] series backfill {_tid}: {_e}", xbmc.LOGDEBUG)
                if _filled:
                    # trvanlivý atomický zápis přes SSOT (3.5.123) — selhání loguje modul
                    richmovie_atomic.write_json(pcache_path, pcache)
        except Exception as _e:
            _log(f"[Rail] series backfill failed: {_e}", xbmc.LOGWARNING)
    _log(f"[Rail] recent_series poster backfill: {_filled}/{len(_missing)} doplněno",
             xbmc.LOGINFO)

    for s in series:
        try:
            tv_id = s.get("tv_id")
            tv_name = (s.get("tv_name") or "Seriál").strip()
            last_s = int(s.get("last_season") or 0)
            li = xbmcgui.ListItem(tv_name)
            li.setInfo("video", {"title": tv_name, "tvshowtitle": tv_name, "mediatype": "tvshow"})
            entry = pcache.get(str(tv_id) or "") or {}
            poster = _tmdb_img(entry.get("p") or "")
            fan = _tmdb_img(entry.get("b") or "", "original")
            if poster:
                art = {"poster": poster, "thumb": poster, "icon": poster}
                if fan:
                    art["fanart"] = fan
                li.setArt(art)
            else:
                li.setArt({"icon": "DefaultTVShows.png", "thumb": "DefaultTVShows.png"})
            xbmcplugin.addDirectoryItem(
                HANDLE,
                _url(action="tv_episodes", tv_id=tv_id, tv_name=tv_name, season=last_s or 1),
                li, isFolder=True)
        except Exception as exc:
            _log(f"[Rail] series item skip: {exc}", xbmc.LOGDEBUG)
    _rail_end("tvshows")


def _rail_collections() -> None:
    """Rail 'Kolekce' — kurátorované kolekce z lokálních JSON (bez sítě).
    DRY: sdílí data loader _iter_collections s CollectionsUI; renderuje tiše
    (žádná notifikace na prázdnu, na rozdíl od foreground show_collections_root)."""
    try:
        from richmovie_collections import CollectionsUI as _CUI
        entries = list(_CUI._iter_collections(ADDON))
    except Exception as exc:
        _log(f"[Rail] collections load failed: {exc}", xbmc.LOGDEBUG)
        entries = []
    for file_path, meta in entries:
        try:
            meta = meta or {}
            title = (meta.get("title")
                     or os.path.splitext(os.path.basename(file_path))[0]).strip()
            li = xbmcgui.ListItem(title)
            li.setInfo("video", {"title": title,
                                 "plot": (meta.get("subtitle") or "").strip(),
                                 "mediatype": "video"})
            art_icon = "DefaultFolder.png"
            try:
                png = os.path.splitext(file_path)[0] + ".png"
                if xbmcvfs.exists(png):
                    art_icon = png
            except Exception:
                pass
            li.setArt({"icon": art_icon, "thumb": art_icon,
                       "clearlogo": art_icon, "poster": art_icon})
            xbmcplugin.addDirectoryItem(
                HANDLE, _url(action="collections_browse", file=file_path), li, isFolder=True)
        except Exception as exc:
            _log(f"[Rail] collection item skip: {exc}", xbmc.LOGDEBUG)
    _rail_end("videos")


def _rail_ai() -> None:
    """Rail 'Pro tebe (AI tipy)' — AI doporučení s lokálním cache (TTL 6h) fallbackem.
    Home se nezasekne při Gate-down (offline-grace filozofie): renderuje cache;
    síťový refresh jen když je cache stará/chybí, vždy best-effort (chyba → stará cache).
    DRY: render přes _build_listitem z richmovie_recommendations (žádný busy dialog)."""
    import json as _json
    import time as _time
    import richmovie_paths
    cache_path = str(richmovie_paths.personal_path("rail_ai_cache.json"))
    items: list = []
    cache_ts = 0.0
    try:
        with open(cache_path, encoding="utf-8") as fh:
            _c = _json.load(fh) or {}
            items = _c.get("items") or []
            cache_ts = float(_c.get("ts") or 0)
    except Exception:
        items = []
    stale = (_time.time() - cache_ts) > 6 * 3600
    if stale or not items:
        # Φ5 (2026-07-06, DRY): fetch+dedup+zápis cache žije v richmovie_feed.
        # ai_rail_fetch_and_store (SSOT — stejnou cestou jde SWR refresh custom
        # UI). Sync volání = legacy widget invoker smí blokovat; po zápisu
        # re-read cache (fallback = stará cache, offline-grace filozofie).
        try:
            import richmovie_feed as _feed_ai
            if _feed_ai.ai_rail_fetch_and_store():
                try:
                    with open(cache_path, encoding="utf-8") as fh:
                        items = (_json.load(fh) or {}).get("items") or items
                except Exception:
                    pass
        except Exception as exc:
            _log(f"[Rail] ai fetch failed (cache fallback): {exc}", xbmc.LOGDEBUG)
    # Doplň chybějící TMDb poster (Gate enrichment gap) — PURE PRESENTATION,
    # NEmění RCAI logiku (titul/důvod/ranking netknuty). Známe tmdb_id + kind →
    # dotáhneme poster/backdrop a přepíšeme cache. Loguje výsledek (LOGINFO).
    _missing = [r for r in items if r.get("tmdb_id") and not r.get("poster_path")]
    if _missing:
        _filled = 0
        try:
            _k = richmovie_settings.get_tmdb_api_key()
            if _k:
                _tc = TMDb(_k, lang="cs-CZ")
                for rec in _missing:
                    try:
                        _kind = (rec.get("kind") or rec.get("media_type") or "").lower()
                        det = (_tc.tv_details(int(rec["tmdb_id"])) if _kind == "tv"
                               else _tc.details(int(rec["tmdb_id"]))) or {}
                        if det.get("poster_path"):
                            rec["poster_path"] = det["poster_path"]
                            _filled += 1
                        if det.get("backdrop_path") and not rec.get("backdrop_path"):
                            rec["backdrop_path"] = det["backdrop_path"]
                    except Exception as _e:
                        _log(f"[Rail] ai backfill {rec.get('tmdb_id')}: {_e}",
                                 xbmc.LOGDEBUG)
                if _filled:
                    try:  # přepiš cache s doplněnými postery (atomicky)
                        # R3-P2-5: zachovat PŮVODNÍ ts — poster-backfill nesmí
                        # „omladit" stale cache (potlačil by SWR refetch o 6 h)
                        _keep_ts = cache_ts
                        try:
                            with open(cache_path, encoding="utf-8") as fh:
                                _keep_ts = float((_json.load(fh) or {}).get("ts")
                                                 or cache_ts)
                        except Exception:
                            pass
                        richmovie_atomic.write_json(cache_path, {"ts": _keep_ts, "items": items})
                    except Exception:
                        pass
        except Exception as _e:
            _log(f"[Rail] ai backfill failed: {_e}", xbmc.LOGWARNING)
        _log(f"[Rail] ai poster backfill: {_filled}/{len(_missing)} doplněno",
                 xbmc.LOGINFO)

    try:
        from richmovie_recommendations import _build_listitem
        addon_id = ADDON.getAddonInfo("id")
        for rec in items:
            try:
                url, li, is_folder = _build_listitem(rec, HANDLE, addon_id)
                xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)
            except Exception as exc:
                _log(f"[Rail] ai item skip: {exc}", xbmc.LOGDEBUG)
    except Exception as exc:
        _log(f"[Rail] ai render failed: {exc}", xbmc.LOGDEBUG)
    _rail_end("movies")


def _client() -> WebshareClient:
    return _SESSION.client












# 2025-08-16 23:44 CEST (Europe/Prague)
def _ensure_login(
    cli: WebshareClient,
    interactive: bool = False,
) -> None:
    """
    Zajistí platné přihlášení k Webshare.cz, aktualizuje VIP stav v GUI
    a zobrazí *informační* toast o VIP stavu **maximálně 1× denně**.

    Výjimka: pokud do konce VIP zbývá **méně než 24 hodin** (tj. `vip_days < 1`),
    toast se zobrazuje při každém vstupu (stejně jako dříve) a denní zarážka se NEaktivuje.

    Implementační poznámky:
    - Nepoužíváme `datetime.datetime.strptime()` (odpadá riziko kolize a pádu).
      Pro "1× denně" ukládáme jen `vip_last_toast_date` ve formátu `YYYY-MM-DD`.
    - Pro debug navíc ukládáme i `vip_last_toast_iso` (ISO timestamp), ale NIKDE jej neparsujeme.
    - UI titulek a nastavení `vip_info` spravuje SessionManager.update_vip_status().

    Vedlejší efekty (nastavení doplňku):
      vip_last_toast_date : 'YYYY-MM-DD' – den, kdy byl toast naposledy zobrazen
      vip_last_toast_iso  : 'YYYY-MM-DDTHH:MM:SS+TZ' – pouze pro ladění
    """
    # 1) Login workflow (původní logika přes SessionManager)
    try:
        _SESSION.ensure_login(interactive=interactive)
    except APIError as e:
        # Česká věta podle kódu Webshare, ne technický text (Fable audit 03.09.2026, F-04).
        _modal(e.user_message)
        raise

    # 1b) Nastav _ws_logged flag pro dynamické tlačítko v settings
    if richmovie_settings.get_str("username").strip():
        richmovie_settings.write("_ws_logged", "true")

    # 2) Titulek + text toastu ze STAVU účtu (3.5.125, Fáze A) — žádný síťový
    #    dotaz v UI cestě; obnovu si `update_vip_status` vyžádá od služby.
    #    Do 3.5.124 tu byly DVA sekvenční dotazy na Webshare (15 s timeout každý).
    import richmovie_account_state as _account
    state = _SESSION.update_vip_status() if HANDLE >= 0 else _account.load()

    # 2b) 3.5.129 (incident PeterFM): přechod VIP → Free zjištěný službou čeká
    #     na JEDNORÁZOVÝ modální dialog — denní toast „Free účet" brácha přehlížel
    #     tři měsíce. Razítko se spotřebuje trvanlivě (stav, ne nastavení), takže
    #     dialog nikdy nevyskočí dvakrát ani po restartu.
    if HANDLE >= 0:
        lapsed = _account.consume_vip_lapse_notice()
        if lapsed is not None:
            _heading, _text = _account.free_block_message(lapsed)
            _modal(_text, _heading)
            _log_event("VIP_LAPSE_DIALOG", lapsed.get("username") or "")

    # 3) Bez známého stavu není co zobrazovat (první spuštění: služba ho doplní)
    vip_text = _account.toast_text(state)
    if not vip_text:
        return

    # 4) Zbývající dny VIP ze stavu (None = Free účet)
    days_left: int | None = _account.days_left(state)

    # 5) Výjimka: <24 h do konce VIP → zobrazuj vždy (bez denní zarážky)
    if days_left is not None and days_left < 1:
        _modal(vip_text, block=False)
        _log_event("VIP_TOAST", "ALWAYS_<24h")
        return

    # 6) Denní zarážka (1× denně) – ukládáme pouze datum v místním čase
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    last_date = (richmovie_settings.get_str("vip_last_toast_date") or "").strip()

    if last_date == today:
        _log_event("VIP_TOAST_SKIP", today)
        return

    # 7) Zobraz a zapiš dnešní datum (ISO navíc jen pro ladění — už neparsujeme)
    _modal(vip_text, block=False)
    richmovie_settings.write("vip_last_toast_date", today)
    try:
        richmovie_settings.write(
            "vip_last_toast_iso",
            datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        )
    except Exception:
        pass
    _log_event("VIP_TOAST_SHOWN", today)





def _update_vip_status(_unused_cli: WebshareClient) -> None:
    _SESSION.update_vip_status()




# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _ws_playback_blocked  (vytvořeno: 02.09.2026 22:05 CEST, Europe/Prague – 3.5.129)
# ---------------------------------------------------------------------------- #
def _ws_playback_blocked() -> bool:
    """Je Webshare přehrávání zablokované stavem účtu (Free)? Jednou per výpis.

    Rozhoduje SSOT `richmovie_account_state.playback_allowed` (autoritativní
    stav z Webshare, R2). Výpis položky NESKRÝVÁ — jen je označí a zařadí za
    Fastshare, aby uživatel viděl PROČ, ne prázdný seznam."""
    try:
        import richmovie_account_state as _account
        allowed, _reason = _account.playback_allowed(_account.load(), source="webshare")
        return not allowed
    except Exception as exc:
        _log(f"ws_playback_blocked: {exc!r}", xbmc.LOGWARNING)
        return False


# Prefix položky výpisu, kterou účet nemůže přehrát — SSOT textu je
# `richmovie_account_state` (sdílí ho legacy výpis i custom picker; Fable audit F-05).
from richmovie_account_state import WS_BLOCKED_LABEL_PREFIX  # noqa: E402


# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _order_ws_blocked_last  (vytvořeno: 02.09.2026 22:05 CEST, Europe/Prague – 3.5.129)
# ---------------------------------------------------------------------------- #
def _order_ws_blocked_last(rels: List[Release], ws_blocked: bool) -> List[Release]:
    """Stabilně přesune Webshare položky za ostatní zdroje, když je Webshare
    zablokovaný. Jen pořadí — NIKDY filtr (filter parity SSOT,
    feedback_addon_release_filter_is_ssot). Bez blokace vrací vstup beze změny."""
    if not ws_blocked:
        return rels
    return sorted(rels, key=lambda r: (getattr(r, "source", "webshare") or "webshare") == "webshare")


def _broken_sources() -> dict:
    """{ident: pozice} vadných souborů na tomto zařízení (SSOT `richmovie_source_health`)."""
    try:
        import richmovie_source_health as _sh
        return _sh.broken_map()
    except Exception:
        return {}


def _order_broken_last(rels: List[Release], broken: dict) -> List[Release]:
    """3.5.158: soubor, který opakovaně končí na stejném místě, stabilně za ostatní.
    Jen pořadí — NIKDY filtr (feedback_addon_release_filter_is_ssot)."""
    if not broken:
        return rels
    import richmovie_source_health as _sh
    return sorted(rels, key=lambda r: _sh.rank(getattr(r, "ident", ""), broken))


def _order_dv_unplayable_last(rels: List[Release]) -> List[Release]:
    """Noc 03.11.2026 (Φ3): Dolby Vision bez kompatibilní vrstvy na zařízení bez DV (černý obraz) stabilně za
    hratelné. Volá se MEZI `_order_ws_blocked_last` a `_order_broken_last` → stejné pořadí jako `_listing_sort_key`.
    Jen pořadí — NIKDY filtr (feedback_addon_release_filter_is_ssot)."""
    if _dv_supported():
        return rels
    return sorted(rels, key=lambda r: 1 if _dv_rank(r) == _rm_quality.DV_NO else 0)


# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _build_stream_li (upraveno: 13.12.2025 14:44 CET, Europe/Prague – FIX: nastavuje Label2 (pravý sloupec) z LabelFormatter.label_right;
#                                02.09.2026 22:05 CEST – 3.5.129: `ws_blocked` prefix)
# ---------------------------------------------------------------------------- #
def _stream_progress_decorate(li: "xbmcgui.ListItem", play_params: dict, progress: Optional[dict], ident: str) -> None:
    """SSOT postupu u položky streamu (4.0.3, A5/A6): stream, na kterém profil skončil, dostane značku
    „◐ pokračuj od 23:10“; každý stream rozkoukaného titulu nese revizi postupu v adrese a „Přehrát od začátku“
    v kontextovém menu. Navázání samo řeší `_play_resolve` (postup profilu)."""
    if not progress:
        return
    play_params["rev"] = _hist_module.progress_rev(progress)
    if ident and ident == str(progress.get("ident") or ""):
        try:
            li.setLabel("[COLOR %s]%s[/COLOR]  %s" % (_hist_module.EP_COLOR_PROGRESS, _hist_module.progress_mark(progress),
                                                    li.getLabel()))
        except Exception:
            pass
    try:
        _start = {k: v for k, v in play_params.items() if k not in ("action", "rev")}
        li.addContextMenuItems([("Přehrát od začátku", f"RunPlugin({_url(action='play_from_start', **_start)})")])
    except Exception:
        pass


def _play_from_start_action() -> None:
    """Kontextové menu streamu „Přehrát od začátku“ (4.0.3, A6): totéž přehrání bez navázání, přes pojistku
    jednoho spuštění (`richmovie_playback_dispatch.request` — jediné místo PlayMedia)."""
    _args = {k: v[0] for k, v in (dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}).items()
             if k != "action" and v}
    _args["from_start"] = "1"
    _rm_dispatch.request(_url(action="play", **_args), source="click", ident=_args.get("ident", ""))


def _build_stream_li(
    rel: Release,
    movie: dict | None = None,
    *,
    show_source_prefix: bool = False,
    size_pad_width: int = 0,
    quality_pad_width: int = 0,
    ws_blocked: bool = False,
    broken: dict | None = None,
) -> Tuple[str, xbmcgui.ListItem, bool]:
    """
    Beta.7 (2026-04-25): tabular column alignment params (forwarded to
    LabelFormatter.format). Caller (_list_releases) počítá max-width + has_fs
    napříč rels a předá sem, aby se quality+size sloupce zobrazily zarovnané
    pod sebou (U+2007 padding pro tabular figures fontů jako Estuary).

    3.5.129: `ws_blocked=True` (Free účet) → Webshare položka dostane prefix
    `WS_BLOCKED_LABEL_PREFIX`; klik pak skončí dialogem z `_resolve_webshare_stream`.

    [Aktualizováno: 2025-08-21 23:19 CEST (Europe/Prague)]
    Převede objekt `Release` na Kodi ListItem – zachovává původní vzhled a chování.
    Navíc přidává do kontextového menu položku "Stáhnout stream".

    • Pokud je k dispozici `movie` (TMDb), vložíme do play URL kontext (m_title, m_year, tmdb),
      aby se po přehrání zapsala Historie sledování.
    • Kontextové menu:
        - "Detail streamu" → RunPlugin(?action=detail&ident=…)
        - "Stáhnout stream" → RunPlugin(?action=download&ident=…&name=<název>&m_title&…)
    """
    info_txt = LabelFormatter.format(
        rel, movie=movie,
        show_source_prefix=show_source_prefix,
        size_pad_width=size_pad_width,
        quality_pad_width=quality_pad_width,
    )

    # — URL pro přehrání — pokud známe kontext filmu, pošleme ho dál
    # — Fastshare integrace (21.01.2026): přidáme source, fs_url, fs_hash —
    qs: dict[str, str] = _rm_play_params.for_release(rel, movie=movie)

    _movie_progress = None
    if movie and movie.get("id"):
        try:
            _movie_progress = _hist_module.progress_for_movie(movie.get("id"))
        except Exception:
            _movie_progress = None
    if _movie_progress:
        qs["rev"] = _hist_module.progress_rev(_movie_progress)
    url = _url(**qs)

    label_left = info_txt["label_left"]
    if ws_blocked and (getattr(rel, "source", "webshare") or "webshare") == "webshare":
        label_left = WS_BLOCKED_LABEL_PREFIX + label_left
    if broken:
        import richmovie_source_health as _sh_lbl
        label_left = _sh_lbl.label_prefix(getattr(rel, "ident", ""), broken) + label_left
    # Noc 03.11.2026 (Φ3): Dolby Vision, které tohle zařízení nepřehraje („⚠ DV“) / nejspíš nepřehraje („DV?“)
    label_left = _rm_quality.dv_label_prefix(_dv_rank(rel)) + label_left
    li = xbmcgui.ListItem(label_left)

    # ✅ NOVĚ: pravý sloupec (Label2)
    label_right = (info_txt.get("label_right") or "").strip()
    if label_right:
        try:
            li.setLabel2(label_right)
        except Exception:
            pass

    # art (zachován původní způsob)
    art = {}
    if movie:
        poster_path   = movie.get("poster_path") or ""
        backdrop_path = movie.get("backdrop_path") or ""
        if poster_path:
            art["poster"] = f"https://image.tmdb.org/t/p/w342{poster_path}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{poster_path}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
    li.setArt(art)

    # Beta.7 (2026-04-25): rozšířené info tagy pro Kodi info panel
    # (skin Estuary zobrazuje plot/runtime/rating/genre/cast vlevo pod posterem).
    # Bez plotu Kodi ukáže "Nejsou dostupné žádné informace". Movie kontext
    # má všechny TMDb metadata — musíme je správně předat.
    info_tags: dict[str, object] = {
        "title": (movie or {}).get("title", rel.name),
        "mediatype": "movie",
    }
    if movie:
        if movie.get("year"):
            try:
                info_tags["year"] = int(movie["year"])
            except (TypeError, ValueError):
                pass
        if movie.get("overview"):
            info_tags["plot"] = str(movie["overview"]).strip()
        if movie.get("original_title"):
            info_tags["originaltitle"] = str(movie["original_title"]).strip()
        # Tagline pokud je
        if movie.get("tagline"):
            info_tags["tagline"] = str(movie["tagline"]).strip()
        # Rating + votes
        try:
            _r = float(movie.get("vote_average") or movie.get("rating") or 0)
            if _r > 0:
                info_tags["rating"] = _r
        except (TypeError, ValueError):
            pass
        try:
            _v = int(movie.get("vote_count") or movie.get("votes") or 0)
            if _v > 0:
                info_tags["votes"] = _v
        except (TypeError, ValueError):
            pass
        # Runtime — preferuj movie.runtime (TMDb) nebo rel.est_min (MI2)
        try:
            _rt = int(movie.get("runtime") or 0)
        except (TypeError, ValueError):
            _rt = 0
        if not _rt:
            try:
                _rt = int(getattr(rel, "est_min", 0) or 0)
            except (TypeError, ValueError):
                _rt = 0
        if _rt > 0:
            info_tags["duration"] = _rt * 60  # Kodi očekává sekundy
        # Genre — TMDb genres list of dicts
        _genres = movie.get("genres") or []
        if isinstance(_genres, list):
            _gnames = [
                str(g.get("name") if isinstance(g, dict) else g).strip()
                for g in _genres if g
            ]
            _gnames = [g for g in _gnames if g]
            if _gnames:
                info_tags["genre"] = _gnames
        # Studios
        _studios = movie.get("production_companies") or []
        if isinstance(_studios, list):
            _snames = [
                str(s.get("name") if isinstance(s, dict) else s).strip()
                for s in _studios if s
            ]
            _snames = [s for s in _snames if s]
            if _snames:
                info_tags["studio"] = _snames
        # Cast (top N)
        _cast = movie.get("cast") or []
        if isinstance(_cast, list) and _cast:
            _cnames = []
            for c in _cast[:10]:
                if isinstance(c, dict):
                    n = c.get("name") or c.get("Name")
                    if n:
                        _cnames.append(str(n).strip())
                elif isinstance(c, str):
                    _cnames.append(c.strip())
            if _cnames:
                info_tags["cast"] = _cnames
        # Director
        _dir = movie.get("director")
        if _dir:
            info_tags["director"] = str(_dir).strip()
        # IMDb / TMDb IDs
        if movie.get("imdb_id"):
            info_tags["imdbnumber"] = str(movie["imdb_id"]).strip()
    # Plot fallback — pokud TMDb plot chybí, použij release name (lepší než
    # "Nejsou dostupné žádné informace").
    if not info_tags.get("plot"):
        info_tags["plot"] = (
            f"{rel.name}\n\n"
            f"Velikost: {rel.size_mb} MB | Kvalita: {rel.quality.upper()}"
        )
    li.setInfo("video", info_tags)

    if _movie_progress:
        _stream_progress_decorate(li, dict(qs), _movie_progress, str(rel.ident))
    # je to přehratelné
    li.setProperty("isPlayable", "true")
    if getattr(rel, "mediainfo", None):
        li.setProperty("richmovie.mediainfo", json.dumps(rel.mediainfo))

    # Beta.7 (2026-04-25): stream details pro Kodi info panel.
    # `addStreamInfo("video"|"audio"|"subtitle", {...})` napumpuje data do
    # standardního Kodi `streamdetails` který skin Estuary umí zobrazit
    # vlevo pod posterem (audio jazyk vlajky, subtitle jazyky, video
    # resolution + codec). Data čerpáme z MI2 cache (mi2_get_flags).
    try:
        from richmovie_engine import mi2_get_flags as _mi2_get_flags
        _mi2 = _mi2_get_flags(rel.ident) or {}

        # Video — height z MI2 preferenčně, fallback ws_height
        _vw = int(_mi2.get("video_w") or 0) or int(getattr(rel, "ws_width", 0) or 0)
        _vh = int(_mi2.get("video_h") or 0) or int(getattr(rel, "ws_height", 0) or 0)
        _dur = int(_mi2.get("duration_s") or 0)
        _video_si: dict = {}
        if _vw > 0:
            _video_si["width"] = _vw
        if _vh > 0:
            _video_si["height"] = _vh
        if _dur > 0:
            _video_si["duration"] = _dur
        if _video_si:
            li.addStreamInfo("video", _video_si)

        # Audio — pro každý detekovaný jazyk addStreamInfo (Kodi zobrazí
        # vlajky / language ikony v info panelu)
        _aud = _mi2.get("aud") or []
        for _lang in _aud:
            _l = str(_lang or "").strip().lower()[:2]
            if _l and _l not in ("?", "un"):
                li.addStreamInfo("audio", {"language": _l})

        # Subtitles — totéž
        _sub = _mi2.get("sub") or []
        for _lang in _sub:
            _l = str(_lang or "").strip().lower()[:2]
            if _l and _l not in ("?", "un"):
                li.addStreamInfo("subtitle", {"language": _l})
    except Exception:
        # MI2 may not be loaded yet; skin fallback to no streamdetails is OK
        pass

    # Kontextové menu (🆕 Stáhnout stream s kontextem filmu)
    safe_name = quote_plus((movie or {}).get("title", rel.name) or "")

    # Sestavíme query pro ?action=download včetně filmového kontextu, pokud ho máme
    dl_qs = {"action": "download", "ident": rel.ident, "name": safe_name}

    # 22.01.2026 – Fastshare parametry pro download
    if getattr(rel, "source", "webshare") == "fastshare":
        dl_qs["source"] = "fastshare"
        if getattr(rel, "fs_download_url", None):
            dl_qs["fs_url"] = rel.fs_download_url
        if getattr(rel, "fs_hash", None):
            dl_qs["fs_hash"] = rel.fs_hash

    if movie:
        if movie.get("title"):
            dl_qs["m_title"] = movie["title"]
        if movie.get("year"):
            dl_qs["m_year"] = str(movie["year"])
        if movie.get("id"):
            dl_qs["tmdb"] = str(movie["id"])

    li.addContextMenuItems([
        ("Detail streamu",  f"RunPlugin({_url(action='detail', ident=rel.ident)})"),
        ("Stáhnout stream", f"RunPlugin({_url(**dl_qs)})"),
    ])

    return url, li, False






def _download_stream() -> None:
    """
    [Aktualizováno: 2025-08-21 23:19 CEST (Europe/Prague)]
    Spouštěč stahování z kontextového menu (`?action=download`).

    • Bezpečně načte parametry z URL: ident (povinné), name (volitelné),
      a dále filmový/seriálový kontext (m_title, m_year, tmdb, tv_name, season, episode, ep_title) pokud je k dispozici.
    • Lazy‑importuje `start_download_from_gui` z `richmovie_downloads` a předá vše dál jako kwargs.
    • Případné chyby zobrazí jako modální dialog a **nikdy neshodí** plugin.
    """
    try:
        # 1) parametry
        args: Dict[str, List[str]] = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        ident = (args.get("ident") or [""])[0].strip()
        raw_name = (args.get("name") or [""])[0]

        try:
            name = urllib.parse.unquote_plus(raw_name)
        except Exception:
            name = raw_name

        if not ident:
            _modal("Chybí ident streamu.")
            if HANDLE >= 0:
                try:
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                except Exception:
                    pass
            return

        # 2) kontext pro hlavičku dialogu
        meta: Dict[str, Any] = {}
        # film
        m_title = (args.get("m_title") or [""])[0].strip()
        m_year  = (args.get("m_year")  or [""])[0].strip()
        tmdb_id = (args.get("tmdb")    or [""])[0].strip()
        if m_title:
            meta["m_title"] = m_title
        if m_year:
            meta["m_year"] = m_year
        if tmdb_id:
            meta["tmdb"] = tmdb_id
        # seriál (pokud by se v budoucnu posílal)
        tv_name  = (args.get("tv_name")  or [""])[0].strip()
        season_s = (args.get("season")   or [""])[0].strip()
        episode_s= (args.get("episode")  or [""])[0].strip()
        ep_title = (args.get("ep_title") or [""])[0].strip()
        if tv_name:
            meta["tv_name"] = tv_name
        if ep_title:
            meta["ep_title"] = ep_title
        try:
            if season_s:
                meta["season"] = int(season_s)
            if episode_s:
                meta["episode"] = int(episode_s)
        except Exception:
            pass  # když nepůjdou převést na int, prostě je nepošleme

        # 22.01.2026 – Fastshare parametry pro stahování
        source = (args.get("source") or ["webshare"])[0].strip()
        fs_url = (args.get("fs_url") or [""])[0].strip()
        fs_hash = (args.get("fs_hash") or [""])[0].strip()
        if source == "fastshare":
            meta["source"] = "fastshare"
            if fs_url:
                meta["fs_url"] = fs_url
            if fs_hash:
                meta["fs_hash"] = fs_hash

        # 3) lazy import + spuštění downloaderu
        try:
            from richmovie_downloads import start_download_from_gui  # import uvnitř kvůli závislostem
            start_download_from_gui(ident, name, **meta)
        except Exception as run_err:
            _net_error_ui(run_err, heading="Stahování")

    except Exception:
        _log("_download_stream(): unexpected error", xbmc.LOGERROR)





# 2025-08-19 15:26 CEST (Europe/Prague)
def _download_action() -> None:
    """
    Handler pro `action=download`.

    • Bezpečně načte parametry z URL (`ident`, `name`)
    • Lazy‑importuje `start_download_from_gui` z modulu `richmovie_downloads`
      → žádný kruhový import při startu GUI.
    • Předá (ident, name) – očekávaná signatura.
    • Chyby zobrazí jako modální dialog.
    """
    try:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        ident = (args.get("ident", [""])[0] or "").strip()
        name  = (args.get("name",  [""])[0] or "").strip()
        if not ident:
            _modal("Chybí ident streamu.");  return
        try:
            # Lazy import – vyhneme se ImportError: partially initialized module
            from richmovie_downloads import start_download_from_gui  # type: ignore
            start_download_from_gui(ident, name)
        except Exception as run_err:
            _net_error_ui(run_err, heading="Stahování")
    except Exception:
        # nikdy nesmí shodit celý plugin
        _log("_download_action(): unexpected error", xbmc.LOGERROR)





def _stream_detail(ident: str) -> None:
    """
    Otevře dialog s detailními technickými informacemi o souboru (MediaInfo).
    Využívá cache SearchEngine → žádné další síťové volání.
    """
    mi = _ENGINE.get_mediainfo(ident)
    text = _format_mediainfo(mi or {})
    xbmcgui.Dialog().textviewer("Detail streamu", text)





def _auto_cleanup_logs() -> None:
    """
    Projde rotační i "per‑search" logy a smaže ty, které jsou starší
    než počet dní nastavený v Settings → "Uchovávat logy (dní)".
    Nastavená hodnota 0 = funkce vypnuta.
    """
    try:
        days = int(richmovie_settings.get_str("logs_retention_days") or "0")
    except ValueError:
        days = 0
    if days <= 0:
        return

    cutoff = datetime.datetime.now() - datetime.timedelta(days=days)
    # 1) globální rotační log + .backup
    for p in (_LOG_PATH, _LOG_PATH + ".1"):
        if os.path.exists(p) and datetime.datetime.fromtimestamp(
            os.path.getmtime(p)
        ) < cutoff:
            try:
                os.remove(p)
            except Exception:
                pass

    # 2) per‑search logy
    log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
    if os.path.isdir(log_dir):
        for fname in os.listdir(log_dir):
            fp = os.path.join(log_dir, fname)
            try:
                if datetime.datetime.fromtimestamp(
                    os.path.getmtime(fp)
                ) < cutoff:
                    os.remove(fp)
            except Exception as exc:
                _log(f"log cleanup delete failed ({fname}): {exc}", xbmc.LOGDEBUG)
        # prázdný adresář smažeme
        try:
            if not os.listdir(log_dir):
                os.rmdir(log_dir)
        except Exception as exc:
            _log(f"log dir rmdir failed: {exc}", xbmc.LOGDEBUG)





# --------------------------------------------------------------------------- #
#  WS_LOGIN — Apple-like dialog (z Settings action button)
# --------------------------------------------------------------------------- #
def _ws_login() -> None:
    """Interaktivni prihlaseni/zmena uctu Webshare.cz pres dialogy."""
    dlg = xbmcgui.Dialog()
    current_user = richmovie_settings.get_str("username").strip()

    if current_user:
        heading = "Změnit účet Webshare"
        default_user = current_user
    else:
        heading = "Přihlášení k Webshare"
        default_user = ""

    new_user = dlg.input(heading + " — uživatelské jméno", defaultt=default_user)
    if not new_user:
        return

    new_pw = dlg.input("Heslo pro " + new_user, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not new_pw:
        return

    # Φ2 (29.09.2026): akce z nastavení nemá kolečko Kodi — průběh do 0,1 s místo ticha,
    # chyba jako věta podle kódu Webshare (`APIError.user_message`), ne `str(e)`.
    try:
        with _rm_fb.working("Přihlašuji k Webshare…"):
            cli = WebshareClient()
            cli.login(new_user.strip(), new_pw.strip())
    except Exception as e:
        _rm_fb.error(e, heading="Přihlášení k Webshare")
        return

    # 3.5.124: identita All-or-Nothing s ověřením (Kodi umí zápis tiše ztratit).
    if not richmovie_settings.write_identity(new_user.strip(), new_pw.strip(), cli.token):
        dlg.ok("Chyba přihlášení",
               "Přihlášení proběhlo, ale nepodařilo se ho uložit. Restartuj prosím Kodi a zkus to znovu.")
        return
    richmovie_settings.write("_ws_logged", "true")

    # 3.5.125: stav účtu do SSOT (`account_state.json` + zrcadlo `vip_info`).
    # Uživatel právě klikl „Přihlásit" v nastavení — jeden dotaz je tu na místě;
    # když selže, stav si dotáhne služba (žádost o obnovu), nic se nevymýšlí.
    import richmovie_account_state as _account
    try:
        with _rm_fb.working("Načítám stav účtu…"):
            _account.save(_account.normalize(cli.account_info(), source="login"))
    except Exception as _acc_exc:
        _log(f"[Webshare] account_info po loginu selhal: {_acc_exc}", xbmc.LOGWARNING)
        _account.request_refresh(_account.REASON_LOGIN)

    _SESSION.client.token = cli.token
    _rm_fb.info("Přihlášeno k Webshare.cz")


# --------------------------------------------------------------------------- #
#  FS_LOGIN — přihlášení k Fastshare (z Settings action button)
# --------------------------------------------------------------------------- #
def _fs_login() -> None:
    """Interaktivní přihlášení/změna účtu Fastshare.cz přes dialogy."""
    global _FS_SESSION
    dlg = xbmcgui.Dialog()
    current_user = richmovie_settings.get_str("fs_username").strip()

    if current_user:
        heading = "Změnit účet Fastshare"
        default_user = current_user
    else:
        heading = "Přihlášení k Fastshare"
        default_user = ""

    new_user = dlg.input(heading + " — uživatelské jméno", defaultt=default_user)
    if not new_user:
        return

    new_pw = dlg.input("Heslo pro " + new_user, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not new_pw:
        return

    try:
        with _rm_fb.working("Přihlašuji k Fastshare…"):
            client = FastshareClient()
            client.login(new_user.strip(), new_pw.strip())
    except FastshareError as e:
        _rm_fb.error(e, heading="Přihlášení k Fastshare")
        richmovie_settings.write("_fs_logged", "false")
        richmovie_settings.write("fs_info", "Chyba přihlášení")
        return

    richmovie_settings.write("fs_username", new_user.strip())
    richmovie_settings.write("fs_password", new_pw.strip())
    richmovie_settings.write("fs_hash", client.hash)
    richmovie_settings.write("_fs_logged", "true")
    richmovie_settings.write("fs_info", "Přihlášeno ({})".format(new_user.strip()))

    # Reinicializace session
    _FS_SESSION = FastshareSessionManager(ADDON)
    _FS_SESSION.client.hash = client.hash

    _rm_fb.info("Přihlášeno k Fastshare.cz")


# --------------------------------------------------------------------------- #
#  FASTSHARE ONBOARDING — jednorazovy Apple-like dialog
# --------------------------------------------------------------------------- #
def _fs_onboard_login() -> bool:
    """
    Interaktivní FastShare login flow (sdílený mezi onboardingem a menu).

    Returns:
        True pokud se uživatel úspěšně přihlásil
    """
    global _FS_SESSION
    dlg = xbmcgui.Dialog()
    max_attempts = 3

    for attempt in range(max_attempts):
        user = dlg.input(
            "Fastshare — uživatelské jméno",
            defaultt=richmovie_settings.get_str("fs_username").strip(),
        )
        if not user:
            return False

        pw = dlg.input(
            "Fastshare — heslo",
            option=xbmcgui.ALPHANUM_HIDE_INPUT,
        )
        if not pw:
            return False

        try:
            with _rm_fb.working("Přihlašuji k Fastshare…"):
                client = FastshareClient()
                client.login(user.strip(), pw.strip())
        except FastshareError as e:
            # Φ2 (29.09.2026): věta podle kódu chyby (`FastshareLoginError.user_message`) nebo třídy
            # síťové chyby; technický text jen do logu
            _log(f"fs onboarding login failed: {e!r}", xbmc.LOGWARNING)
            reason = _net_error_message(e)[0]
            remaining = max_attempts - attempt - 1
            if remaining > 0:
                dlg.ok(
                    "Přihlášení se nezdařilo",
                    reason + "\n\nZkus to prosím znovu."
                )
                continue
            else:
                dlg.ok(
                    "Přihlášení se nezdařilo",
                    reason + "\n\nÚdaje můžeš zadat později v nastavení doplňku."
                )
                return False

        # Úspěch
        richmovie_settings.write("fs_username", user.strip())
        richmovie_settings.write("fs_password", pw.strip())
        richmovie_settings.write("fs_hash", client.hash)
        richmovie_settings.write("_fs_logged", "true")
        richmovie_settings.write("fs_info", "Přihlášeno ({})".format(user.strip()))

        _FS_SESSION = FastshareSessionManager(ADDON)
        _FS_SESSION.client.hash = client.hash

        dlg.ok(
            "Fastshare",
            "Přihlášení proběhlo úspěšně!\n\n"
            "Výsledky z Fastshare se nyní budou zobrazovat\n"
            "automaticky při každém vyhledávání."
        )
        return True

    return False


def _fs_has_working_login() -> bool:
    """Vrátí True pokud má uživatel funkční FastShare (vlastní nebo Gate)."""
    # Vlastní credentials
    if (richmovie_settings.get_str("fs_username").strip()
            and richmovie_settings.get_str("fs_password").strip()
            and richmovie_settings.get_str("fs_hash").strip()):
        return True
    # Gate credentials
    try:
        import richmovie_gate
        creds = richmovie_gate.get_fastshare_credentials()
        if creds and creds.get("username") and creds.get("password"):
            return True
    except ImportError:
        pass
    return False


def _fs_onboarding() -> None:
    """
    Jednorazový onboarding dialog pro FastShare.

    Zobrazí se pouze jednou (flag fs_onboard_done). Ptá se uživatele,
    zda má vlastní FastShare účet. Pokud ano, provede přihlášení.
    """
    # Již zobrazeno → nic
    if richmovie_settings.get_str("fs_onboard_done") == "1":
        return

    # Už má funkční FastShare → označit jako hotové, nezobrazovat
    if _fs_has_working_login():
        richmovie_settings.write("fs_onboard_done", "1")
        return

    dlg = xbmcgui.Dialog()

    answer = dlg.yesno(
        "Fastshare.cz",
        "Máte vlastní účet u Fastshare.cz?\n\n"
        "Fastshare je prémiová služba, která rozšiřuje\n"
        "nabídku filmů a seriálů v RichMovie.\n\n"
        "Pokud účet nemáte, nic se neděje — RichMovie\n"
        "funguje skvěle i bez něj.",
        nolabel="Nemám, pokračovat",
        yeslabel="Ano, přihlásit se",
    )

    if answer:
        _fs_onboard_login()

    # Vždy označit jako zobrazeno (ať už se přihlásil nebo ne)
    richmovie_settings.write("fs_onboard_done", "1")


def _clear_logs() -> None:
    """
    Vymaže *veškeré* logy doplňku (globální i per‑search) a zobrazí notifikaci.
    """
    ok = xbmcgui.Dialog().yesno(
        "Vymazat logy",
        "Opravdu chcete smazat vsechny log soubory doplnku?",
    )
    if not ok:
        return
    try:
        for p in (_LOG_PATH, _LOG_PATH + ".1"):
            if os.path.exists(p):
                os.remove(p)

        log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
        if os.path.isdir(log_dir):
            shutil.rmtree(log_dir, ignore_errors=True)

        _notif("Log soubory byly vymazány.")
        _log_event("LOGS_CLEARED")
    except Exception as e:
        _net_error_ui(e, heading="Mazání logů")



# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _reset_settings (upraveno: 13.12.2025 12:39 CET, Europe/Prague – FIX: Kodi yesno kompatibilita (2 řádky), aby reset nastavení nepadal)
# ---------------------------------------------------------------------------- #
def _reset_settings() -> None:
    """
    Smaže celou složku addon_data → doplněk se po restartu chová jako nový.
    """
    # DŮLEŽITÉ: u některých Kodi buildů má Dialog().yesno() jen 2 textové řádky,
    # proto nepředáváme 3./4. řádek zvlášť – sloučíme text do 2 řádků.
    ok = xbmcgui.Dialog().yesno(
        "Reset RichMovie",
        "Tato akce vymaže veškeré nastavení doplňku, včetně přihlašovacích údajů a lokální cache.",
        "Chcete opravdu pokračovat?",
        yeslabel="Ano, smazat",
        nolabel="Ne",
    )
    if not ok:
        return

    ad_path = Path(
        xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.richmovie"
        )
    ).resolve()

    try:
        if ad_path.exists():
            shutil.rmtree(ad_path)

        _log_event("RESET_SETTINGS_OK", str(ad_path))

        # Notifikace (best effort)
        try:
            fn = globals().get("_notif")
            if callable(fn):
                try:
                    fn("Nastavení vymazáno – restartuji doplněk")  # type: ignore[misc]
                except Exception:
                    pass
        except Exception:
            pass

    except Exception as exc:
        _log_event("RESET_SETTINGS_ERR", str(exc))

        # Notifikace chyby (best effort)
        try:
            fn = globals().get("_notif")
            if callable(fn):
                try:
                    fn(f"Chyba při mazání: {exc}", xbmcgui.NOTIFICATION_ERROR)  # type: ignore[misc]
                except Exception:
                    pass
        except Exception:
            pass
        return

    sys.exit()  # ukončí doplněk, Kodi ho po zavření menu načte znovu



# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _reset_search_caches (upraveno: 13.12.2025 17:19 CET, Europe/Prague – resetuje i mi2_cache.json (MI2 jazykové hinty))
# ---------------------------------------------------------------------------- #
def _reset_search_caches() -> None:
    """
    Reset cache vyhledávání (bez mazání nastavení doplňku).

    Zjednodušené UX:
        • žádný potvrzovací dialog
        • na konci jen toast "Cache vymazána" (případně "částečně")

    Cache:
        • search_cache.json  (disk + RAM instance, pokud existuje)
        • nextup_cache.json  (disk + RAM instance + lru_cache singleton)
        • mi2_cache.json     (disk + RAM MI2 hinty – jazykové ✓)
        • NEXT_CACHE         (RAM)
    """
    try:
        _log_event("CACHE_RESET_BEGIN", {"profile_dir": str(PROFILE_DIR), "log_path": _LOG_PATH})
    except Exception:
        pass

    # --- RESET (disk + RAM) ---
    next_cache_before = None
    nextup_ram_before = None
    search_ram_before = None
    mi2_ram_before = None
    mi2_disk_before = None

    nextup_file_ok = False
    search_file_ok = False
    mi2_file_ok = False
    lru_cleared = False

    # 1) NEXT_CACHE (RAM)
    try:
        with NEXT_CACHE_LOCK:
            next_cache_before = len(NEXT_CACHE)
            NEXT_CACHE.clear()
    except Exception:
        pass

    # 2) Next-Up window props (best effort)
    try:
        win = xbmcgui.Window(10000)
        for prop in (
            "richmovie.nextup.nav_inflight",
            "richmovie.nextup.nav_pending",
            "richmovie.nextup.nav_url",
            "richmovie.nextup.expected_key",
            "richmovie.nextup.expected_url",
            "richmovie.nextup.toast_key",
        ):
            try:
                win.clearProperty(prop)
            except Exception:
                pass
    except Exception:
        pass

    # 3) nextup_cache.json (disk + RAM + lru_cache singleton)
    try:
        c = _disk_nextup_cache()
        try:
            c._load()
            nextup_ram_before = len(getattr(c, "_data", {}) or {})
        except Exception:
            pass

        # RAM clear hned teď
        try:
            with c._lock:
                c._data = {}
                c._loaded = True
        except Exception:
            pass

        # disk clear
        try:
            import richmovie_paths as _rp_paths
            with open(_rp_paths.personal_path("nextup_cache.json"), "w", encoding="utf-8") as fh:
                json.dump({}, fh, ensure_ascii=False, indent=2)
            nextup_file_ok = True
        except Exception as exc:
            _log(f"nextup_cache disk clear failed: {exc}", xbmc.LOGDEBUG)

        # shodit lru_cache singleton
        try:
            _disk_nextup_cache.cache_clear()  # type: ignore[attr-defined]
            lru_cleared = True
        except Exception:
            pass

    except Exception as e:
        try:
            _log_event("CACHE_RESET_NEXTUP_ERR", str(e))
        except Exception:
            pass

    # 4) search_cache.json (disk + RAM)
    try:
        sc = None
        hm = sys.modules.get("richmovie_helpers")
        if hm is not None:
            sc = getattr(hm, "SEARCH_CACHE", None)
        if sc is None:
            em = sys.modules.get("richmovie_engine")
            if em is not None:
                sc = getattr(em, "SEARCH_CACHE", None)

        if sc is not None:
            try:
                sc._load()
                search_ram_before = len(getattr(sc, "_data", {}) or {})
            except Exception:
                pass

            try:
                with sc._lock:
                    sc._data = {}
                    sc._loaded = True
                    try:
                        sc._flush_locked()
                    except Exception:
                        pass
            except Exception:
                pass

        # disk clear (i kdyby sc nebyla dostupná)
        try:
            with open(PROFILE_DIR / "search_cache.json", "w", encoding="utf-8") as fh:
                json.dump({}, fh, ensure_ascii=False, indent=2)
            search_file_ok = True
        except Exception as exc:
            _log(f"search_cache disk clear failed: {exc}", xbmc.LOGDEBUG)

    except Exception as e:
        try:
            _log_event("CACHE_RESET_SEARCH_ERR", str(e))
        except Exception:
            pass

    # 5) MI2 cache (jazykové hinty ✓) – RAM + disk
    try:
        em = sys.modules.get("richmovie_engine")
        if em is not None:
            fn = getattr(em, "mi2_clear_cache", None)
            if callable(fn):
                res = fn() or {}
                mi2_ram_before = res.get("mi2_ram_before")
                mi2_disk_before = res.get("mi2_disk_before")
                mi2_file_ok = bool(res.get("mi2_file_ok"))
            else:
                # fallback: disk-only
                try:
                    with open(PROFILE_DIR / "mi2_cache.json", "w", encoding="utf-8") as fh:
                        json.dump({}, fh, ensure_ascii=False, indent=2)
                    mi2_file_ok = True
                except Exception:
                    pass
        else:
            # fallback: disk-only
            try:
                with open(PROFILE_DIR / "mi2_cache.json", "w", encoding="utf-8") as fh:
                    json.dump({}, fh, ensure_ascii=False, indent=2)
                mi2_file_ok = True
            except Exception:
                pass

    except Exception as e:
        try:
            _log_event("CACHE_RESET_MI2_ERR", str(e))
        except Exception:
            pass

    stats = {
        "next_cache_ram_before": next_cache_before,
        "nextup_ram_before": nextup_ram_before,
        "search_ram_before": search_ram_before,
        "mi2_ram_before": mi2_ram_before,
        "mi2_disk_before": mi2_disk_before,
        "nextup_file_ok": nextup_file_ok,
        "search_file_ok": search_file_ok,
        "mi2_file_ok": mi2_file_ok,
        "lru_cleared": lru_cleared,
    }

    try:
        _log_event("CACHE_RESET_DONE", stats)
    except Exception:
        pass

    # Toast výsledek (bez dialogů)
    try:
        if nextup_file_ok and search_file_ok and mi2_file_ok:
            _rm_notif("Cache vyhledávání vymazána.", xbmcgui.NOTIFICATION_INFO, 3000, "RichMovie")
        else:
            _rm_notif(
                "Cache vymazána částečně – mrkni do richmovie.log (CACHE_RESET_*).",
                xbmcgui.NOTIFICATION_WARNING,
                4500,
                "RichMovie",
            )
    except Exception:
        pass

    # návrat do kořene
    try:
        _root()
    except Exception:
        pass




def _url(**qs) -> str:
    """
    Postaví URL volání vlastního pluginu.

    Příklad:
        _url(action="play", ident="ABC123")  →
        plugin://plugin.video.richmovie/?action=play&ident=ABC123
    """
    return f"plugin://{ADDON.getAddonInfo('id')}/?{urlencode(qs)}"





# ---------------------------------- POZNÁMKA -------------------------------- #
# `_install_collections_blocking` (≈575 řádků, 2025-08 → 3.5.117) byl v 3.5.118
# (2026-08-21) extrahován do `richmovie_collections_install.py` — testovatelný
# modul s All-or-Nothing kontraktem, guardem a typovanými chybami. Start viz
# `_root()` za úspěšným `gate_auth`.
# ---------------------------------------------------------------------------- #


# _install_local_tmdb_blocking ODSTRANENO (Faze CD, 3.5.128): sken lokalnich
# souboru + TMDb parovani bezi na Gate (app/local/scanner.py) primo na NASu,
# inkrementalne. Doplnek cte jen lokalni kopii katalogu (richmovie_local_catalog).


# „Richie aktualizoval DD.MM.RRRR“ v titulku menu: SSOT `richmovie_publish_info` (Φ3, 29.09.2026) —
# síť běží ve službě, root jen čte uložený stav (dřív GitHub dotaz na UI cestě menu).


# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _root (upraveno: 2025-12-28 01:36 CET (Europe/Prague) – přidána položka "ČSFD.cz - TV tipy dne" pod "Reset cache vyhledávání"; zachováno vše původní včetně service_warm triggeru, lokálních LAN souborů a sezónní Vánoční kolekce)
# ---------------------------------------------------------------------------- #
def _root() -> None:
    """
    2025-12-28 01:36 CET (Europe/Prague)

    Kořenové menu doplňku – pořadí a logika beze změn.

    NOVĚ (sezónní zkratka):
        • V období 1.12. až 8.1. (včetně) se zobrazí úplně nahoře speciální položka:
          "Vánoční kolekce" → otevře konkrétní kolekci JSON (stromovou/flat dle souboru).
        • Mimo toto období bude kolekce dostupná pouze standardně v "Kolekce".

    NOVĚ (TMDb warm-up trigger):
        • Při otevření RichMovie (root menu) se zapíše trigger soubor do addon_data:
          tmdb_warm_trigger.json (timestamp).
        • `richmovie_warm` (vlákno služby service_nextup, 3.5.130) si to přečte a provede
          warm-up jen pokud má smysl (nejvýš 1× za 12 h per zařízení, jen ONLINE).

    NOVĚ (Lokální soubory / LAN):
        • Po přihlášení do Webshare se (jen pro vybrané Webshare účty) zobrazí položka:
          "Soukromá databáze na NAS serveru" → SMB browser (share na domácím PC).
        • Whitelist + SMB přístup jsou natvrdo v richmovie_local_files.py.

    ČSFD.cz:
        • Složka "ČSFD" pod "Reset cache vyhledávání":
          → "TV tipy dne" (scrape /televize/ + TMDb párování)
          → "Novinky z ČSFD.cz" (trailery/rozhovory z homepage, servírované přes Gate)
        • Ikona: resources/media/icons/csfd_tv_tipy.png

    Položky (standardní):
        1)  Hledat film
        2)  Hledat seriál
        3)  Soukromá databáze na NAS serveru           (jen pro vybrané účty)
        4)  Reset cache vyhledávání
        5)  ČSFD
        6)  Doporučit od RichMovie A.I.
        7)  Historie sledování
        8)  Historie hledání
        9)  Kolekce
        10) Seriály - Trendy dnes
        11) Seriály - TOP hodnocené
        12) Filmy - Trendy dnes
        13) Filmy - TOP hodnocené
        14) Žánry
        15) Přímé hledání ve Webshare
        17) Vyhledat hudbu
    """

    # — instalátor kolekcí: od 3.5.118 se spouští AŽ PO úspěšném gate_auth
    #   (viz níže, větev AUTH_OK). Do 3.5.117 startoval tady — před přihlášením
    #   k Webshare i před Gate authem → na čerstvé instalaci 2629× HTTP 403 a
    #   otrávená negativní cache (incident gunžik 21.08.2026). Modul:
    #   `richmovie_collections_install` (guard, All-or-Nothing, typované chyby).

    # — footprint cache (text/backdrops/loga) se loguje ve službě po warm-upu (`richmovie_warm`,
    #   Φ3 29.09.2026): v rootu stál 0,6–2,5 s při každém otevření menu (audit A07 F4)

    # — původní housekeeping —
    _ensure_internet_async()
    _auto_cleanup_logs()  # nahrazuje staré _ndjson_trace_init()

    # — uvítací sekvence = JEDEN proces (3.5.146, `richmovie_onboarding`): Kodi spouští root
    #   při startu 2× a do 3.5.145 se dialogy obou běhů proložily (chooser profilu PŘED
    #   přihlášením, uvítáním a FastShare). Druhý běh počká, až držitel dokončí sekvenci,
    #   a projde ji bez dialogů. Pořadí kroků = `richmovie_onboarding.STEPS`, profil poslední.
    import richmovie_onboarding as _onboarding
    _ob = _onboarding.begin()
    # Držení sekvence musí skončit VŽDY — i při výjimce: jinak by keepalive vlákno drželo claim
    # a každý další start by čekal na jeho vypršení (Fable audit 09.09.2026).
    try:
        if _ob.aborted:
            # Kodi se vypíná (abort během čekání na držitele) — žádné přihlašování ani síť
            # (cross-check Flash F10.3 09.09.2026).
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        # — login k Webshare + VIP status v GUI —
        cli = _client()
        try:
            _ensure_login(cli, interactive=_ob.interactive)
        except APIError as e:
            if _ob.interactive:
                _net_error_ui(e, heading="Přihlášení k Webshare")   # Φ2: věta podle kódu, ne str(e)
            else:
                _log(f"[Onboarding] přihlášení bez dialogu selhalo (držitel sekvence běží): {e}", xbmc.LOGINFO)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        # ⚠️ ZACHOVÁNO: po úspěšném loginu aktualizuj VIP (toast o MediaInfo zrušen, Φ3)
        _update_vip_status(cli)

        # 3.5.147 (Φ3 / D4): vedlejší síťová práce root menu (hlášení stavu, flush pádů, plán
        # instalátoru kolekcí, sync katalogu NASu) jen JEDNOU za 30 s napříč souběžnými běhy —
        # Kodi spouští root při startu 2× a dřív se všechno dělalo dvakrát.
        _side_work = _onboarding.claim_side_work()
        if not _side_work:
            _log("[Root] vedlejší práci udělal jiný běh v posledních %.0f s → přeskočeno"
                 % _onboarding.SIDE_WORK_TTL_S, xbmc.LOGDEBUG)

        # === Resolve canonical WS username (user may have entered email) ===
        _gate_ws_user = richmovie_settings.get_str("username").strip()
        _gate_ws_pw = richmovie_settings.get_str("password").strip()
        if cli.token and "@" in _gate_ws_user:
            # 3.5.125: kanonické jméno nejdřív ze stavu účtu (bez sítě); dotaz na
            # Webshare jen když stav ještě neexistuje (první spuštění po e-mail loginu).
            import richmovie_account_state as _account
            _canonical = ((_account.load() or {}).get("username") or "").strip()
            if not _canonical:
                try:
                    _canonical = (cli.account_info().get("username") or "").strip()
                except Exception as _e:
                    _log("[Gate] account_info failed: %s" % _e, xbmc.LOGWARNING)
            if _canonical:
                _log("[Gate] Email login detected, resolved to: %s" % _canonical, xbmc.LOGINFO)
                _gate_ws_user = _canonical

        # === Gate authentication (centralizovaná autentizace + secrets) ===
        try:
            import richmovie_gate

            # 1)+2) Auth (+ čerstvý WS login při expirovaném tokenu) — Φ3 D5: s platnou lease
            #       menu HNED z ní a `/auth` na pozadí (`_gate_auth_menu`), jinak se čeká.
            _gate_code, _gate_data = _gate_auth_menu(cli, _gate_ws_user, _gate_ws_pw)

            # 3) Výsledek
            if _gate_code in (richmovie_gate.AUTH_OK, richmovie_gate.AUTH_OK_OFFLINE) and _gate_data:
                # Úspěch (online) NEBO offline-grace (Gate dole, platná lokální kopie ≤30 dní).
                # Secrets se načtou z cache v obou případech (gettery jedou na _cache_usable).
                _gate_tmdb = richmovie_gate.get_tmdb_api_key()
                if _gate_tmdb:
                    richmovie_settings.write("tmdb_api_key", _gate_tmdb)
                    # Phase G1 sentinel: mark this key as Gate-sourced. Absence
                    # of this timestamp pak signalizuje legacy per-user klíč
                    # (před Phase 3g), který patří do auditu / rotace.
                    try:
                        import datetime as _dt_tk
                        richmovie_settings.write(
                            "_tmdb_key_gate_synced_at",
                            _dt_tk.datetime.now(_dt_tk.timezone.utc)
                                .isoformat(timespec="seconds"),
                        )
                    except Exception:
                        pass
                # Offline-grace: omezený režim — Gate nedostupný, jedeme na lokální kopii.
                # Non-blocking upozornění + flag pro UI (TMDb-závislé obrazovky degradují).
                # Φ2 (2026-08-08): stav se zapisuje přes richmovie_netstate, ne přímo
                # do Window property. Do 08.08.2026 se `richmovie.offline_mode` sice
                # nastavovala a mazala, ale NIKDO ji nečetl — offline-grace tak byla
                # slepá a UI se podle ní nechovalo. Netstate je od teď jediná autorita
                # (kombinuje tenhle auth signál s breakerem transportu) a property
                # zapisuje dál pod původním jménem kvůli zpětné kompatibilitě.
                if _gate_code == richmovie_gate.AUTH_OK_OFFLINE:
                    try:
                        import richmovie_netstate as _nu_ns_auth
                        _nu_ns_auth.note_auth_offline_grace(True)
                    except Exception:
                        # Fail-safe: když netstate chybí, ať se aspoň zapíše původní
                        # property (chování před Φ2).
                        try:
                            xbmcgui.Window(10000).setProperty("richmovie.offline_mode", "1")
                        except Exception:
                            pass
                    try:
                        _rm_notif(
                            "Server je nedostupný. Pokračovat ve sledování a přehrávání "
                            "funguje; vyhledávání a novinky jsou dočasně nedostupné.",
                            xbmcgui.NOTIFICATION_WARNING,
                            6000,
                            "RichMovie – omezený režim",
                        )
                    except Exception:
                        pass
                else:
                    # Online: vyčistit případný offline flag z minulé session
                    try:
                        import richmovie_netstate as _nu_ns_auth
                        _nu_ns_auth.note_auth_offline_grace(False)
                    except Exception:
                        try:
                            xbmcgui.Window(10000).clearProperty("richmovie.offline_mode")
                        except Exception:
                            pass

                    # Instalátor kolekcí (3.5.118: až po potvrzené identitě, nikdy v offline-grace)
                    # od Φ3 (29.09.2026) spouští SLUŽBA — `service_nextup._maybe_install_collections`
                    # (identita AUTHENTICATED + ONLINE). V rootu držel non-daemon vlákno invokace
                    # a soupeřil o CPU se stavěním menu.

                    # 3.5.120: vyžádal si admin z tohoto zařízení kodi.log? Běží
                    # ve vlákně — upload nesmí zdržet vykreslení menu. Bez aktivního
                    # požadavku skončí v milisekundách bez jediného requestu; guard
                    # ošetřuje, že se `/auth` volá 2× při každém otevření root menu.
                    try:
                        import threading as _du_th
                        import richmovie_diag_upload as _rm_diag

                        def _diag_pull_worker():
                            try:
                                _rm_diag.start_if_requested()
                            except Exception as _dp_exc:
                                _log(f"[DiagUpload] Worker-error: {_dp_exc}", xbmc.LOGWARNING)

                        # daemon=False (memory feedback_daemon_threads_kodi) — HTTP
                        # vlákno se nesmí nechat zabít uprostřed POSTu.
                        _du_th.Thread(target=_diag_pull_worker,
                                      name="rm-diag-pull", daemon=False).start()
                    except Exception as _dp_start_exc:
                        _log(f"[DiagUpload] Start-error: {_dp_start_exc}", xbmc.LOGWARNING)

                _gate_cfg = richmovie_gate.get_config()
                _gate_min_ver = (_gate_cfg.get("min_version") or "").strip()
                _cur_ver = ADDON.getAddonInfo("version") or ""

                # Phase 2 version enforcement (Fáze 2 z nadřazeného plánu).
                # Proper semver comparison — string-compare was buggy
                # ("3.10.0" < "3.2.0" under string compare is True).
                if _gate_code == richmovie_gate.AUTH_OK \
                        and _gate_min_ver and richmovie_gate.version_is_older(_cur_ver, _gate_min_ver):
                    if _gate_cfg.get("force_update"):
                        # Hard block — addon odmítá pracovat se starší verzí.
                        xbmcgui.Dialog().ok(
                            "RichMovie – Aktualizace vyžadována",
                            "Je vyžadována verze %s nebo novější.\n"
                            "Vaše verze: %s\n\n"
                            "Aktualizujte doplněk přes\nNastavení > Doplňky > RichMovie." %
                            (_gate_min_ver, _cur_ver),
                        )
                        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                        return
                    else:
                        # Soft warning — user smí pokračovat, jen upozornění.
                        # Ukázat jen jednou na verzi (nezobrazovat při každém otevření).
                        _soft_warn_key = "soft_warn_shown_for_" + _gate_min_ver
                        if richmovie_settings.get_str(_soft_warn_key) != "1":
                            _rm_notif(
                                "Máte verzi %s, doporučena %s." % (_cur_ver, _gate_min_ver),
                                xbmcgui.NOTIFICATION_WARNING,
                                7000,
                                "RichMovie – doporučená aktualizace",
                            )
                            try:
                                richmovie_settings.write(_soft_warn_key, "1")
                            except Exception:
                                pass

                # Admin-authored message channel. Config může poslat:
                #   {"message": "text", "message_type": "info|warning|critical"}
                # "critical" = blocking dialog (výpadek, bezpečnostní upozornění).
                # "warning" = dialog bez block (user OK a pokračuje).
                # "info" (default) = notification (5s auto-dismiss).
                # Každá zpráva se zobrazí jen jednou — klíčuje se hashem textu.
                _gate_msg = (_gate_cfg.get("message") or "").strip()
                _gate_msg_type = (_gate_cfg.get("message_type") or "info").strip().lower()
                if _gate_msg:
                    import hashlib as _hl
                    _msg_fp = _hl.sha1(_gate_msg.encode("utf-8")).hexdigest()[:12]
                    _msg_seen_key = "msg_seen_" + _msg_fp
                    if richmovie_settings.get_str(_msg_seen_key) != "1":
                        try:
                            if _gate_msg_type == "critical":
                                xbmcgui.Dialog().ok("RichMovie – upozornění", _gate_msg)
                            elif _gate_msg_type == "warning":
                                xbmcgui.Dialog().ok("RichMovie", _gate_msg)
                            else:
                                _rm_notif(_gate_msg, xbmcgui.NOTIFICATION_INFO, 7000, "RichMovie")
                            richmovie_settings.write(_msg_seen_key, "1")
                        except Exception:
                            pass

            elif _gate_code == richmovie_gate.AUTH_UNREACHABLE:
                # Server nedostupný A vypršela i 30denní offline-grace (nebo zařízení
                # nebylo nikdy ověřeno) → addon nemůže bezpečně fungovat.
                xbmcgui.Dialog().ok(
                    "RichMovie",
                    "Server je nedostupný a vypršela platnost\n"
                    "lokální kopie oprávnění (30 dní).\n"
                    "Připojte se prosím jednou k internetu se zapnutým serverem.",
                )
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return

            elif _gate_code == richmovie_gate.AUTH_REJECTED:
                # Uživatel není na whitelistu / deaktivován
                xbmcgui.Dialog().ok(
                    "RichMovie",
                    "Přístup zamítnut.\n"
                    "Nemáte oprávnění používat tento doplněk.",
                )
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return

        except Exception as _gate_err:
            _log("[Gate] Error: %s" % _gate_err, xbmc.LOGWARNING)
            # Fáze 2 (dual mode): Gate selhání neshodí addon — jen logujeme
        # === END Gate authentication ===

        # — Fastshare login (vlastní credentials → Gate fallback) —
        global _FS_SESSION
        try:
            ws_username = _gate_ws_user  # use resolved canonical username
            if is_fastshare_allowed(ws_username):
                if _FS_SESSION is None:
                    _FS_SESSION = FastshareSessionManager(ADDON)
                if not _FS_SESSION.is_logged_in():
                    _FS_SESSION.ensure_login(interactive=False)
                if _FS_SESSION.is_logged_in():
                    _log("[Fastshare] Logged in", xbmc.LOGINFO)
        except Exception as fs_err:
            _log(f"[Fastshare] Login error: {fs_err}", xbmc.LOGWARNING)

        # — Background telemetry threads (joined before script exit) —
        _bg_threads = []

        # Status report (WS + FS login status → Gate) — jen držitel vedlejší práce (Φ3)
        try:
            if _side_work:
                _status_ws_user = _gate_ws_user  # use resolved canonical username
                _status_ws_ok = bool(cli.token)  # WS login succeeded
                _status_fs_ok = None  # None = not applicable
                if is_fastshare_allowed(_status_ws_user):
                    _status_fs_ok = bool(_FS_SESSION and _FS_SESSION.is_logged_in())
                _t = threading.Thread(
                    target=richmovie_gate.report_status,
                    args=(_status_ws_user, _status_ws_ok, _status_fs_ok),
                    name="GateStatus",
                )
                _t.start()
                _bg_threads.append(_t)
        except Exception:
            pass

        # Crash report flush (přes Gate /crash endpoint) — jen držitel vedlejší práce (Φ3)
        try:
            if _side_work:
                # Φ0: dřív modulový global z bloku __main__ (import v prologu), teď lokální import
                import richmovie_crash as _rm_crash
                _t = threading.Thread(
                    target=_rm_crash.flush_pending,
                    name="GateCrashFlush",
                )
                _t.start()
                _bg_threads.append(_t)
        except Exception:
            pass

        # — LAN: katalog lokálních souborů (Fáze CD, 3.5.128) —
        # Sken se přestěhoval na Gate (běží přímo na NASu, inkrementálně). Doplněk
        # si jen drží lokální kopii katalogu; tady se při startu vyžádá sync, když
        # je stará — provede ho SLUŽBA, ne tahle invokace (dřív tu běžel non-daemon
        # skenovací thread, který Kodi po vykreslení menu za 5 s zabíjelo).
        try:
            import richmovie_local_catalog as _lc
            import richmovie_gate as _lc_gate
            if _side_work and _lc_gate.is_local_filmoteka_allowed() and _lc.is_stale():
                _lc.request_sync("startup")
        except Exception as _e:
            _log(f"[LocalCatalog] sync request error: {_e}", xbmc.LOGWARNING)

        # — uvítací sekvence (pořadí = `richmovie_onboarding.STEPS`; kreslí jen držitel) —
        if _ob.interactive:
            # 2) jednorázový "VÁNOČNÍ POZDRAV OD RICHIEHO" (fullscreen, povinný) —
            #    zobrazí se pouze 1× (marker welcome_seen v addon_data).
            #    `step()` vrací False, když claim mezitím převzal jiný proces (uspání zařízení,
            #    zamrzlý interpret) → zbytek dialogů kreslí ten druhý, ne my (Pro P3 09.09.2026).
            try:
                if _ob.step("welcome"):
                    maybe_show_welcome(ADDON, PROFILE_DIR)
            except Exception:
                pass

            # 3) jednorázový FastShare onboarding (flag fs_onboard_done)
            try:
                if _ob.step("fastshare"):
                    _fs_onboarding()
            except Exception:
                pass

            # 3b) průvodce zvuk a titulky (jednou po instalaci / změně průvodce) — Φ3: krok sekvence
            try:
                if _ob.step("localization"):
                    _ensure_localization_onboarding()
            except Exception:
                pass

            # 3c) systémový filtr obsahu v cestě (noc 03.11.2026, Bětčin Mac) — jednorázové vysvětlení s postupem,
            #     znovu nejdřív za týden, dokud filtr trvá. RichMovie filtr nikdy neobchází (D1).
            try:
                if _ob.step("os_filter"):
                    import richmovie_device_env as _ob_denv
                    _ob_denv.show_notice_if_due()
            except Exception as _osf_exc:
                _log(f"[DeviceEnv] notice failed: {_osf_exc!r}", xbmc.LOGWARNING)

            # 3d) otevírat RichMovie po zapnutí Kodi? (noc 03.11.2026, Richie) — jednou za život ZAŘÍZENÍ
            try:
                if _ob.step("autostart"):
                    import richmovie_autostart as _ob_auto
                    _ob_auto.ask_once()
            except Exception as _au_exc:
                _log(f"[Autostart] ask failed: {_au_exc!r}", xbmc.LOGWARNING)

            # 4) Profily „Kdo se dívá?" (3.5.134) — POSLEDNÍ krok (Richie 09.09.2026: „výběr
            #    profilů se má zobrazit, až je vše vyplněno"); onboarding jednou per účet, chooser
            #    při každém startu Kodi (D1). Stále PŘED sestavením menu — osobní soubory
            #    (Pokračovat, seriály) se čtou z adresáře vybraného profilu.
            try:
                if _ob.step("profile"):
                    import richmovie_profile_ui as _pf_ui
                    if _pf_ui.ensure_profile_at_start():
                        _ob.complete()   # značka „hotovo" až PO posledním dialogu (cross-check F17.4)
                    else:
                        # S24 D5: výběr odložen (přehrávač) → sekvence zůstává otevřená, výběr při dalším menu
                        _log("[Onboarding] výběr profilu odložen (přehrávač) — sekvence zůstává otevřená",
                             xbmc.LOGINFO)
            except Exception as _pf_exc:
                _log(f"[Profile] start hook failed: {_pf_exc!r}", xbmc.LOGWARNING)
        elif _onboarding.completed_in_this_run():
            _log("[Onboarding] sekvence proběhla v jiném procesu (čekáno %.1f s) → bez dialogů"
                 % _ob.waited_s, xbmc.LOGINFO)
        else:
            # Anomálie (Pro P6): držitel neskončil do stropu čekání, nebo Kodi končí — nahlas.
            _log("[Onboarding] bez dialogů, ale sekvence NEBYLA dokončena (čekáno %.1f s, aborted=%s)"
                 % (_ob.waited_s, _ob.aborted), xbmc.LOGWARNING)
    finally:
        _ob.end()

    # — trigger pro TMDb warm-up (3.5.130: `richmovie_warm` ve službě service_nextup;
    #   dřív service_warm.py, který Kodi nikdy nespustilo). Warm-up běží nejvýš
    #   1× za 12 h per zařízení a jen ONLINE (viz richmovie_warm.run_due).
    try:
        trig_path = PROFILE_DIR / "tmdb_warm_trigger.json"
        payload = {
            "ts": int(time.time()),
            "source": "root",
        }
        f = xbmcvfs.File(str(trig_path), "w")
        try:
            f.write(json.dumps(payload, ensure_ascii=False))
        finally:
            f.close()
    except Exception as _e:
        _log(f"Warm trigger write failed: {_e}", xbmc.LOGDEBUG)

    # — cesty k ikonám —
    try:
        addon_path = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
    except Exception:
        addon_path = ADDON.getAddonInfo("path")

    icons_dir    = os.path.join(addon_path, "resources", "media", "icons")
    icon_movie   = os.path.join(icons_dir, "hledat_film.png")
    icon_tv      = os.path.join(icons_dir, "hledat_serial.png")
    icon_ai      = os.path.join(icons_dir, "doporucit_richmovie_ai.png")
    icon_watch   = os.path.join(icons_dir, "historie_sledovani.png")
    icon_search  = os.path.join(icons_dir, "historie_hledani.png")
    icon_collect = os.path.join(icons_dir, "collections.png")

    # Helper: vezmi první existující ikonu z kandidátů, jinak fallback
    def _pick_icon(candidates: list[str], default_path: str) -> str:
        try:
            for fn in candidates:
                p = os.path.join(icons_dir, fn)
                if xbmcvfs.exists(p):
                    return p
        except Exception:
            pass
        return default_path

    # 🆕 4 nové ikony (upravte názvy v listu dle vašich skutečných souborů)
    icon_tv_trending = _pick_icon(
        ["serialy_trendy_dnes.png", "serialy_trendy.png", "tv_trending.png", "trending_tv.png"],
        icon_tv
    )
    icon_tv_top = _pick_icon(
        ["serialy_top_hodnocene.png", "serialy_top.png", "tv_top.png", "top_tv.png"],
        icon_tv
    )
    icon_movie_trending = _pick_icon(
        ["filmy_trendy_dnes.png", "filmy_trendy.png", "movie_trending.png", "trending_movies.png"],
        icon_movie
    )
    icon_movie_top = _pick_icon(
        ["filmy_top_hodnocene.png", "filmy_top.png", "movie_top.png", "top_movies.png"],
        icon_movie
    )

    # 🆕 ČSFD TV tipy (přímá ikona dle tvé struktury)
    icon_csfd_tv_tips = os.path.join(icons_dir, "csfd_tv_tipy.png")
    try:
        if not xbmcvfs.exists(icon_csfd_tv_tips):
            icon_csfd_tv_tips = icon_movie
    except Exception:
        icon_csfd_tv_tips = icon_movie

    # ──────────────────────────────────────────────────────────────────────
    # 0) SEZÓNNÍ LOGIKA — výpočet oken + dynamická ikona addonu
    # ──────────────────────────────────────────────────────────────────────
    today = datetime.datetime.now().date()
    # box bez RTC před NTP hlásí 1970-01-01 → „Vánoce" v červenci (cross-check Flash P2 14.09.2026)
    _clock_sane = today.year >= 2024
    is_xmas_window = _clock_sane and ((today.month == 12 and today.day >= 1) or (today.month == 1 and today.day <= 8))

    # Computus: Meeus/Jones/Butcher algoritmus pro Velikonoční neděli
    is_easter_window = False
    try:
        _yr = today.year
        _a = _yr % 19
        _b = _yr // 100
        _c = _yr % 100
        _d = _b // 4
        _e = _b % 4
        _f = (_b + 8) // 25
        _g = (_b - _f + 1) // 3
        _h = (19 * _a + _b - _d - _g + 15) % 30
        _i = _c // 4
        _k = _c % 4
        _l = (32 + 2 * _e + 2 * _i - _h - _k) % 7
        _m = (_a + 11 * _h + 22 * _l) // 451
        _em = (_h + _l - 7 * _m + 114) // 31
        _ed = ((_h + _l - 7 * _m + 114) % 31) + 1
        easter_sunday = datetime.date(_yr, _em, _ed)
        easter_start = easter_sunday - datetime.timedelta(days=8)
        easter_end = easter_sunday + datetime.timedelta(days=1)
        is_easter_window = not is_xmas_window and easter_start <= today <= easter_end
    except Exception:
        pass

    # ── Dynamické přepínání ikony addonu dle sezóny ──
    try:
        if is_xmas_window:
            _season_src = os.path.join(addon_path, "icon_christmas2.png")
        elif is_easter_window:
            _season_src = os.path.join(addon_path, "icon_easter.png")
        else:
            _season_src = os.path.join(addon_path, "icon2.png")

        _icon_target = os.path.join(addon_path, "icon.png")

        # Swap jen když se OBSAH liší (= jiná sezóna). 14.09.2026 (Richie: „logo si dělá, co chce"):
        # ve zdrojáku i v release ZIPu ležel jako `icon.png` velikonoční soubor, takže po každé
        # aktualizaci / kopii do AppData svítilo velikonoční logo, dokud se jednou nevykreslilo hlavní
        # menu. Zdrojový `icon.png` je teď VŽDY neutrální (`icon2.png`, hlídá harness) a porovnání
        # jde přes hash, ne přes velikost souboru.
        def _digest(path):
            h = hashlib.md5()
            with open(path, "rb") as fh:
                for chunk in iter(lambda: fh.read(1 << 16), b""):
                    h.update(chunk)
            return h.hexdigest()

        # Kontrola 1× za běh Kodi (Window prop): md5 dvou 2MB souborů při KAŽDÉM vykreslení hlavního
        # menu by na pomalém flash disku znamenala zásek (cross-check Flash P1 14.09.2026).
        _season_prop = "RichMovie.SeasonalIconChecked"
        _season_mark = os.path.basename(_season_src) if _clock_sane else ""
        _need_swap = False
        if _season_mark and xbmcgui.Window(10000).getProperty(_season_prop) != _season_mark and os.path.isfile(_season_src):
            _need_swap = (not os.path.isfile(_icon_target)) or _digest(_icon_target) != _digest(_season_src)
            xbmcgui.Window(10000).setProperty(_season_prop, _season_mark)

        if _need_swap:
            # atomicky (tmp + replace přes SSOT richmovie_atomic): pád uprostřed kopie nesmí nechat
            # poloviční / nulový icon.png
            import richmovie_atomic as _rm_atomic
            with open(_season_src, "rb") as _fh:
                _icon_bytes = _fh.read()
            if not _rm_atomic.write_bytes(_icon_target, _icon_bytes):
                raise OSError("seasonal icon write failed (read-only addon dir?)")
            _log(f"Seasonal icon switched to: {os.path.basename(_season_src)}", xbmc.LOGINFO)
            # Invalidace Kodi texture cache pro ikonu
            try:
                _tex_query = json.dumps({
                    "jsonrpc": "2.0", "method": "Textures.GetTextures",
                    "params": {"filter": {"field": "url", "operator": "contains", "value": "icon.png"}},
                    "id": 1
                })
                _tex_result = json.loads(xbmc.executeJSONRPC(_tex_query))
                for _tex in (_tex_result.get("result") or {}).get("textures") or []:
                    _tid = _tex.get("textureid")
                    if _tid:
                        xbmc.executeJSONRPC(json.dumps({
                            "jsonrpc": "2.0", "method": "Textures.RemoveTexture",
                            "params": {"textureid": _tid}, "id": 1
                        }))
                _log("Texture cache invalidated for icon.png", xbmc.LOGINFO)
            except Exception as _te:
                _log(f"Texture cache clear error: {_te}", xbmc.LOGDEBUG)
    except Exception as _e:
        _log(f"Seasonal icon error: {_e}", xbmc.LOGWARNING)

    # ── VÁNOČNÍ KOLEKCE (SEZÓNNĚ: 1.12. – 8.1. včetně) ──
    try:
        if is_xmas_window:
            # ⚠️ ZDE nastav název souboru konkrétní kolekce (v resources/collections/)
            xmas_json_name = "vanoce_master_structured.json"
            xmas_json_path = os.path.join(addon_path, "resources", "collections", xmas_json_name)

            if xbmcvfs.exists(xmas_json_path):
                # Použij přesně stejné logo jako má kolekce:
                # resources/collections/<jmeno_json_bez_pripony>.png
                xmas_base = os.path.splitext(xmas_json_name)[0]
                xmas_logo_path = os.path.join(addon_path, "resources", "collections", f"{xmas_base}.png")

                # Pro jistotu ještě translatePath (některá prostředí vrací special://)
                try:
                    xmas_logo_path_vfs = xbmcvfs.translatePath(xmas_logo_path)
                except Exception:
                    xmas_logo_path_vfs = xmas_logo_path

                has_logo = xbmcvfs.exists(xmas_logo_path_vfs)
                _log(
                    f"Xmas menu logo check: json='{xmas_json_path}' logo='{xmas_logo_path_vfs}' exists={has_logo}",
                    xbmc.LOGWARNING
                )

                icon_xmas = xmas_logo_path_vfs if has_logo else icon_collect

                li = xbmcgui.ListItem("Vánoční kolekce")
                li.setArt({"icon": icon_xmas, "thumb": icon_xmas, "poster": icon_xmas})

                xbmcplugin.addDirectoryItem(
                    HANDLE,
                    _url(action="collections_browse", file=xmas_json_path),
                    li,
                    True
                )

            else:
                _log(
                    f"Xmas kolekce nenalezena: {xmas_json_path} (přeskočeno sezónní menu)",
                    xbmc.LOGDEBUG
                )
    except Exception as _e:
        _log(f"Xmas menu error: {_e}", xbmc.LOGWARNING)

    # ── VELIKONOČNÍ KOLEKCE (SEZÓNNĚ: Easter-8 až Easter+1) ──
    try:
        if is_easter_window:
            easter_json_name = "cz_velikonoce.json"
            easter_json_path = os.path.join(addon_path, "resources", "collections", easter_json_name)

            if xbmcvfs.exists(easter_json_path):
                easter_base = os.path.splitext(easter_json_name)[0]
                easter_logo_path = os.path.join(addon_path, "resources", "collections", f"{easter_base}.png")
                try:
                    easter_logo_path_vfs = xbmcvfs.translatePath(easter_logo_path)
                except Exception:
                    easter_logo_path_vfs = easter_logo_path

                has_easter_logo = xbmcvfs.exists(easter_logo_path_vfs)
                icon_easter_menu = easter_logo_path_vfs if has_easter_logo else icon_collect

                li = xbmcgui.ListItem("Velikonoční kolekce")
                li.setArt({"icon": icon_easter_menu, "thumb": icon_easter_menu, "poster": icon_easter_menu})

                xbmcplugin.addDirectoryItem(
                    HANDLE,
                    _url(action="collections_browse", file=easter_json_path),
                    li,
                    True
                )
            else:
                _log(f"Easter kolekce nenalezena: {easter_json_path}", xbmc.LOGDEBUG)
    except Exception as _e:
        _log(f"Easter menu error: {_e}", xbmc.LOGWARNING)

    # 0.5) Pokracovat ve sledovani (Continue Watching) — preview nejnovější + odkaz na plný list
    try:
        # Φ3b (3.5.134): krátký deltový pull stavu z jiných zařízení — jen když
        # služba nepullovala v posledních 30 s; offline/bez profilu = okamžitý návrat.
        try:
            import richmovie_state_sync as _ss
            _ss.pull_if_stale()
        except Exception as _ss_exc:
            _log(f"state pull at menu failed: {_ss_exc!r}", xbmc.LOGDEBUG)
        _cw_data = _hist_module.cw_view_load()   # 4.0.3: pohled (za seriál jeden řádek)
        _cw_items = _cw_data.get("items") or []
        if _cw_items:
            _cw_it = _cw_items[0]
            _cw_pos = float(_cw_it.get("position") or 0)
            _cw_dur = float(_cw_it.get("duration") or 1)
            _cw_pct = int((_cw_pos / _cw_dur) * 100) if _cw_dur > 0 else 0
            _cw_h = int(_cw_pos) // 3600
            _cw_m = (int(_cw_pos) % 3600) // 60
            _cw_s = int(_cw_pos) % 60
            _cw_time = f"{_cw_h}:{_cw_m:02d}:{_cw_s:02d}" if _cw_h else f"{_cw_m}:{_cw_s:02d}"

            if _cw_it.get("type") == "episode":
                _tv = _cw_it.get("tv_name") or _cw_it.get("title") or "Seriál"
                _se = int(_cw_it.get("season") or 0)
                _ep = int(_cw_it.get("episode") or 0)
                _cw_name = f"{_tv} S{_se:02d}E{_ep:02d}"
            else:
                _title = _cw_it.get("title") or "Bez názvu"
                _yr = _cw_it.get("year") or ""
                _cw_name = f"{_title} ({_yr})" if _yr else _title

            _cw_count = len(_cw_items)
            _cw_suffix = f"  [COLOR FF9E9E9E](+{_cw_count - 1})[/COLOR]" if _cw_count > 1 else ""
            _cw_label = (f"[COLOR FF87CEFA]Pokračovat:[/COLOR] {_cw_name}"
                         f" [COLOR FF87CEFA]\xb7[/COLOR] {_cw_time} ({_cw_pct}%){_cw_suffix}")
            # Φ3b → 13.09.2026: odkud stav je a co zařízení dělá — jeden formát `origin_text`
            # („⏸ Telefon Richie · před 2 min", „▶ právě hraje · TV obývák", „toto zařízení · před 5 min");
            # offline = jen tento box
            try:
                import richmovie_state_sync as _ss
                _cw_label += f" [COLOR FF9E9E9E]\xb7 {_ss.origin_text(_cw_it)}[/COLOR]"
                import richmovie_netstate as _ns
                if _ns.is_offline():
                    _cw_label += " [COLOR FF9E9E9E](offline, jen toto zařízení)[/COLOR]"
            except Exception:
                pass

            _cw_li = xbmcgui.ListItem(_cw_label)
            _cw_li.setInfo("video", {
                "title": _cw_it.get("title") or _cw_it.get("tv_name") or "Pokračovat",
                "plot": f"Pokračovat od {_cw_time} ({_cw_pct}%)",
            })

            # Artwork z CW záznamu (poster_path uložen při přehrávání — žádný sync TMDb fetch)
            _pp = _cw_it.get("poster_path") or ""
            _bp = _cw_it.get("backdrop_path") or ""
            _cw_art: dict[str, str] = {}
            if _pp:
                _cw_art["poster"] = f"https://image.tmdb.org/t/p/w342{_pp}" if _pp.startswith("/") else _pp
                _cw_art["thumb"] = _cw_art["poster"]
                _cw_art["icon"] = _cw_art["poster"]
            if _bp:
                _cw_art["fanart"] = f"https://image.tmdb.org/t/p/original{_bp}" if _bp.startswith("/") else _bp
            if _cw_art:
                _cw_li.setArt(_cw_art)

            xbmcplugin.addDirectoryItem(
                HANDLE,
                _url(action="cw_list"),
                _cw_li,
                isFolder=True,
            )
    except Exception as _cw_err:
        _log(f"CW root menu error: {_cw_err}", xbmc.LOGWARNING)

    # 0.6) Naposledy sledované seriály — rychlý skok rovnou do seznamu epizod
    try:
        _rws = _hist_module.get_recently_watched_series(limit=8)
        if _rws:
            _rws_li = xbmcgui.ListItem(f"Naposledy sledované seriály ({len(_rws)})")
            _rws_li.setArt({"icon": icon_tv, "thumb": icon_tv})
            _rws_li.setInfo("video", {
                "title": "Naposledy sledované seriály",
                "plot": "Rychlý skok do seznamu epizod rozkoukaných seriálů.",
            })
            xbmcplugin.addDirectoryItem(
                HANDLE,
                _url(action="recent_series"),
                _rws_li,
                isFolder=True,
            )
    except Exception as _rws_err:
        _log(f"recent series root menu error: {_rws_err}", xbmc.LOGWARNING)

    # 0a) Φ5 (2026-08-08) — stav offline režimu jako první položka.
    # PROČ položka a ne dialog: v legacy UI není kam dát trvalý indikátor, a modální
    # okno při každém vstupu do menu by bylo trápení. Nenápadný šedý řádek uživatele
    # informuje, nepřekáží mu a hlavně nevyžaduje kliknutí. Není klikatelný (vede na
    # `noop`), takže se s ním nedá nikam „zabloudit".
    #
    # Do 08.08.2026 se uživatel o omezeném režimu nedozvěděl vůbec — property
    # `richmovie.offline_mode` se sice nastavovala, ale nikdo ji nečetl.
    try:
        import richmovie_netstate as _nu_ns_root
        if _nu_ns_root.is_offline():
            li_off = xbmcgui.ListItem(
                "[COLOR FF9AA0A6]Offline režim — zobrazuji uloženou nabídku[/COLOR]"
            )
            li_off.setArt({"icon": icon_movie, "thumb": icon_movie})
            li_off.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(HANDLE, _url(action="noop"), li_off, False)
    except Exception as _off_err:
        _log(f"offline root badge error: {_off_err}", xbmc.LOGWARNING)

    # 0) RichMovie 4.0 — nový vzhled (beta): JEN pro účty s custom UI povolením
    # (Gate custom_ui). Rodina (custom_ui=false) tuhle položku NESMÍ vidět —
    # jinak by se klikem dostala do custom UI z legacy menu (regrese #5).
    if _custom_ui_enabled():
        try:
            li_new = xbmcgui.ListItem("[COLOR FF3E9BF0]🎬 RichMovie — nový vzhled (beta)[/COLOR]")
            li_new.setArt({"icon": icon_movie, "thumb": icon_movie})
            xbmcplugin.addDirectoryItem(HANDLE, _url(action="home_window"), li_new, True)
        except Exception:
            pass

    # 0b) Profily (3.5.134): „Dívá se: Richie ›" — přepnutí profilu jedním kliknutím.
    try:
        import richmovie_profile_ui as _pf_ui
        _pf_label = _pf_ui.root_label()
        if _pf_label:
            _pf_cur = richmovie_profile.current()
            _pf_li = xbmcgui.ListItem(_pf_label)
            _pf_icon = _pf_ui._avatar_path(_pf_cur) or _pf_ui._fallback_avatar(_pf_cur, guest=bool(_pf_cur.get("is_guest")))
            _pf_li.setArt({"icon": _pf_icon, "thumb": _pf_icon})
            _pf_li.setInfo("video", {"title": _pf_label, "plot": richmovie_profile.WHY_PROFILE_MATTERS})
            xbmcplugin.addDirectoryItem(HANDLE, _url(action="profile_choose"), _pf_li, False)
    except Exception as _pf_exc:
        _log(f"[Profile] root row failed: {_pf_exc!r}", xbmc.LOGWARNING)

    # 0c) Televize (08.11.2026, plán Televizní kanály F3): JEN zařízení s oprávněním `live_tv` (Gate, fail-closed —
    # bez použitelné cache nebo bez klíče se položka neukáže). Výpis i přehrání = `richmovie_livetv_ui`.
    try:
        import richmovie_gate as _gate_live   # vlastní jméno: `import richmovie_gate` výše v _root je jen ve větvi
        if _gate_live.is_live_tv_allowed():
            icon_live = _pick_icon(["televize.png", "live_tv.png", "tv_live.png"], "DefaultAddonPVRClient.png")
            li_live = xbmcgui.ListItem("Televize")
            li_live.setArt({"icon": icon_live, "thumb": icon_live})
            li_live.setInfo("video", {"title": "Televize", "plot": "Živé kanály ze SledovaniTV přes NAS."})
            xbmcplugin.addDirectoryItem(HANDLE, _url(action="live_home"), li_live, True)
    except Exception as _live_err:
        _log(f"[Televize] root row failed: {_live_err!r}", xbmc.LOGWARNING)

    # 1) Hledat film
    li = xbmcgui.ListItem("Hledat film")
    li.setArt({"icon": icon_movie, "thumb": icon_movie})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="movie_search"), li, True)

    # 2) Hledat seriál
    li = xbmcgui.ListItem("Hledat seriál")
    li.setArt({"icon": icon_tv, "thumb": icon_tv})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tv_search"), li, True)

    # 2b) Doporučení přesně pro Vás (Phase E, RichMovie 3.1.0 — AI personalized)
    try:
        icon_recs = _pick_icon(
            ["doporuceni.png", "recommendations.png", "ai_recs.png",
             "tipy.png", "tip.png"],
            icon_movie,
        )
        li_recs = xbmcgui.ListItem("Doporučení přesně pro Vás")
        li_recs.setArt({"icon": icon_recs, "thumb": icon_recs})
        # Plot/info shown when user hovers — sets context for new feature.
        li_recs.setInfo("video", {
            "plot": "Personalizovaná AI doporučení založená na vaší historii "
                    "sledování. Generuje se nově každou noc. Klikni a otevři, "
                    "klik na položku rovnou spustí vyhledávání pro daný titul.",
        })
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action="show_recommendations"), li_recs, True,
        )
    except Exception as _recs_err:
        _log(f"recommendations menu error: {_recs_err}",
                 xbmc.LOGWARNING)

    # 2c) CSFD profil (Phase B8, RichMovie 3.2.0 — explicit ratings sync)
    try:
        icon_csfd = _pick_icon(
            ["csfd.png", "csfd_logo.png", "ratings.png"],
            icon_movie,
        )
        # 3.5.152: ČSFD je per profil — řádek nese jméno profilu („ČSFD profil · Sněhurka")
        try:
            import richmovie_csfd_client as _csfd_lbl
            _csfd_who = _csfd_lbl.csfd_profile_label()
        except Exception:
            _csfd_who = ""
        li_csfd = xbmcgui.ListItem("ČSFD profil" + (" · " + _csfd_who if _csfd_who else ""))
        li_csfd.setArt({"icon": icon_csfd, "thumb": icon_csfd})
        li_csfd.setInfo("video", {
            "plot": ("Připoj ČSFD účet profilu {} — jeho hodnocení a „Chci vidět“ zpřesní doporučení "
                     "jen pro tento profil. ".format(_csfd_who) if _csfd_who else
                     "Připoj svůj ČSFD účet a RichMovie použije tvá hodnocení "
                     "pro mnohem přesnější AI doporučení. ")
                    + "Hesla jsou šifrována. Synchronizace probíhá automaticky 1× za noc.",
        })
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action="csfd_settings"), li_csfd, False,
        )
    except Exception as _csfd_err:
        _log(f"csfd menu error: {_csfd_err}",
                 xbmc.LOGWARNING)

    # 2d) Moje CSFD (Phase B11, 3.2.0-beta.2 — browser pro synced data)
    try:
        icon_my_csfd = _pick_icon(
            ["moje_csfd.png", "csfd_my.png", "csfd.png", "ratings.png"],
            icon_movie,
        )
        li_my = xbmcgui.ListItem("Moje ČSFD a hodnocení" + (" · " + _csfd_who if _csfd_who else ""))
        li_my.setArt({"icon": icon_my_csfd, "thumb": icon_my_csfd})
        li_my.setInfo("video", {
            "plot": "Procházej svá ČSFD hodnocení (★), watchlist a hodnocení zadaná "
                    "v RichMovie. Klik na film tě dovede k hledání releases.",
        })
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action="csfd_my_root"), li_my, True,
        )
    except Exception as _my_csfd_err:
        _log(f"my-csfd menu error: {_my_csfd_err}",
                 xbmc.LOGWARNING)

    # 3) Soukromá databáze na NAS serveru – jen pro vybrané Webshare účty (viz richmovie_local_files.py)
    try:
        ws_user = (richmovie_settings.get_str("username") or "").strip()
        if richmovie_local_files.is_allowed_webshare_user(ws_user):
            icon_local = _pick_icon(
                ["lokalni_soubory.png", "local_files.png", "lan_files.png", "lan.png", "smb.png"],
                icon_movie,
            )
            li = xbmcgui.ListItem("Soukromá databáze na NAS serveru")
            li.setArt({"icon": icon_local, "thumb": icon_local})
            xbmcplugin.addDirectoryItem(HANDLE, _url(action="local_root"), li, True)
    except Exception as _e:
        _log(f"[LocalFiles] Root menu error: {_e}", xbmc.LOGWARNING)

    # 4) Reset cache vyhledávání
    li = xbmcgui.ListItem("Reset cache vyhledávání")
    li.setArt({"icon": icon_search, "thumb": icon_search})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="reset_search_caches"), li, True)

    # 5) ČSFD
    li = xbmcgui.ListItem("ČSFD")
    li.setArt({"icon": icon_csfd_tv_tips, "thumb": icon_csfd_tv_tips})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="csfd_home"), li, True)

    # 6) Doporučit od RichMovie A.I.
    li = xbmcgui.ListItem("Doporučit od RichMovie A.I.")
    li.setArt({"icon": icon_ai, "thumb": icon_ai})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="ai_menu"), li, True)

    # 7) Historie sledování
    li = xbmcgui.ListItem("Historie sledování")
    li.setArt({"icon": icon_watch, "thumb": icon_watch})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="watch_history"), li, True)

    # 8) Historie hledání
    li = xbmcgui.ListItem("Historie hledání")
    li.setArt({"icon": icon_search, "thumb": icon_search})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="history"), li, True)

    # 9) Kolekce
    li = xbmcgui.ListItem("Kolekce")
    li.setArt({"icon": icon_collect, "thumb": icon_collect})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="collections"), li, True)

    # 10) Stream.cz, YouTube a ostatn\u00ed
    li = xbmcgui.ListItem("Stream.cz, YouTube a ostatn\u00ed")
    li.setArt({"icon": icon_movie, "thumb": icon_movie})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="streaming_home"), li, True)

    # 11) Seri\u00e1ly - Trendy dnes
    li = xbmcgui.ListItem("Seri\u00e1ly - Trendy dnes")
    li.setArt({"icon": icon_tv_trending, "thumb": icon_tv_trending})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_tv_trending"), li, True)

    # 12) Seri\u00e1ly - TOP hodnocen\u00e9
    li = xbmcgui.ListItem("Seri\u00e1ly - TOP hodnocen\u00e9")
    li.setArt({"icon": icon_tv_top, "thumb": icon_tv_top})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_tv_top_rated"), li, True)

    # 13) Filmy - Trendy dnes
    li = xbmcgui.ListItem("Filmy - Trendy dnes")
    li.setArt({"icon": icon_movie_trending, "thumb": icon_movie_trending})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_movie_trending"), li, True)

    # 14) Filmy - TOP hodnocen\u00e9
    li = xbmcgui.ListItem("Filmy - TOP hodnocen\u00e9")
    li.setArt({"icon": icon_movie_top, "thumb": icon_movie_top})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_movie_top_rated"), li, True)

    # 15) \u017d\u00e1nry
    li = xbmcgui.ListItem("\u017d\u00e1nry")
    li.setArt({"icon": icon_movie, "thumb": icon_movie})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="tmdb_genres"), li, True)

    # 16) P\u0159\u00edm\u00e9 hled\u00e1n\u00ed Webshare (+ Fastshare pro whitelistovan\u00e9)
    try:
        _ws_user = (richmovie_settings.get_str("username") or "").strip()
        _ws_label = ("P\u0159\u00edm\u00e9 hled\u00e1n\u00ed Webshare a Fastshare"
                     if is_fastshare_allowed(_ws_user)
                     else "P\u0159\u00edm\u00e9 hled\u00e1n\u00ed Webshare")
    except Exception:
        _ws_label = "P\u0159\u00edm\u00e9 hled\u00e1n\u00ed Webshare"
    li = xbmcgui.ListItem(_ws_label)
    li.setArt({"icon": icon_movie, "thumb": icon_movie})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action="ws_search"), li, True)

    # 17) Přihlášení k FastShare — jen pokud nemá funkční FS login
    try:
        if not _fs_has_working_login():
            li = xbmcgui.ListItem("Přihlášení k Fastshare")
            li.setArt({"icon": icon_movie, "thumb": icon_movie})
            xbmcplugin.addDirectoryItem(HANDLE, _url(action="fs_login_onboard"), li, False)
    except Exception:
        pass

    # 18) Odeslat diagnostiku (3.5.120) — druhá, na serveru NEZÁVISLÁ cesta,
    # jak dostat log ze zařízení. Když se zařízení nedokáže ani přihlásit,
    # příznak z dashboardu k němu nedorazí a tohle je jediná možnost: Richie
    # zavolá a uživatel klikne. Položka je záměrně až úplně dole a bez ikony
    # akce — běžný uživatel ji nepotřebuje, ale musí se dát najít po telefonu.
    try:
        li = xbmcgui.ListItem("Odeslat diagnostiku správci")
        li.setArt({"icon": icon_movie, "thumb": icon_movie})
        xbmcplugin.addDirectoryItem(HANDLE, _url(action="diag_upload"), li, False)
    except Exception:
        pass

    _ver = ADDON.getAddonInfo("version")
    import richmovie_publish_info as _rm_pub
    _pub_date, _pub_ver = _rm_pub.cached(_ver)
    _header = f"RichMovie v{_ver}"
    if _pub_ver and _ver != _pub_ver:
        _header += " \u00b7 DEV (nepublikovno)"
    elif _pub_date:
        _header += f" \u00b7 Richie aktualizoval {_pub_date}"
    xbmcplugin.setPluginCategory(HANDLE, _header)
    xbmcplugin.endOfDirectory(HANDLE)

    # — Počkej na telemetry thready (uživatel už vidí menu) —
    for _t in _bg_threads:
        try:
            _t.join(timeout=5)
        except Exception:
            pass













# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _local_files_show_dir
# _local_files_show_dir (upraveno: 2025-12-28 00:45 CET (Europe/Prague) – LAN: provider se zobrazuje vždy: 1) Label2 bez BBCode (některé skiny barvy v Label2 ignorují → prázdno), 2) fallback přidán i do názvu položky (šedě) pro 3-panel/MediaInfo view, kde žádný pravý sloupec neexistuje; + studio=provider jako další fallback. Zachováno: přímé smb:// přehrávání + TMDb art/info + cacheToDisc=False)
# ---------------------------------------------------------------------------- #
def _local_files_show_dir(relative_path: str) -> None:
    """
    2025-12-28 00:45 CET (Europe/Prague)

    LAN listing:
    - stopáž je v názvu (xxx min), takže duration vpravo je redundantní
    - provider chceme vpravo (Label2), ale:
        a) některé skiny ignorují BBCode v Label2 → nesmí tam být [COLOR]
        b) některé view (Media info / 3-panel) pravý "sloupec" vůbec nemají → provider musí být i v názvu
    """
    ws_user = (richmovie_settings.get_str("username") or "").strip()
    if not richmovie_local_files.is_allowed_webshare_user(ws_user):
        _modal("Soukromá databáze na NAS serveru jsou dostupné jen pro vybrané účty.")
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False, cacheToDisc=False)
        except TypeError:
            try:
                xbmcplugin.endOfDirectory(HANDLE, False, False, False)
            except TypeError:
                xbmcplugin.endOfDirectory(HANDLE)
        return

    rel = richmovie_local_files.sanitize_relative_path(relative_path)

    # Fáze CD (3.5.128): listing z LOKÁLNÍ KOPIE katalogu (okamžité, bez SMB
    # kola a bez TMDb dotazů — katalog staví Gate na NASu). SMB listing zůstává
    # jen jako fallback pro první spuštění, dokud služba kopii nestáhne.
    import richmovie_local_catalog as _lc
    if _lc.is_stale():
        _lc.request_sync("menu")
    dirs, files = _lc.list_dir(rel)
    _from_catalog = bool(dirs or files)
    if not _from_catalog:
        dirs, files = richmovie_local_files.list_dir(rel)

    dirs_sorted = sorted(dirs or [], key=lambda s: (s or "").lower())
    video_files = [f for f in (files or []) if richmovie_local_files.is_video_file(f)]
    files_sorted = sorted(video_files, key=lambda s: (s or "").lower())

    try:
        xbmcplugin.setContent(HANDLE, "videos")
    except Exception:
        pass
    try:
        xbmcplugin.setPluginCategory(HANDLE, "Soukromá databáze na NAS serveru")
    except Exception:
        pass

    import richmovie_rmdir
    if rel:
        _nas_title = richmovie_local_files.pretty_label(
            rel.rstrip("/").split("/")[-1], is_dir=True)
    else:
        _nas_title = "Soukromá databáze (NAS)"
    rmdir = richmovie_rmdir.RmDir(HANDLE, _nas_title)

    # FOLDERS
    for d in dirs_sorted:
        next_rel = richmovie_local_files.join_relative_path(rel, d)
        li = xbmcgui.ListItem(richmovie_local_files.pretty_label(d, is_dir=True))
        li.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
        rmdir.add(_url(action="local_browse", path=next_rel), li, True)

    # FILES
    for f in files_sorted:
        next_rel = richmovie_local_files.join_relative_path(rel, f)
        smb_url = richmovie_local_files.build_smb_url(next_rel, is_dir=False)

        # badge z názvu (kvalita)
        base_no_ext = f.rsplit(".", 1)[0] if "." in f else f
        badge_parts = []
        try:
            for b in re.findall(r"\[([^\]]+)\]", base_no_ext):
                bb = (b or "").strip()
                if bb:
                    badge_parts.append(bb)
        except Exception:
            pass
        try:
            no_brackets = re.sub(r"\[[^\]]*\]", " ", base_no_ext)
            mres = re.search(r"\b(2160p|1080p|720p|576p|480p|360p|240p)\b", no_brackets, flags=re.IGNORECASE)
            if mres:
                res = mres.group(1)
                if not any(res.lower() in (x or "").lower() for x in badge_parts):
                    badge_parts.insert(0, res)
        except Exception:
            pass

        badge_txt = " • ".join(badge_parts[:3]).strip() if badge_parts else ""
        badge_suffix = f" [COLOR FF9E9E9E]{badge_txt}[/COLOR]" if badge_txt else ""

        # Metadata z katalogu (Fáze CD): žádný per-soubor TMDb lookup na klientu.
        meta, _did_lookup = _lc.get_local_meta(next_rel)

        if isinstance(meta, dict):
            m_title = (meta.get("title") or "").strip()
            m_year = int(meta.get("year") or 0) if meta.get("year") else 0
            m_runtime = int(meta.get("runtime") or 0) if meta.get("runtime") else 0
            m_rating = float(meta.get("rating") or 0.0)
            m_votes = int(meta.get("votes") or 0)

            # provider (musí být známý ještě před sestavením labelu – fallback do názvu)
            provider = (meta.get("provider") or "").strip()
            provider_suffix = f" [COLOR FF9E9E9E]• {provider}[/COLOR]" if provider else ""

            rating_txt = f"[B][COLOR gold]★ {m_rating}[/COLOR][/B]\t" if m_rating else ""
            title_core = f"{m_title} ({m_year})" if m_year else (m_title or richmovie_local_files.pretty_label(f, is_dir=False))
            runtime_suffix = f" [COLOR FF87CEFA]({m_runtime} min)[/COLOR]" if m_runtime > 0 else ""

            # DŮLEŽITÉ: provider dáváme i do názvu → funguje i v 3-panel view (kde "pravý sloupec" není)
            label = f"{rating_txt}{title_core}{runtime_suffix}{badge_suffix}{provider_suffix}"
            li = xbmcgui.ListItem(label)

            # pravý sloupec: provider (Label2) – BEZ BBCode (některé skiny to jinak zobrazí jako prázdno)
            if provider:
                try:
                    li.setLabel2(provider)
                except Exception:
                    pass
                try:
                    li.setProperty("richmovie.provider", provider)
                except Exception:
                    pass

            # art
            art = {"icon": "DefaultVideo.png"}
            try:
                a = meta.get("art") or {}
                if a.get("poster"):
                    art["poster"] = a["poster"]
                if a.get("thumb"):
                    art["thumb"] = a["thumb"]
                if a.get("fanart"):
                    art["fanart"] = a["fanart"]
            except Exception:
                pass
            li.setArt(art)

            # info-panel (DŮLEŽITÉ: NEnastavujeme duration → pravý sloupec nebude čas)
            # Fallback: některé skiny umí vpravo zobrazit "Studio" → nastavíme studio=provider
            try:
                genres = meta.get("genres") or []
                genre_str = " / ".join([g for g in genres if g]) if isinstance(genres, list) else ""
                info_map = {
                    "title":     m_title or title_core,
                    "plot":      (meta.get("plot") or "").strip(),
                    "year":      m_year or 0,
                    "mediatype": "movie",
                    "rating":    m_rating or 0,
                    "votes":     m_votes or 0,
                    "genre":     genre_str,
                }
                if provider:
                    info_map["studio"] = provider
                li.setInfo("video", info_map)
            except Exception:
                pass

            if m_rating:
                try:
                    li.setRating("tmdb", m_rating, int(m_votes or 0))
                except Exception:
                    pass

        else:
            label = f"{richmovie_local_files.pretty_label(f, is_dir=False)}{badge_suffix}"
            li = xbmcgui.ListItem(label)
            li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png"})

        li.setProperty("IsPlayable", "true")
        li.setProperty("isPlayable", "true")
        try:
            li.setPath(smb_url)
        except Exception:
            pass

        rmdir.add(smb_url, li, False)

    try:
        rmdir.finish(succeeded=True, updateListing=False, cacheToDisc=False)
    except TypeError:
        rmdir.finish()





# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _local_root
# _local_root (vytvořeno: 2025-12-27 21:48 CET (Europe/Prague) – LOCAL: root SMB browser)
# ---------------------------------------------------------------------------- #
def _local_root() -> None:
    """
    2025-12-27 21:48 CET (Europe/Prague)

    Vstup do lokálního SMB browseru – root share.
    """
    _local_files_show_dir("")





# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _local_browse
# _local_browse (vytvořeno: 2025-12-27 21:48 CET (Europe/Prague) – LOCAL: browse podsložek v SMB share)
# ---------------------------------------------------------------------------- #
def _local_browse() -> None:
    """
    2025-12-27 21:48 CET (Europe/Prague)

    Browse podsložek lokálního SMB share.
    """
    rel = params.get("path", [""])[0]
    _local_files_show_dir(rel)







# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _local_play
# _local_play (upraveno: 2025-12-27 22:10 CET (Europe/Prague) – FIX: setResolvedUrl musí dostat ListItem s explicitně nastavenou path přes li.setPath(); jinak Kodi zkouší hrát plugin:// URL a spadne; doplněn debug log s maskovaným smb url)
# ---------------------------------------------------------------------------- #
def _local_play() -> None:
    """
    2025-12-27 22:10 CET (Europe/Prague)

    Přehrání vybraného souboru z lokálního SMB share (LAN).

    FIX:
      Některé verze Kodi ignorují ListItem(path=...) v konstruktoru.
      Pokud pak ListItem nemá nastavenou cestu, Kodi zkouší přehrát původní plugin:// URL
      a VideoPlayer spadne na:
          CVideoPlayer::OpenInputStream - error opening [plugin://...]
      Proto zde explicitně voláme li.setPath(smb_url).
    """
    # Bezpečnostní brzda i na play (i kdyby někdo vyrobil URL ručně)
    ws_user = (richmovie_settings.get_str("username") or "").strip()
    if not richmovie_local_files.is_allowed_webshare_user(ws_user):
        _modal("Soukromá databáze na NAS serveru jsou dostupné jen pro vybrané účty.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # Relativní cesta v rámci SMB share
    rel_raw = params.get("path", [""])[0]
    rel = richmovie_local_files.sanitize_relative_path(rel_raw)

    if not rel:
        _modal("Chybí cesta k souboru.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # Sestav SMB URL včetně credentials (dle zadání)
    smb_url = richmovie_local_files.build_smb_url(rel, is_dir=False)

    # Debug log (bez hesla)
    try:
        masked = smb_url
        try:
            masked = richmovie_local_files._mask_smb_url(smb_url)  # internal helper v modulu
        except Exception:
            pass
        _log(f"[LocalFiles] RESOLVE smb: {masked}", xbmc.LOGINFO)
    except Exception:
        pass

    # Tady je ten kritický fix: explicitně setPath()
    try:
        label = richmovie_local_files.pretty_label(rel.split("/")[-1], is_dir=False)
    except Exception:
        label = "Lokální video"

    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    li.setProperty("isPlayable", "true")  # pro jistotu kompatibility
    li.setPath(smb_url)

    xbmcplugin.setResolvedUrl(HANDLE, True, li)











# ═══════════════════════════════════════════════════════════════════════════════
#  AI UTILITY FUNKCE – DELEGACE NA richmovie_ai (Fáze 2B refaktoringu)
# ═══════════════════════════════════════════════════════════════════════════════

def _ai_log(event: str, message: str = "", *, details: dict | None = None, level: str = "ERROR") -> None:
    """Delegováno do richmovie_ai"""
    _ai_module.ai_log(event, message, details=details, level=level)


def _ai_available_or_warn() -> bool:
    """Ověří, že addon má konfigurovaný Webshare login — jediný identity proof,
    který AI potřebuje (AI volání jdou přes Gate → RichClaudeAI). Při chybějícím
    loginu zobrazí modal a vrátí False.
    """
    if not richmovie_ai_client.is_available():
        _modal("Pro AI funkce je potřeba Webshare login. Zkontroluj nastavení.",
               heading="RichMovie A.I.")
        return False
    return True




def _ai_menu() -> None:
    """
    Submenu RichMovie A.I. + zachycení textového dotazu.

    Nové:
      • Přidána volba "Najít podle popisu (přesné)" – vede na _ai_identify_show().
      • Zachováno: původní tři volby (film/seriál/je mi to jedno) → _ai_recommend_show().

    Každý krok umožňuje Zrušit → návrat do hlavního menu.
    """
    if not _ai_available_or_warn():
        _root()
        return

    kb = xbmcgui.Dialog()
    opts = ["Najdi podle mého popisu", "Doporuč mi film", "Doporuč mi seriál", "Doporuč mi film, nebo seriál"]
    idx = kb.select("Doporučit od RichMovie A.I.", opts)
    if idx < 0:
        _root();  return

    # 0 = nový "přesný" režim (identifikace podle popisu)
    if idx == 0:
        text = _keyboard_input("Co si pamatuješ z děje? Popiš co nejpřesněji.")
        if not text:
            _root();  return
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        xbmc.executebuiltin("Container.Update(%s,replace)" % _url(action="ai_identify", q=text))
        return

    # Původní tři volby → doporučení
    kind = ("movie", "tv", "any")[idx - 1]
    text = _keyboard_input("Co Tě zajímá? :-)")
    if not text:
        _root();  return
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    xbmc.executebuiltin("Container.Update(%s,replace)" % _url(action="ai_recommend_results", kind=kind, q=text))
    return














# 2025-08-14 13:16 CEST (Europe/Prague)
def _ai_recommend_show(kind: str, user_text: str) -> None:
    """
    Zobrazí doporučení od RichMovie A.I. pro zvolený typ obsahu.
    (Sims-like progress, A.I. běží v pozadí.)
    """
    AI_PREFIX       = "[RichMovie A.I.]: "
    AI_PREFIX_NOSPC = "[RichMovie A.I.]:"

    tmdb_key = richmovie_settings.get_tmdb_api_key()

    if not tmdb_key:
        _modal("Chybí API klíč TMDb.", heading="RichMovie A.I.")
        _root()
        return
    # RichMovie 3.000: AI jde přes Gate (centrální tenant). Stačí mít
    # správně nastavený Webshare login (jediný identity proof).
    if not richmovie_ai_client.is_available():
        _modal("AI funkce nejsou k dispozici. Zkontroluj Webshare login v nastavení.",
               heading="RichMovie A.I.")
        _root()
        return

    try:
        # milník do logu i do A.I. logu
        _log_event("AI_QUERY", {"kind": kind, "text": user_text})
        _ai_log("AI_QUERY", "Start doporučení", details={"kind": kind, "text": user_text}, level="INFO")

        # — spustíme A.I. ve vlákně + ukážeme Sims-like progres ————————
        def _worker():
            # RichMovie 3.000: api_key je ignorován shim funkcí; model se
            # vybírá na straně Gate + RCAI podle `quality` (default 'high' = Opus).
            return recommend_titles(
                api_key=None,
                user_text=user_text,
                want=kind,
                limit=20,
            )

        recs, prog = _run_ai_with_progress(kind, user_text, mode="recommend", worker=_worker)
        if recs is None:
            # chyba při A.I. – cleanup progress a předej na běžné hlášení
            if prog:
                try: prog.close()
                except Exception: pass
            raise AIError("A.I. volání selhalo (viz log).")

        _log_event("AI_RESP", {"count": len(recs)})
        _ai_log("AI_RESP", "AI doporučení hotovo", details={"count": len(recs)}, level="INFO")

        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        movies: list[dict] = []
        shows:  list[dict] = []

        def _shorten(txt: str, maxlen: int = 700) -> str:
            t = (txt or "").strip()
            return (t[: maxlen - 1] + "…") if len(t) > maxlen else t

        # závěrečná fáze – drobný posun procent při dohledání
        done = 0
        total = len(recs) or 1

        for it in recs:
            title  = (it.get("title") or "").strip()
            year   = it.get("year")
            reason = (it.get("reason") or it.get("why") or "").strip()
            if reason and not (reason.startswith(AI_PREFIX) or reason.startswith(AI_PREFIX_NOSPC)):
                reason = AI_PREFIX + reason
            if not title:
                continue

            try:
                if kind == "tv" or (kind == "any" and (it.get("kind") or "movie") == "tv"):
                    found = tmdb.search_tv(title, limit=5)
                else:
                    found = tmdb.search(title, limit=5)
                pick  = _tmdb_pick_by_year(found, year)
                if pick:
                    if reason:
                        pick["overview"] = _shorten(reason)
                    if kind == "tv" or (kind == "any" and (it.get("kind") or "movie") == "tv"):
                        shows.append(pick)
                    else:
                        movies.append(pick)
            except TMDbError as e:
                _ai_log("AI_TMDb_ERR", f"Search failed: {title}", details={"err": str(e)})

            # jemné "dotažení" na ~98 %
            done += 1
            try:
                pct = min(98, 95 + int((done / total) * 3))
                prog.update(pct, "Finalizuji výsledky…")
            except Exception:
                pass

        # poslední 100 % + zavřít
        try:
            prog.update(100, "Hotovo.")
            prog.close()
        except Exception:
            pass

        if kind == "movie":
            _list_tmdb_movies(movies or [])
        elif kind == "tv":
            _list_tmdb_tv(shows or [])
        else:
            _list_tmdb_ai_mixed(movies, shows)

    except AIError as e:
        # RichMovie 3.000: `AIError` je nyní shim exception z richmovie_ai_client.
        # Zpráva je v češtině, pochází z Gate → RCAI → Claude pipeline.
        msg = str(e)
        _ai_log("AI_ERROR", msg, details={"kind": kind, "query": user_text})
        _modal(f"Chyba AI: {msg}", heading="RichMovie A.I.")
        _root()
    except Exception as e:
        _ai_log("UNEXPECTED_ERROR", str(e), details={"kind": kind}, level="ERROR")
        _net_error_ui(e, heading="RichMovie A.I.")
        _root()







# 2025-08-14 13:16 CEST (Europe/Prague)
def _ai_identify_show(user_text: str) -> None:
    """
    Přesná identifikace filmů/seriálů podle popisu (RichMovie A.I.).
    (Sims-like progress, A.I. běží v pozadí.)
    """
    AI_PREFIX       = "[RichMovie A.I.]: "
    AI_PREFIX_NOSPC = "[RichMovie A.I.]:"

    tmdb_key = richmovie_settings.get_tmdb_api_key()

    if not tmdb_key:
        _modal("Chybí API klíč TMDb.", heading="RichMovie A.I.")
        _root()
        return
    # RichMovie 3.000: viz _ai_recommend_show — AI jde přes Gate.
    if not richmovie_ai_client.is_available():
        _modal("AI funkce nejsou k dispozici. Zkontroluj Webshare login v nastavení.",
               heading="RichMovie A.I.")
        _root()
        return

    try:
        _log_event("AI_ID_QUERY", {"text": user_text})
        _ai_log("AI_ID_QUERY", "Start identifikace", details={"text": user_text}, level="INFO")

        def _worker():
            # RichMovie 3.000: api_key ignorován shim funkcí (viz _ai_recommend_show).
            return identify_titles(
                api_key=None,
                user_text=user_text,
                limit=5,
            )

        recs, prog = _run_ai_with_progress("any", user_text, mode="identify", worker=_worker)
        if recs is None:
            if prog:
                try: prog.close()
                except Exception: pass
            raise AIError("A.I. volání selhalo (viz log).")

        _log_event("AI_ID_RESP", {"count": len(recs)})
        _ai_log("AI_ID_RESP", "AI identifikace hotovo", details={"count": len(recs)}, level="INFO")

        # Filtrování a řazení dle jistoty; missing_facts musí být prázdné
        def _is_strict_match(it: dict) -> bool:
            miss = it.get("missing_facts") or []
            try:
                conf = int(it.get("confidence") or 0)
            except Exception:
                conf = 0
            return (len(miss) == 0) and (conf >= 0)

        filtered = [it for it in recs if _is_strict_match(it)]
        filtered.sort(key=lambda d: int(d.get("confidence") or 0), reverse=True)
        filtered = filtered[:5]

        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        movies: list[dict] = []
        shows:  list[dict] = []

        def _shorten(txt: str, maxlen: int = 700) -> str:
            t = (txt or "").strip()
            return (t[: maxlen - 1] + "…") if len(t) > maxlen else t

        done = 0
        total = len(filtered) or 1

        for it in filtered:
            title  = (it.get("title") or "").strip()
            year   = it.get("year")
            reason = (it.get("reason") or "").strip()
            kind   = (it.get("kind") or "movie").strip().lower()
            if reason and not (reason.startswith(AI_PREFIX) or reason.startswith(AI_PREFIX_NOSPC)):
                reason = AI_PREFIX + reason
            if not title:
                continue

            try:
                found = tmdb.search_tv(title, limit=5) if kind == "tv" else tmdb.search(title, limit=5)
                pick  = _tmdb_pick_by_year(found, year)
                if pick:
                    if reason:
                        pick["overview"] = _shorten(reason)
                    (shows if kind == "tv" else movies).append(pick)
            except TMDbError as e:
                _ai_log("AI_TMDb_ERR", f"Search {kind} failed: {title}", details={"err": str(e)})

            done += 1
            try:
                pct = min(98, 95 + int((done / total) * 3))
                prog.update(pct, "Finalizuji výsledky…")
            except Exception:
                pass

        try:
            prog.update(100, "Hotovo.")
            prog.close()
        except Exception:
            pass

        # Render výpisu
        if movies and not shows:
            _list_tmdb_movies(movies)
        elif shows and not movies:
            _list_tmdb_tv(shows)
        else:
            _list_tmdb_ai_mixed(movies, shows)

        if not (movies or shows):
            _modal("Nenašel jsem žádný titul, který by přesně odpovídal Tvému popisu.", heading="RichMovie A.I.")
            _root()

    except AIError as e:
        # RichMovie 3.000: viz _ai_recommend_show — AIError je shim z richmovie_ai_client.
        msg = str(e)
        _ai_log("AI_ERROR", msg, details={"kind": "identify", "query": user_text})
        _modal(f"Chyba AI: {msg}", heading="RichMovie A.I.")
        _root()
    except Exception as e:
        _ai_log("UNEXPECTED_ERROR", str(e), details={"kind": "identify"}, level="ERROR")
        _net_error_ui(e, heading="RichMovie A.I.")
        _root()



def _ai_verify_tmdb_match(kind: str, tmdb: TMDb, item: Dict[str, Any], constraints: Dict[str, Any], tmdb_key: str) -> tuple[bool, Dict[str, Any]]:
    """Delegováno do richmovie_ai"""
    return _ai_module.ai_verify_tmdb_match(kind, tmdb, item, constraints, tmdb_key)




def _list_tmdb_ai_mixed(movies: list[dict], shows: list[dict]) -> None:
    """
    Smíšený výpis pro AI doporučení "Je mi to jedno".

    • Filmy routuji stejně jako `_list_tmdb_movies()` → action="movie_search", q=název.
    • Seriály routuji stejně jako `_list_tmdb_tv()` → action="tv_seasons", tv_id + tv_name.
    """
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    tmdb     = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    xbmcplugin.setContent(HANDLE, "videos")

    # — FILMY —
    for m in movies:
        overview       = (m.get("overview") or "").strip()
        backdrop_path  = m.get("backdrop_path") or ""
        if tmdb and (not overview or not backdrop_path):
            try:
                det = tmdb.details(m.get("id", 0))
                overview      = overview      or (det.get("overview") or "").strip()
                backdrop_path = backdrop_path or (det.get("backdrop_path") or "")
            except TMDbError:
                pass

        rating_txt = f"[B][COLOR gold]★ {m.get('rating', 0)}[/COLOR][/B]\t" if m.get("rating") else ""
        title_core = f"{m.get('title', '')} ({m.get('year', '')})" if m.get("year") else m.get("title", "")
        label      = f"{rating_txt}{title_core}"
        li         = xbmcgui.ListItem(label)

        art = {"icon": "DefaultVideo.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        li.setInfo("video", {
            "title":     m.get("title", ""),
            "plot":      overview,
            "year":      m.get("year") or 0,
            "mediatype": "movie",
            "rating":    m.get("rating", 0),
            "votes":     m.get("votes", 0),
        })
        if m.get("rating"):
            li.setRating("tmdb", m.get("rating", 0), int(m.get("votes", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="movie_search", q=m.get("title", "")),
            li,
            isFolder=True,
        )

    # — SERIÁLY —
    for m in shows:
        overview      = (m.get("overview") or "").strip()
        backdrop_path = m.get("backdrop_path") or ""
        if tmdb and (not overview or not backdrop_path):
            try:
                det = tmdb._get_json(f"/tv/{m.get('id', 0)}", {"api_key": tmdb_key, "language": "cs-CZ"})
                overview      = overview      or (det.get("overview") or "").strip()
                backdrop_path = backdrop_path or (det.get("backdrop_path") or "")
            except TMDbError:
                pass

        rating_txt = f"[B][COLOR gold]★ {m.get('rating', 0)}[/COLOR][/B]\t" if m.get("rating") else ""
        title_core = f"{m.get('name', '')} ({m.get('year', '')})" if m.get("year") else m.get("name", "")
        label      = f"{rating_txt}{title_core}"
        li         = xbmcgui.ListItem(label)

        art = {"icon": "DefaultTVShows.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        li.setInfo("video", {
            "title":     m.get("name", ""),
            "plot":      overview,
            "year":      m.get("year") or 0,
            "mediatype": "tvshow",
            "rating":    m.get("rating", 0),
            "votes":     m.get("votes", 0),
        })
        if m.get("rating"):
            li.setRating("tmdb", m.get("rating", 0), int(m.get("votes", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tv_seasons", tv_id=m.get("id", ""), tv_name=m.get("name", "")),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE)








# 2025-08-10 21:29 CEST  _tmdb_pick_by_year() – výběr nejlepší TMDb položky
def _tmdb_pick_by_year(cands: list[dict], year: int | None) -> dict | None:
    """
    Vrátí položku z kandidátů: preferuje přesnou shodu roku, jinak první položku.
    """
    if not cands:
        return None
    if year:
        for it in cands:
            if it.get("year") == year:
                return it
    return cands[0]









def _movie_row_meta(m: dict, enrich: Optional[dict], tmdb: Optional["TMDb"]) -> Tuple[str, str, int, str]:
    """(popis, pozadí, stopáž v min, štítek premiéry) řádku filmu z výpisu TMDb.

    Φ6 (29.09.2026, D10): obohacení přichází hromadně (`TMDb.movie_enrich_many`, jeden dotaz na výpis);
    řádek bez něj vezme jen DISKOVOU cache detailu (`peek_details`) — dřív tu byl HTTP dotaz na každý film
    zvlášť (40× za sebou, audit A06 F11). Popis a pozadí z výpisu mají přednost (beze změny)."""
    overview = (m.get("overview") or "").strip()
    backdrop_path = m.get("backdrop_path") or ""
    src = enrich if isinstance(enrich, dict) and enrich else None
    if src is None and tmdb is not None:
        try:
            src = tmdb.peek_details(int(m.get("id") or 0)) or None
        except (TypeError, ValueError):
            src = None
    runtime_min = 0
    release_badge = ""
    if src:
        overview = overview or (src.get("overview") or "").strip()
        backdrop_path = backdrop_path or (src.get("backdrop_path") or "")
        try:
            runtime_min = int(src.get("runtime") or 0)
        except (TypeError, ValueError):
            runtime_min = 0
        release_badge = (src.get("release_badge") or "").strip()
    return overview, backdrop_path, runtime_min, release_badge


def _movie_enrich_map(tmdb: Optional["TMDb"], ids: list) -> dict:
    """Obohacení výpisu jedním hromadným dotazem; chyba = prázdná mapa (výpis bez stopáže, nikdy pád)."""
    if tmdb is None:
        return {}
    try:
        with _rm_bc.step("tmdb_enrich", items=len(ids or [])):
            return tmdb.movie_enrich_many(ids, region="CZ", fallback_region="US")
    except Exception as exc:
        _log(f"TMDb movie_enrich_many failed: {exc!r}", xbmc.LOGWARNING)
        return {}


# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _list_tmdb_movies (upraveno: 2025-12-23 21:35 CET (Europe/Prague) – FILMY: stopáž (min) modře + release badge (typ+datum + platforma jen když je dostupná), best-effort přes tmdb.movie_enrich)
# ---------------------------------------------------------------------------- #
@_rm_bc.timed_step("tmdb_list", fields=lambda items, **_kw: {"items": len(items or [])})
def _list_tmdb_movies(items: list[dict], *, next_url=None, page: int = 1) -> None:
    """
    2025-12-23 21:35 CET (Europe/Prague)
    (Φ0 29.09.2026: doba do TRACE `step=tmdb_list`; Trendy p50 9–16 s, audit A02 N3.)

    Renderer výpisu filmů z TMDb (Trendy, TOP, Žánry, A.I. doporučení).

    ZACHOVÁNO:
    ----------
    • Klik na položku vede přímo na `?action=auto&tmdb=<id>` (jedno-klik),
      tj. rovnou spustí workflow `_auto_search_movie(<tmdb_id>)`.
    • Ostatní logika (fallback overview/backdrop, rating, artwork, info, votes) beze změny.

    NOVĚ:
    ------
    • Stopáž filmu v minutách (modře) – best-effort z TMDb.
    • Release štítek (varianta B): typ + datum (primárně CZ, fallback US),
      platforma jen když je dostupná (watch/providers nebo TMDb note) – zobrazeno šedě v názvu.

    Implementačně (Φ6, 29.09.2026, D10):
    • Stopáž a štítek pro CELÝ výpis jedním hromadným dotazem (`_movie_enrich_map` →
      `TMDb.movie_enrich_many`, cache 24 h); řádek bez obohacení vezme jen diskovou cache detailu
      (`_movie_row_meta`). Dřív `movie_enrich` 40× za sebou (p50 3,8 s kolečka, audit A06 F11).
    """
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    tmdb     = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None
    # Φ6 (D10): stopáž a štítek premiéry pro celý výpis JEDNÍM dotazem (dřív 40× `movie_enrich` za sebou)
    enrich_map = _movie_enrich_map(tmdb, [m.get("id") for m in items])

    for m in items:
        try:
            _mid = int(m.get("id") or 0)
        except (TypeError, ValueError):
            _mid = 0
        overview, backdrop_path, runtime_min, release_badge = _movie_row_meta(m, enrich_map.get(_mid), tmdb)

        # Stopáž (modře) – zachováno
        runtime_suffix = f" [COLOR FF87CEFA]({runtime_min} min)[/COLOR]" if runtime_min > 0 else ""

        # Release badge (šedě) – nově
        badge_suffix = f" [COLOR FF9E9E9E]{release_badge}[/COLOR]" if release_badge else ""

        # ★ rating (tučně, zlatě) + název
        rating_txt = (
            f"[B][COLOR gold]★ {m.get('rating', 0)}[/COLOR][/B]\t"
            if m.get("rating") else ""
        )
        title_core = f"{m.get('title', '')} ({m.get('year', '')})" if m.get("year") else m.get("title", "")
        label      = f"{rating_txt}{title_core}{runtime_suffix}{badge_suffix}"

        li = xbmcgui.ListItem(label)

        # Properties pro skin (stopáž + badge)
        if runtime_min > 0:
            try:
                li.setProperty("richmovie.runtime_min", str(runtime_min))
            except Exception:
                pass
        if release_badge:
            try:
                li.setProperty("richmovie.release_badge", release_badge)
            except Exception:
                pass

        # artwork
        art = {"icon": "DefaultVideo.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        # info-panel
        li.setInfo(
            "video",
            {
                "title":     m.get("title", ""),
                "plot":      overview,             # u A.I. výpisů je zde A.I. reason
                "year":      m.get("year") or 0,
                "mediatype": "movie",
                "rating":    m.get("rating", 0),
                "votes":     m.get("votes", 0),
            },
        )
        if m.get("rating"):
            li.setRating("tmdb", m.get("rating", 0), int(m.get("votes", 0)))

        # Kontextove menu: Podobne filmy
        if m.get("id"):
            li.addContextMenuItems([
                ("Podobne filmy", f"Container.Update({_url(action='similar_movies', tmdb_id=str(m['id']))})"),
            ])

        # ⟶ PŘÍMÝ SKOK: použij TMDb ID, žádné další "výběry podobných"
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="auto", tmdb=str(m.get("id", ""))),
            li,
            isFolder=True,
        )

    if next_url:
        _add_next_page_item(next_url, page)
    xbmcplugin.endOfDirectory(HANDLE)




# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _csfd_tv_tips
# _csfd_tv_tips (vytvořeno: 2025-12-28 01:16 CET (Europe/Prague) – ČSFD.cz: TV tipy dne → scrape /televize/ + párování na TMDb + bohatý list jako Trendy/Top; klik = auto search (fallback: TMDb vyhledávání dle názvu))
# ---------------------------------------------------------------------------- #
def _csfd_tv_tips() -> None:
    """
    2025-12-28 01:16 CET (Europe/Prague)

    ČSFD.cz – TV tipy dne (MVP):
    • Z ČSFD bereme primárně jen název + rok (pro přesnější match).
    • Zbytek informací (poster/plot/rating/stopáž/provider) taháme z TMDb.
    • Klik na položku je stejné chování jako u Trendy/Top (TMDb ID → ?action=auto).
      Pokud se TMDb ID nepodaří spárovat, fallback je TMDb vyhledávání dle názvu.

    Cache:
    • Stejná filozofie jako Trendy/Top – denní TTL (24 h) na disk (řeší richmovie_csfd).
    """
    # Φ7 (2026-07-06): RmDir sink — custom UI otevře list okno, legacy 1:1 xbmcplugin
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "TV tipy dne")

    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False); return

    try:
        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        items = richmovie_csfd.get_tv_tips_tmdb_items(
            profile_dir=PROFILE_DIR,
            tmdb=tmdb,
            ttl_seconds=24 * 3600,
        )
    except Exception as e:
        _log(f"[CSFD] TV tips error: {e}", xbmc.LOGERROR)
        _net_error_ui(e, heading="ČSFD")
        rmdir.finish(succeeded=False); return

    if not items:
        _modal("ČSFD: nic nenalezeno.")
        rmdir.finish()
        return

    try:
        xbmcplugin.setPluginCategory(HANDLE, "ČSFD.cz - TV tipy dne")
    except Exception:
        pass
    try:
        xbmcplugin.setContent(HANDLE, "movies")
    except Exception:
        pass

    _list_csfd_tv_tips(items, rmdir)





# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _list_csfd_tv_tips
# _list_csfd_tv_tips (vytvořeno: 2025-12-28 01:16 CET (Europe/Prague) – renderer pro ČSFD TV tipy: stejné GUI jako TMDb filmy + klik = auto search; fallback pro nenapárované = TMDb vyhledávání dle názvu)
# ---------------------------------------------------------------------------- #
def _list_csfd_tv_tips(items: list[dict], rmdir) -> None:
    """
    Renderer výpisu ČSFD "TV tipy dne" — pure-view na pre-enriched Gate data.
    Sink = RmDir volajícího (Φ7 2026-07-06) — renderer dokončuje i finish().

    Beta.6+ (2026-04-24): TMDb enrichment probíhá na Gate při scrape, addon
    dostává rovnou `runtime`, `rating`, `votes`, `poster_path`, `backdrop_path`,
    `overview`. Žádné per-item `tmdb.movie_enrich()` volání — rendering je
    instant (< 1 s pro 34 tipů), žádné N×HTTP na TMDb proxy.

    Položky s `id=0` (TMDb match nenamatched na Gate straně) → klik vede
    na `movie_search` s předvyplněným dotazem (název + rok).
    """
    for m in items:
        overview      = (m.get("overview") or "").strip()
        backdrop_path = m.get("backdrop_path") or ""

        try:
            _mid = int(m.get("id") or 0)
        except Exception:
            _mid = 0

        try:
            runtime_min = int(m.get("runtime") or 0)
        except Exception:
            runtime_min = 0

        # release_badge (CZ premiéra dd.MM.YYYY) prozatím nepřednačítáme —
        # vyžaduje samostatnou /release_dates TMDb logiku. Budoucí rozšíření
        # Gate scraperu. Pro beta.6 prázdné, Kodi UI badge_suffix se nevypíše.
        release_badge = ""

        # Stopáž (modře) – zachováno
        runtime_suffix = f" [COLOR FF87CEFA]({runtime_min} min)[/COLOR]" if runtime_min > 0 else ""

        # Release badge (šedě) – zachováno
        badge_suffix = f" [COLOR FF9E9E9E]{release_badge}[/COLOR]" if release_badge else ""

        # ★ rating (tučně, zlatě) + název
        rating_txt = (
            f"[B][COLOR gold]★ {m.get('rating', 0)}[/COLOR][/B]\t"
            if m.get("rating") else ""
        )
        title_core = f"{m.get('title', '')} ({m.get('year', '')})" if m.get("year") else m.get("title", "")
        label      = f"{rating_txt}{title_core}{runtime_suffix}{badge_suffix}"

        li = xbmcgui.ListItem(label)

        # Properties pro skin (stopáž + badge)
        if runtime_min > 0:
            try:
                li.setProperty("richmovie.runtime_min", str(runtime_min))
            except Exception:
                pass
        if release_badge:
            try:
                li.setProperty("richmovie.release_badge", release_badge)
            except Exception:
                pass

        # artwork
        art = {"icon": "DefaultVideo.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        # info-panel
        li.setInfo(
            "video",
            {
                "title":     m.get("title", ""),
                "plot":      overview,
                "year":      m.get("year") or 0,
                "mediatype": "movie",
                "rating":    m.get("rating", 0),
                "votes":     m.get("votes", 0),
            },
        )
        if m.get("rating"):
            li.setRating("tmdb", m.get("rating", 0), int(m.get("votes", 0)))

        # ⟶ Klik: TMDb ID → auto search; fallback: TMDb vyhledávání dle názvu (název + rok)
        if _mid > 0:
            _target = _url(action="auto", tmdb=str(_mid))
        else:
            try:
                _y = int(m.get("year") or 0)
            except Exception:
                _y = 0
            _q = f"{(m.get('title') or '').strip()} {_y}".strip() if _y > 0 else ((m.get('title') or '').strip())
            _target = _url(action="movie_search", q=_q)

        rmdir.add(
            _target,
            li,
            isFolder=True,
        )

    rmdir.finish()


# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _csfd_home
# _csfd_home (vytvořeno: 2026-04-03 – ČSFD rozcestník: TV tipy dne + Novinky z ČSFD.cz)
# ---------------------------------------------------------------------------- #
def _csfd_home() -> None:
    """ČSFD rozcestník — složka se dvěma položkami."""
    # Φ7 (2026-07-06): RmDir sink — custom UI otevře list okno, legacy 1:1 xbmcplugin
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "ČSFD TV tipy a novinky")
    xbmcplugin.setPluginCategory(HANDLE, "ČSFD")
    xbmcplugin.setContent(HANDLE, "files")

    icons_dir = os.path.join(
        xbmcvfs.translatePath(ADDON.getAddonInfo("path")),
        "resources", "media", "icons",
    )
    icon_csfd = os.path.join(icons_dir, "csfd_tv_tipy.png")
    try:
        if not xbmcvfs.exists(icon_csfd):
            icon_csfd = "DefaultVideo.png"
    except Exception:
        icon_csfd = "DefaultVideo.png"

    # 1) TV tipy dne
    li = xbmcgui.ListItem("TV tipy dne")
    li.setArt({"icon": icon_csfd, "thumb": icon_csfd})
    rmdir.add(_url(action="csfd_tv_tips"), li, True)

    # 2) Novinky z ČSFD.cz (trailery + rozhovory z Gate)
    li = xbmcgui.ListItem("Novinky z ČSFD.cz")
    li.setArt({"icon": icon_csfd, "thumb": icon_csfd})
    rmdir.add(_url(action="csfd_trailers"), li, True)

    # 3) Top 1000 ČSFD filmů
    li = xbmcgui.ListItem("Top 1000 filmů ČSFD")
    li.setArt({"icon": icon_csfd, "thumb": icon_csfd})
    rmdir.add(_url(action="csfd_top_films", page="1"), li, True)

    rmdir.finish()


# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _csfd_trailers
# _csfd_trailers (vytvořeno: 2026-04-03 – Novinky z ČSFD.cz: trailery/rozhovory z Gate /trailers endpoint)
# ---------------------------------------------------------------------------- #
def _csfd_trailers() -> None:
    """Načte trailery/rozhovory z Gate /trailers a zobrazí jako playable list."""
    import richmovie_gate
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "Novinky z ČSFD.cz")

    gate_url = richmovie_gate.get_gate_url()
    if not gate_url:
        _notif("Gate nedostupný", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    # Fetch trailers from Gate
    try:
        data = _http_get_json(f"{gate_url}/trailers", timeout=10)
    except Exception as e:
        _log("[CSFD] Trailers fetch error: %s" % e, xbmc.LOGERROR)
        _notif("Nelze načíst novinky z ČSFD", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    trailers = data.get("trailers", [])
    if not trailers:
        _modal("Žádné novinky z ČSFD.cz.")
        rmdir.finish()
        return

    xbmcplugin.setPluginCategory(HANDLE, "Novinky z ČSFD.cz")
    xbmcplugin.setContent(HANDLE, "videos")

    for t in trailers:
        title = t.get("title", "")
        year = t.get("year")
        video_title = t.get("video_title", "Trailer")
        duration = t.get("duration") or 0

        # Label: "Název (rok) — Trailer [délka]"
        label_parts = [title]
        if year:
            label_parts[0] = f"{title} ({year})"
        label_parts.append(f"[COLOR FF87CEFA]{video_title}[/COLOR]")
        if duration > 0:
            mins = duration // 60
            secs = duration % 60
            label_parts.append(f"[COLOR FF9E9E9E]{mins}:{secs:02d}[/COLOR]")
        label = " — ".join(label_parts)

        li = xbmcgui.ListItem(label)
        li.setProperty("IsPlayable", "true")

        # Artwork
        art = {"icon": "DefaultVideo.png"}
        poster = t.get("poster_url")
        if poster:
            art["poster"] = poster
            art["thumb"] = poster
        li.setArt(art)

        # Info
        plot = f"{video_title}: {title}"
        if year:
            plot += f" ({year})"
        li.setInfo("video", {
            "title": title,
            "plot": plot,
            "year": year or 0,
            "mediatype": "video",
        })

        # Build play URL with all needed params
        play_params = {
            "action": "csfd_trailer_play",
            "url": t.get("video_url", ""),
            "title": title,
        }
        if t.get("subtitle_url"):
            play_params["subs"] = t["subtitle_url"]
        if t.get("poster_url"):
            play_params["poster"] = t["poster_url"]

        rmdir.add(_url(**play_params), li, False)

    rmdir.finish()


# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _csfd_trailer_play
# _csfd_trailer_play (vytvořeno: 2026-04-03 – Přehrání ČSFD traileru s titulky)
# ---------------------------------------------------------------------------- #
def _csfd_trailer_play() -> None:
    """Přehraje ČSFD trailer (MP4) s volitelnými českými titulky (WebVTT)."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    video_url = params.get("url", [""])[0]
    title = params.get("title", [""])[0]
    subs_url = params.get("subs", [""])[0]
    poster = params.get("poster", [""])[0]

    if not video_url:
        _modal("Chybí URL pro přehrání.")
        return

    li = xbmcgui.ListItem(path=video_url)
    li.setInfo("video", {"title": title, "mediatype": "video"})
    li.setProperty("richmovie.source", "csfd_trailer")
    if poster:
        li.setArt({"poster": poster, "thumb": poster})

    if subs_url:
        li.setSubtitles([subs_url])

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _csfd_top_films
# _csfd_top_films (vytvořeno: 2026-04-04 – Top 1000 ČSFD filmů: stránkovaný list z Gate, TMDb enrichment per stránku)
# ---------------------------------------------------------------------------- #
_CSFD_TOP_PER_PAGE = 50


def _csfd_top_films() -> None:
    """Top 1000 filmů ČSFD — stránkovaný list s TMDb obohacením."""
    import richmovie_gate

    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    page = 1
    try:
        page = max(1, min(1000, int(params.get("page", ["1"])[0])))
    except (ValueError, TypeError):
        page = 1

    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "Top 1000 filmů ČSFD")

    # --- Disk cache pro Gate /top-films (fallback při výpadku Gate) ---
    _CSFD_CACHE_TTL = 24 * 60 * 60  # 24 h
    _csfd_cache_dir = PROFILE_DIR / "csfd_top_cache"
    _csfd_cache_dir.mkdir(parents=True, exist_ok=True)
    _csfd_cache_file = _csfd_cache_dir / f"page_{page}.json"

    def _csfd_cache_load() -> dict | None:
        """Načte stránku z disk cache, vrátí None pokud neexistuje nebo expirovala."""
        try:
            if not _csfd_cache_file.exists():
                return None
            age = time.time() - _csfd_cache_file.stat().st_mtime
            if age > _CSFD_CACHE_TTL:
                return None
            with open(_csfd_cache_file, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return None

    def _csfd_cache_save(payload: dict) -> None:
        """Uloží stránku do disk cache (trvanlivý atomický zápis přes SSOT)."""
        if not richmovie_atomic.write_json(str(_csfd_cache_file), payload):
            _log("[CSFD] Cache save error", xbmc.LOGWARNING)

    # --- Fetch z Gate s fallback na disk cache ---
    data = None
    gate_url = richmovie_gate.get_gate_url()

    if gate_url:
        try:
            data = _http_get_json(f"{gate_url}/top-films?page={page}&per_page={_CSFD_TOP_PER_PAGE}", timeout=10)
            _csfd_cache_save(data)
        except Exception as e:
            _log("[CSFD] Top films fetch error: %s" % e, xbmc.LOGERROR)
            data = None

    if data is None:
        data = _csfd_cache_load()
        if data is not None:
            _log("[CSFD] Serving page %d from disk cache" % page, xbmc.LOGINFO)

    if data is None:
        _notif("Gate nedostupný a cache prázdná", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    films = data.get("films", [])
    total = data.get("total", 0)

    if not films:
        _modal("Žádné filmy v žebříčku.")
        rmdir.finish()
        return

    xbmcplugin.setPluginCategory(HANDLE, "Top 1000 filmů ČSFD")
    xbmcplugin.setContent(HANDLE, "movies")

    tmdb_key = richmovie_settings.get_tmdb_api_key()
    tmdb = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    # Φ6 (D10): TMDb obohacení stránky JEDNÍM hromadným dotazem (dřív 4 vlákna × dotaz po jednom a
    # `xbmcgui.DialogBusy`, které v Kodi 19+ neexistuje — kolečko se tu nikdy neukázalo)
    enrich_map = _movie_enrich_map(tmdb, [f.get("tmdb_id", 0) for f in films if f.get("tmdb_id", 0) > 0])

    for f in films:
        rank = f.get("rank", 0)
        title = f.get("title", "")
        year = f.get("year") or 0
        csfd_rating = f.get("csfd_rating", 0)
        tmdb_id = f.get("tmdb_id", 0)

        overview = ""
        poster_path = ""
        backdrop_path = ""
        runtime_min = 0
        tmdb_rating = 0
        tmdb_votes = 0
        release_badge = ""

        enrich = enrich_map.get(tmdb_id)
        if enrich:
            overview = (enrich.get("overview") or "").strip()
            poster_path = enrich.get("poster_path") or ""
            backdrop_path = enrich.get("backdrop_path") or ""
            release_badge = (enrich.get("release_badge") or "").strip()
            try:
                runtime_min = int(enrich.get("runtime") or 0)
            except Exception:
                pass
            try:
                tmdb_rating = float(enrich.get("vote_average") or 0)
                tmdb_votes = int(enrich.get("vote_count") or 0)
            except Exception:
                pass

        # Label: "1.  ★ 8.7  Vykoupení z věznice Shawshank (1994)  ČSFD 95%  (142 min)  Blu-ray CZ 15.10.2010"
        rating_txt = (
            f"[B][COLOR gold]\u2605 {tmdb_rating:.1f}[/COLOR][/B]\t"
            if tmdb_rating else ""
        )
        title_core = f"{title} ({year})" if year else title
        csfd_pct = f"{csfd_rating:.0f}%" if csfd_rating == int(csfd_rating) else f"{csfd_rating}%"
        csfd_suffix = f"  [COLOR FFFF6347]CSFD {csfd_pct}[/COLOR]"
        runtime_suffix = f" [COLOR FF87CEFA]({runtime_min} min)[/COLOR]" if runtime_min > 0 else ""
        badge_suffix = f" [COLOR FF9E9E9E]{release_badge}[/COLOR]" if release_badge else ""

        label = f"{rank}. {rating_txt}{title_core}{csfd_suffix}{runtime_suffix}{badge_suffix}"

        li = xbmcgui.ListItem(label)

        # Properties pro skin
        if runtime_min > 0:
            try:
                li.setProperty("richmovie.runtime_min", str(runtime_min))
            except Exception:
                pass
        if release_badge:
            try:
                li.setProperty("richmovie.release_badge", release_badge)
            except Exception:
                pass

        # Artwork
        art = {"icon": "DefaultVideo.png"}
        if poster_path:
            art["poster"] = f"https://image.tmdb.org/t/p/w342{poster_path}"
            art["thumb"] = f"https://image.tmdb.org/t/p/w185{poster_path}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        # Info panel
        li.setInfo("video", {
            "title": title,
            "plot": overview,
            "year": year,
            "mediatype": "movie",
            "rating": tmdb_rating,
            "votes": tmdb_votes,
        })
        if tmdb_rating:
            li.setRating("tmdb", tmdb_rating, tmdb_votes)

        # Click → auto search via TMDb ID (same as TV tips)
        if tmdb_id > 0:
            target = _url(action="auto", tmdb=str(tmdb_id))
        else:
            q = f"{title.strip()} {year}".strip() if year else title.strip()
            target = _url(action="movie_search", q=q)

        rmdir.add(target, li, isFolder=True)

    # "Další stránka" link
    next_offset = page * _CSFD_TOP_PER_PAGE
    if next_offset < total:
        li = xbmcgui.ListItem(f"[B]Dalsi stranka ({page + 1}/{(total + _CSFD_TOP_PER_PAGE - 1) // _CSFD_TOP_PER_PAGE})[/B]")
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(
            _url(action="csfd_top_films", page=str(page + 1)), li, True,
        )

    rmdir.finish()

    if not rmdir.custom:
        # R3-P2-8: view mode jen v legacy — v custom režimu by builtin po zavření
        # list okna cílil na CIZÍ podkladový kontejner (Kodi Home/Videos).
        # WideList view (55 v Estuary): vlevo plakát + popis, vpravo seznam, fanart na pozadí
        xbmc.executebuiltin("Container.SetViewMode(55)")




def _tmdb_trending() -> None:
    """🔥 Nejtrendovější filmy z TMDb (/trending/movie/day)."""
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    page = _page_param()
    try:
        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        movies = tmdb.trending(limit=_TMDB_LIST_PER_PAGE, page=_tmdb_start_page(page))
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    _list_tmdb_movies(movies, next_url=_tmdb_next_page_url(movies, page, action="tmdb_trending"), page=page)




def _tmdb_top() -> None:
    """TOP hodnocené filmy (/movie/top_rated)."""
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    page = _page_param()
    try:
        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        movies = tmdb.top_rated(page=_tmdb_start_page(page), limit=_TMDB_LIST_PER_PAGE)
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    _list_tmdb_movies(movies, next_url=_tmdb_next_page_url(movies, page, action="tmdb_top"), page=page)




def _list_tmdb_tv(items: list[dict], *, next_url=None, page: int = 1) -> None:
    """
    Renderer výpisu seriálů z TMDb (Trendy, TOP).

    Aktualizováno: 10-08-2025 17:03 CEST (Europe/Prague)
    """
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    tmdb     = TMDb(tmdb_key, lang="cs-CZ") if tmdb_key else None

    xbmcplugin.setContent(HANDLE, "tvshows")

    for m in items:
        # –– metadata fallback (overview / backdrop) ––
        overview      = (m.get("overview") or "").strip()
        backdrop_path = m.get("backdrop_path") or ""
        if tmdb and (not overview or not backdrop_path):
            try:
                det = tmdb._get_json(
                    f"/tv/{m.get('id', 0)}",
                    {"api_key": tmdb_key, "language": "cs-CZ"},
                )
                overview      = overview      or (det.get("overview") or "").strip()
                backdrop_path = backdrop_path or (det.get("backdrop_path") or "")
            except TMDbError:
                pass

        # ★ rating (tučně, zlatě) + název
        rating_txt = (
            f"[B][COLOR gold]★ {m.get('rating', 0)}[/COLOR][/B]\t"
            if m.get("rating") else ""
        )
        title_core = f"{m.get('name', '')} ({m.get('year', '')})" if m.get("year") else m.get("name", "")
        label      = f"{rating_txt}{title_core}"

        li = xbmcgui.ListItem(label)

        # artwork – poster/thumb/fanart
        art = {"icon": "DefaultTVShows.png"}
        if (p := m.get("poster_path")):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{p}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{p}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        # info‑panel
        li.setInfo(
            "video",
            {
                "title":     m.get("name", ""),
                "plot":      overview,
                "year":      m.get("year") or 0,
                "mediatype": "tvshow",
                "rating":    m.get("rating", 0),
                "votes":     m.get("votes", 0),
            },
        )
        if m.get("rating"):
            li.setRating("tmdb", m.get("rating", 0), int(m.get("votes", 0)))

        # Kontextove menu: Podobne serialy
        if m.get("id"):
            li.addContextMenuItems([
                ("Podobne serialy", f"Container.Update({_url(action='similar_tv', tmdb_id=str(m['id']))})"),
            ])

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tv_seasons", tv_id=m.get("id", ""), tv_name=m.get("name", "")),
            li,
            isFolder=True,
        )

    if next_url:
        _add_next_page_item(next_url, page)
    xbmcplugin.endOfDirectory(HANDLE)





def _tmdb_tv_trending() -> None:
    """Seriály – Trendy dnes (/trending/tv/day).

    Aktualizováno: 10-08-2025 17:03 CEST (Europe/Prague)
    """
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    page = _page_param()
    try:
        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        shows = tmdb.trending_tv(limit=_TMDB_LIST_PER_PAGE, page=_tmdb_start_page(page))
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    _list_tmdb_tv(shows, next_url=_tmdb_next_page_url(shows, page, action="tmdb_tv_trending"), page=page)


def _tmdb_tv_top() -> None:
    """Seriály – TOP hodnocené (/tv/top_rated).

    Aktualizováno: 10-08-2025 17:03 CEST (Europe/Prague)
    """
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    page = _page_param()
    try:
        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        shows = tmdb.top_rated_tv(page=_tmdb_start_page(page), limit=_TMDB_LIST_PER_PAGE)
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    _list_tmdb_tv(shows, next_url=_tmdb_next_page_url(shows, page, action="tmdb_tv_top"), page=page)


def _tmdb_similar_movies() -> None:
    """Podobne filmy k danemu TMDb ID – pouziva existujici _list_tmdb_movies renderer."""
    tmdb_id = 0
    try:
        tmdb_id = int((params.get("tmdb_id") or params.get("tmdb", ["0"]))[0])
    except (ValueError, IndexError):
        pass
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key or tmdb_id <= 0:
        _notif("Chybi API klic nebo TMDb ID", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    try:
        movies = TMDb(tmdb_key, lang="cs-CZ").similar_movies(tmdb_id, limit=40)
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    if not movies:
        _modal("Zadne podobne filmy nenalezeny.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    _list_tmdb_movies(movies)


def _tmdb_similar_tv() -> None:
    """Podobne serialy k danemu TMDb ID – pouziva existujici _list_tmdb_tv renderer."""
    tmdb_id = 0
    try:
        tmdb_id = int((params.get("tmdb_id") or params.get("tmdb", ["0"]))[0])
    except (ValueError, IndexError):
        pass
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key or tmdb_id <= 0:
        _notif("Chybi API klic nebo TMDb ID", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    try:
        shows = TMDb(tmdb_key, lang="cs-CZ").similar_tv(tmdb_id, limit=40)
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    if not shows:
        _modal("Zadne podobne serialy nenalezeny.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    _list_tmdb_tv(shows)



def _tmdb_genres() -> None:
    """Výpis filmových žánrů (submenu)."""
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    try:
        genres = TMDb(tmdb_key, lang="cs-CZ").genres()
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    for g in genres:
        li = xbmcgui.ListItem(g.get("name", ""))
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tmdb_genre", genre_id=g.get("id", "")),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)






def _tmdb_genre_movies(genre_id: int) -> None:
    """Filmy v daném žánru seřazené podle hodnocení."""
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _notif("Chybí API klíč TMDb", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    page = _page_param()
    try:
        tmdb = TMDb(tmdb_key, lang="cs-CZ")
        movies = tmdb.discover_by_genre(
            genre_id, sort_by="vote_average.desc", vote_count_gte=100,
            page=page, limit=_TMDB_GENRE_PER_PAGE,
        )
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    _list_tmdb_movies(
        movies,
        next_url=_tmdb_next_page_url(movies, page, _TMDB_GENRE_PER_PAGE, action="tmdb_genre", genre_id=str(genre_id)),
        page=page,
    )





# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _list_releases
# _list_releases (upraveno: 27.12.2025 13:42 CET (Europe/Prague) – FIX: (1) title_penalty pro jednoslovné seriály (balast dolů ještě před MI2), (2) MI2 refresh marker clear best-effort i při key mismatch + vynucené updateListing=True)
# ---------------------------------------------------------------------------- #
_CUSTOM_UI_CACHE = None  # in-memory cache per-invoker (Gate perm čte disk cache)
_GATE_REFRESH_THROTTLE_PROP = "richmovie.gate_refresh_ts"
_GATE_REFRESH_MIN_INTERVAL_S = 300  # 5 min — reakce na změnu custom_ui v Gate


def _ensure_gate_cache_fresh() -> None:
    """Best-effort refresh Gate cache (permissions vč. custom_ui) PŘED UI cutover.

    M1 fix: custom UI flow (action=root → home_window) jinak NIKDY nevolá gate_auth
    (ten je jen v _root()/legacy) → Gate cache by se v custom režimu neobnovila →
    per-account gate (custom_ui) by se neaplikoval. Tady zajistíme, že KAŽDÝ vstup
    do RichMovie (root) cache osvěží — throttle ~5 min, ať se HTTP /auth neopakuje
    při rychlých re-vstupech. Best-effort: chyba/Gate down nevadí (gate_auth má
    vlastní lease+grace fallback). NEvolat při classic override (ten jde do _root,
    kde gate_auth proběhne tak jako tak)."""
    import time as _t
    try:
        win = xbmcgui.Window(10000)
        last = (win.getProperty(_GATE_REFRESH_THROTTLE_PROP) or "").strip()
        if last and (_t.time() - float(last)) < _GATE_REFRESH_MIN_INTERVAL_S:
            return
        user = (richmovie_settings.get_str("username") or "").strip()
        token = (richmovie_settings.get_str("token") or "").strip()
        pw = (richmovie_settings.get_str("password") or "").strip()
        if not (user and token):
            return  # bez identity nelze authnout — cache zůstane (fail-safe True)
        # Φ3 D5: s platnou lease hned z ní, `/auth` na pozadí (oprávnění custom_ui se tak
        # projeví o jedno otevření později — stejný kompromis jako u klasického menu)
        _gate_auth_menu(_client(), user, pw)
        win.setProperty(_GATE_REFRESH_THROTTLE_PROP, str(_t.time()))
        # invaliduj in-memory cache, ať _rm_new_ui čte čerstvé permissions
        global _CUSTOM_UI_CACHE
        _CUSTOM_UI_CACHE = None
    except Exception:
        pass


_TMDB_LIST_PER_PAGE = 40          # Trendy / TOP — položek na stránku (2 TMDb stránky po 20)
_TMDB_GENRE_PER_PAGE = 20         # Žánr — discover_by_genre čte jednu TMDb stránku
_TMDB_LIST_MAX_PAGE = 25          # 1 000 titulů = strop TMDb i zdravého rozumu


def _page_param(default: int = 1, lo: int = 1, hi: int = _TMDB_LIST_MAX_PAGE) -> int:
    """SSOT čtení `page` z parametrů pluginu (3.5.131, audit stránkování):
    nečíslo/mimo rozsah → clamp, nikdy výjimka (dřív `int(params["page"])` bez
    ochrany → u Moje ČSFD prázdný výpis místo první stránky)."""
    raw = (params.get("page") or [str(default)])[0]
    try:
        value = int(str(raw).strip())
    except (TypeError, ValueError):
        value = default
    return max(lo, min(hi, value))


def _tmdb_start_page(page: int, per_page: int = _TMDB_LIST_PER_PAGE) -> int:
    """Stránka výpisu N (1-based, `per_page` položek) → počáteční TMDb stránka
    (TMDb vrací 20/stránku). Klient pak stáhne jen `per_page // 20` stránek —
    žádné kumulativní stahování 1..N (cross-check Pro PB8)."""
    return (max(1, page) - 1) * (per_page // 20) + 1


def _tmdb_next_page_url(items: list, page: int, per_page: int = _TMDB_LIST_PER_PAGE, **extra):
    """URL položky „Další stránka", dokud stránka není prázdná (jinak None).
    Klient filtruje (latinka, dedup), takže „méně než 40“ neznamená konec
    (cross-check Pro PB9); TMDb seznamy mají ~500 stránek, strop drží
    `_TMDB_LIST_MAX_PAGE`."""
    if not items or page >= _TMDB_LIST_MAX_PAGE:
        return None
    return _url(page=str(page + 1), **extra)


def _add_next_page_item(next_url, page: int) -> None:
    li = xbmcgui.ListItem(f"[B]→ Další stránka[/B]  ({page + 1})")
    li.setArt({"icon": "DefaultFolderBack.png", "thumb": "DefaultFolderBack.png"})
    xbmcplugin.addDirectoryItem(HANDLE, next_url, li, isFolder=True)


def _build_tip_rotator():
    """SSOT sestavení rotátoru hlášek pro dialog hledání (3.5.131): uživatel s
    vlastním souborem hlášek dostane své (persistence, 3 s), ostatní náhodné ČSFD
    TV tipy z cache (6 s), bez cache obecné hlášky. Nikdy nevyhodí výjimku —
    dialog s hláškami je UX, ne funkčnost hledání; při chybě vrátí None
    (`_SearchProgressWithTips` pak jede bez rotace)."""
    try:
        import richmovie_search_tips
        _ws_user = (richmovie_settings.get_str("username") or "").strip()
        import richmovie_paths
        rotator, _mode = richmovie_search_tips.build_rotator(
            str(ADDON_DIR), _ws_user, str(richmovie_paths.personal_dir()))
        return rotator
    except Exception as _tip_exc:
        _log(f"tip rotator build failed: {_tip_exc!r}", xbmc.LOGWARNING)
        return None


def _custom_ui_enabled() -> bool:
    """Per-účet gate pro RM 4.0 custom UI — řízeno z RichMovie Gate (enterprise,
    nastavitelné server-side per-user). Priorita:
      1) setting rm_custom_ui: on/off = manuální override (dev PC = on);
      2) auto (default) → Gate permission ``custom_ui`` (per-user, lease+grace);
      3) fail-safe = False (legacy) — bezpečné pro rodinu, dokud Gate flag není.
    Výsledek se cachuje per-invoker (Gate perm = disk JSON, _rm_new_ui volán často)."""
    global _CUSTOM_UI_CACHE
    if _CUSTOM_UI_CACHE is not None:
        return _CUSTOM_UI_CACHE
    val = False  # fail-safe = legacy (rodina nesmí dostat beta UI bez povolení)
    try:
        sel = (richmovie_settings.get_str("rm_custom_ui") or "auto").strip().lower()
        if sel == "on":
            val = True
        elif sel == "off":
            val = False
        else:  # auto → Gate per-user gate (fail-safe legacy, viz accessor)
            import richmovie_gate
            val = bool(richmovie_gate.is_custom_ui_allowed())
    except Exception:
        val = False  # fail-safe = legacy (incident bandog 2026-06-24: fail-open zapnul beta UI rodině)
    _CUSTOM_UI_CACHE = val
    return val


def _log_ui_decision(mode: str) -> None:
    """Telemetrie UI režimu do Gate (observability per-účet pojistky custom_ui).

    1× per Kodi session zaloguje, jaký režim účet REÁLNĚ dostal (custom/legacy)
    + proč (gate flag / override / classic). V Gate SQLAdmin (Uživatelské logy,
    filtr ws_user/source) je pak vidět, KDO custom UI používá → kdyby se objevil
    neočekávaný účet (rodina), anomálie je okamžitě viditelná. Best-effort."""
    try:
        win = xbmcgui.Window(10000)
        if win.getProperty("richmovie.ui_decision_logged") == "1":
            return
        gate_flag = None
        try:
            import richmovie_gate
            perms = richmovie_gate.get_permissions()
            gate_flag = perms.get("custom_ui", None)  # True/False/None(chybí)
        except Exception:
            pass
        ctx = {
            "ui_mode": mode,
            "gate_custom_ui": gate_flag,
            "rm_custom_ui_setting": (richmovie_settings.get_str("rm_custom_ui") or "auto"),
            "rm_classic_ui": (richmovie_settings.get_str("rm_classic_ui") or "false"),
            "ws_user": (richmovie_settings.get_str("username") or "").strip(),
        }
        # ANOMÁLIE: custom UI běží, ale Gate ho NEpovolil (jede přes override/
        # fail-safe) → WARNING (ať v Gate vyskočí); jinak INFO (běžná telemetrie).
        anomaly = (mode == "custom" and gate_flag is False)
        _log(f"RM4_UI_MODE={mode} gate_custom_ui={gate_flag}"
             + (" [ANOMALY: custom UI bez Gate povolení]" if anomaly else ""),
             xbmc.LOGWARNING if anomaly else xbmc.LOGINFO, context=ctx)
        win.setProperty("richmovie.ui_decision_logged", "1")
    except Exception:
        pass


def _rm_new_ui() -> bool:
    """SSOT: True = RM 4.0 custom UI režim. Platí, KDYŽ: (a) není rm_classic_ui
    a (b) účet má custom UI povolené (Gate per-user gate, viz _custom_ui_enabled).

    V novém režimu se POTLAČUJE legacy progress UI (search tips dialog, MI2 wait
    okna) — okamžitou odezvu obstarává picker-first Stream-picker. Rodina bez
    custom_ui povolení → False → plné legacy chování (directory UI)."""
    try:
        import richmovie_ui_common as _uc_origin
        if _uc_origin.tv_origin_active():               # z Televize na film: vždy výběr streamů (jinak by nešel návrat na kanál)
            return True
        if (richmovie_settings.get_str("rm_classic_ui") or "false").strip().lower() == "true":
            return False
        return _custom_ui_enabled()
    except Exception:
        return False


def _mi2_prepare(
    rels: List[Release],
    listing_key: str,
    progress: Optional["_SearchProgressWithTips"] = None,
    cap_s: Optional[float] = None,
) -> str:
    """
    Spustí MI2 dávku pro `listing_key` a volitelně na ni chvíli počká.

    PROČ TADY A NE V `_list_releases` (incident Petra / Sony 19.09.2026)
    --------------------------------------------------------------------
    Čekání na MI2 bylo dřív uvnitř `_list_releases`, kde si kvůli němu otevíralo
    VLASTNÍ modální `DialogProgress` — druhý v téže invokaci pluginu, a to až na
    60 s. Na Sony BRAVIA z toho bylo 36 s od kliku k seznamu (16:35:13 → 16:35:49),
    dvakrát zaplacené `close_with_min_display(4.0)` a stisk Zpět se celou dobu
    ignoroval (`iscanceled()` se nečetlo). Na Chromecastu (rychlá MI cache) se
    čekání nespustilo vůbec — proto tam seznam naskočil za 1 s.

    Teď je čekání součástí FÁZE HLEDÁNÍ, kde už dialog otevřený JE: pokračuje
    v něm, uživatel vidí jeden průběh a `_list_releases` je čistý renderer.

    Návratová hodnota: důvod ukončení čekání (pro telemetrii) —
    "no_wait" | "mi2_done" | "first_screen" | "cancelled" | "abort" | "cap".
    """
    if not rels:
        return "no_wait"
    _stel_run = _rm_stel.current()
    if _stel_run is not None:
        _stel_run.mark("mi2")
        _SEARCH_LOG.flush()        # konec fáze hledání = dávka na disk (pád při čekání nic nevezme)

    mi2_mod = sys.modules.get("richmovie_mi2")
    if not mi2_mod:
        try:
            mi2_mod = importlib.import_module("richmovie_mi2")
        except Exception as _imp_err:
            try:
                _log_event("MI2_IMPORT_FAIL", str(_imp_err))
            except Exception:
                pass
            return "no_wait"

    MI2 = getattr(mi2_mod, "MediaInfoSecondEdition", None)
    if not MI2:
        return "no_wait"

    # Rozhoduje VÝHRADNĚ `MI2.start()` — má vlastní bránu s TTL 180 s a porovnáním
    # klíče (`SKIP_GLOBAL`). Vlastní brána nad `richmovie.mi2.running` tady byla vada
    # (audit Fable P1 #1): Window property nemá TTL a přežije zabitý interpret, takže
    # zaseknutý marker by zablokoval MediaInfo pro VŠECHNY listingy až do restartu Kodi.
    try:
        client_factory = getattr(_ENGINE, "_get_client", None)
        if not callable(client_factory):
            client_factory = (lambda: _SESSION.client)

        MI2.start(
            releases=rels[:_rm_listing.MI2_BATCH_ITEMS],
            client_factory=client_factory,
            fs_client_factory=_get_fastshare_client,
            first_batch=8,
            max_items=_rm_listing.MI2_BATCH_ITEMS,
            refresh=True,
            key=listing_key,
        )
        _log_event("MI2_START", "ctx=mi2_prepare", f"count={min(len(rels), _rm_listing.MI2_BATCH_ITEMS)}",
                   f"key={listing_key}")
    except Exception as _kick_err:
        try:
            _log_event("MI2_KICK_FAIL", str(_kick_err))
        except Exception:
            pass
        return "no_wait"

    budget = float(_rm_listing.MI2_WAIT_CAP_S if cap_s is None else cap_s)
    if budget <= 0.0:
        return "no_wait"

    def _flags(ident: str) -> Dict[str, Any]:
        try:
            eng_mod = sys.modules.get("richmovie_engine")
            fn = getattr(eng_mod, "mi2_get_flags", None) if eng_mod else None
            return (fn(ident) or {}) if callable(fn) else {}
        except Exception:
            return {}

    mon = xbmc.Monitor()
    t0 = time.time()
    reason = "cap"
    _shown = (-1, -1)   # poslední (vyřízeno, celkem) v dialogu — překreslit jen při změně

    while (time.time() - t0) < budget:
        # a) MI2 dojelo
        try:
            thr_now = getattr(MI2, "_RUNNING_THR", None)
            if not thr_now or not getattr(thr_now, "is_alive", lambda: False)():
                reason = "mi2_done"
                break
        except Exception:
            reason = "mi2_done"
            break

        # b) první obrazovka je vyřízená (Φ5A, D3: čeká se na ~10 řádků, které uživatel uvidí,
        #    ne na všech 32 — zbytek MI2 doplní tiše na pozadí)
        try:
            _settled, _total = _rm_listing.first_screen_settled(rels, _flags)
            if progress is not None and (_settled, _total) != _shown:
                _shown = (_settled, _total)
                progress.set_phase("Zjišťuji dabing a kvalitu", _settled, _total)
            if _total and _settled >= _total:
                reason = "first_screen"
                break
        except Exception:
            pass

        # c) uživatel zmáčkl Zrušit / Zpět — DŘÍV se to ignorovalo celých 60 s
        try:
            if progress is not None and progress.iscanceled():
                reason = "cancelled"
                break
        except Exception:
            pass

        # d) Kodi se vypíná (5s kill okno) — nikdy time.sleep v čekací smyčce
        if mon.waitForAbort(0.15):
            reason = "abort"
            break

    try:
        _log_event("MI2_WAIT_END", f"reason={reason}", f"waited_s={round(time.time() - t0, 2)}")
    except Exception:
        pass
    # Φ0: čekání na MediaInfo do user_logs (dřív jen lokální per-search log) — audit A06 F01:
    # strop 12 s vyčerpaly 3 ze 4 hledání filmu na PC a flotila to neviděla.
    _rm_bc.checkpoint("step", step="mi2_wait", ms=int((time.time() - t0) * 1000),
                      reason=reason, items=len(rels or []))
    if _stel_run is not None:
        _stel_run.mark("post")

    return reason


def _publish_top_marker(rels: List[Release]) -> None:
    """Φ5A (D3): zapíše, kolik řádků PRVNÍ OBRAZOVKY (v konečném pořadí výpisu) zůstalo při vykreslení
    nevyřízených. MI2 po doběhnutí výpis překreslí jen tehdy, když > 0 — jinak by jen přeskládal, co
    uživatel už vidí (`richmovie_listing.final_refresh_needed`). Jedno místo pro film i díl."""
    _SEARCH_LOG.flush()         # před vykreslením: pád Kodi při renderu nesmí vzít řádky hledání
    try:
        eng_mod = sys.modules.get("richmovie_engine")
        fn = getattr(eng_mod, "mi2_get_flags", None) if eng_mod else None
        flags = (lambda ident: (fn(ident) or {})) if callable(fn) else (lambda ident: {})
        done, total = _rm_listing.first_screen_settled(rels, flags)
        xbmcgui.Window(10000).setProperty(
            _rm_listing.PROP_TOP_UNSETTLED,
            _rm_listing.encode_top_marker(_rm_listing.current_listing_key(), total - done))
    except Exception as exc:
        _log(f"top marker failed: {exc!r}", xbmc.LOGDEBUG)
        flags = (lambda ident: {})
    _save_listing_snapshot(rels)


def _save_listing_snapshot(rels, sid: str = "", key: str = "") -> None:
    """Snímek výpisu V KONEČNÉM POŘADÍ (identy + původ) → `PLAY_PICK` pak zná pozici a původ streamu,
    který divák (nebo automatické přehrání) pustil. Vlastnost okna, ne URL (Kodi podle URL drží záložky a ✔).
    SSOT pro klasický výpis, nový vzhled i předstažený díl (`sid` + `key` zadá služba; jinak běžící hledání)."""
    try:
        run = _rm_stel.current()
        if not (sid and key):
            if run is None:
                return
            sid, key = run.sid, run.key
        if run is not None and run.sid == sid:
            run.mark("render")
            run.n_list = len(rels or [])
        _rm_stel.save_snapshot(_rm_stel.build_snapshot(
            sid, key, rels, mi2_known=lambda ident: bool(_mi2_flags_for(ident).get("video_h"))))
    except Exception as exc:
        _log(f"listing snapshot failed: {exc!r}", xbmc.LOGWARNING)


def _save_autoplay_snapshot(key_str: str, tv_id, season_no: int, ep_no: int, rels, pref, continuity) -> None:
    """Služba: pořadí kandidátů předstaženého dílu (stejný klíč jako výpis) → `PLAY_PICK` automatického
    přehrání nese vlnu a původ streamu (audit Fable F2-V3: jinak by chybějící údaj vypadal jako „nepuštěno“)."""
    info = LAST_EPISODE_SEARCH_INFO.get(key_str) or {}
    broken, blocked = _broken_sources(), _ws_playback_blocked()
    ordered = sorted(rels or [], key=lambda r: _listing_sort_key(r, pref, continuity, blocked, broken))
    _save_listing_snapshot(ordered, sid=str(info.get("sid") or "prefetch"),
                           key=_rm_epsearch.search_key(tv_id, season_no, ep_no))


@_rm_bc.timed_step("render", fields=lambda rels, *_a, **_kw: {"items": len(rels or [])})
def _list_releases(
    rels: List[Release],
    movie: Optional[dict] = None,
    *,
    category_title: Optional[str] = None,
) -> None:
    """
    22.12.2025 20:58 CET (Europe/Prague)
    (Φ0 29.09.2026: doba vykreslení do TRACE `step=render`.)

    Přehledný GUI-výpis nalezených releasů + `xbmcplugin.endOfDirectory()`.

    NOVĚ (parita FILMY/WS se seriály):
      • krátké MI2 "wait okno" (max 5 s) pro první dávku enrichmentu (kvalita + badge),
      • runtime sanity (stopáž streamu vs. TMDb stopáž filmu, tolerance ±10 %) → runtime_mismatch:
          – celý řádek je šedý (LabelFormatter.format),
          – a jde úplně na konec (finální sort key),
      • finální sort: mismatch-last → kvalita → match → velikost → score,
      • UX toasty: "Analyzuji zbytek…" + "Analýza dokončena." bez spamu (vázáno na konkrétní film / kontext listingu).

    DŮLEŽITÉ (FILM parity + stabilita):
      • MI2 se může startovat v engine i tady; tady je best-effort "kick" hlavně pro cache-hit/film flow,
        ale NESMÍ se spustit znovu při Container.Refresh (jinak blikání a více MI2 threadů).
      • FIX: MI2 kick NESMÍ být vázaný na probe_enabled (to je jiná věc – "detailní probe" v SearchEngine).
      • FIX: Detekce "MI2 běží" musí fungovat i napříč Kodi invokery → používáme Window(10000) running marker + ping.
      • FIX: MI2 refresh musí vynutit reálný přepis listingu i když refresh_key nesedí 1:1 (kanonizace/encoding).
    """
    win = xbmcgui.Window(10000)

    # Breadcrumb (2026-07-01): render výsledků je podezřelé místo NATIVNÍCH pádů
    # Kodi (OOM na slabých Android boxech). Checkpoint sem rozdělí „fáze hledání"
    # od „fáze render" — když sentinel uvízne na této fázi, víme, že spadl render.
    try:
        import richmovie_breadcrumb as _bc_lr
        _bc_lr.checkpoint("list_releases_begin",
                          count=len(rels or []), ui=("new" if _rm_new_ui() else "classic"))
    except Exception:
        pass

    # Legacy render (classic seznam releasů) platí pro rm_classic_ui I pro účet
    # bez custom UI povolení (rodina). MUSÍ být _rm_new_ui() SSOT — jinak by
    # rodina (custom_ui=false) šla picker-first cestou a viděla custom
    # Stream-picker z legacy menu (regrese R4).
    _classic_ui = not _rm_new_ui()

    import richmovie_ui_common as _rm_uc

    # Token páruje klik → search → picker (race ochrana: rychlé „film A → zpět →
    # film B"). Click-site (Detail/Episodes) ho vygeneruje (streams_new_token)
    # a předá v URL (rm_token) — čte se ze sys.argv[2] = scoped per-invoker.
    # Legacy toky bez tokenu → "" → fallback otevření pickeru níže funguje dál.
    try:
        _rv_token = urllib.parse.parse_qs(
            sys.argv[2][1:] if len(sys.argv) > 2 else "").get("rm_token", [""])[0]
    except Exception:
        _rv_token = ""

    if not _classic_ui:
        # New-UI režim nemá Container.Refresh konzumenta MI2 markerů — visící
        # marker z MINULÉHO hledání by níže potlačil MI2 kick (is_mi2_refresh_any).
        try:
            win.clearProperty("richmovie.mi2.refresh_reason")
            win.clearProperty("richmovie.mi2.refresh_key")
            win.clearProperty("richmovie.rm_streams_open")  # legacy guard hygiena
        except Exception:
            pass

    # ── RM 4.0 SSOT: payload builder + atomický persist release_view.json ────
    # Jediné místo, kde se staví data pro custom Stream-picker (initial persist,
    # empty stav i MI2 drainer). mi2_lookup (volitelné) merguje MI2 flags →
    # picker dostává kvalitu/dabing/titulky živě.
    # 3.5.129: Free účet → Webshare položky se v pickeru označí a řadí za Fastshare.
    # Jedno čtení stavu per výpis (payload se staví opakovaně při MI2 refreshi).
    _rv_ws_blocked = _ws_playback_blocked()

    def _rv_release_dict(r, mi2_lookup=None):
        d = {
            "ident": r.ident, "name": r.name, "quality": r.quality,
            "audios": list(r.audios or []), "subs": list(r.subs or []),
            "size": r.size, "size_mb": r.size_mb, "match": bool(r.match),
            "source": getattr(r, "source", "webshare"),
            "ws_blocked": bool(_rv_ws_blocked
                               and (getattr(r, "source", "webshare") or "webshare") == "webshare"),
            "fs_url": getattr(r, "fs_download_url", None) or "",
            "fs_hash": getattr(r, "fs_hash", None) or "",
            "runtime_mismatch": bool(getattr(r, "runtime_mismatch", False)),
            "runtime_confirmed": bool(getattr(r, "runtime_confirmed", False)),
            "est_min": r.est_min, "score": r.score,
            # P2 #11 (2026-07-07): relevance vůči termínu ručního WS hledání
            # (0 = neutrální; nastavuje jen _ws_search). Ostatní flow default 0
            # → řadicí klíč beze změny (viz _rv_final_sort).
            "ws_rel": int(getattr(r, "ws_rel", 0) or 0),
            # Φ-D (30.09.2026): pole pro SSOT řazení (`richmovie_quality.stream_sort_key`) — dřív nový vzhled
            # penalizaci názvu ani rozměry z Webshare neznal a řadil jinak než klasický výpis
            "title_penalty": int(getattr(r, "title_penalty", 0) or 0),
            "ws_width": getattr(r, "ws_width", None), "ws_height": getattr(r, "ws_height", None),
            "ws_len_s": getattr(r, "ws_len_s", None),
        }
        _q_res, _q_src = _rm_quality.resolve(None, d["ws_width"], d["ws_height"], "")
        if _q_res:
            d["quality"] = "%dP" % _q_res
        if mi2_lookup is None:
            return d
        try:
            fl = mi2_lookup(r.ident) or {}
        except Exception:
            fl = {}
        if not fl or fl.get("fail"):
            return d
        if fl.get("aud"):
            d["audios"] = list(fl.get("aud") or [])
        if fl.get("sub"):
            d["subs"] = list(fl.get("sub") or [])
        # štítek = třída, podle které se řadí (šířka i výška obrazu; MediaInfo má přednost)
        _q_res, _q_src = _rm_quality.resolve(fl, d["ws_width"], d["ws_height"], "")
        if _q_res:
            d["quality"] = "%dP" % _q_res
        return d

    def _rv_build_payload(status, mi2_lookup=None, mi2_running=False, resort=False):
        _m = movie or {}
        return {
            "movie": {
                "title": _m.get("title") or _m.get("name") or category_title or "",
                "poster_path": _m.get("poster_path") or "",
                "backdrop_path": _m.get("backdrop_path") or "",
                "tmdb_id": _m.get("id") or _m.get("tmdb_id") or "",
                "year": _m.get("year") or (_m.get("release_date") or "")[:4] or "",
                # TV (epizoda) kontext — picker ho přepošle do action=play, aby
                # přehrání epizody dostalo tv_id/season/episode (→ ✔ markery,
                # watch_events telemetrie kind="tv", správné Continue Watching).
                # U filmů zůstávají prázdné → play handler jde movie větví.
                "kind": _m.get("kind") or "movie",
                "tv_id": _m.get("tv_id") or "",
                "tv_name": _m.get("tv_name") or "",
                "season": _m.get("season") if _m.get("season") not in (None, "") else "",
                "episode": _m.get("episode") if _m.get("episode") not in (None, "") else "",
                "ep_title": _m.get("ep_title") or "",
                "ep_overview": _m.get("ep_overview") or "",
                "ep_still": _m.get("ep_still") or "",
            },
            "releases": [_rv_release_dict(r, mi2_lookup) for r in (rels or [])],
            "token": _rv_token,
            "ts": time.time(),
            "status": status,
            "mi2_running": bool(mi2_running),
            "resort": bool(resort),
        }

    def _rv_persist(payload):
        try:
            _rv_path = os.path.join(PROFILE_DIR, "release_view.json")
            return richmovie_atomic.write_json(_rv_path, payload)
        except Exception as _rv_e:
            _log(f"[Streams] persist release_view: {_rv_e}", xbmc.LOGDEBUG)
            return False

    # S31: Webshare v tomto hledání selhal, ale výsledky (Fastshare) jsou → jedna pravdivá věta, nejvýš jednou
    if rels:
        _src_down_notice(with_results=True)

    # – 1) ochrana – prázdný seznam ------------------------------------
    if not rels:
        _sd_text = ""
        if not _classic_ui:
            # Picker (pokud čeká) zobrazí branded empty stav místo Kodi modalu.
            # Token = picker-first klik → picker empty payload zkonzumuje poll
            # loopem i kdyby ping ještě nebyl čerstvý (start race) — modal by
            # byl duplicitní UX.
            # S31: výpadek Webshare = výběr streamu řekne pravdu v prázdném stavu (audit Fable S-6)
            _sd_text = _src_down_text(with_results=False)
            _rv_empty = _rv_build_payload(status="empty")
            if _sd_text:
                _rv_empty["empty_msg"] = _sd_text
            _rv_persist(_rv_empty)
            if _rv_token or _rm_uc.streams_picker_alive():
                return
        _no_release_ui(_sd_text)
        # Kodi musí dostat odpověď o osudu adresáře. Holý `return` nechává
        # kontrakt handle nedořešený — a právě na kontraktu handle stál celý
        # incident 19.09.2026 (cross-check Flash B2).
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        except Exception:
            pass
        return

    # RM 4.0 (ADDITIVNÍ, best-effort): initial persist pro custom Stream-picker.
    # NEMĚNÍ render ani řazení. MI2 merge doplní new-UI drainer (běží po kicku).
    _rv_persist(_rv_build_payload(status="ready", mi2_running=False))

    # (RM 4.0 CUTOVER blok se přesunul AŽ ZA MI2 kick — viz „CUTOVER + MI2
    def _mi2_flags(ident: str) -> Dict[str, Any]:
        """
        Jedno místo pro čtení MI2 cache (sekundy + rozměry + audio/sub).
        Best-effort: pokud cache není, vrací {}.
        """
        try:
            eng_mod = sys.modules.get("richmovie_engine")
            if not eng_mod:
                return {}
            fn = getattr(eng_mod, "mi2_get_flags", None)
            if callable(fn):
                return fn(ident) or {}
        except Exception:
            pass
        return {}

    def _mi2_is_running_here() -> bool:
        """
        True, pokud MI2 právě běží pro TENTO listing (klíč = URL invokace).

        DŮLEŽITÉ:
          • Kodi umí po Container.Refresh spustit plugin v jiném invokeru/sub-interpretu.
            V takovém případě nevidíme běžící thread přes MI2._RUNNING_THR.
          • Proto kontrolujeme i globální marker ve Window(10000) (nastavuje richmovie_mi2.py).
        """
        # 0) klíč TOHOTO listingu — musí sedět s MI2 `running_key`, který od 3.5.153
        #    nese klíč listingu (URL invokace), NE `Container.FolderPath`.
        #    Cross-check Flash 19.09.2026 (A3): tohle místo zůstalo na staré cestě,
        #    takže po opravě klíče by se `rk == cur_key` NIKDY neshodlo.
        cur_key = _rm_listing.current_listing_key()

        # 1) globální marker (funguje i napříč invokery)
        try:
            rk = (win.getProperty("richmovie.mi2.running_key") or "").strip()
            running = (win.getProperty("richmovie.mi2.running") or "").strip()
            ping_s = (win.getProperty("richmovie.mi2.running_ping") or "").strip()

            if running in ("1", "true", "True", "yes", "on") and rk and cur_key and (rk == cur_key):
                try:
                    last_ping = float(ping_s) if ping_s else 0.0
                    # TTL: když je ping čerstvý, MI2 považujeme za běžící
                    if last_ping > 0.0 and (time.time() - last_ping) < 120.0:
                        return True
                except Exception:
                    # nemáme ping → radši True (best-effort), než zbytečně startovat další MI2
                    return True
        except Exception:
            pass

        # 2) fallback: lokální thread kontrola (pokud jsme ve stejném python kontextu)
        try:
            mi2_mod = sys.modules.get("richmovie_mi2")
            MI2 = getattr(mi2_mod, "MediaInfoSecondEdition", None) if mi2_mod else None
            if not MI2:
                return False

            thr = getattr(MI2, "_RUNNING_THR", None)
            if not thr or not getattr(thr, "is_alive", lambda: False)():
                return False

            run_key = getattr(MI2, "_RUNNING_KEY", None)
            if run_key and cur_key and (str(run_key) != str(cur_key)):
                return False

            return True
        except Exception:
            return False

    # `_quality_rank` ODSTRANĚNA (Φ-D, 30.09.2026): kvalita i řazení = SSOT `richmovie_quality`.

    # ------------------------------------------------------------------
    # Titulek listingu (kategorie) + klíč pro MI2 toasty
    # ------------------------------------------------------------------
    try:
        if category_title:
            cat = str(category_title)
        else:
            if movie:
                t = (movie.get("title") or movie.get("original_title") or "").strip()
                y = int(movie.get("year") or int((movie.get("release_date") or "0000")[:4] or 0) or 0)
                if t and y:
                    cat = f"{t} ({y})"
                elif t:
                    cat = t
                else:
                    cat = "Nalezené streamy"
            else:
                cat = "Nalezené streamy"
    except Exception:
        cat = "Nalezené streamy"

    key_str = ""
    try:
        if movie and movie.get("id"):
            key_str = f"movie:{int(movie.get('id') or 0)}"
    except Exception:
        key_str = ""

    if not key_str:
        # Klíč listingu, ne odchozí kontejner — jinak by se toast „Analyzuji…"
        # vázal na obrazovku, ze které se odešlo (cross-check Flash A4).
        key_str = "path:" + _rm_listing.current_listing_key()

    # Klíč TOHOTO listingu = URL, kterou nás Kodi zavolalo (`sys.argv`).
    # NIKDY `Container.FolderPath` — ta je tady pořád cesta, ze které odcházíme
    # (incident Sony 19.09.2026: MI2 klíč ukazoval na `?action=show_recommendations`
    # v okamžiku, kdy se vypisovalo 127 streamů Terminátora 2).
    cur_key = _rm_listing.current_listing_key()

    # ------------------------------------------------------------------
    # 0) Kontext listingu: MI2 refresh marker + vynulování "listing.ready"
    # ------------------------------------------------------------------
    rr = ""
    rk = ""
    try:
        rr = (win.getProperty("richmovie.mi2.refresh_reason") or "").strip().lower()
        rk = (win.getProperty("richmovie.mi2.refresh_key") or "").strip()
    except Exception:
        rr = ""
        rk = ""

    # Stav MI2 vlákna (čte volající, rozhoduje čistá brána)
    _mi2_thr_alive = False
    try:
        _mi2_mod_chk = sys.modules.get("richmovie_mi2")
        if _mi2_mod_chk:
            _mi2_cls_chk = getattr(_mi2_mod_chk, "MediaInfoSecondEdition", None)
            if _mi2_cls_chk:
                _mi2_thr = getattr(_mi2_cls_chk, "_RUNNING_THR", None)
                _mi2_thr_alive = bool(_mi2_thr and getattr(_mi2_thr, "is_alive", lambda: False)())
    except Exception:
        pass

    # SSOT rozhodnutí (testovatelné bez Kodi — harness scénář 64)
    _plan = _rm_listing.plan_listing(
        cur_key=cur_key,
        marker_reason=rr,
        marker_key=rk,
        has_releases=bool(rels),
        mi2_running_here=_mi2_is_running_here(),
        mi2_thread_alive=_mi2_thr_alive,
    )

    is_mi2_refresh_any = _plan.is_refresh_any
    is_mi2_refresh_call = _plan.is_refresh_call
    is_final_refresh_any = bool(rr in ("final", "deferred") and rk)

    if _plan.mismatch:
        # Po opravě klíče (3.5.153) by tohle nemělo nastat. Když nastane, je to
        # regrese identity listingu — harness i runtime smoke to hlídají.
        try:
            _log_event("MI2_REFRESH_KEY_MISMATCH", {"rr": rr or None, "rk": rk or None, "cur_key": cur_key or None})
        except Exception:
            pass

    # VŽDY před renderem: listing ještě není hotový → MI2 nesmí refreshnout moc brzo
    try:
        win.setProperty("richmovie.listing.ready", "0")
        win.setProperty("richmovie.mi2.listing_ready", "0")  # legacy kompatibilita
    except Exception:
        pass

    # ------------------------------------------------------------------
    # 1) MI2 kick (FILM/WS parity): cache-hit film flow potřebuje MI2 start.
    #    DŮLEŽITÉ: při MI2 refreshi (marker existuje) to NESMÍME spustit znovu.
    #    FIX 21.02.2026: Pokud MI2 thread UŽ běží (startovaný engine search_wave),
    #    NESMÍME ho startovat znovu – jinak duplicitní probe + race condition.
    # ------------------------------------------------------------------
    # Pozn.: hlavní cesta (hledání) startuje MI2 už ve fázi hledání přes
    # `_mi2_prepare()`, kde je otevřený průběhový dialog. Tenhle kick pokrývá
    # vstupy do listingu bez fáze hledání (reentry, cache-hit, lokální katalog).
    try:
        if _plan.kick_mi2:
            # Cross-check Pro Q3: `cap_s=0.0` by znamenalo, že cesty BEZ fáze hledání
            # (cache-hit, reentry, lokální katalog) ukážou surový seznam bez kvality
            # a dabingu — přesně to, co měl zákaz z Beta.7 vyloučit. Čeká se tedy
            # i tady, ale BEZ vlastního modálního dialogu: Kodi po dobu stavby
            # adresáře drží vlastní busy indikátor. Druhý modál uvnitř `GetDirectory`
            # byl root cause incidentu 19.09.2026 a ten se nevrací.
            _mi2_prepare(rels, cur_key, progress=None, cap_s=_rm_listing.MI2_WAIT_NODIALOG_CAP_S)
        elif rels and (not is_mi2_refresh_any) and _mi2_thr_alive:
            try:
                _log_event("MI2_SKIP_ALREADY_RUNNING", "ctx=list_releases")
            except Exception:
                pass
    except Exception as _mi2_kick_err:
        try:
            _log_event("MI2_KICK_FAIL", str(_mi2_kick_err))
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════════════
    # RM 4.0 CUTOVER + MI2 DRAINER (new-UI režim) — Φ-R2 (2026-06-12)
    # Žádný Kodi seznam: picker čte release_view.json. Tenhle invoker po MI2
    # kicku zůstane žít jako drainer — merguje MI2 flags do JSON, picker je
    # konzumuje poll loopem (live badge + finální re-sort). Classic režim
    # pokračuje starým renderem níže.
    # ══════════════════════════════════════════════════════════════════════
    if not _classic_ui:
        try:
            # Fallback otevření pickeru: jen když neběží A pro tento token ještě
            # žádný nebyl (uživatel, který picker sám zavřel, ho nedostane znovu).
            if not _rm_uc.streams_picker_alive() \
                    and not _rm_uc.streams_token_seen(_rv_token):
                xbmc.executebuiltin(
                    f"RunPlugin({_url(action='rm_streams', rm_token=_rv_token)})")
        except Exception:
            pass
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass

        def _rv_mi2_alive():
            try:
                _mod = sys.modules.get("richmovie_mi2")
                _cls = getattr(_mod, "MediaInfoSecondEdition", None) if _mod else None
                _thr = getattr(_cls, "_RUNNING_THR", None) if _cls else None
                if _thr is not None and _thr.is_alive():
                    return True
            except Exception:
                pass
            try:
                if (win.getProperty("richmovie.mi2.running") or "").strip() == "1":
                    _ping = (win.getProperty("richmovie.mi2.running_ping") or "").strip()
                    if _ping and (time.time() - float(_ping)) < 30.0:
                        return True
            except Exception:
                pass
            return False

        def _rv_missing_count():
            # Jen prvních 32 — MI2.start() dávku stejně capuje na max_items=32,
            # počítat zbytek by vedlo k marným rekickům.
            n = 0
            for _r in rels[:32]:
                try:
                    if not (_mi2_flags(getattr(_r, "ident", "")) or {}):
                        n += 1
                except Exception:
                    pass
            return n

        def _rv_mi2_rekick():
            # MI2.start() odmítá novou dávku, dokud žije CIZÍ (jiný klíč) —
            # po jejím doběhnutí spustíme dávku pro tento search dodatečně.
            try:
                _mod = sys.modules.get("richmovie_mi2") or importlib.import_module("richmovie_mi2")
                _cls = getattr(_mod, "MediaInfoSecondEdition", None)
                if not _cls:
                    return False
                _cf = getattr(_ENGINE, "_get_client", None)
                if not callable(_cf):
                    _cf = (lambda: _SESSION.client)
                _cls.start(releases=rels[:32], client_factory=_cf,
                           fs_client_factory=_get_fastshare_client,
                           first_batch=8, max_items=32, refresh=False,
                           key=cur_key)
                _log_event("MI2_START", "ctx=rv_drainer", f"count={min(len(rels), 32)}")
                return True
            except Exception as _rk_e:
                try:
                    _log_event("MI2_REKICK_FAIL", str(_rk_e))
                except Exception:
                    pass
                return False

        def _rv_final_sort(payload):
            # Φ-D (30.09.2026): TOTÉŽ řazení jako klasický výpis a automatický výběr — SSOT
            # `_release_sort_key` → `richmovie_quality.stream_sort_key` (pořadí polí `SORT_KEY_FIELDS`).
            # Φ4 (2026-07-06, audit A03): per-title pref (observed/manuální)
            # dabingu/titulků řadí PŘED vším ostatním — kontinuita „další díl
            # hraje stejnou stopou". JEN řazení, NIKDY filtr (filter parity
            # SSOT, feedback_addon_release_filter_is_ssot). „Auto nejlepší"
            # v pickeru bere pořadí payloadu → pref-aware automaticky.
            _pm = payload.get("movie") or {}
            _pref = None
            try:
                _pref = _lookup_title_pref(
                    tv_id=(_pm.get("tv_id") or None),
                    m_tmdb=(int(_pm.get("tmdb_id") or 0) or None),
                    m_title=(_pm.get("title") or None),
                    m_year=(int(_pm.get("year") or 0) or None))
            except Exception:
                _pref = None
            # 3.5.151 kontinuita verze (díl) — stejně jako klasický výpis a automatický výběr
            _cont = None
            try:
                if _pm.get("tv_id"):
                    import richmovie_continuity as _rv_cont_mod
                    _cont = _rv_cont_mod.context_for_title("tv:%s" % _pm.get("tv_id"))
            except Exception:
                _cont = None
            try:
                # Φ-D/Φ-E (30.09.2026): SSOT klíč; vadný soubor (3.5.158) a nepřehratelné (Free účet,
                # 3.5.129) až za vším — stejně jako klasický výpis a automatický výběr
                _rv_broken = _broken_sources()
                payload["releases"].sort(key=lambda d: _listing_sort_key(d, _pref, _cont, False, _rv_broken))
            except Exception as _rs_exc:
                _log(f"[Streams] final sort failed: {_rs_exc!r}", xbmc.LOGWARNING)
                _log_event("FINAL_SORT_ERR", "ctx=new_ui", repr(_rs_exc)[:200])
            return payload

        try:
            _drain_mon = xbmc.Monitor()
            _drain_t0 = time.time()
            _last_snap = ""
            _rekicked = False
            import json as _snap_json
            while not _drain_mon.abortRequested() and (time.time() - _drain_t0) < 90.0:
                if _drain_mon.waitForAbort(2.0):
                    break
                # picker mrtvý → nikdo se nedívá; MI2 si dojede do cache sám
                if (time.time() - _drain_t0) > 15.0 \
                        and not _rm_uc.streams_picker_alive(ttl_s=12.0):
                    break
                _alive = _rv_mi2_alive()
                if (not _alive) and (not _rekicked) and _rv_missing_count() > 0 \
                        and (time.time() - _drain_t0) < 75.0:
                    _rekicked = True
                    if _rv_mi2_rekick():
                        continue
                # Φ-E (30.09.2026, cross-check Flash F11): nový vzhled se vrací PŘED kontrolou délky
                # klasického výpisu → „nesedí délka“ tu nikdy nebylo a takový stream mohl být první
                _apply_runtime_sanity(rels, _runtime_refs(movie), (movie or {}).get("kind") or "movie",
                                      log=(not _alive))
                _SEARCH_LOG.flush()     # sběrač čeká až 90 s bez logování — dávka nesmí ležet v paměti
                _pl = _rv_build_payload(status="ready", mi2_lookup=_mi2_flags,
                                        mi2_running=_alive, resort=(not _alive))
                if not _alive:
                    _rv_final_sort(_pl)
                    # snímek v pořadí, které divák v novém vzhledu vidí (audit Fable F2-V3)
                    _rv_by_ident = {getattr(r, "ident", ""): r for r in (rels or [])}
                    _save_listing_snapshot([_rv_by_ident[d.get("ident")] for d in _pl["releases"]
                                            if d.get("ident") in _rv_by_ident])
                try:
                    _snap = _snap_json.dumps(_pl["releases"], sort_keys=True)
                except Exception:
                    _snap = ""
                if (_snap != _last_snap) or (not _alive):
                    _rv_persist(_pl)
                    _last_snap = _snap
                if not _alive:
                    break
        except Exception as _drain_e:
            _log(f"[Streams] mi2 drainer: {_drain_e}", xbmc.LOGWARNING)
        finally:
            # New-UI režim nemá Container.Refresh konzumenta MI2 markerů —
            # visící marker by potlačil MI2 kick příštího hledání.
            try:
                win.clearProperty("richmovie.mi2.refresh_reason")
                win.clearProperty("richmovie.mi2.refresh_key")
            except Exception:
                pass
        return

    # ------------------------------------------------------------------
    # 2) MI2 wait window + "Analyzuji…" toast (jen pro první render)
    # ------------------------------------------------------------------
    toast_analyze_now = False
    try:
        analyze_for = (win.getProperty("richmovie.mi2.toast.analyze_for") or "").strip()
        done_for = (win.getProperty("richmovie.mi2.toast.done_for") or "").strip()
    except Exception:
        analyze_for = ""
        done_for = ""

    if rels and (not is_mi2_refresh_any) and (not is_final_refresh_any) and _mi2_is_running_here():
        # 3.5.153: TADY SE UŽ NEČEKÁ.
        # Beta.7 (25.04.2026) chtěla počkat na MI2, ať se neukazují raw výsledky
        # bez kvality/audio/subs — ten záměr platí dál, ale čekání se přesunulo
        # do fáze hledání (`_mi2_prepare`), kde je průběhový dialog už otevřený.
        # Tady si kvůli němu plugin otevíral DRUHÝ modální DialogProgress uvnitř
        # stavby adresáře, až na 60 s, bez čtení `iscanceled()`. Na Sony BRAVIA
        # z toho bylo 36 s od kliku k seznamu (19.09.2026); na Chromecastu se
        # čekání nespustilo vůbec, proto tam seznam naskočil za 1 s.
        try:
            if _mi2_is_running_here():
                if done_for != key_str and analyze_for != key_str:
                    win.setProperty("richmovie.mi2.toast.analyze_for", key_str)

                    if (win.getProperty("richmovie.mi2.toast.done_for") or "").strip() == key_str:
                        win.clearProperty("richmovie.mi2.toast.done_for")

                    toast_analyze_now = True
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 3) Runtime sanity (FILM): stream duration vs. TMDb runtime (±10 %)
    # ------------------------------------------------------------------
    _apply_runtime_sanity(rels, _runtime_refs(movie), (movie or {}).get("kind") or "movie")

    # ------------------------------------------------------------------
    # 4) Finální seřazení (vždy)
    # ------------------------------------------------------------------
    if rels:
        try:
            try:
                ws_h = sum(1 for r in rels if getattr(r, "ws_height", None))
            except Exception:
                ws_h = 0

            try:
                mi2_h = 0
                for r in rels:
                    fl = _mi2_flags(getattr(r, "ident", ""))
                    vh = fl.get("video_h", None)
                    if isinstance(vh, (int, float)) and int(vh) > 0:
                        mi2_h += 1

                _log_event(
                    "FINAL_SORT_PRE",
                    {
                        "ctx": "movie",
                        "count": len(rels),
                        "ws_h": ws_h,
                        "mi2_h": mi2_h,
                    },
                )
            except Exception:
                pass

            # Φ-D (30.09.2026): SSOT klíč (`_release_sort_key`) — stejný jako výpis dílu, nový vzhled i
            # automatický výběr. Film tak nově zná preferenci diváka, český dabing (D1) a balast.
            _mv = movie or {}
            try:
                _mv_pref = _lookup_title_pref(
                    m_tmdb=(int(_mv.get("id") or _mv.get("tmdb_id") or 0) or None),
                    m_title=(_mv.get("title") or None),
                    m_year=(int(_mv.get("year") or 0) or None))
            except Exception:
                _mv_pref = None
            rels.sort(key=lambda r: _release_sort_key(r, _mv_pref, None))

        except Exception as _e:
            try:
                _log_event("FINAL_SORT_ERR", str(_e))
            except Exception:
                pass

    # – 5) základní GUI setup -------------------------------------------
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.setPluginCategory(HANDLE, cat)

    # Phase: FINAL STREAM ORDER LOG (2026-04-19) — kompaktní jednořádkový
    # 3.5.129 (incident PeterFM): Free účet → Webshare položky za Fastshare (jen
    # pořadí, nikdy filtr). PŘED logem STREAM_ORDER_FINAL, aby log ukazoval
    # pořadí, které uživatel skutečně vidí. Jedna pravda per výpis: stejná
    # hodnota jako pro payload pickeru (`_rv_ws_blocked`; Fable audit F-11).
    _ws_blk = _rv_ws_blocked
    rels = _order_ws_blocked_last(rels, _ws_blk)
    rels = _order_dv_unplayable_last(rels)   # noc 03.11.2026 (Φ3): DV bez kompatibilní vrstvy za hratelné
    _broken = _broken_sources()
    rels = _order_broken_last(rels, _broken)
    _publish_top_marker(rels)   # Φ5A (D3): závěrečný refresh MI2 jen při neúplné první obrazovce

    # záznam per-release v přesném pořadí, v jakém se zobrazí v GUI.
    # Fires KAŽDÉ volání _list_releases (tedy i po Container.Refresh,
    # kdy jsou MI2 hints naplněny). Slouží pro ladění řazení.
    try:
        _refresh_tag = "refresh" if (is_mi2_refresh_any or is_final_refresh_any) else "initial"
        _title_for_log = ""
        try:
            if movie:
                _title_for_log = str(movie.get("title") or movie.get("name") or "")
            elif category_title:
                _title_for_log = str(category_title)
        except Exception:
            _title_for_log = ""
        _log_event(
            "LIST_FINAL_BEGIN",
            f"count={len(rels)}",
            f"stage={_refresh_tag}",
            f"title={_title_for_log[:80]}",
        )
        for _fidx, _fr in enumerate(rels, 1):
            try:
                _mi_fl = {}
                try:
                    _eng_mod = sys.modules.get("richmovie_engine")
                    if _eng_mod and callable(getattr(_eng_mod, "mi2_get_flags", None)):
                        _mi_fl = _eng_mod.mi2_get_flags(
                            getattr(_fr, "ident", "")
                        ) or {}
                except Exception:
                    _mi_fl = {}
                _fsize_b = int(getattr(_fr, "size", 0) or 0)
                _fsize_mb = round(_fsize_b / 1_048_576) if _fsize_b else 0
                try:
                    from richmovie_engine import QUALITY_RANK as _QR
                    _fq_rank = _QR.get(getattr(_fr, "quality", ""), 99)
                except Exception:
                    _fq_rank = None
                _faud = ",".join(getattr(_fr, "audios", []) or []) or "-"
                _fsub = ",".join(getattr(_fr, "subs", []) or []) or "-"
                _mi_aud = ",".join(_mi_fl.get("aud") or []) or "-"
                _mi_sub = ",".join(_mi_fl.get("sub") or []) or "-"
                _log_event(
                    "STREAM_ORDER_FINAL",
                    f"#{_fidx:02d}",
                    f"src={getattr(_fr, 'source', '') or '-'}",
                    f"q={getattr(_fr, 'quality', '') or '-'}",
                    f"qrank={_fq_rank}",
                    f"size={_fsize_mb}MB",
                    f"match={'Y' if getattr(_fr, 'match', False) else 'N'}",
                    f"mismatch={'Y' if getattr(_fr, 'runtime_mismatch', False) else 'N'}",
                    f"pen={int(getattr(_fr, 'title_penalty', 0) or 0)}",
                    f"score={_score_text(getattr(_fr, 'score', None))}",
                    f"heur_aud={_faud}",
                    f"heur_sub={_fsub}",
                    f"mi2_h={_mi_fl.get('video_h') or '-'}",
                    f"mi2_dur={_mi_fl.get('duration_s') or '-'}",
                    f"mi2_aud={_mi_aud}",
                    f"mi2_sub={_mi_sub}",
                    f"mi2_cz_dub={_mi_fl.get('cz_dub') if _mi_fl.get('cz_dub') is not None else '-'}",
                    f"ws_h={getattr(_fr, 'ws_height', None) or '-'}",
                    f"ident={getattr(_fr, 'ident', '')}",
                    f"name={(getattr(_fr, 'name', '') or '')[:80]}",
                )
            except Exception:
                pass
        _log_event("LIST_FINAL_END", f"count={len(rels)}", f"stage={_refresh_tag}")
    except Exception:
        pass

    # – 6) položky ------------------------------------------------------
    # Beta.7 (2026-04-25): tabular column alignment.
    # Spočítáme max šířku quality + size napříč rels, předáme do
    # _build_stream_li → LabelFormatter padding U+2007 (digit-width space)
    # → kvalita a velikost se zobrazí pod sebou.
    # `has_fs` rozhoduje o WS/FS prefixu: pokud user má FS k dispozici (mix
    # sources), prefix u všech releasů; jinak žádný prefix.
    _has_fs = any(getattr(r, "source", "webshare") == "fastshare" for r in rels)
    _max_qual_w, _max_size_w = _column_widths(rels)

    for r in rels:
        xbmcplugin.addDirectoryItem(
            HANDLE,
            *_build_stream_li(
                r, movie,
                show_source_prefix=_has_fs,
                quality_pad_width=_max_qual_w,
                size_pad_width=_max_size_w,
                ws_blocked=_ws_blk,
                broken=_broken,
            ),
        )

    # – 7) endOfDirectory NEJDŘÍVE, listing.ready AŽ POTOM ---------------
    # FIX 21.02.2026: Dříve bylo listing.ready=1 PŘED endOfDirectory.
    # To způsobovalo race condition: MI2 thread viděl ready=1 a poslal
    # Container.Refresh ještě předtím, než Kodi věděl o hotovém listingu.
    # Na Chromecastu/Android to vedlo ke crashi.
    # Navíc: xbmc.sleep(120) nahrazeno za mon.waitForAbort(0.12) – abort-safe.
    try:
        xbmcplugin.endOfDirectory(
            HANDLE,
            succeeded=True,
            # 3.5.153: `is_refresh_call`, ne `_any`. Marker patřící CIZÍMU
            # kontejneru nesmí z čerstvé navigace udělat in-place update —
            # přesně to dělal rozbitý klíč (viz richmovie_listing).
            updateListing=bool(_plan.update_listing),
            cacheToDisc=False,
        )
    except TypeError:
        xbmcplugin.endOfDirectory(HANDLE)

    # Krátká pauza po endOfDirectory – abort-safe (reaguje na Kodi shutdown / Back)
    try:
        xbmc.Monitor().waitForAbort(0.12)
    except Exception:
        pass

    # Teď teprve signalizuj MI2, že listing je hotový a může refreshnout
    try:
        xbmcgui.Window(10000).setProperty("richmovie.listing.ready", "1")
        xbmcgui.Window(10000).setProperty("richmovie.mi2.listing_ready", "1")
    except Exception:
        pass

    # Stal se kontejner TÍMHLE listingem? Kodi to zpracuje krátce po
    # `endOfDirectory`, takže se na to pár sekund počká PŘÍMO TADY.
    #
    # Cross-check Pro Q5: dřív se otisk publikoval vždycky a vyhodnocoval ho až
    # dispatcher příští invokace — jenže mezitím mohl uživatel dát Zpět (Kodi se
    # vrátí z cache, plugin se nezavolá) a klik na jiný film pak hlásil ztrátu,
    # která se nestala. Otisk se proto publikuje JEN když se kontejner listingem
    # do `_LANDED_DEADLINE_S` nestal — tedy jen při skutečném podezření.
    _LANDED_DEADLINE_S = 2.0
    try:
        _landed = False
        _aborted = False
        _mon_land = xbmc.Monitor()
        _t_land = time.time()
        while (time.time() - _t_land) < _LANDED_DEADLINE_S:
            if _rm_listing.same_listing(xbmc.getInfoLabel("Container.FolderPath") or "", cur_key):
                _landed = True
                break
            if _mon_land.waitForAbort(0.2):
                # Kodi se vypíná — listing nedopadl, ale NENÍ to ztráta (audit Fable).
                _aborted = True
                break
        if not _landed and not _aborted:
            # Runtime smoke 19.09.2026 20:04: smyčka doběhla celá (2,1 s mezi
            # posledním addDirectoryItem a phase=end) → kontejner se listingem
            # nestal. Logujeme OBA klíče, aby příští reprodukce rozlišila
            # „Kodi adresář nepřevzalo" od „porovnávám špatně".
            try:
                _nl_ctx = {
                    "cur_key": cur_key,
                    "container": _rm_listing.canon_key(
                        xbmc.getInfoLabel("Container.FolderPath") or ""),
                    "items": len(rels or []),
                    "waited_s": round(time.time() - _t_land, 2),
                    "aborted": _aborted,
                }
                _log_event("LISTING_NOT_LANDED", _nl_ctx)
                # Φ0 (29.09.2026): i do user_logs — `_log_event` píše jen lokální soubor, takže
                # diagnostika 3.5.153 za 60 dní na NAS nedorazila ani jednou (audit A03 F9).
                _log(f"LISTING_NOT_LANDED items={_nl_ctx['items']} waited_s={_nl_ctx['waited_s']}",
                     xbmc.LOGWARNING, context=_nl_ctx)
            except Exception:
                pass
            xbmcgui.Window(10000).setProperty(
                "richmovie.listing.published",
                # Monotónní hodiny, ne kalendářní: Android boxy bez RTC přenastaví
                # čas po NTP skokem a otisk by se tvářil jako z budoucnosti nebo
                # dávno vypršelý (cross-check Flash E5; totéž řeší richmovie_guard._now).
                _rm_listing.encode_published(cur_key, len(rels or []), time.monotonic()),
            )
    except Exception:
        pass

    # ------------------------------------------------------------------
    # 8) MI2 UX toasty: "Analyzuji…" + "Analýza dokončena."
    # ------------------------------------------------------------------
    try:
        if toast_analyze_now:
            _rm_notif(
                "Analyzuji zbytek streamů, jestli nemají náhodou dabing a české titulky…",
                xbmcgui.NOTIFICATION_INFO,
                3000,
                "RichMovie",
            )
    except Exception:
        pass

    try:
        analyze_for = (win.getProperty("richmovie.mi2.toast.analyze_for") or "").strip()
        done_for = (win.getProperty("richmovie.mi2.toast.done_for") or "").strip()

        # marker smažeme (ať nezůstane viset mezi view) – BEST EFFORT i při key mismatch
        # Důvod: v praxi se může stát rk != cur_key (např. tv_episodes vs tv_play), a marker by jinak visel napříč view.
        try:
            rk2 = (win.getProperty("richmovie.mi2.refresh_key") or "").strip()
            rr2 = (win.getProperty("richmovie.mi2.refresh_reason") or "").strip().lower()

            # SSOT úklidu markeru (audit Fable P1 #5): dřív tu byl ručně psaný
            # žebříček podmínek VČETNĚ vlastní kopie `targets_match` — a totéž
            # o dvě obrazovky dál. Sémantika beze změny: marker se po renderu
            # vždycky uklidí, ať mířil kamkoli; jen se rozliší log.
            if _rm_listing.marker_present(rr2, rk2):
                _mine = bool(cur_key and (_rm_listing.canon_key(rk2) == _rm_listing.canon_key(cur_key)
                                          or _rm_listing.targets_match(rk2, cur_key)))
                try:
                    _log_event(
                        "MI2_REFRESH_MARKER_CLEAR_MATCH" if _mine else "MI2_REFRESH_MARKER_CLEAR_FORCED",
                        {"rr": rr2 or None, "rk": rk2 or None, "cur_key": cur_key or None},
                    )
                except Exception:
                    pass
                win.clearProperty("richmovie.mi2.refresh_reason")
                win.clearProperty("richmovie.mi2.refresh_key")
        except Exception:
            pass


        if analyze_for == key_str and done_for != key_str:
            # done ukážeme buď na MI2 finálním markeru (i když klíč nesedí), nebo když už MI2 neběží
            if is_final_refresh_any or (not _mi2_is_running_here()):
                win.setProperty("richmovie.mi2.toast.done_for", key_str)
                _rm_notif("Analýza dokončena.", xbmcgui.NOTIFICATION_INFO, 2500, "RichMovie")
    except Exception:
        pass











# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _auto_search_movie (upraveno: 14.12.2025 17:51 CET (Europe/Prague) – FILMY: doplnění det["rm_runtimes"] pro runtime sanity + best-effort enrich před listingem; zachování BAN klíčů + whitelist roků + FIX return)
# ---------------------------------------------------------------------------- #
WS_LIMIT_PROBE_QUERY = "Matrix 1999"      # dotaz s jistě > 100 výsledky (výchozí pro měření D4)
WS_LIMIT_PROBE_LIMIT = 200
WS_LIMIT_PROBE_PAGE = 100                 # velikost stránky dnešního hledání (`richmovie_webshare.PAGE_SIZE`)


def _ws_limit_probe(query: str = "") -> Dict[str, Any]:
    """D4 (Richie 29.09.2026): vrátí Webshare `limit=200` jedním požadavkem TOTÉŽ co dnešní dvě stránky po
    100? Jen měření — stránkování hledání se tím NEMĚNÍ. Výsledek jde do user_logs (`WS_LIMIT_PROBE`);
    o přechodu na jednu stránku se rozhodne až podle něj (shodná množina i pořadí = −49 % volání hledání)."""
    q = query or WS_LIMIT_PROBE_QUERY
    cli = _client()
    _ensure_login(cli, interactive=False)
    # 3 čtecí požadavky hledání: 1× limit 200 + dvě stránky po 100 ke srovnání. Posun druhé stránky je
    # PEVNÝ (klient ze stránky vyřazuje smazané soubory, takže plná stránka může vrátit 99 položek).
    big = cli.search(q, offset=0, limit=WS_LIMIT_PROBE_LIMIT)
    p1 = cli.search(q, offset=0)
    p2 = cli.search(q, offset=WS_LIMIT_PROBE_PAGE)
    a = [x.get("ident") for x in big]
    b = [x.get("ident") for x in (p1 + p2)]
    first_diff = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), -1)
    out = {
        "q": q, "limit": WS_LIMIT_PROBE_LIMIT, "n_big": len(a), "n_pages": len(b), "n_p1": len(p1), "n_p2": len(p2),
        "same_set": set(a) == set(b), "same_order": a == b, "first_diff": first_diff,
        "only_big": len(set(a) - set(b)), "only_pages": len(set(b) - set(a)),
    }
    _log("WS_LIMIT_PROBE %s" % json.dumps(out, ensure_ascii=False), xbmc.LOGINFO, context=out)
    return out


RUNTIME_SANITY_LOG_ROWS = 40      # strop jmenovitých řádků v logu kontroly délky (ident, minuty, zdroj)


def _runtime_refs(title: Optional[dict]) -> List[int]:
    """Referenční délky titulu v minutách (TMDb: `rm_runtimes` / `runtimes` / `runtime`), vzestupně."""
    out: List[int] = []
    try:
        if title:
            cand = title.get("rm_runtimes") or title.get("runtimes")
            if not isinstance(cand, (list, tuple)):
                cand = [title.get("runtime") or title.get("runtime_min") or 0]
            for x in cand:
                try:
                    xi = int(float(str(x).strip()))
                except (TypeError, ValueError):
                    continue
                if xi > 0:
                    out.append(xi)
    except Exception as exc:
        _log(f"runtime refs failed: {exc!r}", xbmc.LOGDEBUG)
        return []
    return sorted(set(out))


def _apply_runtime_sanity(rels, refs_min, kind: str = "movie", log: bool = True) -> int:
    """Označí streamy, kterým nesedí délka (`runtime_mismatch`); u dílu i potvrzenou délku
    (`runtime_confirmed`, `runtime_ref_available`). SSOT pro výpis filmu, výpis dílu i nový vzhled —
    pravidlo je `richmovie_quality.runtime_verdict` (D6: prodloužená verze a dvojdíl sedí).
    Jen příznaky pro pořadí a barvu řádku, nikdy filtr. Vrací počet nesedících."""
    refs = [int(x) for x in (refs_min or []) if x and int(x) > 0]
    if not rels or not refs:
        return 0
    is_tv = (kind == "tv")
    mismatch = 0
    used = {"ws": 0, "est": 0, "mi2": 0, "none": 0}
    rows: List[list] = []          # [ident, délka v min, zdroj údaje] streamů, kterým délka nesedí
    for r in rels:
        try:
            if is_tv:
                setattr(r, "runtime_ref_available", True)
            setattr(r, "runtime_confirmed", False)
            setattr(r, "runtime_mismatch", False)
            dur_s, src = _rm_quality.duration_s(r, _mi2_flags_for(getattr(r, "ident", "")))
            used[src] = used.get(src, 0) + 1
            verdict = _rm_quality.runtime_verdict(dur_s, refs, "tv" if is_tv else "movie")
            if verdict == _rm_quality.RUNTIME_MISMATCH:
                setattr(r, "runtime_mismatch", True)
                mismatch += 1
                if len(rows) < RUNTIME_SANITY_LOG_ROWS:
                    rows.append([str(getattr(r, "ident", "")), int(round(dur_s / 60.0)), src])
            elif verdict == _rm_quality.RUNTIME_OK:
                setattr(r, "runtime_confirmed", True)      # D9: rozhoduje mezi stejnou kvalitou a dabingem
        except Exception as exc:
            # best-effort: jeden vadný stream nesmí shodit výpis — ale je v logu
            _log_event("RUNTIME_SANITY_ERR", getattr(r, "ident", ""), repr(exc)[:200])
    if log:
        info = {"total": len(rels), "mismatch": mismatch, "used_ws": used["ws"], "used_est": used["est"],
                "used_mi2": used["mi2"]}
        if is_tv:
            info["ref_min"] = refs[0]
        else:
            info["ctx"] = "movie"
            info["ref_min_list"] = refs
        if rows:
            info["mismatch_rows"] = rows
        _log_event("RUNTIME_SANITY", info)
    return mismatch


def _column_widths(rels) -> Tuple[int, int]:
    """(šířka sloupce kvality, šířka sloupce velikosti) výpisu streamů. Kvalita = štítek, který se opravdu
    zobrazí (`LabelFormatter.quality_label`), ne popisek z názvu souboru."""
    qual, size = [0], [0]
    for r in rels or []:
        try:
            qual.append(len(LabelFormatter.quality_label(r, _mi2_flags_for(getattr(r, "ident", "")))))
            if getattr(r, "size", None):
                size.append(len(f"{r.size_mb:,}".replace(",", " ") + " MB"))
        except Exception as exc:
            _log(f"column width failed: {exc!r}", xbmc.LOGDEBUG)
    return max(qual), max(size)


def _mi2_flags_for(ident: str) -> Dict[str, Any]:
    """MediaInfo údaje streamu z cache (prázdný slovník = neznámé). Nikdy nevyhazuje."""
    try:
        eng_mod = sys.modules.get("richmovie_engine")
        fn = getattr(eng_mod, "mi2_get_flags", None) if eng_mod else None
        return (fn(ident) or {}) if callable(fn) else {}
    except Exception:
        return {}


def _play_pick(req_ident: str, ident: str, source: str, pick_key: str, release_name: str,
               autoplay: bool, resumed: bool) -> Dict[str, Any]:
    """Φ-A (E5-F01/F02/F04): co divák (nebo autoplay) pustil — pozice ve výpisu, původ (vlna, dotazy,
    stránka), třída kvality a cesta spuštění. Jeden řádek `PLAY_PICK` do user_logs; vrací údaje pro kontext
    přehrávače (konec přehrání pak nese tentýž ident, sid a pozici). Nikdy nevyhazuje."""
    pick: Dict[str, Any] = {}
    try:
        state = _rm_dispatch.read_state() or {}
        pick = _rm_stel.pick_from_snapshot(_rm_stel.load_snapshot(), req_ident, pick_key)
        fl = _mi2_flags_for(ident)
        q_class, q_src = _rm_quality.resolve(fl, name_label=(_quality_of_name(release_name) if release_name else ""))
        pick.update({
            "v": _rm_stel.SCHEMA, "key": pick_key,
            "via": str(state.get("source") or ("autoplay" if autoplay else "click")),
            "ident": req_ident, "resolved": ident, "src": (source or "")[:2],
            "q": _rm_quality.class_label(q_class), "q_src": q_src,
            "cz_dub": (1 if fl.get("cz_dub") else 0) if fl and not fl.get("fail") else -1,
            "resume": bool(resumed),
        })
        _log("PLAY_PICK %s" % _rm_stel.compact(pick), xbmc.LOGINFO, context=pick)
    except Exception as exc:
        _log(f"PLAY_PICK failed: {exc!r}", xbmc.LOGDEBUG)
    return pick


def _close_search_progress(prog: Optional["_SearchProgressWithTips"]) -> None:
    """Zavře dialog hledání (idempotentní) — VŽDY dřív, než se ukáže jiný dialog nebo výpis."""
    if prog is not None:
        try:
            prog.close()
        except Exception:
            pass


def _search_cancelled(title: str, prog: Optional["_SearchProgressWithTips"]) -> bool:
    """Φ5A (A06 R10): uživatel zmáčkl Zrušit / Zpět → konec BEZ dalších vln, MediaInfo, enrich a výpisu.
    Vrací True, když bylo zrušeno (adresář je pak uzavřený `succeeded=False` → Kodi zůstane, kde byl)."""
    global _SEARCH_LOG_PATH
    if prog is None or not prog.iscanceled():
        return False
    _close_search_progress(prog)
    _log_event("SEARCH_END", title, "CANCELLED")
    _log(f"SEARCH_CANCELLED title={title!r}", xbmc.LOGINFO)
    _SEARCH_LOG_PATH = ""
    try:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    except Exception:
        pass
    return True


def _after_render_enrich(rels: List[Release], title: str) -> None:
    """Φ5A (A06 R04): `file_info` enrich až PO vykreslení výpisu (seznam je vidět) a jen pro první
    obrazovku — slouží jako MĚŘENÍ (`WS_ENRICH_EFFECT`), zda `/file_info` přináší něco navíc proti
    `/search`. Dřív stál PŘED výpisem pro KAŽDÝ stream (PC: 154 streamů = 10 s holého kolečka)."""
    _stel_run = _rm_stel.current()
    if _stel_run is not None:
        _stel_run.mark("enrich")
    try:
        _ws_fileinfo_enrich(list(rels or [])[:_rm_listing.FIRST_SCREEN_ITEMS])
    except Exception as exc:
        _log(f"ws_fileinfo_enrich after render failed: {exc!r}", xbmc.LOGDEBUG)
    try:
        _log_search_summary(rels, title=title)
    except Exception:
        pass
    if _stel_run is not None:
        _stel_run.mark("post")


def _auto_search_movie(tmdb_id: int) -> None:  # 14.12.2025 17:51 CET (Europe/Prague)
    """
    Jedno-klikové vyhledání filmu dle TMDb ID (TMDb detail → dotazy → vlna hledání → MediaInfo → výpis).

    Φ5A (29.09.2026, audit A06 R01/R03/R10): JEDEN dialog od kliknutí do seznamu. Otevře se PŘED fází
    TMDb (dřív ~2,4 s holého kolečka), provede fázemi s počty („Zjišťuji názvy a stopáž…“ → „Hledám na
    Webshare a Fastshare (2/4)…“ → „Zjišťuji dabing a kvalitu (7/10)…“), zavře se hned, jak je hotovo
    (žádné umělé „minimální zobrazení hlášky“ — D4), a Zrušit opravdu ukončí hledání. Obal zaručuje
    zavření dialogu na všech cestách (výjimka, návrat, chyba).
    """
    _auto_key = f"richmovie.auto.done.{tmdb_id}"
    # Návrat Zpět z přehrávání (re-entry): bez dialogu — uživatel nechce „Vyhledávání“ pokaždé, když se vrátí.
    _is_reentry = bool(xbmcgui.Window(10000).getProperty(_auto_key))
    # new-UI: dialog NEukazovat — „Hledám streamy…“ zobrazuje picker
    prog = None if (_is_reentry or _rm_new_ui()) else _SearchProgressWithTips(
        "RichMovie", _build_tip_rotator(), first_phase="Zjišťuji názvy a stopáž…"
    )
    try:
        with _search_scope("movie", f"movie:{tmdb_id}", "reentry" if _is_reentry else "click"):
            _auto_search_movie_run(tmdb_id, prog, _auto_key)
    finally:
        _close_search_progress(prog)


def _auto_search_movie_run(tmdb_id: int, prog: Optional["_SearchProgressWithTips"], _auto_key: str) -> None:
    """Tělo `_auto_search_movie` (dialog `prog` vlastní a zavírá obal). Hledání = SSOT `richmovie_movie_search`
    (stejná kaskáda jako `_search_movie` pro nabídku v Televizi), tady zůstává jen UI: dialog, MediaInfo, výpis,
    SkTorrent a hlášky.

    Diagnostické logy: SEARCH_BEGIN / SEARCH_FALLBACK / SEARCH_END, MOVIE_BAN_TOKENS(+_JSON).
    """
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _close_search_progress(prog)
        _modal("Chybí API klíč TMDb.")
        return

    try:
        ctx = _rm_moviesearch.build_context(TMDb(tmdb_key, lang="cs-CZ"), tmdb_id)
    except TMDbError as e:
        _close_search_progress(prog)
        _net_error_ui(e)
        return
    det = ctx.det
    banned_keys = ctx.banned_keys
    primary_norms = ctx.primary_norms

    # – LOG BEGIN –––––––––––––––––––––––––––––––––––––––––––––––––––
    global _SEARCH_LOG_PATH
    log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
    if not xbmcvfs.exists(log_dir):
        xbmcvfs.mkdirs(log_dir)
    ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    safe = re.sub(r"[^0-9A-Za-z]+", "_", f"{det['title']}_{det['year']}")[:40]
    _SEARCH_LOG_PATH = os.path.join(log_dir, f"{ts}_{safe}.log")
    _log_event("SEARCH_BEGIN", det["title"], det["year"])

    # NOVĚ: vypiš použité ban-tokény (pro ladění)
    try:
        preview = ", ".join(sorted(list(banned_keys))[:18])
        _log_event("MOVIE_BAN_TOKENS", det["title"], len(banned_keys), preview)
        _log_event("MOVIE_BAN_TOKENS_JSON", json.dumps(sorted(list(banned_keys)), ensure_ascii=False))
        # Φ-B: názvy, proti kterým filtr posuzuje shodu (pro replay — dřív se odvozovaly z dotazů)
        _log_event("MOVIE_TITLE_NORMS_JSON", json.dumps(sorted(primary_norms), ensure_ascii=False))
    except Exception:
        pass

    def _relogin() -> None:
        nonlocal prog
        _close_search_progress(prog)
        prog = None
        _ensure_login(_client(), interactive=True)

    try:
        result = _rm_moviesearch.run_cascade(
            _ENGINE, ctx, log_event=_log_event, progress=prog, relogin=_relogin,
            should_cancel=lambda: _search_cancelled(det["title"], prog),
        )
    except _rm_moviesearch.WaveFailed as wf:
        _close_search_progress(prog)
        _is_login = wf.stage == _rm_moviesearch.STAGE_LOGIN
        _net_error_ui(wf.cause, heading="Přihlášení k Webshare" if _is_login else "Webshare")
        _second = wf.wave == _rm_moviesearch.WAVE_ALT
        _log_event("SEARCH_END", det["title"],
                   ("TOKEN_RETRY_FAIL2" if _second else "TOKEN_RETRY_FAIL") if _is_login else ("ERR2" if _second else "ERR"))
        _SEARCH_LOG_PATH = ""
        return

    if result.cancelled:
        return
    rels = result.rels

    # – MediaInfo pro první obrazovku (v tomtéž dialogu), výpis, enrich až po něm –––––––––––––––––
    if rels:
        # 3.5.153: MI2 se startuje a dočkává, dokud je dialog otevřený (dřív druhý modální dialog uvnitř
        # stavby adresáře, incident Sony 19.09.2026). Bez dialogu (návrat Zpět) jen krátký strop.
        _mi2_prepare(rels, _rm_listing.current_listing_key(), progress=prog,
                     cap_s=None if prog is not None else _rm_listing.MI2_WAIT_NODIALOG_CAP_S)
        if _search_cancelled(det["title"], prog):
            return
        _close_search_progress(prog)
        _list_releases(rels, movie=det)
        xbmcgui.Window(10000).setProperty(_auto_key, "1")
        _after_render_enrich(rels, det["title"])
        _log_event("SEARCH_END", det["title"], len(rels))
        _SEARCH_LOG_PATH = ""
        return

    # – Nic: SkTorrent fallback (WS+FS prázdné; bez alternativních názvů nebo i po nich) ––––––––––
    _close_search_progress(prog)
    _had_alt = bool(result.alt_titles)
    _skt_q = det.get("original_title") or det.get("title") or ""
    if det.get("year"):
        _skt_q += f" {det['year']}"
    _skt_poster = f"https://image.tmdb.org/t/p/w342{det['poster_path']}" if det.get("poster_path") else ""
    _skt_fanart = f"https://image.tmdb.org/t/p/w1280{det['backdrop_path']}" if det.get("backdrop_path") else ""
    _skt_meta = {
        "poster": _skt_poster,
        "fanart": _skt_fanart,
        "overview": det.get("overview") or "",
        "rating": det.get("vote_average"),
    }
    if _skt_q and _sktorrent_fallback(_skt_q, tmdb_meta=_skt_meta):
        if _had_alt:
            try:
                _log_search_summary([], title=det["title"])
            except Exception:
                pass
        _log_event("SEARCH_END_SKT", det["title"], "sktorrent_fallback_alt" if _had_alt else "sktorrent_fallback_no_alt")
        _SEARCH_LOG_PATH = ""
        xbmcplugin.setContent(HANDLE, "videos")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    _no_release_ui()
    if _had_alt:
        # 2025-10-12 – SEARCH SUMMARY (0 položek)
        try:
            _log_search_summary([], title=det["title"])
        except Exception:
            pass
    _log_event("SEARCH_END", det["title"], 0)
    _SEARCH_LOG_PATH = ""
    # Explicitní uzavření adresáře (cross-check Flash B3) — koncová větev, nic dalšího už handle nepoužije.
    try:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    except Exception:
        pass


def _search_movie(tmdb_id: int, should_cancel: Optional[Callable[[], bool]] = None,
                  info: Optional[Dict[str, Any]] = None) -> Tuple[List['Release'], Dict[str, Any], bool]:
    """Hledání filmu BEZ UI (nabídka lepší verze při sledování Televize): stejný kontext a stejná kaskáda jako výpis,
    výsledek jde do stejné cache hledání. Vrací (streamy, detail filmu, prázdné_je_autoritativní). Chyby propagují
    (`TMDbError`, `WaveFailed`, `TokenExpired`): volající je klasifikuje a nic z nich neukládá (R2)."""
    with _search_scope("movie", f"movie:{int(tmdb_id)}", "live_offer") as _run:
        tmdb_key = richmovie_settings.get_tmdb_api_key()
        if not tmdb_key:
            return [], {}, False
        ctx = _rm_moviesearch.build_context(TMDb(tmdb_key, lang="cs-CZ"), int(tmdb_id))
        _log_event("SEARCH_BEGIN", ctx.det["title"], ctx.det["year"], "live_offer")
        result = _rm_moviesearch.run_cascade(
            _ENGINE, ctx, log_event=_log_event,
            progress=_rm_moviesearch.CancelOnly(should_cancel) if should_cancel is not None else None,
            should_cancel=should_cancel, kick_mi2=False,
        )
        if info is not None:
            info["rate_limited"] = result.rate_limited
        _run.n_list = len(result.rels)
        if _run.searched and not _run.outcome:
            _run.outcome = "cancelled" if result.cancelled else ("live_offer" if result.rels else "live_offer_empty")
        if result.errors:
            _run.errors = max(int(_run.errors), int(result.errors))
        return result.rels, ctx.det, _rm_moviesearch.empty_is_authoritative(result, ctx)


# `_search_movie_flow` ODSTRANĚNA (Φ5A, 29.09.2026): nikdo ji nevolal (mrtvý kód; hledání filmu = SSOT
# `_auto_search_movie`).








# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _movie_search (upraveno: 2025-12-23 22:23 CET (Europe/Prague) – FILMY: stopáž (min) modře + release badge (typ+datum + platforma jen když je dostupná) ve výsledcích vyhledávání, best-effort přes tmdb.movie_enrich)
# ---------------------------------------------------------------------------- #
def _movie_search(term: str | None = None) -> None:
    """
    2025-12-23 22:23 CET (Europe/Prague)

    Interaktivní workflow vyhledávání filmu na TMDb.

    ZACHOVÁNO:
    ----------
    • Pokud TMDb vrátí jediný výsledek → rovnou spustíme `_auto_search_movie(<tmdb_id>)`.
    • Jinak zobrazíme přehledný GUI výpis výsledků jako u seriálů.
    • Každá položka odkazuje na `?action=auto&tmdb=<id>` (jedno-klik).

    NOVĚ:
    ------
    • Stopáž filmu v minutách (modře) – best-effort z TMDb.
    • Release badge (varianta B): typ + datum (primárně CZ, fallback US),
      platforma jen když je dostupná (watch/providers nebo TMDb note) – zobrazeno šedě v názvu.
    • Φ6 (D10): obohacení celého výpisu jedním hromadným dotazem (`_movie_enrich_map`), bez dotazů po jednom.
    """
    # ❶ Získání textu dotazu --------------------------------------------------
    # POZOR: Search probíhá INLINE (klávesnice + TMDb dotaz ve stejném procesu).
    # Původně zde byl redirect pattern (endOfDirectory + Container.Update s q=),
    # který zajišťoval, že Back z výsledků neukáže klávesnici znovu.
    # Redirect ale na některých strojích nefunguje – Kodi zahodí Container.Update
    # s hláškou "updating in progress", protože ještě zpracovává prázdný listing
    # z endOfDirectory. Výsledek: uživatel vidí prázdnou složku, search neproběhne.
    # Testováno s succeeded=True i False, obojí selhává. (2026-02-27, Kodi 21.3)
    if term is None:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        term = (args.get("q", [""])[0] or "").strip()
        if not term:
            term = _keyboard_input("Název filmu")
            if not term:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    term = term.strip()

    # ❷ Dotaz na TMDb ----------------------------------------------------------
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _add_to_history(term, category="movie")
        _modal("Chybí API klíč TMDb.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    tmdb = TMDb(tmdb_key, lang="cs-CZ")

    try:
        movies = tmdb.search(term, limit=40)
    except TMDbError as e:
        _add_to_history(term, category="movie")
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # Ulozit do historie s TMDb metadaty (pokud mame vysledky)
    if movies:
        _first = movies[0]
        _add_to_history(term, category="movie", meta={
            "tmdb_id": _first.get("id"),
            "title": _first.get("title", term),
            "year": _first.get("year"),
            "poster_path": _first.get("poster_path", ""),
            "backdrop_path": _first.get("backdrop_path", ""),
            "overview": _first.get("overview", ""),
            "rating": _first.get("rating", 0),
        })
    else:
        _add_to_history(term, category="movie")

    # Breadcrumb (2026-07-01): TMDb hledání proběhlo → hranice mezi „fází hledání"
    # a renderem výsledků. Když sentinel uvízne PŘED tímto bodem, spadla síť/TMDb;
    # když ZA ním (list_releases_begin), spadl render.
    try:
        import richmovie_breadcrumb as _bc_ms
        _bc_ms.checkpoint("movie_search_tmdb_done", n=len(movies or []), term=(term or "")[:60])
    except Exception:
        pass

    if not movies:
        _modal("Nic nenalezeno.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # ❸ Pokud je výsledek jediný → chováme se beze změny -----------------------
    if len(movies) == 1:
        _auto_search_movie(movies[0]["id"])
        return

    # ❹ GUI výpis výsledků (shodný styl jako _tv_search) -----------------------
    xbmcplugin.setPluginCategory(HANDLE, f"Výsledky: {term}")
    xbmcplugin.setContent(HANDLE, "movies")  # typ obsahu

    # Φ6 (D10): stopáž a štítek premiéry pro celý výpis JEDNÍM dotazem (dřív movie_enrich po jednom)
    enrich_map = _movie_enrich_map(tmdb, [m.get("id") for m in movies])

    for m in movies:
        try:
            _mid = int(m.get("id") or 0)
        except (TypeError, ValueError):
            _mid = 0
        overview, backdrop_path, runtime_min, release_badge = _movie_row_meta(m, enrich_map.get(_mid), tmdb)

        runtime_suffix = f" [COLOR FF87CEFA]({runtime_min} min)[/COLOR]" if runtime_min > 0 else ""
        badge_suffix   = f" [COLOR FF9E9E9E]{release_badge}[/COLOR]" if release_badge else ""

        # ★ hodnocení tučně + zlatě + tabulátor
        rating_txt = (
            f"[B][COLOR gold]★ {m.get('rating', 0)}[/COLOR][/B]\t"
            if m.get("rating") else ""
        )
        title_core = (f"{m.get('title', '')} ({m.get('year', '')})" if m.get("year") else m.get("title", ""))
        label = f"{rating_txt}{title_core}{runtime_suffix}{badge_suffix}"

        li = xbmcgui.ListItem(label)

        # Properties pro skin (stopáž + badge)
        if runtime_min > 0:
            try:
                li.setProperty("richmovie.runtime_min", str(runtime_min))
            except Exception:
                pass
        if release_badge:
            try:
                li.setProperty("richmovie.release_badge", release_badge)
            except Exception:
                pass

        # artwork --------------------------------------------------------------
        art = {"icon": "DefaultVideo.png"}
        if m.get("poster_path"):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{m['poster_path']}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{m['poster_path']}"
        if backdrop_path:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{backdrop_path}"
        li.setArt(art)

        # info-panel -----------------------------------------------------------
        li.setInfo(
            "video",
            {
                "title":     m.get("title", ""),
                "plot":      overview,
                "year":      m.get("year") or 0,
                "mediatype": "movie",
                "rating":    m.get("rating", 0),
                "votes":     m.get("votes", 0),
            },
        )
        if m.get("rating"):
            try:
                li.setRating("tmdb", m.get("rating", 0), int(m.get("votes", 0)))
            except Exception:
                pass

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="auto", tmdb=str(m.get("id", ""))),
            li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(HANDLE)







# 2025‑07‑22 07:56 CEST  _tv_search() – rating: tab + tučná zlatá
def _tv_search(term: str | None = None) -> None:
    """
    Vyhledá seriály na TMDb a zobrazí je s tučným zlatým hodnocením.

    Novinky 22/07/2025 07:56 CEST
    -----------------------------
    • hodnocení v Label1 tučně + zlatě, za ním tabulátor
    """
    # 1) — vstup ———————————————————————————————————————————
    # POZOR: Inline search – viz komentář v _movie_search() k redirect problému.
    if term is None:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        term = (args.get("q", [""])[0] or "").strip()
        if not term:
            term = _keyboard_input("Název seriálu")
            if not term:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
    term = term.strip()
    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _add_to_history(term, category="tv")
        _modal("Chybí API klíč TMDb.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    try:
        shows = TMDb(tmdb_key, lang="cs-CZ").search_tv(term, limit=20)
    except TMDbError as e:
        _add_to_history(term, category="tv")
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    # Ulozit do historie s TMDb metadaty (pokud mame vysledky)
    if shows:
        _first_tv = shows[0]
        _add_to_history(term, category="tv", meta={
            "tmdb_id": _first_tv.get("id"),
            "title": _first_tv.get("name", term),
            "year": _first_tv.get("year"),
            "poster_path": _first_tv.get("poster_path", ""),
            "backdrop_path": _first_tv.get("backdrop_path", ""),
            "overview": _first_tv.get("overview", ""),
            "rating": _first_tv.get("rating", 0),
        })
    else:
        _add_to_history(term, category="tv")

    if not shows:
        _modal("Nic nenalezeno.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    # 2) — GUI výpis ———————————————————————————————
    xbmcplugin.setPluginCategory(HANDLE, f"Výsledky: {term}")
    xbmcplugin.setContent(HANDLE, "tvshows")

    for s in shows:
        rating_txt = (
            f"[B][COLOR gold]★ {s.get('rating', 0)}[/COLOR][/B]\t"
            if s.get("rating") else ""
        )
        title_core = (
            f"{s.get('name', '')} ({s.get('year', '')})" if s.get("year") else s.get("name", "")
        )
        label      = f"{rating_txt}{title_core}"

        li = xbmcgui.ListItem(label)

        

        # artwork --------------------------------------------------------------
        art = {"icon": "DefaultTVShows.png"}
        if s.get("poster_path"):
            art["poster"] = f"https://image.tmdb.org/t/p/w342{s.get('poster_path', '')}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{s.get('poster_path', '')}"
        if s.get("backdrop_path"):
            art["fanart"] = f"https://image.tmdb.org/t/p/original{s.get('backdrop_path', '')}"
        li.setArt(art)

        # info‑panel -----------------------------------------------------------
        li.setInfo(
            "video",
            {
                "title":     s.get("name", ""),
                "plot":      s.get("overview", ""),
                "year":      s.get("year") or 0,
                "mediatype": "tvshow",
                "rating":    s.get("rating", 0),
                "votes":     s.get("votes", 0),
            },
        )
        if s.get("rating"):
            li.setRating("tmdb", s.get("rating", 0), int(s.get("votes", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="tv_seasons", tv_id=s.get("id", ""), tv_name=s.get("name", "")),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)









# 2025‑07‑22 07:56 CEST  _tv_seasons() – rating: tab + tučná zlatá
def _tv_seasons(tv_id_arg: Optional[str] = None, tv_name_arg: Optional[str] = None) -> None:
    """
    Výpis řad (season) daného seriálu s tučným zlatým hodnocením.

    Novinky 22/07/2025 07:56 CEST
    -----------------------------
    • hodnocení v Label1 tučně + zlatě, za ním tabulátor
    """
    args     = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    # Explicitní argumenty mají přednost — volá je `open_recommendation`, jehož
    # URL nese `tmdb_id`, ne `tv_id` (audit Fable F-A).
    tv_id    = (tv_id_arg or args.get("tv_id", [""])[0])
    tv_name  = (tv_name_arg or args.get("tv_name", [""])[0])

    if not tv_id:
        _modal("Chybí tv_id.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    tmdb_key = richmovie_settings.get_tmdb_api_key()
    tmdb = TMDb(tmdb_key, lang="cs-CZ")
    try:
        det = tmdb.tv_details(int(tv_id))
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    tv_overview = det.get("overview", "")
    tv_poster   = det.get("poster_path") or ""
    tv_backdrop = det.get("backdrop_path") or ""

    seasons = [s for s in det.get("seasons", []) if s.get("season_number", 0) > 0]
    if not seasons:
        # Distinguish: TMDb partial payload (cache shape mismatch — Gate served a
        # search projection) vs. legitimate "TMDb has no positive-numbered seasons".
        # The former is recoverable on retry once Gate refetches; the latter is
        # a data fact about the show. See Handoff/session_2026-04-30_tmdb_partial_
        # cache_poisoning.md.
        is_partial = ("_partial_from" in det) or ("seasons" not in det)
        if is_partial:
            _log(
                "_tv_seasons: partial detail received tv_id={} keys={}".format(
                    tv_id, sorted(list(det.keys()))[:20],
                ),
                xbmc.LOGWARNING,
            )
            # Evict local cached partial so the retry hits Gate (which will
            # detect partial server-side via migration 0006 and live-refetch).
            try:
                tmdb.cache_evict("tv_details:{}:{}".format(int(tv_id), "cs-CZ"))
            except Exception:
                pass
            _modal("TMDb vrátilo neúplná data. Cache se obnoví, zkuste znovu.")
        else:
            _modal("TMDb nemá žádné sezóny pro tento seriál.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return

    # 4.0.3 (A5, A9): souhrn řady („6/10 ✔ · rozkoukaný díl 7") z čerstvého stavu profilu — divák hned vidí,
    # kde je, místo hledání po sezónách (incident 07.10.2026)
    try:
        import richmovie_state_sync as _ss_seasons
        _ss_seasons.pull_if_stale(max_age_s=_ss_seasons.LIST_FRESH_MAX_AGE_S, step="pull_list")
    except Exception as _ss_s_exc:
        _log(f"state pull at seasons failed: {_ss_s_exc!r}", xbmc.LOGDEBUG)
    try:
        _season_w = _hist_module.watched_info_for_series(tv_id)
        _season_p = _hist_module.progress_for_series(tv_id)
    except Exception:
        _season_w, _season_p = {}, {}

    for s in seasons:
        sn = s["season_number"]
        rating = round(float(s.get("vote_average") or 0), 1)
        rating_txt = (
            f"[B][COLOR gold]★ {rating}[/COLOR][/B]\t" if rating else ""
        )

        label_core = f"Série {sn:02d}"
        if s.get("name") and s.get("name", "").lower() not in ("season", label_core.lower()):
            label_core += f" – {s.get('name', '')}"
        try:
            _summary = _hist_module.season_summary(int(sn), int(s.get("episode_count") or 0), _season_w, _season_p)
        except Exception:
            _summary = ""
        label = f"{rating_txt}{label_core}" + (f"  [COLOR FF9E9E9E]· {_summary}[/COLOR]" if _summary else "")

        # artwork – beze změny -------------------------------------------------
        poster = s.get("poster_path") or tv_poster
        art = {"icon": "DefaultTVShows.png"}
        if poster:
            art["poster"] = f"https://image.tmdb.org/t/p/w342{poster}"
            art["thumb"]  = f"https://image.tmdb.org/t/p/w185{poster}"
        if tv_backdrop:
            art["fanart"] = f"https://image.tmdb.org/t/p/original{tv_backdrop}"

        # info‑panel – beze změny ---------------------------------------------
        info = {
            "title":     label_core,
            "plot":      (s.get("overview") or "").strip() or tv_overview,
            "season":    sn,
            "mediatype": "season",
            "rating":    rating,
            "votes":     int(s.get("vote_count", 0)),
        }

        li = xbmcgui.ListItem(label)
        li.setArt(art)
        li.setInfo("video", info)
        if rating:
            li.setRating("tmdb", rating, int(s.get("vote_count", 0)))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(
                action="tv_episodes",
                tv_id=tv_id,
                tv_name=tv_name,
                season=str(sn),
            ),
            li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)






# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _tv_episodes
# _tv_episodes (upraveno: 14.12.2025 13:24 CET (Europe/Prague) – stopáž v labelu + FIX: artwork bez TMDb.image_url + předání rt_min do tv_play (runtime sanity ±10%))
# ---------------------------------------------------------------------------- #
def _tv_episodes() -> None:
    """
    14.12.2025 13:24 CET (Europe/Prague)

    ÚPRAVA:
      • Zachováno zlaté hodnocení (★) v labelu.
      • U budoucích epizod šedý dovětek "(Premiéra DD.MM.RRRR)".
      • NOVĚ: Stopáž epizody (minuty) – světle modře v závorce.
      • FIX: nepoužívat TMDb.image_url (neexistuje v našem tmdb_client.py),
        artwork skládáme stejně jako ve zbytku pluginu přes https://image.tmdb.org/t/p/...
      • NOVĚ: do klik URL na tv_play předáváme rt_min (runtime epizody), aby šel dělat sanity check streamů.
    """
    args     = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    tv_id    = (args.get("tv_id")   or [""])[0]
    tv_name  = (args.get("tv_name") or [""])[0]
    try:
        season = int((args.get("season") or ["0"])[0])
    except Exception:
        season = 0

    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _modal("Chybí API klíč TMDb.")
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
        except Exception:
            pass
        return

    def _img(path: str, size: str) -> str:
        """
        Složí TMDb image URL.
        size např.: w185, w300, w342, w500, w1280, original
        """
        p = (path or "").strip()
        if not p:
            return ""
        return f"https://image.tmdb.org/t/p/{size}{p}"

    # Načti sezónu
    eps = []
    season_overview = ""
    season_poster   = ""
    try:
        season_data = TMDb(tmdb_key, lang="cs-CZ")._get_json(
            f"/tv/{tv_id}/season/{season}",
            {"api_key": tmdb_key, "language": "cs-CZ"},
        )
        eps = season_data.get("episodes", []) or []
        season_overview = (season_data.get("overview") or "").strip()
        season_poster   = season_data.get("poster_path") or ""
    except TMDbError:
        pass
    except Exception as exc:
        _log(f"TMDb season episodes fetch failed: {exc}", xbmc.LOGDEBUG)

    # Fallback – detail seriálu (kvůli overview/poster/backdrop + default runtime)
    tv_overview = ""
    tv_poster   = ""
    tv_backdrop = ""
    tv_runtime_default_min: Optional[int] = None
    try:
        tv_det = TMDb(tmdb_key, lang="cs-CZ").tv_details(int(tv_id))
        tv_overview = (tv_det.get("overview") or "").strip()
        tv_poster   = tv_det.get("poster_path") or ""
        tv_backdrop = tv_det.get("backdrop_path") or ""

        # TMDb: episode_run_time je list – vezmeme první rozumnou hodnotu
        try:
            rts = tv_det.get("episode_run_time") or []
            if isinstance(rts, list):
                for v in rts:
                    try:
                        iv = int(v or 0)
                    except Exception:
                        iv = 0
                    if iv > 0:
                        tv_runtime_default_min = iv
                        break
        except Exception:
            tv_runtime_default_min = None

    except TMDbError:
        pass
    except Exception as exc:
        _log(f"TMDb TV details fetch failed (tv_episodes): {exc}", xbmc.LOGDEBUG)

    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.setPluginCategory(HANDLE, f"{tv_name} – S{season:02d}")

    # "Zpět" položka
    li_back = xbmcgui.ListItem("Zpět na sezóny…")
    li_back.setArt({"icon": "DefaultFolderBack.png"})
    xbmcplugin.addDirectoryItem(
        HANDLE, _url(action="tv_seasons", tv_id=tv_id, tv_name=tv_name), li_back, isFolder=True
    )

    if not eps:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Šířka číslování (podle max čísla epizody v sezóně)
    try:
        pad = len(str(max(int(e.get("episode_number") or 0) for e in eps)))
    except Exception:
        pad = 2

    today = datetime.date.today()

    # 4.0.3 (A9): zastaralé zařízení (probuzený notebook) si stav profilu nejdřív stáhne — jinak ukáže díl
    # dokoukaný na jiném zařízení jako neviděný (incident 10.10.2026). Strop 1,5 s, offline = lokální data.
    try:
        import richmovie_state_sync as _ss_list
        _ss_list.pull_if_stale(max_age_s=_ss_list.LIST_FRESH_MAX_AGE_S, step="pull_list")
    except Exception as _ss_list_exc:
        _log(f"state pull at episode list failed: {_ss_list_exc!r}", xbmc.LOGDEBUG)
    # Stav dílů seriálu: ✔ (watched_episodes.json) + rozkoukanost (postup per titul, 4.0.3) — jednou per render.
    try:
        _watched_info = _hist_module.watched_info_for_series(tv_id)
    except Exception:
        _watched_info = {}
    try:
        _progress_info = _hist_module.progress_for_series(tv_id)
    except Exception:
        _progress_info = {}
    _now_ts = time.time()

    for e in eps:
        no = int(e.get("episode_number") or 0)
        name = (e.get("name") or "").strip()
        rating = round(float(e.get("vote_average") or 0.0), 1)
        votes  = int(e.get("vote_count") or 0)

        # Zlaté tučné hodnocení + tabulátor
        rating_txt = f"[B][COLOR gold]★ {rating:.1f}[/COLOR][/B]\t" if rating >= 1.0 else ""

        # Jádro labelu
        label_core = f"{no:0{pad}d}" + (f" – {name}" if name else "")

        # Stopáž epizody (minuty) – primárně z epizody, fallback z tv defaultu
        runtime_min = 0
        try:
            runtime_min = int(e.get("runtime") or 0)
        except Exception:
            runtime_min = 0
        if runtime_min <= 0 and tv_runtime_default_min:
            try:
                runtime_min = int(tv_runtime_default_min)
            except Exception:
                runtime_min = 0

        runtime_suffix = f" [COLOR FF87CEFA]({runtime_min} min)[/COLOR]" if runtime_min > 0 else ""

        # Premiéra – šedý dovětek, jen pokud je datum v budoucnu
        premiere_suffix = ""
        premiere_iso = (e.get("air_date") or "").strip()
        air_dt = None
        if premiere_iso:
            try:
                y, m, d = [int(x) for x in premiere_iso.split("-", 2)]
                air_dt = datetime.date(y, m, d)
                if air_dt > today:
                    premiere_suffix = f" [COLOR gray](Premiéra {air_dt.strftime('%d.%m.%Y')})[/COLOR]"
            except Exception:
                air_dt = None

        # Stav dílu — SSOT `richmovie_history.episode_badge` (4.0.3, A5): ✔ viděno · ◐ rozkoukáno (odkud, kdy,
        # kolik) · ⏾ běželo bez tebe (prokázaný spánek). Stejný jazyk jako nový vzhled a řádek sezóny.
        _badge = _hist_module.episode_badge(_watched_info.get((season, no)), _progress_info.get((season, no)), _now_ts)
        _ep_watched = bool(_badge["watched"])
        _ep_unattended = _badge["state"] == "asleep"
        _watched_prefix = f"[COLOR {_badge['color']}]{_badge['symbol']}[/COLOR]  " if _badge["symbol"] else ""
        _watched_suffix = f" [COLOR FF9E9E9E]{_badge['text']}[/COLOR]" if _badge["text"] else ""
        label = f"{_watched_prefix}{rating_txt}{label_core}{runtime_suffix}{premiere_suffix}{_watched_suffix}"
        li = xbmcgui.ListItem(label)

        # Artwork (stejně jako jinde v pluginu – bez TMDb.image_url)
        still = (e.get("still_path") or "").strip()
        poster = season_poster or tv_poster

        art = {"icon": "DefaultEpisodes.png"}
        if still:
            art["thumb"] = _img(still, "w300")
        if poster:
            art["poster"] = _img(poster, "w342")
            art["thumb"]  = art.get("thumb") or _img(poster, "w185")
        if tv_backdrop:
            art["fanart"] = _img(tv_backdrop, "original")
        li.setArt({k: v for k, v in art.items() if v})

        # InfoTag
        plot = (e.get("overview") or "").strip() or season_overview or tv_overview
        li.setInfo("video", {
            "title":        name or f"Epizoda {no}",
            "tvshowtitle":  tv_name,
            "season":       season,
            "episode":      no,
            "mediatype":    "episode",
            "aired":        premiere_iso or "",
            "plot":         plot,
            "rating":       rating,
            "votes":        votes,
            # Nativní Kodi watched overlay (Estuary fajfka) — doplněk k label markeru.
            # `unattended` (prokázaný spánek) tu je 0: díl se nabízí znovu.
            "playcount":    1 if _ep_watched else 0,
        })
        if _badge["position"] > 0 and _badge["duration"] > 0:
            try:   # nativní ukazatel postupu skinu (rozkoukaný díl) — z postupu PROFILU, ne ze záložky zařízení
                li.getVideoInfoTag().setResumePoint(_badge["position"], _badge["duration"])
            except Exception:
                pass

        # Ruční korekce ✔ (3.5.149): „⏾" díl potvrdit jako viděný, viděný odznačit
        try:
            _ep_ctx = []
            _ep_args = {"tv_id": tv_id, "season": str(season), "episode": str(no)}
            if not _ep_watched:
                _ep_ctx.append(("Viděl jsem to",
                                f"RunPlugin({_url(action='ep_mark_watched', **_ep_args)})"))
            if _ep_watched or _ep_unattended:
                _ep_ctx.append(("Označit jako neviděné",
                                f"RunPlugin({_url(action='ep_unmark_watched', **_ep_args)})"))
            if _ep_ctx:
                li.addContextMenuItems(_ep_ctx)
        except Exception as _ctx_exc:
            _log(f"episode context menu skip: {_ctx_exc!r}", xbmc.LOGDEBUG)

        # Properties pro skin
        if air_dt:
            try:
                li.setProperty("richmovie.premiere_iso", premiere_iso)
                li.setProperty("richmovie.premiere_date", air_dt.strftime("%d.%m.%Y"))
            except Exception:
                pass
        if runtime_min > 0:
            try:
                li.setProperty("richmovie.runtime_min", str(runtime_min))
            except Exception:
                pass

        # Klik → vyhledat streamy (NOVĚ: předáváme rt_min pro runtime sanity check v tv_play)
        qs = {
            "action": "tv_play",
            "tv_id": tv_id,
            "tv_name": tv_name,
            "season": str(season),
            "ep_no": str(no),
            "ep_title": name,
        }
        if runtime_min > 0:
            qs["rt_min"] = str(runtime_min)
        url = _url(**qs)

        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


# ---------------------------------- METODA ---------------------------------- #
# plugin.py > _tv_next_episode
# (vytvoreno: 2026-02-27 – "Dalsi dil": najde nasledujici nezhlédnuty dil a spusti tv_play)
# ---------------------------------------------------------------------------- #
def _tv_next_episode() -> None:
    """
    Najde dalsi nezhlédnuty dil serialu a primo vykresli streamy (deleguje na _tv_play).

    Logika:
      1. Nacti watch historii -> najdi posledni zhlednuty dil tohoto serialu.
      2. Pokud neni zadna historie -> zacni od S01E01.
      3. Pokud existuje -> spocitej dalsi dil pres TMDb (season_details + tv_details).
      4. Override sys.argv[2] s parametry pro _tv_play() a zavolej ji primo.

    DULEZITE: Zadne presmerovani/Container.Update – _tv_play() sam vykresli listing
    a zavola endOfDirectory. Tim se vyhneme znamemu race condition (viz _movie_search).
    """
    args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    tv_id_str = (args.get("tv_id", [""])[0] or "").strip()
    tv_name = (args.get("tv_name", [""])[0] or "").strip()

    if not tv_id_str:
        _modal("Chybi tv_id.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    tmdb_key = richmovie_settings.get_tmdb_api_key()
    if not tmdb_key:
        _modal("Chybi API klic TMDb.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # 1) Kde v seriálu pokračovat — SSOT `richmovie_series_nav.continue_point` (4.0.3, M6): položka Pokračovat
    #    (rozkoukaný / nabídnutý díl), jinak díl po nejvzdálenějším ✔, jinak od začátku. Dřív poslední SPUŠTĚNÝ
    #    díl z historie: rozkoukaný díl se přeskočil a díl s ⏾ se už nenabídl.
    import richmovie_series_nav as _nav
    next_season = 1
    next_ep = 1
    ep_title = ""
    tmdb = TMDb(tmdb_key, lang="cs-CZ")
    tv_id_int = int(tv_id_str)
    try:
        import richmovie_state_sync as _ss_next
        _ss_next.pull_if_stale(max_age_s=_ss_next.LIST_FRESH_MAX_AGE_S, step="pull_list")   # A9: zastaralé zařízení nejdřív poslouchá
    except Exception:
        pass
    point = _nav.continue_point(tv_id_str)
    found_in_history = point is not None
    try:
        if point and point.get("at"):
            next_season, next_ep = point["at"]
        elif point and point.get("after"):
            nxt = _nav.next_coords(tmdb, tv_id_int, point["after"][0], point["after"][1])
            if not nxt:
                _modal(f"Seriál '{tv_name}' nemá další díl "
                       f"(poslední zhlédnutý S{point['after'][0]:02d}E{point['after'][1]:02d}).")
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
            next_season, next_ep = nxt
        else:
            first = _nav.first_coords(tmdb, tv_id_int)
            if not first:
                _modal(f"Seriál '{tv_name}' nemá žádné řady.")
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
            next_season, next_ep = first
    except TMDbError as e:
        _net_error_ui(e)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    except Exception as e:
        _net_error_ui(e, heading="Další díl")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    # Ziskej ep_title z season_details (uz ho muzeme mit nactenej)
    try:
        ep_list = tmdb.season_details(tv_id_int, next_season)
        for e in ep_list:
            if int(e.get("episode_number", 0)) == next_ep:
                ep_title = (e.get("name") or "").strip()
                break
    except Exception:
        ep_title = ""

    # 3) Override sys.argv[2] a deleguj na _tv_play()
    new_qs = urlencode({
        "action": "tv_play",
        "tv_id": tv_id_str,
        "tv_name": tv_name,
        "season": str(next_season),
        "ep_no": str(next_ep),
        "ep_title": ep_title,
    })
    sys.argv[2] = f"?{new_qs}"

    try:
        _log_event("TV_NEXT_EPISODE", {
            "tv_id": tv_id_str, "tv_name": tv_name,
            "found_in_history": found_in_history,
            "next": f"S{next_season:02d}E{next_ep:02d}",
            "ep_title": ep_title,
        })
    except Exception:
        pass

    _tv_play()





# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _tv_play
# _tv_play (upraveno: 10.10.2026 (Europe/Prague) – S10: klíč měření ze SSOT `_rm_epsearch.search_key` + `episode_numbers` (dřív jen parametr `episode` → klíč …:0))
# ---------------------------------------------------------------------------- #
def _tv_play() -> None:
    """Výpis streamů dílu. Φ5A (29.09.2026): obal zaručí zavření dialogu hledání (`tv_prog`) na VŠECH
    cestách — výjimka ve vlně, návrat, zrušení (dřív mohl po chybě zůstat viset dialog)."""
    holder: Dict[str, Any] = {}
    try:
        _a = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        _key = _rm_epsearch.search_key((_a.get("tv_id") or [""])[0], *_rm_epsearch.episode_numbers(_a))
    except Exception:
        _key = "tv:?"
    try:
        with _search_scope("tv", _key, "click"):
            _tv_play_run(holder)
    finally:
        _close_search_progress(holder.get("prog"))


def _tv_play_run(holder: Dict[str, Any]) -> None:
    """
    22.12.2025 20:58 CET (Europe/Prague)

    ÚČEL: Bezpečně vykreslit seznam releasů pro epizodu a zabránit přepsání
    nového listingu "starým" během závodu po skončení přehrávání.

    NOVĚ:
      • Čtu 'nav_key' z query a porovnám s Window(10000).property('expected_key').
        • Pokud klíč nesedí, jde o "stará" nebo cizí volání → tiše je ukončím voláním
        endOfDirectory(succeeded=True, updateListing=False, cacheToDisc=False) — bez redirectu.
      • V případě pending scénáře využiji přednačtené releasy z RAM/disku, až poté
        smažu nav_pending a i nové expected_* property.

    NOVĚ (14.12.2025 11:05 CET (Europe/Prague)):
      • Po doběhnutí poslední vlny (W1/W2/W3/WX/WX+) ukážu spinner a dám MI2 šanci max 5 s.
        Jakmile je MI2 hotová (nebo máme výšku videa pro všechny položky), pokračuji hned.
      • Před vykreslením listu finálně seřadím releasy podle kvality (2160P → … → OTHER),
        přičemž priorita dat je: WS height → MI2 video_h → heuristika.

    NOVĚ (14.12.2025 13:45 CET (Europe/Prague)):
      • Runtime sanity (TMDb ±10 %) umí použít i stopáž z MI2 cache (duration_s),
        pokud WS/est_min není vyplněné. Díky tomu se "špatný díl" opravdu zešedí a spadne dolů.

    NOVĚ (14.12.2025 14:49 CET (Europe/Prague)):
      • UX toasty:
          - po wait okně (5 s) a vykreslení "předběžného" seznamu: "Analyzuji zbytek streamů…" (jen když MI2 pořád běží)
          - po finálním MI2 refreshi (nebo když MI2 doběhne): "Analýza dokončena." (jen jednou)
        Navázáno na MI2 marker property:
          Window(10000).Property(richmovie.mi2.refresh_reason) = first|final|deferred
          Window(10000).Property(richmovie.mi2.refresh_key)    = klíč listingu (URL invokace)

    NOVĚ (26.12.2025 21:20 CET (Europe/Prague)):
      • ser_full = OR přes varianty názvu seriálu (hlavní/alt tituly z TMDb) – alt názvy už neshazují správné releasy do u=1.
      • MI2 se nově umí nakopnout i při cache-hitu (RAM/disk/SEARCH cache), takže seriály dostanou stejné toasty + finální refresh jako filmy.
      • Wait okno + "Analyzuji…" toast se spouští podle toho, zda MI2 opravdu běží (ne jen podle searching=True).

    NOVĚ (27.12.2025 00:36 CET (Europe/Prague)):
      • MI2 refresh: updateListing=True i v případě, že refresh_key nesedí 1:1 (marker je přítomný, ale klíč se liší kanonizací/encodingem).
        Cíl: vždy se v GUI projeví runtime_mismatch (šedě + úplně dole) i finální sort dle MI2.
      • MI2 refresh nesmí být zablokován větví "expected_key and not nav_key" (auto-návrat Kodi), pokud je aktivní MI2 marker pro refresh.
    """
    # -------------------------------------------------------------------------
    # Helper: detekce, jestli tohle volání je MI2 refresh (Container.Refresh)
    #
    # mi2_refresh_call = přesná shoda refresh_key == current container key
    # mi2_refresh_any  = marker existuje (reason+key), ale shoda nemusí sedět (kanonizace/encoding)
    # -------------------------------------------------------------------------
    def _mi2_refresh_state(win: "xbmcgui.Window") -> tuple[bool, bool, str, str, str]:
        rr = ""
        rk = ""
        cur_key = ""
        try:
            rr = (win.getProperty("richmovie.mi2.refresh_reason") or "").strip().lower()
            rk = (win.getProperty("richmovie.mi2.refresh_key") or "").strip()
        except Exception:
            rr = ""
            rk = ""

        # Klíč TOHOTO listingu = URL invokace (viz richmovie_listing).
        # `Container.FolderPath` je uvnitř stavby adresáře cesta, ze které odcházíme.
        cur_key = _rm_listing.current_listing_key()

        _p = _rm_listing.plan_listing(
            cur_key=cur_key,
            marker_reason=rr,
            marker_key=rk,
            has_releases=True,
            mi2_running_here=False,
            mi2_thread_alive=False,
        )
        mi2_refresh_any = _p.is_refresh_any
        mi2_refresh_call = _p.is_refresh_call

        # Po opravě klíče (3.5.153) by mismatch neměl nastat — když nastane, je to regrese.
        if _p.mismatch:
            try:
                _log_event("MI2_REFRESH_KEY_MISMATCH", {
                    "rr": rr or None,
                    "rk": rk or None,
                    "cur_key": cur_key or None,
                })
            except Exception:
                pass

        return mi2_refresh_call, mi2_refresh_any, rr, rk, cur_key

    # 1) Parametry z URL
    args: Dict[str, List[str]] = (
        dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    )
    tv_id   = args.get("tv_id",   [""])[0]
    tv_name = args.get("tv_name", [""])[0]
    nav_key = (args.get("nav_key", [""])[0] or "").strip()

    season_no, ep_no = _rm_epsearch.episode_numbers(args)   # S10: jedno čtení i pro klíč měření v `_tv_play`

    ep_title = args.get("ep_title", [""])[0].strip()

    # Re-entry detekce – potlačit search dialog při Back navigaci
    _tv_auto_key = f"richmovie.auto.done.tv.{tv_id}.{season_no}.{ep_no}"
    _tv_is_reentry = bool(xbmcgui.Window(10000).getProperty(_tv_auto_key))

    # Volitelně: TMDb runtime epizody (min) – pro runtime sanity check streamů (±10%).
    tmdb_rt_min = 0
    try:
        tmdb_rt_min = int((args.get("rt_min") or args.get("tmdb_rt_min") or args.get("runtime_min") or ["0"])[0])
    except Exception:
        tmdb_rt_min = 0
    if tmdb_rt_min < 0:
        tmdb_rt_min = 0

    if not (tv_name and season_no > 0 and ep_no > 0):
        _modal("Neplatné parametry vyhledávání.")
        return

    # 2) NEXT-UP GUARD (zastaví "stará/cizí" volání bez správného klíče)
    win = xbmcgui.Window(10000)
    expected_key = (win.getProperty("richmovie.nextup.expected_key") or "").strip()
    expected_url = (win.getProperty("richmovie.nextup.expected_url") or "").strip()

    current_key  = f"{tv_id}:{season_no}:{ep_no}"
    nextup_call  = bool(expected_key and nav_key and (nav_key == expected_key))

    # Guard jen pro PODEPSANÁ (next-up) volání: blokujeme pouze když je nav_key přítomen
    # a nesedí na očekávaný cíl. Nepodepsaná volání (bez nav_key) neblokujeme.
    if expected_key and nav_key and (nav_key != expected_key or current_key != expected_key):
        try:
            _log_event("NEXTUP_MISMATCH", {
                "nav_key":       nav_key or None,
                "expected_key":  expected_key,
                "current_key":   current_key,
                "expected_url":  expected_url or None,
                "plugin_call":   f"{sys.argv[0]}{sys.argv[2] if len(sys.argv) > 2 else ''}",
                "tv_id":         tv_id,
                "season":        season_no,
                "episode":       ep_no,
                "ep_title":      ep_title,
            })
        except Exception:
            pass

        # ❗TICHÉ ukončení bez chyby – žádné "Error getting plugin://…"
        # FIX 21.02.2026: endOfDirectory NEJDŘÍVE, listing.ready AŽ POTOM (race condition fix)
        try:
            xbmcplugin.endOfDirectory(
                HANDLE,
                succeeded=True,
                updateListing=False,
                cacheToDisc=False,
            )
        except TypeError:
            xbmcplugin.endOfDirectory(HANDLE)

        try:
            xbmc.Monitor().waitForAbort(0.12)
        except Exception:
            pass
        try:
            xbmcgui.Window(10000).setProperty("richmovie.listing.ready", "1")
            xbmcgui.Window(10000).setProperty("richmovie.mi2.listing_ready", "1")
        except Exception:
            pass

        return  # ✅ KRITICKÉ: po mismatch už nesmíme pokračovat dál

    # Pokud je nastavené očekávání, ale tohle volání NENÍ podepsané (auto-návrat Kodi),
    # tak ho tichounce ukonči BEZ přepisu GUI – a nech proběhnout řízenou Next-Up navigaci.
    #
    # POZOR: pokud jde o MI2 refresh (Container.Refresh), NESMÍME ho zablokovat,
    # jinak se runtime_mismatch/finální sort v GUI neprojeví.
    # Picker-first klik nese rm_token a NEMÁ nav_key → NESMÍ být spolknut tímto
    # auto-návrat guardem (jinak search neproběhne a Stream-picker visí 75 s).
    # Guard je určen jen pro Kodi auto-návrat (stale expected_key, žádný token).
    _picker_first_click = bool((args.get("rm_token", [""])[0] or "").strip())
    if expected_key and not nav_key and not _picker_first_click:
        mi2_refresh_call, mi2_refresh_any, _rr, _rk, _cur_key = _mi2_refresh_state(win)
        if not (mi2_refresh_call or mi2_refresh_any):
            try:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)
            except TypeError:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
            return

    # ————————————————————————————————————————————————————————————————
    # NEXT-UP: počkej na "volno" z navigace (nav_inflight → vypnuto) + rezerva 0,5 s
    # ————————————————————————————————————————————————————————————————
    try:
        _await_nav_idle(expected_key, nav_key)
    except Exception:
        pass  # "best effort" – nikdy nesmí shodit GUI

    # 3) FAST-PATH pro Next-Up: vytáhni releasy z RAM/disku při nav_pending=1
    key_str   = f"{tv_id}:{season_no}:{ep_no}"
    cache_key = (tv_id, season_no, ep_no)
    with NEXT_CACHE_LOCK:
        rels: Optional[List[Release]] = NEXT_CACHE.pop(cache_key, None)

    pending = False
    try:
        pending = (win.getProperty("richmovie.nextup.nav_pending") or "") == "1"
    except Exception:
        pending = False

    if rels is None and pending:
        mon = xbmc.Monitor()
        for _ in range(15):  # ~3,0 s
            with NEXT_CACHE_LOCK:
                if cache_key in NEXT_CACHE:
                    rels = NEXT_CACHE.pop(cache_key, None)
            if rels:
                break
            disk_json = _disk_nextup_cache().get(key_str)
            if isinstance(disk_json, list):
                rels = _releases_from_records(disk_json, _log_event)
                if rels:
                    break
            if mon.waitForAbort(0.2):
                break

    # Po zpracování pending + expected_* uklidíme (už nás nechrání) + smažeme nav_url.
    try:
        if pending:
            win.clearProperty("richmovie.nextup.nav_pending")
            win.clearProperty("richmovie.nextup.nav_url")
        # NOVĚ: uklidíme i očekávaný cíl (už ho nepotřebujeme)
        win.clearProperty("richmovie.nextup.expected_key")
        win.clearProperty("richmovie.nextup.expected_url")
    except Exception:
        pass

    # --- fallback: načtení z disk-cache (mimo pending) ---
    if rels is None:
        disk_json = _disk_nextup_cache().get(key_str)
        if isinstance(disk_json, list):
            rels = _releases_from_records(disk_json, _log_event)

    searching = rels is None

    # --- MI2 kick i při cache-hitu (RAM/disk/search_cache) ---
    # Pokud releasy přišly z cache, dřív se často přeskočilo nakopnutí MI2 → chyběly toasty + finální refresh.
    try:
        if rels and not searching:
            # SSOT kick (3.5.153): klíč listingu se PŘEDÁVÁ. Čeká se i tady
            # (cross-check Pro Q3), ale bez vlastního dialogu — viz `_list_releases`.
            _mi2_prepare(rels, _rm_listing.current_listing_key(), progress=None,
                         cap_s=_rm_listing.MI2_WAIT_NODIALOG_CAP_S)
    except Exception:
        pass

    # --- MI2 UX toast state (per epizoda) ---
    # searching=True = čerstvé hledání → chceme povolit nové toasty i pro stejnou epizodu.
    if searching:
        try:
            if (win.getProperty("richmovie.mi2.toast.analyze_for") or "").strip() == key_str:
                win.clearProperty("richmovie.mi2.toast.analyze_for")
            if (win.getProperty("richmovie.mi2.toast.done_for") or "").strip() == key_str:
                win.clearProperty("richmovie.mi2.toast.done_for")
        except Exception:
            pass

    # 2) --- DÍL z TMDb (lokální cache) + hledání přes SSOT `richmovie_episode_search` -----------
    # Φ5A (29.09.2026, audit A06 F07/R08): díl, jehož streamy přišly z cache (89 % výpisů dílů díky
    # předhledání ve službě), NEPOTŘEBUJE aliasy, překlady, `spin_tokens` ani dotazy — to jsou vstupy
    # HLEDÁNÍ (`build_context`, jen pod `if searching`). Vykreslení potřebuje jen `det`, `ep_cs`, `ep_en`.
    # Φ-B (30.09.2026): kontext i kaskáda vln jsou SSOT společný s předstažením ve službě.
    tv_prog: Optional["_SearchProgressWithTips"] = None
    _ep_base = _rm_epsearch.load_base(str(tv_id or ""), tv_name, season_no, ep_no, ep_title,
                                      richmovie_settings.get_tmdb_api_key())
    det, ep_cs, ep_en = _ep_base.det, _ep_base.ep_cs, _ep_base.ep_en
    ep_title = _ep_base.ep_title

    # ──────────────────────────────────────────────────────────────
    #  Budoucí premiéra – blokovací dialog (jen při "searching")
    # ──────────────────────────────────────────────────────────────
    if searching and _ep_base.tmdb_cs is not None:
        air_dt = _rm_epsearch.air_date(_ep_base)
        if air_dt and air_dt > datetime.date.today():
            days_left = (air_dt - datetime.date.today()).days

            # mini-skloňování: den / dny / dní
            def _cz_days(n: int) -> str:
                if n % 100 in (11, 12, 13, 14):
                    return "dní"
                if n % 10 == 1:
                    return "den"
                if n % 10 in (2, 3, 4):
                    return "dny"
                return "dní"

            heading = "Epizoda ještě nevyšla"
            line1   = f"Premiéra této epizody je až za {days_left} {_cz_days(days_left)} ({air_dt.strftime('%d.%m.%Y')})."
            try:
                ok = xbmcgui.Dialog().yesno(
                    heading, line1, "", "",
                    nolabel="Zrušit",
                    yeslabel="Zkusit štěstí při hledání",
                )
            except TypeError:
                # starší Kodi neumí custom labely → standardní Yes/No
                ok = xbmcgui.Dialog().yesno(heading, line1)

            if not ok:
                return  # uživatel si nepřeje hledat (ještě) nevydaný díl

    # Φ5A (A06 R01): dialog hledání HNED — nekešovaná fáze TMDb (aliasy, překlady, spin-off tokeny) dřív
    # běžela pod holým kolečkem (pre_ws p50 6,3 s). Jeden dialog pro všechny vlny.
    if searching and not (_tv_is_reentry or _rm_new_ui()):
        tv_prog = _SearchProgressWithTips("RichMovie", _build_tip_rotator(),
                                          first_phase="Zjišťuji názvy dílu…")
        holder["prog"] = tv_prog

    # Φ-C (30.09.2026, E1-F09): služba TENTÝŽ díl právě předhledává → počkat na její výsledek (tentýž filtr,
    # tytéž dotazy) místo druhého souběžného hledání. Zrušit funguje; po vypršení čekání hledá výpis sám.
    if searching:
        import richmovie_guard as _rm_guard
        _pf_claim = _rm_epsearch.prefetch_claim_name(tv_id, season_no, ep_no)

        def _pf_result() -> Optional[List[Release]]:
            _dj = _disk_nextup_cache().get(key_str)
            if isinstance(_dj, list) and _dj:
                return _releases_from_records(_dj, _log_event)
            return None

        if _rm_guard.is_claimed(_pf_claim):
            if tv_prog is not None:
                tv_prog.set_phase(_rm_epsearch.PHASE_WAIT_PREFETCH)
            _pf_t0 = time.monotonic()
            _pf_rels, _pf_why = _rm_epsearch.wait_for_running(
                lambda: _rm_guard.is_claimed(_pf_claim), _pf_result,
                lambda: bool(tv_prog is not None and tv_prog.iscanceled()),
                lambda _s: xbmc.Monitor().waitForAbort(_s))
            _log(f"PREFETCH_WAIT key={key_str} result={_pf_why} "
                 f"waited_ms={int((time.monotonic() - _pf_t0) * 1000)} n={len(_pf_rels or [])}", xbmc.LOGINFO)
            if _search_cancelled(f"{tv_name} S{season_no:02d}E{ep_no:02d}", tv_prog):
                return
            if _pf_rels:
                rels = _pf_rels
                searching = False
                try:
                    _mi2_prepare(rels, _rm_listing.current_listing_key(), progress=tv_prog)
                except Exception:
                    pass
                if _search_cancelled(f"{tv_name} S{season_no:02d}E{ep_no:02d}", tv_prog):
                    return
                _close_search_progress(tv_prog)

    if searching:
        _ep_ctx = _rm_epsearch.build_context(_ep_base, log_event=_log_event)

        # 5) --- LOG SOUBOR ------------------------------------------------
        log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
        if not xbmcvfs.exists(log_dir):
            xbmcvfs.mkdirs(log_dir)
        ts   = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        safe = re.sub(r"[^0-9A-Za-z]+", "_", f"{tv_name}_s{season_no:02d}e{ep_no:02d}")[:50]
        global _SEARCH_LOG_PATH
        _SEARCH_LOG_PATH = os.path.join(log_dir, f"{ts}_{safe}.log")
        _log_event("SEARCH_BEGIN", tv_name, season_no, ep_no)

        # 6) --- HLEDÁNÍ s řízenými vlnami + záchrana číslem (SSOT) ----------
        rels, _ep_info = _rm_epsearch.run_cascade(
            _ENGINE, _ep_ctx, ctx_name="tv_play", log_event=_log_event,
            progress=tv_prog, top_full_probe=0, on_wave_end=_SEARCH_LOG.flush,
        )
        _tv_label = f"{tv_name} S{season_no:02d}E{ep_no:02d}"
        if _search_cancelled(_tv_label, tv_prog):
            return

        # cache dílu jen pro ÚPLNÝ výsledek (selhal-li zdroj, příští otevření hledá znovu — R2, Fable F1-V4)
        _ep_complete = not int(_ep_info.get("errors") or 0)
        if rels and _ep_complete:
            try:
                _disk_nextup_cache().put(key_str, [asdict(r) for r in rels])
            except Exception as exc:
                _log(f"nextup disk cache write failed: {exc}", xbmc.LOGDEBUG)

        # 3.5.153: MI2 se startuje a dočkává, dokud je dialog hledání otevřený (dřív druhý modální dialog
        # v renderovací fázi, až 60 s — incident Sony 19.09.2026). Φ5A: jen první obrazovka (D3), i pro
        # výsledky záchrany (dřív se na ně nečekalo), zrušení se kontroluje před i po.
        if rels and not _search_cancelled(_tv_label, tv_prog):
            try:
                _mi2_prepare(rels, _rm_listing.current_listing_key(), progress=tv_prog)
            except Exception:
                pass
        if _search_cancelled(_tv_label, tv_prog):
            return
        _close_search_progress(tv_prog)   # hotovo = hotovo (D4: žádné umělé držení hlášky)

    # -------------------------------------------------------------------------
    #  6.5) FINÁL: MI2 "wait window" (max 5 s) + finální seřazení dle kvality
    #       (priorita: WS height → MI2 video_h → heuristika)
    #  upraveno: 14.12.2025 11:05 CET (Europe/Prague)
    # -------------------------------------------------------------------------
    def _mi2_flags(ident: str) -> Dict[str, Any]:
        """Bezpečně vrátí MI2 flags pro ident (nebo prázdný dict)."""
        try:
            eng_mod = sys.modules.get("richmovie_engine")
            fn = getattr(eng_mod, "mi2_get_flags", None) if eng_mod else None
            if callable(fn):
                return fn(ident) or {}
        except Exception:
            pass
        return {}

    def _mi2_is_running_here() -> bool:
        """Vrátí True, pokud MI2 thread běží pro TENTO listing (klíč = URL invokace)."""
        try:
            mi2_mod = sys.modules.get("richmovie_mi2")
            MI2 = getattr(mi2_mod, "MediaInfoSecondEdition", None) if mi2_mod else None
            if not MI2:
                return False

            thr = getattr(MI2, "_RUNNING_THR", None)
            if not thr or not getattr(thr, "is_alive", lambda: False)():
                return False

            run_key = getattr(MI2, "_RUNNING_KEY", None)
            # Klíč listingu, ne odchozí kontejner (cross-check Flash A5) — MI2
            # od 3.5.153 drží v `_RUNNING_KEY` klíč listingu.
            cur_key = _rm_listing.current_listing_key()

            if run_key and cur_key and (run_key != cur_key):
                return False

            return True
        except Exception:
            return False

    # `_nearest_std` a `_quality_rank` ODSTRANĚNY (Φ-D, 30.09.2026): SSOT `richmovie_quality`.

    toast_analyze_now = False

    # Spinner a čekání dává smysl, když MI2 opravdu běží (ať už po čerstvém hledání, nebo po cache-hitu).
    # new-UI: NEČEKAT (až 60 s!) — picker se plní živě z release_view.json (drainer).
    if rels and (not _rm_new_ui()) and _mi2_is_running_here():
        # 3.5.153: TADY SE UŽ NEČEKÁ — čekání patří do fáze hledání (`_mi2_prepare`),
        # kde je průběhový dialog už otevřený. Druhý modální DialogProgress uvnitř
        # stavby adresáře byl root cause incidentu Sony 19.09.2026 (viz _list_releases).

        # MI2 pořád běží → jde o "předběžný seznam" → toast až po vykreslení listu.
        try:
            if _mi2_is_running_here():
                if (win.getProperty("richmovie.mi2.toast.analyze_for") or "").strip() != key_str:
                    win.setProperty("richmovie.mi2.toast.analyze_for", key_str)

                    # pro jistotu odblokuj případný "done" z minula
                    if (win.getProperty("richmovie.mi2.toast.done_for") or "").strip() == key_str:
                        win.clearProperty("richmovie.mi2.toast.done_for")

                    toast_analyze_now = True
        except Exception:
            pass

    # Stopáž sanity check (TV): pokud máme TMDb runtime epizody (rt_min) a zároveň známe stopáž streamu,
    # označíme streamy mimo ±10 % jako runtime_mismatch. Ty pak:
    #   • budou celé ŠEDÉ (LabelFormatter.format),
    #   • a půjdou ÚPLNĚ NA KONEC seznamu (finální sort key).
    #
    # Pokud WS/est_min nemá stopáž, zkusíme MI2 cache (duration_s).
    if tmdb_rt_min > 0:
        _apply_runtime_sanity(rels, [tmdb_rt_min], "tv")

    # Finální seřazení (vždy – i pro cache/pending), aby pořadí odpovídalo kvalitě.
    if rels:
        try:
            # diagnostika – kolik položek má výšku z WS / MI2
            try:
                ws_h = sum(1 for r in rels if getattr(r, "ws_height", None))
            except Exception:
                ws_h = 0
            try:
                mi2_h = 0
                for r in rels:
                    fl = _mi2_flags(getattr(r, "ident", ""))
                    vh = fl.get("video_h", None)
                    if isinstance(vh, (int, float)) and int(vh) > 0:
                        mi2_h += 1
                _log_event("FINAL_SORT_PRE", {
                    "count": len(rels),
                    "searching": bool(searching),
                    "ws_h": ws_h,
                    "mi2_h": mi2_h,
                })
            except Exception:
                pass

            # Per-title preference (audio/titulky) — preferované streamy nahoru.
            # Stejná logika jako auto-next-up (_pick_best_release). pref=None → beze změny.
            _tv_pref = _lookup_title_pref(tv_id=tv_id)
            try:
                if _tv_pref:
                    _log_event("STREAM_PREF", {"tv_id": tv_id, "pref": _tv_pref})
            except Exception:
                pass
            # 3.5.151 (Φ3c): verze minulého dílu — stejná logika jako autoplay (`_release_sort_key`)
            _tv_cont = None
            try:
                import richmovie_continuity as _tv_cont_mod
                _tv_cont = _tv_cont_mod.context_for_title("tv:%s" % tv_id if tv_id else None)
                if _tv_cont:
                    _log_event("STREAM_CONTINUITY", {"tv_id": tv_id, "prefer_lower": _tv_cont.get("prefer_lower"),
                                                     "profile": {k: _tv_cont["profile"].get(k) for k in
                                                                 ("codec", "height", "bitrate_bps", "ident")}})
            except Exception:
                _tv_cont = None
            # Φ-D (30.09.2026): SSOT klíč — první řádek výpisu = stream, který vybere automatické přehrání
            rels.sort(key=lambda r: _release_sort_key(r, _tv_pref, _tv_cont))



        except Exception as _e:
            try:
                _log_event("FINAL_SORT_ERR", str(_e))
            except Exception:
                pass

        # do disk-cache uložíme už seřazené pořadí (pouze při searching),
        # aby NextUp/pending dostal identické pořadí
        if searching and _ep_complete:
            try:
                _disk_nextup_cache().put(key_str, [asdict(r) for r in rels])
            except Exception as exc:
                _log(f"nextup disk cache sorted write failed: {exc}", xbmc.LOGDEBUG)

    # ── RM 4.0 new-UI picker-first: SSOT delegace na _list_releases ─────────
    # Seriálový search MUSÍ persistovat release_view.json — custom Stream-picker
    # jinak visí 75 s (jeho poll-loop čte VÝHRADNĚ tento soubor). Persist umí
    # jedině _list_releases (vnořený _rv_persist), proto delegujeme na něj se
    # seriálovým kontextem: kind/season/episode → zelená ✔, watch_events
    # telemetrie a správné Continue Watching; rm_runtimes → runtime sanity ±10 %.
    # Token (rm_token v sys.argv) páruje klik s pickerem — čte ho _list_releases.
    # GUARD: jen picker-first klik (nese rm_token). Auto-next-up (service_nextup →
    # tv_play s nav_key, BEZ tokenu) jde dál legacy directory cestou níže.
    _rv_tv_token = ""
    try:
        _rv_tv_token = (args.get("rm_token", [""])[0] or "").strip()
    except Exception:
        _rv_tv_token = ""
    if _rv_tv_token and _rm_new_ui():
        _ep_lbl = (ep_title or "").strip()
        _ep_disp = f"{tv_name} S{season_no:02d}E{ep_no:02d}"
        if _ep_lbl:
            _ep_disp += f" · {_ep_lbl}"
        _ep_det = det if isinstance(det, dict) else {}
        _ep_ctx = {
            "title": _ep_disp,
            "name": tv_name or "",
            "id": int(tv_id) if str(tv_id).isdigit() else "",
            "poster_path": _ep_det.get("poster_path") or "",
            "backdrop_path": _ep_det.get("backdrop_path") or "",
            "year": "",
            "rm_runtimes": [tmdb_rt_min] if tmdb_rt_min > 0 else [],
            "kind": "tv",
            "season": season_no,
            "episode": ep_no,
            "ep_title": ep_title or "",
            "tv_id": str(tv_id or ""),
            "tv_name": tv_name or "",
            # Episode-specific popis + náhled (z ep_cs, fallback ep_en) → picker.
            "ep_overview": ((ep_cs.get("overview") if isinstance(ep_cs, dict) else "")
                            or (ep_en.get("overview") if isinstance(ep_en, dict) else "") or ""),
            "ep_still": ((ep_cs.get("still_path") if isinstance(ep_cs, dict) else "")
                         or (ep_en.get("still_path") if isinstance(ep_en, dict) else "") or ""),
        }
        # _list_releases zvládne i prázdný rels (persistuje status="empty" →
        # picker ukáže branded prázdný stav místo timeoutu). SkTorrent fallback
        # pro seriály v novém pickeru = vědomý follow-up (paritní s filmy).
        _list_releases(rels, movie=_ep_ctx)
        return

    # 7) --- GUI VÝPIS ------------------------------------------------
    if not rels:
        # SkTorrent fallback (WS+FS prazdne pro TV epizodu)
        _skt_q = f"{tv_name} s{season_no:02d}e{ep_no:02d}"
        _skt_poster = ""
        _skt_fanart = ""
        _skt_overview = ""
        if det and isinstance(det, dict):
            if det.get("poster_path"):
                _skt_poster = f"https://image.tmdb.org/t/p/w342{det['poster_path']}"
            if det.get("backdrop_path"):
                _skt_fanart = f"https://image.tmdb.org/t/p/w1280{det['backdrop_path']}"
        if ep_cs and isinstance(ep_cs, dict):
            _skt_overview = ep_cs.get("overview") or ""
        _skt_meta = {
            "poster": _skt_poster,
            "fanart": _skt_fanart,
            "overview": _skt_overview,
            "rating": None,
        }
        if _sktorrent_fallback(_skt_q, tmdb_meta=_skt_meta):
            if searching:
                try:
                    _log_search_summary([], title=tv_name)
                except Exception:
                    pass
                _log_event("SEARCH_END_SKT", tv_name, "sktorrent_fallback_tv")
                _SEARCH_LOG_PATH = ""
            xbmcplugin.setContent(HANDLE, "videos")
            mi2_refresh_call, mi2_refresh_any, _rr, _rk, _cur_key = _mi2_refresh_state(win)
            try:
                xbmcplugin.endOfDirectory(
                    HANDLE,
                    succeeded=True,
                    updateListing=bool((nextup_call if 'nextup_call' in locals() else False) or mi2_refresh_call),
                    cacheToDisc=False,
                )
            except TypeError:
                xbmcplugin.endOfDirectory(HANDLE)
            return

        _no_release_ui()
        if searching:
            # 2025-10-12 07:42 CEST (Europe/Prague) – SEARCH SUMMARY (0 položek)
            try:
                _log_search_summary([], title=tv_name)
            except Exception:
                pass
            _log_event("SEARCH_END", tv_name, 0)
            _SEARCH_LOG_PATH = ""

        # Při Next-Up volání aktualizuj listing; navíc při MI2 Container.Refresh také.
        mi2_refresh_call, mi2_refresh_any, _rr, _rk, _cur_key = _mi2_refresh_state(win)

        try:
            xbmcplugin.endOfDirectory(
                HANDLE,
                succeeded=True,
                updateListing=bool((nextup_call if 'nextup_call' in locals() else False) or mi2_refresh_call),
                cacheToDisc=False,
            )
        except TypeError:
            xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setPluginCategory(HANDLE, f"{tv_name} S{season_no:02d}E{ep_no:02d}")
    xbmcplugin.setContent(HANDLE, "videos")

    # TV artwork pro stream listing (TMDb 30-denní disk cache → instant)
    _tv_stream_art: dict[str, str] = {}
    try:
        if tv_id and str(tv_id).isdigit():
            _tmdb_key = richmovie_settings.get_tmdb_api_key()
            if _tmdb_key:
                _tv_det = TMDb(_tmdb_key, lang="cs-CZ").tv_details(int(tv_id)) or {}
                _pp = _tv_det.get("poster_path") or ""
                _bp = _tv_det.get("backdrop_path") or ""
                if _pp:
                    _tv_stream_art["poster"] = f"https://image.tmdb.org/t/p/w342{_pp}"
                    _tv_stream_art["thumb"]  = f"https://image.tmdb.org/t/p/w185{_pp}"
                if _bp:
                    _tv_stream_art["fanart"] = f"https://image.tmdb.org/t/p/original{_bp}"
    except Exception:
        pass

    # 3.5.129: Free účet → Webshare položky označit a zařadit za Fastshare (jen pořadí).
    _ws_blk = _ws_playback_blocked()
    rels = _order_ws_blocked_last(rels, _ws_blk)
    rels = _order_dv_unplayable_last(rels)   # noc 03.11.2026 (Φ3): DV bez kompatibilní vrstvy za hratelné
    _broken = _broken_sources()
    rels = _order_broken_last(rels, _broken)
    _publish_top_marker(rels)   # Φ5A (D3): závěrečný refresh MI2 jen při neúplné první obrazovce
    # Beta.7 (2026-04-25): tabular alignment — viz _list_releases dál.
    _has_fs = any(getattr(r, "source", "webshare") == "fastshare" for r in rels)
    _max_qual_w, _max_size_w = _column_widths(rels)
    # 4.0.3 (A5/A6): postup PROFILU u tohoto dílu (kterékoli zařízení) — stream, na kterém se skončilo, dostane
    # značku; všechny streamy dílu nesou revizi postupu (Kodi nenajde vlastní záložku → žádný druhý dialog)
    try:
        _ep_progress = (_hist_module.progress_for_series(int(tv_id)).get((int(season_no), int(ep_no)))
                        if str(tv_id).isdigit() else None)
    except Exception:
        _ep_progress = None

    for r in rels:
        url, li, _ = _build_stream_li(
            r,
            show_source_prefix=_has_fs,
            quality_pad_width=_max_qual_w,
            size_pad_width=_max_size_w,
            ws_blocked=_ws_blk,
            broken=_broken,
        )

        li.setInfo(
            "video",
            {
                "title":        ep_title or li.getLabel(),
                "tvshowtitle":  tv_name,
                "season":       season_no,
                "episode":      ep_no,
                "mediatype":    "episode",
            },
        )
        if _tv_stream_art:
            li.setArt(_tv_stream_art)
        li.setProperty("IsPlayable", "true")

        # Přesměruj na play s TV kontextem (POZOR: správný klíč je 'ident')
        # — Fastshare integrace (21.01.2026) —
        play_params: dict[str, str] = _rm_play_params.for_release(r, episode={
            "tv_id": tv_id, "tv_name": tv_name, "season": season_no, "episode": ep_no, "ep_title": ep_title,
        })
        _stream_progress_decorate(li, play_params, _ep_progress, str(r.ident))

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(**play_params),
            li,
            isFolder=False,
        )

    # 24-08-2025 20:17 CEST (Europe/Prague) – Next-Up handshake: Container.Update(..., replace)
    # DŮLEŽITÉ: Sem jsme se dostali přes Container.Update(), tudíž je NUTNÉ
    # volat endOfDirectory(updateListing=True), jinak se obsah okna NEPŘEKRESLÍ.
    # (Dříve tu bylo `updateListing = (not nextup_call)` → vedlo to k "prázdnému" GUI.)
    nextup_call = bool(expected_key and nav_key and (nav_key == expected_key))

    # Před samotným ukončením listingů krátce počkej na uvolnění navigace + 0,5 s rezerva.
    # (Jde jen o Next-Up; pro běžné výpisy nic nečekáme.)
    try:
        _await_nav_idle(expected_key, nav_key)
    except Exception:
        pass

    # FIX 21.02.2026: endOfDirectory NEJDŘÍVE, listing.ready AŽ POTOM (race condition fix)
    mi2_refresh_call, mi2_refresh_any, _rr, _rk, _cur_key = _mi2_refresh_state(win)

    try:
        xbmcplugin.endOfDirectory(
            HANDLE,
            succeeded=True,
            # 3.5.153: `mi2_refresh_call` (marker patří TOMUTO listingu), nikdy `_any`.
            # Cizí marker nesmí z čerstvé navigace udělat in-place update — přesně to
            # dělal rozbitý klíč (cross-check Flash D16).
            updateListing=bool(nextup_call or mi2_refresh_call),
            cacheToDisc=False,
        )
    except TypeError:
        xbmcplugin.endOfDirectory(HANDLE)

    try:
        xbmc.Monitor().waitForAbort(0.12)
    except Exception:
        pass
    try:
        xbmcgui.Window(10000).setProperty("richmovie.listing.ready", "1")
        xbmcgui.Window(10000).setProperty("richmovie.mi2.listing_ready", "1")
        xbmcgui.Window(10000).setProperty(_tv_auto_key, "1")
    except Exception:
        pass

    # ---------------------------------------------------------------------
    # MI2 UX toasty: "Analyzuji zbytek…" (po wait okně) + "Analýza dokončena"
    # ---------------------------------------------------------------------
    try:
        if toast_analyze_now:
            _rm_notif(
                "Analyzuji zbytek streamů, jestli nemají náhodou dabing a české titulky…",
                xbmcgui.NOTIFICATION_INFO,
                3000,
                "RichMovie",
            )
    except Exception:
        pass

    try:
        analyze_for = (win.getProperty("richmovie.mi2.toast.analyze_for") or "").strip()
        done_for    = (win.getProperty("richmovie.mi2.toast.done_for") or "").strip()

        # "final refresh" marker od MI2 (nastavuje MI2 těsně před Container.Refresh)
        is_final_refresh = False
        # Klíč listingu, ne odchozí kontejner (cross-check Flash A6).
        cur_key = _rm_listing.current_listing_key()

        try:
            rr = (win.getProperty("richmovie.mi2.refresh_reason") or "").strip().lower()
            rk = (win.getProperty("richmovie.mi2.refresh_key") or "").strip()
            if rr in ("final", "deferred") and rk and cur_key and (rk == cur_key):
                is_final_refresh = True
        except Exception:
            is_final_refresh = False

        # marker smažeme (ať nezůstane viset mezi view) – BEST EFFORT i při key mismatch
        # Důvod: v praxi se může stát rk != cur_key (např. tv_episodes vs tv_play), a marker by jinak visel napříč view.
        try:
            rk2 = (win.getProperty("richmovie.mi2.refresh_key") or "").strip()
            rr2 = (win.getProperty("richmovie.mi2.refresh_reason") or "").strip().lower()

            # SSOT úklidu markeru (audit Fable P1 #5): dřív tu byl ručně psaný
            # žebříček podmínek VČETNĚ vlastní kopie `targets_match` — a totéž
            # o dvě obrazovky dál. Sémantika beze změny: marker se po renderu
            # vždycky uklidí, ať mířil kamkoli; jen se rozliší log.
            if _rm_listing.marker_present(rr2, rk2):
                _mine = bool(cur_key and (_rm_listing.canon_key(rk2) == _rm_listing.canon_key(cur_key)
                                          or _rm_listing.targets_match(rk2, cur_key)))
                try:
                    _log_event(
                        "MI2_REFRESH_MARKER_CLEAR_MATCH" if _mine else "MI2_REFRESH_MARKER_CLEAR_FORCED",
                        {"rr": rr2 or None, "rk": rk2 or None, "cur_key": cur_key or None},
                    )
                except Exception:
                    pass
                win.clearProperty("richmovie.mi2.refresh_reason")
                win.clearProperty("richmovie.mi2.refresh_key")
        except Exception:
            pass


        if analyze_for == key_str and done_for != key_str:
            # done ukážeme buď na MI2 finálním refreshi, nebo když už MI2 neběží
            if is_final_refresh or (not _mi2_is_running_here()):
                win.setProperty("richmovie.mi2.toast.done_for", key_str)
                _rm_notif("Analýza dokončena.", xbmcgui.NOTIFICATION_INFO, 2500, "RichMovie")
    except Exception:
        pass

    # Volitelná zpětná vazba pro uživatele – pouze při Next-Up listingu:
    if nextup_call:
        try:
            _rm_notif("Zobrazeny streamy pro další díl", xbmcgui.NOTIFICATION_INFO, 2500, "RichMovie")
        except Exception:
            pass

    if searching:
        # Φ5A: enrich jako měření až po vykreslení, jen první obrazovka (SSOT `_after_render_enrich`)
        _after_render_enrich(rels, tv_name)
        _log_event("SEARCH_END", tv_name, len(rels))
        _SEARCH_LOG_PATH = ""









# ---------------------------------- METODA ---------------------------------- #
# plugin.py › _ws_search (upraveno: 14.12.2025 17:40 CET (Europe/Prague) – WS: používá _list_releases (MI2 wait + toasty + sort) místo ručního výpisu)
# ---------------------------------------------------------------------------- #
def _ws_search(term: str | None = None) -> None:
    """
    14.12.2025 17:40 CET (Europe/Prague)

    Rychlé vyhledání jen na Webshare (bez TMDb).

    • Každý dotaz má vlastní .log soubor
    • Přímý WS+FS search s ReleaseFilter.enrich() (bez agresivního title filtering)

    NOVĚ:
      • GUI výpis jde přes `_list_releases(rels)` (stejná logika jako u seriálů/filmů:
        MI2 wait window + background refresh + toasty + finální řazení + konzistentní labely).
      • Best-effort doplním `_ws_fileinfo_enrich(rels)` i při úspěchu (pomáhá quality/len heuristikám).
    """
    # ── 1) Vstup --------------------------------------------------------
    if not term:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        term = (args.get("q", [""])[0] or "").strip()
        if not term:
            term = _keyboard_input("Hledat na Webshare")
            if not term:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                return
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            xbmc.executebuiltin("Container.Update(%s,replace)" % _url(action="ws_search", q=term))
            return
    term = term.strip()
    _add_to_history(term, category="ws")

    # ── 2) PER-SEARCH LOG ----------------------------------------------
    global _SEARCH_LOG_PATH
    log_dir = xbmcvfs.translatePath("special://logpath/richmovie/")
    if not xbmcvfs.exists(log_dir):
        xbmcvfs.mkdirs(log_dir)

    ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    safe = re.sub(r"[^0-9A-Za-z]+", "_", term)[:50]
    _SEARCH_LOG_PATH = os.path.join(log_dir, f"{ts}_{safe}.log")
    _log_event("SEARCH_BEGIN", term)

    # ── 3) Vyhledání (raw – přímý WS+FS search bez title filtering) -----
    # S31 (08.11.2026): stahování TOUTÉŽ cestou jako vlny hledání (`_ENGINE.fetch_raw`) — výpadek Webshare už
    # nepřeskočí Fastshare; limit `MAX_WS_RESULTS` platí pro každý zdroj zvlášť jako dřív
    rels: list[Release] = []
    ws_fetch = None
    try:
        cli = _client()
        _ensure_login(cli, interactive=True)
        ws_fetch = _ENGINE.fetch_raw(term, cap=MAX_WS_RESULTS)
        if isinstance(ws_fetch.ws_exc, TokenExpired):
            # vypršelé přihlášení Webshare → znovu přihlásit a stáhnout znovu (dřívější větev `except TokenExpired`)
            try:
                _ensure_login(cli, interactive=True)
                ws_fetch = _ENGINE.fetch_raw(term, cap=MAX_WS_RESULTS)
            except Exception as e2:
                _net_error_ui(e2, heading="Přihlášení k Webshare")
                _log_event("SEARCH_END", term, "TOKEN_RETRY_FAIL")
                _SEARCH_LOG_PATH = ""
                return
        merged = ws_fetch.items          # každý zdroj oříznutý na `MAX_WS_RESULTS` PŘED odstraněním duplicit

        # Základní enrichment (přípona, velikost, metadata) – bez title filtering
        for itm in merged:
            r = ReleaseFilter.enrich(itm)
            if r:
                rels.append(r)
    except APIError as e:
        _net_error_ui(e, heading="Webshare")
        _log_event("SEARCH_END", term, "ERR")
        _SEARCH_LOG_PATH = ""
        return
    except Exception as e:
        _net_error_ui(e, heading="Vyhledávání")
        _log_event("SEARCH_END", term, "ERR")
        _SEARCH_LOG_PATH = ""
        return

    # ── 3b) enrich `/file_info` se od Φ5A (29.09.2026) dělá až PO vykreslení a jen jako měření
    #       (`_after_render_enrich`, audit A06 R04) — řazení i odznaky jedou z polí `/search`.

    # ── 3b2) RELEVANCE k termínu (P2 #11, analýza H2 „Hawking") ---------
    # Ruční WS hledání nemá TMDb → žádný match signál → finální řazení
    # degeneruje na velikost a cizí velký soubor (Taking Lives 2601 MB) se
    # dostane NAD přesný zásah (Hawking 1449 MB). Spočítáme relevanci =
    # počet obsahových term-tokenů CHYBĚJÍCÍCH v názvu (0 = úplný zásah).
    # Roky a <2 znaky ignorujeme (slabý/šumový signál). ws_rel se pak řadí
    # PŘED velikostí (viz _rv_final_sort). Best-effort — chyba → beze změny.
    try:
        _term_toks = [
            t for t in _norm(term).split()
            if t and len(t) >= 2 and not (t.isdigit() and len(t) == 4)
        ]
        if _term_toks:
            for _r in rels:
                _nm_toks = set(_norm(_r.name).split())
                _r.ws_rel = sum(1 for t in _term_toks if t not in _nm_toks)
    except Exception:
        pass

    # S31: Webshare v tomto hledání selhal → pravdivá věta; KDY rozhoduje tatáž funkce jako u vln hledání
    _ws_down = False
    if ws_fetch is not None and ws_fetch.ws_error:
        import richmovie_feedback as _fb_ws
        _sd_code = _rm_stel.source_down_code(
            ws_outage=ws_fetch.ws_error in _rm_stel.OUTAGE_KINDS, ws_pages_ok=int(ws_fetch.ws_pages),
            fs_ok=bool(ws_fetch.fs_calls and not ws_fetch.fs_error), have_results=bool(rels))
        if _sd_code:
            _ws_down = True
            _fb_ws.warn(_fb_ws.SOURCE_DOWN_TEXTS[_sd_code], heading="Hledání")
            _log_event("SOURCE_DOWN_NOTICE", "ws", _sd_code)
        elif not rels:
            # Webshare odpověděl chybou (429, API) a nic jiného není → dřívější věta podle třídy chyby
            _ws_down = True
            _net_error_ui(ws_fetch.ws_exc or APIError("Síťová chyba"), heading="Webshare")

    # ── 3c) Nic nenalezeno ---------------------------------------------
    if not rels:
        if not _ws_down:
            _modal("Nic nenalezeno.")
        # 2025-10-12 08:54 CEST (Europe/Prague) – WS FILE_INFO ENRICH + SEARCH SUMMARY
        try:
            _log_search_summary(rels, title=term)
        except Exception:
            pass
        _log_event("SEARCH_END", term, len(rels))
        _SEARCH_LOG_PATH = ""
        return

    # ── 4) GUI ---------------------------------------------------------
    # Důležité: výpis jde přes _list_releases(), aby se použila stejná MI2 logika
    # jako u seriálů (wait window, background refresh + toasty, finální sort, labely).
    _list_releases(rels)

    # ── 5) END + reset cesty -------------------------------------------
    _after_render_enrich(rels, term)
    _log_event("SEARCH_END", term, len(rels))

    _SEARCH_LOG_PATH = ""





# 2025-08-22 11:20 CEST (Europe/Prague)
def _music_search(term: str | None = None) -> None:
    """
    Jednoduché vyhledávání hudby (mp3/flac) na Webshare s přísným AND‑filtrem.

    • Vstup: jedno řádkové pole "Zadej název interpreta a název skladby"
      (neřešíme tečky, čárky, diakritiku – přesně jako u filmů; použijeme `_norm`)
    • Do GUI propouštíme pouze soubory s příponou **.mp3** nebo **.flac**,
      jejichž **název obsahuje všechna zadaná slova** (po normalizaci).
    • Výsledky seřadíme **od největšího po nejmenší** podle velikosti.
    • Klik na položku → jednoduchý dialog: [Přehrát] nebo [Stáhnout].

    Pozn.: Používáme přihlášeného klienta ze _SESSION; streamování probíhá
    přímo přes přímý odkaz z Webshare (bez resolveru). Stahování recykluje
    existující `start_download_from_gui()` – není potřeba nic měnit.
    """
    try:
        # 1) Vstup (z URL `q` nebo interaktivně)
        if not term:
            args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
            term = (args.get("q", [""])[0] or "").strip()
            if not term:
                term = _keyboard_input("Zadej název interpreta a název skladby")
                if not term:
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=False); return
                # Φ7-fix (re-audit R3-P1-6): v custom UI Container.Update
                # renderuje NEVIDITELNĚ (RunPlugin invoker nemá container) —
                # položka „Vyhledat hudbu" byla po migraci _streaming_home
                # mrtvý klik. Custom → přímá rekurze (RmDir níže otevře list
                # okno); legacy → původní redirect (directory sémantika).
                import richmovie_rmdir as _rmdir_ms
                if _rmdir_ms.is_custom_ui():
                    _music_search(term)
                    return
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
                xbmc.executebuiltin("Container.Update(%s,replace)" % _url(action="music_search", q=term))
                return

        _add_to_history(term, category="other")   # nechceme měnit strukturu historie

        # Φ7-fix (R3-P1-6): RmDir sink — custom UI otevře list okno, legacy 1:1
        import richmovie_rmdir
        rmdir = richmovie_rmdir.RmDir(HANDLE, f"Vyhledat hudbu – {term}")

        # 2) Připrav normalizované tokeny (přísný AND)
        q_norm = _norm(term)
        want   = [t for t in q_norm.split() if t]
        if not want:
            _modal("Zadejte prosím aspoň jedno slovo.")
            rmdir.finish(succeeded=False); return

        # 3) Webshare → search(type='audio'), vyzobeme jen mp3/flac
        cli = _client()
        try:
            items = cli.search(term, file_type="audio")
        except TokenExpired:
            try:
                _ensure_login(cli, interactive=True)
                items = cli.search(term, file_type="audio")
            except Exception as e2:
                _net_error_ui(e2, heading="Přihlášení k Webshare")
                rmdir.finish(succeeded=False); return
        if not items:
            _modal("Nic nenalezeno.")
            rmdir.finish(succeeded=False); return

        allowed_ext = {'.mp3', '.flac'}
        def _ext(name: str) -> str:
            import os as _os
            return _os.path.splitext(name)[1].lower()

        def _match(name: str) -> bool:
            n = _norm(name)
            return all(t in n for t in want)

        cand = [it for it in items if _ext(it.get("name","")) in allowed_ext and _match(it.get("name",""))]
        if not cand:
            _modal("Nic nenalezeno.")
            rmdir.finish(succeeded=False); return

        # 4) řazení podle velikosti (desc)
        cand.sort(key=lambda d: int(d.get("size", 0) or 0), reverse=True)

        # 5) GUI – výpis písniček
        xbmcplugin.setPluginCategory(HANDLE, f"Vyhledat hudbu – {term}")
        xbmcplugin.setContent(HANDLE, "songs")

        def _fmt_bytes(n: int) -> str:
            # mini helper (neměň globální util v richmovie_downloads)
            try: n = int(n)
            except Exception: n = 0
            if n < 1024: return f"{n} B"
            if n < 1024**2: return f"{n/1024:.1f} kB"
            if n < 1024**3: return f"{n/1024/1024:.1f} MB"
            return f"{n/1024/1024/1024:.2f} GB"

        for it in cand:
            ident = it.get("ident", "")
            name  = it.get("name", "")
            size  = int(it.get("size", 0) or 0)

            label = f"🎵 {name}  [{_fmt_bytes(size)}]"
            li = xbmcgui.ListItem(label)
            li.setInfo("music", {"title": name})
            li.setProperty("isPlayable", "true")   # aby šlo přehrát i enterem přes ?action=music_item
            url = _url(action="music_item", ident=ident, name=quote_plus(name))
            rmdir.add(url, li, isFolder=False)

        rmdir.finish()

    except Exception as e:
        _log(f"_music_search() ERR: {e}", xbmc.LOGERROR)
        _net_error_ui(e, heading="RichMovie")






# 2025-08-22 11:20 CEST (Europe/Prague)
def _music_item() -> None:
    """
    Akce po kliku na hudební položku: dotáže se, zda **Přehrát** nebo **Stáhnout**.

    • `?action=music_item&ident=…&name=…`
    • Přehrát → `_music_play()` (přímý link z Webshare)
    • Stáhnout → `start_download_from_gui()` (existující downloader)
    """
    try:
        args = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
        ident = (args.get("ident", [""])[0] or "").strip()
        raw   = (args.get("name",  [""])[0] or "").strip()
        try:
            name = urllib.parse.unquote_plus(raw)
        except Exception:
            name = raw
        if not ident:
            _modal("Chybí ident streamu.");  return

        idx = xbmcgui.Dialog().select("Vyberte akci", ["Přehrát", "Stáhnout"])
        if idx < 0:
            return
        if idx == 0:
            _music_play(ident, name)
        else:
            try:
                from richmovie_downloads import start_download_from_gui  # lazy import
                start_download_from_gui(ident, name)
            except Exception as run_err:
                _net_error_ui(run_err, heading="Stahování")

    except Exception as e:
        _log(f"_music_item() ERR: {e}", xbmc.LOGERROR)
        _net_error_ui(e, heading="RichMovie")







# 2025-08-22 11:20 CEST (Europe/Prague)
def _music_play(ident: str, name: str = "") -> None:
    """
    Přehrání hudebního souboru (MP3/FLAC) přes přímý HTTP odkaz.

    • Získá se URL přes `WebshareClient.file_link(ident, download_type=None)`
    • Kodi si s MP3/FLAC poradí nativně – stačí `setResolvedUrl()`
    """
    try:
        cli = _client()
        try:
            url = cli.file_link(ident, download_type=None)
        except TokenExpired:
            try:
                _ensure_login(cli, interactive=True)
                url = cli.file_link(ident, download_type=None)
            except Exception as e2:
                _net_error_ui(e2, heading="Přihlášení k Webshare"); return
        except Exception as e:
            _net_error_ui(e, heading="Přehrání"); return

        li = xbmcgui.ListItem(label=name or "Hudební soubor")
        li.setInfo("music", {"title": name or "Audio"})
        li.setProperty("IsPlayable", "true")
        li.setPath(url)
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        _log_event("PLAY_MUSIC", ident, name)

    except Exception as e:
        _log(f"_music_play() ERR: {e}", xbmc.LOGERROR)
        _net_error_ui(e, heading="RichMovie")







# 2025-08-14 19:22 CEST (Europe/Prague) – _play(): zachována původní logika přehrání + doplněn zápis do "Historie sledování" (filmy / epizody)
# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _mi2_mark_not_media  (vytvořeno: 02.09.2026 22:10 CEST, Europe/Prague – 3.5.129)
# ---------------------------------------------------------------------------- #
def _mi2_mark_not_media(ident: str, check: dict) -> None:
    """Lokální negativní marker MI2 pro odkaz, který ze zařízení nevydal médium.

    Politika `not_media` (richmovie_engine._MI2_RETRY_POLICY): 1 h → 2 h → … →
    týdenní opakování, nikdy permanentní — po obnovení VIP soubor hraje. Jen
    lokální disk cache; sdílená cache na Gate nic takového nepřijme. Best-effort.
    """
    try:
        import richmovie_engine as _eng_mod
        from richmovie_mi2 import FAIL_REASON_NOT_MEDIA as _reason
        _eng_mod.mi2_publish(
            ident, fail_reason=_reason,
            fail_detail="linkcheck status=%s ct=%s host=%s" % (
                check.get("status"), check.get("content_type") or "-", check.get("host") or "-"),
        )
        _eng_mod.mi2_flush_disk(force=True)
    except Exception as exc:
        _log(f"mi2 not_media marker failed ident={ident}: {exc!r}", xbmc.LOGWARNING)


# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _resolve_webshare_stream  (vytvořeno: 02.09.2026 22:10 CEST, Europe/Prague – 3.5.129;
#                            03.09.2026 přesun logiky do richmovie_webshare, Fable audit F-07)
# ---------------------------------------------------------------------------- #
@_rm_bc.timed_step("ws_resolve", fields=lambda _i, fallback_list, *_a, **_kw: {
    "fallbacks": len(fallback_list or [])})
def _resolve_webshare_stream(ident: str, fallback_list: List[str],
                             interactive: bool = True) -> Dict[str, Any]:
    """Tenký wrapper nad `richmovie_webshare.resolve_playable_stream` — logika
    (Free brána, kontrola odkazu, fallback identy, hlášky) žije v modulu Webshare,
    aby byla testovatelná bez Kodi (harness scénář 49). Sem patří jen injekce
    závislostí z pluginu: klient, login (interaktivní jen mimo autoplay), MI2
    marker, logger."""
    import richmovie_account_state as _account
    import richmovie_webshare as _ws_mod
    return _ws_mod.resolve_playable_stream(
        _client(), ident, fallback_list,
        # TokenExpired = autoritativní SESSION_EXPIRED → `relogin` (token pryč, tichý
        # login z údajů, dialog jen když `inter`) — ne `_ensure_login`, který platný-
        # vypadající token jen znovu nasadí a nikdy nepřihlásí (Fable audit N1).
        ensure_login=lambda cli, inter: _SESSION.relogin(interactive=inter),
        mark_not_media=_mi2_mark_not_media,
        log=_log,
        net_error_message=_net_error_message,
        account_state=_account,
        interactive=interactive,
    )


# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _play  (vytvořeno: 29.09.2026 15:02 CEST, Europe/Prague — obal pojistky jednoho startu, Φ1)
# ---------------------------------------------------------------------------- #
def _play(ident: str, args: Optional[dict] = None) -> None:
    """JEDINÝ vstup do resolve přehrávání (akce `play`, `cw_play`).

    Φ1 (29.09.2026, pád Kodi 21.2 „two concurrent busydialogs“): převezme odeslaný start
    (`richmovie_playback_dispatch.request`) nebo claimne vlastní (ruční klik na stream). Když jiný start
    ještě běží (resolve / otevírání), skončí `setResolvedUrl(False)` bez práce — druhé přehrání by se
    jinak rozjelo souběžně. Ve `finally` uvolní claim, pokud resolve neskončil úspěchem; po úspěchu ho
    drží stav OTEVÍRÁNÍ, který uvolní služba (AVStarted / chyba).
    `args` = parametry přehrání ve tvaru `parse_qs` (Pokračovat je předává ve stejné invokaci);
    None = parametry této invokace z `sys.argv`.
    """
    _args = args if args is not None else (dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {})
    _is_auto = (_args.get("autoplay", [""])[0] or "").strip() == "1"
    token = _rm_dispatch.begin_resolve(ident, source="autoplay" if _is_auto else "click")
    if token is None:
        # Jiné spouštění běží — tohle se nerozjede (žádné druhé přehrání, žádný vnořený resolve).
        if not _is_auto:
            _rm_dispatch.notify_busy()
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    try:
        _play_resolve(ident, _args, token)
    finally:
        _rm_dispatch.end_resolve(token)


def _play_resolve(ident: str, args: dict, dispatch_token: Optional[str] = None) -> None:
    # 3.5.119 (audit #4 + Pro kolo 2 #3): požadavek na navázání převzít a SMAZAT hned na
    # vstupu, ne až po resolve — jinak by po selhaném resolve seekl příští nesouvisející
    # přehrávání. Adresát (ident) nesedí → zahodit. 3.5.151: SSOT `richmovie_resume`
    # (producenti: klik na Pokračovat, auto-resume po utnutí, obnova mrtvého zdroje).
    try:
        import richmovie_resume as _rm_resume
        _resume_req = _rm_resume.consume_request(ident)
    except Exception as _rr_exc:
        _log(f"RESUME request read failed: {_rr_exc!r}", xbmc.LOGWARNING)
        _rm_resume = None
        _resume_req = None
    """
    Přehrání souboru z Webshare se zachováním původní logiky:
      • získání přímého odkazu přes Webshare API,
      • sestavení ListItem včetně InfoTagů (title/year pro filmy; tvshow/season/episode pro epizody),
      • předání délky videa (pokud je k dispozici) do InfoTagů a property "richmovie.duration",
      • volání xbmcplugin.setResolvedUrl(HANDLE, True, li).

    NOVĚ:
      • Po úspěšném setResolvedUrl() zapíšu záznam do "Historie sledování":
          – FILM  → _watch_add_movie(tmdb_id, title, year)
          – EPIZODA → _watch_add_episode(tv_id, tv_name, season, episode, ep_title)

    Vstupní parametry z query (jsou volitelné; pokud chybí, historie se prostě nezapíše):
      • Filmy:  m_title, m_year, tmdb
      • Seriály: tv_id, tv_name, season, episode, ep_title
    """
    # ──────────────────────────────────────────────────────────────────────
    # 1) PARAMS Z URL (bezpečně a tolerantně)
    # ──────────────────────────────────────────────────────────────────────
    # Φ1: parametry předává obal `_play` (z `sys.argv`, nebo z položky Pokračovat ve stejné invokaci)

    # TV kontext
    tv_name   = (args.get("tv_name", [""])[0] or "").strip()
    season_no = 0
    episode_no = 0
    try:
        season_no  = int((args.get("season")  or ["0"])[0])
        episode_no = int((args.get("episode") or ["0"])[0])
    except Exception:
        season_no = episode_no = 0
    ep_title = (args.get("ep_title", [""])[0] or "").strip()
    tv_id    = args.get("tv_id", [""])[0]

    # Movie kontext
    m_title = (args.get("m_title", [""])[0] or "").strip()
    try:
        m_year = int((args.get("m_year") or ["0"])[0])
    except Exception:
        m_year = 0
    try:
        m_tmdb = int((args.get("tmdb") or ["0"])[0])
    except Exception:
        m_tmdb = 0

    # 3.5.151 (cross-check Flash F1): požadavek bez adresáta (picker-first Pokračovat) patří jen
    # TÉMUŽ titulu — jiný titul spuštěný po zrušeném výběru nesmí převzít cizí pozici.
    if _resume_req is not None and _rm_resume is not None:
        if tv_name and season_no and episode_no and str(tv_id).isdigit():
            _play_key = "tv:%d:%d:%d" % (int(tv_id), season_no, episode_no)
        elif m_tmdb:
            _play_key = "movie:%d:0:0" % int(m_tmdb)
        else:
            _play_key = ""
        if not _rm_resume.request_matches_key(_resume_req, _play_key):
            _log(f"RESUME_SKIP: pozice patří titulu {_resume_req.get('key')}, hraje se {_play_key}",
                 xbmc.LOGINFO)
            _resume_req = None

    # Φ6 (A05 R4): přímé spuštění bez převzaté pozice → dotaz na Gate (novější pozice z jiného zařízení)
    # běží od teď souběžně s resolve; převezme se až před `prepare_resolved_item` (Φ5 níže).
    _remote_lookup = None
    if _resume_req is None and _rm_resume is not None:
        if tv_name and season_no and episode_no and str(tv_id).isdigit():
            _direct_item = {"type": "episode", "tv_id": int(tv_id), "season": int(season_no),
                            "episode": int(episode_no)}
        elif m_tmdb and str(m_tmdb).isdigit():
            _direct_item = {"type": "movie", "tmdb_id": int(m_tmdb)}
        else:
            _direct_item = None
        if _direct_item is not None:
            try:
                _remote_lookup = _RemoteResumeLookup(_direct_item)
            except Exception as _rl_exc:
                _log(f"direct remote resume lookup not started: {_rl_exc!r}", xbmc.LOGDEBUG)

    _req_ident = ident     # Φ-A: ident, na který se kliklo (resolve ho může nahradit záložním)

    # — Fastshare kontext (21.01.2026) —
    source = (args.get("source", ["webshare"])[0] or "webshare").strip().lower()
    fs_url = (args.get("fs_url", [""])[0] or "").strip()
    fs_hash = (args.get("fs_hash", [""])[0] or "").strip()

    # ──────────────────────────────────────────────────────────────────────
    # 2) VYŽÁDÁNÍ ODKAZU – Webshare nebo Fastshare (21.01.2026)
    # ──────────────────────────────────────────────────────────────────────
    url: str = ""
    vid_len: int = 0
    finfo: dict = {}   # Webshare file_info (size/video_length) — Fastshare ho nemá

    if source == "fastshare" and fs_url and fs_hash:
        # Fastshare přehrávání – URL s cookie + User-Agent
        # 22.01.2026 – debug logy pro měření času + User-Agent pro kompatibilitu
        import time as _time_play
        _t0_fs = _time_play.time()
        _log(f"[Fastshare] PLAY_START t={_t0_fs:.3f}", xbmc.LOGINFO)
        try:
            cookie = urllib.parse.quote_plus(f"FASTSHARE={fs_hash}")
            user_agent = urllib.parse.quote_plus("Kodi/21.0 (RichMovie Fastshare)")
            # Kodi formát: url|Header1=Value1&Header2=Value2
            url = f"{fs_url}|Cookie={cookie}&User-Agent={user_agent}"
            vid_len = 0  # Fastshare neposkytuje délku v API
            _log(f"[Fastshare] PLAY_URL_BUILT dt={_time_play.time()-_t0_fs:.3f}s url={fs_url[:60]}...", xbmc.LOGINFO)
        except Exception as e:
            _log(f"[Fastshare] PLAY_ERROR dt={_time_play.time()-_t0_fs:.3f}s err={e}", xbmc.LOGERROR)
            # Technický text zůstává v logu; do UI česká věta (Fable audit F-13).
            _fs_why, _fs_transient = _net_error_message(e)
            _modal(_fs_why, "Fastshare")
            _rm_play_failed_return()  # Φ2: návrat do RM UI (stack je složený)
            return
    else:
        # Webshare přehrávání — 3.5.129 (incident PeterFM 02.09.2026): rozhodnutí
        # „smí se hrát" (Free účet) + kontrola odkazu ze zařízení + fallback identy
        # žijí v `_resolve_webshare_stream`; `_play` zůstává orchestrací.
        # Fallback identy z autoplay URL (seřazené dle kvality/velikosti)
        fallback_raw = (args.get("fallback", [""])[0] or "").strip()
        fallback_list = [x for x in fallback_raw.split(",") if x] if fallback_raw else []
        # 3.5.130: `autoplay=1` = spustila služba (Next-Up) bez uživatele → žádný
        # interaktivní login ani modální dialog; jen notifikace + log.
        _is_autoplay = (args.get("autoplay", [""])[0] or "").strip() == "1"

        resolved_ws = _resolve_webshare_stream(ident, fallback_list, interactive=not _is_autoplay)
        if not resolved_ws.get("ok"):
            _is_reconnect = bool(_resume_req and _rm_resume is not None
                                 and _resume_req.get("source") == _rm_resume.SOURCE_RECONNECT)
            if _is_reconnect:
                # 3.5.151 (Φ3b): obnova spojení za běhu — starý stream pořád hraje z bufferu.
                # Kodi s `setResolvedUrl(False)` přehrávač nezmění; návrat do RM UI by jen
                # otevřel okna přes běžící video.
                _log(f"RECONNECT_RESOLVE_FAILED ident={ident}: {resolved_ws.get('message')!r}",
                     xbmc.LOGWARNING)
                _notif("Spojení se zdrojem zatím nejde obnovit, hraju z vyrovnávací paměti.",
                       xbmcgui.NOTIFICATION_WARNING, 5000, "RichMovie")
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return
            if _is_autoplay and _resume_req and _rm_resume is not None \
                    and _resume_req.get("source") == _rm_resume.SOURCE_AUTO_RESUME:
                # 3.5.151: navázání TÉHOŽ dílu, ne další díl — pravdivá hláška, pozice je v Pokračovat
                _notif("Navázání se nepodařilo – pozice %s je v Pokračovat."
                       % _rm_resume.format_time(_resume_req.get("position")),
                       xbmcgui.NOTIFICATION_WARNING, 6000, "RichMovie")
            elif _is_autoplay:
                _notif(resolved_ws.get("message") or "Další díl se nepodařilo přehrát.",
                       xbmcgui.NOTIFICATION_WARNING, 6000,
                       resolved_ws.get("heading") or "RichMovie")
            elif not resolved_ws.get("silent"):
                # `silent` = dialog už ukázal `_ensure_login` (F-04) — neopakovat.
                _modal(resolved_ws.get("message") or "Přehrání selhalo.",
                       resolved_ws.get("heading") or "RichMovie")
            _rm_play_failed_return()  # Φ2: návrat do RM UI (stack je složený)
            # Kodi musí dostat výsledek, jinak po skončení skriptu ukáže vlastní
            # „Přehrávání selhalo" nad naším dialogem (parita s `_local_play`).
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        url = resolved_ws["url"]
        finfo = resolved_ws["finfo"]
        vid_len = int(resolved_ws.get("vid_len") or 0)  # v sekundách (0, pokud chybí)
        ident = resolved_ws["ident"]

    # ──────────────────────────────────────────────────────────────────────
    # 3) SESTAVENÍ ListItem + INFOTAGY (ZACHOVÁNO)
    # ──────────────────────────────────────────────────────────────────────
    li = xbmcgui.ListItem(path=url)

    # 20.02.2026 – Fastshare: download.php neodpovídá na HEAD requesty,
    # Kodi Stat proto 2× timeoutuje (~40 s).  setContentLookup(False) přeskočí
    # Stat a otevře stream rovnou.
    if source == "fastshare":
        li.setContentLookup(False)

    info_tags: Dict[str, Any] = {}
    play_art: Dict[str, str] = {}

    if tv_name and season_no and episode_no:
        # Epizoda seriálu
        info_tags.update({
            "title":        ep_title or f"{tv_name} S{season_no:02d}E{episode_no:02d}",
            "tvshowtitle":  tv_name,
            "season":       season_no,
            "episode":      episode_no,
            "mediatype":    "episode",
        })
        # TMDb: metadata seriálu pro player overlay (poster, fanart, plot, rating)
        # Φ6 (A05 R6): JEN z diskové cache (`peek_*`, 0 HTTP) — síť před `setResolvedUrl` zdržovala start
        try:
            if tv_id and str(tv_id).isdigit():
                _tmdb_key = richmovie_settings.get_tmdb_api_key()
                if _tmdb_key:
                    _tmdb_play = TMDb(_tmdb_key, lang="cs-CZ")
                    _tv_det = _tmdb_play.peek_tv_details(int(tv_id)) or {}
                    _orig_name = (_tv_det.get("original_name") or "").strip()
                    if _orig_name:
                        info_tags["originaltitle"] = _orig_name
                    # Artwork — poster + fanart z TMDb (30-denní disk cache → instant)
                    _pp = _tv_det.get("poster_path") or ""
                    _bp = _tv_det.get("backdrop_path") or ""
                    if _pp:
                        play_art["poster"] = f"https://image.tmdb.org/t/p/w342{_pp}"
                        play_art["thumb"]  = f"https://image.tmdb.org/t/p/w185{_pp}"
                        li.setProperty("richmovie.poster_path", _pp)
                    if _bp:
                        play_art["fanart"] = f"https://image.tmdb.org/t/p/original{_bp}"
                        li.setProperty("richmovie.backdrop_path", _bp)
                    # Episode-level data (plot dílu, still obrázek, rating dílu)
                    try:
                        _ep_det = _tmdb_play.peek_episode_details(int(tv_id), season_no, episode_no) or {}
                        _ep_overview = (_ep_det.get("overview") or "").strip()
                        if _ep_overview:
                            info_tags["plot"] = _ep_overview
                        elif _tv_det.get("overview"):
                            info_tags["plot"] = _tv_det["overview"]
                        if _ep_det.get("still_path"):
                            play_art["thumb"] = f"https://image.tmdb.org/t/p/w780{_ep_det['still_path']}"
                        if _ep_det.get("vote_average"):
                            info_tags["rating"] = float(_ep_det["vote_average"])
                        if _ep_det.get("vote_count"):
                            info_tags["votes"] = int(_ep_det["vote_count"])
                        _ep_name = (_ep_det.get("name") or "").strip()
                        if _ep_name and not ep_title:
                            info_tags["title"] = _ep_name
                    except Exception:
                        # Fallback na show-level data
                        if _tv_det.get("overview"):
                            info_tags["plot"] = _tv_det["overview"]
                        if _tv_det.get("vote_average"):
                            info_tags["rating"] = float(_tv_det["vote_average"])
                        if _tv_det.get("vote_count"):
                            info_tags["votes"] = int(_tv_det["vote_count"])
        except Exception:
            pass
        # Pomocné vlastnosti pro NextUp / vlastní logiku
        li.setProperty("richmovie.tv_id",   str(tv_id))
        li.setProperty("richmovie.season",  str(season_no))
        li.setProperty("richmovie.episode", str(episode_no))
    else:
        # Film (pokud máme aspoň název)
        if m_title:
            info_tags.update({
                "title":     m_title,
                "mediatype": "movie",
            })
            if m_year:
                info_tags["year"] = m_year
        # TMDb: metadata filmu pro player overlay (poster, fanart, plot, rating)
        # Φ6 (A05 R6): JEN z diskové cache (`peek_details`, 0 HTTP)
        try:
            if m_tmdb:
                _tmdb_key = richmovie_settings.get_tmdb_api_key()
                if _tmdb_key:
                    _tmdb_play = TMDb(_tmdb_key, lang="cs-CZ")
                    _m_det = _tmdb_play.peek_details(int(m_tmdb)) or {}
                    _orig_title = (_m_det.get("original_title") or "").strip()
                    if _orig_title:
                        info_tags["originaltitle"] = _orig_title
                    # Artwork — poster + fanart z TMDb (30-denní disk cache → instant)
                    _pp = _m_det.get("poster_path") or ""
                    _bp = _m_det.get("backdrop_path") or ""
                    if _pp:
                        play_art["poster"] = f"https://image.tmdb.org/t/p/w342{_pp}"
                        play_art["thumb"]  = f"https://image.tmdb.org/t/p/w185{_pp}"
                        li.setProperty("richmovie.poster_path", _pp)
                    if _bp:
                        play_art["fanart"] = f"https://image.tmdb.org/t/p/original{_bp}"
                        li.setProperty("richmovie.backdrop_path", _bp)
                    # Plot + rating z TMDb detailu
                    if _m_det.get("overview"):
                        info_tags["plot"] = _m_det["overview"]
                    if _m_det.get("vote_average"):
                        info_tags["rating"] = float(_m_det["vote_average"])
                    if _m_det.get("vote_count"):
                        info_tags["votes"] = int(_m_det["vote_count"])
        except Exception:
            pass
        # Pomocné vlastnosti pro per-title preference
        if m_tmdb:
            li.setProperty("richmovie.m_tmdb", str(m_tmdb))
        if m_title:
            li.setProperty("richmovie.m_title", m_title)
        if m_year:
            li.setProperty("richmovie.m_year", str(m_year))

    # Televize F4: spuštění z nabídky nese původ a výchozí pozici (služba + hook podle nich drží Pokračovat a ✔)
    import richmovie_live_offer as _rm_live_offer
    _rm_live_offer.note_origin(xbmcgui.Window(10000).setProperty, args.get("origin", [""])[0], args.get("origin_start", ["0"])[0], ident)
    # CW: stream identifikace pro primy play z Continue Watching
    li.setProperty("richmovie.ident", ident)
    # 4.0.3 (M6): kdo přehrávání spustil, nese PŘEHRÁVANÁ POLOŽKA (služba ji čte v onAVStarted). Dřív globální
    # Window prop nastavená před dispatchem — když se stream neotevřel, visela do dalšího RUČNÍHO startu.
    if (args.get("autoplay", [""])[0] or "").strip() == "1":
        li.setProperty("richmovie.autoplay", "1")
    li.setProperty("richmovie.source", source)
    if fs_url:
        li.setProperty("richmovie.fs_url", fs_url)
    if fs_hash:
        li.setProperty("richmovie.fs_hash", fs_hash)

    if vid_len > 0:
        info_tags["duration"] = vid_len
        info_tags["runtime"]  = max(1, vid_len // 60)
        li.setProperty("richmovie.duration", str(vid_len))

    # Φ1 adaptivní cache (3.5.127): velikost souboru pro výpočet bitrate streamu
    # (B = size×8 / délka) v měřiči plnění cache ve službě. Bez B se vzorek
    # zahazuje (normalizace fill_ratio jinak nejde). Fastshare velikost nemá → 0.
    try:
        _size_bytes = int((finfo or {}).get("size") or 0)
    except (TypeError, ValueError):
        _size_bytes = 0
    if _size_bytes > 0:
        li.setProperty("richmovie.size_bytes", str(_size_bytes))
    # 3.5.151 (Φ3c): jméno vydání = podpis verze pro výběr dalšího dílu (`richmovie_continuity`)
    try:
        _release_name = str((finfo or {}).get("name") or "").strip()
        if _release_name:
            li.setProperty("richmovie.release_name", _release_name[:240])
    except Exception:
        pass

    if info_tags:
        li.setInfo("video", info_tags)
    if play_art:
        li.setArt(play_art)

    # ──────────────────────────────────────────────────────────────────────
    # 3b) TELEMETRIE: bootstrap player contextu PŘED přehráním (FU-4 fix).
    #     Historicky se set_player_context() NIKDY nevolal → RichMoviePlayer.onAVStarted
    #     četl prázdný context (tmdb_id=None) → _finalize přeskočil enqueue → živá
    #     watch_events telemetrie byla mrtvá od 3.1.0 (jediná data = backfill 2026-04-26).
    #     Musí být PŘED setResolvedUrl, ať onAVStarted čte naplněný context.
    #     Best-effort, fail-safe — nikdy nesmí shodit přehrávání.
    if tv_name and season_no and episode_no and str(tv_id).strip():
        _pick_key = _rm_epsearch.search_key(tv_id, season_no, episode_no)
    elif m_tmdb:
        _pick_key = "movie:%d" % int(m_tmdb)
    else:
        _pick_key = ""
    _pick = _play_pick(_req_ident, ident, source, _pick_key,
                       str((finfo or {}).get("name") or ""),
                       (args.get("autoplay", [""])[0] or "").strip() == "1", bool(_resume_req))
    _pick_ctx = dict(
        source_used=(source or None),
        quality_picked=(_pick.get("q") or None),
        ident=ident, search_id=(_pick.get("sid") or None), list_pos=int(_pick.get("pos") or 0),
    )
    try:
        import richmovie_player_hook as _ph
        # 3.5.131 (doporučení v2, plán R1): žánry/rating/země z DISKOVÉ cache TMDb
        # (`peek_*`, 0 síťových volání) — dřív šly eventy na Gate s prázdnými
        # žánry (917/917) a profil chuti byl slepý. Gate si je stejně dopočítá
        # z katalogu; klient posílá, co zná, aby byl event úplný hned.
        _ctx_meta = {}
        try:
            _peek_key = richmovie_settings.get_tmdb_api_key()
            _peek = TMDb(_peek_key, lang="cs-CZ")
            if tv_name and season_no and episode_no and str(tv_id).isdigit():
                _ctx_meta = _peek.player_context_meta("tv", int(tv_id))
            elif m_tmdb and str(m_tmdb).isdigit():
                _ctx_meta = _peek.player_context_meta("movie", int(m_tmdb))
        except Exception as _peek_exc:
            _log(f"player context peek failed: {_peek_exc!r}", xbmc.LOGDEBUG)
        if tv_name and season_no and episode_no:
            _ph.set_player_context(
                tmdb_id=int(tv_id) if str(tv_id).isdigit() else None,
                kind="tv",
                season=int(season_no),
                episode=int(episode_no),
                title=tv_name,
                genres=_ctx_meta.get("genres"),
                origin_country=_ctx_meta.get("origin_country"),
                imdb_rating=_ctx_meta.get("rating"),
                **_pick_ctx
            )
        elif m_title or m_tmdb:
            _ph.set_player_context(
                tmdb_id=int(m_tmdb) if (m_tmdb and str(m_tmdb).isdigit()) else None,
                kind="movie",
                title=m_title or "",
                year=int(m_year) if (m_year and str(m_year).isdigit()) else None,
                genres=_ctx_meta.get("genres"),
                origin_country=_ctx_meta.get("origin_country"),
                imdb_rating=_ctx_meta.get("rating"),
                **_pick_ctx
            )
    except Exception as _ctx_exc:
        _log(f"set_player_context failed: {_ctx_exc}", xbmc.LOGDEBUG)

    # Φ5 (13.09.2026): přímé spuštění (klik na díl/film mimo Pokračovat) bez převzaté pozice →
    # když má profil na Gate novější `watching` z JINÉHO zařízení (≥ 120 s), navázat z něj.
    # „Přehrát od začátku" jde přes Pokračovat (restart=1) a tudy neprochází.
    # Φ6: dotaz běží od vstupu `_play` souběžně s resolve (`_RemoteResumeLookup`), tady se jen převezme.
    _from_start = (args.get("from_start", [""])[0] or "").strip() == "1"
    if _remote_lookup is not None and _resume_req is None and _rm_resume is not None and not _from_start:
        try:
            _remote = _remote_lookup.result()
            if _remote:
                _remote_pos = _announce_remote_resume(_remote, 0.0)
                if _remote_pos > 0:
                    _resume_req = _rm_resume.make_request(_remote_pos, runtime_s=vid_len,
                                                          source=_rm_resume.SOURCE_REMOTE)
        except Exception as _dr_exc:
            _log(f"direct remote resume skipped: {_dr_exc!r}", xbmc.LOGDEBUG)
    # 4.0.3 (A6, nález M5): přímý klik na rozkoukaný díl/film naváže od pozice PROFILU (postup z kteréhokoli
    # zařízení, Gate → lokální úložiště). Dřív začal od nuly a nízká pozice pak přepsala rozkoukanost všude.
    # „Přehrát od začátku“ = kontextové menu streamu (`from_start=1`).
    if _resume_req is None and _rm_resume is not None and not _from_start:
        try:
            if tv_name and season_no and episode_no and str(tv_id).isdigit():
                _own = _hist_module.progress_for_series(int(tv_id)).get((int(season_no), int(episode_no)))
            elif m_tmdb:
                _own = _hist_module.progress_for_movie(int(m_tmdb))
            else:
                _own = None
            if _own and float(_own.get("position") or 0) > _rm_resume.MIN_POSITION_S:
                _resume_req = _rm_resume.make_request(float(_own["position"]),
                                                      runtime_s=vid_len or _own.get("duration") or 0,
                                                      source=_rm_resume.SOURCE_PROFILE)
                if _resume_req is not None:
                    _notif(_hist_module.progress_mark(_own).replace("◐ pokračuj", "Navazuji"),
                           xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as _own_exc:
            _log(f"profile resume skipped: {_own_exc!r}", xbmc.LOGDEBUG)

    # 3.5.151 (plán PLAN_resume_native_start_sync_integrity_20260916, Φ1): pozice jde do
    # RESOLVOVANÉ položky PŘED `setResolvedUrl` — Kodi otevře stream rovnou na ní
    # (STARTOFFSET_RESUME → `starttime` → seek demuxeru před prvním snímkem). Dřívější
    # `seekTime()` po `isPlaying()` Kodi tiše zahodil, dokud stream nebyl otevřený
    # (incident notebook 16.09.2026). Ověření a případnou opravu dělá služba.
    if _rm_resume is not None:
        try:
            from richmovie_playback_end import player_ctx_key as _resume_ctx_key
            _rm_resume.prepare_resolved_item(li, _resume_req, ident=ident, runtime_hint_s=vid_len,
                                             key=_resume_ctx_key() or "")
        except Exception as _rp_exc:
            _log(f"RESUME prepare failed: {_rp_exc!r}", xbmc.LOGWARNING)

    # 3.5.155: stopa se vybírá už PŘI OTEVŘENÍ souboru (Kodi `locale.audiolanguage` /
    # `locale.subtitlelanguage` podle profilu/titulu/zařízení), ne přepnutím za běhu —
    # přepnutí = flush dekodéru = zamrzlý obraz na Chromecastu (26.09.2026). Předchozí
    # hodnoty vrátí služba po konci přehrávání (`restore_primed_settings`).
    try:
        _loc_module.prime_initial_streams(
            m_tmdb=(m_tmdb if 'm_tmdb' in locals() and m_tmdb else None),
            tv_id=(int(tv_id) if 'tv_id' in locals() and str(tv_id).isdigit() else None),
            m_title=(m_title if 'm_title' in locals() and m_title else None),
            m_year=(m_year if 'm_year' in locals() and m_year else None),
        )
    except Exception as _prime_exc:
        _log(f"LOC prime failed: {_prime_exc!r}", xbmc.LOGWARNING)

    # ──────────────────────────────────────────────────────────────────────
    # 4) RESOLVE – spuštění přehrávání (ZACHOVÁNO)
    # ──────────────────────────────────────────────────────────────────────
    # Φ1: start drží stav OTEVÍRÁNÍ, dokud služba neuvidí obraz nebo chybu TÉHOŽ streamu (`_rm_dispatch.finish`).
    # PŘED `setResolvedUrl` (audit Fable F-2): po předání může AVStarted rychlého streamu předběhnout návrat skriptu.
    _rm_dispatch.note_resolved(dispatch_token, ident=ident)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    # Φ0 (29.09.2026): okamžik předání streamu Kodi (od TRACE begin) — dřív ho Webshare cesta
    # neznačila vůbec a flotila neuměla oddělit práci pluginu od otevírání streamu (audit A05).
    _rm_bc.checkpoint("resolved", ms=_rm_bc.action_elapsed_ms(), source=source or "webshare")

    # 22.01.2026 – debug log pro Fastshare timing
    if source == "fastshare":
        try:
            import time as _time_play
            _log(f"[Fastshare] PLAY_RESOLVED source=fastshare", xbmc.LOGINFO)
        except Exception:
            pass

    # 3.5.151: navázání na pozici už NENÍ seek po startu (viz Φ1 výše — Kodi seek před
    # otevřením streamu tiše zahodí). Start na pozici zajistil bod v položce, ověření dělá
    # služba (`service_nextup` → `richmovie_resume.run_verification`).

    # 2025-09-05 21:05 CEST (Europe/Prague)
    # Po startu videa nastav audio/titulky dle preferencí (asynchronně + logy LOC_*)
    try:
        _apply_stream_localization_async(
            m_tmdb=(m_tmdb if 'm_tmdb' in locals() and m_tmdb else None),
            tv_id=(int(tv_id) if 'tv_id' in locals() and str(tv_id).isdigit() else None),
            m_title=(m_title if 'm_title' in locals() and m_title else None),
            m_year=(m_year if 'm_year' in locals() and m_year else None),
        )
        _log_event("LOC_HOOK", {"m_tmdb": (m_tmdb if 'm_tmdb' in locals() else None),
                                "tv_id":  (int(tv_id) if ('tv_id' in locals() and str(tv_id).isdigit()) else None)})
    except Exception as _e:
        _log_event("LOC_HOOK_ERR", str(_e))




    # ──────────────────────────────────────────────────────────────────────
    # 5) ZÁPIS DO HISTORIE SLEDOVÁNÍ (NOVÉ, FAIL‑SAFE)
    # ──────────────────────────────────────────────────────────────────────
    try:
        if tv_name and season_no and episode_no:
            # Epizoda
            _watch_add_episode(
                tv_id     = int(tv_id) if str(tv_id).isdigit() else tv_id,
                tv_name   = tv_name,
                season    = season_no,
                episode   = episode_no,
                ep_title  = ep_title,
            )
            _log_event("WATCH_EP", tv_id, season_no, episode_no, tv_name)
        elif m_title or m_tmdb:
            # Film (stačí TMDb ID nebo název)
            _watch_add_movie(
                tmdb_id = m_tmdb if m_tmdb else None,
                title   = m_title,
                year    = m_year or None,
            )
            _log_event("WATCH_MOVIE", m_tmdb or "-", m_title, m_year or "-")
        # pokud chybí všechny kontextové parametry, jen nic nelogujeme
    except Exception as exc:
        _log(f"watch history write failed: {exc}", xbmc.LOGDEBUG)


# ─────────────────────────────────────────────────────────────────────────────
#  iDNES.tv – handler funkce
# ─────────────────────────────────────────────────────────────────────────────

def _idnestv_relative_time(published: str) -> str:
    """Relativní čas v češtině: 'před 5 minutami', 'včera', 'předevčírem' atd."""
    if not published:
        return ""
    try:
        dt = datetime.datetime.fromisoformat(published.replace("Z", "+00:00"))
        now = datetime.datetime.now(datetime.timezone.utc)
        diff = now - dt
        mins = int(diff.total_seconds() / 60)
        hours = int(diff.total_seconds() / 3600)
        days = diff.days

        if mins < 1:
            return "právě teď"
        if mins < 60:
            if mins == 1:
                return "před minutou"
            if mins < 5:
                return "před %d minutami" % mins
            return "před %d minutami" % mins
        if hours < 24 and days == 0:
            if hours == 1:
                return "před hodinou"
            if hours < 5:
                return "před %d hodinami" % hours
            return "před %d hodinami" % hours
        if days == 1:
            return "včera"
        if days == 2:
            return "předevčírem"
        if days < 7:
            return "před %d dny" % days
        return dt.strftime("%d.%m.%Y")
    except Exception:
        return ""


def _idnestv_home() -> None:
    """iDNES.tv homepage: složka Poslední videa + kategorie."""
    import richmovie_gate
    # Φ7 (2026-07-06): RmDir sink — custom UI otevře list okno, legacy 1:1 xbmcplugin
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "iDNES.tv")

    gate_url = richmovie_gate.get_gate_url()
    if not gate_url:
        _notif("Gate nedostupný", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    try:
        data = _http_get_json(f"{gate_url}/idnes-tv?limit=1", timeout=10)
    except Exception as e:
        _log("[iDNES] Fetch error: %s" % e, xbmc.LOGERROR)
        _notif("Nelze načíst iDNES.tv", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, "iDNES.tv")
    xbmcplugin.setContent(HANDLE, "files")

    # 1) Poslední videa — vždy první
    li = xbmcgui.ListItem("Poslední videa na iDNES.tv")
    li.setArt({"icon": "DefaultRecentlyAddedVideos.png"})
    rmdir.add(_url(action="idnestv_latest"), li, True)

    # 2) Kategorie
    categories = data.get("categories", [])
    for cat in categories:
        slug = cat.get("slug", "")
        label = cat.get("label", slug)
        cnt = cat.get("count", 0)
        li = xbmcgui.ListItem(f"{label} ({cnt})")
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(_url(action="idnestv_category", cat=slug, name=label), li, True)

    rmdir.finish()


def _idnestv_latest() -> None:
    """iDNES.tv — všechna poslední videa s relativním časem."""
    import richmovie_gate
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "iDNES.tv – Poslední videa")

    gate_url = richmovie_gate.get_gate_url()
    if not gate_url:
        _notif("Gate nedostupný", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    try:
        data = _http_get_json(f"{gate_url}/idnes-tv?limit=50", timeout=10)
    except Exception as e:
        _log("[iDNES] Latest fetch error: %s" % e, xbmc.LOGERROR)
        _notif("Nelze načíst videa", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, "iDNES.tv – Poslední videa")
    xbmcplugin.setContent(HANDLE, "videos")

    videos = data.get("videos", [])
    _idnestv_render_videos(videos, rmdir)

    rmdir.finish()
    if not rmdir.custom:
        # R3-P2-8: view mode jen v legacy — v custom režimu by builtin po
        # zavření list okna cílil na CIZÍ podkladový kontejner (Kodi Home/Videos)
        xbmc.executebuiltin("Container.SetViewMode(55)")


def _idnestv_category() -> None:
    """iDNES.tv videa pro konkrétní kategorii."""
    import richmovie_gate
    import richmovie_rmdir

    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    cat = (params.get("cat", [""])[0] or "").strip()
    name = (params.get("name", [""])[0] or "").strip() or cat
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"iDNES.tv – {name}")

    gate_url = richmovie_gate.get_gate_url()
    if not gate_url:
        _notif("Gate nedostupný", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    try:
        data = _http_get_json(f"{gate_url}/idnes-tv?category={cat}&limit=50", timeout=10)
    except Exception as e:
        _log("[iDNES] Category fetch error: %s" % e, xbmc.LOGERROR)
        _notif("Nelze načíst kategorii", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, f"iDNES.tv – {name}")
    xbmcplugin.setContent(HANDLE, "videos")

    videos = data.get("videos", [])
    _idnestv_render_videos(videos, rmdir)

    rmdir.finish()
    if not rmdir.custom:
        # R3-P2-8: view mode jen v legacy — v custom režimu by builtin po
        # zavření list okna cílil na CIZÍ podkladový kontejner (Kodi Home/Videos)
        xbmc.executebuiltin("Container.SetViewMode(55)")


def _idnestv_render_videos(videos: list, rmdir) -> None:
    """Render iDNES.tv video items into Kodi listing (sink = RmDir volajícího)."""
    for v in videos:
        title = v.get("title", "")
        desc = v.get("description", "")
        thumb = v.get("thumbnail_url", "")
        duration = v.get("duration", 0)
        category = v.get("category", "")
        video_id = v.get("video_id", "")
        published = v.get("published_at", "")
        video_url = v.get("video_url_high") or v.get("video_url_mid", "")

        # Relativní čas vydání
        rel_time = _idnestv_relative_time(published)

        # Label: název + relativní čas
        time_suffix = ""
        if rel_time:
            time_suffix = f"  [COLOR FF888888]{rel_time}[/COLOR]"
        label = f"{title}{time_suffix}"
        li = xbmcgui.ListItem(label)

        art = {"icon": "DefaultVideo.png"}
        if thumb:
            art["thumb"] = thumb
            art["poster"] = thumb
        li.setArt(art)

        # Plot s kategorií a časem
        plot_parts = []
        if category:
            _cat_labels = {
                "domaci": "Domácí", "zahranicni": "Zahraniční", "krimi": "Krimi",
                "sport": "Sport", "technika": "Technika", "spolecnost": "Revue",
                "lifestyle": "Magazíny", "rozstrel": "Rozstřel",
            }
            plot_parts.append(_cat_labels.get(category, category))
        if rel_time:
            plot_parts.append(rel_time)
        if desc:
            if plot_parts:
                plot_parts.append("")
            plot_parts.append(desc)
        plot = "\n".join(plot_parts)

        info = {
            "title": title,
            "plot": plot,
            "mediatype": "video",
        }
        if duration > 0:
            info["duration"] = duration
        if published:
            try:
                dt = datetime.datetime.fromisoformat(published.replace("Z", "+00:00"))
                info["date"] = dt.strftime("%d.%m.%Y")
                info["aired"] = dt.strftime("%Y-%m-%d")
            except Exception:
                pass
        li.setInfo("video", info)

        li.setProperty("IsPlayable", "true")

        if video_url:
            play_url = _url(action="idnestv_play", video_url=video_url, title=title)
        else:
            play_url = _url(action="idnestv_play", vid=video_id, title=title)

        rmdir.add(play_url, li, isFolder=False)


def _idnestv_play() -> None:
    """Přehrání iDNES.tv videa — přímé MP4 URL nebo resolve přes Gate."""
    import richmovie_gate

    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    video_url = (params.get("video_url", [""])[0] or "").strip()
    video_id = (params.get("vid", [""])[0] or "").strip()
    title = (params.get("title", [""])[0] or "").strip()

    if not video_url and video_id:
        # Resolve via Gate
        gate_url = richmovie_gate.get_gate_url()
        if gate_url:
            try:
                data = _http_get_json(f"{gate_url}/idnes-tv/video/{video_id}", timeout=10)
                vid_data = data.get("video", {})
                video_url = vid_data.get("video_url_high") or vid_data.get("video_url_mid", "")
            except Exception as e:
                _log("[iDNES] Resolve error: %s" % e, xbmc.LOGERROR)

    if not video_url:
        _notif("Video nenalezeno", xbmcgui.NOTIFICATION_ERROR)
        return

    li = xbmcgui.ListItem(path=video_url)
    if title:
        li.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ─────────────────────────────────────────────────────────────────────────────
#  NOVINKY.CZ – handler funkce
# ─────────────────────────────────────────────────────────────────────────────

_NOVINKY_CAT_LABELS = {
    "domaci": "Domácí", "zahranicni": "Zahraniční", "krimi": "Krimi",
    "finance": "Finance", "koktejl": "Koktejl", "sport": "Sport",
    "veda": "Věda", "cestovani": "Cestování", "kultura": "Kultura",
    "auto": "Auto",
}


def _novinky_home() -> None:
    """Novinky.cz homepage: složka Poslední videa + kategorie."""
    import richmovie_gate
    # Φ7 (2026-07-06): RmDir sink — custom UI otevře list okno, legacy 1:1 xbmcplugin
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "Novinky.cz")

    gate_url = richmovie_gate.get_gate_url()
    if not gate_url:
        _notif("Gate nedostupný", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    try:
        data = _http_get_json(f"{gate_url}/novinky-tv?limit=1", timeout=10)
    except Exception as e:
        _log("[Novinky] Fetch error: %s" % e, xbmc.LOGERROR)
        _notif("Nelze načíst Novinky.cz", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, "Novinky.cz")
    xbmcplugin.setContent(HANDLE, "files")

    # 1) Poslední videa
    li = xbmcgui.ListItem("Poslední videa na Novinky.cz")
    li.setArt({"icon": "DefaultRecentlyAddedVideos.png"})
    rmdir.add(_url(action="novinky_latest"), li, True)

    # 2) Kategorie
    categories = data.get("categories", [])
    for cat in categories:
        slug = cat.get("slug", "")
        label = cat.get("label", slug)
        cnt = cat.get("count", 0)
        li = xbmcgui.ListItem(f"{label} ({cnt})")
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(_url(action="novinky_category", cat=slug, name=label), li, True)

    rmdir.finish()


def _novinky_latest() -> None:
    """Novinky.cz — všechna poslední videa s relativním časem."""
    import richmovie_gate
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "Novinky.cz – Poslední videa")

    gate_url = richmovie_gate.get_gate_url()
    if not gate_url:
        _notif("Gate nedostupný", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    try:
        data = _http_get_json(f"{gate_url}/novinky-tv?limit=50", timeout=10)
    except Exception as e:
        _log("[Novinky] Latest fetch error: %s" % e, xbmc.LOGERROR)
        _notif("Nelze načíst videa", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, "Novinky.cz – Poslední videa")
    xbmcplugin.setContent(HANDLE, "videos")

    videos = data.get("videos", [])
    _novinky_render_videos(videos, rmdir)

    rmdir.finish()
    if not rmdir.custom:
        # R3-P2-8: view mode jen v legacy — v custom režimu by builtin po
        # zavření list okna cílil na CIZÍ podkladový kontejner (Kodi Home/Videos)
        xbmc.executebuiltin("Container.SetViewMode(55)")


def _novinky_category() -> None:
    """Novinky.cz videa pro konkrétní kategorii."""
    import richmovie_gate
    import richmovie_rmdir

    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    cat = (params.get("cat", [""])[0] or "").strip()
    name = (params.get("name", [""])[0] or "").strip() or cat
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"Novinky.cz – {name}")

    gate_url = richmovie_gate.get_gate_url()
    if not gate_url:
        _notif("Gate nedostupný", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    try:
        data = _http_get_json(f"{gate_url}/novinky-tv?category={cat}&limit=50", timeout=10)
    except Exception as e:
        _log("[Novinky] Category fetch error: %s" % e, xbmc.LOGERROR)
        _notif("Nelze načíst kategorii", xbmcgui.NOTIFICATION_ERROR)
        rmdir.finish(succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, f"Novinky.cz – {name}")
    xbmcplugin.setContent(HANDLE, "videos")

    videos = data.get("videos", [])
    _novinky_render_videos(videos, rmdir)

    rmdir.finish()
    if not rmdir.custom:
        # R3-P2-8: view mode jen v legacy — v custom režimu by builtin po
        # zavření list okna cílil na CIZÍ podkladový kontejner (Kodi Home/Videos)
        xbmc.executebuiltin("Container.SetViewMode(55)")


def _novinky_render_videos(videos: list, rmdir) -> None:
    """Render Novinky.cz video items into Kodi listing (sink = RmDir volajícího)."""
    import time as _time

    now_ts = int(_time.time())

    for v in videos:
        title = v.get("title", "")
        desc = v.get("description", "")
        thumb = v.get("thumbnail_url", "")
        duration = v.get("duration", 0)
        category = v.get("category", "")
        video_id = v.get("video_id", "")
        published = v.get("published_at", "")
        video_url = v.get("video_url", "")
        video_expires = v.get("video_expires", 0)

        # Skip expired videos (token expired)
        if video_expires and video_expires < now_ts:
            continue

        # Relativní čas
        rel_time = _idnestv_relative_time(published)

        time_suffix = ""
        if rel_time:
            time_suffix = f"  [COLOR FF888888]{rel_time}[/COLOR]"
        label = f"{title}{time_suffix}"
        li = xbmcgui.ListItem(label)

        art = {"icon": "DefaultVideo.png"}
        if thumb:
            art["thumb"] = thumb
            art["poster"] = thumb
        li.setArt(art)

        # Plot s kategorií a časem
        plot_parts = []
        if category:
            plot_parts.append(_NOVINKY_CAT_LABELS.get(category, category))
        if rel_time:
            plot_parts.append(rel_time)
        if desc:
            if plot_parts:
                plot_parts.append("")
            plot_parts.append(desc)
        plot = "\n".join(plot_parts)

        info = {
            "title": title,
            "plot": plot,
            "mediatype": "video",
        }
        if duration > 0:
            info["duration"] = duration
        if published:
            try:
                dt = datetime.datetime.fromisoformat(published.replace("Z", "+00:00"))
                info["date"] = dt.strftime("%d.%m.%Y")
                info["aired"] = dt.strftime("%Y-%m-%d")
            except Exception:
                pass
        li.setInfo("video", info)

        li.setProperty("IsPlayable", "true")

        play_url = _url(action="novinky_play", video_url=video_url, title=title)
        rmdir.add(play_url, li, isFolder=False)


def _novinky_play() -> None:
    """Přehrání Novinky.cz videa — resolve SPL → HLS (same pattern as Stream.cz)."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    video_url = (params.get("video_url", [""])[0] or "").strip()
    title = (params.get("title", [""])[0] or "").strip()

    if not video_url:
        _notif("Video nenalezeno", xbmcgui.NOTIFICATION_ERROR)
        return

    # Resolve via richmovie_stream.resolve_streams (same CDN as Stream.cz)
    try:
        result = richmovie_stream.resolve_streams(video_url)
    except Exception as exc:
        _log(f"[Novinky] SPL resolve failed: {exc}", xbmc.LOGERROR)
        _notif("Video nelze načíst", xbmcgui.NOTIFICATION_ERROR)
        return

    hls_url = result.get("hls", "")
    formats = result.get("formats") or []

    if not hls_url and not formats:
        _notif("Video nenalezeno", xbmcgui.NOTIFICATION_ERROR)
        return

    # HLS preferred (adaptive bitrate, native seek, instant start)
    if hls_url:
        play_url = hls_url.replace("|", "%7C") + "|User-Agent=Mozilla/5.0"
    else:
        # MP4 fallback — pick best quality
        play_url = formats[0]["url"].replace("|", "%7C") + "|User-Agent=Mozilla/5.0"

    li = xbmcgui.ListItem(path=play_url)
    if title:
        li.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ─────────────────────────────────────────────────────────────────────────────
#  STREAMING HOME – podmenu pro Stream.cz, YouTube a ostatni
# ─────────────────────────────────────────────────────────────────────────────
def _streaming_home() -> None:
    """Podmenu pro externi streamovaci sluzby a dalsi zdroje."""
    # Phi7 (2026-07-06): RmDir sink - custom UI otevre list okno, legacy 1:1 xbmcplugin
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "Stream.cz, YouTube a ostatn\u00ed")
    xbmcplugin.setPluginCategory(HANDLE, "Stream.cz, YouTube a ostatn\u00ed")
    xbmcplugin.setContent(HANDLE, "files")

    # 1) Stream.cz
    li = xbmcgui.ListItem("Stream.cz")
    li.setArt({"icon": "DefaultNetwork.png"})
    rmdir.add(_url(action="stream_home"), li, True)

    # 2) YouTube
    li = xbmcgui.ListItem("YouTube")
    li.setArt({"icon": "DefaultNetwork.png"})
    rmdir.add(_url(action="yt_home"), li, True)

    # 3) SkTorrent Online
    li = xbmcgui.ListItem("SkTorrent Online")
    li.setArt({"icon": "DefaultNetwork.png"})
    rmdir.add(_url(action="sktorrent_home"), li, True)

    # 4) iDNES.tv
    li = xbmcgui.ListItem("iDNES.tv")
    li.setArt({"icon": "DefaultNetwork.png"})
    rmdir.add(_url(action="idnestv_home"), li, True)

    # 5) Novinky.cz
    li = xbmcgui.ListItem("Novinky.cz")
    li.setArt({"icon": "DefaultNetwork.png"})
    rmdir.add(_url(action="novinky_home"), li, True)

    # 6) Vyhledat hudbu
    li = xbmcgui.ListItem("Vyhledat hudbu")
    li.setArt({"icon": "DefaultMusicSearch.png"})
    rmdir.add(_url(action="music_search"), li, True)

    rmdir.finish()


# ─────────────────────────────────────────────────────────────────────────────
#  SKTORRENT – handler funkce
# ─────────────────────────────────────────────────────────────────────────────
_SKTORRENT_SORTS = [
    ("mr", "Nejnov\u011bj\u0161\u00ed"),
    ("mv", "Nejsledovan\u011bj\u0161\u00ed"),
    ("tr", "Nejl\u00e9pe hodnocen\u00e9"),
    ("bw", "Pr\u00e1v\u011b sledovan\u00e9"),
    ("lg", "Nejdel\u0161\u00ed"),
]


def _sktorrent_home() -> None:
    """Domovska stranka SkTorrent: hledani + kategorie."""
    # Phi7 (2026-07-06): RmDir sink - custom UI otevre list okno, legacy 1:1 xbmcplugin
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "SkTorrent Online")
    xbmcplugin.setPluginCategory(HANDLE, "SkTorrent Online")
    xbmcplugin.setContent(HANDLE, "files")

    # Hledani
    li = xbmcgui.ListItem("[B]Hledat na SkTorrent[/B]")
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    rmdir.add(_url(action="sktorrent_search"), li, True)

    # Kategorie
    for cat in richmovie_sktorrent.get_categories():
        li = xbmcgui.ListItem(cat["name"])
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(
            _url(action="sktorrent_browse", slug=cat["slug"], name=cat["name"]),
            li,
            True,
        )

    rmdir.finish()


def _sktorrent_search() -> None:
    """Hledani na SkTorrent s klavesnici."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    query = params.get("q", [""])[0]
    # 3.4.7 (audit Ω5, 2026-05-17): bounded cast, replicates pattern from line 6619.
    try:
        page = max(1, min(1000, int(params.get("page", ["1"])[0])))
    except (ValueError, TypeError):
        page = 1

    if not query:
        kb = xbmc.Keyboard("", "Hledat na SkTorrent")
        kb.doModal()
        if not kb.isConfirmed():
            return
        query = kb.getText().strip()
        if not query:
            return

    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"SkTorrent - {query}")
    xbmcplugin.setPluginCategory(HANDLE, f"SkTorrent - {query}")
    xbmcplugin.setContent(HANDLE, "videos")

    try:
        items, has_next = richmovie_sktorrent.search(query, page=page)
    except Exception as exc:
        _log(f"[SkTorrent] search error: {exc}", xbmc.LOGERROR)
        _net_error_ui(exc, heading="SkTorrent")
        rmdir.finish(succeeded=False)
        return

    _sktorrent_add_items(items, rmdir)

    if has_next:
        li = xbmcgui.ListItem("[B]Dal\u0161\u00ed str\u00e1nka...[/B]")
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(
            _url(action="sktorrent_search", q=query, page=str(page + 1)),
            li,
            True,
        )

    if not items and page == 1:
        _modal(f"Nic nenalezeno pro: {query}")

    rmdir.finish()


def _sktorrent_browse() -> None:
    """Proch\u00e1zen\u00ed kategorie na SkTorrent s v\u00fdb\u011brem \u0159azen\u00ed."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    slug = params.get("slug", [""])[0]
    name = params.get("name", ["SkTorrent"])[0]
    # 3.4.7 (audit \u03a95, 2026-05-17): bounded cast (same pattern as _sktorrent_search).
    try:
        page = max(1, min(1000, int(params.get("page", ["1"])[0])))
    except (ValueError, TypeError):
        page = 1
    sort = params.get("sort", [""])[0]

    if not slug:
        return

    # Prvni navsteva kategorie → nabidnout razeni
    if not sort and page == 1:
        labels = [s[1] for s in _SKTORRENT_SORTS]
        idx = xbmcgui.Dialog().select("\u0158azen\u00ed", labels)
        if idx < 0:
            return
        sort = _SKTORRENT_SORTS[idx][0]

    if not sort:
        sort = "mr"

    sort_label = dict(_SKTORRENT_SORTS).get(sort, "")
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"SkTorrent - {name} ({sort_label})")
    xbmcplugin.setPluginCategory(
        HANDLE, f"SkTorrent - {name} ({sort_label})")
    xbmcplugin.setContent(HANDLE, "videos")

    try:
        items, has_next = richmovie_sktorrent.browse(slug, page=page, sort=sort)
    except Exception as exc:
        _log(f"[SkTorrent] browse error: {exc}", xbmc.LOGERROR)
        _net_error_ui(exc, heading="SkTorrent")
        rmdir.finish(succeeded=False)
        return

    _sktorrent_add_items(items, rmdir)

    if has_next:
        li = xbmcgui.ListItem("[B]Dal\u0161\u00ed str\u00e1nka...[/B]")
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(
            _url(action="sktorrent_browse", slug=slug, name=name,
                 sort=sort, page=str(page + 1)),
            li,
            True,
        )

    rmdir.finish()


# ---------------------------------------------------------------------------
#  SkTorrent FALLBACK – pouziti jako zalozni zdroj v hlavnim vyhledavani
# ---------------------------------------------------------------------------

def _sktorrent_fallback(query: str, tmdb_meta: dict = None) -> bool:
    """
    Fallback vyhledavani na SkTorrent (online.sktorrent.eu).
    Vola se kdyz Webshare + Fastshare nenajdou zadne vysledky.
    Vraci True pokud neco nasla a pridala do directory listingu.
    """
    try:
        items, _ = richmovie_sktorrent.search(query)
    except Exception as exc:
        _log(f"[SkTorrent] fallback search error: {exc}", xbmc.LOGINFO)
        items = []
    _log_event("SKT_FALLBACK", len(items or []), query)
    if not items:
        return False

    _log(f"[SkTorrent] fallback: {len(items)} results for '{query}'", xbmc.LOGINFO)

    for it in items:
        vid = it["id"]
        raw_title = it["title"]
        parsed = richmovie_sktorrent.parse_title(raw_title)

        display_title = parsed.get("title_cs") or raw_title
        season = parsed.get("season", "")
        episode = parsed.get("episode", "")
        year_str = parsed.get("year", "")
        lang = parsed.get("lang", "")
        hd = it.get("hd", False)
        duration = it.get("duration", "")

        # Label: SKT prefix + nazev + S01E23 + rok + jazyk + HD + stopaz
        label = "[COLOR FFFF6B00]SKT[/COLOR]  " + display_title
        if season and episode:
            label += f"  [COLOR FF87CEFA]S{int(season):02d}E{int(episode):02d}[/COLOR]"
        if year_str:
            label += f"  [COLOR FFFFFF00]({year_str})[/COLOR]"
        if lang:
            label += f"  [COLOR FF87CEFA]{lang}[/COLOR]"
        if hd:
            label += "  [COLOR FF87CEFA]HD[/COLOR]"
        if duration:
            label += f"  [COLOR FFAAAAAA]{duration}[/COLOR]"

        li = xbmcgui.ListItem(label)

        # Artwork: preferovat TMDb metadata, fallback na SkTorrent thumbnail
        thumb = it.get("thumb", "")
        art = {"icon": "DefaultVideo.png"}
        if tmdb_meta:
            if tmdb_meta.get("poster"):
                art["poster"] = tmdb_meta["poster"]
                art["thumb"] = tmdb_meta["poster"]
            elif thumb:
                art["poster"] = thumb
                art["thumb"] = thumb
            if tmdb_meta.get("fanart"):
                art["fanart"] = tmdb_meta["fanart"]
            elif thumb:
                art["fanart"] = thumb.replace("/1.jpg", "/default.jpg")
        else:
            if thumb:
                art["thumb"] = thumb
                art["poster"] = thumb
                art["fanart"] = thumb.replace("/1.jpg", "/default.jpg")
        li.setArt(art)

        # Info: TMDb plot/rating pokud k dispozici
        plot = ""
        if tmdb_meta and tmdb_meta.get("overview"):
            plot = tmdb_meta["overview"]
        else:
            parts = []
            if parsed.get("title_en"):
                parts.append(parsed["title_en"])
            if year_str:
                parts.append(f"({year_str})")
            if lang:
                parts.append(f"[{lang}]")
            plot = " ".join(parts) if parts else raw_title

        info: dict = {"title": display_title, "plot": plot, "mediatype": "movie"}
        if year_str:
            try:
                info["year"] = int(year_str)
            except ValueError:
                pass
        if tmdb_meta and tmdb_meta.get("rating"):
            info["rating"] = tmdb_meta["rating"]
        li.setInfo("video", info)
        li.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action="sktorrent_play", video_id=vid, title=raw_title),
            li, False,
        )

    return True


def _sktorrent_add_items(items: list, rmdir) -> None:
    """Pomocny: prida SkTorrent video polozky do directory listingu (sink = RmDir volajiciho)."""
    for it in items:
        vid = it["id"]
        raw_title = it["title"]
        duration = it.get("duration", "")
        hd = it.get("hd", False)

        # Parsovat titulek: rok, jazyk
        parsed = richmovie_sktorrent.parse_title(raw_title)
        year_str = parsed.get("year", "")
        lang = parsed.get("lang", "")
        display_title = parsed.get("title_cs") or raw_title

        # Label: nazev S01E23 (rok) [HD] [stopaz]
        season = parsed.get("season", "")
        episode = parsed.get("episode", "")
        label = display_title
        if season and episode:
            label += f"  [COLOR FF87CEFA]S{int(season):02d}E{int(episode):02d}[/COLOR]"
        if year_str:
            label += f"  [COLOR FFFFFF00]({year_str})[/COLOR]"
        if lang:
            label += f"  [COLOR FF87CEFA]{lang}[/COLOR]"
        if hd:
            label += "  [COLOR FF87CEFA]HD[/COLOR]"
        if duration:
            label += f"  [COLOR FFAAAAAA]{duration}[/COLOR]"

        li = xbmcgui.ListItem(label)
        art = {"icon": "DefaultVideo.png"}
        thumb = it.get("thumb", "")
        if thumb:
            art["thumb"] = thumb
            art["poster"] = thumb
            # Pouzit default.jpg jako fanart (sirsi obraz nez 1.jpg)
            art["fanart"] = thumb.replace("/1.jpg", "/default.jpg")
        li.setArt(art)

        # Plot: cesky nazev / anglicky nazev (rok) – zakladni info bez API
        plot_parts = []
        if parsed.get("title_en"):
            plot_parts.append(parsed["title_en"])
        if year_str:
            plot_parts.append(f"({year_str})")
        if lang:
            plot_parts.append(f"[{lang}]")
        if hd:
            plot_parts.append("HD")
        if duration:
            plot_parts.append(duration)
        plot_line = " ".join(plot_parts) if plot_parts else raw_title

        info: dict = {
            "title": display_title,
            "plot": plot_line,
            "mediatype": "movie",
        }
        if year_str:
            try:
                info["year"] = int(year_str)
            except ValueError:
                pass
        li.setInfo("video", info)
        li.setProperty("IsPlayable", "true")

        rmdir.add(
            _url(action="sktorrent_play", video_id=vid, title=raw_title),
            li,
            False,
        )


def _sktorrent_play() -> None:
    """Přehrání videa ze SkTorrent – resolve + výběr kvality."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    video_id = params.get("video_id", [""])[0]
    title = params.get("title", [""])[0]
    _fail = xbmcgui.ListItem()

    if not video_id:
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        return

    try:
        result = richmovie_sktorrent.resolve(video_id)
    except Exception as exc:
        _log(f"[SkTorrent] resolve error: {exc}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        _net_error_ui(exc, heading="Přehrání")
        return

    streams = result.get("streams") or []
    if not streams:
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        _modal("SkTorrent: \u017e\u00e1dn\u00e9 dostupn\u00e9 streamy.")
        return

    # Vyber kvality
    if len(streams) == 1:
        chosen = streams[0]
    else:
        labels = [f"{s['quality']} ({s['height']}p)" for s in streams]
        idx = xbmcgui.Dialog().select("Kvalita", labels)
        if idx < 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
            return
        chosen = streams[idx]

    play_url = chosen["url"]
    # Nekterym CDN subdomenam nefunguje HTTPS (SSL timeout) → HTTP
    if play_url.startswith("https://online") and "sktorrent.eu" in play_url:
        play_url = play_url.replace("https://", "http://", 1)

    # Rychly test dostupnosti CDN (timeout 6s misto Kodi 30s)
    _cdn_ok = False
    try:
        import urllib.request as _ur
        import time as _tm
        _treq = _ur.Request(play_url, method="HEAD",
                            headers={"User-Agent": "Kodi/21.0"})
        _t0 = _tm.time()
        _tresp = _ur.urlopen(_treq, timeout=6)
        _elapsed = _tm.time() - _t0
        _log(f"[SkTorrent] CDN check: HTTP {_tresp.status} "
                 f"in {_elapsed:.1f}s", xbmc.LOGINFO)
        _cdn_ok = _elapsed < 5.0
    except Exception as _exc:
        _log(f"[SkTorrent] CDN check failed: {_exc}",
                 xbmc.LOGINFO)

    if not _cdn_ok:
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        _rm_notif(
            "Server m\u00e1 pot\u00ed\u017ee \u2013 zkuste jin\u00fd film.",
            xbmcgui.NOTIFICATION_WARNING,
            5000,
            "SkTorrent",
        )
        return

    _log(f"[SkTorrent] playing: {play_url}", xbmc.LOGINFO)

    li = xbmcgui.ListItem(path=play_url)

    # TMDb enrichment – parsovat nazev, hledat na TMDb
    parsed = richmovie_sktorrent.parse_title(result.get("title", title))
    tmdb_query = parsed.get("title_en") or parsed.get("title_cs") or title
    tmdb_year = parsed.get("year", "")
    tmdb_movie = None

    try:
        tmdb_key = richmovie_settings.get_tmdb_api_key()
        if tmdb_key and tmdb_query:
            tmdb_cli = TMDb(tmdb_key, lang="cs-CZ")
            # Hledat s rokem pro presnejsi vysledek
            if tmdb_year:
                tmdb_query_full = f"{tmdb_query} {tmdb_year}"
            else:
                tmdb_query_full = tmdb_query
            results_tmdb = tmdb_cli.search(tmdb_query_full, limit=3)
            if results_tmdb:
                # Preferovat shodu roku
                if tmdb_year:
                    yr = int(tmdb_year)
                    for r in results_tmdb:
                        if r.get("year") == yr:
                            tmdb_movie = r
                            break
                if not tmdb_movie:
                    tmdb_movie = results_tmdb[0]
                _log(f"[SkTorrent] TMDb match: "
                         f"{tmdb_movie.get('title')} ({tmdb_movie.get('year')})",
                         xbmc.LOGINFO)
    except Exception as _exc:
        _log(f"[SkTorrent] TMDb lookup failed: {_exc}",
                 xbmc.LOGINFO)

    # Info tagy – TMDb data maji prednost
    info_tags: dict = {"mediatype": "movie"}
    if tmdb_movie:
        info_tags["title"] = tmdb_movie.get("title", parsed.get("title_cs", title))
        if tmdb_movie.get("year"):
            info_tags["year"] = tmdb_movie["year"]
        if tmdb_movie.get("overview"):
            info_tags["plot"] = tmdb_movie["overview"]
        if tmdb_movie.get("rating"):
            info_tags["rating"] = tmdb_movie["rating"]
        if tmdb_movie.get("votes"):
            info_tags["votes"] = tmdb_movie["votes"]
    else:
        info_tags["title"] = parsed.get("title_cs") or result.get("title", title)
        if result.get("description"):
            info_tags["plot"] = result["description"]
        if tmdb_year:
            try:
                info_tags["year"] = int(tmdb_year)
            except ValueError:
                pass
    li.setInfo("video", info_tags)
    li.setProperty("richmovie.source", "sktorrent")

    # Artwork – TMDb poster/fanart, fallback SkTorrent
    art: dict = {}
    if tmdb_movie and tmdb_movie.get("poster_path"):
        art["poster"] = f"https://image.tmdb.org/t/p/w342{tmdb_movie['poster_path']}"
        art["thumb"] = f"https://image.tmdb.org/t/p/w185{tmdb_movie['poster_path']}"
    elif result.get("poster"):
        art["poster"] = result["poster"]
        art["thumb"] = result["poster"]
    if tmdb_movie and tmdb_movie.get("backdrop_path"):
        art["fanart"] = f"https://image.tmdb.org/t/p/w1280{tmdb_movie['backdrop_path']}"
    if art:
        li.setArt(art)

    # TMDb rating
    if tmdb_movie and tmdb_movie.get("rating"):
        li.setRating("tmdb", tmdb_movie["rating"],
                     int(tmdb_movie.get("votes", 0)))

    # Titulky
    subs = result.get("subtitles") or []
    if subs:
        sub_urls = [s["url"] for s in subs if s.get("url")]
        if sub_urls:
            li.setSubtitles(sub_urls)

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ─────────────────────────────────────────────────────────────────────────────
#  STREAM.CZ – handler funkce
# ─────────────────────────────────────────────────────────────────────────────
def _stream_home() -> None:
    """Domovska stranka Stream.cz: hledani + kategorie."""
    # Phi7 (2026-07-06): RmDir sink - custom UI otevre list okno, legacy 1:1 xbmcplugin
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "Stream.cz")
    xbmcplugin.setPluginCategory(HANDLE, "Stream.cz")
    xbmcplugin.setContent(HANDLE, "files")

    # Hledani
    li = xbmcgui.ListItem("[B]Hledat na Stream.cz[/B]")
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    rmdir.add(_url(action="stream_search"), li, True)

    # Kategorie
    for cat in richmovie_stream.get_categories():
        li = xbmcgui.ListItem(cat["name"])
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(
            _url(action="stream_category", id=cat["id"], name=cat["name"]), li, True
        )

    rmdir.finish()


def _stream_category() -> None:
    """Porady v kategorii."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    channel_id = params.get("id", [""])[0]
    cat_name = params.get("name", ["Stream.cz"])[0]
    after = params.get("after", [None])[0]

    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"Stream.cz - {cat_name}")
    xbmcplugin.setPluginCategory(HANDLE, f"Stream.cz - {cat_name}")
    xbmcplugin.setContent(HANDLE, "tvshows")

    try:
        shows, page_info = richmovie_stream.get_shows(channel_id, after=after)
    except Exception as exc:
        _log(f"[Stream] category error: {exc}", xbmc.LOGERROR)
        _net_error_ui(exc, heading="Stream.cz")
        rmdir.finish(succeeded=False)
        return

    for s in shows:
        li = xbmcgui.ListItem(s["name"])
        art = {"icon": "DefaultVideo.png"}
        if s.get("thumb"):
            art["thumb"] = s["thumb"]
            art["poster"] = s["thumb"]
        if s.get("fanart"):
            art["fanart"] = s["fanart"]
        li.setArt(art)
        li.setInfo("video", {
            "title": s["name"],
            "plot": s.get("perex", ""),
            "mediatype": "tvshow",
        })
        rmdir.add(
            _url(action="stream_show", show=s["urlName"]),
            li,
            True,
        )

    # Strankovani
    if page_info.get("hasNextPage"):
        li = xbmcgui.ListItem("[B]Dalsi stranka...[/B]")
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(
            _url(action="stream_category", id=channel_id, name=cat_name,
                 after=page_info["endCursor"]),
            li,
            True,
        )

    rmdir.finish()


def _stream_show() -> None:
    """Epizody/sezony poradu."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    show_url = params.get("show", [""])[0]

    # 3.5.131 (audit stránkování): „Další stránka" epizod pořadu bez sezón se
    # vrací sem s kurzorem `after`. Sezony už známe (nebyly) → rovnou epizody,
    # jinak by se sezony načítaly znovu a kurzor by mohl zapadnout.
    if params.get("after", [None])[0]:
        _stream_episodes_list(url_name=show_url, category="show")
        return

    try:
        # Zkusime nejdriv sezony
        seasons = richmovie_stream.get_seasons(show_url)
    except Exception:
        seasons = []

    if seasons:
        # Zobrazime sezony
        import richmovie_rmdir
        rmdir = richmovie_rmdir.RmDir(HANDLE, f"Stream.cz - {show_url}")
        xbmcplugin.setPluginCategory(HANDLE, f"Stream.cz - {show_url}")
        xbmcplugin.setContent(HANDLE, "seasons")
        for s in seasons:
            ep_count = s.get("episodes_count", 0)
            label = s["name"]
            if ep_count:
                label += f" ({ep_count} dilu)"
            li = xbmcgui.ListItem(label)
            art = {"icon": "DefaultFolder.png"}
            if s.get("thumb"):
                art["thumb"] = s["thumb"]
            li.setArt(art)
            rmdir.add(
                _url(action="stream_season", id=s["id"]),
                li,
                True,
            )
        rmdir.finish()
    else:
        # Bez sezon — rovnou epizody
        _stream_episodes_list(url_name=show_url, category="show")


def _stream_season() -> None:
    """Epizody v sezone."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    season_id = params.get("id", [""])[0]
    _stream_episodes_list(tag_id=season_id)


def _stream_quality() -> None:
    """Resolvne streamy a prehraje pres setResolvedUrl (HLS nebo MP4 fallback)."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    spl_url = params.get("spl", [""])[0]
    title = params.get("title", [""])[0]
    thumb = params.get("thumb", [""])[0]
    _fail = xbmcgui.ListItem()

    if not spl_url:
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        _modal("Chybi SPL URL pro prehrani.")
        return

    try:
        result = richmovie_stream.resolve_streams(spl_url)
    except Exception as exc:
        _log(f"[Stream] resolve error: {exc}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        _net_error_ui(exc, heading="Přehrání")
        return

    hls_url = result.get("hls", "")
    formats = result.get("formats") or []

    if not hls_url and not formats:
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        _modal("Zadne dostupne streamy.")
        return

    subs = result.get("subtitles") or []
    # Encode CDN pipes (%7C) — Kodi pouziva | jako separator HTTP hlavicek
    sub_urls = [s["url"].replace("|", "%7C") for s in subs if s.get("url")]

    # Preferujeme HLS — nativni seek, adaptivni kvalita
    mp4_fallback = False
    if hls_url:
        play_url = hls_url.replace("|", "%7C") + "|User-Agent=Mozilla/5.0"
    else:
        # Fallback: MP4 — dialog vyberu kvality
        mp4_fallback = True
        labels = []
        for f in formats:
            bw = f.get("bandwidth", 0)
            bw_str = f" ({bw // 1000} Mbps)" if bw >= 1000 else (f" ({bw} kbps)" if bw else "")
            h = f.get("height", 0)
            labels.append(f"{h}p MP4{bw_str}" if h else f"{f['quality']} MP4{bw_str}")
        idx = xbmcgui.Dialog().select("Kvalita", labels)
        if idx < 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
            return
        play_url = formats[idx]["url"].replace("|", "%7C") + "|User-Agent=Mozilla/5.0"

    li = xbmcgui.ListItem(path=play_url)
    li.setInfo("video", {"title": title, "mediatype": "video"})
    li.setProperty("richmovie.source", "stream_cz")
    if thumb:
        li.setArt({"thumb": thumb, "poster": thumb})
    if mp4_fallback:
        li.setProperty("seekable", "false")
    if sub_urls:
        li.setSubtitles(sub_urls)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

    if mp4_fallback:
        _notif("Starší video bez HLS — přetáčení není k dispozici", xbmcgui.NOTIFICATION_INFO, 5000)


def _stream_episodes_list(
    *,
    tag_id: str | None = None,
    url_name: str | None = None,
    category: str | None = None,
) -> None:
    """Sdileny helper pro zobrazeni seznamu epizod (vlastni RmDir sink — kresli
    kompletni obrazovku vcetne finish, volajici nic nepredava)."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    after = params.get("after", [None])[0]

    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "Stream.cz")
    xbmcplugin.setPluginCategory(HANDLE, "Stream.cz")
    xbmcplugin.setContent(HANDLE, "episodes")

    try:
        episodes, page_info = richmovie_stream.get_episodes(
            tag_id=tag_id, url_name=url_name, category=category, after=after,
        )
    except Exception as exc:
        _log(f"[Stream] episodes error: {exc}", xbmc.LOGERROR)
        _net_error_ui(exc, heading="Stream.cz")
        rmdir.finish(succeeded=False)
        return

    for ep in episodes:
        dur = ep.get("duration", 0)
        dur_min = dur // 60 if dur else 0
        views = ep.get("views", 0)

        prefix = ep.get("namePrefix", "")
        label = f"{prefix} - {ep['name']}" if prefix else ep["name"]
        if dur_min:
            label += f"  [COLOR FF87CEFA]({dur_min} min)[/COLOR]"
        if views:
            label += f"  [COLOR FF888888]{views:,} zhlednuti[/COLOR]".replace(",", " ")

        li = xbmcgui.ListItem(label)
        art = {"icon": "DefaultVideo.png"}
        if ep.get("thumb"):
            art["thumb"] = ep["thumb"]
        li.setArt(art)
        li.setInfo("video", {
            "title": ep.get("name", ""),
            "duration": dur,
            "tvshowtitle": ep.get("show_name", ""),
            "mediatype": "episode",
        })
        li.setProperty("IsPlayable", "true")

        rmdir.add(
            _url(action="stream_quality", spl=ep.get("spl", ""),
                 title=ep.get("name", ""), thumb=ep.get("thumb", "")),
            li,
            False,
        )

    # Strankovani
    if page_info.get("hasNextPage"):
        li = xbmcgui.ListItem("[B]Dalsi stranka...[/B]")
        li.setArt({"icon": "DefaultFolder.png"})
        pg_params: dict[str, str] = {"after": page_info["endCursor"]}
        if tag_id:
            pg_params.update(action="stream_season", id=tag_id)
        else:
            pg_params.update(action="stream_show", show=url_name or "")
        rmdir.add(_url(**pg_params), li, True)

    rmdir.finish()


def _stream_search() -> None:
    """Hledani na Stream.cz."""
    kb = xbmc.Keyboard("", "Hledat na Stream.cz")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return

    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"Stream.cz - {query}")
    xbmcplugin.setPluginCategory(HANDLE, f"Stream.cz - {query}")
    xbmcplugin.setContent(HANDLE, "videos")

    try:
        results = richmovie_stream.search(query)
    except Exception as exc:
        _log(f"[Stream] search error: {exc}", xbmc.LOGERROR)
        _net_error_ui(exc, heading="Stream.cz")
        rmdir.finish(succeeded=False)
        return

    # Porady (isFolder=True)
    for t in results.get("tags") or []:
        cat = t.get("category", "")
        if cat not in ("show", "channel", "service"):
            continue
        li = xbmcgui.ListItem(f"[B]{t['name']}[/B]  [COLOR FF888888]({cat})[/COLOR]")
        art = {"icon": "DefaultFolder.png"}
        if t.get("thumb"):
            art["thumb"] = t["thumb"]
            art["poster"] = t["thumb"]
        if t.get("fanart"):
            art["fanart"] = t["fanart"]
        li.setArt(art)
        li.setInfo("video", {"title": t["name"], "plot": t.get("perex", ""), "mediatype": "tvshow"})

        if cat == "show":
            target = _url(action="stream_show", show=t["urlName"])
        else:
            target = _url(action="stream_category", id=t["id"], name=t["name"])
        rmdir.add(target, li, True)

    # Epizody (isFolder=False, playable)
    for ep in results.get("episodes") or []:
        dur = ep.get("duration", 0)
        dur_min = dur // 60 if dur else 0
        show_name = ep.get("show_name", "")

        label = ep["name"]
        if show_name:
            label = f"{show_name} - {label}"
        if dur_min:
            label += f"  [COLOR FF87CEFA]({dur_min} min)[/COLOR]"

        li = xbmcgui.ListItem(label)
        art = {"icon": "DefaultVideo.png"}
        if ep.get("thumb"):
            art["thumb"] = ep["thumb"]
        li.setArt(art)
        li.setInfo("video", {
            "title": ep.get("name", ""),
            "duration": dur,
            "tvshowtitle": show_name,
            "mediatype": "episode",
        })
        li.setProperty("IsPlayable", "true")

        rmdir.add(
            _url(action="stream_quality", spl=ep.get("spl", ""),
                 title=ep.get("name", ""), thumb=ep.get("thumb", "")),
            li,
            False,
        )

    if not results.get("tags") and not results.get("episodes"):
        _modal(f"Nic nenalezeno pro: {query}")

    rmdir.finish()


def _stream_play() -> None:
    """Prehrani Stream.cz videa - prima URL, bez dialogu."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    video_url = params.get("url", [""])[0]
    title = params.get("title", [""])[0]
    subs_joined = params.get("subs", [""])[0]
    thumb = params.get("thumb", [""])[0]

    if not video_url:
        _modal("Chybi URL pro prehrani.")
        return

    # Kodi pipe headers — CDN vyzaduje browserovy UA pro plny streaming
    # Encode CDN pipes (%7C) — Kodi pouziva | jako separator HTTP hlavicek
    play_url = video_url.replace("|", "%7C") + "|User-Agent=Mozilla/5.0"

    li = xbmcgui.ListItem(path=play_url)
    li.setInfo("video", {"title": title, "mediatype": "video"})
    li.setProperty("richmovie.source", "stream_cz")
    if thumb:
        li.setArt({"thumb": thumb, "poster": thumb})

    if subs_joined:
        li.setSubtitles(subs_joined.split("|"))

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ═══════════════════════════════════════════════════════════════════════════
#  YOUTUBE
# ═══════════════════════════════════════════════════════════════════════════

def _yt_home() -> None:
    """Domovska stranka YouTube: hledani, pro tebe, trendy."""
    # Phi7 (2026-07-06): RmDir sink - custom UI otevre list okno, legacy 1:1 xbmcplugin
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "YouTube")
    xbmcplugin.setPluginCategory(HANDLE, "YouTube")
    xbmcplugin.setContent(HANDLE, "videos")

    # Hledani
    li = xbmcgui.ListItem("[B]Hledat na YouTube[/B]")
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    rmdir.add(_url(action="yt_search"), li, True)

    # Pro tebe (jen pokud ma profil neco)
    top_channels = richmovie_yt_profile.get_top_channels(1)
    if top_channels:
        li = xbmcgui.ListItem("[B]Pro tebe[/B]")
        li.setArt({"icon": "DefaultFavourites.png"})
        rmdir.add(_url(action="yt_for_you"), li, True)

    # Trendy
    li = xbmcgui.ListItem("Trendy v CR")
    li.setArt({"icon": "DefaultRecentlyAddedMovies.png"})
    rmdir.add(_url(action="yt_trending"), li, True)

    rmdir.finish()


def _yt_search() -> None:
    """Hledani na YouTube."""
    kb = xbmc.Keyboard("", "Hledat na YouTube")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return

    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"YouTube - {query}")
    xbmcplugin.setPluginCategory(HANDLE, f"YouTube - {query}")
    xbmcplugin.setContent(HANDLE, "videos")

    try:
        results = richmovie_youtube.search(query)
    except Exception as exc:
        _log(f"[YouTube] search error: {exc}", xbmc.LOGERROR)
        _net_error_ui(exc, heading="YouTube")
        rmdir.finish(succeeded=False)
        return

    # Kanaly
    for ch in results.get("channels", []):
        label = f"[B]{ch['name']}[/B]"
        if ch.get("subscribers"):
            label += f"  ({ch['subscribers']})"
        li = xbmcgui.ListItem(label)
        art = {"icon": "DefaultArtist.png"}
        if ch.get("thumb"):
            art["thumb"] = ch["thumb"]
        li.setArt(art)
        li.setInfo("video", {"title": ch["name"], "mediatype": "video"})
        rmdir.add(
            _url(action="yt_channel", channel_id=ch["channel_id"], name=ch["name"]),
            li, True,
        )

    # Videa
    for vid in results.get("videos", []):
        _yt_add_video_item(vid, rmdir)

    if not results.get("videos") and not results.get("channels"):
        _modal(f"Nic nenalezeno pro: {query}")

    rmdir.finish()


def _yt_trending() -> None:
    """Trending videa v CR."""
    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "YouTube - Trendy v CR")
    xbmcplugin.setPluginCategory(HANDLE, "YouTube - Trendy v CR")
    xbmcplugin.setContent(HANDLE, "videos")

    try:
        videos = richmovie_youtube.trending(region="CZ")
    except Exception as exc:
        _log(f"[YouTube] trending error: {exc}", xbmc.LOGERROR)
        _net_error_ui(exc, heading="YouTube")
        rmdir.finish(succeeded=False)
        return

    for vid in videos:
        _yt_add_video_item(vid, rmdir)

    rmdir.finish()


def _yt_for_you() -> None:
    """Personalizovana doporuceni na zaklade taste profilu."""
    xbmcplugin.setPluginCategory(HANDLE, "YouTube - Pro tebe")
    xbmcplugin.setContent(HANDLE, "videos")

    top_channels = richmovie_yt_profile.get_top_channels(5)
    if not top_channels:
        # Prazdny profil -> redirect na trending (vlastni RmDir sink uvnitr)
        _yt_trending()
        return

    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, "YouTube - Pro tebe")

    all_videos = []
    for ch in top_channels:
        try:
            vids, _ = richmovie_youtube.channel_videos(ch["channel_id"])
            # Max 5 poslednich z kazdeho kanalu
            all_videos.extend(vids[:5])
        except Exception:
            pass

    # Odfiltrovat uz sledovana
    filtered = [v for v in all_videos if not richmovie_yt_profile.is_watched(v["video_id"])]

    # Seradit podle poctu zhlednuti (proxy pro popularitu)
    filtered.sort(key=lambda v: v.get("views", 0), reverse=True)

    for vid in filtered[:20]:
        _yt_add_video_item(vid, rmdir)

    if not filtered:
        _modal("Zadna nova videa od oblíbenych kanalu.")

    rmdir.finish()


def _yt_channel() -> None:
    """Videa kanalu s paginaci."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    channel_id = params.get("channel_id", [""])[0]
    channel_name = params.get("name", ["YouTube"])[0]
    cont = params.get("cont", [None])[0]

    import richmovie_rmdir
    rmdir = richmovie_rmdir.RmDir(HANDLE, f"YouTube - {channel_name}")
    xbmcplugin.setPluginCategory(HANDLE, f"YouTube - {channel_name}")
    xbmcplugin.setContent(HANDLE, "videos")

    try:
        videos, next_cont = richmovie_youtube.channel_videos(channel_id, continuation=cont)
    except Exception as exc:
        _log(f"[YouTube] channel error: {exc}", xbmc.LOGERROR)
        _net_error_ui(exc, heading="YouTube")
        rmdir.finish(succeeded=False)
        return

    for vid in videos:
        _yt_add_video_item(vid, rmdir)

    # Strankovani
    if next_cont:
        li = xbmcgui.ListItem("[B]Dalsi stranka...[/B]")
        li.setArt({"icon": "DefaultFolder.png"})
        rmdir.add(
            _url(action="yt_channel", channel_id=channel_id, name=channel_name, cont=next_cont),
            li, True,
        )

    rmdir.finish()


def _yt_has_inputstream_adaptive() -> bool:
    """Zkontroluje, zda je nainstalovan inputstream.adaptive."""
    try:
        xbmcaddon.Addon("inputstream.adaptive")
        return True
    except Exception:
        return False


def _yt_play() -> None:
    """Prehrani YouTube videa pres setResolvedUrl (DASH nebo progressive)."""
    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    video_id = params.get("video_id", [""])[0]
    title = params.get("title", [""])[0]
    channel = params.get("channel", [""])[0]
    channel_id = params.get("channel_id", [""])[0]
    _fail = xbmcgui.ListItem()

    if not video_id:
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        return

    has_isa = _yt_has_inputstream_adaptive()

    try:
        stream = richmovie_youtube.resolve_stream(video_id)
    except Exception as exc:
        _log(f"[YouTube] resolve error: {exc}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        _net_error_ui(exc, heading="Přehrání")
        return

    if not stream:
        xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
        _modal("YouTube video nelze prehrat (chraneno nebo nedostupne).")
        return

    mode = stream.get("mode", "progressive")

    if mode == "dash" and has_isa:
        # DASH: MPD manifest pres HTTP localhost
        # ISA neumi cist local files ani data: URI – jediny zpusob je
        # vystavit manifest na localhost HTTP serveru (jako official YT addon).
        from http.server import HTTPServer, BaseHTTPRequestHandler

        mpd_content = stream["mpd"]
        mpd_bytes = mpd_content.encode("utf-8")

        class _MpdHandler(BaseHTTPRequestHandler):
            """Jednorazovy handler – vrati MPD a ukonci server."""
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "application/dash+xml")
                self.send_header("Content-Length", str(len(mpd_bytes)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(mpd_bytes)

            def do_HEAD(self):
                self.send_response(200)
                self.send_header("Content-Type", "application/dash+xml")
                self.send_header("Content-Length", str(len(mpd_bytes)))
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()

            def log_message(self, fmt, *args):
                _log(f"[YouTube] MPD server: {fmt % args}",
                         xbmc.LOGINFO)

        srv = HTTPServer(("127.0.0.1", 0), _MpdHandler)
        port = srv.server_address[1]
        # 3.4.7 (audit Ω1, 2026-05-17, post-audit revert): daemon=True kept
        # for this specific case. Memory rule `feedback_daemon_threads_kodi.md`
        # bans daemon=True for threads that WRITE state (HTTP client fetches
        # that mutate JSON files, cache writes, etc.) because force-kill mid-
        # write corrupts state. THIS thread is a pure SERVING thread for
        # localhost MPD bytes — no disk writes, no persistent state. Port
        # leak on Kodi exit is acceptable because Kodi process death releases
        # all ports. Non-daemon would block Kodi exit indefinitely (HTTPServer
        # serve_forever has no internal abort listener).
        # Original post-audit feedback: post-audit Agent flagged this as
        # "worse than original" — correct, daemon=False without shutdown()
        # wire blocks Kodi exit. Reverting to documented exception.
        srv_thread = threading.Thread(target=srv.serve_forever, daemon=True, name="YTMpdServer")
        srv_thread.start()
        _log(f"[YouTube] MPD server started on port {port}",
                 xbmc.LOGINFO)

        mpd_url = f"http://127.0.0.1:{port}/manifest.mpd"
        li = xbmcgui.ListItem(path=mpd_url)
        li.setMimeType("application/dash+xml")
        li.setContentLookup(False)
        li.setProperty("inputstream", "inputstream.adaptive")
        quality = stream.get("quality", "")
        _log(f"[YouTube] DASH playback: {quality} via inputstream.adaptive",
                 xbmc.LOGINFO)

    else:
        # Progressive fallback (360p) — pokud ISA neni dostupny
        play_url = stream.get("url", "")
        if not play_url and mode == "dash":
            _log("[YouTube] inputstream.adaptive neni dostupny, "
                     "pouzivam progressive (360p)", xbmc.LOGINFO)
            try:
                fallback = richmovie_youtube.resolve_stream_progressive(video_id)
                if fallback:
                    play_url = fallback["url"]
            except Exception:
                pass
        if not play_url:
            xbmcplugin.setResolvedUrl(HANDLE, False, _fail)
            _modal("YouTube video nelze prehrat.")
            return
        li = xbmcgui.ListItem(path=play_url)

    li.setInfo("video", {
        "title": title,
        "studio": channel,
        "mediatype": "video",
    })
    li.setProperty("richmovie.source", "youtube")
    li.setArt({
        "thumb":  f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
        "fanart": f"https://i.ytimg.com/vi/{video_id}/maxresdefault.jpg",
    })
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

    # Zaznamenat sledovani (fire-and-forget)
    try:
        richmovie_yt_profile.record_watch(video_id, channel_id, channel, title)
    except Exception:
        pass


def _yt_add_video_item(vid: dict, rmdir) -> None:
    """Helper: prida YouTube video polozku do directory listingu (sink = RmDir volajiciho)."""
    duration = vid.get("duration", 0)
    views = vid.get("views", 0)
    channel = vid.get("channel", "")
    published = vid.get("published", "")

    # Label: nazev + metadata
    label = vid["title"]
    label2_parts = []
    if channel:
        label2_parts.append(channel)
    if duration:
        label2_parts.append(richmovie_youtube.format_duration(duration))
    if views:
        label2_parts.append(f"{richmovie_youtube.format_views(views)} zhlednuti")
    if published:
        label2_parts.append(published)
    label2 = " | ".join(label2_parts)

    li = xbmcgui.ListItem(label)
    if label2:
        li.setLabel2(label2)
    art = {"icon": "DefaultVideo.png"}
    if vid.get("thumb"):
        art["thumb"] = vid["thumb"]
    li.setArt(art)
    li.setInfo("video", {
        "title": vid["title"],
        "duration": duration,
        "studio": channel,
        "mediatype": "video",
    })

    if vid.get("is_live"):
        # LIVE streamy: neaktivní řádek (MVP nepodporuje). R3-P3-1: url=""
        # — dřív target yt_home otevíral v custom listu DALŠÍ YouTube okno
        # (a v legacy skákal zpět na YT home); prázdný target = klik no-op.
        li.setLabel(f"[COLOR red]LIVE[/COLOR] {label}")
        rmdir.add("", li, False)
    else:
        li.setProperty("IsPlayable", "true")
        rmdir.add(
            _url(action="yt_play", video_id=vid["video_id"],
                 title=vid["title"], channel=channel,
                 channel_id=vid.get("channel_id", "")),
            li, False,
        )


# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# main  (vytvořeno: 29.09.2026 14:40 CEST, Europe/Prague — dřív blok `if __name__ == '__main__'`
#        z 28.12.2025)
# ---------------------------------------------------------------------------- #
def _reset_base_to_home() -> None:
    """Φ-NOFLASH (13.06.2026): custom okno (WindowXMLDialog) se kreslí NAD základním oknem Kodi — zůstal-li základem
    adresář Videos, reset na skin Home (krátké omezené čekání, ať se dialog nevykreslí přes Videos). Idempotentní;
    JEDINÉ místo (vstup do custom oken nového vzhledu i okno Televize)."""
    try:
        _WIN_VIDEO_NAV, _WIN_HOME = 10025, 10000  # Kodi core window IDs (skin-agnostic)
        if xbmcgui.getCurrentWindowId() == _WIN_VIDEO_NAV:
            xbmc.executebuiltin("ActivateWindow(home)")
            for _ in range(30):  # max ~600 ms
                if xbmcgui.getCurrentWindowId() == _WIN_HOME:
                    break
                xbmc.sleep(20)
    except Exception:
        pass


def main(t0: Optional[float] = None, activity_token: Optional[str] = None) -> None:
    """Vstup invokace pluginu: diagnostika, prolog (UI režim, onboarding lokalizace, breadcrumb,
    debounce custom oken) a dispatch akce.

    Φ0 (29.09.2026): dřív top-level blok `__main__`. Jako funkce (1) zapíše konec akce VŽDY —
    `finally` volá `end_action(ok=…)` i při výjimce (dřív výjimka nechala viset crash sentinel
    a příští proces hlásil falešný `PRIOR_SESSION_UNCLEAN_EXIT … (nativní pád?)`, audit A03 F9),
    (2) je připravená pro tenký spouštěč (Φ4), který importuje `plugin` z cache `.pyc`.

    `params` a `action` zůstávají modulové proměnné (čte je řada funkcí, např.
    `_continue_watching_action`, `_page_param`).
    """
    global params, action
    _t0 = _RM_T0 if t0 is None else float(t0)
    # 21.02.2026 – Crash reporting (sys.excepthook → GitHub Issues)
    try:
        import richmovie_crash
        richmovie_crash.install(source="plugin")
    except Exception:
        pass

    # ── 2026-07-01: Breadcrumb diagnostika NATIVNÍCH pádů Kodi ───────────────
    # sys.excepthook (výše) chytá jen Python výjimky. Nativní pád (segfault/OOM
    # na Androidu) zabije proces POD Pythonem → žádný traceback. Breadcrumb píše
    # durable stopu (fsync per záznam) přes log pipeline + „crash sentinel"; když
    # proces nativně zemře uprostřed akce, sentinel zůstane viset a příští proces
    # ho nahlásí jako PRIOR_SESSION_UNCLEAN_EXIT. Detaily: richmovie_breadcrumb.py.
    try:
        import richmovie_breadcrumb as _bc
        _bc.detect_prior_crash()   # ohlásí, jestli minulý proces skončil čistě
    except Exception:
        _bc = None

    params = dict(parse_qs(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get("action", ["root"])[0]

    # 4.0.2: Kodi nechává postavit VÝPIS → odložená obnova téhož výpisu (akce na klik při přehrávání) je tímhle
    # vyřízená — data se čtou až teď, po změně (`richmovie_playback_dispatch.note_listing_build`). Jen adresářové akce
    # podle registru: akce na klik (handle −1) výpis nestaví.
    try:
        if _rm_routes.kind(action) == _rm_routes.DIR:
            _rm_dispatch.note_listing_build(_rm_listing.current_listing_key())
    except Exception:
        pass

    # Zahodilo Kodi minulý listing? (Φ6, 3.5.153)
    # Tady už je `Container.FolderPath` usazená, takže se dá porovnat s otiskem,
    # který zapsal předchozí `_list_releases`. Čistě diagnostika — nic nemění.
    try:
        _w_drop = xbmcgui.Window(10000)
        _pub = _w_drop.getProperty("richmovie.listing.published") or ""
        if _pub:
            _verdict = _rm_listing.dropped_verdict(
                _pub,
                xbmc.getInfoLabel("Container.FolderPath") or "",
                time.monotonic(),
            )
            _w_drop.clearProperty("richmovie.listing.published")
            if _verdict:
                _log_event("LISTING_DROPPED", _verdict)
                # Φ0: i do user_logs (dřív jen lokální soubor, viz LISTING_NOT_LANDED)
                _log(f"LISTING_DROPPED {_verdict}", xbmc.LOGWARNING)
    except Exception:
        pass

    # Breadcrumb: start akce (zapíše sentinel + durable „TRACE ... phase=begin").
    # Brackuje i pre-dispatch setup níže (custom-window/NOFLASH), aby i případný
    # pád tam byl lokalizovatelný. Čistý konec = end_action() za dispatch chainem.
    if _bc is not None:
        try:
            _bc.begin_action(action, params,
                             import_ms=int((time.monotonic() - _t0) * 1000))
        except Exception:
            pass

    # ── RmDir SSOT: 1× per invokaci ulož autoritativní UI režim do window
    # property. richmovie_rmdir.RmDir ho čte (bez importu plugin.py → žádný
    # cyklus), aby long-tail obrazovky renderovaly custom okno vs Kodi directory.
    try:
        xbmcgui.Window(10000).setProperty(
            "richmovie.rm_new_ui", "1" if _rm_new_ui() else "0")
    except Exception:
        pass

    # Průvodce „zvuk a titulky“ (jednou po instalaci/změně průvodce) je od Φ3 (29.09.2026) krokem
    # uvítací sekvence `localization` v `_root` (a vstupem do RM 4.0 `home_window`) — dřív běžel
    # z prologu KAŽDÉ akce, před přihlášením a mimo claim sekvence (audit A07 F12).

    # Phase G1 TMDb legacy key sentinel — vydá WARN když settings.xml drží
    # tmdb_api_key bez Gate-sync timestampu (typicky legacy per-user klíč
    # z období před Phase 3g). Gate při úspěšném auth klíč přepíše a
    # timestamp vyplní, takže sentinel po dalším startu odmlkne.
    try:
        # R3-P2-9: sentinel čte RAW lokální setting — jeho sémantika je výslovně
        # „co je v settings.xml". SSOT accessor (Gate fallback, 3.5.69/86) tady
        # vracel i klíč z Gate lease cache → falešný WARNING na čisté instalaci.
        _tk_present = (richmovie_settings.get_str("tmdb_api_key") or "").strip()
        _tk_sync = (richmovie_settings.get_str("_tmdb_key_gate_synced_at") or "").strip()
        if _tk_present and not _tk_sync:
            _log(
                "[Sentinel] Legacy tmdb_api_key v settings.xml bez "
                "Gate-sync timestampu. Bude přepsán při dalším Gate /auth. "
                "Doporučeno neukládat TMDb klíč manuálně (Gate je SSOT).",
                xbmc.LOGWARNING,
            )
    except Exception:
        pass


    # ── P0-1 (2026-06-13): breadcrumb „‹ Zpět do RichMovie" ──────────────────
    # Container-leaf z custom hubu (Kolekce/Historie/Zdroje/NAS) složí dialog
    # stack přes goto_container → Back by skončil v Kodi home, ne v RM.
    # Dokud je marker rm_from_hub aktivní, KAŽDÝ directory list dostane nahoře
    # cestu zpět do custom UI. Φ1 (2026-07-06, audit A04/A05): hodnota markeru
    # = plugin URL rodičovské routy (předává goto_container) → breadcrumb vrací
    # PŘESNĚ do okna, odkud se odešlo (např. Hub Zdroje); legacy hodnota "1"
    # = home_window. Marker se ruší při vstupu do KTERÉHOKOLI custom okna
    # (dřív jen home/root — breadcrumb do hubu by se jinak nikdy nezrušil).
    _CUSTOM_WIN_ACTIONS = ("home_window", "rm_streams", "rm_detail",
                           "rm_episodes", "rm_grid", "rm_hub", "rm_search")
    if action in _CUSTOM_WIN_ACTIONS or action == "root":
        try:
            xbmcgui.Window(10000).clearProperty("richmovie.rm_from_hub")
        except Exception:
            pass
    elif _rm_new_ui():
        try:
            _from_hub = (xbmcgui.Window(10000).getProperty("richmovie.rm_from_hub") or "")
            if _from_hub:
                # POZOR: NEpojmenovat `_bc` — to je modulový alias breadcrumb
                # diagnostiky (import výše); kolize by shadowovala end_action()
                # → sentinel by zůstal viset → falešný PRIOR_SESSION_UNCLEAN_EXIT.
                _back_target = (_from_hub if _from_hub.startswith("plugin://")
                                else _url(action="home_window"))
                _back_li = xbmcgui.ListItem("‹ Zpět do RichMovie")
                _back_li.setArt({"icon": "DefaultFolderBack.png", "thumb": "DefaultFolderBack.png"})
                xbmcplugin.addDirectoryItem(HANDLE, _back_target, _back_li, isFolder=False)
        except Exception:
            pass

    # ── Φ1 (2026-07-06): nav debounce — dvojklik = dvě identické invokace =
    # dvě okna nad sebou (z-order pak mate Back). Duplicitní (akce+parametry)
    # invokace do 1,2 s jde do noop větve rm_nav_debounced (NE return —
    # end_action() breadcrumbu na konci dispatch chainu MUSÍ proběhnout,
    # jinak falešný PRIOR_SESSION_UNCLEAN_EXIT). rm_streams vynechán — picker
    # má vlastní token/play_debounce lifecycle.
    if action in _CUSTOM_WIN_ACTIONS and action != "rm_streams":
        try:
            import richmovie_ui_common as _uc_nav
            _nav_key = action + "|" + "&".join(
                f"{_k}={_v[0]}" for _k, _v in sorted(params.items()) if _v)
            if not _uc_nav.nav_debounce(_nav_key):
                _log(f"[NavStack] duplicitní invokace ignorována: {_nav_key}",
                     xbmc.LOGINFO)
                action = "rm_nav_debounced"
        except Exception:
            pass

    # ── Φ-NOFLASH (2026-06-13): „okno s doplňky" nesmí probliknout ───────────
    # Custom UI okna jsou WindowXMLDialog kreslené NAD základním Kodi oknem.
    # Long-tail destinace (Historie/Zdroje/CSFD/NAS/Stahování) se otevírají přes
    # goto_container → `ActivateWindow(Videos,…)` → reálné Kodi Videos/„Doplňky"
    # okno se stane ZÁKLADEM. Návrat do custom Home (breadcrumb) otevře Home dialog
    # NAD tím Videos oknem; klik „Pokračovat" Home dialog zavře (self.close) → Videos
    # okno se na okamžik odhalí = problikne „okno s doplňky". ROOT CAUSE FIX (SSOT):
    # při KAŽDÉM vstupu do custom okna, pokud základ zůstal Kodi Videos directory,
    # resetuj ho na skin Home (s krátkým bounded waitem, ať se Home dialog nevykreslí
    # přes Videos). Idempotentní — na hot-path (základ už Home) je to no-op.
    # (_CUSTOM_WIN_ACTIONS definováno výše u breadcrumb/debounce bloku — Φ1.)
    if action in _CUSTOM_WIN_ACTIONS:
        _reset_base_to_home()


    # ── Breadcrumb: konec akce (Φ0: VŽDY, i při výjimce) ─────────────────────
    # Smaže crash sentinel + durable „TRACE … phase=end ok=… ms=… settings_reads=…“.
    # Pokud Kodi nativně spadne uvnitř dispatche, `finally` se neprovede → sentinel zůstane
    # a příští proces vydá PRIOR_SESSION_UNCLEAN_EXIT (to je jediný případ, kdy má vzniknout).
    _ok = False
    # Φ3 (29.09.2026): značka „menu se staví“ (fronta obnov výpisu ho mezitím nepřekreslí). Že menu vykreslilo
    # čerstvá data, pozná fronta ze značky stavby výpisu (`note_listing_build` výše, S18). SSOT `richmovie_onboarding`.
    _root_mark = None
    # Φ4 (29.09.2026): „uživatel právě kliká“ — práce na pozadí ve službě během invokace ustoupí
    # (`richmovie_activity`; sdílený GIL: souběh zvedal import 410 → 1 133 ms, audit A08 F5).
    # 4.0.1 (audit Fable F-2): spouštěč `default.py` značku zapisuje už PŘED importem pluginu a předá token —
    # tady se převezme (vlastní značka jen při spuštění bez spouštěče, např. harness).
    try:
        import richmovie_activity as _rm_activity
        _activity_tok = activity_token or _rm_activity.note_invocation_begin()
    except Exception:
        _activity_tok = activity_token
    if action == "root":
        try:
            import richmovie_onboarding as _ob_mark
            _root_mark = _ob_mark.note_root_begin()
        except Exception:
            _root_mark = None
    try:
        _dispatch_action(action)
        _ok = True
    finally:
        if _root_mark is not None:
            try:
                _ob_mark.note_root_end(_root_mark)
            except Exception:
                pass
        if _activity_tok is not None:
            try:
                _rm_activity.note_invocation_end(_activity_tok)
            except Exception:
                pass
        if _bc is not None:
            try:
                _bc.end_action(ok=_ok, settings_reads=richmovie_settings.addon_instances())
            except Exception:
                pass


# ---------------------------------- FUNKCE ---------------------------------- #
# plugin.py
# _dispatch_action  (vytvořeno: 29.09.2026 14:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _dispatch_action(action: str) -> None:
    """Řetěz akcí pluginu (beze změny obsahu; jen přesunutý z bloku `__main__`, Φ0)."""
    if action == "root":
        # ── RM 4.0 CUTOVER ── Výchozí vstup = CUSTOM HOME okno (NE staré Kodi menu).
        # Escape hatch: rm_classic_ui=true → staré directory menu.
        #
        # Φ-A2 (2026-06-12, incident „Videa problikává"): vstup z Kodi menu otevře
        # VIDEOS window s plugin adresářem. Dřív jsme Home otevřeli v TOMHLE
        # invokeru → pod všemi custom okny celou session ležel Videos window
        # s failed listingem („Videa / Soubory / Doplňky videí") a problikával
        # při každém zavření oken (přehrávání, přechody). FIX: directory request
        # okamžitě ukončit, Videos window OPUSTIT (ActivateWindow(home) = branded
        # skin home) a custom Home otevřít v novém invokeru NAD skin home.
        # M1: osvěž Gate cache PŘED rozhodnutím (custom flow jinak gate_auth nevolá).
        _ensure_gate_cache_fresh()
        # Custom UI JEN když: není classic, není ?classic=1, a účet má povolení
        # (Gate per-user gate — rodina bez custom_ui → legacy directory menu).
        if (not _rm_new_ui()) or params.get("classic", [""])[0] == "1":
            _log_ui_decision("legacy")  # telemetrie do Gate (observability pojistky)
            _root()
        else:
            _log_ui_decision("custom")
            try:
                if xbmcgui.getCurrentWindowId() != 10000:
                    xbmc.executebuiltin("ActivateWindow(home)")
            except Exception:
                pass
            try:
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
            except Exception:
                pass
            xbmc.executebuiltin(f"RunPlugin({_url(action='home_window')})")

    # — LOKÁLNÍ SOUBORY (LAN / SMB) —
    elif action == "local_root":
        _local_root()
    elif action == "ws_limit_probe":
        # Φ-C (D4, Richie 29.09.2026): jednorázové MĚŘENÍ přes RunPlugin — nic nemění (HANDLE = -1)
        try:
            _ws_limit_probe((params.get("q", [""])[0] or "").strip())
        except Exception as _e_lp:
            _log(f"WS_LIMIT_PROBE failed: {_e_lp!r}", xbmc.LOGWARNING)
    elif action == "silent_auth":
        # 3.5.141 (cross-check T2 Pro P4): zotavení identity vyžádané SLUŽBOU (REJECTED
        # uprostřed maratonu). `/auth` smí volat jen plugin — služba ho spustí přes RunPlugin.
        try:
            _gate_auth_silent()
        except Exception as _e_sa:
            _log(f"silent_auth failed: {_e_sa!r}", xbmc.LOGWARNING)
        # RunPlugin routa (HANDLE = -1): žádný endOfDirectory — Kodi by logoval ERROR
        # „invalid handle" každých 30 min v REJECTED (Fable P3-6); stejně jako `profile_choose`.
    elif action == "profile_av_prefs":
        # 3.5.155: zvuk a titulky PRO TENTO PROFIL (title_prefs `_global`, synchronizuje se)
        try:
            _loc_module.ask_profile_prefs(force=True)
        except Exception as _e_av:
            _log(f"profile_av_prefs error: {_e_av}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    elif action == "profile_choose":
        # 3.5.134: chooser z hlavního menu (RunPlugin-like: bez adresáře)
        try:
            import richmovie_profile_ui
            richmovie_profile_ui.request_chooser_now()
        except Exception as _e_pf:
            _log(f"profile_choose error: {_e_pf}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    elif action == "profile_settings":
        try:
            import richmovie_profile_ui
            richmovie_profile_ui.show_manage_dialog()
        except Exception as _e_pf:
            _log(f"profile_settings error: {_e_pf}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    elif action == "local_browse":
        _local_browse()
    elif action == "local_play":
        _local_play()

    # — CSFD profil (Phase B8, RichMovie 3.2.0) —
    elif action == "csfd_settings":
        try:
            import richmovie_csfd_client
            richmovie_csfd_client.show_csfd_settings_dialog()
        except Exception as _e_csfd:
            _log(f"csfd_settings error: {_e_csfd}", xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
    elif action == "csfd_sync_now":
        try:
            import richmovie_csfd_client
            richmovie_csfd_client.show_csfd_sync_now_action()
        except Exception as _e_csfd_sync:
            _log(f"csfd_sync_now error: {_e_csfd_sync}",
                     xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

    # — Moje CSFD browser (Phase B11, 3.2.0-beta.2) —
    elif action == "csfd_my_root":
        try:
            import richmovie_csfd_browser
            richmovie_csfd_browser.show_my_csfd_root()
        except Exception as _e_my_csfd:
            _log(f"csfd_my_root error: {_e_my_csfd}",
                     xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "my_ratings_local":
        # 3.5.152 (Petra Φ3): hodnocení zadaná v RichMovie (i bez ČSFD)
        try:
            import richmovie_csfd_browser
            richmovie_csfd_browser.show_my_richmovie_ratings()
        except Exception as _e_my_rl:
            _log(f"my_ratings_local error: {_e_my_rl}", xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "clear_rating":
        try:
            _kind = (params.get("kind") or ["movie"])[0]
            _tid = int((params.get("tmdb_id") or ["0"])[0] or 0)
            if richmovie_ratings.clear_rating(_kind, _tid):
                _rm_notif("Hodnocení smazáno", xbmcgui.NOTIFICATION_INFO, 2500, "RichMovie", sound=False)
                _rm_dispatch.refresh_container("clear_rating")
        except Exception as _e_clr:
            _log(f"clear_rating error: {_e_clr}", xbmc.LOGERROR)
    elif action == "csfd_my_ratings":
        try:
            import richmovie_csfd_browser
            richmovie_csfd_browser.show_my_ratings(page=_page_param(default=0, lo=0, hi=1000))
        except Exception as _e_my_r:
            _log(f"csfd_my_ratings error: {_e_my_r}",
                     xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "csfd_my_watchlist":
        try:
            import richmovie_csfd_browser
            richmovie_csfd_browser.show_my_watchlist(page=_page_param(default=0, lo=0, hi=1000))
        except Exception as _e_my_w:
            _log(f"csfd_my_watchlist error: {_e_my_w}",
                     xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "csfd_my_top_rated":
        try:
            import richmovie_csfd_browser
            richmovie_csfd_browser.show_my_top_rated(page=_page_param(default=0, lo=0, hi=1000))
        except Exception as _e_my_t:
            _log(f"csfd_my_top_rated error: {_e_my_t}",
                     xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "csfd_my_resolve":
        try:
            import richmovie_csfd_browser
            richmovie_csfd_browser.trigger_resolve_now()
        except Exception as _e_my_resolve:
            _log(f"csfd_my_resolve error: {_e_my_resolve}",
                     xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

    # — DOPORUČENÍ PŘESNĚ PRO VÁS (Phase E, RichMovie 3.1.0) —
    elif action == "show_recommendations":
        try:
            import richmovie_recommendations
            richmovie_recommendations.show_listing(HANDLE, ADDON)
        except Exception as _e_rec:
            _log(f"show_recommendations error: {_e_rec}",
                     xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "dismiss_recommendation":
        # 3.5.131 (plán R6): „Nezajímá mě" z kontextového menu → Gate /dismiss,
        # titul zmizí ze seznamu a 180 dní se nevrací do poolu.
        try:
            import richmovie_recommendations
            richmovie_recommendations.trigger_dismiss(
                int((params.get("recommendation_id") or ["0"])[0]),
                title=(params.get("title") or [""])[0],
            )
        except Exception as _e_dis:
            _log(f"dismiss_recommendation error: {_e_dis}", xbmc.LOGERROR)
    elif action == "seen_recommendation":
        # 3.5.152 (Petra, plán Φ1): „Už jsem to viděl" → Gate reason=already_seen (navždy) + ✔ filmu
        try:
            import richmovie_recommendations
            richmovie_recommendations.trigger_seen(
                int((params.get("recommendation_id") or ["0"])[0]),
                tmdb_id=int((params.get("tmdb_id") or ["0"])[0] or 0),
                kind=(params.get("kind") or ["movie"])[0],
                title=(params.get("title") or [""])[0],
            )
        except Exception as _e_seen:
            _log(f"seen_recommendation error: {_e_seen}", xbmc.LOGERROR)
    elif action == "rate_title":
        # 3.5.152 (plán Φ3): ruční hodnocení ★ z kontextového menu (doporučení, historie sledování)
        try:
            import richmovie_rating_ui
            richmovie_rating_ui.rate_from_menu(
                kind=(params.get("kind") or ["movie"])[0],
                tmdb_id=int((params.get("tmdb_id") or ["0"])[0] or 0),
                title=(params.get("title") or [""])[0],
            )
        except Exception as _e_rate:
            _log(f"rate_title error: {_e_rate}", xbmc.LOGERROR)
    elif action == "regenerate_recommendations":
        try:
            import richmovie_recommendations
            richmovie_recommendations.trigger_regenerate(ADDON)
        except Exception as _e_reg:
            _log(f"regenerate error: {_e_reg}", xbmc.LOGERROR)
        # No directory rendering — fire-and-forget action
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
    elif action == "open_recommendation":
        # User clicked a rec → record click + delegate to TMDb-driven search.
        # Use action=auto (TMDb id) — _auto_search_movie skips input dialog
        # and directly drives Webshare search using TMDb metadata. This is
        # the same flow as clicks from "Trendy" / "Top filmy" / TV tipy.
        try:
            import richmovie_recommendations
            rec_id_raw = (params.get("recommendation_id", ["0"])[0] or "0").strip()
            try:
                rec_id = int(rec_id_raw)
            except ValueError:
                rec_id = 0
            title = (params.get("title", [""])[0] or "").strip()
            kind  = (params.get("kind",  ["movie"])[0] or "movie").strip()
            tmdb_raw = (params.get("tmdb_id", [""])[0] or "").strip()
            try:
                tmdb_id = int(tmdb_raw) if tmdb_raw else 0
            except ValueError:
                tmdb_id = 0

            # Klik se zapocitava JEN pri skutecnem kliku uzivatele.
            # `Container.Refresh` od MI2 spusti tuhle akci znovu se stejnym URL —
            # do 3.5.152 se tim kazdy klik na Gate poslal vickrat (dedup drzel
            # modulovy dict, ktery je v novem interpretu vzdycky prazdny).
            _is_mi2_refresh = False
            try:
                _w = xbmcgui.Window(10000)
                _is_mi2_refresh = _rm_listing.plan_listing(
                    cur_key=_rm_listing.current_listing_key(),
                    marker_reason=(_w.getProperty("richmovie.mi2.refresh_reason") or ""),
                    marker_key=(_w.getProperty("richmovie.mi2.refresh_key") or ""),
                    has_releases=True,
                    mi2_running_here=False,
                    mi2_thread_alive=False,
                ).is_refresh_call
            except Exception:
                _is_mi2_refresh = False

            # Návrat do seznamu (Zpět z přehrávání, znovuotevření) spouští tuhle akci
            # znovu se stejným URL — to NENÍ nový klik. Poznává se stejně jako v
            # `_auto_search_movie`: marker „listing pro tenhle titul už v této session vznikl".
            # SSOT markeru = `richmovie_recommendations.note_opened` (maže ho vykreslení seznamu).
            _is_reentry = richmovie_recommendations.note_opened(rec_id)

            if richmovie_recommendations.should_record_click(
                    rec_id, is_mi2_refresh=_is_mi2_refresh, is_reentry=_is_reentry):
                richmovie_recommendations.record_click(rec_id, search_query=title)

            # Direct TMDb-driven search (no input dialog).
            if tmdb_id > 0:
                if kind == "tv":
                    # TV: delegate to seasons listing (same as TV tip click)
                    # `_tv_seasons_from_tmdb` nikdy neexistovala, takže seriál padal
                    # do `_auto_search_movie` se SERIÁLOVÝM id → cizí film (audit Fable F-A).
                    _tv_seasons(tv_id_arg=str(tmdb_id), tv_name_arg=title)
                else:
                    _auto_search_movie(tmdb_id)
            else:
                # Fallback (no tmdb_id) — use title-based search
                if kind == "tv":
                    params["action"] = ["tv_search"]
                    params["q"] = [title]
                    _tv_search()
                else:
                    params["action"] = ["movie_search"]
                    params["q"] = [title]
                    _movie_search()
        except Exception as _e_open:
            _log(f"open_recommendation error: {_e_open}",
                     xbmc.LOGERROR)
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "delete_ai_history":
        # Settings → Privacy → Smazat AI historii (Phase G GDPR)
        try:
            import richmovie_recommendations
            richmovie_recommendations.trigger_delete_all(ADDON)
        except Exception as _e_del:
            _log(f"delete_ai_history error: {_e_del}",
                     xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

    # — FILMY —
    elif action == "movie_search":
        _movie_search()


    # — SERIÁLY —
    elif action == "tv_search":
        _tv_search()
    elif action == "tv_seasons":
        _tv_seasons()
    elif action == "tv_episodes":
        _tv_episodes()
    elif action == "tv_play":
        _tv_play()
    elif action == "tv_next_episode":
        _tv_next_episode()

    # — RICHMOVIE A.I. —  (alias pro starší odkazy i hlavní menu)
    elif action in ("ai_menu", "ai_recommend"):
        _ai_menu()
    elif action == "ai_identify":
        _q = (params.get("q", [""])[0] or "").strip()
        if _q:
            _ai_identify_show(_q)
        else:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == "ai_recommend_results":
        _q = (params.get("q", [""])[0] or "").strip()
        _kind = (params.get("kind", ["any"])[0] or "any").strip()
        if _q:
            _ai_recommend_show(_kind, _q)
        else:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)

    # — WEBSHARE / HISTORIE —
    elif action == "ws_search":
        _ws_search()
    elif action == "music_search":
        _music_search()
    elif action == "music_item":
        _music_item()
    elif action == "history":
        _show_history()
    elif action == "history_category":
        _show_history_category()
    elif action == "history_clear":
        _history_clear()
        _rm_dispatch.refresh_container("history_clear")
    elif action == "watch_history":
        _watch_history()
    elif action == "continue_watching":
        _continue_watching_action()
    elif action == "cw_list":
        _continue_watching_list()
    elif action == "ep_mark_watched":
        _ep_watched_action(mark=True)
    elif action == "ep_unmark_watched":
        _ep_watched_action(mark=False)
    elif action == "cw_remove":
        _cw_remove_action()
    elif action == "play_from_start":
        _play_from_start_action()
    elif action == "cw_clear":
        _cw_clear_action()
    elif action == "recent_series":
        _recent_series()
    elif action == "rail_cw":            # RM 4.0 Home rail (widget-safe)
        _rail_continue_watching()
    elif action == "rail_recent_series":  # RM 4.0 Home rail (widget-safe)
        _rail_recent_series()
    elif action == "rail_collections":    # RM 4.0 Home rail (widget-safe)
        _rail_collections()
    elif action == "rail_ai":             # RM 4.0 Home rail (widget-safe, cached)
        _rail_ai()
    elif action == "home_window":         # RM 4.0 custom UI okno (WindowXMLDialog)
        # RM 4.0 nemá uvítací sekvenci `_root`; průvodce zvuk/titulky (dřív z prologu každé akce)
        # proto dostane tady, na vstupu do domovského okna (Φ3, 29.09.2026).
        try:
            _ensure_localization_onboarding()
        except Exception:
            pass
        try:
            import richmovie_home_window
            richmovie_home_window.open_home(ADDON)
        except Exception as _hw_e:
            # auto-fallback: neztratit přístup k addonu → klasické directory menu
            _log(f"[Home] router selhal → fallback klasika: {_hw_e}",
                     xbmc.LOGWARNING)
            try:
                xbmc.executebuiltin(
                    f'ActivateWindow(Videos,"{_url(action="root", classic="1")}",return)')
            except Exception:
                pass
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass
    elif action == "rm_streams":          # RM 4.0 custom Stream-picker (WindowXMLDialog)
        try:
            import richmovie_streams_window
            richmovie_streams_window.open_streams(
                ADDON, token=params.get("rm_token", [""])[0])
        except Exception as _sw_e:
            _log(f"[Streams] router: {_sw_e}", xbmc.LOGWARNING)
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass
    elif action == "rm_detail":           # RM 4.0 custom Detail / title page (WindowXMLDialog)
        try:
            import richmovie_detail_window
            richmovie_detail_window.open_detail(
                ADDON,
                tmdb_id=params.get("tmdb_id", [""])[0],
                kind=params.get("kind", ["movie"])[0],
                title=params.get("title", [""])[0],
            )
        except Exception as _dw_e:
            _log(f"[Detail] router: {_dw_e}", xbmc.LOGWARNING)
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass
    elif action == "rm_grid":             # RM 4.0 reusable Browse grid (WindowXMLDialog)
        try:
            import richmovie_grid_window
            richmovie_grid_window.open_grid(
                ADDON,
                feed=params.get("feed", [""])[0],
                title=params.get("title", [""])[0],
                q=params.get("q", [""])[0],
                genre_id=params.get("genre_id", [""])[0],
                ref_id=params.get("ref_id", [""])[0],
            )
        except Exception as _gw_e:
            _log(f"[Grid] router: {_gw_e}", xbmc.LOGWARNING)
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass
    elif action == "rm_episodes":         # RM 4.0 custom Episodes okno (seriály)
        try:
            import richmovie_episodes_window
            richmovie_episodes_window.open_episodes(
                ADDON, tv_id=params.get("tv_id", [""])[0], tv_name=params.get("tv_name", [""])[0])
        except Exception as _ep_e:
            _log(f"[Episodes] router: {_ep_e}", xbmc.LOGWARNING)
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass
    elif action == "rm_hub":              # RM 4.0 generic Hub okno (Moje/Zdroje)
        try:
            import richmovie_hub_window
            richmovie_hub_window.open_hub(ADDON, hub=params.get("hub", [""])[0])
        except Exception as _hb_e:
            _log(f"[Hub] router: {_hb_e}", xbmc.LOGWARNING)
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass
    elif action == "rm_search":           # RM 4.0 custom Hledat — VLASTNÍ klávesnice + live výsledky
        _search_kind = (params.get("kind", [""])[0] or "all").strip().lower()
        _search_q = (params.get("q", [""])[0] or "").strip()  # R2-P2-7 replay pre-fill
        try:
            import richmovie_search_window
            richmovie_search_window.open_search(ADDON, kind=_search_kind, q=_search_q)
        except Exception as _se:
            # fallback: systémová klávesnice → grid (nikdy neztratit hledání)
            _log(f"[Search] custom okno selhalo → fallback: {_se}",
                     xbmc.LOGWARNING)
            try:
                _kb_title = {"movie": "Hledat film", "tv": "Hledat seriál"}.get(
                    _search_kind, "Hledat film nebo seriál")
                _feed = {"movie": "search_movies", "tv": "search_tv"}.get(
                    _search_kind, "search_all")
                _q = xbmcgui.Dialog().input(_kb_title, type=xbmcgui.INPUT_ALPHANUM)
                if _q and _q.strip():
                    import richmovie_grid_window
                    richmovie_grid_window.open_grid(ADDON, feed=_feed,
                                                    title=f"Hledat: {_q.strip()}", q=_q.strip())
            except Exception as _se2:
                _log(f"[Search] fallback: {_se2}", xbmc.LOGWARNING)
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass

    elif action == "watch_history_movies":
        _watch_history_movies()
    elif action == "watch_history_tv":
        _watch_history_tv()
    elif action == "watch_history_clear":
        _watch_history_clear()
        # Po smazání přepnout zpět na výběr kategorií (ať UI hned sedí)
        try:
            xbmc.executebuiltin(f'Container.Update("{_url(action="watch_history")}", replace)')
        except Exception:
            _rm_dispatch.refresh_container("watch_history_clear")


    # — KOLEKCE —
    elif action == "collections":
        CollectionsUI.show_collections_root(ADDON, HANDLE)
    elif action == "collections_browse":
        _file = params.get("file", [""])[0]
        _node = params.get("node", [""])[0]
        # Zápis do historie hledání (jen root úroveň kolekce, ne vnořená navigace)
        if _file and not _node:
            try:
                _cdata = CollectionsUI._load_json(_file)
                _ctitle = (_cdata.get("title") or "") if isinstance(_cdata, dict) else ""
                if _ctitle:
                    _add_to_history(f"{_ctitle}||{_file}", category="collections")
            except Exception:
                pass
        try:
            # novější verze (tree kolekce)
            CollectionsUI.browse_collection(_file, ADDON, HANDLE, _node)
        except TypeError:
            # starší verze (flat kolekce)
            CollectionsUI.browse_collection(_file, ADDON, HANDLE)

    elif action == "collections_tv":
        _file = params.get("file", [""])[0]
        _tv_id = params.get("tv_id", [""])[0]
        _tv_name = params.get("tv_name", [""])[0]
        _node = params.get("node", [""])[0]
        try:
            # novější verze (tree kolekce)
            CollectionsUI.browse_tv(_file, _tv_id, _tv_name, ADDON, HANDLE, _node)
        except TypeError:
            # starší verze
            CollectionsUI.browse_tv(_file, _tv_id, _tv_name, ADDON, HANDLE)



    # — ČSFD.cz —
    elif action == "csfd_home":
        _csfd_home()
    elif action == "csfd_tv_tips":
        _csfd_tv_tips()
    elif action == "csfd_trailers":
        _csfd_trailers()
    elif action == "csfd_trailer_play":
        _csfd_trailer_play()
    elif action == "csfd_top_films":
        _csfd_top_films()


    # — TMDb —
    # (aliasy: menu používá tmdb_movie_* / tmdb_tv_*_rated, staré odkazy používají tmdb_trending_* / tmdb_top_*)
    elif action in ("tmdb_movie_trending", "tmdb_trending_movie", "tmdb_trending"):
        _tmdb_trending()
    elif action in ("tmdb_movie_top_rated", "tmdb_top_movie", "tmdb_top"):
        _tmdb_top()
    elif action in ("tmdb_tv_trending", "tmdb_trending_tv"):
        _tmdb_tv_trending()
    elif action in ("tmdb_tv_top_rated", "tmdb_tv_top", "tmdb_top_tv"):
        _tmdb_tv_top()

    elif action in ("tmdb_genres", "genres"):
        _tmdb_genres()

    elif action == "tmdb_genre":
        try:
            _tmdb_genre_movies(int(params.get("genre_id", ["0"])[0]))
        except ValueError:
            _log("Invalid genre id", xbmc.LOGERROR)

    # — PODOBNE TITULY (TMDb similar) —
    elif action == "similar_movies":
        _tmdb_similar_movies()
    elif action == "similar_tv":
        _tmdb_similar_tv()

    # — AUTOSEARCH (TMDb id) —
    elif action == "auto":
        try:
            _auto_search_movie(int(params.get("tmdb", ["0"])[0]))
        except ValueError:
            _log("Invalid tmdb id", xbmc.LOGERROR)

    # — PŘEHRÁNÍ / DETAIL —
    elif action == "play":
        _play(params.get("ident", [""])[0])
    elif action == "cw_play":
        # Φ1 (29.09.2026): přehratelná položka Pokračovat (resolve ve stejné invokaci)
        _cw_play_action()
    elif action == "detail":
        _stream_detail(params.get("ident", [""])[0])

    # — STAHOVÁNÍ —
    elif action == "download":
        _download_stream()

    # — UTILITY —
    elif action == "ws_login":
        _ws_login()
    elif action == "fs_login":
        _fs_login()
    elif action == "fs_login_onboard":
        _fs_onboard_login()
    elif action == "clear_logs":
        _clear_logs()
    elif action == "reset_settings":
        _reset_settings()
    elif action == "reset_search_caches":
        _reset_search_caches()

    # ── Streaming home (podmenu) ────────────────────────────────────
    elif action == "streaming_home":
        _streaming_home()

    # ── SkTorrent ────────────────────────────────────────────────────
    elif action == "sktorrent_home":
        _sktorrent_home()
    elif action == "sktorrent_search":
        _sktorrent_search()
    elif action == "sktorrent_browse":
        _sktorrent_browse()
    elif action == "sktorrent_play":
        _sktorrent_play()

    # ── Stream.cz ────────────────────────────────────────────────────
    elif action == "stream_home":
        _stream_home()
    elif action == "stream_category":
        _stream_category()
    elif action == "stream_show":
        _stream_show()
    elif action == "stream_season":
        _stream_season()
    elif action == "stream_search":
        _stream_search()
    elif action == "stream_quality":
        _stream_quality()
    elif action == "stream_play":
        _stream_play()

    # ── YouTube ──────────────────────────────────────────────────────
    elif action == "yt_home":
        _yt_home()
    elif action == "yt_search":
        _yt_search()
    elif action == "yt_trending":
        _yt_trending()
    elif action == "yt_for_you":
        _yt_for_you()
    elif action == "yt_channel":
        _yt_channel()
    elif action == "yt_play":
        _yt_play()

    # ── iDNES.tv ────────────────────────────────────────────────────
    elif action == "idnestv_home":
        _idnestv_home()
    elif action == "idnestv_latest":
        _idnestv_latest()
    elif action == "idnestv_category":
        _idnestv_category()
    elif action == "idnestv_play":
        _idnestv_play()

    # ── Novinky.cz ──────────────────────────────────────────────────
    # ── Televize (08.11.2026, plán Televizní kanály F3) ─────────────
    elif action in ("live_home", "live_play"):
        # Televize F4c (08.11.2026, plán F4 §3.14): vlastní okno s videem v okně. Adresář se ukončí PŘED doModal — jinak
        # Kodi drží kolečko celou dobu, co je Televize otevřená (druhé kolečko = „two concurrent busydialogs“ = pád Kodi).
        # `live_play&ch=` (staré odkazy z výpisu F3) = okno naladěné na kanál. Nový vzhled: základ Home (Φ-NOFLASH);
        # starý vzhled: okno nad adresářem, Zpět vrátí do adresáře.
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass
        _live_ch = (params.get("ch") or [""])[0]
        try:
            import richmovie_ui_common as _uc_live
            _live_dup = not _uc_live.nav_debounce("live|" + _live_ch)
        except Exception:
            _live_dup = False
        if _live_dup:
            _log("[NavStack] duplicitní otevření Televize ignorováno", xbmc.LOGINFO)
        else:
            if _rm_new_ui():
                _reset_base_to_home()
            import richmovie_tv_vod as _tv_vod
            _tv_vod.run_window_loop(_live_ch or None, addon=ADDON)

    elif action == "novinky_home":
        _novinky_home()
    elif action == "novinky_latest":
        _novinky_latest()
    elif action == "novinky_category":
        _novinky_category()
    elif action == "novinky_play":
        _novinky_play()

    elif action == "rm_nav_debounced":
        # Φ1 NavStack: duplicitní dvojklik invokace — vědomě žádná akce
        # (viz nav debounce blok před dispatch chainem). Φ2 (29.09.2026): dřívější
        # `busy_close()` pryč — busy dialog z doplňku nikdy nevznikl (Kodi ho ignoruje)
        # a zavírání cizího kolečka mohlo shodit ochranu probíhajícího resolve (A10 F4).
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass

    elif action == "noop":
        # Φ5 (2026-08-08): informační položka bez akce (indikátor offline režimu
        # v legacy kořenovém menu). Klik nesmí nic udělat ani zalogovat chybu —
        # bez téhle větve by spadl do `Unknown action` a strašil v logu.
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass

    elif action == "diag_upload":
        # 3.5.120: ruční odeslání diagnostiky z menu. Gate přijme upload JEN s platným
        # `log_pull_id` (serverem vydané jednorázové pověření, `diag/router._authorize`) —
        # bez něj vrací 400 `missing_pull_id` (cross-check 09.09.2026 F15.1: dřív se posílal
        # prázdný a ruční cesta nikdy nefungovala). `run_pull("")` si proto pověření vezme
        # z posledního `/auth`; když správce log nevyžádal, řekne to uživateli na rovinu.
        try:
            import richmovie_diag_upload as _rm_diag
            _res = _rm_diag.run_pull("", interactive=True)
            _messages = {
                _rm_diag.RESULT_DONE: "Diagnostika odeslána. Díky!",
                _rm_diag.RESULT_NOTHING_REQUESTED: "Správce si log z tohoto zařízení zatím nevyžádal — napiš Richiemu.",
                _rm_diag.RESULT_ALREADY_DONE: "Tenhle log už byl odeslán.",
                _rm_diag.RESULT_DECLINED: "Odesílání zrušeno.",
                _rm_diag.RESULT_DISABLED: "Odesílání diagnostiky je v nastavení vypnuté.",
                _rm_diag.RESULT_NO_LOG: "Log je prázdný — není co odeslat.",
                _rm_diag.RESULT_BUSY: "Odesílání už běží.",
                _rm_diag.RESULT_NO_DEVICE_ID: "Nepodařilo se určit zařízení.",
            }
            _notif(_messages.get(_res, "Diagnostiku se nepodařilo odeslat."),
                   xbmcgui.NOTIFICATION_INFO
                   if _res == _rm_diag.RESULT_DONE else xbmcgui.NOTIFICATION_WARNING,
                   5000)
        except Exception as _diag_exc:
            _log(f"[DiagUpload] Manual-error: {_diag_exc}", xbmc.LOGERROR)
            _notif("Diagnostiku se nepodařilo odeslat.",
                   xbmcgui.NOTIFICATION_WARNING, 5000)
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False)
        except Exception:
            pass

    else:
        _log(f"Unknown action {action}", xbmc.LOGERROR)


if __name__ == '__main__':
    main()
