# -*- coding: utf-8 -*-
"""
RichMovie – Next‑Up Service
---------------------------
• Sleduje přehrávání přes xbmc.Player().
• _N_ sekund před koncem (dle Settings → nextup_margin) spustí na pozadí
  `_search_episode()` a uloží výsledek do `plugin.NEXT_CACHE`.
• Funkci lze globálně vypnout v Settings → nextup_enable = False.
"""

from __future__ import annotations

# — Standard library —
import functools
import json
import os
import sys
import threading
import time
import urllib.parse
from dataclasses import asdict
from typing import Optional
from pathlib import Path

# — Vendored libs bootstrap (defensive — plugin.py taky bootstrap dela) —
_ADDON_DIR = Path(__file__).resolve().parent
_VENDOR_DIR = _ADDON_DIR / "resources" / "lib" / "vendor"
if _VENDOR_DIR.exists() and str(_VENDOR_DIR) not in sys.path:
    sys.path.insert(0, str(_VENDOR_DIR))
_LIB_DIR = _ADDON_DIR / "resources" / "lib"
if _LIB_DIR.exists() and str(_LIB_DIR) not in sys.path:
    sys.path.insert(0, str(_LIB_DIR))

# — Kodi API —
import xbmc
import xbmcgui
import richmovie_settings  # SSOT čtení i ověřeného zápisu nastavení (3.5.124)

# — Lokální moduly —
import plugin as _rm
import richmovie_history as _hist
import richmovie_playback_dispatch as _rm_dispatch  # Φ1: jedno spuštění přehrávání (pád Kodi 21.2)
import richmovie_start_watch as _rm_sw  # Φ6: hlídač startu + stavové texty startu (SSOT)
import richmovie_livetv as _rm_live  # Televizní kanály F3: druh přehrávání (živý kanál) + konec relace relay
import richmovie_media_kind as _rm_kind  # Televizní kanály F3: schopnosti živého přehrávání (Zpět, návrat do RichMovie)
from richmovie_playback_end import MIN_DURATION_S, EndKind, is_completed
from richmovie_resume import VERIFY_DEADLINE_S as _RESUME_VERIFY_DEADLINE_S
from tmdb_client import TMDb, TMDbError
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)

# 2026-07-01 (observability program): NextUp/TitlePrefs/service diagnostické logy
# přepnuty z přímého xbmc.log na ROUTOVANÝ logger → tečou na NAS (Gate). Source
# "richmovie.service_nextup"; subsystémový tag (NAV_ERR/TitlePrefs/LogDrain…) zůstává
# v textu zprávy. (import plugin výše už spustil init_logging → pipeline je připravená.)
try:
    from richmovie_logging import make_legacy_logger as _nu_make_legacy_logger
    _log = _nu_make_legacy_logger("richmovie.service_nextup", "RichMovie/NextUp")
except Exception:
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log("[RichMovie/NextUp] " + str(msg), level)
        except Exception:
            pass

# — Nastavení —
SETTINGS = _rm.ADDON
def _enabled() -> bool:  return richmovie_settings.get_bool("nextup_enable")
def _margin()  -> int:   return richmovie_settings.get_int("nextup_margin") or 300
def _dialog_enabled() -> bool:  return richmovie_settings.get_bool("nextup_dialog")
def _autoplay_enabled() -> bool:  return richmovie_settings.get_bool("nextup_autoplay")


def _back_stop_enabled() -> bool:
    # Φ2 fullscreen-exit watcher killswitch. POZOR: getSettingBool na settingu
    # chybějícím v settings.xml vrací False (incident nextup_dialog, Φ0) —
    # rm_back_stops_playback JE v settings.xml, default true.
    return richmovie_settings.get_bool("rm_back_stops_playback")


def _restore_primed_streams(reason: str) -> None:
    """3.5.155: vrátit Kodi jazyk zvuku/titulků, který plugin nastavil pro otevření souboru."""
    try:
        import richmovie_localization as _loc
        _loc.restore_primed_settings(reason=reason)
    except Exception:
        pass

def _kick_log_archive() -> None:
    """3.5.155: konec přehrávání → segment logu na Gate do minuty (incident je hned k dispozici)."""
    try:
        import richmovie_log_archive as _archive
        _archive.kick()
    except Exception:
        pass

def _os_filter_kind() -> str:
    """Noc 03.11.2026 (Φ1): druh systémového filtru obsahu v cestě (SSOT `richmovie_device_env.os_filter`), "" = žádný.
    Chyba = "" (beze změny chování)."""
    try:
        import richmovie_device_env as _denv
        return _denv.os_filter()
    except Exception:
        return ""

def _spawn_followup(kind: str, target, *, args=(), kwargs=None, name: str = "",
                    daemon: bool = True) -> threading.Thread:
    """4.0.2 (plán E9): navazující akce po konci přehrávání (autoplay, navázání, navigace, dialog po konci, návrat
    do RichMovie) běží uvnitř RELACE PŘEHRÁVÁNÍ (`richmovie_playback_dispatch.followup`) — programová obnova výpisu
    do ní nevletí (jinak by `PlayMedia` dalšího dílu Kodi zpracovalo uvnitř běžícího načítání = mechanismus pádu 4.0.1).
    JEDINÁ cesta, jak navazující akci spustit; `daemon` a jméno vlákna zůstávají podle původních míst."""
    def _run() -> None:
        try:
            target(*args, **(kwargs or {}))
        finally:
            _rm_dispatch.followup_end(kind)
    # Započítat UŽ TADY, v callbacku konce přehrávání (ne až ve vlákně): tik služby mezi koncem callbacku a startem
    # vlákna by jinak relaci ukončil a obnova výpisu by vletěla před `PlayMedia` autoplaye.
    _rm_dispatch.followup_begin(kind)
    try:   # i konstrukce vlákna patří do `try` — započítaná akce bez vlákna by relaci držela navždy (cross-check Flash F2)
        th = threading.Thread(target=_run, name=name or ("RMFollowup-" + kind), daemon=daemon)
        th.start()
    except Exception:
        _rm_dispatch.followup_end(kind)
        raise
    return th


def _ends_playback(callback):
    """4.0.2 (plán E9): callback konce přehrávání (Stopped / Ended / Error) po doběhnutí — i přes `return` uprostřed
    nebo výjimku — ohlásí relaci „konec viděn“ (`richmovie_playback_dispatch.session_end_seen`): navazující akce jsou
    v tu chvíli započítané, takže další tik bez přehrávače smí relaci ukončit hned (odložená obnova po Stopu do 5 s)."""
    @functools.wraps(callback)
    def _wrapped(self, *args, **kwargs):
        try:
            return callback(self, *args, **kwargs)
        finally:
            _rm_dispatch.session_end_seen()
    return _wrapped


def _auto_resume_enabled() -> bool:
    # 3.5.119 (B3): automatické navázání po utnutí streamu zdrojem (CDN stall).
    # Setting `auto_resume_enabled` JE v settings.xml (Next-Up), default true.
    # Nový kód čte settings přes SSOT richmovie_settings (feedback_settings_ssot_required).
    from richmovie_settings import get_bool
    return get_bool("auto_resume_enabled")


def _is_custom_ui() -> bool:
    """SSOT dotaz na RM 4.0 režim (Window prop, plní plugin.py router)."""
    try:
        import richmovie_rmdir
        return richmovie_rmdir.is_custom_ui()
    except Exception:
        return False


# — Intervaly —
_CHECK_EVERY   = 5     # (s) dotaz na čas
HANDOFF_SEEK_TOLERANCE_S = 10.0   # keyframe seek dosedne i o několik s vedle cíle (cross-check Pro A 13.09.)
_PROMPT_MARGIN = 15    # (s) před koncem zobrazit dotaz

# — Auto-resume po nečekaném EOF (3.5.119, B3; incident Zelňačka 23.08.2026) —
# Zdroj (Webshare CDN) utnul stream 7× za 40 minut; Kodi každé utnutí ohlásí
# jako konec souboru a uživatel musel ručně navazovat. Politika:
#   • max AUTO_RESUME_MAX_ATTEMPTS po sobě jdoucích navázání, která NEVYDRŽELA
#     aspoň AUTO_RESUME_STABLE_S přehrávání (měřeno z reálné pozice videa, ne z
#     hodin). Navázání, po kterém stream běžel déle, čítač vynuluje — zdroj
#     zjevně funguje a občasné utnutí je tolerovatelné.
#   • po vyčerpání: dialog „zdroj se seká — vybrat jiný stream?".
AUTO_RESUME_MAX_ATTEMPTS = 3
AUTO_RESUME_STABLE_S = 120.0
# A#6 (Fable audit): delta pozice selže po seeku ZPĚT (záporná) — druhé kritérium
# stability je reálný čas od posledního navázání (zahrnuje pauzy, proto delší).
AUTO_RESUME_STABLE_WALL_S = 600.0
# 3.5.151 (cross-check Pro A PA5): utnutí bez sítě (vlak v tunelu) — navázat, AŽ se síť vrátí.
# Dřív pokus hned selhal na resolve odkazu a po návratu sítě se nestalo nic.
AUTO_RESUME_WAIT_NETWORK_S = 600.0     # déle čekat nemá smysl — divák mezitím dělá něco jiného
AUTO_RESUME_NETWORK_POLL_S = 15.0      # kontrola CDN streamu (+ Gate, když CDN mlčí) — 40× za 10 min
# 3.5.151 (Pro A PA4a): obnova mrtvého zdroje otevírá stream; EOF v tomhle okně NESMÍ pustit
# druhé přehrání přes auto-resume (to by bez požadavku začalo od nuly). = strop ověření startu (SSOT).
RESTART_INFLIGHT_S = _RESUME_VERIFY_DEADLINE_S
# Výsledek `_proactive_reconnect` (Fable F1: čekání na cestu ke zdroji drží hlídač, žádné nové vlákno)
RECONNECT_STARTED = "started"
RECONNECT_WAIT_ROUTE = "wait_route"
RECONNECT_SKIPPED = "skipped"
# Čekání na zavření fullscreen videa po konci přehrávání (Kodi ho zavírá sám,
# typicky < 1 s; 5 s = strop, stejný jako v _autoplay_safely / _navigate).
_FULLSCREEN_CLOSE_WAIT_S = 5.0
_FULLSCREEN_POLL_S = 0.1
_TOAST_MS = 4000




# ------------------------------------------------------------------ #
def _cw_backfill_lost_series(monitor) -> None:
    """Φ8 (2026-07-07): JEDNORÁZOVÁ rekonstrukce seriálů ztracených z CW.

    Bug 2 (audit A02) mazal seriály z Pokračovat měsíce: dokoukaný díl =
    cw_remove bez náhrady + autoplay díl stopnutý <30 s se nezapsal. Oprava
    (cw_advance, 3.5.89) je going-forward — TENTO backfill obnoví historii:
    z watched_episodes.json (completion SSOT) vezme poslední dokoukaný díl
    per seriál, přes _next_coords určí DALŠÍ díl a vloží ho do CW (position=0,
    bez identu → klik jde korektně picker-first cestou přes tv kontext).

    Pravidla: run-once (setting cw_backfill_v1), seriály UŽ přítomné v CW se
    nedotýkají, cap 8 (CW_MAX_ITEMS=10 — nevytlačit čerstvou aktivitu),
    dokoukané celé seriály (next=None) se přeskočí. ts=now (starší watched_at
    by _cw_purge_expired okamžitě smazal). Non-daemon vlákno (HTTP!) s abort
    checky.

    3.5.118 (Φ5): start řídí hlavní smyčka služby podle SKUTEČNÉ podmínky
    (identita potvrzena + TMDb klíč), ne pevných 20 s po bootu — služba startuje
    s Kodi, kdežto `gate_auth` běží až při otevření RichMovie (za minutu nebo za
    hodinu). Flag `cw_backfill_v1` se zapisuje VÝHRADNĚ při nule selhání
    (All-or-Nothing, vzor `richmovie_backfill.py`); do 3.5.117 se zapsal i po
    100% selhání a backfill se už nikdy nespustil."""
    try:
        import richmovie_history as _hist
        import richmovie_settings as _rm_settings
        import richmovie_ui_common as _uc

        watched = _hist.watched_load().get("episodes") or []
        if not watched:
            _rm_settings.set_flag("cw_backfill_v1", f"done:{int(time.time())}:0")
            return

        # poslední dokoukaný díl per seriál + recency (watched_at)
        last: dict = {}
        for it in watched:
            tid = str(it.get("tv_id") or "")
            if not tid:
                continue
            pos = (int(it.get("season") or 0), int(it.get("episode") or 0))
            rec = last.get(tid)
            if rec is None or pos > (rec["s"], rec["e"]):
                last[tid] = {"s": pos[0], "e": pos[1],
                             "ts": int(it.get("watched_at") or 0)}
            elif int(it.get("watched_at") or 0) > rec["ts"]:
                rec["ts"] = int(it.get("watched_at") or 0)

        # tv_name z watch_history (start-based store nese názvy), poster z rail cache
        names: dict = {}
        for it in (_uc.load_json("watch_history.json").get("episodes") or []):
            tid = str(it.get("tv_id") or "")
            if tid and tid not in names and (it.get("tv_name") or "").strip():
                names[tid] = it["tv_name"].strip()
        posters = _uc.load_json("rail_series_posters.json")

        cand = [(tid, rec) for tid, rec in last.items()
                if rec["s"] > 0 and rec["e"] > 0
                and not _hist.cw_contains_series(tid)]
        # nejstarší první → cw_upsert insertuje na index 0 → nejčerstvější
        # seriál skončí nahoře railu
        cand.sort(key=lambda x: x[1]["ts"])
        cand = cand[-8:]

        added = 0
        failures = 0
        for tid, rec in cand:
            if monitor.abortRequested():
                return
            try:
                coords = _next_coords(int(tid), rec["s"], rec["e"])
            except Exception as _nc_exc:
                # 3.5.118: selhání lookupu ≠ „seriál skončil". Počítá se a flag
                # se NEZAPÍŠE; po selhání se ptáme stavů, zda má smysl pokračovat.
                failures += 1
                _log(f"CW_BACKFILL lookup failed tv_id={tid}: {_nc_exc!r}", xbmc.LOGWARNING)
                if _backfill_stop_reason():
                    _log(f"CW_BACKFILL STOPPED reason={_backfill_stop_reason()}", xbmc.LOGWARNING)
                    break
                continue
            if not coords:
                continue  # dokoukaný celý seriál — legitimní None, nevkládat
            ns, ne = coords
            _n_title = ""
            try:
                from richmovie_settings import get_tmdb_api_key as _gk
                _k = _gk()
                if _k:
                    _d = TMDb(_k, lang="cs-CZ").episode_details(int(tid), ns, ne)
                    _n_title = (_d.get("name") or "").strip()
            except Exception:
                _n_title = ""
            _hist.cw_upsert({
                "type": "episode", "tv_id": tid,
                "tv_name": names.get(tid) or "Seriál",
                "season": ns, "episode": ne, "ep_title": _n_title,
                "position": 0, "duration": 0,
                "ts": int(time.time()),
                "ident": "", "source": "webshare", "fs_url": "", "fs_hash": "",
                "poster_path": (posters.get(tid) or {}).get("p") or "",
                "backdrop_path": "",
            })
            added += 1
            if monitor.waitForAbort(0.5):  # šetrné tempo na Gate/TMDb
                return
        if failures == 0:
            _rm_settings.set_flag("cw_backfill_v1", f"done:{int(time.time())}:{added}")
            _log(f"CW_BACKFILL: obnoveno {added} seriálů do Pokračovat", xbmc.LOGINFO)
        else:
            # All-or-Nothing: flag NEZAPSÁN → hlavní smyčka zkusí znovu po změně
            # stavu sítě/identity (ne každých 5 s — viz run loop).
            _log(f"CW_BACKFILL partial: added={added} failures={failures} — flag "
                 f"nezapsán, retry po zotavení", xbmc.LOGWARNING)
    except Exception as exc:
        _log(f"CW_BACKFILL err: {exc!r}", xbmc.LOGWARNING)


def _backfill_stop_reason() -> str:
    """"" = pokračuj; jinak důvod, proč další TMDb/Gate request nemá smysl
    (SSOT stavy: identita zamítnuta / síť offline). Žádné počítadlo."""
    try:
        import richmovie_identity_state as _ident
        if _ident.is_rejected():
            return "identity_rejected"
    except Exception:
        pass
    try:
        import richmovie_netstate as _ns
        if not _ns.allow_request():
            return "offline"
    except Exception:
        pass
    return ""


def _backfill_preconditions_met() -> bool:
    """Smí backfill vůbec začít? Identita potvrzená v této Kodi session (plugin
    prošel `gate_auth`) a TMDb klíč k dispozici (lokálně nebo z lease cache)."""
    try:
        import richmovie_identity_state as _ident
        if not _ident.is_authenticated():
            return False
    except Exception:
        return False
    try:
        from richmovie_settings import get_tmdb_api_key as _gk
        return bool(_gk())
    except Exception:
        return False


def _next_coords(tv_id: int, season: int, episode: int) -> tuple[int, int] | None:
    """Vrátí (next_season, next_episode), nebo None POUZE když seriál skončil — SSOT
    `richmovie_series_nav.next_coords` (4.0.3: jediná kopie pro autoplay, Pokračovat i „Další díl").

    3.5.118: chyby lookupu (TMDbError, chybějící klíč) PROPAGUJÍ jako výjimka — „seriál skončil" a „TMDb
    neodpovídá" se nesmí zaměnit (CW backfill pak tiše zahodil seriál). Klíč: SSOT 3.5.69 (Gate fallback)."""
    from richmovie_settings import get_tmdb_api_key
    import richmovie_series_nav as _nav
    tmdb_key = get_tmdb_api_key()
    if not tmdb_key:
        raise TMDbError("TMDb klíč není k dispozici (lokálně ani z Gate lease)")
    return _nav.next_coords(TMDb(tmdb_key, lang="cs-CZ"), int(tv_id), int(season), int(episode))


ADVANCE_ADVANCED = "advanced"   # Pokračovat nabízí další díl
ADVANCE_REMOVED = "removed"     # seriál skončil / nebylo co posunout → dokoukaný díl z Pokračovat pryč
ADVANCE_DEFERRED = "deferred"   # další díl nejde zjistit (TMDb) → řádek zůstává, dožene úklid po startu


def _advance_series_cw(tv_id, season: int, episode: int) -> str:
    """JEDINÝ posun Pokračovat po dokoukaném dílu (přirozený konec i `_close_completed_leftovers`).
    Chyba zjištění dalšího dílu NENÍ konec seriálu (3.5.118, 4.0.3): do 4.0.2 přirozený konec při výpadku TMDb díl
    z Pokračovat smazal a seriál zmizel. Teď řádek zůstane (✔ už je zapsaný) a dalším startem služby ho uzavře úklid."""
    try:
        season, episode = int(season), int(episode)
    except (TypeError, ValueError):
        _log(f"CW_ADVANCE deferred: {tv_id} díl {season!r}/{episode!r} (neplatná čísla)", xbmc.LOGWARNING)
        return ADVANCE_DEFERRED
    try:
        coords = _next_coords(int(tv_id), season, episode)
    except Exception as exc:
        _log(f"CW_ADVANCE deferred: {tv_id} S{season:02d}E{episode:02d} (další díl nezjištěn: {exc!r})",
             xbmc.LOGWARNING)
        return ADVANCE_DEFERRED
    if not coords:
        _hist.cw_remove(tv_id=tv_id, season=season, episode=episode)
        _log(f"CW_ADVANCE: {tv_id} S{season:02d}E{episode:02d} = konec seriálu → z Pokračovat pryč", xbmc.LOGINFO)
        return ADVANCE_REMOVED
    ns, ne = coords
    title = ""
    try:
        from richmovie_settings import get_tmdb_api_key as _gtak
        key = _gtak()
        if key:
            title = (TMDb(key, lang="cs-CZ").episode_details(int(tv_id), ns, ne).get("name") or "").strip()
    except Exception:
        title = ""   # název dalšího dílu je ozdoba; Pokračovat ho doplní z cache při vykreslení
    if _hist.cw_advance_episode(tv_id=tv_id, season=season, episode=episode, next_season=ns, next_episode=ne,
                                next_ep_title=title):
        _log(f"CW_ADVANCE: {tv_id} S{season:02d}E{episode:02d} → S{ns:02d}E{ne:02d}", xbmc.LOGINFO)
        return ADVANCE_ADVANCED
    # Záznam dílu v Pokračovat není (rewatch staršího dílu za rozkoukaným — R3-P1-1 — nebo seriál posunul autoplay
    # jinam): dokoukaný díl tam přesto nesmí zůstat (přesné odebrání, bez záznamu no-op).
    _hist.cw_remove(tv_id=tv_id, season=season, episode=episode)
    return ADVANCE_REMOVED


LEFTOVERS_START_DELAY_S = 60.0   # po startu služby: síť, identita a první pull stavu mají přednost


def _close_completed_leftovers() -> int:
    """M8 (4.0.3, data 10.10.2026: ~30 filmů a dílů na 93–99,9 % bez ✔): Kodi na Androidu během titulků často
    zavře / uspí aplikace — Stop ani Ended nepřijde a v Pokračovat zůstane titul, který divák dokoukal. Po startu
    služby se takové záznamy (pozice splňuje SSOT `is_completed`) uzavřou STEJNĚ jako konec přehrávání: ✔,
    díl → další díl v Pokračovat (`_advance_series_cw`, konec seriálu → pryč), film → pryč. Když další díl nejde
    zjistit, díl dostane jen ✔ a záznam počká na příští start (žádné hádání konce seriálu). Uklízí i díly, jejichž
    posun při přirozeném konci odložil výpadek TMDb. Vrací počet uzavřených titulů."""
    mon = xbmc.Monitor()
    if mon.waitForAbort(LEFTOVERS_START_DELAY_S):
        return 0
    closed = 0
    import richmovie_state_sync as _ss_left
    playing = _ss_left.playing_key() or ""   # právě hrající titul se neuzavírá (rozhodne jeho vlastní konec)
    store = _hist.cw_load()
    hidden = store.get("hidden_series") or {}
    for it in list(store.get("items") or []):
        if mon.abortRequested():
            break
        try:
            pos, dur = float(it.get("position") or 0), float(it.get("duration") or 0)
            # nesmyslná pozice (M3: 47 547 s u dílu o 2 638 s) není dokoukání (cross-check Codex C1)
            if not _ss_left.sane_checkpoint(pos, dur) or not is_completed(pos, dur):
                continue
            pct = min(1.0, pos / dur)
            # ✔ s časem POSLEDNÍHO checkpointu: pozdější výslovné odznačení ho na Gate přebije (Codex C1)
            at = float(it.get("client_time") or it.get("ts") or 0) or None
            if it.get("type") == "episode":
                tv_id, s, e = it.get("tv_id"), int(it.get("season") or 0), int(it.get("episode") or 0)
                if not tv_id or s <= 0 or e <= 0 or playing == f"tv:{tv_id}:{s}:{e}":
                    continue
                prior = _hist.watched_info_for_series(str(tv_id)).get((s, e)) or {}
                if str(prior.get("kind") or "") == "unattended":
                    continue   # ⏾ = prokázaný spánek; automat ho nezvedá (Pro B PB2) — rozhodne divák v Pokračovat
                _hist.watched_mark_episode(tv_id=tv_id, season=s, episode=e, completion=pct, kind="attended",
                                           watched_at=at)
                if float(hidden.get(str(tv_id), 0) or 0) >= float(it.get("ts") or 0):
                    _hist.cw_remove(tv_id=tv_id, season=s, episode=e)   # skrytý seriál nevracet (Flash C F13)
                elif _advance_series_cw(tv_id, s, e) == ADVANCE_DEFERRED:
                    continue   # ✔ je zapsaný, Pokračovat dožene příští start
                key = f"tv:{tv_id}:{s}:{e}"
            elif it.get("tmdb_id"):
                tmdb = it.get("tmdb_id")
                if playing == f"movie:{tmdb}:0:0":
                    continue
                _hist.watched_movie_mark(tmdb, watched_at=at)
                _hist.cw_remove(tmdb_id=tmdb)
                key = f"movie:{tmdb}"
            elif it.get("path"):
                # film z NASu bez TMDb (Flash C F3): ✔ nemá kam (✔ filmů je per TMDb id) — jen pryč z Pokračovat
                if not _hist.cw_remove_matching(it):
                    continue
                key = "path:%s" % it.get("path")
            else:
                continue
            closed += 1
            _log(f"LEFTOVER_CLOSED: {key} na {pct:.3f} (konec přehrávání nepřišel) → ✔ + Pokračovat dál", xbmc.LOGINFO)
        except Exception as exc:
            _log(f"leftover close failed: {exc!r}", xbmc.LOGWARNING)
    if closed:
        try:
            _ss_left.request_push()
        except Exception:
            pass
    return closed


# ------------------------------------------------------------------ #
class _NextUpPlayer(xbmc.Player):
    """Player wrapper, který spouští pre‑fetch v dalším vlákně."""




    _av_gen = 0
    _end_handled = False  # A#1 (Fable audit): Ended už zpracován → ignorovat Stopped
    # 3.5.129 (incident PeterFM, nález N4): Kodi při selhání OTEVŘENÍ streamu
    # (HTML místo videa, CDN 4xx) nepošle Error, ale rovnou Stopped — dřív se to
    # logovalo jako „user pressed Stop" na INFO a v NAS filtru WARN+ incident
    # neexistoval. `_av_started` = přišel onAVStarted pro aktuální otevření;
    # `_open_ts` = monotonic čas onPlayBackStarted (doba do selhání do logu).
    _av_started = False
    _open_ts = 0.0
    # Φ6 (29.09.2026): pořadí otevření (hlídač startu patří jednomu otevření) + „divák zvolil jiný stream“
    # po zaseknutí: (pořadí otevření, cílová URL výpisu streamů) — Stopped pak naviguje, nevrací do menu
    _open_seq = 0
    _open_ident = ""   # ident streamu RichMovie (Webshare/Fastshare) tohoto otevření; "" = cizí přehrávání Kodi
    # Televizní kanály F3 (08.11.2026): druh média = VRÁTNÝ služby. `_open_live` = tohle otevření je živý kanál
    # RichMovie (`richmovie_livetv.is_live_item`, SSOT druhu `richmovie_media_kind`) → žádná VOD logika (Pokračovat,
    # ✔, autoplay, navázání, zdraví zdroje, stres, hodnocení, Zpět = Stop, preference stop, návrat do RichMovie).
    # `_live_playing` = obraz kanálu naskočil a relace relay na NASu běží → Stop / konec / chyba / start VOD ji ukončí.
    # VOD a cizí přehrávání (i Filmotéka přes smb:// bez značek) mají `_open_live = False` → chování beze změny.
    _open_live = False
    _live_playing = False
    _live_channel = ""
    _live_csid = ""            # identita relace (`client_session_id`) — konec ukončí na NASu jen ji
    _stall_redirect = None
    _cached_pos = 0.0
    _cached_dur = 0.0
    _cached_li = None  # posledni zname PlayingItem
    _cached_at = 0.0   # time.monotonic() posledního zápisu _cached_pos (stáří checkpointu)
    _observed_av = None  # Φ4: snapshot reálně použité stopy (observed pref)
    # 13.09.2026 (3.5.148, nález N1): poslední ZAPSANÝ checkpoint CW tohoto přehrávání
    # (klíč, pozice, activity) — nezměněný stav se nezapisuje (žádný nový čas, žádný push).
    _cw_last_saved = None
    # Φ3 handoff: pozice, na kterou jsme sami seekli podle jiného zařízení — následný
    # onPlayBackSeek od Kodi NENÍ akce uživatele (jinak by se převzatá pozice pushla jako naše).
    _handoff_seek_expected = -1.0
    # Po handoffu Kodi dosedne na nejbližší keyframe (i o několik s vedle cíle) — checkpoint by to bral
    # jako „změnu" a pushl cizí pozici jako naši (cross-check Pro A P1 13.09.). Do další AKCE UŽIVATELE
    # (resume/seek) je tolerance dedupe širší; pak zpět na výchozí.
    _cw_min_delta = None   # None = výchozí richmovie_state_sync.CHECKPOINT_MIN_DELTA_S
    # Čas poslední ZMĚNY postupu (epoch): finální Stop po dlouhé pauze nese tenhle čas jako `client_time`,
    # ne „teď" — jinak by v LWW přepsal postup, který mezitím udělalo jiné zařízení (Flash C P0 13.09.).
    _cw_last_change_ts = 0.0
    # Handoff `watched`: jiné zařízení díl dokoukalo → tenhle klíč se při Stopu už NEposílá jako `watching`
    _cw_suppress_final_key = ""
    # 4.0.3 (M2): klíč titulu, který je otevřený a ještě ho neuzavřel Ended/Stopped (přepnutí za běhu ho uzavře)
    _title_open_key = ""
    # 4.0.3 (M8): klíč titulu, kterému už v tomhle přehrávání vznikl ✔ v titulcích
    _early_watched_key = ""
    # 3.5.149: „Díváš se ještě?" — snímek dílu pro případný návrat Pokračovat (D2)
    _attention_snapshot = None
    # B3 auto-resume stav (jen v tomto procesu služby — plugin ho nečte):
    _resume_key = ""          # ident zdroje, ke kterému se čítač vztahuje
    _resume_attempts = 0      # po sobě jdoucí krátkodobá navázání
    _resume_from_pos = 0.0    # pozice, ze které poslední navázání startovalo
    _resume_started_at = 0.0  # time.monotonic() posledního navázání (A#6)
    # 3.5.151 (plán PLAN_resume_native_start_sync_integrity_20260916, Φ1/Φ2): navázání na pozici
    # převzaté v onAVStarted (`richmovie_resume.take_pending`). Dokud není ověřené, checkpoint
    # nesmí zapsat nižší pozici (D1: při selhání zůstává Pokračovat na původním místě).
    _resume_hold = None           # {"ident", "target", "source"} | None
    _resume_verify_token = 0      # uživatelský seek / nové přehrávání → běžící ověření končí
    # Zámek generace přehrávání vs. akce vláken služby (opravný seek, obnova spojení) — cross-check
    # Pro A PA2/PA4a: kontrola „pořád tentýž stream" a akce musí být atomické vůči callbackům Kodi.
    _resume_lock = threading.Lock()
    _restart_inflight_until = 0.0  # time.monotonic(): obnova spojení právě otevírá stream
    # Fable N1: generace přehrávání, během které obnova spojení poslala Kodi nový soubor a ten se ještě neotevřel
    # (onAVStarted ho nuluje). Chyba otevření za běhu = Kodi už zahodil buffer starého streamu → navázat.
    _reconnect_open_gen = -1
    # Φ3b: mrtvý zdroj — pro kterou generaci přehrávání už služba jednala (jednou per přehrávání)
    _dead_source_acted_gen = -1
    # Φ3c: kodek a výška reálně přehrávaného videa (JSON-RPC během přehrávání; po konci už nejde číst)
    _observed_video = None
    # Fable F1: adresa právě hraného streamu (po konci souboru už `getPlayingFile()` nejde číst) —
    # auto-resume podle ní ověří cestu ke ZDROJI (CDN), ne ke Gate
    _last_stream_url = ""

    # ── Φ1 (3.5.127): měření plnění filecache — jeden tracker na přehrávání ──
    _cache_meter = None   # richmovie_cache_meter.FillTracker | None

    def _cache_meter_start(self, my_gen: int) -> None:
        """Spustí 2s sampler `Player.CacheLevel` (richmovie_cache_tuning.start_fill_meter).
        Zdroj z Window prop `RichMovie.PlayerCtx.source` (fail-closed: neznámý →
        neměří se), velikost z ListItem `richmovie.size_bytes` (plugin `_play`),
        délka a pozice z přehrávače. Nikdy nesmí shodit callback."""
        self._cache_meter = None
        try:
            import richmovie_cache_tuning as _ct
            import richmovie_player_hook as _ph
            source = (_ph._get_window_prop(_ph._WIN_PROP_SOURCE) or "").strip().lower()
            try:
                li = self.getPlayingItem()
                size_bytes = int(li.getProperty("richmovie.size_bytes") or 0)
            except Exception:
                size_bytes = 0
            try:
                duration = float(self.getTotalTime())
                start_pos = float(self.getTime())
            except Exception:
                duration, start_pos = 0.0, 0.0
            self._cache_meter = _ct.start_fill_meter(
                self, xbmc.Monitor(), source=source, size_bytes=size_bytes,
                duration_s=duration, start_pos_s=start_pos,
                generation_alive=lambda: self._av_gen == my_gen and self.isPlaying(),
            )
        except Exception as exc:
            _log(f"cache meter start failed: {exc!r}", xbmc.LOGWARNING)

    def _cache_meter_finish(self, *, unexpected_eof: bool) -> None:
        """Uzavře měření podle způsobu konce a zapíše vzorek (ok/censored/eof)."""
        tracker, self._cache_meter = self._cache_meter, None
        if tracker is None:
            return
        try:
            import richmovie_cache_tuning as _ct
            sample = tracker.finish(now=time.time(), unexpected_eof=unexpected_eof)
            if sample is not None:
                _ct.record_sample(sample)
        except Exception as exc:
            _log(f"cache meter finish failed: {exc!r}", xbmc.LOGWARNING)

    def onPlayBackStarted(self) -> None:
        """3.5.129: Kodi otevřel položku (ještě bez audia/videa). Jen razítko pro
        `PLAY_OPEN_FAILED` — když pak přijde Stopped bez onAVStarted, víme, že
        stream se neotevřel, a za jak dlouho to Kodi vzdalo. Žádná jiná logika:
        vše, co potřebuje reálný obraz, zůstává v onAVStarted."""
        self._av_started = False
        self._open_ts = time.monotonic()
        self._open_epoch = time.time()   # 3.5.152: pro úklid kontextu titulu po neotevřeném streamu
        # Φ6 (29.09.2026): nové otevření = Ended minulého souboru je vyřízený. Dřív se `_end_handled` nuloval
        # jen v onAVStarted → když se další díl po autoplayi NEOTEVŘEL, jeho Stopped spadl do guardu
        # „Stopped po Ended“ a nic se nestalo (pojistka startu visela do TTL, žádná zpráva, žádný návrat).
        # Pozdní Stopped TÉHOŽ souboru po Ended přichází před dalším otevřením, guard tedy platí dál.
        self._end_handled = False
        self._open_seq += 1
        self._stall_redirect = None
        # Televizní kanály F3: druh TOHOTO otevření (vrátný Pause/Seek/Stopped/Ended/Error a checkpointů). Jiný než živý
        # start po živém kanálu (film, Filmotéka, cizí video) = relace relay končí hned (Kodi kanál zavřelo bez Stopu).
        self._open_live = self._playing_is_live()
        if self._live_playing and not self._open_live:
            self._end_live_session("switched_to_vod")
        if self._open_live:
            # kanál a identita relace už při OTEVŘENÍ: selhání před prvním obrazem musí ukončit na NASu TUHLE relaci —
            # ne minulou (kanál → kanál) ani „celé zařízení“ (cross-check Codex 08.11.2026)
            self._live_channel, self._live_csid = self._playing_live_ids()
        # Φ6: hlídač startu a věta o neotevřeném streamu patří jen streamům RichMovie z Webshare / Fastshare
        # (`richmovie.ident`) — služba dostává callbacky i od cizího přehrávání Kodi (knihovna, PVR, doplňky).
        try:
            self._open_ident = self.getPlayingItem().getProperty("richmovie.ident") or ""
        except Exception:
            self._open_ident = ""
        if not self._open_ident or time.monotonic() < self._restart_inflight_until:
            # cizí přehrávání; nebo obnova spojení otevírá nový odkaz ZA BĚHU (starý hraje z bufferu, vlastní ošetření)
            return
        # Non-daemon: vlákno zapisuje zdraví zdroje a může otevřít dialog; končí s abortem Kodi (waitForAbort)
        threading.Thread(target=self._start_watch, args=(self._open_seq, self._open_ts, self._open_ident),
                         name="RMStartWatch", daemon=False).start()

    # ── Televizní kanály F3 (08.11.2026): živý kanál — vrátný, start a konec ─────────────────────────────────────
    def _playing_is_live(self) -> bool:
        """Je právě přehrávaná položka živý kanál RichMovie? Čte se STEJNĚ jako `richmovie.ident`
        (`getPlayingItem().getProperty`), rozhoduje SSOT `richmovie_media_kind` (přes `richmovie_livetv`).
        Nečitelná položka = ne → VOD a cizí přehrávání jdou dnešní cestou beze změny."""
        try:
            li = self.getPlayingItem()
        except Exception:
            return False
        return _rm_live.is_live_item(li.getProperty)

    def _playing_live_ids(self) -> tuple:
        """(kanál, `client_session_id`) přehrávané živé položky; nečitelná položka = ("", "")."""
        try:
            li = self.getPlayingItem()
            return (li.getProperty(_rm_live.PROP_CHANNEL) or "", li.getProperty(_rm_live.PROP_SESSION) or "")
        except Exception:
            return "", ""

    def _end_live_session(self, reason: str) -> None:
        """Relace relay končí (Stop, konec, chyba, start VOD) → místo na NASu uvolnit HNED, ne až po nečinnosti.
        HTTP běží ve vlastním vlákně: callback Kodi ani 5s okno vypnutí neblokuje a `richmovie_http.cancel_all` ho při
        ukončení služby zruší. Přepnutí na JINÝ živý kanál relaci neukončuje — relay ji pro stejné zařízení nahradí sama
        a ukončení by mohlo vzít relaci nového kanálu (vlákno proto mlčí, když se mezitím otevřel další živý kanál)."""
        channel = self._live_channel
        csid = self._live_csid
        seq = self._open_seq
        self._live_playing = False
        self._live_channel = ""
        self._live_csid = ""

        def _run() -> None:
            if self._open_seq != seq and self._open_live:
                _log(f"LIVE_END_SKIPPED reason={reason} — mezitím se otevřel další živý kanál (relay ho nahradí sama)",
                     xbmc.LOGINFO)
                return
            ended = _rm_live.end_session(reason, client_session_id=csid or None)
            _log(f"LIVE_SESSION_END reason={reason} channel={channel or '-'} ended={ended}", xbmc.LOGINFO)

        try:
            threading.Thread(target=_run, name="RMLiveSessionEnd", daemon=True).start()
        except Exception as exc:   # bez vlákna uvolní místo nečinnost relace na NASu
            _log(f"LIVE_SESSION_END thread failed: {exc!r}", xbmc.LOGWARNING)

    def _on_live_av_started(self) -> None:
        """Obraz živého kanálu naskočil. Předchozí titul, který Kodi neukončilo (film → kanál bez Stopu), se uzavře
        JEDINOU cestou konce titulu — kontext hráče pořád patří filmu (plugin ho pro kanál nepíše), proto bez porovnání
        klíčů. Pak uvolnit pojistku startu, založit relaci přehrávání (brána obnovy výpisu), ukončit vlákna minulého
        přehrávání a vynulovat jeho stav. Nic z VOD logiky se NESPUSTÍ: žádný watch loop (Pokračovat, předstažení,
        „další díl“), hlídání mrtvého zdroje, měření cache, Zpět = Stop ani detekce preferencí stop."""
        channel, csid = self._playing_live_ids()
        self._close_superseded_title(superseded_by_live=True)
        self._open_live = True                 # i když `onPlayBackStarted` nepřišel
        self._av_started = True
        _rm_dispatch.finish("av_started", ident=self._open_ident)
        _rm_dispatch.session_note(True)
        with self._resume_lock:
            self._av_gen += 1                  # vlákna minulého přehrávání (watch loop, hlídače) končí
            self._resume_hold = None           # ověřování navázání minulého titulu končí
            self._resume_verify_token += 1
            self._restart_inflight_until = 0.0
            self._reconnect_open_gen = -1
        try:
            if getattr(self, "_av_change_timer", None) is not None:
                # odložená detekce změny stop minulého titulu by zapsala volbu kanálu jako preferenci filmu
                self._av_change_timer.cancel()
                self._av_change_timer = None
        except Exception:
            pass
        if self._cache_meter is not None:
            self._cache_meter_finish(unexpected_eof=False)   # měření titulu přepnutého na kanál se uzavře
        self._reset_auto_resume()
        self._end_handled = False
        self._cached_pos = 0.0
        self._cached_dur = 0.0
        self._cached_li = None
        self._cached_at = 0.0
        self._cw_last_saved = None
        self._cw_last_change_ts = 0.0
        self._cw_suppress_final_key = ""
        self._handoff_seek_expected = -1.0
        self._attention_snapshot = None
        self._observed_av = None
        self._observed_video = None
        self._title_open_key = ""
        self._cw_advanced_key = ""
        self._early_watched_key = ""
        self._last_stream_url = ""             # adresa kanálu nese tiket — v paměti služby ji nedržet
        self._show_autoplay_pick(show=False)   # info o verzi dalšího dílu patří startu VOD → zahodit
        try:
            win = xbmcgui.Window(10000)
            for _k in ("richmovie.nextup.nav_url", "richmovie.nextup.nav_pending", "richmovie.nextup.expected_key",
                       "richmovie.nextup.expected_url", "richmovie.nextup.autoplay_url", "richmovie.nextup.toast_key",
                       "richmovie.nextup.chain_stopped"):
                win.clearProperty(_k)          # čekající navigace / autoplay minulého titulu nesmí vystřelit později
        except Exception:
            pass
        self._live_playing = True
        self._live_channel = channel
        self._live_csid = csid
        if _rm_kind.allows(_rm_kind.LIVE, "fs_exit_stop"):
            # Zpět z celé obrazovky = konec kanálu a návrat do seznamu kanálů (jako film; jen start z okna RichMovie)
            threading.Thread(target=self._fullscreen_exit_watch, args=(self._av_gen,), name="RMLiveFsExit",
                             daemon=True).start()
        _log(f"LIVE_STARTED channel={channel or '-'} — Pokračovat, ✔, autoplay, navázání a hlídače VOD vypnuté",
             xbmc.LOGINFO)

    def _on_live_end(self, kind: str) -> None:
        """Konec živého kanálu (`stopped` / `ended` / `error`). Žádná VOD logika (Pokračovat, ✔, autoplay, navázání,
        hodnocení, preference stop, návrat do RichMovie — Zpět z televize patří průvodci F4); jen uvolnit pojistku
        startu, ukončit vlákna přehrávání a relaci relay na NASu (místo hned volné)."""
        opened = self._av_started
        channel = self._live_channel
        with self._resume_lock:
            self._av_gen += 1
        try:
            if getattr(self, "_av_change_timer", None) is not None:
                self._av_change_timer.cancel()
                self._av_change_timer = None
        except Exception:
            pass
        if not opened:
            _dt_ms = int((time.monotonic() - self._open_ts) * 1000) if self._open_ts else -1
            _log(f"LIVE_OPEN_FAILED: {kind} bez onAVStarted dt_ms={_dt_ms}", xbmc.LOGWARNING)
            _rm_dispatch.finish("error" if kind == "error" else "open_failed", ident=self._open_ident)
        elif kind == "error":
            _rm_dispatch.finish("error", ident=self._open_ident)
        if kind == "error":
            self._open_seq += 1                # parita s VOD: chyba = konec tohoto otevření
        self._end_handled = kind == "ended"    # pozdní Stopped po Ended nic nezdvojí (A#1)
        self._av_started = False
        self._open_ts = 0.0
        self._open_live = False
        self._end_live_session("player_" + kind)
        _log(f"LIVE_ENDED kind={kind} channel={channel or '-'} opened={opened}", xbmc.LOGINFO)
        if _rm_kind.allows(_rm_kind.LIVE, "return_to_ui"):
            self._maybe_return_to_richmovie()   # zpět do seznamu kanálů, odkud se pouštělo (jen start z okna RichMovie)

    def _start_watch(self, seq: int, opened_at: float, ident: str) -> None:
        """Φ6 (audit A05 R1): hlídač jednoho otevření. Rozhoduje `richmovie_start_watch.next_action`;
        končí, jakmile naskočí obraz, otevírání skončí (Stopped/Ended/Error nulují `_open_ts`) nebo začne jiné."""
        mon = xbmc.Monitor()
        done = set()
        broken_at = None

        def _same_open() -> bool:
            return (self._open_seq == seq and self._open_ts == opened_at and bool(opened_at)
                    and not self._av_started)

        try:
            while not mon.waitForAbort(_rm_sw.TICK_S):
                if not _same_open():
                    return
                elapsed = time.monotonic() - opened_at
                action = _rm_sw.next_action(elapsed, busy=(_rm_sw.busy_visible() or self._ui_busy()), done=done)
                if action == _rm_sw.ACTION_WAIT:
                    continue
                if action == _rm_sw.ACTION_DONE:
                    return
                done.add(action)
                if action == _rm_sw.ACTION_SLOW:
                    _osf = _os_filter_kind()
                    _log(f"START_SLOW: bez obrazu {elapsed:.1f}s os_filter={_osf or '-'}", xbmc.LOGINFO)
                    _rm_notif(_rm_sw.slow_text(_osf), xbmcgui.NOTIFICATION_INFO, None, "RichMovie")
                elif action == _rm_sw.ACTION_STALL:
                    broken_at = self._note_start_stall(elapsed, ident)
                elif action == _rm_sw.ACTION_HINT:
                    _osf = _os_filter_kind()
                    _log(f"START_STALL_HINT: kolečko Kodi běží → jen toast os_filter={_osf or '-'}", xbmc.LOGINFO)
                    _rm_notif(_rm_sw.stall_hint_text(_osf), xbmcgui.NOTIFICATION_WARNING, None, "RichMovie")
                elif action == _rm_sw.ACTION_ASK:
                    # Cross-check Pro A7: modální dialog NE v tomhle (non-daemon) vlákně — otevřený dialog by
                    # blokoval ukončení Kodi (5s okno). Dialog žije v daemon vlákně (vzor `_give_up_auto_resume`),
                    # hlídač ho zavře, když se stream mezitím otevře nebo otevírání skončí.
                    asking = threading.Event()   # nabídka hlídače je PRÁVĚ na obrazovce (audit Fable F-4)
                    asker = threading.Thread(target=self._ask_other_stream_on_stall,
                                             args=(seq, _same_open, broken_at, asking), name="RMStartAsk",
                                             daemon=True)
                    asker.start()
                    while asker.is_alive() and not mon.waitForAbort(_rm_sw.TICK_S):
                        if not _same_open():
                            # zavřít jen vlastní nabídku — cizí yes/no (nastavení, jiný doplněk) nechat být
                            if asking.is_set():
                                xbmc.executebuiltin("Dialog.Close(yesnodialog,true)")
                            _log("START_STALL_ASK_CLOSED: obraz naskočil / otevírání skončilo → nabídka zavřena",
                                 xbmc.LOGINFO)
                            break
                    return
        except Exception as exc:
            _log(f"start watch failed: {exc!r}", xbmc.LOGWARNING)

    def _note_start_stall(self, elapsed: float, ident: str) -> "float | None":
        """Zaseknuté NAVÁZÁNÍ na pozici → záznam do `richmovie_source_health` (start od nuly se nepočítá).
        Vrací pozici, od které je soubor vadný, nebo None."""
        import richmovie_resume as _rres_sw
        plan = _rres_sw.load_pending()
        target = float((plan or {}).get("target") or 0) if _rres_sw.pending_valid(plan, ident) else 0.0
        _log(f"START_STALL: bez obrazu {elapsed:.0f}s ident={ident or '?'} cíl={target:.0f}s",
             xbmc.LOGWARNING, context={"ident": ident, "elapsed_s": int(elapsed), "target_s": int(target)})
        if not ident or target <= 0:
            return None
        # Cross-check Pro A4: výpadek sítě není vadný soubor. Počítá se jen, když CDN streamu odpovídá (jakákoli HTTP
        # odpověď = trasa funguje; SSOT „síť = cesta ke zdroji“, `_cdn_reachable`) — jinak by utnutí sítí + zaseknutý
        # start po výpadku označily zdravý soubor jako vadný. Vlákno hlídače není daemon (HTTP).
        if not self._cdn_reachable():
            _log("START_STALL_NOT_COUNTED: CDN neodpovídá → výpadek sítě, ne vadný soubor", xbmc.LOGINFO)
            return None
        # Noc 03.11.2026 (Φ1): systémový filtr obsahu zdržuje každý velký přenos — zaseknutí není vlastnost
        # souboru (Bětčin Mac: 6 ze 6 startů). Soubor by se jinak na 30 dní odsunul na konec výpisu.
        _osf = _os_filter_kind()
        if _osf:
            _log(f"START_STALL_NOT_COUNTED: systémový filtr obsahu ({_osf}) → ne vadný soubor", xbmc.LOGINFO)
            return None
        try:
            import richmovie_source_health as _sh_sw
            return _sh_sw.note_open_stall(ident, target, float((plan or {}).get("total") or 0))
        except Exception as exc:
            _log(f"source health (stall) failed: {exc!r}", xbmc.LOGWARNING)
            return None

    def _ask_other_stream_on_stall(self, seq: int, same_open, broken_at: "float | None",
                                   asking: "threading.Event | None" = None) -> None:
        """Nabídka po T2 — jen bez kolečka Kodi (rozhodlo `next_action`). „Zkusit jiný stream“ = Stop tohoto
        otevření a výpis streamů téhož titulu (`_other_stream_target`), „Čekat“ = Kodi otevírá dál."""
        try:
            li = self.getPlayingItem()
        except Exception:
            li = None
        target = self._other_stream_target(li) if li is not None else ""
        if asking is not None:
            asking.set()
        try:
            choose = xbmcgui.Dialog().yesno("RichMovie", _rm_sw.stall_question(broken_at),
                                            yeslabel=_rm_sw.STALL_YES, nolabel=_rm_sw.STALL_NO,
                                            autoclose=_rm_sw.STALL_ASK_AUTOCLOSE_MS)
        finally:
            if asking is not None:
                asking.clear()
        if not same_open():
            _log("START_STALL_ASK: mezitím naskočil obraz / otevírání skončilo → nic", xbmc.LOGINFO)
            return
        if not choose:
            _log("START_STALL_WAIT: divák čeká dál", xbmc.LOGINFO)
            return
        _log(f"START_STALL_SWITCH: divák chce jiný stream → Stop otevírání (výpis: {'ano' if target else 'ne'})",
             xbmc.LOGWARNING)
        self._stall_redirect = (seq, target)
        self.stop()

    def onAVStarted(self):
        """
        24-08-2025 13:04 CEST (Europe/Prague)
        ÚČEL: Při startu nového přehrávání vyčistit veškerou „odloženou" navigaci
        (včetně nových property s očekávaným cílem), aby po skončení předchozího
        videa nedošlo k omylům. Zachováno: start watch‑loopu (prefetch + dialog).
        """
        # Televizní kanály F3: živý kanál jde vlastní cestou (žádné vlákno ani stav VOD); start VOD po kanálu bez
        # `onPlayBackStarted` (pojistka) relaci relay ukončí. VOD a cizí přehrávání pokračují beze změny.
        if self._playing_is_live():
            self._on_live_av_started()
            return
        self._open_live = False
        if self._live_playing:
            self._end_live_session("switched_to_vod")
        _log("[TitlePrefs] onAVStarted - starting av_monitor")
        # 4.0.3 (M2): předchozí titul, který Kodi neukončilo (přepnutí za běhu), uzavřít DŘÍV, než se cache vynuluje
        self._close_superseded_title()
        self._av_started = True   # 3.5.129: stream se reálně otevřel (audio+video tečou)
        # Φ1 (29.09.2026): obraz naskočil = konec startu → uvolnit pojistku jednoho spuštění (+ doba od odeslání)
        _rm_dispatch.finish("av_started", ident=self._open_ident)
        # 4.0.2 (E9): relace přehrávání začíná s obrazem (tik služby ji pak drží, dokud existuje přehrávač)
        _rm_dispatch.session_note(True)

        # Reset CW cache pro nove prehravani
        self._end_handled = False
        self._cached_pos = 0.0
        self._cached_dur = 0.0
        self._cached_li = None
        self._cached_at = 0.0
        self._cw_last_saved = None          # nový titul = první checkpoint se zapíše vždy
        self._cw_last_change_ts = 0.0
        self._cw_suppress_final_key = ""
        self._handoff_seek_expected = -1.0
        self._attention_snapshot = None
        self._observed_video = None
        self._restart_inflight_until = 0.0   # obnova spojení (pokud běžela) otevřela stream
        self._reconnect_open_gen = -1
        try:
            self._last_stream_url = self.getPlayingFile() or ""
        except Exception:
            self._last_stream_url = ""
        # 3.5.151 (Φ1): navázání na pozici, které pro TENTO stream připravil `plugin._play`
        _resume_pending = self._resume_take_pending()
        # 3.5.149 / 4.0.3 (M6): kdo tenhle díl spustil? Značku `richmovie.autoplay` nese PŘEHRÁVANÁ POLOŽKA
        # (`plugin._play_resolve` z `autoplay=1` v adrese) — nemůže viset do dalšího ručního startu jako dřívější
        # globální Window prop. Ruční spuštění (klik člověka) ji nemá → řetěz bdělosti se nuluje.
        _is_auto = False
        try:
            import richmovie_attention as _att_s
            import richmovie_resume as _rres_att
            try:
                _is_auto = self.getPlayingItem().getProperty("richmovie.autoplay") == "1"
            except RuntimeError:
                _is_auto = False
            from richmovie_playback_end import player_ctx_key as _att_key
            _att_k = _att_key() or ""
            if (_resume_pending and _resume_pending.get("source") in _rres_att.RESTART_SOURCES
                    and _att_k and _att_s.TRACKER.key == _att_k):
                # 3.5.151: navázání TÉHOŽ dílu po utnutí / obnově spojení není nový díl — vstupy
                # diváka z první části dílu platí dál (begin by je smazal a díl by vyšel „bez diváka").
                _log("ATTENTION: navázání téhož dílu → bdělost beze změny", xbmc.LOGDEBUG)
            else:
                _att_s.TRACKER.begin(_att_k, autoplay=_is_auto)
                if not _is_auto:
                    _att_s.clear_state()
                    _log("ATTENTION: ruční spuštění → řetěz bdělosti vynulován", xbmc.LOGDEBUG)
        except Exception as _att_exc:
            _log(f"attention begin failed: {_att_exc!r}", xbmc.LOGDEBUG)
        try:
            from richmovie_playback_end import player_ctx_key as _open_key
            self._title_open_key = _open_key() or ""   # otevřený titul — zavře ho Ended/Stopped/přepnutí za běhu
        except Exception:
            self._title_open_key = ""
        self._observed_av = None  # Φ4: observed pref snapshot patří MINULÉMU titulu
        self._cw_advanced_key = ""  # R3-P1-2: advance throttle patří minulému dílu
        self._early_watched_key = ""  # 4.0.3 (M8): ✔ v titulcích patří minulému titulu

        # Zastavit starý av_monitor (inkrementace generace)
        self._av_gen += 1
        my_gen = self._av_gen

        # Start AV monitor thread (polling fallback pro per-title pref detekci)
        threading.Thread(target=self._av_monitor_loop, args=(my_gen,), daemon=True).start()

        # 3.5.151 (Φ1): ověření navázání (až Kodi stream skutečně otevře)
        if _resume_pending:
            self._resume_verify_start(my_gen, _resume_pending)
        # 3.5.151 (Φ3b): hlídání mrtvého zdroje + kodek/výška pro profil verze (Φ3c).
        # Non-daemon: kontrola CDN před obnovou spojení je HTTP (feedback_daemon_threads_kodi).
        threading.Thread(target=self._dead_source_watch, args=(my_gen,), name="RMDeadSourceWatch",
                         daemon=False).start()
        # 3.5.151 (Φ3c): autoplay dalšího dílu — jakou verzi služba vybrala a proč. Info patří výběru DALŠÍHO dílu:
        # obnova téhož dílu (auto-resume / obnova spojení) ho nechá čekat; každý jiný start ho spotřebuje — autoplay
        # s toastem, ruční start bez něj (jinak by zastaralé info čekalo na pozdější navázání toho dílu; Pro B2 QC4)
        try:
            import richmovie_resume as _rres_pick
            _restart = bool(_resume_pending and _resume_pending.get("source") in _rres_pick.RESTART_SOURCES)
        except Exception:
            _restart = False
        if not _restart:
            self._show_autoplay_pick(show=_is_auto)

        # Fable F3 (3.5.151): soubor otevřený ZA BĚHU (obnova spojení `Player.play`) nepřinese Ended ani
        # Stopped → měření předchozího segmentu je pořád otevřené. Uzavřít ho teď, až nový stream opravdu
        # hraje; obnova mrtvého zdroje = utnutí, marker `eof` jen za PRVNÍ navázání řetězu (parita
        # s onPlayBackEnded, cross-check Pro 31.08. P3). Bez toho by výpadek v evidenci chyběl.
        if self._cache_meter is not None:
            try:
                import richmovie_resume as _rres_cm
                _reconnect = bool(_resume_pending
                                  and _resume_pending.get("source") == _rres_cm.SOURCE_RECONNECT)
            except Exception:
                _reconnect = False
            self._cache_meter_finish(
                unexpected_eof=_reconnect and int(getattr(self, "_resume_attempts", 0) or 0) <= 1)

        # Φ1 (3.5.127): dedikovaný 2s sampler plnění cache (av_monitor jede po 15 s
        # — pro fill s ideálem ~80 s je to šum ±20 %; do av_monitoru se NEZASAHUJE).
        self._cache_meter_start(my_gen)

        # Φ2 (2026-07-06, UX audit A01 — jádro bugu „Back → Kodi menu"):
        # fullscreen-exit watcher. Back z fullscreenu NEzastaví přehrávání →
        # žádný player callback → návratový kontrakt se nikdy nespustí.
        threading.Thread(target=self._fullscreen_exit_watch, args=(my_gen,),
                         daemon=True).start()

        if _enabled():
            # Vyčistit případné „pending" hodnoty z minula
            win = xbmcgui.Window(10000)
            win.clearProperty("richmovie.nextup.nav_url")
            win.clearProperty("richmovie.nextup.nav_pending")
            win.clearProperty("richmovie.nextup.expected_key")
            win.clearProperty("richmovie.nextup.expected_url")
            win.clearProperty("richmovie.nextup.autoplay_url")
            win.clearProperty("richmovie.nextup.toast_key")
            win.clearProperty("richmovie.nextup.chain_stopped")

            # Start hlídací smyčky (prefetch + dotaz před koncem). 3.5.151: s generací — nový
            # soubor otevřený ZA BĚHU (obnova spojení, Kodi neposílá Stopped) by jinak nechal
            # běžet dvě smyčky nad jedním přehráváním (dvojí prefetch, toasty, checkpointy).
            threading.Thread(target=self._watch_loop, args=(my_gen,), daemon=True).start()


    # ── 13.09.2026 (3.5.148, Φ1): pauza / resume / seek jsou UDÁLOSTI stavu ──────────
    # Dřív pozice z pauzy čekala na 30s checkpoint + 60s kadenci pushe. Teď: zápis CW hned
    # s `activity` a `request_push()` → Gate ji má do sekund, ostatní zařízení přes long-poll.
    def onPlayBackPaused(self) -> None:
        self._note_activity("paused")

    def onPlayBackResumed(self) -> None:
        self._note_activity("playing")

    def onPlayBackSeek(self, time_ms: int, seekOffset_ms: int) -> None:
        try:
            target = float(time_ms) / 1000.0
        except (TypeError, ValueError):
            return
        expected = float(getattr(self, "_handoff_seek_expected", -1.0))
        if expected >= 0 and abs(target - expected) < HANDOFF_SEEK_TOLERANCE_S:
            # seek, který jsme sami vyvolali (handoff / oprava navázání) — není to akce uživatele
            self._handoff_seek_expected = -1.0
            _log(f"OWN_SEEK_ACK target={target:.0f}s (vlastní seek, bez pushe)", xbmc.LOGDEBUG)
            return
        if self._resume_hold is not None:
            # 3.5.151 (Φ2): uživatel převzal řízení — jeho pozice platí, navázání se už neověřuje
            _log(f"RESUME_HOLD_RELEASED: uživatelský seek na {target:.0f}s", xbmc.LOGINFO)
            with self._resume_lock:
                self._resume_hold = None
                self._resume_verify_token += 1
        self._note_activity(None, position_override=target)

    def _seek_own(self, position: float) -> None:
        """Seek vyvolaný službou (handoff, oprava navázání): `onPlayBackSeek` ho pozná podle
        `_handoff_seek_expected` a nepočítá ho jako vstup uživatele (push, bdělost, uvolnění
        blokace). Jedno místo pro oba případy."""
        self._handoff_seek_expected = float(position)
        self.seekTime(float(position))

    # ── 3.5.151 (Φ1/Φ2): ověření navázání na pozici ──────────────────────────────────
    def _resume_take_pending(self):
        """Převezme čekající navázání pro právě otevřený stream (ident z PlayingItem)."""
        try:
            import richmovie_resume as _rres
            try:
                ident = self.getPlayingItem().getProperty("richmovie.ident") or ""
            except Exception:
                ident = ""
            pending = _rres.take_pending(ident)
        except Exception as exc:
            _log(f"resume pending read failed: {exc!r}", xbmc.LOGDEBUG)
            pending = None
        with self._resume_lock:
            self._resume_verify_token += 1      # případné ověření minulého streamu končí
            if pending:
                self._resume_hold = {"ident": pending.get("ident"), "target": pending.get("target"),
                                     "source": pending.get("source")}
            else:
                self._resume_hold = None
        return pending

    def _resume_verify_start(self, gen: int, plan: dict) -> None:
        token = self._resume_verify_token
        stream_file = self._last_stream_url

        def _same_file() -> bool:
            # Generace se mění až v onAVStarted NOVÉHO souboru; Kodi ale mění přehrávaný soubor už při jeho
            # otevírání (Player.play / PlayMedia za běhu). Bez této kontroly by ověření v tom okně četlo délku
            # a čas otevíraného streamu a opravný seek by skočil do něj (cross-check Pro A QA5, 17.09.).
            if not stream_file:
                return True
            try:
                return self.getPlayingFile() == stream_file
            except RuntimeError:
                return False

        def _alive() -> bool:
            return (self._av_gen == gen and self._resume_verify_token == token
                    and not xbmc.Monitor().abortRequested() and self.isPlaying() and _same_file())

        def _seek_checked(target: float) -> None:
            # Kontrola a seek atomicky vůči onAVStarted/onPlayBackSeek (cross-check Pro A PA2): mezi
            # posledním čekáním a seekem se mohl otevřít JINÝ stream — oprava do něj nesmí skočit.
            with self._resume_lock:
                if not _alive():
                    _log("RESUME_CORRECTION_SKIPPED: stream se mezitím změnil", xbmc.LOGINFO)
                    return
                self._seek_own(target)

        def _run() -> None:
            import richmovie_resume as _rres
            result = _rres.run_verification(self, xbmc.Monitor(), plan, alive=_alive, seek_own=_seek_checked)
            outcome = result.get("outcome")
            with self._resume_lock:
                # Kontrola „pořád tentýž stream" a uvolnění blokace atomicky (Fable F6): mezi nimi mohl
                # onAVStarted nového streamu nastavit blokaci JEHO navázání — ta se smazat nesmí.
                if self._av_gen != gen or self._resume_verify_token != token:
                    return
                if outcome in (_rres.OUTCOME_NATIVE_OK, _rres.OUTCOME_CORRECTED, _rres.OUTCOME_IGNORED):
                    self._resume_hold = None   # ověřeno → checkpointy zase normálně
                    return
            if outcome == _rres.OUTCOME_UNVERIFIED:
                # Stream se do 45 s nerozjel (cross-check Flash F4): blokace ZŮSTÁVÁ. Když Kodi pak otevře
                # stream nativně na cíli, pozice je nad cílem a `hold_checkpoint` nic neblokuje; když by hrál
                # od nuly, Pokračovat nepřepíše. Uvolní ji ruční seek, Stop nebo další přehrávání.
                _log("RESUME_HOLD_KEPT: start neověřen, Pokračovat se nepřepíše nižší pozicí", xbmc.LOGINFO)
            elif outcome == _rres.OUTCOME_FAILED:
                # D1: hraje se dál, Pokračovat zůstává na cíli, dokud divák nepřetočí sám
                try:
                    _rm_notif(
                        "Nepodařilo se navázat na %s — přetoč ručně" % _rres.format_time(plan.get("target")),
                        xbmcgui.NOTIFICATION_WARNING,
                        6000,
                        "RichMovie",
                    )
                except Exception:
                    pass

        threading.Thread(target=_run, name="RMResumeVerify", daemon=True).start()

    def _note_activity(self, activity, *, position_override: float = -1.0) -> None:
        """Okamžitý checkpoint CW s activity (None = podle `Player.Paused`) + vynucený push.
        Akce uživatele = konec tolerance po handoffu (`_cw_min_delta` zpět na výchozí)
        a zároveň DŮKAZ BDĚLOSTI (3.5.149): řetěz dílů bez reakce se nuluje."""
        if self._open_live:
            return   # Televizní kanály F3: živý kanál nemá Pokračovat ani stav k pushi (pauza / seek / resume)
        self._cw_min_delta = None
        try:
            import richmovie_attention as _att_n
            _att_n.TRACKER.note_input()
        except Exception:
            pass
        try:
            if position_override >= 0:
                self._cached_pos = float(position_override)
                self._cached_at = time.monotonic()
            self._save_cw_position(final=False, activity=activity, position_override=position_override)
            import richmovie_state_sync as _ss
            _ss.request_push()
        except Exception as exc:
            _log(f"activity checkpoint failed: {exc!r}", xbmc.LOGWARNING)

    def current_activity(self) -> str:
        """SSOT: co přehrávač právě dělá (playing/paused/stopped) podle Kodi."""
        try:
            if not self.isPlaying():
                return "stopped"
            return "paused" if xbmc.getCondVisibility("Player.Paused") else "playing"
        except Exception:
            return "stopped"

    @_ends_playback
    def onPlayBackEnded(self) -> None:
        """
        Video dokonceno -> smazat z continue watching + auto-play nebo odlozena navigace.
        """
        _kick_log_archive()
        _restore_primed_streams("playback_end")
        if self._open_live:
            self._on_live_end("ended")   # Televizní kanály F3: konec vysílání ≠ dokoukaný titul — nic z VOD
            return
        # Zastavit av_monitor (inkrementace generace) + cancel debounce timer.
        # 3.5.151: pod `_resume_lock` — obnova spojení kontroluje generaci pod týmž zámkem (Pro A PA4a)
        with self._resume_lock:
            self._av_gen += 1
        try:
            if hasattr(self, "_av_change_timer") and self._av_change_timer is not None:
                self._av_change_timer.cancel()
                self._av_change_timer = None
        except Exception:
            pass
        self._write_observed_pref()  # Φ4: reálně použitá stopa → observed pref
        self._write_stream_profile()  # Φ3c (3.5.151): verze streamu pro další díl
        self._title_open_key = ""    # 4.0.3 (M2): titul uzavírá tenhle callback
        # A#1 (Fable audit): některé platformy pošlou po Ended ještě Stopped.
        # Bez guardu druhý callback nastavil chain_stopped=1 a vynuloval čítač
        # → auto-resume PlayMedia byl VŽDY zrušen. Hook má týž guard (_finalized).
        self._end_handled = True
        if not self._av_started:
            # Φ1: Ended bez obrazu = start se nepovedl → uvolnit pojistku jednoho spuštění
            _rm_dispatch.finish("ended_no_av", ident=self._open_ident)
        self._av_started = False
        self._open_ts = 0.0   # 3.5.129: konec = razítko otevření už neplatí (Pro PB11)

        # 3.5.119 (B2): Kodi „konec souboru" NENÍ důkaz dokoukání. CDN utne
        # stream → CFileCache EOF → onPlayBackEnded při 40 % (incident Zelňačka
        # 23.08.2026: film označen ✔ a smazán z Pokračovat). Rozhoduje SSOT
        # richmovie_playback_end podle POZICE, ne podle callbacku.
        position, duration, position_lag = self._last_known_progress_with_lag()
        from richmovie_playback_end import classify_end_shared as _classify_shared, player_ctx_key as _ctx_key
        end_kind = _classify_shared(_ctx_key(), kodi_ended=True, position_s=position,
                                    duration_s=duration, position_lag_s=position_lag)
        # Φ1: uzavřít měření plnění cache — UNEXPECTED_EOF = `eof` marker
        # (nejhorší síťové stavy nesmí být v evidenci neviditelné, audit P1.2).
        # Cross-check Pro 31.08. (2. kolo, P3): auto-resume řetěz by z JEDNOHO
        # výpadku vyrobil až 3 eof markery (každé krátké navázání = nový tracker)
        # a sám překročil práh shrinku. Marker proto zapisuje jen PRVNÍ utnutí
        # řetězu (`_resume_attempts == 0` = ještě se nenavazovalo); navázané
        # segmenty končí bez vzorku (krátké pozorování → finish vrátí None).
        _eof_first_in_chain = (end_kind is EndKind.UNEXPECTED_EOF
                               and int(getattr(self, "_resume_attempts", 0) or 0) == 0)
        self._cache_meter_finish(unexpected_eof=_eof_first_in_chain)
        if end_kind is EndKind.UNEXPECTED_EOF:
            self._on_unexpected_eof(position, duration)
            return

        if end_kind is EndKind.UNKNOWN:
            # A#3 (Fable audit): délka neznámá → nelze rozlišit dokoukání od
            # utnutí. Kontrakt SSOT (richmovie_playback_end): žádné ✔, žádný
            # auto-resume — a tedy ani autoplay dalšího dílu (skočil by na
            # další díl uprostřed možná utnutého). Jen uložit, co jde, a vrátit.
            try:
                self._save_cw_position()
            except Exception:
                pass
            self._reset_auto_resume()
            win_u = xbmcgui.Window(10000)
            for _k in ("richmovie.nextup.autoplay_url", "richmovie.nextup.nav_url",
                       "richmovie.nextup.nav_pending", "richmovie.nextup.expected_key",
                       "richmovie.nextup.expected_url"):
                win_u.clearProperty(_k)
            _log("END_UNKNOWN: duration neznámá — bez autoplay/✔", xbmc.LOGINFO)
            self._maybe_return_to_richmovie()
            return

        try:
            self._save_cw_position()
        except Exception:
            pass
        self._reset_auto_resume()

        # 3.5.152 (Petra Φ3): dokoukaný FILM → „Jak se ti líbil?" (vlákno čeká na zavření
        # fullscreenu, dialog, pak návrat do RichMovie). Seriály: jen kontextové menu (D3).
        if self._maybe_ask_rating():
            return

        win = xbmcgui.Window(10000)

        # 1) AUTO-PLAY: prime prehrani dalsiho dilu (bez seznamu streamu)
        autoplay_url = win.getProperty("richmovie.nextup.autoplay_url") or ""
        if autoplay_url:
            win.clearProperty("richmovie.nextup.autoplay_url")
            # Vycistit pripadne nav properties (autoplay ma prednost)
            win.clearProperty("richmovie.nextup.nav_url")
            win.clearProperty("richmovie.nextup.nav_pending")
            win.clearProperty("richmovie.nextup.expected_key")
            win.clearProperty("richmovie.nextup.expected_url")
            _spawn_followup("autoplay", self._autoplay_safely, args=(autoplay_url,), daemon=True)
            return

        # 2) DIALOG navigace (Container.Update na seznam streamu)
        url = win.getProperty("richmovie.nextup.nav_url") or ""
        if not url:
            # Žádná next-up navigace → pokud přehrávání startovalo z RM 4.0 UI,
            # vrať uživatele do RichMovie Home, ne do holého Kodi (P0-3).
            self._maybe_return_to_richmovie()
            return

        self._navigate(url)

    def _maybe_ask_rating(self) -> bool:
        """Zeptat se po přehrání na hodnocení. True = dialog převzal i návrat do RichMovie.

        FILM (3.5.152): jednou po přirozeném konci.
        SERIÁL (3.5.154, rozhodnutí Richie 20.09.2026 — ruší D3): dvakrát za život seriálu —
        po polovině první řady (nejpozději po 5. dokoukaném dílu) a po dokoukání celého.
        Obojí rozhoduje čistá funkce v `richmovie_ratings`; tady se jen sbírají vstupy.
        """
        li = self._cached_li
        if li is None:
            return False
        if li.getProperty("richmovie.tv_id"):
            return self._maybe_ask_rating_series(li)
        try:
            tmdb_id = int(li.getProperty("richmovie.m_tmdb") or 0)
            if tmdb_id <= 0:
                return False
            title = (li.getVideoInfoTag().getTitle() or "").strip()
            import richmovie_attention as _att_r
            import richmovie_profile as _rp_r
            import richmovie_ratings as _rt_r
            from richmovie_playback_end import player_ctx_key as _rt_key
            watched_kind = _att_r.TRACKER.current_kind(_rt_key() or "")
            enabled = richmovie_settings.get_bool("rating_ask_enabled")
            if not _rt_r.should_ask(_rt_r.get("movie", tmdb_id), _rt_r.skipped_count("movie", tmdb_id),
                                    watched_kind=watched_kind,
                                    is_guest=_rp_r.is_guest() or not _rp_r.has_active_profile(), enabled=enabled):
                _log(f"RATING_ASK skipped tmdb={tmdb_id} kind={watched_kind} enabled={enabled}", xbmc.LOGDEBUG)
                return False
            try:
                poster = li.getArt("poster") or li.getArt("thumb") or ""
                fanart = li.getArt("fanart") or ""
            except Exception:
                poster, fanart = "", ""
        except Exception as exc:
            _log(f"rating ask precheck failed: {exc!r}", xbmc.LOGDEBUG)
            return False

        def _run() -> None:
            try:
                mon = xbmc.Monitor()
                if not self._wait_fullscreen_closed(mon, require_player_stopped=True, wait_s=6.0):
                    return
                if self.isPlaying() or mon.abortRequested():
                    return
                import richmovie_rating_ui as _rui
                _log(f"RATING_ASK tmdb={tmdb_id} title={title[:60]}", xbmc.LOGINFO,
                     context={"tmdb_id": tmdb_id})
                _rui.collect("movie", tmdb_id, title, poster=poster, fanart=fanart)
            except Exception as exc:
                _log(f"rating dialog failed: {exc!r}", xbmc.LOGWARNING)
            finally:
                self._maybe_return_to_richmovie()

        _spawn_followup("rating_ask", _run, name="RMRatingAsk", daemon=True)
        return True

    def _navigate(self, url: str) -> None:
        """Naviguje na cílovou URL (seznam streamů) po zavření přehrávače.
        Vlákno: čeká na zavření fullscreen videa, zavře modální dialogy, v RM 4.0
        replayne origin okna a spustí RunPlugin; legacy = Container.Update.
        3.5.119: extrahováno z onPlayBackEnded (closure) — používá i B3 auto-resume
        (dialog „vybrat jiný stream")."""
        xbmcgui.Window(10000).clearProperty("richmovie.nextup.nav_url")
        xbmcgui.Window(10000).setProperty("richmovie.nextup.nav_inflight", "1")

        def _navigate_safely(u: str) -> None:
            _log(f"NAV_START: {u[:80]}...", xbmc.LOGINFO)
            mon = xbmc.Monitor()

            if not self._wait_fullscreen_closed(mon, require_player_stopped=True):
                _log("NAV_ABORT: Kodi shutting down")
                return
            _log("NAV_FULLSCREEN_CLOSED", xbmc.LOGINFO)

            for _ in range(20):  # <=2 s
                if mon.abortRequested():
                    return
                if xbmc.getCondVisibility("System.HasActiveModalDialog"):
                    xbmc.executebuiltin("Dialog.Close(all,true)")
                    xbmc.sleep(100)
                else:
                    break

            # Φ2 (2026-07-06, audit A04/A08): RM 4.0 custom UI — ŽÁDNÝ
            # ActivateWindow(Videos)/Container.Update (legacy únik z nového
            # designu). Základ = replay origin oken (Home…), cílová akce se
            # spustí RunPluginem: tv_play&rm_token → custom Stream-picker si
            # otevře fallback v _list_releases; rm_episodes → custom okno.
            if _is_custom_ui():
                _skip_target = False
                try:
                    import richmovie_ui_common as _uc_nav
                    _desc = _uc_nav.consume_return_route()
                    _uc_nav.replay_return_routes(_desc or {},
                                                 abort_check=mon.abortRequested)
                    # R2-P2-11: cílová routa (typicky rm_episodes) už mohla být
                    # právě replaynuta z originu — porovnat action+tv_id
                    # (STRUKTURNĚ, ne přes tv_name text) a duplikát vynechat.
                    try:
                        _tq = urllib.parse.parse_qs(u.split("?", 1)[1]) if "?" in u else {}
                        _t_action = (_tq.get("action") or [""])[0]
                        _t_tvid = (_tq.get("tv_id") or [""])[0]
                        _routes = (_desc or {}).get("routes") or []
                        _last = _routes[-1] if _routes else {}
                        if (_t_action and _t_action == (_last.get("action") or "")
                                and _t_tvid
                                and _t_tvid == ((_last.get("params") or {}).get("tv_id") or "")):
                            _skip_target = True
                    except Exception:
                        _skip_target = False
                    xbmc.sleep(400)
                except Exception as _re:
                    _log(f"NAV_CUSTOM replay: {_re}", xbmc.LOGWARNING)
                try:
                    if _skip_target:
                        _log("NAV_OK (custom, cíl = replaynutá routa — vynechán)")
                    else:
                        xbmc.executebuiltin(f"RunPlugin({u})")
                        _log("NAV_OK (custom)")
                except Exception as _rp:
                    _log(f"NAV_CUSTOM err: {_rp}", xbmc.LOGWARNING)
                w = xbmcgui.Window(10000)
                w.clearProperty("richmovie.nextup.nav_inflight")
                return

            safe_url = urllib.parse.quote(u, safe="/:?&=%")

            try:
                xbmc.executebuiltin("ActivateWindow(Videos)")
                xbmc.sleep(100)
                xbmc.executebuiltin(f"Container.Update({safe_url},replace)")
                xbmc.Monitor().waitForAbort(0.5)
                _log("NAV_OK")
            except Exception as e:
                _log(f"NAV_ERR: {e}", xbmc.LOGINFO)
                try:
                    xbmc.executebuiltin(f"ActivateWindow(Videos,{safe_url},return)")
                    _log("NAV_FALLBACK_OK")
                except Exception as e2:
                    _log(f"NAV_FALLBACK_ERR: {e2}", xbmc.LOGINFO)

            w = xbmcgui.Window(10000)
            w.clearProperty("richmovie.nextup.nav_inflight")

        _spawn_followup("navigate", _navigate_safely, args=(url,), daemon=True)

    def _attention_gate(self, play_url: str = "") -> bool:
        """„Díváš se ještě?" (3.5.149; 4.0.3 D1–D3, incident 06.10.2026).

        True = pokračovat dalším dílem. False = řetěz končí. Odpověď rozhoduje deterministický dialog
        (`richmovie_still_watching`): „Pokračovat" = dál; „Dnes už končím" / Zpět = konec BEZ trestu (✔ zůstávají,
        Pokračovat ukáže další díl); vypršení bez jediného stisku = PROKÁZANÝ spánek → verdikt spánku
        (`_sleep_verdict`: ⏾ dílům řetězu + Pokračovat na první z nich s volbou). Rozhodnutí `should_ask` je čistá
        funkce (harness 58/90). Chyba PŘED rozhodnutím = pokračovat (dotaz nesmí zabít přehrávání)."""
        try:
            import richmovie_attention as _att
        except Exception:
            return True
        try:
            cfg = _att.settings_thresholds()
            tr = _att.TRACKER
            streak, idle_s = tr.streak, tr.idle_s()
            if not _att.should_ask(streak, idle_s, ask_after=cfg["ask_after"], idle_min=cfg["idle_min"]):
                return True
            if xbmc.Monitor().abortRequested():
                return False   # Kodi se vypíná: řetěz nepokračuje a na dialog není 5s okno
            _log(f"ATTENTION_ASK: řetěz={streak} nečinnost={int(idle_s // 60)} min → dotaz", xbmc.LOGINFO)
            tr.note_ask_shown()
            _att.save_state()    # Kodi může zemřít s dotazem na obrazovce (vybitá baterie) → verdikt dořeší start
            import richmovie_still_watching as _sw_dlg
            series, next_label, poster, fanart = self._attention_dialog_texts(play_url)
            answer = _sw_dlg.ask(series=series, next_label=next_label, streak=streak, idle_min=int(idle_s // 60),
                                 poster=poster, fanart=fanart, timeout_s=float(cfg["timeout_s"]))
        except Exception as exc:
            _log(f"attention gate failed before answer: {exc!r} → pokračovat", xbmc.LOGWARNING)
            return True
        try:
            if answer == _att.ANSWER_CONTINUE:
                tr.note_input()      # odpověď JE vstup: řetěz od nuly
                _att.clear_state()
                _log("ATTENTION_ASK: pokračovat", xbmc.LOGINFO)
                return True
            if answer == _att.ANSWER_STOP:
                # člověk odpověděl → u dílů byl; ✔ zůstávají `attended`, Pokračovat = další díl (už ho nabídl advance)
                tr.note_input()
                _att.clear_state()
                _log("ATTENTION_ASK: dnes už končím (odpověděl člověk → bez verdiktu spánku)", xbmc.LOGINFO)
                self._maybe_return_to_richmovie()
                return False
            if answer == _att.ANSWER_ABORT:
                _log("ATTENTION_ASK: Kodi se vypíná → řetěz dořeší start služby", xbmc.LOGINFO)
                return False
            _log("ATTENTION_ASK: bez odpovědi → verdikt spánku", xbmc.LOGINFO)
            self._sleep_verdict(tr, reason="timeout")
            self._maybe_return_to_richmovie()   # parita s ostatními konci přehrávání (Fable F7)
            return False
        except Exception as exc:
            # Chyba PO odpovědi nesmí řetěz pustit dál (Flash/Pro A 14.09.)
            _log(f"attention gate failed after answer: {exc!r}", xbmc.LOGWARNING)
            return False

    def _attention_dialog_texts(self, play_url: str) -> "tuple[str, str, str, str]":
        """(seriál, „S04E08 · Název", plakát, fanart) pro dialog — z adresy dalšího dílu a z právě dohraného dílu
        (žádná síť: dialog musí naskočit hned)."""
        series = next_label = poster = fanart = ""
        try:
            q = urllib.parse.parse_qs(play_url.split("?", 1)[1]) if "?" in play_url else {}
            series = (q.get("tv_name") or [""])[0]
            s_, e_ = int((q.get("season") or ["0"])[0] or 0), int((q.get("episode") or ["0"])[0] or 0)
            title = (q.get("ep_title") or [""])[0]
            if s_ > 0 and e_ > 0:
                next_label = "S%02dE%02d" % (s_, e_) + (" · %s" % title if title else "")
        except Exception:
            pass
        li = self._cached_li
        if li is not None:
            try:
                poster = li.getProperty("richmovie.poster_path") or li.getArt("poster") or ""
                fanart = li.getProperty("richmovie.backdrop_path") or li.getArt("fanart") or ""
                series = series or (li.getVideoInfoTag().getTVShowTitle() or "")
            except Exception:
                pass
        if poster.startswith("/"):
            poster = "https://image.tmdb.org/t/p/w342" + poster
        if fanart.startswith("/"):
            fanart = "https://image.tmdb.org/t/p/w1280" + fanart
        return series, next_label, poster, fanart

    def _sleep_verdict(self, tracker, *, reason: str) -> None:
        """Prokázaný spánek (dotaz vypršel / Kodi zemřelo uprostřed řetězu ≥ prahu): díly řetězu bez vstupu
        → `unattended` („⏾ usnul jsi?", JEDINÁ cesta snížení ✔ — `richmovie_history.watched_sleep_verdict`
        + compare-and-set na Gate) a Pokračovat zpět na první z nich s volbou „od začátku / už ho mám
        za sebou" (D3). Úklid řetězu vždy."""
        try:
            chain = tracker.chain_episodes()
            by_series: dict = {}
            for tv_id, s_, e_ in chain:
                if tv_id:
                    by_series.setdefault(str(tv_id), []).append((int(s_), int(e_)))
            marked = 0
            for tv_id, eps in by_series.items():
                marked += _hist.watched_sleep_verdict(tv_id, eps)
            _log(f"ATTENTION_SLEEP: {reason} → {marked}/{len(chain)} dílů ⏾", xbmc.LOGINFO)
            self._attention_rewind(tracker, asleep=chain)
        except Exception as exc:
            _log(f"sleep verdict failed: {exc!r}", xbmc.LOGWARNING)
        finally:
            tracker.reset_streak()
            try:
                import richmovie_attention as _att_v
                _att_v.clear_state()
            except Exception:
                pass

    def _attention_rewind(self, tracker, asleep=None) -> None:
        """D2: „Pokračovat" zpět na PRVNÍ díl, který se přehrál bez diváka, od začátku.
        Bez snímku (dotaz přišel z nečinnosti, ne z řetězu) se nemění nic. `asleep` = díly s verdiktem spánku
        ([tv_id, s, e]) — položka Pokračovat je nese (`asleep_eps`), klik pak nabídne „už ho mám za sebou" (D3)."""
        # JEN skutečný řetěz dílů bez diváka. Dotaz z pouhé nečinnosti (`streak == 0`, např.
        # 2,5h film, u kterého divák jen nesáhl na ovladač) NESMÍ přetočit titul na začátek
        # (cross-check Pro A P1 / Flash): žádný snímek = žádný rewind.
        snap = (tracker.state() or {}).get("first_unattended")
        if not snap:
            _log("ATTENTION_REWIND: bez řetězu dílů bez diváka → Pokračovat se nemění", xbmc.LOGINFO)
            return
        try:
            import richmovie_history as _hist_r
            snap = dict(snap)
            eps = [[int(s_), int(e_)] for tv_, s_, e_ in (asleep or []) if str(tv_) == str(snap.get("tv_id"))]
            if eps:
                snap["asleep_eps"] = eps
            if _hist_r.cw_rewind_series(snap, asleep_since=tracker.last_input_ts):
                _log(f"ATTENTION_REWIND: Pokračovat → S{int(snap.get('season') or 0):02d}"
                     f"E{int(snap.get('episode') or 0):02d} od začátku", xbmc.LOGINFO)
                try:
                    import richmovie_state_sync as _ss_r
                    _ss_r.request_push()
                except Exception:
                    pass
                _rm_notif(
                    "⏾ Pokračovat počká na S%02dE%02d"
                    % (int(snap.get("season") or 0), int(snap.get("episode") or 0)),
                    xbmcgui.NOTIFICATION_INFO,
                    5000,
                    "RichMovie",
                    sound=False,
                )
        except Exception as exc:
            _log(f"attention rewind failed: {exc!r}", xbmc.LOGWARNING)

    def _autoplay_safely(self, play_url: str, cleanup_props=(), *, gate: bool = True) -> None:
        """Pocka na zavreni prehravace a spusti PlayMedia pro dalsi dil.

        `cleanup_props` (3.5.119, audit #4 + Pro kolo 2 #2): Window properties,
        které volající nastavil PRO toto přehrání (resume_position + resume_ident).
        Pokud se PlayMedia nespustí (Stop, abort, výjimka), musí se smazat —
        jinak by ovlivnily příští NESOUVISEJÍCÍ přehrávání. Po ÚSPĚŠNÉM PlayMedia
        je konzumentem plugin._play (převezme a smaže na vstupu — mazat tady by
        byl race s jeho čtením)."""
        def _cleanup() -> None:
            win_c = xbmcgui.Window(10000)
            for _prop in (cleanup_props or ()):
                win_c.clearProperty(_prop)

        try:
            win = xbmcgui.Window(10000)
            mon = xbmc.Monitor()

            # Kontrola: uzivatel mohl stisknout Stop behem race condition
            if win.getProperty("richmovie.nextup.chain_stopped") == "1":
                _log("AUTOPLAY_CANCELLED: chain stopped")
                _cleanup()
                return

            # Pockat na zavreni fullscreen videa (<=5s)
            if not self._wait_fullscreen_closed(mon):
                _cleanup()
                return

            # Zavrit modal dialogy
            for _ in range(20):
                if mon.abortRequested():
                    _cleanup()
                    return
                if xbmc.getCondVisibility("System.HasActiveModalDialog"):
                    xbmc.executebuiltin("Dialog.Close(all,true)")
                    xbmc.sleep(100)
                else:
                    break

            xbmc.sleep(500)  # kratka pauza pro stabilitu

            if mon.abortRequested():
                _cleanup()
                return

            # Druha kontrola po cekani (uzivatel mohl stisknout Stop mezitim)
            if win.getProperty("richmovie.nextup.chain_stopped") == "1":
                _log("AUTOPLAY_CANCELLED: chain stopped (after wait)")
                _cleanup()
                return

            # 3.5.149: brána „Díváš se ještě?" — jen pro DALŠÍ díl (`gate=True`), ne pro
            # navázání téhož dílu po utnutí streamu (auto-resume má vlastní čítač 3×).
            if gate and not self._attention_gate(play_url):
                _cleanup()
                return

            _log(f"AUTOPLAY: {play_url[:100]}...", xbmc.LOGINFO)
            if gate:
                # Φ6 (A05 F12): co se spouští, hned — ne až s obrazem (Chromecast p50 8,5 s mezi díly)
                _ap_text = _rm_sw.autoplay_start_text(play_url)
                if _ap_text:
                    _rm_notif(_ap_text, xbmcgui.NOTIFICATION_INFO, None, _rm_sw.autoplay_heading(play_url))
            # `noresume` (3.5.151): pozici určuje RichMovie (auto-resume = bod v resolvované položce,
            # další díl = od začátku). Kodi by jinak podle vlastní záložky URL ukázal dialog
            # „Pokračovat od…" (PlayerBuiltins.cpp:514–527) — v noci nad spícím divákem.
            # Φ1 (29.09.2026): přes pojistku jednoho startu — když uživatel mezitím sám spustil
            # přehrávání (klik na stream), autoplay ustoupí (jinak dva resolve naráz = pád Kodi 21.2).
            _dispatched = _rm_dispatch.request(play_url, source=("autoplay" if gate else "auto_resume"),
                                               notify_busy=False)
            if not _dispatched:
                _log("AUTOPLAY_SKIPPED: spouští se jiné přehrání (nebo Kodi stále načítá)", xbmc.LOGINFO)
                _cleanup()
                return

        except Exception as e:
            _log(f"AUTOPLAY_ERR: {e}", xbmc.LOGINFO)
            _cleanup()

    def _maybe_ask_rating_series(self, li) -> bool:
        """Dotaz na hodnocení SERIÁLU (3.5.154). True = dialog převzal návrat do RichMovie."""
        try:
            tv_id = int(li.getProperty("richmovie.tv_id") or 0)
            if tv_id <= 0:
                return False

            # Nepřerušovat večer: když hned naskakuje další díl, dotaz se odloží na konec
            # dílu, po kterém už autoplay nepokračuje (rozhodnutí Richie 20.09.2026).
            if xbmcgui.Window(10000).getProperty("richmovie.nextup.autoplay_url"):
                _log("RATING_ASK_TV odlozeno (navazuje autoplay) tv=%d" % tv_id, xbmc.LOGDEBUG)
                return False

            import richmovie_history as _rh_r
            import richmovie_profile as _rp_r
            import richmovie_ratings as _rt_r

            # PRÁVĚ dokoukaný díl musí být sledovaný bděle — stejná podmínka jako u filmu.
            # Bez ní by dialog vyskočil ve tři ráno nad spícím divákem po posledním dílu
            # autoplay řetězu (Fable audit 20.09.2026, F4).
            import richmovie_attention as _att_r
            from richmovie_playback_end import player_ctx_key as _rt_key
            if str(_att_r.TRACKER.current_kind(_rt_key() or "") or "attended") != "attended":
                _log("RATING_ASK_TV preskoceno: dil bez divaka tv=%d" % tv_id, xbmc.LOGDEBUG)
                return False

            # Počítají se jen ŘÁDNÉ řady (sezóna 0 = speciály; TMDb je do `number_of_episodes`
            # nepočítá, takže by fázi „dokoukáno" spustily předčasně — cross-check Flash F5).
            # Do prahu jdou jen díly, u kterých divák BYL: kulisa (Futurama: 62 % dílů bez
            # doteku ovladače) by ho jinak překročila za noc. „Dokoukáno" naopak bere ✔
            # jakéhokoli druhu — dva prospané díly nesmí fázi zablokovat navždy.
            kinds = _rh_r.watched_kinds_for_series(tv_id)
            regular = {k: v for k, v in kinds.items()
                       if isinstance(k, tuple) and len(k) == 2 and int(k[0] or 0) > 0}
            attended = sum(1 for v in regular.values() if str(v or "attended") in ("attended", "manual"))
            marked_any = len(regular)

            # Jen disková cache, 0 síťových volání. Klíč je povinný argument konstruktoru —
            # `TMDb()` bez něj vyhodí TypeError a široký `except` by ho spolkl: práh by byl
            # napořád 5 a fáze „dokoukáno" by nenastala nikdy (Fable audit 20.09.2026, F3).
            detail = None
            try:
                from richmovie_settings import get_tmdb_api_key as _gk_r
                _key_r = _gk_r()
                if _key_r:
                    detail = TMDb(_key_r, lang="cs-CZ").peek_tv_details(tv_id)
            except Exception as _exc_d:
                _log("RATING_ASK_TV detail z cache selhal: %r" % (_exc_d,), xbmc.LOGWARNING)
            if detail is None:
                _log("RATING_ASK_TV tv=%d bez detailu v cache → práh %d, fáze 'finished' vypnuta"
                     % (tv_id, _rt_r.SERIES_ASK_CAP), xbmc.LOGDEBUG)
            first_n = _rt_r.first_season_episodes(detail)
            total_n = _rt_r.total_episodes(detail)
            finished = bool(total_n and marked_any >= int(total_n))

            stage = _rt_r.should_ask_series(
                _rt_r.get("tv", tv_id), _rt_r.skipped_count("tv", tv_id),
                attended_episodes=attended, first_season_episodes=first_n,
                series_finished=finished, asked=_rt_r.asked_stages("tv", tv_id),
                is_guest=_rp_r.is_guest() or not _rp_r.has_active_profile(),
                enabled=richmovie_settings.get_bool("rating_ask_enabled"),
                last_ask_age_s=_rt_r.last_series_ask_age_s(),
            )
            if not stage:
                return False

            title = (li.getProperty("richmovie.tv_name")
                     or li.getVideoInfoTag().getTVShowTitle() or "").strip()
            try:
                poster = li.getArt("poster") or li.getArt("thumb") or ""
                fanart = li.getArt("fanart") or ""
            except Exception:
                poster, fanart = "", ""
        except Exception as exc:
            _log("rating ask (tv) precheck failed: %r" % (exc,), xbmc.LOGDEBUG)
            return False

        def _run() -> None:
            try:
                mon = xbmc.Monitor()
                if not self._wait_fullscreen_closed(mon, require_player_stopped=True, wait_s=6.0):
                    return
                if self.isPlaying() or mon.abortRequested():
                    return
                import richmovie_rating_ui as _rui
                # Fáze se zapisuje TĚSNĚ před dialogem, ne dřív: když čekání na zavření
                # fullscreenu skončí bez dialogu (divák mezitím pustil další díl), nesmí se
                # fáze spálit naprázdno (cross-check Flash F3). Zápis PŘED `collect` zůstává —
                # pád Kodi uprostřed dialogu nesmí vyrobit druhý dotaz na totéž.
                _rt_r.note_asked("tv", tv_id, stage)
                _log("RATING_ASK_TV tv=%d stage=%s attended=%d title=%s"
                     % (tv_id, stage, attended, title[:60]), xbmc.LOGINFO,
                     context={"tmdb_id": tv_id})
                _rui.collect("tv", tv_id, title, poster=poster, fanart=fanart)
            except Exception as exc:
                _log("rating dialog (tv) failed: %r" % (exc,), xbmc.LOGWARNING)
            finally:
                # Stejně jako u filmu: dialog převzal návrat do RichMovie (Flash F7).
                self._maybe_return_to_richmovie()

        _spawn_followup("rating_ask_tv", _run, name="RMRatingAskTV", daemon=True)
        return True

    def _wait_fullscreen_closed(self, mon: xbmc.Monitor, *,
                                require_player_stopped: bool = False,
                                wait_s: float = _FULLSCREEN_CLOSE_WAIT_S) -> bool:
        """Počká (≤ wait_s), až Kodi zavře fullscreen video (volitelně i až
        přehrávač skutečně stojí). False = Kodi se vypíná (abort). Jedno místo
        pro všechna čekání (audit #5; Flash kolo 2 #1/#2 — dřív 3 inline kopie).
        Strop je parametr, protože historická místa mají různé hodnoty (5 s
        autoplay/navigace, 6 s return-route) a jejich změna = změna chování."""
        steps = int(wait_s / _FULLSCREEN_POLL_S)
        for _ in range(steps):
            if mon.abortRequested():
                return False
            closed = not xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)")
            if require_player_stopped:
                closed = closed and not self.isPlaying()
            if closed:
                return True
            if mon.waitForAbort(_FULLSCREEN_POLL_S):
                return False
        return True






    def _mark_watched_early(self, li, *, tv_id, tmdb_id, is_episode: bool, pct: float) -> None:
        """✔ dokoukaného titulu ještě během titulků (M8) — jednou za přehrávání titulu (idempotentní zápis).
        Druh `attended` (D1); verdikt spánku ho případně sníží až po dotazu, jako u ✔ z konce dílu."""
        try:
            if is_episode:
                s = int(li.getProperty("richmovie.season") or li.getVideoInfoTag().getSeason())
                e = int(li.getProperty("richmovie.episode") or li.getVideoInfoTag().getEpisode())
                key = f"tv:{tv_id}:{s}:{e}"
            elif tmdb_id:
                s = e = 0
                key = f"movie:{tmdb_id}"
            else:
                return
            if self._early_watched_key == key:
                return
            self._early_watched_key = key
            if is_episode:
                _hist.watched_mark_episode(tv_id=tv_id, season=s, episode=e, completion=pct, kind="attended")
            else:
                _hist.watched_movie_mark(tmdb_id)
            _log(f"WATCHED_EARLY: {key} ✔ v titulcích ({pct:.3f})", xbmc.LOGINFO)
        except Exception as exc:
            _log(f"watched early failed: {exc!r}", xbmc.LOGWARNING)

    def _close_superseded_title(self, *, superseded_by_live: bool = False) -> None:
        """M2 (incident 09.10.2026, SG-1 S07E07 na 95 %): divák spustil jiný díl, zatímco předchozí ještě hrál
        (klik na další díl během titulků — video běží na pozadí). Kodi pak NEPOŠLE Stopped ani Ended, jen
        onAVStarted nového souboru, takže předchozí díl dřív nikdo neuzavřel: žádné ✔, Pokračovat na 95 %.
        Teď ho uzavře JEDINÁ cesta konce titulu (`_save_cw_position(final=True)`) nad snímkem z cache:
        dokoukaný (SSOT `is_completed`) = ✔ + další díl v Pokračovat, jinak uložená pozice. Bez autoplaye,
        dotazů a navigace — divák už si vybral, co chce sledovat.

        `superseded_by_live` (Televizní kanály F3): nový soubor je živý kanál — kontext hráče (`player_ctx_key`) pořád
        patří předchozímu titulu (plugin ho pro kanál nepíše), takže shoda klíčů NENÍ obnova téhož titulu (A4 past 15)."""
        prev_key = getattr(self, "_title_open_key", "") or ""
        li = self._cached_li
        if not prev_key or li is None:
            return
        if superseded_by_live:
            new_key = "live"
        else:
            try:
                from richmovie_playback_end import player_ctx_key as _new_key_fn
                new_key = _new_key_fn() or ""
            except Exception:
                new_key = ""
            if new_key == prev_key:
                return   # navázání / obnova spojení TÉHOŽ titulu není konec
        self._title_open_key = ""
        pos = float(self._cached_pos or 0.0)
        dur = float(self._cached_dur or 0.0)
        if dur <= 0:
            try:
                dur = float(li.getProperty("richmovie.duration") or 0.0)
            except Exception:
                dur = 0.0
        if pos <= 0 or dur <= 0:
            return
        try:
            if self.getPlayingItem().getProperty("richmovie.autoplay") != "1":
                import richmovie_attention as _att_sup
                _att_sup.TRACKER.note_input()   # nový titul pustil člověk → u předchozího byl
        except Exception:
            pass
        _log(f"TITLE_SUPERSEDED: {prev_key} → {new_key or '?'} pos={int(pos)}/{int(dur)}s → uzavřít", xbmc.LOGINFO)
        try:
            self._save_cw_position(final=True, snapshot={"li": li, "position": pos, "duration": dur,
                                                         "key": prev_key, "url": self._last_stream_url})
        except Exception as exc:
            _log(f"TITLE_SUPERSEDED close failed: {exc!r}", xbmc.LOGWARNING)

    def _last_known_progress(self) -> "tuple[float, float]":
        """(pozice, délka) v sekundách — živě z přehrávače, po jeho zavření
        z 5s/15s checkpointů (`_cached_pos/_cached_dur`). (0, 0) = neznámé."""
        pos, dur, _lag = self._last_known_progress_with_lag()
        return pos, dur

    def _last_known_progress_with_lag(self) -> "tuple[float, float, float]":
        """Jako `_last_known_progress` + stáří checkpointu (s; 0 = živá hodnota).
        Stáří je z reálného času zápisu (`_cached_at`), ne z intervalu smyčky —
        watch_loop běží jen s nextup_enable, jinak jen 15s av_monitor."""
        try:
            if self.isPlaying():
                return float(self.getTime() or 0.0), float(self.getTotalTime() or 0.0), 0.0
        except RuntimeError:
            pass
        cached_dur = float(self._cached_dur)
        if cached_dur <= 0 and self._cached_li is not None:
            # A#3 (Fable audit): Kodi u části streamů getTotalTime() nezná (0),
            # ale plugin délku uložil do ListItem property (Webshare vid_len) —
            # watch_loop ji pro prefetch používá, klasifikace konce musí taky,
            # jinak je konec UNKNOWN a CW pozice se zahodí.
            try:
                cached_dur = float(self._cached_li.getProperty("richmovie.duration") or 0.0)
            except Exception:
                cached_dur = 0.0
        if self._cached_pos > 0 and cached_dur > 0:
            lag = max(0.0, time.monotonic() - self._cached_at) if self._cached_at > 0 else 0.0
            return float(self._cached_pos), cached_dur, lag
        return 0.0, 0.0, 0.0

    def _save_cw_position(self, *, final: bool = True, activity=None, position_override: float = -1.0,
                          snapshot: Optional[dict] = None) -> None:
        """
        Ulozi aktualni pozici prehravani do continue_watching.json.

        13.09.2026 (3.5.148, nález N1): `activity` = playing/paused/stopped (None = podle Kodi;
        finální volání = stopped). Průběžný checkpoint se ZAPÍŠE jen když se změnil titul,
        activity nebo pozice (`richmovie_state_sync.checkpoint_changed`) — pozastavený přehrávač
        dřív každých 30 s zapsal tutéž pozici s novým `ts` a služba ji každou minutu pushla jako
        „novější" stav (přepisovala postup zařízení, které díl reálně hrálo).
        Dokoukaný titul (SSOT `richmovie_playback_end.is_completed`) se z CW
        odstraní / nahradí dalším dílem a označí ✔.

        3.5.119 (B2): parametr `completed` ODSTRANĚN — dřív ho onPlayBackEnded
        posílal jako True a tím vnutil „dokoukáno" i streamu utnutému CDN při
        40 %. Jediným kritériem dokončení je pozice vůči délce.

        Φ8 (R3-P2-2): `final=False` = průběžný 30s checkpoint — dokončovací
        větev (advance + watched ✔) smí běžet JEN z finálních volání
        (Ended/Stopped/shutdown/přepnutí za běhu). Dřív checkpoint po 93 % provedl advance
        UPROSTŘED přehrávání (seek zpět pak vyrobil duplicitní řádek) a
        pozice se v posledních 7 % dílu přestala ukládat.

        4.0.3 (M2, 10.10.2026): `snapshot` = PŘEDCHOZÍ titul, který Kodi neukončilo (divák spustil jiný díl,
        zatímco ten běžel — klik na další díl během titulků). Přehrávač už hraje nový soubor, takže pozice,
        položka, klíč i adresa jdou ze snímku, nikdy z živého přehrávače. Stejná dokončovací větev jako Stop:
        JEDNA cesta konce titulu (`_close_superseded_title`).

        Televizní kanály F3: hraje-li živý kanál, checkpoint z PŘEHRÁVAČE se nezapisuje (kanál nemá Pokračovat; ISA
        hlásí jako délku okno časového posunu → „film“ s nesmyslnou pozicí). Snímek předchozího titulu projde.
        """
        if snapshot is None and self._open_live:
            return
        try:
            if snapshot is not None:
                position, duration = float(snapshot.get("position") or 0), float(snapshot.get("duration") or 0)
            else:
                position, duration = self._last_known_progress()
            if position_override >= 0:
                position = float(position_override)
            if duration <= 0:
                return  # přehrávač už neběží a checkpoint neexistuje

            if duration < MIN_DURATION_S:
                return  # prilis kratke video (SSOT richmovie_playback_end)

            import richmovie_state_sync as _ss_cp
            if not _ss_cp.sane_checkpoint(position, duration):
                # 4.0.3 (M3): rozbité časové značky streamu (produkce 06.10.: 47 547 s u dílu o 2 638 s) — taková
                # pozice by přepsala Pokračovat na všech zařízeních a na Gate skončila v karanténě (422)
                _log(f"CHECKPOINT_INVALID pos={position:.0f}s dur={duration:.0f}s final={final} → nezapsáno",
                     xbmc.LOGWARNING)
                return
            if final:
                activity = "stopped"
            elif activity is None:
                activity = self.current_activity()
            activity = _ss_cp.normalize_activity(activity)

            # 3.5.152 (backlog B1): po Stopu/Ended přehrávač neběží — `getPlayingItem()` by Kodi zalogovalo
            # jako ERROR „Kodi is not playing any item" (2× při každém zastavení); položka je v cache.
            li = snapshot.get("li") if snapshot is not None else None
            if snapshot is None:
                try:
                    if self.isPlaying():
                        li = self.getPlayingItem()
                except RuntimeError:
                    li = None
            if li is None:
                li = self._cached_li
                if li is None:
                    return
            if self._resume_hold is not None and snapshot is None:
                # 3.5.151 (Φ2): neověřené navázání — nižší pozice (start od nuly) by přepsala
                # Pokračovat na všech zařízeních profilu (incident notebook 16.09.2026)
                import richmovie_resume as _rres_cp
                if _rres_cp.hold_checkpoint(self._resume_hold, li.getProperty("richmovie.ident") or "", position):
                    _log(f"CW_HOLD pos={position:.0f}s < cíl {float(self._resume_hold.get('target') or 0):.0f}s "
                         f"(navázání neověřené) → nezapsáno", xbmc.LOGDEBUG)
                    return
            tv_id = li.getProperty("richmovie.tv_id") or ""
            tv_name = (li.getVideoInfoTag().getTVShowTitle() or "").strip()
            tmdb_id = li.getProperty("richmovie.m_tmdb") or ""
            m_title = (li.getVideoInfoTag().getTitle() or "").strip()

            # Lokální NAS soubor (smb://) — přehrává se přímo přes path, NE přes
            # Webshare ident. Bez tohoto by CW záznam neměl jak znovu spustit
            # → klik spadl do fallback vyhledávání podle názvu (incident
            # „Bez názvu" → hledá „Video bez názvu.mp4" na Webshare).
            local_path = ""
            try:
                # po konci přehrávání z uložené adresy (B1: `getPlayingFile` po Stopu = ERROR v kodi.log)
                if snapshot is not None:
                    _pf = str(snapshot.get("url") or "")
                else:
                    _pf = (self.getPlayingFile() if self.isPlaying() else self._last_stream_url) or ""
                if _pf.startswith("smb://") or _pf.startswith("nfs://"):
                    local_path = _pf
            except Exception:
                local_path = ""

            is_episode = bool(tv_id and tv_name)

            pct = min(1.0, position / duration) if duration > 0 else 0   # 4.0.3 (M3): podíl nikdy > 1

            if is_completed(position, duration) and not final:
                # 4.0.3 (M8, data 10.10.2026: ~30 filmů a dílů na 93–99,9 % bez ✔): Android Kodi během titulků
                # často zavře / uspí aplikace a Stop ani Ended nepřijde. ✔ proto vzniká už ve chvíli, kdy pozice
                # splní pravidlo dokoukání (SSOT `is_completed`); posun Pokračovat, autoplay a dotazy dál jen z konce.
                self._mark_watched_early(li, tv_id=tv_id, tmdb_id=tmdb_id, is_episode=is_episode, pct=pct)

            if is_completed(position, duration) and final:
                # Dokonceno -> Φ3 (2026-07-06, audit A02): NAHRADIT dalším dílem
                # („Netflix sémantika"), ne smazat — cw_remove bez náhrady byl
                # root cause „v CW mi měsíc visí jen film" (seriály mizely).
                if is_episode:
                    try:
                        s = int(li.getProperty("richmovie.season") or li.getVideoInfoTag().getSeason())
                        e = int(li.getProperty("richmovie.episode") or li.getVideoInfoTag().getEpisode())
                    except (TypeError, ValueError):
                        return
                    # Φ8: dokončovací větev běží JEN z finálních volání (`final=True`:
                    # Ended/Stopped/shutdown); throttle `_cw_advanced_key` kryje platformy,
                    # které po Ended pošlou ještě Stopped (advance + TMDb jen jednou).
                    _adv_key = f"{tv_id}:{s}:{e}"
                    if getattr(self, "_cw_advanced_key", "") == _adv_key:
                        return  # advance tohoto dílu už proběhl
                    self._cw_advanced_key = _adv_key
                    _advance_series_cw(tv_id, s, e)
                    # 3.5.149: uzavřít díl v trackeru bdělosti — vrátí `attended` / `unattended`
                    # (= autoplay a od začátku do konce žádný vstup) a posune řetěz. Snímek dílu
                    # slouží k návratu „Pokračovat", když řetěz skončí dotazem bez odpovědi (D2).
                    _att_kind = "attended"
                    try:
                        import richmovie_attention as _att_f
                        _snap = {
                            "type": "episode", "tv_id": tv_id, "tv_name": tv_name,
                            "season": s, "episode": e,
                            "tmdb_id": int(tv_id) if str(tv_id).isdigit() else None,
                            "title": tv_name,
                            "ep_title": li.getProperty("richmovie.ep_title") or "",
                            "poster_path": li.getProperty("richmovie.poster_path") or "",
                            "backdrop_path": li.getProperty("richmovie.backdrop_path") or "",
                            "duration": round(duration, 1),
                            "ident": li.getProperty("richmovie.ident") or "",
                            "source": li.getProperty("richmovie.source") or "webshare",
                        }
                        _att_kind = _att_f.TRACKER.finish(snapshot=_snap, key="tv:%s:%d:%d" % (tv_id, s, e))
                        self._attention_snapshot = _att_f.TRACKER.state().get("first_unattended")
                        if _att_kind == _att_f.KIND_UNATTENDED:
                            _log(f"ATTENTION_UNATTENDED: S{s:02d}E{e:02d} bez reakce "
                                 f"(řetěz {_att_f.TRACKER.streak})", xbmc.LOGINFO)
                        # řetěz na disk: vybitá baterie nebo pád Kodi nesmí vzít informaci,
                        # KDE divák usnul (cross-check Flash/Pro A)
                        _att_f.save_state()
                    except Exception as _att_e:
                        _log(f"attention finish failed: {_att_e!r}", xbmc.LOGWARNING)

                    # Označit jako dokoukané (completion-based SSOT pro UI markery).
                    # Idempotentní s player_hook._finalize; pojistka, kdyby finalize
                    # neproběhl. Best-effort — nesmí shodit službu.
                    try:
                        # 4.0.3 (D1): dokoukáno = ✔ `attended` i bez doteku ovladače; ⏾ dá jen verdikt spánku
                        # (`_sleep_verdict`), až dotaz „Díváš se ještě?" vyprší. `_att_kind` = jen řetěz bdělosti.
                        _hist.watched_mark_episode(tv_id=tv_id, season=s, episode=e,
                                                   completion=pct, kind="attended")
                    except Exception as _wme:
                        # 2026-07-01: dřív tiché — ovlivní zelené ✔ markery epizod.
                        _log(f"watched_mark_episode failed: {_wme!r}", xbmc.LOGWARNING)
                elif tmdb_id:
                    _hist.cw_remove(tmdb_id=tmdb_id)
                    # P0-1: dokoukaný film → zelený ✔ (konzistentně s epizodami)
                    try:
                        _hist.watched_movie_mark(tmdb_id)
                    except Exception as _wmm:
                        # 2026-07-01: dřív tiché — ovlivní zelený ✔ marker filmu.
                        _log(f"watched_movie_mark failed: {_wmm!r}", xbmc.LOGWARNING)
                elif local_path:
                    # 4.0.3 (cross-check Flash C F3): film z NASu bez TMDb dřív v Pokračovat zůstal i po dokoukání
                    _hist.cw_remove_matching({"type": "movie", "path": local_path})
                return

            # 13.09.2026 (N1): nezměněný stav = žádný zápis (viz docstring)
            try:
                from richmovie_playback_end import player_ctx_key as _cp_key
                _cp_k = str(snapshot.get("key") or "") if snapshot is not None else _cp_key()
            except Exception:
                _cp_k = ""
            if not _cp_k:
                # klíč přehrávání je stabilní po celou session — bez PlayerCtx (lokální soubor) drž první
                # použitý fallback, aby se v jedné session nestřídaly dva klíče (Pro A P3)
                _cp_k = self._cw_last_saved[0] if self._cw_last_saved else f"{tv_id}:{tmdb_id}"
            _delta = _ss_cp.CHECKPOINT_MIN_DELTA_S if self._cw_min_delta is None else float(self._cw_min_delta)
            if not _ss_cp.checkpoint_changed(self._cw_last_saved, _cp_k, position, activity, final, min_delta_s=_delta):
                return
            if final and self._cw_suppress_final_key and self._cw_suppress_final_key == _cp_k:
                # jiné zařízení tenhle díl dokoukalo (handoff watched) — Stop tady není nový postup
                self._cw_suppress_final_key = ""
                _log(f"CW_FINAL_SUPPRESSED key={_cp_k} (dokoukáno jinde)", xbmc.LOGINFO)
                return
            # čas změny postupu: pozice se hnula (nebo první zápis) → teď; jen activity (pauza→stop) → čas
            # poslední změny pozice (LWW nesmí brát „zavřel jsem přehrávač" za novější postup)
            _now_epoch = time.time()
            _position_moved = (self._cw_last_saved is None or self._cw_last_saved[0] != _cp_k
                               or abs(float(position) - float(self._cw_last_saved[1])) >= _delta)
            if _position_moved or self._cw_last_change_ts <= 0:
                self._cw_last_change_ts = _now_epoch
            _client_time = _now_epoch if (_position_moved or not final) else self._cw_last_change_ts

            if pct < 0.05 or position < 30:
                # Φ3 (2026-07-06, audit A02): guard blokuje jen NOVÉ záznamy
                # (omylem spuštěné video). Rozkoukaný seriál (autoplay chain po
                # cw_advance) se aktualizovat MUSÍ — dřív stopnutí dalšího dílu
                # do 30 s pozici seriálu ztratilo (evidence: Hvězdná brána
                # S02E03, Narcos S02E08 zmizely z CW úplně).
                # R3-P2-1: PŘESNĚ tento díl, ne celá série — celoseriálový test
                # propouštěl i omylem kliknutý JINÝ díl (duplicitní řádek).
                _exact = False
                if is_episode:
                    try:
                        _gs = int(li.getProperty("richmovie.season")
                                  or li.getVideoInfoTag().getSeason())
                        _ge = int(li.getProperty("richmovie.episode")
                                  or li.getVideoInfoTag().getEpisode())
                        _exact = _hist.cw_contains_episode(
                            tv_id=tv_id, season=_gs, episode=_ge)
                    except Exception:
                        _exact = False
                if not _exact:
                    return  # sotva zacalo

            # Sestavit zaznam
            import time as _time
            poster_path = li.getProperty("richmovie.poster_path") or ""
            backdrop_path = li.getProperty("richmovie.backdrop_path") or ""
            # FALLBACK na art z ListItemu — zdroje, které nenastaví richmovie.*
            # properties (lokální NAS soubory přehrávané přímo přes smb URL),
            # mají poster/fanart jen v setArt → CW by jinak byl bez obrázku.
            if not poster_path:
                try:
                    poster_path = li.getArt("poster") or li.getArt("thumb") or ""
                except Exception:
                    poster_path = ""
            if not backdrop_path:
                try:
                    backdrop_path = li.getArt("fanart") or ""
                except Exception:
                    backdrop_path = ""
            cw_ident = li.getProperty("richmovie.ident") or ""
            cw_source = li.getProperty("richmovie.source") or "webshare"
            cw_fs_url = li.getProperty("richmovie.fs_url") or ""
            cw_fs_hash = li.getProperty("richmovie.fs_hash") or ""

            if is_episode:
                try:
                    s = int(li.getProperty("richmovie.season") or li.getVideoInfoTag().getSeason())
                    e = int(li.getProperty("richmovie.episode") or li.getVideoInfoTag().getEpisode())
                except (TypeError, ValueError):
                    return
                ep_title = (li.getProperty("richmovie.ep_title")
                            or li.getVideoInfoTag().getTitle() or "").strip()
                item = {
                    "type": "episode",
                    "tv_id": tv_id,
                    "tv_name": tv_name,
                    "season": s,
                    "episode": e,
                    "ep_title": ep_title,
                    "tmdb_id": int(tv_id) if str(tv_id).isdigit() else None,
                    "title": tv_name,
                    "poster_path": poster_path,
                    "backdrop_path": backdrop_path,
                    "position": round(position, 1),
                    "duration": round(duration, 1),
                    "ts": int(_time.time()),
                    "ident": cw_ident,
                    "source": cw_source,
                    "fs_url": cw_fs_url,
                    "fs_hash": cw_fs_hash,
                    "activity": activity,
                    "client_time": _client_time,
                }
            else:
                year = 0
                try:
                    year = li.getVideoInfoTag().getYear()
                except Exception:
                    pass
                # title fallback: ListItem label (název souboru u NAS bez TMDb
                # matche) je lepší než „Bez názvu"
                if not m_title:
                    try:
                        import re as _re
                        m_title = (li.getLabel() or "").strip()
                        # ořež BBCode + ★rating/badge prefixy z labelu
                        m_title = _re.sub(r"\[/?[A-Z][^\]]*\]", "", m_title).strip()
                        m_title = _re.sub(r"^[★\d.\s]+", "", m_title).strip()
                    except Exception:
                        m_title = ""
                item = {
                    "type": "movie",
                    "title": m_title or "Neznámý titul",
                    "year": year or 0,
                    "tmdb_id": int(tmdb_id) if str(tmdb_id).isdigit() else None,
                    "poster_path": poster_path,
                    "backdrop_path": backdrop_path,
                    "position": round(position, 1),
                    "duration": round(duration, 1),
                    "ts": int(_time.time()),
                    "ident": cw_ident,
                    "source": "local" if local_path else cw_source,
                    "fs_url": cw_fs_url,
                    "fs_hash": cw_fs_hash,
                    "activity": activity,
                    "client_time": _client_time,
                }
                if local_path:
                    item["path"] = local_path  # NAS soubor → znovu přehrát přímo

            # OCHRANA: nepřehratelný film (žádný ident, tmdb ani path) by v CW
            # jen vyrobil mrtvou dlaždici, jejíž klik spadne do fallback hledání
            # podle názvu (incident „Bez názvu"). Takový záznam NEukládat.
            if (item.get("type") == "movie" and not item.get("ident")
                    and not item.get("tmdb_id") and not item.get("path")):
                try:
                    _rm._log_event("CW_SKIP_UNPLAYABLE", m_title or "?")
                except Exception:
                    pass
                return

            _hist.cw_upsert(item)
            self._cw_last_saved = (_cp_k, int(position), activity)
            if final:
                try:
                    import richmovie_state_sync as _ss
                    _ss.request_push()   # stop/konec = push v nejbližším tiku (D13, cross-check PC6)
                except Exception:
                    pass

        except Exception as exc:
            try:
                _rm._log_event("CW_SAVE_ERR", str(exc))
            except Exception:
                pass

    # ------------------------------------------------------------------ #
    #  B3 (3.5.119): auto-resume po utnutí streamu zdrojem
    # ------------------------------------------------------------------ #
    def _reset_auto_resume(self) -> None:
        self._resume_key = ""
        self._resume_attempts = 0
        self._resume_from_pos = 0.0
        self._resume_started_at = 0.0

    def _on_unexpected_eof(self, position: float, duration: float) -> None:
        """Kodi ohlásil konec souboru, ale pozice je hluboko pod prahem
        dokoukání → zdroj (CDN) utnul stream. Uložit pozici jako checkpoint,
        NIC neoznačovat jako dokoukané, a pokud je to povolené, navázat.
        `final=False`: verdikt UNEXPECTED_EOF je rozhodnutý — dokončovací větev
        (✔ / advance / cw_remove) sem NESMÍ (Fable P1-1: 3h film utnutý v 93,5 %
        by jinak dostal ✔ a zmizel z Pokračovat = incident Zelňačka znovu)."""
        # 3.5.158: skutečná pozice konce souboru (před převzetím cizí pozice / cíle navázání) —
        # vstup pro rozhodnutí „vadný soubor" (`richmovie_source_health`).
        eof_position = position
        # 3.5.147 (Φ2 / D3, cross-check T3-P4): než navážeme, zeptat se Gate, jestli tentýž
        # titul právě nesleduje JINÉ zařízení dál než my. Pak navazujeme z jeho pozice a
        # NEpřepisujeme jeho `watching` naší starší pozicí (LWW ping-pong). Read-only
        # dotaz s krátkým timeoutem; selhání = dnešní chování (lokální pozice).
        remote_pos = None
        try:
            from richmovie_playback_end import player_ctx_key as _ctx_key
            import richmovie_state_sync as _rss
            _key = _ctx_key()
            if _key:
                remote = _rss.remote_resume_position(_key, position)
                if remote is not None:
                    remote_pos = float(remote.get("position_s") or 0)
                    _log(f"AUTO_RESUME_REMOTE_POS key={_key} local={position:.0f}s remote={remote_pos:.0f}s "
                         f"from={remote.get('updated_device_label') or '?'}", xbmc.LOGINFO,
                         context={"key": _key, "local_s": int(position), "remote_s": int(remote_pos)})
        except Exception as _rr_exc:
            _log(f"remote resume check failed: {_rr_exc!r}", xbmc.LOGINFO)
        if remote_pos is not None:
            position = remote_pos
        else:
            try:
                self._save_cw_position(final=False)
            except Exception:
                pass
        # 3.5.151 (Φ2): utnutí během NEověřeného navázání — přehrávač mohl hrát od nuly, cíl platí
        try:
            import richmovie_resume as _rres_eof
            _hold = self._resume_hold
            _hold_ident = ""
            try:
                _hold_ident = (self._cached_li.getProperty("richmovie.ident") or "") if self._cached_li is not None else ""
            except Exception:
                _hold_ident = ""
            if _hold and _rres_eof.hold_checkpoint(_hold, _hold_ident, position):
                _log(f"AUTO_RESUME_HOLD pos={position:.0f}s → cíl neověřeného navázání "
                     f"{float(_hold.get('target') or 0):.0f}s", xbmc.LOGINFO)
                position = float(_hold.get("target") or position)
        except Exception:
            pass
        # 3.5.151 (D4): utnutí streamu = síť zařízení je teď nespolehlivá → další díl nižší datový tok
        try:
            import richmovie_continuity as _cont_eof
            _cont_eof.note_stress(_cont_eof.STRESS_UNEXPECTED_EOF)
        except Exception:
            pass
        win = xbmcgui.Window(10000)
        # Next-up chain do utnutého streamu nepatří (autoplay by skočil na
        # další díl uprostřed tohoto).
        for _k in ("richmovie.nextup.autoplay_url", "richmovie.nextup.nav_url",
                   "richmovie.nextup.nav_pending", "richmovie.nextup.expected_key",
                   "richmovie.nextup.expected_url"):
            win.clearProperty(_k)

        li = self._cached_li
        ident = (li.getProperty("richmovie.ident") or "") if li is not None else ""
        pct = (position / duration) if duration > 0 else 0.0
        _log(
            f"UNEXPECTED_EOF ident={ident or '?'} pos={position:.0f}s "
            f"dur={duration:.0f}s pct={pct:.2f}",
            xbmc.LOGWARNING,
            context={"ident": ident, "position_s": int(position),
                     "duration_s": int(duration), "completion": round(pct, 3)},
        )

        # 3.5.158 (incident Lioness 27.09.2026): soubor, který skončil opakovaně na stejném
        # místě, je od toho místa vadný → nenavazovat na totéž místo (čítač pokusů v paměti se
        # po restartu Kodi i ručním Pokračovat nuluje, záznam zdraví zdroje je trvalý).
        broken_at = None
        _osf_eof = _os_filter_kind()
        if ident and _osf_eof:
            # Noc 03.11.2026 (Φ1): utnutí přes systémový filtr obsahu není vada souboru — nezapočítat.
            _log(f"SOURCE_HEALTH_NOT_COUNTED: systémový filtr obsahu ({_osf_eof}) ident={ident}", xbmc.LOGINFO)
        elif ident:
            try:
                import richmovie_source_health as _sh_eof
                broken_at = _sh_eof.note_unexpected_eof(ident, eof_position, duration)
            except Exception as _sh_exc:
                _log(f"source health failed: {_sh_exc!r}", xbmc.LOGWARNING)
        if broken_at is not None and li is not None:
            _log(f"SOURCE_BROKEN ident={ident} od={broken_at:.0f}s → nabídnout jiný stream (bez navázání)",
                 xbmc.LOGWARNING, context={"ident": ident, "broken_at_s": int(broken_at)})
            self._give_up_auto_resume(li, ident, broken_at=broken_at)
            return

        if not _auto_resume_enabled() or li is None or not ident:
            # Bez identu nelze znovu resolvovat (lokální NAS soubor utnutý
            # sítí → jiný problém, ne CDN). Chovat se jako dřív: návrat do RM.
            self._reset_auto_resume()
            self._maybe_return_to_richmovie()
            return

        # 3.5.151 (cross-check Pro A PA4a/PA5): navázání běží ve vlákně — nejdřív počká, jestli stream
        # právě neotevírá obnova spojení, a ověří síť; bez sítě (tunel) čeká a naváže po jejím návratu.
        # Non-daemon: kontrola CDN / sonda Gate jsou HTTP (feedback_daemon_threads_kodi).
        _spawn_followup("auto_resume", self._auto_resume_worker,
                        args=(li, ident, position, duration, self._av_gen, self._last_stream_url),
                        name="RMAutoResume", daemon=False)

    def _resume_route(self, stream_url: str) -> str:
        """Síť pro navázání = cesta ke ZDROJI (Fable F1): nejdřív CDN utnutého streamu, Gate jen když
        CDN neodpoví (SSOT rozhodnutí `richmovie_resume.resume_route`). "" = síť není."""
        import richmovie_resume as _rres_rt

        def _probe_gate() -> bool:
            import richmovie_netstate as _ns_ar
            return bool(_ns_ar.probe_now(timeout_s=4.0))

        return _rres_rt.resume_route(stream_url, check_cdn=self._cdn_status, probe_gate=_probe_gate)

    def _auto_resume_worker(self, li, ident: str, position: float, duration: float, gen: int,
                            stream_url: str = "") -> None:
        """Navázání po utnutí streamu, až to jde. Skončí bez akce, když mezitím začne jiné
        přehrávání (obnova spojení, ruční klik) nebo Kodi končí; po `AUTO_RESUME_WAIT_NETWORK_S`
        bez sítě to vzdá s toastem (pozice je uložená v Pokračovat).
        „Jiné přehrávání" = změnila se generace (`onAVStarted` ji zvyšuje), ne `isPlaying()` —
        to smí hned po konci souboru ještě chvíli vracet True a auto-resume by se neprávem přeskočil.
        Po ČEKÁNÍ na síť se přehrávání nespustí přes otevřený modální dialog ani klávesnici (Fable F5):
        divák mezitím mohl v Kodi dělat něco jiného a `_autoplay_safely` dialogy zavírá."""
        import richmovie_resume as _rres_w
        mon = xbmc.Monitor()
        started = time.monotonic()
        while time.monotonic() < self._restart_inflight_until:
            if self._av_gen != gen:
                _log("AUTO_RESUME_SKIPPED: stream už otevřela obnova spojení", xbmc.LOGINFO)
                return
            if mon.waitForAbort(0.5):
                return
        announced = False
        ui_wait_logged = False
        while True:
            if mon.abortRequested():
                return
            if self._av_gen != gen:
                _log("AUTO_RESUME_SKIPPED: mezitím začalo jiné přehrávání", xbmc.LOGINFO)
                return
            route = self._resume_route(stream_url)
            if route and announced and self._ui_busy():
                if not ui_wait_logged:
                    ui_wait_logged = True
                    _log("AUTO_RESUME_WAIT_UI: síť je zpět, ale otevřený dialog/klávesnice → čekám",
                         xbmc.LOGINFO, context={"ident": ident, "position_s": int(position)})
            elif route:
                _log(f"AUTO_RESUME_ROUTE via={route} ident={ident}", xbmc.LOGINFO,
                     context={"ident": ident, "route": route})
                break
            elif not announced:
                announced = True
                _log(f"AUTO_RESUME_WAIT_NETWORK ident={ident} pos={position:.0f}s (čekám nejvýš "
                     f"{int(AUTO_RESUME_WAIT_NETWORK_S // 60)} min)", xbmc.LOGINFO,
                     context={"ident": ident, "position_s": int(position)})
                try:
                    _rm_notif(
                        "Síť vypadla – navážu na %s, až se vrátí" % _rres_w.format_time(position),
                        xbmcgui.NOTIFICATION_INFO,
                        6000,
                        "RichMovie",
                    )
                except Exception:
                    pass
            if time.monotonic() - started >= AUTO_RESUME_WAIT_NETWORK_S and route:
                # síť je zpátky, ale divák celou dobu pracuje v dialogu → nerušit ani nevracet do RichMovie
                _log(f"AUTO_RESUME_GAVE_UP_UI ident={ident} pos={position:.0f}s", xbmc.LOGINFO,
                     context={"ident": ident, "position_s": int(position)})
                try:
                    _rm_notif(
                        "Pozice %s čeká v Pokračovat" % _rres_w.format_time(position),
                        xbmcgui.NOTIFICATION_INFO,
                        6000,
                        "RichMovie",
                    )
                except Exception:
                    pass
                self._reset_auto_resume()
                return
            if time.monotonic() - started >= AUTO_RESUME_WAIT_NETWORK_S:
                _log(f"AUTO_RESUME_GAVE_UP_NETWORK ident={ident} pos={position:.0f}s", xbmc.LOGWARNING)
                try:
                    _rm_notif(
                        "Síť se nevrátila – pozice %s je v Pokračovat" % _rres_w.format_time(position),
                        xbmcgui.NOTIFICATION_WARNING,
                        6000,
                        "RichMovie",
                    )
                except Exception:
                    pass
                self._reset_auto_resume()
                if self._ui_busy():
                    # divák mezitím pracuje v dialogu/klávesnici → okna RichMovie přes to nevracet (Fable N2, D6)
                    _log("AUTO_RESUME_GAVE_UP_NETWORK: otevřený dialog → bez návratu do RichMovie", xbmc.LOGINFO)
                else:
                    self._maybe_return_to_richmovie()
                return
            if mon.waitForAbort(AUTO_RESUME_NETWORK_POLL_S):
                return
        if announced:
            _log(f"AUTO_RESUME_NETWORK_BACK po {time.monotonic() - started:.0f}s", xbmc.LOGINFO)
        self._start_auto_resume(li, ident, position, duration)

    @staticmethod
    def _ui_busy() -> bool:
        """Divák právě pracuje v Kodi: otevřený modální dialog (nastavení, výběr, potvrzení) nebo
        virtuální klávesnice. Samovolné spuštění přehrávání by mu ho zavřelo (Fable F5)."""
        try:
            return bool(xbmc.getCondVisibility("System.HasActiveModalDialog")
                        or xbmc.getCondVisibility("Window.IsActive(virtualkeyboard)"))
        except Exception:
            return False

    def _start_auto_resume(self, li, ident: str, position: float, duration: float) -> None:
        """Pokus o navázání (čítač, požadavek přes SSOT `richmovie_resume`, PlayMedia)."""
        win = xbmcgui.Window(10000)
        if not self._begin_resume_attempt(ident, position):
            self._give_up_auto_resume(li, ident)
            return

        play_url = self._rebuild_play_url(li, ident)
        if not play_url:
            self._reset_auto_resume()
            self._maybe_return_to_richmovie()
            return

        _log(
            f"AUTO_RESUME attempt={self._resume_attempts}/{AUTO_RESUME_MAX_ATTEMPTS} "
            f"ident={ident} pos={position:.0f}s",
            xbmc.LOGINFO,
            context={"ident": ident, "attempt": self._resume_attempts,
                     "position_s": int(position)},
        )
        try:
            _rm_notif(
                _rm_sw.auto_resume_text(position, self._resume_attempts, AUTO_RESUME_MAX_ATTEMPTS),
                xbmcgui.NOTIFICATION_INFO,
                _TOAST_MS,
                "RichMovie",
            )
        except Exception:
            pass
        # Stejný mechanismus jako „Pokračovat ve sledování" (SSOT `richmovie_resume`): plugin._play
        # požadavek převezme (a smaže) a Kodi otevře stream rovnou na pozici. Adresát = ident
        # (Pro kolo 2 #3): kdyby uživatel během čekacího okna spustil JINÝ titul, požadavek zahodí.
        import richmovie_resume as _rres_ar
        try:
            from richmovie_playback_end import player_ctx_key as _ar_key
            _ar_k = _ar_key() or ""
        except Exception:
            _ar_k = ""
        _rres_ar.publish_request(position, ident=ident, runtime_s=duration, source=_rres_ar.SOURCE_AUTO_RESUME,
                                 key=_ar_k)
        win.clearProperty("richmovie.nextup.chain_stopped")
        _spawn_followup(
            "auto_resume_play", self._autoplay_safely,
            args=(play_url, _rres_ar.REQUEST_PROPS),
            # 3.5.149: navázání TÉHOŽ dílu po utnutí streamu není další díl — brána
            # „Díváš se ještě?" sem nepatří (auto-resume má vlastní čítač 3 pokusů).
            kwargs={"gate": False},
            daemon=True)

    def _begin_resume_attempt(self, ident: str, position: float) -> bool:
        """Čítač po sobě jdoucích navázání (auto-resume po utnutí i obnova mrtvého zdroje —
        jeden rozpočet `AUTO_RESUME_MAX_ATTEMPTS`). False = pokusy vyčerpané. Navázání, po
        kterém stream vydržel `AUTO_RESUME_STABLE_S` pozice nebo `AUTO_RESUME_STABLE_WALL_S`
        času, čítač nuluje (zdroj zjevně funguje)."""
        if ident != self._resume_key:
            self._resume_key = ident
            self._resume_attempts = 0
            self._resume_from_pos = 0.0
            self._resume_started_at = 0.0
        elif self._resume_attempts and (
                (position - self._resume_from_pos) >= AUTO_RESUME_STABLE_S
                or (self._resume_started_at > 0.0
                    and (time.monotonic() - self._resume_started_at)
                    >= AUTO_RESUME_STABLE_WALL_S)):
            # Poslední navázání vydrželo (pozicí NEBO časem — A#6: seek zpět
            # dělá deltu pozice zápornou) → zdroj funguje, čítač od nuly.
            self._resume_attempts = 0

        if self._resume_attempts >= AUTO_RESUME_MAX_ATTEMPTS:
            return False
        self._resume_attempts += 1
        self._resume_from_pos = position
        self._resume_started_at = time.monotonic()
        return True

    # ── 3.5.151 (Φ3b): mrtvý zdroj → obnova spojení za běhu ─────────────────────────
    def _dead_source_watch(self, gen: int) -> None:
        """Hlídá, jestli Kodi po výpadku sítě ještě stahuje (hranice cache se posouvá). Když
        ne a síť je zpátky, naváže HNED (D3) na aktuální pozici. Jednou per přehrávání;
        pokusy sdílí rozpočet s auto-resume. Kodi-free rozhodnutí: `DeadSourceDetector`."""
        monitor = xbmc.Monitor()
        try:
            import richmovie_resume as _rres
        except Exception:
            return
        if monitor.waitForAbort(_rres.DEAD_SOURCE_GRACE_S):
            return
        if self._av_gen != gen or not self.isPlayingVideo():
            return
        try:
            li = self.getPlayingItem()
            source = (li.getProperty("richmovie.source") or "").strip().lower()
            ident = li.getProperty("richmovie.ident") or ""
        except Exception:
            return
        self._sample_video_stream(gen)
        if source not in _rres.DEAD_SOURCE_SOURCES or not ident:
            return
        detector = None
        route = _rres.RouteTracker()
        last_state = ""
        stress_noted = False
        while not monitor.abortRequested() and self._av_gen == gen:
            try:
                if not self.isPlayingVideo():
                    return
                duration = float(self.getTotalTime() or 0.0)
                position = float(self.getTime() or 0.0)
                raw_pct = (xbmc.getInfoLabel("Player.ProgressCache") or "").strip()
                cache_pct = float(raw_pct) if raw_pct else None
                paused = bool(xbmc.getCondVisibility("Player.Paused"))
                if detector is None or abs(detector.duration_s - duration) > 1.0:
                    detector = _rres.DeadSourceDetector(duration)
                import richmovie_netstate as _ns
                now = time.monotonic()
                # Síť zpátky = netstate stabilně ONLINE, NEBO vlastní kontroly CDN stabilně OK. Netstate vidí
                # hlavně provoz na Gate — při výpadku Gate by obnova jinak nikdy nepřišla (Fable F1).
                online = (_rres.network_ready(_ns.get_state(), _ns.state_since()) or route.stable(now))
                state = detector.feed(now=now, position_s=position, cache_pct=cache_pct,
                                      paused=paused, online=online)
                if state != last_state and state in (_rres.DEAD_WAIT_NETWORK, _rres.DEAD_SOURCE):
                    _log(f"DEAD_SOURCE_{state.upper()} ident={ident} pos={position:.0f}s cache={raw_pct}% "
                         f"stall={detector.stalled_s(now):.0f}s", xbmc.LOGWARNING,
                         context={"ident": ident, "position_s": int(position), "cache_pct": raw_pct,
                                  "state": state, "source": source})
                last_state = state
                if state in (_rres.DEAD_WAIT_NETWORK, _rres.DEAD_SOURCE) and not stress_noted:
                    stress_noted = True
                    try:
                        import richmovie_continuity as _cont_ds
                        _cont_ds.note_stress(_cont_ds.STRESS_DEAD_SOURCE)   # D4: další díl nižší datový tok
                    except Exception:
                        pass
                if state == _rres.DEAD_WAIT_NETWORK and route.due(now):
                    route.note(self._cdn_reachable(), now)
                elif (state == _rres.DEAD_SOURCE and route.due(now)
                        and self._dead_source_acted_gen != gen):
                    outcome = self._proactive_reconnect(gen, li, ident, position, duration)
                    if outcome == RECONNECT_WAIT_ROUTE:
                        # CDN těsně před obnovou neodpověděla: hlídat dál se zachovaným oknem stání
                        route.note(False, now)
                    else:
                        self._dead_source_acted_gen = gen
                        return
            except RuntimeError:
                return
            except Exception as exc:
                _log(f"dead source watch error: {exc!r}", xbmc.LOGDEBUG)
            if monitor.waitForAbort(_rres.DEAD_SOURCE_SAMPLE_S):
                return

    def _proactive_reconnect(self, gen: int, li, ident: str, position: float, duration: float) -> str:
        """Znovu otevře TÝŽ stream na aktuální pozici, dokud divákovi ještě hraje buffer.
        Vrací `RECONNECT_STARTED` / `RECONNECT_WAIT_ROUTE` (CDN neodpovídá — hlídač zkusí znovu) /
        `RECONNECT_SKIPPED` (obnova se pro toto přehrávání dělat nebude)."""
        import richmovie_resume as _rres
        if not _auto_resume_enabled():
            _log("DEAD_SOURCE: auto_resume_enabled=false → bez obnovy (dohraje buffer)", xbmc.LOGINFO)
            return RECONNECT_SKIPPED
        if is_completed(position, duration):
            _log("DEAD_SOURCE: konec dílu → bez obnovy (dohraje buffer)", xbmc.LOGINFO)
            return RECONNECT_SKIPPED
        if not self._cdn_reachable():
            # Rozhoduje cesta ke ZDROJI, ne sonda Gate (Fable F1). Obnova naslepo by zahodila buffer:
            # VideoPlayer při otevření nového souboru za běhu vyprázdní fronty (VideoPlayer.cpp:2640)
            # a když se nový stream neotevře, divák přijde o zbytek bufferu.
            _log("DEAD_SOURCE: CDN streamu nedosažitelná → čekám", xbmc.LOGINFO)
            return RECONNECT_WAIT_ROUTE
        play_url = self._rebuild_play_url(li, ident)
        if not play_url:
            return RECONNECT_SKIPPED
        with self._resume_lock:
            # EOF (vyschlý buffer) mohl přijít během kontroly — pak navazuje auto-resume, ne my (Pro A PA4a)
            if self._av_gen != gen or self._end_handled or not self.isPlayingVideo():
                _log("RECONNECT_ABORTED: přehrávání mezitím skončilo → navazuje auto-resume", xbmc.LOGINFO)
                return RECONNECT_SKIPPED
            attempt_before = (self._resume_key, self._resume_attempts, self._resume_from_pos, self._resume_started_at)
            if not self._begin_resume_attempt(ident, position):
                _log(f"DEAD_SOURCE: pokusy o navázání vyčerpány ident={ident} → dohraje buffer", xbmc.LOGWARNING)
                return RECONNECT_SKIPPED
            self._restart_inflight_until = time.monotonic() + RESTART_INFLIGHT_S
            self._reconnect_open_gen = gen
        try:
            live_pos = float(self.getTime() or position)
        except Exception:
            live_pos = position
        try:
            self._save_cw_position(final=False)
        except Exception:
            pass
        # Telemetrický segment ani měření cache se tady NEuzavírají (Fable F2/F3): když se nový stream
        # neotevře, starý hraje z bufferu dál. Uzavře je až onAVStarted nového streamu (hook i služba).
        try:
            from richmovie_playback_end import player_ctx_key as _rc_key
            _rc_k = _rc_key() or ""
        except Exception:
            _rc_k = ""
        _rres.publish_request(live_pos, ident=ident, runtime_s=duration, source=_rres.SOURCE_RECONNECT, key=_rc_k)
        _log(f"RECONNECT attempt={self._resume_attempts}/{AUTO_RESUME_MAX_ATTEMPTS} ident={ident} "
             f"pos={live_pos:.0f}s", xbmc.LOGINFO,
             context={"ident": ident, "attempt": self._resume_attempts, "position_s": int(live_pos)})
        try:
            _rm_notif("Obnovuji spojení se zdrojem…", xbmcgui.NOTIFICATION_INFO, _TOAST_MS, "RichMovie")
        except Exception:
            pass
        # `Player.play` otevře nový soubor ZA BĚHU bez opuštění fullscreenu (VideoPlayer umí otevřít
        # soubor, když běží — ApplicationPlayer.cpp:95–126). Builtin PlayMedia by nejdřív zavolal
        # `PreviousWindow()` z fullscreenu (PlayerBuiltins.cpp:446–451) = probliknutí menu.
        try:
            # Φ1 (29.09.2026): přes pojistku jednoho startu (via_player = nový soubor za běhu).
            if not _rm_dispatch.request(play_url, source="reconnect", via_player=True, notify_busy=False):
                raise RuntimeError("spouští se jiné přehrání")
        except Exception as exc:
            with self._resume_lock:
                self._restart_inflight_until = 0.0
                self._reconnect_open_gen = -1
                # Pokus, který stream ani neposlal Kodi, není pokus (Fable N3): čítač zpět, jinak by auto-resume po
                # EOF měl o pokus méně a řetěz by nedostal marker `eof` (první navázání = `_resume_attempts == 0`).
                (self._resume_key, self._resume_attempts,
                 self._resume_from_pos, self._resume_started_at) = attempt_before
            _rres.clear_request()
            # hlídač končí; starý stream dohraje buffer a utnutí převezme auto-resume
            _log(f"RECONNECT play failed: {exc!r} → dohraje buffer", xbmc.LOGWARNING)
            return RECONNECT_SKIPPED
        return RECONNECT_STARTED

    def _cdn_reachable(self) -> bool:
        """Odpoví CDN PRÁVĚ HRANÉHO streamu? Jakákoli HTTP odpověď = trasa k CDN funguje (i 403
        prošlého odkazu — nový resolve dá čerstvý); transportní chyba = ne."""
        try:
            playing = self.getPlayingFile() or ""
        except Exception:
            return False
        import richmovie_resume as _rres_cdn
        url = _rres_cdn.stream_http_url(playing)
        if not url:
            return True   # ne-HTTP zdroj se kontrolou CDN neblokuje (hlídač ho stejně nesleduje)
        return self._cdn_status(url) > 0

    @staticmethod
    def _cdn_status(url: str) -> int:
        """HTTP stav CDN streamu: jeden Range GET 1 KB ze zařízení (SSOT
        `richmovie_webshare.validate_stream_link`, bez retry). Jako sonda projde breakerem netstate
        a úspěch vrátí netstate do ONLINE (Fable F1); selhání se netstate NEHLÁSÍ — mrtvý uzel CDN
        nic neříká o lince ke Gate a opakované kontroly à 15 s stav flapovaly (Fable N4).
        0 = transportní chyba."""
        try:
            import richmovie_resume as _rres_cdn
            import richmovie_webshare as _ws_cdn
            res = _ws_cdn.validate_stream_link(_rres_cdn.stream_http_url(url), probe=True, report_failures=False)
        except Exception as exc:
            _log(f"kontrola CDN selhala: {exc!r}", xbmc.LOGDEBUG)
            return 0
        status = int(res.get("status") or 0)
        _log(f"CDN_CHECK host={res.get('host')} status={status} verdict={res.get('verdict')} "
             f"dt={res.get('dt_ms')}ms", xbmc.LOGINFO)
        return status

    def _sample_video_stream(self, gen: int) -> None:
        """Kodek a výška reálně přehrávaného videa (Φ3c) — po konci přehrávání už nejdou číst."""
        if self._observed_video is not None:
            return
        try:
            resp = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "Player.GetActivePlayers", "params": {}})) or "{}")
            player_id = next((p.get("playerid") for p in (resp.get("result") or []) if p.get("type") == "video"), None)
            if player_id is None or self._av_gen != gen:
                return
            resp = json.loads(xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0", "id": 1, "method": "Player.GetProperties",
                "params": {"playerid": player_id, "properties": ["currentvideostream"]}})) or "{}")
            video = (resp.get("result") or {}).get("currentvideostream") or {}
            if self._av_gen == gen and isinstance(video, dict) and (video.get("codec") or video.get("height")):
                self._observed_video = {"codec": video.get("codec") or "", "height": int(video.get("height") or 0)}
        except Exception as exc:
            _log(f"video stream sample failed: {exc!r}", xbmc.LOGDEBUG)

    def _write_stream_profile(self) -> None:
        """Profil verze seriálu pro výběr dalšího dílu (Φ3c). Podmínky parita s observed
        preferencí: RM přehrávání seriálu, ≥ 300 s pozice, stream z Webshare/Fastshare."""
        try:
            import richmovie_continuity as _cont
            li = self._cached_li
            if li is None or float(self._cached_pos or 0) < _cont.PROFILE_MIN_WATCHED_S:
                return
            tv_id = li.getProperty("richmovie.tv_id") or ""
            source = (li.getProperty("richmovie.source") or "").strip().lower()
            if not tv_id or source not in ("webshare", "fastshare"):
                return
            duration = float(self._cached_dur or 0) or float(li.getProperty("richmovie.duration") or 0)
            video = self._observed_video or {}
            profile = _cont.build_profile(
                release_name=li.getProperty("richmovie.release_name") or "",
                size_bytes=li.getProperty("richmovie.size_bytes") or 0,
                duration_s=duration, source=source, ident=li.getProperty("richmovie.ident") or "",
                video_codec=video.get("codec") or "", video_height=video.get("height") or 0)
            if _cont.save_profile("tv:%s" % tv_id, profile):
                _log(f"STREAM_PROFILE saved tv:{tv_id} codec={profile['codec'] or '?'} "
                     f"h={profile['height'] or '?'} rate={int(profile['bitrate_bps'] or 0)}", xbmc.LOGINFO)
        except Exception as exc:
            _log(f"stream profile write failed: {exc!r}", xbmc.LOGDEBUG)

    def _show_autoplay_pick(self, *, show: bool) -> None:
        """Spotřebuje info o výběru verze dalšího dílu; `show` = start z autoplaye → toast, jakou verzi
        služba vybrala (Richie 16.09.2026: „vůbec nevím, jaký stream se pustil"). Volá se jen pro start,
        který NENÍ obnovou téhož dílu (Fable F7: auto-resume utnutého dílu info nesmí smazat)."""
        try:
            win = xbmcgui.Window(10000)
            raw = win.getProperty("richmovie.nextup.autoplay_info") or ""
            win.clearProperty("richmovie.nextup.autoplay_info")
            if not raw or not show:
                return
            info = json.loads(raw)
            ident = self.getPlayingItem().getProperty("richmovie.ident") or ""
            if not isinstance(info, dict) or info.get("ident") != ident:
                return   # autoplay spustil jiný díl, než pro který se verze vybírala → toast by lhal
            heading = "S%02dE%02d" % (int(info.get("season") or 0), int(info.get("episode") or 0))
            if info.get("reason"):
                heading += " \u00b7 " + str(info["reason"])
            _rm_notif(
                str(info.get("params") or "RichMovie"),
                xbmcgui.NOTIFICATION_INFO,
                6000,
                heading,
                sound=False,
            )
        except Exception as exc:
            _log(f"autoplay pick toast failed: {exc!r}", xbmc.LOGDEBUG)

    def _rebuild_play_url(self, li, ident: str) -> str:
        """Plugin play URL pro TÝŽ stream — parita s plugin._continue_watching_action
        (Webshare ident / Fastshare ident+fs_url+fs_hash + TV/film kontext).
        Přímá CDN URL z getPlayingFile() se NEPOUŽÍVÁ: Webshare linky expirují,
        action=play ji resolvuje znovu."""
        try:
            qs = {"action": "play", "ident": ident,
                  "autoplay": "1"}   # 3.5.130: navázání bez uživatele → žádné dialogy
            source = (li.getProperty("richmovie.source") or "webshare").strip()
            if source == "fastshare":
                fs_url = li.getProperty("richmovie.fs_url") or ""
                fs_hash = li.getProperty("richmovie.fs_hash") or ""
                if not (fs_url and fs_hash):
                    return ""  # bez obou by _play tiše spadl do Webshare větve
                qs["source"] = "fastshare"
                qs["fs_url"] = fs_url
                qs["fs_hash"] = fs_hash
            elif source == "local":
                return ""
            tv_id = li.getProperty("richmovie.tv_id") or ""
            if tv_id:
                qs["tv_id"] = tv_id
                qs["tv_name"] = (li.getVideoInfoTag().getTVShowTitle() or "").strip()
                qs["season"] = li.getProperty("richmovie.season") or ""
                qs["episode"] = li.getProperty("richmovie.episode") or ""
                # parita s _save_cw_position: richmovie.ep_title plugin nenastavuje,
                # název dílu je v InfoTagu (audit #6)
                qs["ep_title"] = (li.getProperty("richmovie.ep_title")
                                  or li.getVideoInfoTag().getTitle() or "").strip()
            else:
                m_tmdb = li.getProperty("richmovie.m_tmdb") or ""
                if li.getProperty("richmovie.m_title"):
                    qs["m_title"] = li.getProperty("richmovie.m_title")
                if li.getProperty("richmovie.m_year"):
                    qs["m_year"] = li.getProperty("richmovie.m_year")
                if m_tmdb:
                    qs["tmdb"] = m_tmdb
            return _rm._url(**qs)
        except Exception as exc:
            _log(f"AUTO_RESUME url build failed: {exc!r}", xbmc.LOGWARNING)
            return ""

    def _other_stream_target(self, li) -> str:
        """URL výpisu streamů TÉHOŽ titulu (díl → `tv_play`, film → `auto`); "" = nejde sestavit.
        Jedno místo pro „vybrat jiný stream“ (vyčerpané navázání, vadný soubor, zaseknutý start — Φ6)."""
        try:
            tv_id = li.getProperty("richmovie.tv_id") or ""
            if tv_id:
                qs = {"action": "tv_play", "tv_id": tv_id,
                      "tv_name": (li.getVideoInfoTag().getTVShowTitle() or "").strip(),
                      "season": li.getProperty("richmovie.season") or "",
                      "episode": li.getProperty("richmovie.episode") or ""}
            else:
                m_tmdb = li.getProperty("richmovie.m_tmdb") or ""
                qs = {"action": "auto", "tmdb": m_tmdb} if m_tmdb else {}
            if qs and _is_custom_ui():
                import richmovie_ui_common as _uc_res
                qs["rm_token"] = _uc_res.streams_new_token()
            return _rm._url(**qs) if qs else ""
        except Exception as exc:
            _log(f"other stream target build failed: {exc!r}", xbmc.LOGWARNING)
            return ""

    def _give_up_auto_resume(self, li, ident: str, broken_at: "float | None" = None) -> None:
        """Vyčerpané pokusy NEBO vadný soubor (`broken_at`, 3.5.158) → nabídnout jiný stream
        téhož titulu. Výpis streamů vadný soubor označí a zařadí na konec."""
        _log(f"AUTO_RESUME give up ident={ident} attempts={self._resume_attempts} "
             f"broken_at={'-' if broken_at is None else int(broken_at)}",
             xbmc.LOGWARNING, context={"ident": ident})
        self._reset_auto_resume()
        target = self._other_stream_target(li)

        def _ask() -> None:
            try:
                mon = xbmc.Monitor()
                if not self._wait_fullscreen_closed(mon):
                    return
                if broken_at is not None:
                    import richmovie_source_health as _sh_ask
                    text = ("Tenhle soubor je poškozený – přehrávání v něm opakovaně končí v %s.\n"
                            "Vyber jinou verzi, pozice je uložená v Pokračovat ve sledování."
                            % _sh_ask.format_time(broken_at))
                else:
                    text = ("Zdroj streamu se opakovaně přerušuje.\n"
                            "Pozice je uložená v sekci Pokračovat ve sledování.")
                choose = xbmcgui.Dialog().yesno(
                    "RichMovie", text,
                    yeslabel="Vybrat jiný stream", nolabel="Zavřít")
                if choose and target:
                    self._navigate(target)
                else:
                    self._maybe_return_to_richmovie()
            except Exception as exc:
                _log(f"AUTO_RESUME dialog failed: {exc!r}", xbmc.LOGWARNING)

        _spawn_followup("other_stream_ask", _ask, daemon=True)

    @_ends_playback
    def onPlayBackStopped(self) -> None:
        """
        Rucni zastaveni: uloz pozici, ale NENAVIGOVAT (uzivatel chtel zastavit).
        """
        # A#1 (Fable audit): Stopped bezprostředně po Ended (některé platformy)
        # NENÍ ruční zastavení — Ended větev už vše zpracovala (CW, auto-resume,
        # čítač). Bez tohoto returnu by chain_stopped zabil běžící auto-resume.
        if self._end_handled:
            _log("STOPPED_AFTER_ENDED: ignored (Ended už zpracován)")
            return
        _kick_log_archive()
        _restore_primed_streams("playback_end")
        if self._open_live:
            self._on_live_end("stopped")   # Televizní kanály F3: Pokračovat / návrat / autoplay se kanálu netýkají
            return
        self._title_open_key = ""    # 4.0.3 (M2): titul uzavírá tenhle callback
        _opened = self._av_started
        # Φ6: Stop poslala nabídka po zaseknutém startu (divák chce jiný stream) — jen pro TOTO otevření
        _redirect = self._stall_redirect if (self._stall_redirect and self._stall_redirect[0] == self._open_seq) else None
        self._stall_redirect = None
        # 3.5.129 (nález N4 incidentu PeterFM): Stopped BEZ onAVStarted = Kodi
        # stream neotevřelo (HTML místo videa, CDN 4xx, rozbitý kontejner) —
        # to není „user pressed Stop". WARNING, ať je incident v NAS filtru vidět;
        # `dt_ms` od onPlayBackStarted odliší selhání (stovky ms) od ručního
        # stopu během bufferování (sekundy) — rozhoduje čtenář, ne heuristika.
        if not self._av_started:
            try:
                import richmovie_player_hook as _ph_stop
                _src = _ph_stop._get_window_prop(_ph_stop._WIN_PROP_SOURCE) or "-"
                _title = _ph_stop._get_window_prop(_ph_stop._WIN_PROP_TITLE) or "-"
            except Exception:
                _src, _title = "-", "-"
            _dt_ms = int((time.monotonic() - self._open_ts) * 1000) if self._open_ts else -1
            if _redirect is not None:
                _log(f"PLAY_OPEN_ABORTED: zaseknutý start, divák zvolil jiný stream source={_src} "
                     f"title={_title[:80]} dt_ms={_dt_ms}", xbmc.LOGWARNING)
            else:
                _log(f"PLAY_OPEN_FAILED: Stopped bez onAVStarted source={_src} "
                     f"title={_title[:80]} dt_ms={_dt_ms}", xbmc.LOGWARNING)
                # Φ6 (A05 F10): dřív divák nedostal od RichMovie ani větu (Nokia box: 28× za sebou).
                # Jen u streamu RichMovie — cizí přehrávání Kodi komentovat nebudeme — a ne když Stop zmáčkl divák
                # sám (sáhl na ovladač až po začátku otevírání; cross-check Pro A8).
                try:
                    _idle_s = float(xbmc.getGlobalIdleTime())
                except Exception:
                    _idle_s = float("inf")
                if self._open_ident and not _rm_sw.stopped_by_user(max(0.0, _dt_ms / 1000.0), _idle_s):
                    _rm_notif(_rm_sw.OPEN_FAILED_TEXT, xbmcgui.NOTIFICATION_WARNING, None, "RichMovie")
            # Φ1: stream se neotevřel = konec startu → uvolnit pojistku (jinak by další klik čekal na TTL)
            _rm_dispatch.finish("open_failed", ident=self._open_ident)
            # 3.5.152 (backlog 3.5.151): kontext titulu neotevřeného streamu nesmí přežít do dalšího
            # přehrávání (hook `_finalize` ho bez onAVStarted nemaže); jen kontext starší než toto otevření
            try:
                import richmovie_player_hook as _ph_clr
                if _ph_clr.clear_player_context_if_older(float(getattr(self, "_open_epoch", 0.0) or 0.0)):
                    _log("PLAY_OPEN_FAILED: kontext titulu uklizen", xbmc.LOGDEBUG)
            except Exception as _clr_exc:
                _log(f"player context cleanup failed: {_clr_exc!r}", xbmc.LOGDEBUG)
        self._av_started = False
        self._open_ts = 0.0   # razítko patří tomuto otevření; příště dt_ms=-1, ne lež (Pro PB11)
        # Zastavit av_monitor + cancel debounce timer
        self._av_gen += 1
        try:
            if hasattr(self, "_av_change_timer") and self._av_change_timer is not None:
                self._av_change_timer.cancel()
                self._av_change_timer = None
        except Exception:
            pass
        self._write_observed_pref()  # Φ4: reálně použitá stopa → observed pref
        self._write_stream_profile()  # Φ3c (3.5.151): verze streamu pro další díl
        try:
            # ruční Stop = člověk je u toho (3.5.149): řetěz bdělosti od nuly
            import richmovie_attention as _att_st
            _att_st.TRACKER.note_input()
        except Exception:
            pass
        self._save_cw_position()   # 3.5.151: neověřené navázání → pozice zůstává na cíli (D1)
        self._resume_hold = None
        self._resume_verify_token += 1
        self._cache_meter_finish(unexpected_eof=False)  # Φ1: ruční Stop → ok/censored/nic
        self._reset_auto_resume()  # ruční Stop = konec incidentu, čítač od nuly
        # Vycistit pending autoplay/nav (uzivatel chtel zastavit, ne prehrat dalsi)
        try:
            win = xbmcgui.Window(10000)
            had_autoplay = bool(win.getProperty("richmovie.nextup.autoplay_url"))
            win.clearProperty("richmovie.nextup.autoplay_url")
            win.clearProperty("richmovie.nextup.nav_url")
            win.clearProperty("richmovie.nextup.nav_pending")
            win.clearProperty("richmovie.nextup.expected_key")
            win.clearProperty("richmovie.nextup.expected_url")
            # Flag pro _autoplay_safely: i kdyz uz thread bezi, zastav retez
            win.setProperty("richmovie.nextup.chain_stopped", "1")
            # Φ6 (A05 F10): Stopped bez obrazu není „user pressed Stop“ (zavádějící log u selhání otevření)
            _log("CHAIN_STOPPED: user pressed Stop" if _opened else "CHAIN_STOPPED: stream se neotevřel")
            if had_autoplay and _opened:
                _rm_notif(_rm_sw.AUTOPLAY_CANCELLED_TEXT, xbmcgui.NOTIFICATION_INFO, None, "RichMovie")
        except Exception:
            pass
        if _redirect is not None and _redirect[1]:
            # Φ6: zaseknutý start → rovnou výpis streamů téhož titulu (vadný soubor v něm je označený)
            self._navigate(_redirect[1])
            return
        # Uživatel zastavil → vrátit do RichMovie Home, ne do holého Kodi (P0-3)
        self._maybe_return_to_richmovie()

    @_ends_playback
    def onPlayBackError(self) -> None:
        """Φ2 (2026-07-06, audit A06): chyba přehrávání dřív neměla ŽÁDNÝ
        handler — uživatel zůstal v holém Kodi a stale origin descriptor pak
        vystřelil falešný reopen u příštího videa. Parita s onPlayBackStopped:
        úklid next-up chainu + návrat do RM (parita s richmovie_player_hook,
        který onPlayBackError má — jen finalizuje telemetrii, návrat neřeší)."""
        _kick_log_archive()
        _restore_primed_streams("playback_end")
        if self._open_live:
            self._on_live_end("error")   # Televizní kanály F3: chyba kanálu ≠ utnutí VOD (žádné navázání ani návrat)
            return
        # Φ1 (29.09.2026): chyba přehrávače = konec startu → uvolnit pojistku jednoho spuštění
        _rm_dispatch.finish("error", ident=self._open_ident)
        # Φ6: chyba = konec tohoto otevření → hlídač startu skončí (`_open_ts` tu zůstává pro log Stopped)
        self._open_seq += 1
        with self._resume_lock:
            # Fable N1 (3.5.151): nový odkaz z obnovy spojení se neotevřel. Kodi při otevírání souboru za běhu
            # nejdřív zahodí vstup starého streamu (VideoPlayer.cpp PLAYER_OPENFILE `m_pInputStream.reset()`), selhaný
            # `Prepare` pak skončí `OnPlayBackError` — divák nemá ani zbytek bufferu. Stejná situace jako utnutí.
            # Jen v okně otevírání obnovy (Fable N6): když resolve v `_play` selže, Kodi neudělá nic a značka by zůstala —
            # pozdější neotevřený JINÝ titul by jinak navázal ten starý.
            reconnect_failed = (self._reconnect_open_gen == self._av_gen
                                and time.monotonic() < self._restart_inflight_until)
            self._reconnect_open_gen = -1
            self._restart_inflight_until = 0.0
            self._av_gen += 1
        if reconnect_failed:
            self._end_handled = True   # případné pozdní Stopped nesmí navázání zrušit (A#1)
            self._av_started = False
            position, duration, _lag = self._last_known_progress_with_lag()
            # první navázání řetězu = marker `eof` (parita s onAVStarted / onPlayBackEnded)
            self._cache_meter_finish(unexpected_eof=int(self._resume_attempts or 0) <= 1)
            _log(f"RECONNECT_OPEN_FAILED: nový odkaz se neotevřel pos={position:.0f}s → navazuje auto-resume",
                 xbmc.LOGWARNING, context={"position_s": int(position), "duration_s": int(duration)})
            self._on_unexpected_eof(position, duration)
            return
        # chyba přehrávání = měření plnění cache nemá platný konec → zahodit (dřív ho zahodil až příští
        # `_cache_meter_start`; onAVStarted od 3.5.151 otevřené měření uzavírá jako soubor otevřený za běhu)
        self._cache_meter = None
        try:
            if hasattr(self, "_av_change_timer") and self._av_change_timer is not None:
                self._av_change_timer.cancel()
                self._av_change_timer = None
        except Exception:
            pass
        try:
            win = xbmcgui.Window(10000)
            win.clearProperty("richmovie.nextup.autoplay_url")
            win.clearProperty("richmovie.nextup.nav_url")
            win.clearProperty("richmovie.nextup.nav_pending")
            win.clearProperty("richmovie.nextup.expected_key")
            win.clearProperty("richmovie.nextup.expected_url")
            win.setProperty("richmovie.nextup.chain_stopped", "1")
            _log("CHAIN_STOPPED: playback error", xbmc.LOGWARNING)
        except Exception:
            pass
        self._maybe_return_to_richmovie()

    def _maybe_return_to_richmovie(self) -> None:
        """Po skončení/zastavení/CHYBĚ přehrávání spuštěného z RM 4.0 custom UI
        vrať uživatele PŘESNĚ tam, odkud přehrávání spustil (Φ2: origin
        descriptor + NavStack replay Home → Detail → Episodes…; fallback Home
        = chování 3.5.86). Vlákno počká na zavření fullscreen videa, pak
        replayne okna. Best-effort, neshodí service."""
        try:
            import richmovie_ui_common as _uc
            # R2-P1-2 (re-audit 2026-07-06): descriptor se NEkonzumuje tady —
            # konzumace až v _reopen za autoplay guardem (commit point). Dřív:
            # seek-to-end mohl nastavit autoplay_url AŽ PO čtení v
            # onPlayBackEnded → descriptor spotřebován, _reopen abortnul bez
            # restore → autoplay chain skončil BEZ návratu (= přesně bug 1).
            if not _uc.return_route_pending():
                return
        except Exception:
            return

        def _reopen() -> None:
            try:
                mon = xbmc.Monitor()
                # počkej na zavření přehrávače (max 6 s — historický strop této cesty)
                if not self._wait_fullscreen_closed(mon, require_player_stopped=True,
                                                    wait_s=6.0):
                    return
                # další epizoda se mezitím mohla rozjet (autoplay) → nereopenovat
                # (descriptor ZŮSTÁVÁ pending — spotřebuje ho až konec chainu)
                w = xbmcgui.Window(10000)
                if w.getProperty("richmovie.nextup.autoplay_url") or self.isPlaying():
                    return
                import richmovie_ui_common as _uc2
                desc = _uc2.consume_return_route()  # commit point
                if desc is None:
                    return
                opened = _uc2.replay_return_routes(desc, abort_check=mon.abortRequested)
                _log(f"RETURN_ROUTE: reopened {opened} window(s)")
            except Exception as exc:
                _log(f"RETURN_ROUTE err: {exc}", xbmc.LOGWARNING)

        _spawn_followup("return_route", _reopen, name="RMReturnRoute", daemon=False)

    def _fullscreen_exit_watch(self, gen: int) -> None:
        """Φ2 (2026-07-06, bug 1 — jádro): Back z fullscreen videa je Kodi core
        chování „opusť fullscreen BEZ zastavení přehrávání" → nevyvolá žádný
        player callback → jediný návratový mechanismus (_maybe_return_to_
        richmovie na Stopped/Ended/Error) se nikdy nespustí a uživatel zůstane
        v holém Kodi, zatímco video hraje dál (dnešní kodi.log 20:00:02–14
        přesně tenhle scénář zachycuje — audit A10).

        Watcher: přehrávání startovalo z RM UI (origin descriptor pending) +
        uživatel reálně stojí v browse okně (Kodi Home 10000 / Videos 10025;
        OSD/seek/dialogy nad fullscreenem se nepočítají) 2 ticky po sobě (~2 s,
        žádný přechodový glitch) → chovej se jako Stop: stop() → callbacky →
        replay návrat do RM. RM je fullscreen-first appliance UX — „browsing
        Kodi při běžícím videu" není náš use-case; kdo ho chce, vypne setting
        rm_back_stops_playback."""
        monitor = xbmc.Monitor()
        # grace po startu: fullscreen se otevírá až po buffer fázi
        if monitor.waitForAbort(3.0):
            return
        misses = 0
        while not monitor.abortRequested() and self._av_gen == gen:
            # R2-P2 (re-audit): isPlayingVideo, NE isPlaying — se stale
            # descriptorem (TTL 6 h) by watcher jinak dokázal zabít HUDBU
            # hrající na pozadí a nevyžádaně replaynout RM okna.
            if not self.isPlayingVideo():
                return
            try:
                import richmovie_ui_common as _uc
                if not (_uc.nav_enabled() and _back_stop_enabled()
                        and _uc.return_route_pending()):
                    misses = 0
                    if monitor.waitForAbort(2.0):
                        return
                    continue
                if xbmc.getCondVisibility("Window.IsActive(fullscreenvideo)") \
                        or xbmc.getCondVisibility("Window.IsActive(videoosd)"):
                    misses = 0
                elif xbmcgui.getCurrentWindowId() in (10000, 10025):
                    misses += 1
                    if misses >= 2:
                        _log("FS_EXIT: Back z fullscreenu → stop + návrat do RM",
                             xbmc.LOGINFO)
                        try:
                            self.stop()  # → onPlayBackStopped → replay návrat
                        except Exception:
                            pass
                        return
                else:
                    misses = 0  # dialog/jiné okno (nastavení, titulky…) — neřešit
                    # R2-P2-3: whitelist browse oken (10000/10025) může být
                    # neúplný → missed exit by byl TICHÝ (bug 1 by tam trval
                    # a nikdo by se to nedozvěděl). 1× per playback zaloguj
                    # neznámé okno bez aktivního dialogu — user_logs ukážou,
                    # která okna do whitelistu chybí.
                    try:
                        _wid = xbmcgui.getCurrentWindowId()
                        if (not xbmc.getCondVisibility("System.HasActiveModalDialog")
                                and getattr(self, "_fsx_unknown_logged", 0) != _wid):
                            self._fsx_unknown_logged = _wid
                            import richmovie_ui_common as _uc_fsx
                            _uc_fsx.nav_event("fs_exit_unknown_window", window=_wid)
                    except Exception:
                        pass
            except Exception:
                pass
            if monitor.waitForAbort(1.0):
                return


    # ─── Per-title audio/subtitle preference detection ───────────────────

    def _write_observed_pref(self) -> None:
        """Φ4 (2026-07-06, audit A03): propíše REÁLNĚ použitou audio/titulkovou
        stopu do title_prefs jako OBSERVED vrstvu (set_observed_pref manuální
        volbu NIKDY nepřepíše). Řeší root cause „next-up nehraje stejnou
        stopou": set_pref měl jediný call-site (manuální přepnutí) → typický
        divák žádnou preferenci neměl → pref-aware výběr streamu (3.4.12)
        neměl vstup a degradoval na quality-first.

        Podmínka ≥300 s reálného sledování — omylem spuštěné video nemá
        vytvářet preference. Volá se z onPlayBackEnded/Stopped (1 zápis na
        playback, žádný disk spam); snapshot plní _handle_av_change každých
        15 s z JSONRPC (jediné místo, které zná i subtitleenabled)."""
        try:
            obs = self._observed_av
            if not obs or not obs.get("key"):
                return
            if float(self._cached_pos or 0) < 300:
                return
            if not (obs.get("audio_lang") or "").strip():
                return  # neznámý jazyk stopy (und/"") — nic smysluplného k uložení
            import richmovie_title_prefs as _tp
            _tp.set_observed_pref(
                obs["key"],
                audio_lang=obs.get("audio_lang") or "",
                sub_lang=obs.get("sub_lang") or "",
                sub_enabled=bool(obs.get("sub_enabled")),
            )
            _log(f"[TitlePrefs] observed pref saved: {obs['key']} "
                 f"audio={obs.get('audio_lang')} sub={obs.get('sub_lang')}"
                 f"/{bool(obs.get('sub_enabled'))}", xbmc.LOGINFO)
            self._observed_av = None
        except Exception as e:
            _log(f"observed pref write: {e}", xbmc.LOGINFO)

    def _av_monitor_loop(self, gen: int = 0) -> None:
        """Polling fallback: kontroluje AV stav kazdych 15s behem prehravani."""
        monitor = xbmc.Monitor()
        # Pockej az se nastavi init_done (max 30s)
        for _ in range(30):
            if self._av_gen != gen or not self.isPlaying() or monitor.abortRequested():
                return
            win = xbmcgui.Window(10000)
            if win.getProperty("richmovie.loc.init_done") == "1":
                break
            if monitor.waitForAbort(1):
                return
        else:
            _log("[TitlePrefs] av_monitor: init_done never set, exiting")
            return

        # Grace period 15s - pockat az se lokalizace ustali,
        # aby se false-positive zmeny z auto-apply nezapocitaly
        _log("[TitlePrefs] av_monitor: grace period 15s")
        if monitor.waitForAbort(15):
            return
        if self._av_gen != gen or not self.isPlaying():
            return

        # Refresh applied_state - snimek AKTUALNIHO stavu NYNI (po grace period),
        # cimz se eliminuji false-positive z rozjezdu lokalizace
        try:
            payload = json.dumps({
                "jsonrpc": "2.0", "id": 1,
                "method": "Player.GetActivePlayers", "params": {}
            })
            resp = json.loads(xbmc.executeJSONRPC(payload) or "{}")
            player_id = None
            for p in (resp.get("result") or []):
                if p.get("type") == "video":
                    player_id = p.get("playerid")
                    break
            if player_id is not None:
                payload = json.dumps({
                    "jsonrpc": "2.0", "id": 1,
                    "method": "Player.GetProperties",
                    "params": {
                        "playerid": player_id,
                        "properties": ["currentaudiostream", "currentsubtitle", "subtitleenabled"]
                    }
                })
                resp = json.loads(xbmc.executeJSONRPC(payload) or "{}")
                props = resp.get("result") or {}
                from richmovie_localization import _norm_lang
                fresh_state = {
                    "audio_lang": _norm_lang(
                        (props.get("currentaudiostream") or {}).get("language") or ""
                    ),
                    "sub_lang": _norm_lang(
                        (props.get("currentsubtitle") or {}).get("language") or ""
                    ),
                    "sub_enabled": bool(props.get("subtitleenabled")),
                }
                win = xbmcgui.Window(10000)
                win.setProperty("richmovie.loc.applied_state",
                                json.dumps(fresh_state, ensure_ascii=False))
                xbmc.log(
                    f"[RichMovie/TitlePrefs] av_monitor: refreshed applied_state={fresh_state}",
                    xbmc.LOGINFO,
                )
        except Exception as e:
            _log(f"TitlePrefs av_monitor: refresh error: {e}", xbmc.LOGINFO)

        _log("[TitlePrefs] av_monitor: started polling")
        while self.isPlaying() and not monitor.abortRequested():
            if monitor.waitForAbort(15):
                break
            if self._av_gen != gen or not self.isPlaying():
                break
            # 3.5.149: vzorek nečinnosti i tady — watch_loop běží jen se zapnutým Next-Up
            try:
                import richmovie_attention as _att_av
                _att_av.TRACKER.sample_idle(float(xbmc.getGlobalIdleTime() or 0))
            except Exception:
                pass
            # Cache pozice pro onPlayBackStopped fallback
            try:
                self._cached_pos = float(self.getTime())
                self._cached_at = time.monotonic()
                _td = float(self.getTotalTime())
                if _td > 0:
                    self._cached_dur = _td
                self._cached_li = self.getPlayingItem()
            except Exception:
                pass
            self._handle_av_change()
        _log("[TitlePrefs] av_monitor: stopped")

    def onAVChange(self) -> None:
        """Detekce zmeny audio/titulku - debounce 5s."""
        if self._open_live:
            return   # Televizní kanály F3: `richmovie.loc.title_key` patří poslednímu titulu VOD, ne kanálu
        try:
            _log("[TitlePrefs] onAVChange FIRED")
            if hasattr(self, "_av_change_timer") and self._av_change_timer is not None:
                self._av_change_timer.cancel()
            self._av_change_timer = threading.Timer(5.0, self._handle_av_change)
            self._av_change_timer.daemon = True
            self._av_change_timer.start()
        except Exception as e:
            _log(f"TitlePrefs onAVChange error: {e}", xbmc.LOGINFO)

    def _handle_av_change(self) -> None:
        """Zpracuje AV zmenu - detekuje manualni zmeny uzivatele."""
        if self._open_live:
            return   # Televizní kanály F3: volba stopy kanálu není preference titulu VOD
        try:
            win = xbmcgui.Window(10000)

            # Guard: jen po dokonceni auto-apply (init_done)
            init_done = win.getProperty("richmovie.loc.init_done")
            if init_done != "1":
                return

            # FIX 22.02.2026: Grace period 20s po lokalizaci.
            # onAVChange se vyvola i z auto-lokalizace (ne jen z manualniho prepnuti).
            # Kodi po lokalizaci jeste "doseda" (meni subtitle indexy, audio metadata)
            # a to zpusobovalo false-positive detekce a nechteny toast "Preference ulozena".
            try:
                _init_ts = float(win.getProperty("richmovie.loc.init_done_ts") or "0")
                if _init_ts > 0 and (time.time() - _init_ts) < 20.0:
                    return
            except Exception:
                pass

            # Guard: potrebujeme title_key
            title_key = win.getProperty("richmovie.loc.title_key") or ""
            if not title_key:
                return

            # R3-P1-3 (re-audit 2026-07-06): jen RM přehrávání! _NextUpPlayer
            # monitoruje VŠECHNA Kodi přehrávání, ale richmovie.loc.* properties
            # čistí jen RM lokalizace — cizí video (jiný addon/soubor) by se
            # porovnávalo (a observed/manual pref ZAPISOVALO) pod stale
            # title_key posledního RM titulu. RM playback poznáme podle
            # richmovie.* properties na PlayingItem (setuje plugin._play).
            try:
                _pli = self.getPlayingItem()
                if not (_pli.getProperty("richmovie.tv_id")
                        or _pli.getProperty("richmovie.m_tmdb")):
                    return
            except Exception:
                return

            # Nacti ulozeny applied state
            applied_raw = win.getProperty("richmovie.loc.applied_state") or ""
            if not applied_raw:
                return
            applied = json.loads(applied_raw)

            # Najdi aktivniho video playera
            payload = json.dumps({
                "jsonrpc": "2.0", "id": 1,
                "method": "Player.GetActivePlayers", "params": {}
            })
            resp = json.loads(xbmc.executeJSONRPC(payload) or "{}")
            player_id = None
            for p in (resp.get("result") or []):
                if p.get("type") == "video":
                    player_id = p.get("playerid")
                    break
            if player_id is None:
                _log("[TitlePrefs] guard: no active video player")
                return

            # Precti aktualni stav
            payload = json.dumps({
                "jsonrpc": "2.0", "id": 1,
                "method": "Player.GetProperties",
                "params": {
                    "playerid": player_id,
                    "properties": ["currentaudiostream", "currentsubtitle", "subtitleenabled"]
                }
            })
            resp = json.loads(xbmc.executeJSONRPC(payload) or "{}")
            props = resp.get("result") or {}

            # Normalizuj aktualni stav
            from richmovie_localization import _norm_lang
            current_audio = _norm_lang(
                (props.get("currentaudiostream") or {}).get("language") or ""
            )
            current_sub = _norm_lang(
                (props.get("currentsubtitle") or {}).get("language") or ""
            )
            current_sub_enabled = bool(props.get("subtitleenabled"))

            # Φ4 (2026-07-06, audit A03): průběžný snapshot REÁLNĚ použité
            # stopy — zdroj pro observed pref (zapíše se 1× při konci
            # přehrávání, viz _write_observed_pref; žádný spam disku).
            self._observed_av = {
                "key": title_key,
                "audio_lang": current_audio,
                "sub_lang": current_sub if current_sub_enabled else "",
                "sub_enabled": current_sub_enabled,
            }

            xbmc.log(
                f"[RichMovie/TitlePrefs] compare: current=({current_audio},{current_sub},{current_sub_enabled}) "
                f"vs applied=({applied.get('audio_lang','')},{applied.get('sub_lang','')},{applied.get('sub_enabled',False)})",
                xbmc.LOGINFO,
            )

            # FIX 22.02.2026: Porovnej s applied state.
            # Kdyz jsou titulky vypnute v OBOU stavech, ignoruj sub_lang
            # (Kodi meni "selected subtitle" index i pri disabled subs -> false positive).
            applied_sub_enabled = bool(applied.get("sub_enabled", False))

            audio_changed = (current_audio != applied.get("audio_lang", ""))
            sub_enabled_changed = (current_sub_enabled != applied_sub_enabled)
            # Sub jazyk porovnavej JEN kdyz jsou titulky zapnute alespon v jednom stavu
            sub_lang_changed = False
            if current_sub_enabled or applied_sub_enabled:
                sub_lang_changed = (current_sub != applied.get("sub_lang", ""))

            changed = audio_changed or sub_enabled_changed or sub_lang_changed

            if not changed:
                return

            # Uzivatel rucne zmenil -> ulozit preferenci
            import richmovie_title_prefs as _tp
            _tp.set_pref(
                title_key,
                audio_lang=current_audio,
                sub_lang=current_sub if current_sub_enabled else None,
                sub_enabled=current_sub_enabled,
            )

            # Aktualizuj applied_state (aby se neukladalo znovu)
            new_state = {
                "audio_lang": current_audio,
                "sub_lang": current_sub,
                "sub_enabled": current_sub_enabled,
            }
            win.setProperty("richmovie.loc.applied_state",
                            json.dumps(new_state, ensure_ascii=False))

            # Toast notifikace (thread-safe via executebuiltin)
            try:
                li = self.getPlayingItem()
                tv_show = li.getVideoInfoTag().getTVShowTitle()
                movie_title = li.getVideoInfoTag().getTitle()
                display_name = str(tv_show or movie_title or title_key).replace('"', "'")
                xbmc.executebuiltin(
                    'Notification("RichMovie", "Preference ulozena pro %s", 3000, DefaultIconInfo.png)'
                    % display_name
                )
            except Exception:
                pass

            xbmc.log(
                f"[RichMovie/TitlePrefs] SAVED pref for {title_key}: "
                f"audio={current_audio} sub={current_sub} enabled={current_sub_enabled}",
                xbmc.LOGINFO,
            )

        except Exception as e:
            _log(f"TitlePrefs _handle_av_change ERROR: {e}", xbmc.LOGINFO)



    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def _watch_loop(self, gen: int = -1) -> None:
        """
        Hlavní smyčka monitorující přehrávání:

        • (_margin s) před koncem → tichý pre‑fetch další epizody
        • (_PROMPT_MARGIN s)      → dotaz „Přehrát další díl?"
        • Fallback: pokud Kodi nezná TotalTime (0 s),
          použijeme ListItem property „richmovie.duration".
        """
        prefetch_done   = False
        asked           = False
        monitor         = xbmc.Monitor()
        _cw_tick        = 0          # pocitadlo pro continue-watching checkpoint
        _CW_INTERVAL    = 6          # kazdy 6. tick (6*5s = 30s)

        while self.isPlaying() and (gen < 0 or self._av_gen == gen):
            try:
                total   = int(self.getTotalTime())
                current = int(self.getTime())

                # Cache pro onPlayBackStopped (getTime() uz nebude fungovat)
                self._cached_pos = float(current)
                self._cached_at = time.monotonic()
                self._cached_dur = float(total) if total > 0 else self._cached_dur
                try:
                    self._cached_li = self.getPlayingItem()
                except Exception:
                    pass

                # Fallback na ručně uloženou délku
                if total <= 0:
                    try:
                        li = self.getPlayingItem()
                        total = int(li.getProperty("richmovie.duration") or 0)
                    except Exception:
                        total = 0                    # stále nevíme stopáž

                if total <= 0:                       # stále chybí údaje
                    if monitor.waitForAbort(_CHECK_EVERY):
                        break
                    continue

                remain = total - current

                # 1️⃣ Prefetch (jen jednou)
                if (not prefetch_done) and remain <= _margin():
                    self._prefetch()
                    prefetch_done = True

                # 2️⃣ Dialog Next‑Up (pouze pokud je v nastavení povolen)
                if (not asked) and remain <= _PROMPT_MARGIN:
                    if _autoplay_enabled():
                        # Auto-play toast: informovat uzivatele co se bude prehravat
                        asked = True
                        try:
                            ap_url = xbmcgui.Window(10000).getProperty("richmovie.nextup.autoplay_url") or ""
                            if ap_url:
                                _ap_li = self.getPlayingItem()
                                _ap_tv = _ap_li.getVideoInfoTag().getTVShowTitle() or ""
                                _ap_s = int(_ap_li.getProperty("richmovie.season") or 0)
                                _ap_e = int(_ap_li.getProperty("richmovie.episode") or 0)
                                _ap_coords = _next_coords(
                                    int(_ap_li.getProperty("richmovie.tv_id") or 0),
                                    _ap_s, _ap_e,
                                )
                                if _ap_coords:
                                    _ns, _ne = _ap_coords
                                    # Ep title z prefetch (best-effort)
                                    _ap_ep_title = ""
                                    try:
                                        from urllib.parse import parse_qs, urlparse
                                        _parsed = parse_qs(urlparse(ap_url).query)
                                        _ap_ep_title = (_parsed.get("ep_title", [""])[0] or "").strip()
                                    except Exception:
                                        pass
                                    _toast_txt = f"Za chvili: S{_ns:02d}E{_ne:02d}"
                                    if _ap_ep_title:
                                        _toast_txt += f" - {_ap_ep_title}"
                                    _safe_tv = str(_ap_tv or "RichMovie").replace('"', "'")
                                    _safe_toast = str(_toast_txt).replace('"', "'")
                                    xbmc.executebuiltin(
                                        'Notification("%s", "%s", 8000, DefaultIconInfo.png)'
                                        % (_safe_tv, _safe_toast)
                                    )
                        except Exception:
                            pass
                    elif _dialog_enabled():
                        # R3-P2-10: _ask_next volá _next_coords (TMDb HTTP) —
                        # TMDbError propadal přes `except RuntimeError` níže a
                        # ZABÍJEL watch-loop (žádné CW checkpointy do konce
                        # dílu). Φ0 Gate-fallback klíče tuhle cestu otevřel
                        # i uživatelům, kde dřív končila na prázdném klíči.
                        try:
                            self._ask_next()
                        except Exception as _an_e:
                            _log(f"_ask_next failed: {_an_e!r}", xbmc.LOGWARNING)
                        asked = True
                        break
                    else:
                        # Jen prefetch toast, zadna navigace
                        asked = True

                # 3.5.149: vzorek nečinnosti Kodi — pokles `getGlobalIdleTime()` = vstup člověka
                try:
                    import richmovie_attention as _att_w
                    _att_w.TRACKER.sample_idle(float(xbmc.getGlobalIdleTime() or 0))
                except Exception:
                    pass

                # Continue-watching checkpoint (kazdych ~30s)
                _cw_tick += 1
                if _cw_tick >= _CW_INTERVAL:
                    _cw_tick = 0
                    try:
                        # R3-P2-2: final=False — checkpoint JEN ukládá pozici,
                        # advance/✔ dělají až finální callbacky (Ended/Stopped)
                        self._save_cw_position(final=False)
                    except Exception:
                        pass

            except RuntimeError:                     # prehravac zmizel
                break

            if monitor.waitForAbort(_CHECK_EVERY):
                break





    def _publish_autoplay_pick(self, best, rels, pref, continuity, season: int, episode: int) -> None:
        """Proč služba vybrala tuhle verzi dalšího dílu: log `NEXTUP_PICK` do user_logs (dřív jen
        kodi.log) + Window prop pro toast při startu (`_show_autoplay_pick`)."""
        try:
            import richmovie_continuity as _cont
            prefer_lower = bool((continuity or {}).get("prefer_lower"))
            rank = _cont.rank_release(best, continuity) if continuity else None
            reason, params = _cont.describe_release(best, rank, prefer_lower=prefer_lower)
            ranked = sorted(rels, key=lambda _x: _rm._release_sort_key(_x, pref, continuity))[:4]
            top = [{"ident": getattr(r, "ident", ""), "size_mb": int((getattr(r, "size", 0) or 0) / 1048576),
                    "q": getattr(r, "quality", ""), "cont": (_cont.rank_release(r, continuity) if continuity else None)}
                   for r in ranked]
            _log(f"NEXTUP_PICK S{season:02d}E{episode:02d} ident={getattr(best, 'ident', '')} "
                 f"cont_rank={rank} prefer_lower={prefer_lower} {params}", xbmc.LOGINFO,
                 context={"ident": getattr(best, "ident", ""), "cont_rank": rank, "prefer_lower": prefer_lower,
                          "has_profile": bool(continuity), "params": params, "top": top})
            xbmcgui.Window(10000).setProperty("richmovie.nextup.autoplay_info", json.dumps({
                "ident": getattr(best, "ident", ""), "season": season, "episode": episode,
                "reason": reason, "params": params}, ensure_ascii=False))
        except Exception as exc:
            _log(f"autoplay pick describe failed: {exc!r}", xbmc.LOGDEBUG)

    def _prefetch(self) -> None:
        """
        23-08-2025 11:17 CEST (Europe/Prague)
        ÚČEL: Tichý pre‑fetch příští epizody (stejná logika jako aktivní hledání),
            uloží do RAM i disk‑cache a po úspěchu zobrazí malý toast „Další díl
            připraven", aby uživatel věděl, že výběr streamů bude okamžitý.
        """
        if self._open_live:
            return   # Televizní kanály F3: kanál přepnutý během iterace watch loopu filmu nemá „další díl“
        try:
            li = self.getPlayingItem()
        except RuntimeError:
            return
        tv_name = li.getVideoInfoTag().getTVShowTitle()
        tv_id   = li.getProperty("richmovie.tv_id")

        try:
            season  = int(li.getProperty("richmovie.season")
                        or li.getVideoInfoTag().getSeason())
            episode = int(li.getProperty("richmovie.episode")
                        or li.getVideoInfoTag().getEpisode())
        except (TypeError, ValueError):
            return

        if not (tv_id and tv_name and season > 0 and episode > 0):
            return

        try:
            coords = _next_coords(int(tv_id), season, episode)
        except Exception as _nc_exc:
            # 3.5.118: `_next_coords` chyby propaguje; tady je správná odpověď
            # „nepřehrávat další díl" (stejně jako do 3.5.117 při None).
            _log(f"NEXTUP next_coords failed tv_id={tv_id}: {_nc_exc!r}", xbmc.LOGWARNING)
            return
        if not coords:
            return
        next_season, next_ep = coords

        cache_key = (tv_id, next_season, next_ep)
        key_str   = f"{tv_id}:{next_season}:{next_ep}"

        # Už v RAM? Přeskočit jen když není co armovat. A#4 (Fable audit):
        # po auto-resume onAVStarted smazal autoplay_url; cache-hit early-return
        # ho už nikdy nearmoval → po dokoukání se další díl nespustil. Worker
        # při existující cache jen znovu vybere best (search jde přes SearchCache).
        with _rm.NEXT_CACHE_LOCK:
            _in_ram = cache_key in _rm.NEXT_CACHE
        if _in_ram:
            _armed = bool(xbmcgui.Window(10000).getProperty("richmovie.nextup.autoplay_url"))
            if _armed or not _autoplay_enabled():
                return

        def _worker() -> None:
            # Φ-C (30.09.2026, E1-F08/F10): TENTÝŽ díl se předhledává nejvýš jednou (claim sdílený s výpisem
            # dílu) a autoritativně prázdné předstažení se do konce běhu Kodi (nejdéle 6 h) neopakuje.
            import richmovie_episode_search as _eps
            import richmovie_guard as _pf_guard
            if _eps.EMPTY_MEMO.is_fresh(key_str):
                # Divák mohl díl mezitím najít ručně (plugin = jiný proces, výsledek je na disku) → paměť
                # „nic nenalezeno“ už neplatí (audit Fable F1-V9)
                if _rm._disk_nextup_cache().get(key_str):
                    _eps.EMPTY_MEMO.forget(key_str)
                else:
                    _log(f"PREFETCH_SKIP_EMPTY_MEMO key={key_str} (nedávné hledání nic nenašlo)", xbmc.LOGINFO)
                    return
            _claim = _eps.prefetch_claim_name(tv_id, next_season, next_ep)
            _token = _pf_guard.claim(_claim, _eps.PREFETCH_CLAIM_TTL_S)
            if _token is None:
                _log(f"PREFETCH_ALREADY_RUNNING key={key_str}", xbmc.LOGINFO)
                return
            try:
                _worker_claimed(lambda: _pf_guard.renew(_claim, _token, _eps.PREFETCH_CLAIM_TTL_S))
            finally:
                _pf_guard.release(_claim, _token)

        def _worker_claimed(_renew) -> None:
            import richmovie_episode_search as _eps
            mon = xbmc.Monitor()
            if mon.abortRequested():
                return
            rels = _rm._search_episode(tv_id, tv_name, next_season, next_ep, on_wave_end=_renew)
            if mon.abortRequested():
                return
            if not rels:
                if _eps.empty_is_authoritative(rels, _rm.LAST_EPISODE_SEARCH_INFO.get(key_str)):
                    _eps.EMPTY_MEMO.remember(key_str)
                xbmc.log(
                    f"[RichMovie/NextUp] PREFETCH_EMPTY: "
                    f"{tv_name} S{next_season:02d}E{next_ep:02d} - zadne streamy",
                    xbmc.LOGINFO,
                )
                try:
                    xbmc.executebuiltin(
                        'Notification("%s", "%s", %d, DefaultIconWarning.png)'
                        % ("Další díl",
                           "S%02dE%02d nenalezen" % (next_season, next_ep),
                           4000)
                    )
                except Exception:
                    pass
                return
            if rels:
                # RAM-cache (thread-safe)
                with _rm.NEXT_CACHE_LOCK:
                    _rm.NEXT_CACHE[cache_key] = rels
                # Disk-cache — jen ÚPLNÝ výsledek. Když při hledání selhal zdroj (např. výpadek Fastshare),
                # seznam stačí v paměti služby pro automatické přehrání; výpis dílu si pak hledá sám a
                # neúplný seznam se mu nevydává za hotový (R2; audit Fable F1-V4).
                _pf_info = _rm.LAST_EPISODE_SEARCH_INFO.get(key_str) or {}
                if int(_pf_info.get("errors") or 0):
                    _log(f"PREFETCH_PARTIAL key={key_str} errors={_pf_info.get('errors')} "
                         f"streams={len(rels)} (jen paměť služby)", xbmc.LOGINFO)
                else:
                    try:
                        _rm._disk_nextup_cache().put(key_str, [asdict(r) for r in rels])
                    except Exception as _dc_exc:
                        _log(f"nextup disk cache write failed: {_dc_exc!r}", xbmc.LOGWARNING)

                # Toast jen jednou pro dany dil
                try:
                    win = xbmcgui.Window(10000)
                    last_key = win.getProperty("richmovie.nextup.toast_key") or ""
                    if last_key != key_str:
                        _toast_name = str(tv_name).replace('"', "'")
                        xbmc.executebuiltin(
                            'Notification("%s", "%s", %d, DefaultIconInfo.png)'
                            % ("Další díl připraven",
                               "%s – S%02dE%02d" % (_toast_name, next_season, next_ep),
                               3000)
                        )
                        win.setProperty("richmovie.nextup.toast_key", key_str)
                except Exception:
                    pass

                # AUTO-PLAY: pripravit PlayMedia URL pro nejlepsi stream
                if _autoplay_enabled():
                    try:
                        # Per-title preference (audio/titulky) — vybrat stream s
                        # preferovaným dabingem/titulky (ne jen nejvyšší kvalita).
                        # SSOT `plugin._lookup_title_pref` (titul + profil + zařízení) — stejně jako výpis dílu
                        _np_pref = _rm._lookup_title_pref(tv_id=tv_id)
                        # 3.5.151 (Φ3c): stejná verze jako minulý díl (po výpadcích nižší datový tok)
                        _np_cont = None
                        try:
                            import richmovie_continuity as _np_cont_mod
                            _np_cont = _np_cont_mod.context_for_title("tv:%s" % tv_id)
                        except Exception:
                            _np_cont = None
                        best = _rm._pick_best_release(rels, pref=_np_pref, continuity=_np_cont)
                        try:
                            _rm._save_autoplay_snapshot(key_str, tv_id, next_season, next_ep, rels,
                                                        _np_pref, _np_cont)
                        except Exception as _snap_exc:
                            _log(f"autoplay snapshot failed: {_snap_exc!r}", xbmc.LOGWARNING)
                        # 3.5.129 (Fable audit F-03): Free účet + jen Webshare →
                        # autoplay by skončil blokujícím modálem uprostřed noci.
                        # Služba dialogy nemá: přeskočit + WARNING + krátký toast.
                        try:
                            import richmovie_account_state as _np_account
                            _np_allowed, _np_reason = _np_account.playback_allowed(
                                _np_account.load(),
                                source=(getattr(best, "source", "webshare") or "webshare") if best else "webshare")
                        except Exception:
                            _np_allowed, _np_reason = True, ""
                        # Profily (3.5.134, D12): Host smí Next-Up (nic se neukládá); multi účet
                        # BEZ zvoleného profilu ne — nevíme, čí díl by to byl.
                        try:
                            import richmovie_profile as _np_profile
                            if _np_allowed and not _np_profile.autoplay_allowed():
                                _np_allowed, _np_reason = False, "no_profile_chosen"
                        except Exception:
                            pass
                        if best and not _np_allowed:
                            _log(f"AUTOPLAY_SKIPPED reason={_np_reason} ident={best.ident} "
                                 f"tv:{tv_id} S{next_season}E{next_ep}", xbmc.LOGWARNING)
                            try:
                                _rm_notif(
                                    "Další díl nelze přehrát bez Webshare VIP.",
                                    xbmcgui.NOTIFICATION_WARNING,
                                    5000,
                                    "RichMovie",
                                )
                            except Exception:
                                pass
                            best = None
                        # Diagnostika (B / FU-4): pref hit/miss + audio/sub vybraného streamu.
                        try:
                            xbmc.log(
                                "[RichMovie/NextUp] PREF tv:%s = %s | picked audios=%s subs=%s"
                                % (tv_id,
                                   (_np_pref if _np_pref else "NONE"),
                                   (getattr(best, "audios", None) if best else None),
                                   (getattr(best, "subs", None) if best else None)),
                                xbmc.LOGINFO,
                            )
                        except Exception:
                            pass
                        if best:
                            self._publish_autoplay_pick(best, rels, _np_pref, _np_cont, next_season, next_ep)
                            # Ep title z TMDb (best-effort)
                            _ep_title = ""
                            try:
                                from richmovie_settings import get_tmdb_api_key
                                _tmdb_key = get_tmdb_api_key()  # SSOT 3.5.69 (Gate fallback)
                                if _tmdb_key:
                                    _ep_det = TMDb(_tmdb_key, lang="cs-CZ").episode_details(
                                        int(tv_id), next_season, next_ep
                                    )
                                    _ep_title = (_ep_det.get("name") or "").strip()
                            except Exception:
                                pass

                            qs = {
                                "action": "play",
                                "ident": best.ident,
                                "tv_id": tv_id,
                                "tv_name": tv_name,
                                "season": str(next_season),
                                "episode": str(next_ep),
                                "ep_title": _ep_title,
                                # 3.5.130: přehrání bez uživatele → žádné modály ani
                                # interaktivní login (Pro PB7 z 02.09.2026)
                                "autoplay": "1",
                            }
                            if getattr(best, "source", "webshare") == "fastshare":
                                qs["source"] = "fastshare"
                                if getattr(best, "fs_download_url", None):
                                    qs["fs_url"] = best.fs_download_url
                                if getattr(best, "fs_hash", None):
                                    qs["fs_hash"] = best.fs_hash

                            # Fallback: top 4 Webshare kandidatu serazenych dle kvality
                            try:
                                _fb = []
                                _fb_broken = _rm._broken_sources()
                                _fb_blocked = _rm._ws_playback_blocked()
                                for _r in sorted(rels, key=lambda _x: _rm._listing_sort_key(
                                        _x, _np_pref, _np_cont, _fb_blocked, _fb_broken)):
                                    _rid = getattr(_r, "ident", "")
                                    if _rid == best.ident or _rid.startswith("fs:"):
                                        continue
                                    _fb.append(_rid)
                                    if len(_fb) >= 4:
                                        break
                                if _fb:
                                    qs["fallback"] = ",".join(_fb)
                            except Exception:
                                pass

                            ap_url = _rm._url(**qs)
                            xbmcgui.Window(10000).setProperty(
                                "richmovie.nextup.autoplay_url", ap_url
                            )
                            xbmc.log(
                                f"[RichMovie/NextUp] AUTOPLAY_READY: "
                                f"{tv_name} S{next_season:02d}E{next_ep:02d} "
                                f"ident={best.ident[:12]}",
                                xbmc.LOGINFO,
                            )
                    except Exception as e:
                        _log(f"AUTOPLAY_PREP_ERR: {e}", xbmc.LOGINFO)

        threading.Thread(target=_worker, daemon=True).start()


    # ---------------------------------- METODA ---------------------------------- #
    # service_nextup.py › class _NextUpPlayer # _ask_next (upraveno: 13.12.2025 15:26 CET, Europe/Prague – kompatibilní yesno() bez nolabel/yeslabel + ochrana proti pádu)
    # ---------------------------------------------------------------------------- #
    def _ask_next(self) -> None:
        """
        Zeptá se na přehrání dalšího dílu a připraví odloženou navigaci.

        FIX race condition: navigace se pre-nastaví PŘED zobrazením dialogu,
        aby onPlayBackEnded mohl navigovat i když dialog ještě blokuje.
        Pokud uživatel klikne Ne, navigace se zruší (pokud ještě neproběhla).
        """
        if self._open_live:
            return   # Televizní kanály F3: kanál přepnutý během iterace watch loopu filmu nemá „další díl“
        try:
            li = self.getPlayingItem()
        except RuntimeError:
            return
        tv_name = li.getVideoInfoTag().getTVShowTitle()
        tv_id = li.getProperty("richmovie.tv_id")

        try:
            season = int(li.getProperty("richmovie.season") or li.getVideoInfoTag().getSeason())
            episode = int(li.getProperty("richmovie.episode") or li.getVideoInfoTag().getEpisode())
        except (TypeError, ValueError):
            return

        if not (tv_id and tv_name and season > 0 and episode > 0):
            return

        try:
            coords = _next_coords(int(tv_id), season, episode)
        except Exception as _nc_exc:
            # 3.5.118: `_next_coords` chyby propaguje; tady je správná odpověď
            # „nepřehrávat další díl" (stejně jako do 3.5.117 při None).
            _log(f"NEXTUP next_coords failed tv_id={tv_id}: {_nc_exc!r}", xbmc.LOGWARNING)
            return
        if not coords:
            return
        next_season, next_ep = coords

        ep_title = ""
        ep_overview = ""
        try:
            from richmovie_settings import get_tmdb_api_key
            tmdb_key = get_tmdb_api_key()  # SSOT 3.5.69 (Gate fallback)
            if tmdb_key:
                ep_det = TMDb(tmdb_key, lang="cs-CZ").episode_details(int(tv_id), next_season, next_ep)
                ep_title = (ep_det.get("name") or "").strip()
                ep_overview = (ep_det.get("overview") or "").strip()
        except TMDbError:
            pass

        line = f"{tv_name}  S{next_season:02d}E{next_ep:02d}"
        if ep_title:
            line += f" – {ep_title}"
        if ep_overview:
            short = ep_overview[:200]
            if len(ep_overview) > 200:
                idx = short.rfind(" ")
                if idx > 100:
                    short = short[:idx]
                short += "..."
            line += f"\n\n{short}"

        win = xbmcgui.Window(10000)
        expected_key = f"{tv_id}:{next_season}:{next_ep}"

        # PRE-SET navigace PRED dialogem (optimisticky "Ano")
        # Pokud video skonci behem dialogu, onPlayBackEnded muze rovnou navigovat.
        # Φ2 (2026-07-06, audit A08): RM 4.0 — picker-first URL (rm_token, BEZ
        # nav_key). nav_key by klik degradoval na legacy signed-nav directory;
        # rm_token → _list_releases otevře custom Stream-picker fallbackem
        # (prefetch fast-path drží nav_pending). Legacy větev beze změny.
        if _is_custom_ui():
            import richmovie_ui_common as _uc_dlg
            url_yes = _rm._url(
                action="tv_play",
                tv_id=int(tv_id),
                tv_name=tv_name,
                season=next_season,
                episode=next_ep,
                rm_token=_uc_dlg.streams_new_token(),
            )
        else:
            url_yes = _rm._url(
                action="tv_play",
                tv_id=int(tv_id),
                tv_name=tv_name,
                season=next_season,
                episode=next_ep,
                nav_key=expected_key,
            )
        win.setProperty("richmovie.nextup.nav_url", url_yes)
        win.setProperty("richmovie.nextup.nav_pending", "1")
        win.setProperty("richmovie.nextup.expected_key", expected_key)
        win.setProperty("richmovie.nextup.expected_url", url_yes)

        try:
            self._prefetch()
        except Exception:
            pass

        try:
            _rm._log_event("NEXTUP_SET", expected_key, url_yes)
        except Exception:
            pass

        # Dialog (blocking – ale navigace uz je pripravena pro pripad, ze video skonci)
        try:
            play_next = xbmcgui.Dialog().yesno("Prehrat dalsi dil?", line)
        except Exception as e:
            # Dialog failed — clean up pre-set navigation properties
            win.clearProperty("richmovie.nextup.nav_url")
            win.clearProperty("richmovie.nextup.nav_pending")
            win.clearProperty("richmovie.nextup.expected_key")
            win.clearProperty("richmovie.nextup.expected_url")
            try:
                _rm._log_event("NEXTUP_DIALOG_ERR", str(e))
            except Exception:
                pass
            return

        if not play_next:
            # Uzivatel klikl Ne → zrusit navigaci (pokud jeste neprobehla)
            if win.getProperty("richmovie.nextup.nav_url"):
                # Φ2 (audit A08): RM 4.0 → custom Episodes okno (rm_episodes),
                # NE legacy tv_episodes directory (únik z nového designu).
                if _is_custom_ui():
                    url_no = _rm._url(
                        action="rm_episodes",
                        tv_id=int(tv_id),
                        tv_name=tv_name,
                    )
                else:
                    url_no = _rm._url(
                        action="tv_episodes",
                        tv_id=int(tv_id),
                        tv_name=tv_name,
                        season=season,
                    )
                win.setProperty("richmovie.nextup.nav_url", url_no)
                win.clearProperty("richmovie.nextup.nav_pending")
                win.clearProperty("richmovie.nextup.expected_key")
                win.clearProperty("richmovie.nextup.expected_url")

            try:
                _rm._log_event("NEXTUP_CANCEL", f"{tv_id}:{season}:{episode}")
            except Exception:
                pass




# ------------------------------------------------------------------ #
if __name__ == "__main__":
    import xbmcaddon  # needed for crash flush password retrieval
    # 21.02.2026 – Crash reporting + flush
    try:
        import richmovie_crash
        richmovie_crash.install(source="service_nextup")
        _sn_pw = richmovie_settings.get_str("password")   # SSOT, explicitní ID (3.5.124)
        if _sn_pw:
            import threading as _sn_th
            _sn_th.Thread(target=richmovie_crash.flush_pending, args=(_sn_pw,), daemon=True).start()
    except Exception:
        pass

    _log("[TitlePrefs] service_nextup.py STARTED (has onAVChange+av_monitor)")
    # 3.5.151 (Φ3): osiřelé `*.tmp` (proces zabit mezi zápisem a replace) a karanténa > 30 dní
    try:
        import richmovie_atomic as _nu_atomic
        import richmovie_paths as _nu_paths
        _nu_atomic.cleanup_data_dirs(str(_nu_paths.addon_data_dir()))
    except Exception as _nu_cl_exc:
        _log(f"data cleanup failed: {_nu_cl_exc!r}", xbmc.LOGDEBUG)
    player  = _NextUpPlayer()
    try:
        # 3.5.149: řetěz „dílů bez diváka" přežije restart Kodi i vybitou baterii. Když Kodi zemřelo
        # uprostřed řetězu, na dotaz nikdo neodpověděl → stejný výsledek jako timeout dialogu:
        # Pokračovat zpět na první díl bez reakce (Fable audit F4/F17 14.09.2026).
        import richmovie_attention as _att_boot
        if _att_boot.migrate_threshold_defaults():
            _log("ATTENTION: prahy dotazu převedeny ze staré výchozí 2 / 60 na 3 / 90 (D2)", xbmc.LOGINFO)
        if _att_boot.load_state():
            _tr = _att_boot.TRACKER
            _cfg = _att_boot.settings_thresholds()
            _log(f"ATTENTION: obnoven řetěz {_tr.streak} dílů bez reakce", xbmc.LOGINFO)
            if _att_boot.boot_sleep_proven(_tr.streak, _tr.ask_shown_at, ask_after=_cfg["ask_after"]):
                player._sleep_verdict(_tr, reason="boot")   # dotaz byl na obrazovce a Kodi zemřelo = nikdo neodpověděl
            elif _tr.streak:
                # řetěz bez zobrazeného dotazu není důkaz spánku (D1 + M8, audit Fable A-V9): díly zůstávají ✔
                _log(f"ATTENTION: řetěz {_tr.streak} dílů bez zobrazeného dotazu → bez ⏾", xbmc.LOGINFO)
            _tr.reset_streak()
            _att_boot.clear_state()
    except Exception as _att_b:
        _log(f"attention boot restore failed: {_att_b!r}", xbmc.LOGWARNING)
    try:
        # 4.0.3 (M3): ✔ a postup odmítnuté Gate kvůli mezím (completion > 1) zpět do fronty — jednorázově, idempotentní
        import richmovie_state_sync as _ss_boot
        _ss_boot.requeue_clamped_quarantine()
    except Exception as _q_b:
        _log(f"quarantine requeue failed: {_q_b!r}", xbmc.LOGWARNING)
    # 4.0.3 (M8): rozkoukané tituly, kterým Kodi zemřelo v titulcích → uzavřít (non-daemon: TMDb přes síť)
    threading.Thread(target=_close_completed_leftovers, name="RMCompletedLeftovers", daemon=False).start()
    monitor = xbmc.Monitor()

    # 2026-04-27 — User logs pipeline drainer init (Phase 4 z user_logs Handoff plánu).
    # Original D2 decision (drainer in service_warm.py) reverted: service_warm.py
    # nestartuje na tomto Kodi buildu (ověřeno 0 entries v kodi.log napříč
    # sessions). service_nextup.py je proven-running xbmc.service.
    _nu_log_drainer = None
    try:
        import richmovie_logging as _nu_rm_logging
        import richmovie_log_buffer as _nu_rm_buf
        import richmovie_log_drainer as _nu_rm_drain
        _nu_addon = xbmcaddon.Addon()
        _nu_rm_logging.init_logging(_nu_addon)
        # Observability 2026-07-01 (3.5.79): per-user DEBUG gate ze serveru
        # (Gate /auth → permissions.debug_logs, mig 0018 default TRUE).
        # Fail-safe False (INFO). Zrcadlí bootstrap plugin.py — služba je
        # dlouhoběžící proces s vlastní pipeline instancí, flag se u ní
        # aplikuje při startu Kodi (flip chytí po restartu; server-side
        # per-level drop v batch handleru platí okamžitě i bez toho).
        try:
            import richmovie_gate as _nu_rm_gate_dbg
            _nu_rm_logging.set_debug(_nu_rm_gate_dbg.is_debug_logs_enabled())
            # Self-proving marker (viz plugin.py bootstrap): vznikne JEN při
            # aktivním DEBUG → potvrzuje gate v session story; jinak nic.
            _nu_rm_logging.get_logger("richmovie.diag").debug(
                "DEBUG_GATE active (server flag debug_logs=true)")
        except Exception:
            pass
        _nu_buffer = _nu_rm_buf.get_buffer()

        def _nu_gate_url():
            try:
                import richmovie_gate
                return richmovie_gate.get_gate_url() or ""
            except Exception:
                return ""

        def _nu_ws_user():
            # 3.5.120: NESMÍ číst přes `_nu_addon` — ten objekt vzniká jednou při
            # startu služby a žije hodiny. Právě takové dlouhoběžící čtení začalo
            # na jednom zařízení vracet prázdno bez chyby, což drainer vyhodnotil
            # jako „nikdo není přihlášen" a 15 h mlčel (incident bandog 27.08.2026).
            # SSOT si bere čerstvou instanci s explicitním ID při každém volání.
            # Import uvnitř: modul je po prvním volání v `sys.modules`, takže to
            # nic nestojí, a callback tím nezávisí na pořadí importů ve službě.
            try:
                import richmovie_settings as _nu_rm_set
                return (_nu_rm_set.get_ws_username() or "").strip()
            except Exception:
                return ""

        _nu_addon_ver = _nu_addon.getAddonInfo("version") or ""
        _nu_platform = ""
        _nu_kodi_ver = ""
        _nu_device_hash = ""
        try:
            import richmovie_gate_transport as _nu_rm_transport
            _nu_platform = _nu_rm_transport.detect_platform()  # SSOT (drive System.OSVersionInfo → "Zaneprazdneno")
            _nu_kodi_ver = xbmc.getInfoLabel("System.BuildVersion") or ""
            _nu_device_hash = _nu_rm_transport.get_device_hash()  # per-device logging (mig 0016)
        except Exception:
            pass

        _nu_log_drainer = _nu_rm_drain.LogDrainer(
            buffer=_nu_buffer,
            gate_url_provider=_nu_gate_url,
            ws_username_provider=_nu_ws_user,
            addon_version=_nu_addon_ver,
            platform=_nu_platform,
            kodi_version=_nu_kodi_ver,
            device_hash=_nu_device_hash,
            monitor=monitor,
        )
        _nu_log_drainer.start()

        # Force first event into buffer (creates SQLite file + sentinel record)
        _nu_boot_log = _nu_rm_logging.get_logger("richmovie.service_nextup")
        _nu_boot_log.info(
            "service_nextup boot",
            extra={"context": {
                "addon_version": _nu_addon_ver,
                "platform": _nu_platform,
                "kodi_version": _nu_kodi_ver,
                "session_id": _nu_rm_logging.get_session_id(),
            }},
        )
        _log("[LogDrain] drainer started in service_nextup")

        # Noc 03.11.2026 (Φ1 + Φ3): prostředí zařízení PŘED otiskem SESSION_ENV (nese os_filter + hdr_types) —
        # systémový filtr obsahu (macOS Čas u obrazovky) a schopnost Dolby Vision. SSOT `richmovie_device_env`.
        try:
            import richmovie_device_env as _nu_denv
            _nu_denv.refresh()
        except Exception as _nu_denv_exc:
            _log(f"device env refresh failed: {_nu_denv_exc!r}", 2)

        # 2026-07-01: health snapshot zařízení (SESSION_ENV) hned po startu služby.
        # Běžící xbmc.service = spolehlivé místo (service_warm nestartuje). Otisk
        # (OS/RAM/disk/SSL/certifi/backlog) dá device-specific bugům okamžitý kontext.
        try:
            import richmovie_diag as _nu_diag
            _nu_diag.session_env(source="service_nextup")
        except Exception as _nu_env_exc:
            _log(f"Diag session_env failed: {_nu_env_exc!r}", 3)
    except Exception as _nu_drain_exc:
        _log(f"LogDrain init failed: {_nu_drain_exc!r}", 3)

    # 2026-05-30 (FU-4 fix): telemetrický hook (RichMoviePlayer) byl historicky
    # připojován v service_warm._start_telemetry_subsystem. ALE service_warm na tomto
    # Kodi buildu NESTARTUJE (viz komentář u drainer init výše + 2026-04-27) → hook se
    # NIKDY nepřipojil → 0 živých watch_events za měsíc+ (jen backfill 2026-04-26).
    # Přesun MINIMÁLNÍHO bootstrapu sem (proven-running xbmc.service), stejně jako u draineru.
    # Doplňuje set_player_context() v plugin._play (3.4.13).
    #
    # POZOR (regrese-prevence): NEvoláme service_warm._start_telemetry_subsystem celé —
    # to startuje NON-DAEMON periodic-flush vlákno (+ backfill), které se při zavření Kodi
    # neukončilo včas → 27s hang + SystemExit (ověřeno 3.4.14). Stačí:
    #   1) get_player() — připojí hook (CAPTURE), idempotentní singleton,
    #   2) flush_in_background() — odešle pending z minulé session (běží na startu, má čas),
    #   3) periodický flush jako DAEMON vlákno (resilience retry + finalizace abandoned
    #      search eventů). DAEMON je ZDE bezpečný (durable buffer + idempotentní Gate
    #      přes client_event_id → kill mid-flush nic neztratí) a zaručí, že NIKDY
    #      neblokuje zavírání Kodi (to byla regrese 3.4.14, kdy non-daemon periodic
    #      vlákno viselo ~27s mid-flush). Synchronizace tak NEzávisí na zavření Kodi.
    try:
        import richmovie_player_hook as _nu_ph
        _nu_ph.get_player()
        _log("telemetry: player hook attached")
        try:
            import richmovie_telemetry as _nu_tel0
            _nu_tel0.flush_in_background()  # odeslat pending z minulé session
            _nu_th0 = __import__("threading").Thread(
                target=_nu_tel0.periodic_flush_loop,
                args=(monitor, 300),
                name="RichMovie-telemetry-periodic",
                daemon=True,
            )
            _nu_th0.start()
        except Exception:
            pass
    except Exception as _nu_tel_exc:
        _log(f"telemetry bootstrap failed: {_nu_tel_exc!r}", 2)

    # 3.5.155: osiřelý priming stop (Kodi spadlo uprostřed přehrávání) → vrátit nastavení
    _restore_primed_streams("service_boot")

    # 3.5.119 (Φ4): adaptivní Kodi filecache podle RAM — JSON-RPC, bez restartu.
    # Jednou za start služby, idempotentní, respektuje uživatelské hodnoty.
    # Lokální volání (žádná síť) → inline; výsledek jde na NAS přes _log modulu.
    try:
        import richmovie_cache_tuning as _nu_ct
        _nu_ct_result = _nu_ct.apply(addon_version=SETTINGS.getAddonInfo("version"))
        _log(f"cache tuning: {_nu_ct_result.get('action')}", context=_nu_ct_result)
    except Exception as _nu_ct_exc:
        _log(f"cache tuning failed: {_nu_ct_exc!r}", xbmc.LOGWARNING)

    # 3.5.130: TMDb warm-up (Trendy/TOP/žánry + enrich) jako vlákno TÉTO služby.
    # Do 3.5.129 žil v `service_warm.py` = druhý xbmc.service, který Kodi nikdy
    # nespustilo (dluh z 3.5.118). Brzdy: 12 h per zařízení, jen ONLINE + identita
    # OK, žádný start při TMDb 429 cooldownu (incident 12.07.2026). Non-daemon,
    # abort-safe (viz richmovie_warm).
    try:
        import richmovie_warm as _nu_warm
        _nu_warm.start_worker(xbmc.Monitor())
        _log("warm-up worker started")
    except Exception as _nu_warm_exc:
        _log(f"warm-up worker failed to start: {_nu_warm_exc!r}", xbmc.LOGWARNING)

    # 3.5.155 (Gate mig 0034): průběžný archiv kodi.log bez dialogu — jen účty se souhlasem
    # (`permissions.kodi_log_archive.enabled`), toto zařízení se může odhlásit v nastavení.
    # Start služby = dokončit session z kodi.old.log (přežije pád i restart), pak kadence
    # 120 s a `kick()` po konci přehrávání. Non-daemon, abort-safe (waitForAbort).
    try:
        import richmovie_log_archive as _nu_archive
        _nu_archive.start_worker(xbmc.Monitor())
        _log("log archive worker started")
    except Exception as _nu_arch_exc:
        _log(f"log archive worker failed to start: {_nu_arch_exc!r}", xbmc.LOGWARNING)

    # Noc 03.11.2026 (4.0.6, Φ4): otevřít RichMovie po zapnutí Kodi (nastavení TOHOTO zařízení). Vlákno čeká nejvýš
    # `WAIT_HOME_S` přes `waitForAbort` (non-daemon, žádné HTTP), rozhoduje čisté `richmovie_autostart.decide` —
    # nikdy nenaviguje po aktualizaci doplňku za běhu Kodi, při přehrávání, s dialogem ani mimo Domů.
    try:
        import richmovie_autostart as _nu_auto
        threading.Thread(target=_nu_auto.run_service, args=(xbmc.Monitor(),),
                         name="RMAutostart", daemon=False).start()
    except Exception as _nu_auto_exc:
        _log(f"autostart worker failed to start: {_nu_auto_exc!r}", xbmc.LOGWARNING)

    # 3.5.130 (Fable audit N2): jednorázový backfill watch_history.json → Gate
    # (3.1.0 polish A1) žil jen v `service_warm.py`, který Kodi nikdy nespustilo →
    # na žádném zařízení neproběhl. Run-once přes settings flag (`richmovie_backfill`,
    # All-or-Nothing), spustí se až po 120 s a jen s identitou/sítí v pořádku.
    def _nu_backfill_later() -> None:
        _mon = xbmc.Monitor()
        if _mon.waitForAbort(120.0):
            return
        try:
            if not _backfill_preconditions_met():
                _log("watch-history backfill: preconditions not met → skipped this session")
                return
            import richmovie_backfill as _nu_bf
            _nu_bf.backfill_if_needed()
        except Exception as _nu_bf_exc:
            _log(f"watch-history backfill failed to start: {_nu_bf_exc!r}", xbmc.LOGWARNING)
    threading.Thread(target=_nu_backfill_later, name="RMWatchHistoryBackfill", daemon=False).start()

    # Observability 2026-07-02 (3.5.84, Fáze 3a): periodický SESSION_ENV
    # re-snapshot. TV běží dny v standby → boot otisk (RAM/disk/certifi/backlog)
    # zastarává a device-specific problém (leak paměti, plnící se disk, rostoucí
    # unsent backlog) není vidět. Interval 6 h = 4 řádky/den/zařízení (INFO tier,
    # 30d retence — zanedbatelný objem), dost hustý na zachycení driftu.
    # Φ8 (2026-07-07): jednorázová rekonstrukce seriálů ztracených z CW
    # (bug 2 mazal seriály měsíce; cw_advance je going-forward). Run-once
    # setting flag; non-daemon (HTTP) s abort checky uvnitř.
    # 3.5.118 (Φ5): backfill se NESTARTUJE z bootu s pevným čekáním, ale z tiku
    # hlavní smyčky, až platí skutečná podmínka (`_backfill_preconditions_met`:
    # identita potvrzená v této session + TMDb klíč). Po neúspěšném běhu (flag
    # nezapsán) se další pokus dělá JEN po změně stavu sítě/identity — ne každých
    # 5 s. Stejný deterministický vzor jako Φ4 v `service_warm`.
    # Držák stavu (tenhle blok je na úrovni modulu, ne ve funkci → `nonlocal`
    # nelze; slovník se mutuje na místě).
    _cw_backfill = {"thread": None, "last_key": None}  # type: dict

    # Φ3b (3.5.134): stav profilu napříč zařízeními — jeden ticker, jedno
    # non-daemon pracovní vlákno: push fronty (60 s při přehrávání, po stopu hned
    # v dalším tiku), pull každých 30 s JEN při nečinnosti; hlavní menu se
    # překreslí jen přes frontu obnov výpisu (D11 → `richmovie_playback_dispatch.request_refresh`, S18).
    import richmovie_state_sync as _state_sync
    _state_ticker = _state_sync.ServiceTicker()

    # Φ3 (13.09.2026): handoff pozastaveného přehrávače — state sync rozhoduje (`plan_handoff`),
    # služba provede (seek + CW zápis pod applying_remote + toast). Aktivně hrající se nedotýká (D2).
    def _handoff_provider():
        try:
            if not player.isPlaying() or not xbmc.getCondVisibility("Player.Paused"):
                return None
            from richmovie_playback_end import player_ctx_key as _hk
            key = _hk()
            if not key:
                return None
            return {"key": key, "position": float(player.getTime() or 0.0)}
        except Exception:
            return None

    def _handoff_executor(plan):
        item = plan.get("item") or {}
        label = _state_sync.safe_label(item.get("updated_device_label")) or "jiné zařízení"
        if plan.get("action") == "seek":
            pos = float(plan.get("position") or 0.0)
            player._cw_min_delta = HANDOFF_SEEK_TOLERANCE_S   # keyframe dosednutí ≠ změna postupu
            player._seek_own(pos)
            player._cached_pos = pos
            player._cached_at = time.monotonic()
            player._cw_last_saved = (str(plan.get("key") or ""), int(pos), "paused")
            _state_sync.apply_handoff_item(item)
            mm, ss = divmod(int(pos), 60)
            hh, mm = divmod(mm, 60)
            t = f"{hh}:{mm:02d}:{ss:02d}" if hh else f"{mm}:{ss:02d}"
            _log(f"HANDOFF_SEEK pos={pos:.0f}s from={label!r} activity={item.get('activity')} version={item.get('version')}",
                 xbmc.LOGINFO)
            # Cizí zařízení právě HRAJE → pozastavený přehrávač ho tiše sleduje (heartbeat 60 s; toast každou
            # minutu by otravoval). Toast jen při skutečném předání (jiné zařízení pauza / stop).
            if _state_sync.normalize_activity(item.get("activity")) != "playing":
                _rm_notif(f"\u23e9 {t} \xb7 {label}", xbmcgui.NOTIFICATION_INFO, 4000, "RichMovie", sound=False)
        elif plan.get("action") == "watched":
            # ✔ + odebrání z Pokračovat se převezme hned (i pro právě hraný klíč) a Stop tohoto
            # přehrávače už `watching` neposílá (Flash A P1: jinak by LWW ✔ přepsalo)
            _state_sync.apply_item_unskipped(item)
            player._cw_suppress_final_key = str(plan.get("key") or "")
            _log(f"HANDOFF_WATCHED from={label!r} key={plan.get('key')}", xbmc.LOGINFO)
            _rm_notif(f"Dokoukáno \xb7 {label}", xbmcgui.NOTIFICATION_INFO, 4000, "RichMovie", sound=False)

    _state_sync.register_handoff(_handoff_provider, _handoff_executor)

    def _state_key() -> tuple:
        ns_since = ident_since = 0.0
        try:
            import richmovie_netstate as _ns
            ns_since = float(_ns.state_since() or 0.0)
        except Exception:
            pass
        try:
            import richmovie_identity_state as _ident
            ident_since = float(_ident.state_since() or 0.0)
        except Exception:
            pass
        return (ns_since, ident_since)

    def _maybe_start_cw_backfill() -> None:
        try:
            from richmovie_settings import get_flag as _gf
            if _gf("cw_backfill_v1"):
                return
            th = _cw_backfill["thread"]
            if th is not None and th.is_alive():
                return
            if not _backfill_preconditions_met():
                return
            key = _state_key()
            if th is not None and key == _cw_backfill["last_key"]:
                return  # už jsme to v tomhle stavu zkusili a selhalo; čekáme na změnu
            _cw_backfill["last_key"] = key
            th = threading.Thread(
                target=_cw_backfill_lost_series, args=(monitor,),
                name="RMCwBackfill", daemon=False)
            _cw_backfill["thread"] = th
            th.start()
        except Exception as _bf_exc:
            _log(f"CW backfill start failed: {_bf_exc!r}", 2)

    # 3.5.125 (Fáze A): obnova stavu Webshare účtu na žádost pluginu — držák
    # vlákna (HTTP → non-daemon, viz feedback_daemon_threads_kodi) + guard proti
    # souběhu dvou žádostí (druhá se prostě neprovede, stav je jeden).
    _account_refresh = {"thread": None}  # type: dict

    def _account_refresh_worker(reason: str) -> None:
        try:
            import richmovie_account_state as _account
            import richmovie_guard as _guard
            from richmovie_webshare import WebshareClient
            token = _guard.claim("account_refresh", 60.0)
            if token is None:
                return
            try:
                previous = _account.load()
                client = WebshareClient(richmovie_settings.get_ws_token())
                state, outcome = _account.refresh_now(client, reason=reason, previous=previous)
                if outcome == _account.OUTCOME_OK and _account.changed(previous, state):
                    # Φ3 (29.09.2026): překreslení JEN přes SSOT bránu D11 (`maybe_refresh_menu`:
                    # hlavní menu, žádný dialog, nečinnost, menu se právě nestaví; jinak čeká).
                    # Dřív přímé `Container.Refresh`, jakmile byl root na obrazovce — i uprostřed
                    # stavění menu nebo nad otevřeným „Kdo se dívá?“ → druhý root, 2× 15 min čekání
                    # a 7 z 12 nedokončených rootů (audit A07 F1).
                    _state_sync.maybe_refresh_menu()
            finally:
                _guard.release("account_refresh", token)
        except Exception as _acc_exc:
            _log(f"account refresh failed: {_acc_exc!r}", xbmc.LOGWARNING)

    _identity_recover = {"last": 0.0}
    _IDENTITY_RECOVER_EVERY_S = 30 * 60

    def _maybe_recover_identity() -> None:
        import richmovie_identity_state as _ident
        if not _ident.is_rejected():
            return
        now = time.time()
        if now - _identity_recover["last"] < _IDENTITY_RECOVER_EVERY_S:
            return
        _identity_recover["last"] = now
        _log("identity REJECTED → asking plugin for silent /auth (RunPlugin)", xbmc.LOGINFO)
        xbmc.executebuiltin('RunPlugin("plugin://plugin.video.richmovie/?action=silent_auth")')

    def _maybe_refresh_account() -> None:
        try:
            import richmovie_account_state as _account
            reason = _account.consume_refresh_request()
            if not reason:
                return
            th = _account_refresh["thread"]
            if th is not None and th.is_alive():
                return
            th = threading.Thread(target=_account_refresh_worker, args=(reason,),
                                  name="RMAccountRefresh", daemon=False)
            _account_refresh["thread"] = th
            th.start()
        except Exception as _acc_exc:
            _log(f"account refresh start failed: {_acc_exc!r}", xbmc.LOGWARNING)

    # Fáze CD (3.5.128): sync katalogu lokálních souborů — držák vlákna (HTTP →
    # non-daemon) + „už běží" guard. Katalog staví Gate; tady se jen stahuje delta.
    _local_sync = {"thread": None}  # type: dict

    def _maybe_sync_local_catalog() -> None:
        try:
            import richmovie_local_catalog as _lc
            reason = _lc.consume_sync_request()
            if not reason:
                return
            th = _local_sync["thread"]
            if th is not None and th.is_alive():
                return
            th = threading.Thread(target=lambda: _lc.sync_now(reason),
                                  name="RMLocalCatalogSync", daemon=False)
            _local_sync["thread"] = th
            th.start()
        except Exception as _lc_exc:
            _log(f"local catalog sync start failed: {_lc_exc!r}", xbmc.LOGWARNING)

    # Φ3 (29.09.2026): instalátor offline kolekcí běží ze SLUŽBY (dřív vlákno invokace rootu, které
    # soupeřilo o CPU se stavěním menu). Podmínka beze změny oproti 3.5.118: identita potvrzená a síť
    # (nikdy v offline-grace — 21 bundle GETů by jen pálilo retry rozpočet). Bundly Gate přestavuje
    # nejvýš 1× za den (noční předehřívání), kontrola po 6 h je tedy zachytí týž den; sám instalátor
    # má guard a v ustáleném stavu skončí bez jediného požadavku.
    _COLLECTIONS_RECHECK_S = 6 * 3600
    _coll_install = {"thread": None, "next": 0.0}  # type: dict

    def _maybe_install_collections() -> None:
        now = time.monotonic()
        if now < _coll_install["next"]:
            return
        th = _coll_install["thread"]
        if th is not None and th.is_alive():
            return
        try:
            import richmovie_identity_state as _ident_ci
            import richmovie_netstate as _ns_ci
            if not _ident_ci.is_authenticated() or _ns_ci.is_offline():
                return
            import richmovie_collections_install as _ci
            _coll_install["next"] = now + _COLLECTIONS_RECHECK_S
            _coll_install["thread"] = _ci.start_background(SETTINGS)
        except Exception as _ci_exc:
            _log(f"collections install start failed: {_ci_exc!r}", xbmc.LOGWARNING)

    # Φ3 (29.09.2026): „Richie aktualizoval DD.MM.RRRR“ — síť jen tady, root čte uložený stav
    # (`richmovie_publish_info`). Kdy je obnova na řadě, spočítá modul (6 h / hned po aktualizaci
    # addonu / hodina po chybě) — služba se neptá častěji, než je potřeba.
    _publish = {"thread": None, "next": 0.0}  # type: dict

    def _maybe_refresh_publish_info() -> None:
        now = time.monotonic()
        if now < _publish["next"]:
            return
        th = _publish["thread"]
        if th is not None and th.is_alive():
            return
        try:
            import richmovie_publish_info as _pub
            ver = SETTINGS.getAddonInfo("version") or ""
            wait_s = _pub.next_due_in(ver)
            if wait_s > 0:
                _publish["next"] = now + wait_s
                return
            _publish["next"] = now + _pub.RETRY_AFTER_FAILURE_S   # další kontrola až po běhu / odkladu
            th = threading.Thread(target=_pub.refresh_if_due, args=(ver,),
                                  name="RMPublishInfo", daemon=False)
            _publish["thread"] = th
            th.start()
        except Exception as _pub_exc:
            _log(f"publish info start failed: {_pub_exc!r}", xbmc.LOGWARNING)

    _ENV_RESNAPSHOT_INTERVAL_S = 6 * 3600
    _env_last_snap = time.time()
    try:
        import richmovie_device_env as _nu_denv_const
        _DENV_REFRESH_S = float(_nu_denv_const.REFRESH_INTERVAL_S)
    except Exception:
        _DENV_REFRESH_S = 600.0
    _denv_last_refresh = time.time()   # první refresh proběhl při bootu (před SESSION_ENV)

    # V9 / cross-check Pro A5 (10.10.2026): relace přehrávání končí se službou — při abortu i při výjimce, která by
    # vyletěla z hlavní smyčky (jinak by hlídací vlákno drželo bránu obnovy výpisu až `SESSION_STALL_MAX_S`).
    try:
        while not monitor.abortRequested():
            if monitor.waitForAbort(_CHECK_EVERY):
                break

            # 4.0.2 (E9): relace přehrávání — obnovit / ukončit PŘED dohnáním fronty obnov výpisu (níže, S18).
            # Tik je zároveň signál živosti claimu relace (`TTL_SESSION_S`).
            _player_now = _rm_dispatch.player_present(on_error=True)   # jednou za tik: relace i fronta obnov (F-7)
            _rm_dispatch.session_note(_player_now)

            _maybe_start_cw_backfill()

            try:
                _state_ticker.tick(bool(player.isPlaying()), paused=bool(xbmc.getCondVisibility("Player.Paused")))
            except Exception as _ss_exc:
                _log(f"state sync tick failed: {_ss_exc!r}", xbmc.LOGWARNING)

            # S18 (4.0.4): JEDNA fronta odložených obnov výpisu — akce na klik, kterou brána odmítla (přehrávač, start,
            # busy dialog), i D11 (změny z jiného zařízení) se dohánějí tady, nezávisle na synchronizaci s Gate (data jsou
            # lokálně). Funkce nikdy nevyhazuje.
            _rm_dispatch.flush_refresh_queue(_player_now)

            # Φ2 network resilience (2026-08-08): automatické zotavení z výpadku sítě.
            # Když je addon v offline režimu, tenhle tik jednou za čas pošle sondu na
            # Gate /health a při úspěchu vrátí stav na ONLINE (+ probudí UI, aby se
            # překreslilo z čerstvých dat). Mimo offline stav se funkce okamžitě vrací,
            # takže do běžného tiku nepřidává prakticky nic.
            #
            # PROČ TADY a ne ve vlastním vlákně: tahle smyčka už existuje, má korektní
            # abort handling a běží v non-daemon service procesu. Další vlákno by
            # znamenalo další objekt k ukončení v pětisekundovém okně, které Kodi dává
            # na shutdown (viz memory feedback_daemon_threads_kodi).
            try:
                import richmovie_netstate as _nu_netstate
                _nu_netstate.recovery_tick()
            except Exception as _ns_exc:
                _log(f"netstate recovery_tick failed: {_ns_exc!r}", 2)

            # 3.5.125 (Fáze A): obnova stavu Webshare účtu (VIP) na žádost pluginu.
            # Plugin při vykreslení root menu stav jen ČTE a když je obnova na řadě
            # (podle STAVU: aktivní 1×/den, končí/propadlé při každém otevření),
            # nastaví Window property. Tahle smyčka ji vyzvedne a provede dotaz
            # tady — mimo UI vlákno, mimo 5s okno invokace pluginu, bez dialogů.
            # Po změně viditelných dat překreslí root menu (jen když je zobrazené).
            _maybe_refresh_account()

            # 3.5.141 (cross-check T2 Pro P4): identita REJECTED (403 s Gate kódem) se dřív zotavila
            # až otevřením hlavního menu — služba (telemetrie, sync stavu) mlčela celý maraton.
            # Jednou za 30 min požádá plugin o tichý `/auth` (RunPlugin = stále volá jen plugin).
            try:
                _maybe_recover_identity()
            except Exception as _ri_exc:
                _log(f"identity recovery trigger failed: {_ri_exc!r}", xbmc.LOGWARNING)

            # Fáze CD (3.5.128): synchronizace katalogu lokálních souborů na žádost
            # pluginu (menu NASu). Stejný vzor: plugin čte lokální kopii a jen žádá,
            # HTTP běží tady. Selhání nechává kopii beze změny (stale-first, R2).
            _maybe_sync_local_catalog()

            # Φ3 (29.09.2026): práce, která dřív stála v cestě hlavního menu
            _maybe_install_collections()
            _maybe_refresh_publish_info()

            # Noc 03.11.2026 (Φ1): vypnutí / zapnutí filtru obsahu se projeví bez restartu RichMovie (10 min).
            if (time.time() - _denv_last_refresh) >= _DENV_REFRESH_S:
                _denv_last_refresh = time.time()
                try:
                    import richmovie_device_env as _nu_denv_tick
                    _nu_denv_tick.refresh()
                except Exception as _nu_denv_tick_exc:
                    _log(f"device env refresh failed: {_nu_denv_tick_exc!r}", 2)

            if (time.time() - _env_last_snap) >= _ENV_RESNAPSHOT_INTERVAL_S:
                _env_last_snap = time.time()
                try:
                    import richmovie_diag as _nu_diag_resnap
                    # force=True: obchází once-guard (per-proces i Window property).
                    _nu_diag_resnap.session_env(source="service_nextup_resnap",
                                                force=True)
                except Exception as _env_re_exc:
                    _log(f"Diag env re-snapshot failed: {_env_re_exc!r}", 2)
    finally:
        # S23 (03.11.2026): PRVNÍ krok ukončení — žádné nové workery stavu a zrušení VŠECH rozběhnutých spojení
        # tohoto interpretu (long-poll `/state/wait`, push/pull, warm-up, archiv logu, telemetrie). Kodi 21 čeká
        # na všechna vlákna bez ohledu na `daemon` a `SystemExit` do blokujícího `recv` nedosáhne; bez tohohle
        # trvalo vypnutí Kodi 5–24 s („script didn't stop in 5 seconds“, Bětčin Mac 03.11.). Fronty jsou
        # trvanlivé na disku → zrušený push nic neztratí (R2: `CancelledError` = přechodná, nic se nepersistuje).
        try:
            _state_ticker.stop()
        except Exception as _st_exc:
            _log(f"state ticker stop failed: {_st_exc!r}", 2)
        try:
            import richmovie_http as _http_stop
            _http_stop.cancel_all("service_stop")
        except Exception as _cx_exc:
            _log(f"http cancel_all failed: {_cx_exc!r}", 2)
        _rm_dispatch.session_stop()

    # Kodi shutdown sequence (5s budget per memory feedback_kodi_shutdown_window):
    # 1. log drainer shutdown_flush (1.5s) — best-effort POST tail to Gate
    # 2. drainer thread .stop(timeout=3.0) — clean join under Kodi 5s force-kill
    if _nu_log_drainer is not None:
        try:
            _nu_log_drainer.shutdown_flush(timeout=1.5)
        except Exception as _exc:
            _log(f"LogDrain shutdown_flush failed: {_exc!r}", 2)
        try:
            _nu_log_drainer.stop(timeout=3.0)
        except Exception as _exc:
            _log(f"LogDrain stop failed: {_exc!r}", 2)

    # 2026-05-30 (FU-4/3.4.16): ŽÁDNÝ blokující shutdown_flush — synchronizace NESMÍ
    # záviset na zavření Kodi (TV jde do standby, Kodi se prakticky nezavírá). Eventy
    # se flushují HNED po každém přehrání (player_hook._finalize → flush_in_background,
    # daemon) + na startu. Cokoli neflushnuté zůstane v durable bufferu (pending_events.json)
    # a odešle se příště (deduplikovaně přes client_event_id). Žádné blokování zavírání.

    # Kodi shutdown: onPlayBackStopped se pri zavreni Kodi nevyvola,
    # ulozime CW pozici explicitne pred ukoncenim sluzby.
    try:
        if player.isPlaying():
            player._save_cw_position()
    except Exception:
        pass

    _log("[TitlePrefs] service_nextup.py STOPPING")
