# -*- coding: utf-8 -*-
"""
richmovie_season — SSOT sezón RichMovie (Vánoce, Velikonoce): kdy období začíná a končí.

Richie 28.11.2026: „Chci, se spouštěl systém o první adventní neděli.“ Do 4.5.5 počítal `plugin._root` vánoční okno
natvrdo 1.12.–8.1. a vedle něj Velikonoce (computus) — teď je tu JEDNO místo, které se ptá „jaká je dnes sezóna?“.

  • Vánoce = od SOBOTY před 1. adventní nedělí (čtvrtá neděle před Božím hodem = neděle v rozmezí 27.11.–3.12.) do 8.1.
    včetně (konec beze změny proti 4.5.5). Richie 28.11.2026: „začneme sobotu před adventní nedělí, to dává ještě větší
    smysl“ — liturgicky advent začíná už v sobotu večer a o víkendu jsou lidé doma; sobota je fáze „zítra 1. adventní neděle“.
  • Velikonoce = Velikonoční neděle − 8 dní … + 1 den (beze změny), jen mimo Vánoce.
  • Hodiny zařízení: box bez RTC před NTP hlásí 1970-01-01 → bez sezóny (`CLOCK_MIN_YEAR`, cross-check Flash P2 14.09.2026).

Modul je ČISTÝ (bez importu Kodi, bez sítě, bez souborů), aby šel celý otestovat v `_tools/net_resilience_sim/`.
Vědomě NENÍ v `rm_core`: změna jádra mění jeho otisk = Gate `--rebuild` ve stejném okně a přepočet Trendů (CLAUDE.md past 4.5.2).
"""
from __future__ import annotations

import datetime
from typing import Any

import richmovie_cz as _cz            # čistý modul (bez Kodi): skloňování „zbývá 5 dní“

#: Rok, od kterého hodinám zařízení věříme (dřívější = nenastavené hodiny boxu bez RTC).
CLOCK_MIN_YEAR = 2024
#: Názvy sezón (`season_at`); "" = žádná.
CHRISTMAS = "christmas"
EASTER = "easter"
#: Poslední den vánočního období v lednu (včetně) — beze změny proti 4.5.5.
CHRISTMAS_LAST_JANUARY_DAY = 8
#: O kolik dní dřív než 1. adventní neděle Vánoce začínají (Richie 28.11.2026: sobota před ní).
CHRISTMAS_STARTS_DAYS_BEFORE_ADVENT = 1
#: Velikonoční okno kolem Velikonoční neděle (včetně) — beze změny proti 4.5.5.
EASTER_DAYS_BEFORE = 8
EASTER_DAYS_AFTER = 1


def _as_date(value: Any) -> Any:
    """`datetime` → `date` (datetime je podtřída date a s date se nedá porovnat); ostatní beze změny."""
    return value.date() if isinstance(value, datetime.datetime) else value


def clock_sane(today: Any) -> bool:
    """Lze datu zařízení věřit? (datum a rok ≥ `CLOCK_MIN_YEAR`). Nikdy nevyhodí."""
    return isinstance(today, datetime.date) and today.year >= CLOCK_MIN_YEAR


def first_advent_sunday(year: int) -> datetime.date:
    """1. adventní neděle roku `year`: poslední neděle nejpozději 3.12. (= neděle 27.11.–3.12., čtvrtá před 25.12.)."""
    dec3 = datetime.date(year, 12, 3)
    return dec3 - datetime.timedelta(days=(dec3.weekday() + 1) % 7)   # weekday: po = 0 … ne = 6


def christmas_start(year: int) -> datetime.date:
    """První den vánočního období roku `year` = sobota před 1. adventní nedělí (`CHRISTMAS_STARTS_DAYS_BEFORE_ADVENT`)."""
    return first_advent_sunday(year) - datetime.timedelta(days=CHRISTMAS_STARTS_DAYS_BEFORE_ADVENT)


def easter_sunday(year: int) -> datetime.date:
    """Velikonoční neděle (gregoriánský kalendář) — algoritmus Meeus / Jones / Butcher."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l_ = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l_) // 451
    month = (h + l_ - 7 * m + 114) // 31
    day = ((h + l_ - 7 * m + 114) % 31) + 1
    return datetime.date(year, month, day)


def is_christmas(today: Any) -> bool:
    """Vánoční období: od soboty před 1. adventní nedělí do 31.12., nebo 1.1.–8.1. Nečitelné / nesmyslné datum = ne."""
    today = _as_date(today)
    if not clock_sane(today):
        return False
    if today.month == 1:
        return today.day <= CHRISTMAS_LAST_JANUARY_DAY
    return today >= christmas_start(today.year)


def is_easter(today: Any) -> bool:
    """Velikonoční období (Velikonoční neděle −8 … +1 den), jen mimo Vánoce. Nečitelné / nesmyslné datum = ne."""
    today = _as_date(today)
    if not clock_sane(today) or is_christmas(today):
        return False
    sunday = easter_sunday(today.year)
    return (sunday - datetime.timedelta(days=EASTER_DAYS_BEFORE)
            <= today <= sunday + datetime.timedelta(days=EASTER_DAYS_AFTER))


def season_at(today: Any) -> str:
    """Sezóna dne `today`: `CHRISTMAS`, `EASTER`, nebo "" (žádná / nečitelné datum). Nikdy nevyhodí."""
    try:
        if is_christmas(today):
            return CHRISTMAS
        if is_easter(today):
            return EASTER
    except (TypeError, ValueError, OverflowError):
        pass
    return ""


# ── 4.5.6 fáze 0b: výsledná sezóna zařízení (náhled, pojistka z Gate, hodiny) ─────────────────────────────────────────
#: Volby nastavení `rm_season_preview` (resources/settings.xml) — „auto“ = podle data.
PREVIEW_AUTO = "auto"
PREVIEW_OFF = "off"
PREVIEWS = (PREVIEW_AUTO, CHRISTMAS, EASTER, PREVIEW_OFF)


def _parse_date(value: Any) -> Any:
    """„2026-11-28“ / date → date; jinak None. Nikdy nevyhodí."""
    if isinstance(value, datetime.datetime):
        return value.date()
    if isinstance(value, datetime.date):
        return value
    try:
        return datetime.date.fromisoformat(str(value).strip()[:10])
    except (TypeError, ValueError):
        return None


def season_date(device_today: Any, server_date: Any = None) -> Any:
    """Datum, podle kterého se sezóna rozhoduje: datum zařízení, pokud jeho hodiny NEZAOSTÁVAJÍ o víc než den za datem
    Gate (`/auth` → `config.server_date`). Box bez RTC před NTP (1970) nebo s vybitou baterií hodin tak dostane datum
    serveru. Hodiny NAPŘED se nepřebíjí: `server_date` je z cache odpovědi `/auth` (lease až 72 h) a může být starší."""
    dev = _parse_date(device_today)
    srv = _parse_date(server_date)
    if srv is not None and clock_sane(srv) and (dev is None or dev < srv - datetime.timedelta(days=1)):
        return srv
    return dev


def effective_season(device_today: Any, *, preview: Any = PREVIEW_AUTO, gate_mode: Any = "", server_date: Any = None) -> str:
    """Výsledná sezóna zařízení: pojistka Gate `config.season_mode = off` vypne vždy (i náhled — je to bezpečnostní
    vypínač); náhled z nastavení (`christmas` / `easter` / `off`) přebije datum; jinak `season_at(season_date(…))`.
    Nikdy nevyhodí."""
    if str(gate_mode or "").strip().lower() == PREVIEW_OFF:
        return ""
    choice = str(preview or PREVIEW_AUTO).strip().lower()
    if choice == PREVIEW_OFF:
        return ""
    if choice in (CHRISTMAS, EASTER):
        return choice
    return season_at(season_date(device_today, server_date))


def display_date(today: Any, season: str) -> Any:
    """Datum, podle kterého se sezóna ZOBRAZUJE: v jejím období `today`; náhled mimo období (`rm_season_preview`) = její
    VÝCHOZÍ den v roce `today` (Vánoce: první den období = sobota před 1. adventní nedělí; Velikonoce: Velikonoční neděle,
    ne první den období −8) — tip týdne, odpočet a nadpis pak ukážou skutečný obsah sezóny místo prázdna. Bez sezóny /
    nesmyslné hodiny = `today` jako `datetime.date` (datetime se zkrátí na datum); nečitelný vstup se vrátí beze změny.
    Text (ISO) nečte — datum Gate převádí `season_date`. Nikdy nevyhodí (cross-check 28.11.2026 A1 N2)."""
    try:
        today = _as_date(today)
        if not clock_sane(today):
            return today
        if season == CHRISTMAS and not is_christmas(today):
            return christmas_start(today.year)
        if season == EASTER and not is_easter(today):
            return easter_sunday(today.year)
    except (TypeError, ValueError, OverflowError, AttributeError):
        pass
    return today


# ── 4.5.6 fáze 0b: fáze vánočního období a texty hlavního menu (JEDNO místo pro všechny vánoční texty) ────────────────
PHASE_ADVENT_EVE = "advent_eve"  # sobota před 1. adventní nedělí (první den období — „zítra 1. adventní neděle“)
PHASE_ADVENT = "advent"          # 1. adventní neděle … 22.12.
PHASE_EVE_TOMORROW = "eve_tomorrow"   # 23.12.
PHASE_EVE = "eve"                # 24.12.
PHASE_FEAST = "feast"            # 25.–26.12.
PHASE_BETWEEN = "between"        # 27.–30.12.
PHASE_SILVESTR = "silvestr"      # 31.12.
PHASE_NEW_YEAR = "new_year"      # 1.1.
PHASE_TO_KINGS = "to_kings"      # 2.–5.1.
PHASE_KINGS = "kings"            # 6.1.
PHASE_AFTER = "after"            # po Třech králích do konce období
KINGS_DAY = 6


def christmas_phase(today: Any) -> str:
    """Fáze vánočního období pro `today`; mimo Vánoce (nebo nečitelné datum) "". Nikdy nevyhodí."""
    try:
        today = _as_date(today)
        if not is_christmas(today):
            return ""
        if today.month == 1:
            if today.day == 1:
                return PHASE_NEW_YEAR
            if today.day < KINGS_DAY:
                return PHASE_TO_KINGS
            if today.day == KINGS_DAY:
                return PHASE_KINGS
            return PHASE_AFTER
        if today.month == 12 and today.day >= 24:
            return {24: PHASE_EVE, 25: PHASE_FEAST, 26: PHASE_FEAST, 31: PHASE_SILVESTR}.get(today.day, PHASE_BETWEEN)
        if today.month == 12 and today.day == 23:
            return PHASE_EVE_TOMORROW
        if today < first_advent_sunday(today.year):
            return PHASE_ADVENT_EVE
        return PHASE_ADVENT
    except (TypeError, ValueError, OverflowError):
        return ""


def advent_number(today: Any) -> int:
    """Kolikátý je adventní týden (1–4) mezi 1. adventní nedělí a Štědrým dnem; jinak 0. Nikdy nevyhodí."""
    try:
        today = _as_date(today)
        if not clock_sane(today) or today.month not in (11, 12):
            return 0
        first = first_advent_sunday(today.year)
        if not first <= today <= datetime.date(today.year, 12, 24):
            return 0
        return min(4, 1 + (today - first).days // 7)
    except (TypeError, ValueError, OverflowError):
        return 0


def _days_until(today: Any, target: Any) -> int:
    return (target - today).days


def menu_label(today: Any, season: str = CHRISTMAS) -> str:
    """Řádek hlavního menu pro sezónu `season` dne `today` (každý den jiný — odpočet, svátky). Mimo vlastní období
    (náhled z nastavení) obecný text. Nikdy nevyhodí, nikdy prázdný řetězec pro známou sezónu. BEZ emoji — písmo Kodi je
    neumí (obdélníky, Richie 28.11.2026); zvýraznění řádku (zlatá barva) přidá až výpis menu."""
    if season == EASTER:
        return "Velikonoční kolekce"
    if season != CHRISTMAS:
        return ""
    try:
        today = _as_date(today)
        phase = christmas_phase(today)
        if phase == PHASE_ADVENT_EVE:
            return "Vánoce · zítra 1. adventní neděle"
        if phase == PHASE_ADVENT:
            n = _days_until(today, datetime.date(today.year, 12, 24))
            return "Vánoce · do Štědrého dne %s %s" % (_cz.remains(n), _cz.days(n))
        if phase == PHASE_EVE_TOMORROW:
            return "Vánoce · zítra je Štědrý den"
        if phase == PHASE_EVE:
            return "Dnes je Štědrý den"
        if phase == PHASE_FEAST:
            return "Veselé Vánoce"
        if phase == PHASE_BETWEEN:
            return "Vánoce · mezi svátky"
        if phase == PHASE_SILVESTR:
            return "Silvestr"
        if phase == PHASE_NEW_YEAR:
            return "Šťastný nový rok"
        if phase == PHASE_TO_KINGS:
            n = _days_until(today, datetime.date(today.year, 1, KINGS_DAY))
            return "Vánoce · do Tří králů %s %s" % (_cz.remains(n), _cz.days(n))
        if phase == PHASE_KINGS:
            return ("Tři králové · poslední den Vánoc" if CHRISTMAS_LAST_JANUARY_DAY == KINGS_DAY
                    else "Tři králové")
        if phase == PHASE_AFTER:
            return ("Vánoce · dnes naposledy" if today.day == CHRISTMAS_LAST_JANUARY_DAY
                    else "Vánoce doznívají")
    except (TypeError, ValueError, OverflowError, AttributeError):
        pass
    return "Vánoce"


def menu_plot(today: Any, season: str = CHRISTMAS) -> str:
    """Popis řádku hlavního menu (info panel / nový vzhled) — co je teď za den a co nabídka nese. Nikdy nevyhodí."""
    if season == EASTER:
        return "Velikonoční pohádky a filmy pro celou rodinu."
    if season != CHRISTMAS:
        return ""
    offer = "Pohádky, rodinné filmy a vánoční díly seriálů na sváteční večery."
    try:
        today = _as_date(today)
        phase = christmas_phase(today)
        if phase in (PHASE_ADVENT, PHASE_EVE_TOMORROW):
            k = advent_number(today)
            when = ("Dnes je %d. adventní neděle." if today.weekday() == 6 else "%d. adventní týden.") % k
            return "%s %s" % (when, offer)
        return {
            PHASE_ADVENT_EVE: "Zítra je 1. adventní neděle — Vánoce v RichMovie začínají. " + offer,
            PHASE_EVE: "Krásný Štědrý večer! Pohádky a sváteční klasika jsou připravené.",
            PHASE_FEAST: "Sváteční dny — " + offer[0].lower() + offer[1:],
            PHASE_BETWEEN: "Mezi svátky je čas na filmy, na které jindy není kdy. " + offer,
            PHASE_SILVESTR: "Poslední večer roku — komedie, pohádky a sváteční klasika.",
            PHASE_NEW_YEAR: "Pohodový první den roku s pohádkou nebo rodinným filmem.",
            PHASE_TO_KINGS: "Vánoce pokračují až do Tří králů. " + offer,
            PHASE_KINGS: "Tři králové. " + offer,
            PHASE_AFTER: "Vánoce doznívají. " + offer,
        }.get(phase, offer)
    except (TypeError, ValueError, OverflowError, AttributeError):
        return offer
