# -*- coding: utf-8 -*-
"""
RichMovie — instalátor offline metadat kurátorovaných kolekcí (3.5.118).

HISTORIE A PROČ JE TO VLASTNÍ MODUL
-----------------------------------
Do 3.5.117 žil instalátor jako `plugin.py::_install_collections_blocking` — ~575
řádků vnořených closures uvnitř 11 400řádkového souboru, spouštěný z `_root()`
PŘED přihlášením k Webshare i PŘED `gate_auth`. Incident gunžik 21.08.2026:
čerstvá instalace bez identity → 2629× HTTP 403 z `/v1/tmdb/*` v jednom běhu,
a protože `_do_task` zapsal každé selhání jako MISS s časovým razítkem a přidal
klíč do `done_keys`, položky zůstaly 7 dní „neexistující". Druhý nález
(cross-check Pro): vlákno startovalo při KAŽDÉM návratu do kořenového menu bez
jakéhokoli guardu a bundle preflight (21 živých GET) běžel i když nebylo co
instalovat.

Extrakce není kosmetika: vnořené closures nejdou importovat do offline harnessu
(`_tools/net_resilience_sim`), takže chování „selhání se neperzistuje" by nešlo
regresně hlídat a vrátilo by se.

KONTRAKT (All-or-Nothing, R3 plánu 3.5.118)
-------------------------------------------
Každá položka práce končí jedním ze tří výsledků:

    HIT     TMDb titul našel               → zapsat meta, klíč = hotovo
    MISS    TMDb AUTORITATIVNĚ nic nemá    → negativní záznam s `_ts`, hotovo
            (200 s prázdným výsledkem, 404)   retry po `NEG_CACHE_TTL_S`
    FAILED  volání selhalo                 → NIC se nezapíše, klíč zůstává
            (transport, 5xx, 429, 401/403)    ve frontě pro příští běh

Po FAILED se smyčka ptá dvou SSOT stavů — `richmovie_identity_state.is_rejected()`
a `richmovie_netstate.allow_request()` — a když některý říká „nemá smysl
pokračovat", run končí s WARN `STOPPED`. Žádné počítadlo „N selhání po sobě":
stop-signál je stav, ne magická konstanta.

POŘADÍ V `run()`
----------------
    plan()  → lokální I/O, žádná síť; prázdná práce = návrat bez jediného requestu
    claim   → `richmovie_guard` (TTL odvozené z velikosti práce a HTTP profilů)
    identita→ `allow_gate_request()` — bez identity / po zamítnutí se nic neposílá
    preflight bundle z Gate (jen když JE co instalovat) → re-plan
    legacy smyčka per položka → průběžné atomické flushe → release

SOUBORY (addon_data)
--------------------
    collections_meta_cache.json  {"_meta": {"version": 5, "tv_id_cache": {...},
                                            "last_done_ts": N, "runs_done": N},
                                  "items": {...}}
    collections_install.json     LEGACY (do 3.5.122) — jen se z něj jednorázově
                                 převezme `tv_id_cache` a pak se smaže.

JEDNA PRAVDA (3.5.123, incident gunžík 30.08.2026)
--------------------------------------------------
Do 3.5.122 rozhodoval `needs()` NEJDŘÍV podle seznamu `completed` v
`collections_install.json` a teprve pak podle metadat. Dva soubory pro jeden fakt:
když zmizel ten levný (110 kB), přeinstalovalo se všech 4 386 položek, přestože
metadata (2,6 MB) byla kompletní — ~37 minut „aktualizace" na notebooku. Od v5 je
zdrojem pravdy VÝHRADNĚ `items` v meta cache: záznam existuje a je HIT → hotovo;
MISS → po TTL znovu; chybí → práce. `completed` byl vždy jen odvozená množina
klíčů `items` (ověřeno u Richieho: 2 995 completed = 3 050 items − 55 artwork).

Zápisy jdou přes `richmovie_atomic` (tmp → fsync → replace): do 3.5.122 chyběl
`fsync`, takže po výpadku napájení mohl být přejmenovaný soubor nulové délky.
Chybějící/poškozený soubor se hlásí NAHLAS (INFO/ERROR + karanténa), ne na DEBUG.

Python 3.8 (Kodi runtime).
"""

from __future__ import annotations

import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import richmovie_atomic as _atomic
import richmovie_collection_keys as _keys  # 4.5.6: SSOT klíčů offline meta (výpis kolekce čte TÉŽ klíče)
import richmovie_guard as _guard
import richmovie_activity as _activity  # Φ4 (29.09.2026): pozadí ustoupí, když uživatel kliká
import richmovie_identity_state as _identity
import richmovie_netstate as _netstate
import richmovie_settings
from richmovie_collections import CollectionsUI
from tmdb_client import (
    BUNDLE_NOT_MODIFIED,
    TMDb,
    TMDbAuthError,
    TMDbError,
    TMDbNotFoundError,
)

try:
    import richmovie_http as _rm_http
except Exception:  # pragma: no cover
    _rm_http = None  # type: ignore

try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.collections_install", "RichMovie/CollectionsInstall")
except Exception:  # pragma: no cover
    def _log(msg, level=xbmc.LOGINFO, *, context=None):
        try:
            xbmc.log("[RichMovie/CollectionsInstall] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Konstanty
# --------------------------------------------------------------------------- #
GUARD_NAME = "collections_install"
STATE_FILENAME = "collections_install.json"
META_FILENAME = "collections_meta_cache.json"

# Verze schématu meta cache.
#   v2 (3.4.6, 2026-05-07): negativní cache s TTL + miss-aware `_needs()`.
#   v3 (3.5.x, 2026-05-30): force-prune missů po Gate year-fixu resolveru.
#   v4 (3.5.118, 2026-08-21): force-prune záznamů s neprázdným `_err` — to jsou
#      selhání zapsaná jako fakt (403 před authem, timeouty), ne skutečné missy.
#      Uzdraví každého uživatele otráveného incidentem gunžik bez mazání souborů.
#   v5 (3.5.123, 2026-08-30): JEDNA PRAVDA — `tv_id_cache` se stěhuje do `_meta`,
#      `collections_install.json` (seznam `completed`) přestává existovat. Žádný
#      pruning; migrace jen převezme `tv_id_cache` z legacy souboru a smaže ho.
META_VERSION_CURRENT = 5

# Práh, od kterého se plán hlásí jako PLNÁ reinstalace (WARNING s diagnostikou
# souboru). Zařízení, které už někdy dokončilo běh, nemá důvod plánovat víc než
# zlomek katalogu — když ano, něco se stalo se souborem, a to se má vědět.
FULL_REINSTALL_RATIO = 0.5

# Negativní cache: MISS (TMDb autoritativně nic nemá) se zkusí znovu po tomhle
# okně. Standardní vzor (DNS, HTTP) — samoléčení bez mlácení do TMDb kvůli
# titulům, které tam opravdu nejsou.
NEG_CACHE_TTL_S = 7 * 24 * 3600

# Pravidla, kterými se položky bundlu Gate zapisují do meta (`_apply_bundle_item`). ETag bundlu potvrzuje jen „položky
# tohoto bundlu prošly pravidly verze N“ — změna pravidel = ETagy neplatí a bundly se jednou stáhnou celé.
#   1 (Φ7, 29.09.2026): jakýkoli existující záznam se přeskočí.
#   2 (4.5.6, 28.11.2026): vlastní „nenalezeno“ (`is_miss`) údaje z Gate přepíší (F52 V1). Bez nové verze by zařízení,
#      které nový bundle stáhlo ještě starým doplňkem (přeskočilo „nenalezeno“, uložilo ETag), dostalo 304 a Dalskabáty
#      by zůstaly „nenalezeno“, dokud se bundle na Gate nezmění (cross-check 28.11.2026 A3 N4).
BUNDLE_APPLY_RULES = 2

# Průběžný flush stavu po N zpracovaných jednotkách (ochrana proti ztrátě práce
# při Kodi kill). Hodnota z 3.5.117 beze změny.
SAVE_EVERY_UNITS = 30

OUTCOME_HIT = "hit"
OUTCOME_MISS = "miss"
OUTCOME_FAILED = "failed"


class InstallStopped(Exception):
    """Run ukončen stavem (identita zamítnuta / síť offline) — ne chybou."""


# --------------------------------------------------------------------------- #
# JSON I/O — atomické
# --------------------------------------------------------------------------- #
def _json_load(path: Path, default: Any) -> Any:
    """Tenký wrapper nad `richmovie_atomic.read_json` (kvůli volajícím a harnessu,
    kteří chtějí jen hodnotu). Kdo potřebuje i STAV souboru, volá `_json_load_state`."""
    value, _state = _json_load_state(path, default)
    return value


def _json_load_state(path: Path, default: Any) -> Tuple[Any, str]:
    """(hodnota, stav) — stav z `richmovie_atomic` (OK / NO_FILE / EMPTY / CORRUPT /
    UNREADABLE). Poškozený soubor jde do karantény a loguje se ERROR; chybějící
    INFO s počtem položek ve složce (čerstvá instalace vs. ztráta jednoho souboru).
    Do 3.5.122 tohle bylo `DEBUG`, resp. nic — a další zápis důkaz přepsal."""
    return _atomic.read_json(str(path), default, name=path.name, expected_type=dict)


def file_fingerprint(path: Path) -> Optional[Tuple[int, int]]:
    """(mtime_ns, velikost) souboru; chybějící / nečitelný = None. Vzor otisku cache čtené víc procesy (past 4.0.0)."""
    try:
        st = path.stat()
        return int(st.st_mtime_ns), int(st.st_size)
    except OSError:
        return None


def _json_save(path: Path, obj: Any) -> bool:
    """Trvanlivý atomický zápis přes SSOT (`richmovie_atomic`): tmp → fsync →
    replace. Kodi má 5s okno na shutdown a vlákno může být killnuto uprostřed
    zápisu (3.4.6 incident); bez fsync navíc výpadek napájení nechal soubor
    prázdný (incident gunžík 30.08.2026)."""
    ok = _atomic.write_json(str(path), obj, indent=2)
    if not ok:
        _log(f"[CollectionsInstall] Save failed: {path.name}", xbmc.LOGWARNING,
             context={"path": str(path)})
    return ok


# --------------------------------------------------------------------------- #
# Klasifikace záznamů (klíče skládá JEN `richmovie_collection_keys`; mrtvý `canon_key` odstraněn — audit Fable F54 P)
# --------------------------------------------------------------------------- #
def is_miss(entry: Any) -> bool:
    """Záznam bez použitelných TMDb dat (= negativní cache, nebo poškozený)."""
    if not isinstance(entry, dict):
        return True
    kind = (entry.get("kind") or "").strip().lower()
    if kind in ("movie", "tv"):
        return not (entry.get("id") or 0)
    if kind == "ep":
        return not ((entry.get("name") or "").strip() or (entry.get("overview") or "").strip())
    if kind == "collection":
        return not (entry.get("poster_path") or "").strip()
    return True


def is_recorded_failure(entry: Any) -> bool:
    """Záznam, který vznikl ze SELHÁNÍ volání (3.5.117 a starší: `_err` != "").
    Od v4 se takové záznamy nezapisují; migrace je jednorázově odstraní.

    Defenzivně JEN pro missy: HIT s neprázdným `_err` by 3.5.117 vyrobit neměl
    (`_err` se plnil jen v `except`, kdy `id` zůstalo 0), ale kdyby se nějaký
    objevil, nesou platná data a mazat je by byla ztráta (cross-check Pro Q5)."""
    return (isinstance(entry, dict) and is_miss(entry)
            and bool((entry.get("_err") or "").strip()))


# --------------------------------------------------------------------------- #
# Plán
# --------------------------------------------------------------------------- #
class InstallPlan:
    """Výsledek `plan()`: načtený stav + seznam práce. Čistě lokální data."""

    def __init__(self, state_path: Path, meta_path: Path) -> None:
        # `state_path` = legacy `collections_install.json`; od v5 se z něj jen
        # jednorázově přebírá `tv_id_cache` (viz `_migrate_meta`) a pak se maže.
        self.state_path = state_path
        self.meta_path = meta_path
        self.meta: Dict[str, Any] = {"_meta": {"version": META_VERSION_CURRENT}, "items": {}}
        self.meta_file_state: str = _atomic.STATE_NO_FILE
        self.work: List[Dict[str, Any]] = []
        self.collections: List[Tuple[str, Dict[str, Any]]] = []
        self.pruned_on_migration = 0
        #: Otisk meta souboru v okamžiku načtení (`file_fingerprint`) — běh pod zámkem pozná, že soubor mezitím
        #: zapsal jiný proces, a plán načte znovu (jinak by `persist()` přepsal jeho práci starým snímkem).
        self.loaded_fingerprint: Optional[Tuple[int, int]] = None
        #: Klíč meta → pevné `tmdb_id` z katalogu doplňku (`_apply_pins`); pevné id má přednost před hledáním podle názvu.
        self.pinned: Dict[str, int] = {}

    def changed_on_disk(self) -> bool:
        """Zapsal meta soubor od načtení někdo jiný? (Vlastní `persist()` otisk obnoví.)"""
        return file_fingerprint(self.meta_path) != self.loaded_fingerprint

    @property
    def meta_items(self) -> Dict[str, Any]:
        return self.meta["items"]

    @property
    def tv_id_cache(self) -> Dict[str, int]:
        """Název seriálu → TMDb id. Žije v `_meta`, ne ve zvláštním souboru —
        jeden soubor, jedna pravda, jeden zápis."""
        cache = self.meta["_meta"].get("tv_id_cache")
        if not isinstance(cache, dict):
            cache = {}
            self.meta["_meta"]["tv_id_cache"] = cache
        return cache

    @property
    def bundle_etags(self) -> Dict[str, str]:
        """Slug → ETag bundlu Gate, ze kterého už položky v TOMTO souboru vznikly (Φ7). Žije v `_meta` téhož
        souboru jako položky → zapisuje se spolu s nimi jedním atomickým `persist()`, nikdy se nerozejdou.
        ETagy uložené za jiných pravidel aplikace (`BUNDLE_APPLY_RULES`) neplatí — vrátí se prázdné a s novou verzí
        pravidel se zapíšou až po stažení (týmž `persist()`)."""
        meta = self.meta["_meta"]
        tags = meta.get("bundle_etags")
        if not isinstance(tags, dict) or meta.get("bundle_rules") != BUNDLE_APPLY_RULES:
            tags = {}
            meta["bundle_etags"] = tags
            meta["bundle_rules"] = BUNDLE_APPLY_RULES
        return tags

    def has_title_misses(self) -> bool:
        """Je v meta aspoň jeden film / seriál „nenalezeno“ (`is_miss`)? Údaje pro něj může mít Gate (náhradní dotazy,
        pevné `tmdb_id` z katalogu — Richie 28.11.2026 Dalskabáty)."""
        return any(isinstance(e, dict) and str(e.get("kind") or "").strip().lower() in ("movie", "tv") and is_miss(e)
                   for e in self.meta_items.values())

    @property
    def total_units(self) -> int:
        return len(self.work)

    @property
    def runs_done(self) -> int:
        try:
            return int(self.meta["_meta"].get("runs_done") or 0)
        except Exception:
            return 0

    def needs(self, key: str) -> bool:
        """Potřebuje položka (znovu) zpracovat? Rozhoduje VÝHRADNĚ meta záznam:
          1. záznam chybí / poškozený → True
          2. HIT → False (trvale)
          3. MISS → jen po uplynutí NEG_CACHE_TTL_S od `_ts`
        Do 3.5.122 se nejdřív kontroloval seznam `completed` ve druhém souboru —
        jeho ztráta znamenala plnou reinstalaci i s kompletními metadaty.
        """
        entry = self.meta_items.get(key)
        if not isinstance(entry, dict):
            return True
        if not is_miss(entry):
            return False
        try:
            age = int(time.time()) - int(entry.get("_ts") or 0)
        except Exception:
            age = NEG_CACHE_TTL_S + 1
        return age > NEG_CACHE_TTL_S

    def mark_run_done(self) -> None:
        """Marker dokončeného běhu — až po absolutním úspěchu (volá `run()`
        jen když nebyl stop). Slouží diagnostice plné reinstalace v `plan()`."""
        self.meta["_meta"]["last_done_ts"] = int(time.time())
        self.meta["_meta"]["runs_done"] = self.runs_done + 1

    def persist(self) -> bool:
        ok = _json_save(self.meta_path, self.meta)
        if ok:
            self.loaded_fingerprint = file_fingerprint(self.meta_path)
        return ok


def _iter_collection_items(meta_src: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
    """Položky kolekce z `items` (flat) i `tree` (strom). Beze změny."""
    if isinstance(meta_src.get("items"), list):
        for it in meta_src.get("items") or []:
            if isinstance(it, dict):
                yield it

    def _walk(node: Dict[str, Any]):
        if isinstance(node.get("items"), list):
            for it in node.get("items") or []:
                if isinstance(it, dict):
                    yield it
        if isinstance(node.get("children"), list):
            for ch in node.get("children") or []:
                if isinstance(ch, dict):
                    yield from _walk(ch)

    if isinstance(meta_src.get("tree"), list):
        for top in meta_src.get("tree") or []:
            if isinstance(top, dict):
                yield from _walk(top)


def _migrate_meta(plan: InstallPlan) -> None:
    """Jednorázové migrace schématu meta cache (ordered, každá nejvýš jednou).
    Po migraci se stav hned persistuje — migrace nesmí záviset na tom, jestli
    run doběhne."""
    try:
        version = int(plan.meta["_meta"].get("version") or 1)
    except Exception:
        version = 1
    if version >= META_VERSION_CURRENT:
        return

    items = plan.meta_items
    pruned = 0
    if version < 3:
        # v1/v2 → v3: prune všech missů (Gate year-fix, poisoned install 2026-04-27)
        for k in list(items.keys()):
            if is_miss(items.get(k)):
                items.pop(k, None)
                pruned += 1
    if version < 4:
        # v3 → v4: prune záznamů vzniklých ze selhání volání (incident gunžik)
        for k in list(items.keys()):
            if is_recorded_failure(items.get(k)):
                items.pop(k, None)
                pruned += 1
    imported_tv_ids = 0
    if version < 5:
        # v4 → v5: jedna pravda. Z legacy `collections_install.json` se převezme
        # JEN `tv_id_cache` (ušetří hledání seriálů); seznam `completed` se
        # zahazuje — byl vždy jen odvozený z `items`. Soubor se po převzetí smaže,
        # aby nikdo (ani starší kód) nemohl znovu rozhodovat podle něj.
        legacy, legacy_state = _json_load_state(plan.state_path, {})
        if isinstance(legacy, dict) and isinstance(legacy.get("tv_id_cache"), dict):
            for name, tv_id in legacy["tv_id_cache"].items():
                try:
                    if name and int(tv_id):
                        plan.tv_id_cache.setdefault(str(name), int(tv_id))
                        imported_tv_ids += 1
                except Exception:
                    continue
        try:
            if plan.state_path.exists():
                plan.state_path.unlink()
        except Exception as exc:
            _log(f"[CollectionsInstall] legacy state unlink failed: {exc!r}", xbmc.LOGWARNING)
        _log(f"[CollectionsInstall] META_MIGRATION legacy state={legacy_state} "
             f"tv_ids_imported={imported_tv_ids}", xbmc.LOGINFO,
             context={"legacy_state": legacy_state, "tv_ids_imported": imported_tv_ids})

    plan.meta["_meta"]["version"] = META_VERSION_CURRENT
    plan.pruned_on_migration = pruned
    _log(
        f"[CollectionsInstall] META_MIGRATION v{version}→v{META_VERSION_CURRENT}: "
        f"pruned {pruned} entries (one-shot; re-fetched by next run)",
        xbmc.LOGINFO,
        context={"from": version, "to": META_VERSION_CURRENT, "pruned": pruned,
                 "tv_ids_imported": imported_tv_ids},
    )
    plan.persist()


def plan(addon: Optional[xbmcaddon.Addon] = None,
         profile_dir: Optional[Path] = None,
         collections: Optional[Iterable[Tuple[str, Dict[str, Any]]]] = None) -> InstallPlan:
    """Načte stav, provede migrace a spočítá práci. ŽÁDNÁ síť.

    Args:
        collections: Injekce zdroje kolekcí (harness). None = `CollectionsUI._iter_collections`.
    """
    addon = addon or xbmcaddon.Addon()
    profile_dir = profile_dir or Path(xbmcvfs.translatePath(
        f"special://profile/addon_data/{addon.getAddonInfo('id')}"))
    p = InstallPlan(profile_dir / STATE_FILENAME, profile_dir / META_FILENAME)

    p.loaded_fingerprint = file_fingerprint(p.meta_path)       # PŘED čtením: zápis mezi otiskem a čtením = jen plán navíc
    meta, meta_state = _json_load_state(
        p.meta_path, {"_meta": {"version": META_VERSION_CURRENT}, "items": {}})
    p.meta_file_state = meta_state
    if not isinstance(meta, dict):
        meta = {"_meta": {"version": META_VERSION_CURRENT}, "items": {}}
    if not isinstance(meta.get("_meta"), dict):
        meta["_meta"] = {"version": 1}
    if not isinstance(meta.get("items"), dict):
        meta["items"] = {}
    meta["_meta"].setdefault("version", 1)
    p.meta = meta

    _migrate_meta(p)

    p.collections = [(vfs, src) for vfs, src in (collections if collections is not None
                                                 else CollectionsUI._iter_collections(addon))
                     if isinstance(src, dict)]
    _apply_pins(p)
    p.work = _compute_work(p)
    _warn_if_full_reinstall(p)
    return p


def pin_id(value: Any) -> int:
    """Pevné `tmdb_id`: kladné CELÉ číslo (int, celé float z JSONu, číslice v textu); bool, desetinné číslo („19384.9“
    se neořízne na jiné id — cross-check OpenAI 28.11.2026), nula, nesmysl = 0."""
    if isinstance(value, bool):
        return 0
    if isinstance(value, int):
        n = value
    elif isinstance(value, float):
        n = int(value) if value.is_integer() else 0
    elif isinstance(value, str) and value.strip().isdigit():
        n = int(value.strip())
    else:
        return 0
    return n if n > 0 else 0


def _apply_pins(p: InstallPlan) -> int:
    """Pevné `tmdb_id` z katalogu má přednost před vlastním hledáním doplňku podle názvu (28.11.2026: Comeback —
    zařízení si v dubnu hledáním přiřadilo americký „Návrat na výsluní“ (id 1999) místo českého (19384), vánoční díl
    stahovalo z cizího seriálu a odkaz vedl jinam; bundle Gate platný záznam nepřepíše). Záznam s jiným id se zahodí
    (příští práce ho doplní z bundlu Gate nebo z detailu TMDb podle pevného id); u seriálu i jeho díly (byly z jiného
    seriálu) a `tv_id_cache` = pevné id. Vrací počet opravených záznamů. Jen v paměti — zapíše je až běh pod zámkem."""
    pinned: Dict[str, int] = {}
    tv_names: Dict[str, str] = {}                    # klíč seriálu → jeho název (adresa `tv_id_cache` a dílů)
    conflicts = set()
    for _vfs, src in p.collections:
        for it in _iter_collection_items(src):
            pin, key = pin_id(it.get("tmdb_id")), _keys.item_key(it)
            if not (pin and key):
                continue
            if pinned.get(key, pin) != pin:
                conflicts.add(key)                   # dvě různá pevná id pro týž titul = katalog si odporuje
            pinned[key] = pin
            if _keys.item_kind(it) == "tv":
                tv_names[key] = _keys.item_title(it)
    for key in conflicts:
        pinned.pop(key, None)                        # rozpor neřeší doplněk tipem — platí, jak to bylo
        _log(f"[CollectionsInstall] COLLECTION_PIN_CONFLICT {key}", xbmc.LOGWARNING, context={"key": key})
    p.pinned = pinned
    fixed = 0
    for key, pin in pinned.items():
        entry = p.meta_items.get(key)
        wrong_entry = isinstance(entry, dict) and not is_miss(entry) and pin_id(entry.get("id")) != pin
        name = tv_names.get(key)
        if name is not None:
            cached = pin_id(p.tv_id_cache.get(name))
            if wrong_entry or (cached and cached != pin):
                # díly se stahovaly přes id z `tv_id_cache` → byly z jiného seriálu (i když záznam seriálu sám chybí)
                prefix = _keys.ep_prefix(name)
                for ep_key in [k for k in p.meta_items if k.startswith(prefix)]:
                    p.meta_items.pop(ep_key, None)
            p.tv_id_cache[name] = pin
        if wrong_entry:
            p.meta_items.pop(key, None)
            fixed += 1
            _log(f"[CollectionsInstall] COLLECTION_PIN_FIX {key} id={entry.get('id')} → {pin}", xbmc.LOGINFO,
                 context={"key": key, "was": entry.get("id"), "pin": pin})
    return fixed


def _warn_if_full_reinstall(p: InstallPlan) -> None:
    """Plný plán na zařízení, které už kdy dokončilo běh, není normální — někdo
    přišel o soubor. Do 3.5.122 se to nedalo poznat od čerstvé instalace (gunžík
    30.08.2026: 4 386 jednotek, důvod navždy neznámý). Stav souboru z
    `richmovie_atomic` říká, JAK se to stalo: NO_FILE = smazán zvenčí, EMPTY =
    pád po rename, CORRUPT = poškozený obsah (v karanténě), OK = soubor je, ale
    prázdný `items` (= čerstvá instalace nebo výmaz obsahu)."""
    try:
        catalog = 0
        for _vfs, src in p.collections:
            for it in _iter_collection_items(src):
                catalog += 1 + len(it.get("episodes") or [])
        if catalog <= 0 or p.total_units < catalog * FULL_REINSTALL_RATIO:
            return
        if p.runs_done <= 0 and p.meta_file_state == _atomic.STATE_NO_FILE and not p.meta_items:
            # Nikdy nedokončeno + žádný soubor = čerstvá instalace. Legitimní.
            _log(f"[CollectionsInstall] FIRST_INSTALL units={p.total_units} catalog={catalog}",
                 xbmc.LOGINFO, context={"units": p.total_units, "catalog": catalog})
            return
        _log(
            f"[CollectionsInstall] COLLECTIONS_FULL_REINSTALL reason={p.meta_file_state} "
            f"units={p.total_units} catalog={catalog} items_in_meta={len(p.meta_items)} "
            f"runs_done={p.runs_done}",
            xbmc.LOGWARNING,
            context={"reason": p.meta_file_state, "units": p.total_units,
                     "catalog": catalog, "items_in_meta": len(p.meta_items),
                     "runs_done": p.runs_done,
                     "last_done_ts": p.meta["_meta"].get("last_done_ts")},
        )
    except Exception as exc:  # diagnostika nesmí shodit plán
        _log(f"[CollectionsInstall] full-reinstall check failed: {exc!r}", xbmc.LOGDEBUG)


def _compute_work(p: InstallPlan) -> List[Dict[str, Any]]:
    raw_movies: List[Dict[str, Any]] = []
    raw_tvs: List[Dict[str, Any]] = []
    raw_eps: List[Dict[str, Any]] = []
    for _vfs, meta_src in p.collections:
        for it in _iter_collection_items(meta_src):
            typ = (it.get("type") or it.get("kind") or "movie").strip().lower()
            if typ == "movie":
                title = (it.get("title") or it.get("name") or "").strip()
                year = it.get("year") or it.get("release_year") or None
                if not title:
                    continue
                key = _keys.movie_key(title, year)
                if p.needs(key):
                    raw_movies.append({"kind": "movie", "title": title, "year": year, "key": key,
                                       "pin": p.pinned.get(key, 0)})
            elif typ == "tv":
                name = (it.get("title") or it.get("name") or "").strip()
                if not name:
                    continue
                key_tv = _keys.tv_key(name)
                if p.needs(key_tv):
                    raw_tvs.append({"kind": "tv", "name": name, "key": key_tv, "pin": p.pinned.get(key_tv, 0)})
                for ep in (it.get("episodes") or []):
                    s_raw = ep.get("season") or ep.get("s") or ep.get("season_number")
                    e_raw = ep.get("episode") or ep.get("e") or ep.get("episode_number")
                    try:
                        s_no, e_no = int(s_raw), int(e_raw)
                    except Exception:
                        continue
                    key_ep = _keys.ep_key(name, s_no, e_no)
                    if p.needs(key_ep):
                        raw_eps.append({"kind": "ep", "tv": name, "s": s_no, "e": e_no, "key": key_ep})

    season_groups: Dict[str, Dict[str, Any]] = {}
    for ep in raw_eps:
        k = f"{ep['tv']}|{int(ep['s'])}"
        if k not in season_groups:
            season_groups[k] = {"kind": "season", "tv": ep["tv"], "s": int(ep["s"]), "keys": []}
        season_groups[k]["keys"].append(ep["key"])

    work: List[Dict[str, Any]] = []
    work.extend(raw_movies)
    work.extend(raw_tvs)
    work.extend(season_groups.values())
    return work


# --------------------------------------------------------------------------- #
# Gate bundle preflight
# --------------------------------------------------------------------------- #
def _apply_bundle_item(p: InstallPlan, item: Dict[str, Any]) -> int:
    """Položka bundlu → záznam meta. 1 = použito, 0 = přeskočeno. Záznam s TMDb daty se nepřepisuje, vlastní
    „nenalezeno“ (`is_miss`) ano (4.5.6, audit Fable F52 V1)."""
    try:
        kind = (item.get("kind") or "").strip().lower()
        tmdb_id = item.get("tmdb_id")
        source_title = (item.get("source_title") or "").strip()
        source_year = item.get("source_year")
        payload = item.get("payload")
        if (not kind or kind not in ("movie", "tv") or not tmdb_id
                or not source_title or not isinstance(payload, dict)):
            return 0
        key = _keys.movie_key(source_title, source_year) if kind == "movie" else _keys.tv_key(source_title)
        # Položka, kterou zařízení UŽ zná s TMDb daty, se nepřepisuje. Vlastní záznam „nenalezeno“ (`is_miss` — doplněk hledal
        # celým názvem, který TMDb nenajde) ale údaje z Gate přepíší: Gate hledá i náhradními dotazy a pevným `tmdb_id`
        # z katalogu (audit Fable F52 V1, Richie 28.11.2026 „Dalskabáty“ — bez toho by oprava nedošla na stávající zařízení).
        # Na zařízení dorazí při nejbližším běhu instalátoru (nejpozději po `NEG_CACHE_TTL_S` od záznamu „nenalezeno“).
        if isinstance(p.meta_items.get(key), dict) and not is_miss(p.meta_items.get(key)):
            return 0

        entry: Dict[str, Any] = {
            "kind": kind,
            "id": int(tmdb_id),
            "rating": round(float(payload.get("vote_average") or 0), 1),
            "votes": int(payload.get("vote_count") or 0),
            "overview": payload.get("overview") or "",
            "poster_path": payload.get("poster_path") or "",
            "backdrop_path": payload.get("backdrop_path") or "",
            "_ts": int(time.time()),
            "_err": "",
        }
        if kind == "movie":
            entry["title"] = payload.get("title") or source_title
            try:
                entry["year"] = int((payload.get("release_date") or "0000")[:4] or 0)
            except Exception:
                entry["year"] = int(source_year) if isinstance(source_year, (int, float)) else 0
            if not entry["year"] and isinstance(source_year, (int, float)):
                entry["year"] = int(source_year)
        else:
            entry["title"] = payload.get("name") or source_title
            entry["name"] = payload.get("name") or source_title
            try:
                entry["year"] = int((payload.get("first_air_date") or "0000")[:4] or 0)
            except Exception:
                entry["year"] = 0
            try:
                p.tv_id_cache[source_title] = int(tmdb_id)
            except Exception:
                pass
        p.meta_items[key] = entry
        return 1
    except Exception as exc:
        _log(f"[CollectionsInstall] Bundle item apply failed: {exc}", xbmc.LOGDEBUG)
        return 0


def _apply_bundles_from_gate(p: InstallPlan, tmdb: TMDb, stats: Optional[Dict[str, int]] = None) -> int:
    """Prewarmed bundly z Gate pro všechny slugy. Nikdy nevyhazuje; selhání
    Gate = 0 = plný legacy fallback. Když JE co instalovat (viz run()), a v ustáleném stavu kvůli „nenalezeno“
    (`_heal_misses_from_bundles`). `stats["unanswered"]` = kolik bundlů Gate nepotvrdil (chyba / neplatná odpověď).

    Φ7 (29.09.2026, audit A09 N6): bundle, který se od minulého použití nezměnil (ETag → 304), se
    nestahuje — dřív šlo všech 21 bundlů (desítky MB) při každém běhu, přestože `bundle_hits=0`.
    Nezměněný bundle by stejné `meta_items` nedoplnil (položka, která už v souboru je, se přeskakuje)."""
    applied = 0
    unchanged = 0
    if stats is not None:
        stats.setdefault("unanswered", 0)
    etags = p.bundle_etags
    for _vfs, meta_src in p.collections:
        slug = (meta_src.get("id") or "").strip()
        if not slug:
            continue
        try:
            bundle = tmdb.get_collection_bundle(slug, lang="cs-CZ", etag=etags.get(slug))
        except Exception:
            bundle = None
        if isinstance(bundle, dict) and bundle.get("status") == BUNDLE_NOT_MODIFIED:
            unchanged += 1
            continue
        if not isinstance(bundle, dict) or bundle.get("status") != "ok":
            if stats is not None:
                stats["unanswered"] += 1
            continue
        if stats is not None:
            stats["fetched"] = stats.get("fetched", 0) + 1
        for it in bundle.get("items") or []:
            if isinstance(it, dict):
                applied += _apply_bundle_item(p, it)
        for group in bundle.get("tree") or []:
            if not isinstance(group, dict):
                continue
            for it in group.get("items") or []:
                if isinstance(it, dict):
                    applied += _apply_bundle_item(p, it)
        # ETag až PO aplikaci položek (cross-check Pro B6): výjimka výše = ETag se nezmění a bundle se stáhne znovu;
        # na disk ho zapíše až `persist()` spolu s položkami (All-or-Nothing)
        if bundle.get("_etag"):
            etags[slug] = str(bundle["_etag"])
        else:
            etags.pop(slug, None)
    if unchanged:
        _log(f"[CollectionsInstall] Gate bundles unchanged (304): {unchanged}", xbmc.LOGINFO)
    return applied


#: Klíč `_meta`: místní den poslední kontroly bundlů kvůli položkám „nenalezeno“ (`_heal_misses_from_bundles`).
HEAL_DAY_KEY = "bundle_heal_day"


def _heal_misses_from_bundles(p: InstallPlan, tmdb: TMDb, today: str) -> Tuple[int, bool]:
    """Položky „nenalezeno“ se hojí z bundlů Gate i v ustáleném stavu (nic dalšího k práci), NEJVÝŠ jednou za místní den
    (Gate přestavuje bundly jednou za noc) a jen když zařízení nějaké „nenalezeno“ má. Bundle beze změny = 304 (ETag),
    nic se nepřenáší. Vrací (použité položky, uložit = položky, značka dne nebo ETagy staženého bundlu se změnily).
    Značka dne se zapíše JEN když Gate potvrdil VŠECHNY bundly (ok / 304) — výpadek Gate nesmí odložit hojení o den
    (R2: selhání se neperzistuje; audit Fable F53 V1); další pokus tak přijde s příštím během služby (6 h).
    Proč (Richie 28.11.2026: „a pořád tam vidím Dalskabáty nenalezeno“): bez toho se oprava na Gate dostala na zařízení až
    po `NEG_CACHE_TTL_S` (7 dní) od vlastního „nenalezeno“ — ustálený běh skončil bez jediného dotazu."""
    if p.meta["_meta"].get(HEAL_DAY_KEY) == today or not p.has_title_misses():
        return 0, False
    stats: Dict[str, int] = {}
    hits = _apply_bundles_from_gate(p, tmdb, stats)
    answered = not stats.get("unanswered")
    if answered:
        p.meta["_meta"][HEAL_DAY_KEY] = today
    if hits:
        _log(f"[CollectionsInstall] Gate bundles healed {hits} not-found items", xbmc.LOGINFO)
    # Uložit i když Gate jeden bundle nepotvrdil, ale jiné se stáhly: jejich nové ETagy (a verze pravidel) jinak zůstanou
    # jen v paměti a každý další běh by bundly stahoval celé znovu (audit Fable F54 V1)
    return hits, bool(hits) or answered or bool(stats.get("fetched"))


def _fetch_collection_artwork(p: InstallPlan, tmdb: TMDb) -> int:
    """Artwork ság (tree kolekce) z TMDb Collection API. Jen pro `coll|id`, které
    ještě poster nemají → v ustáleném stavu 0 requestů. Selhání se NEZAPISUJE."""
    count = 0
    for _vfs, meta_src in p.collections:
        if not isinstance(meta_src.get("tree"), list):
            continue
        for coll_node in meta_src["tree"]:
            if not isinstance(coll_node, dict):
                continue
            coll_id = coll_node.get("tmdb_collection_id")
            if not coll_id:
                continue
            cache_key = _keys.coll_key(coll_id)
            existing = p.meta_items.get(cache_key)
            if isinstance(existing, dict) and existing.get("poster_path"):
                continue
            try:
                params = {"api_key": tmdb.api_key, "language": tmdb.lang}
                coll_data = tmdb._get_json(f"/collection/{int(coll_id)}", params)
            except TMDbAuthError:
                raise InstallStopped("identity")
            except TMDbError as exc:
                _log(f"[CollectionsInstall] Collection art {coll_id}: {exc}", xbmc.LOGDEBUG)
                continue
            if isinstance(coll_data, dict):
                p.meta_items[cache_key] = {
                    "kind": "collection",
                    "id": int(coll_id),
                    "name": coll_data.get("name", ""),
                    "overview": coll_data.get("overview", ""),
                    "poster_path": coll_data.get("poster_path", ""),
                    "backdrop_path": coll_data.get("backdrop_path", ""),
                    "_ts": int(time.time()),
                }
                count += 1
    return count


# --------------------------------------------------------------------------- #
# Jedna jednotka práce → (outcome, meta_delta)
# --------------------------------------------------------------------------- #
def _base_entry(kind: str, found: Dict[str, Any], tmdb_id: int, now_ts: int) -> Dict[str, Any]:
    entry = dict(found or {})
    entry["kind"] = kind
    entry["id"] = int(tmdb_id or 0)
    entry.setdefault("rating", float(entry.get("rating") or entry.get("vote_average") or 0.0))
    entry.setdefault("votes", int(entry.get("votes") or entry.get("vote_count") or 0))
    entry.setdefault("overview", entry.get("overview") or "")
    entry.setdefault("poster_path", entry.get("poster_path") or "")
    entry.setdefault("backdrop_path", entry.get("backdrop_path") or "")
    entry["_ts"] = now_ts
    entry["_err"] = ""
    return entry


def do_task(p: InstallPlan, tmdb: TMDb, t: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    """Zpracuje jednu jednotku. Vrací (outcome, meta_delta).

    HIT/MISS zapisují do `p` (meta `items`). FAILED NEZAPISUJE NIC — to je
    celá pointa 3.5.118. Typ výjimky rozhoduje, ne její text:
        TMDbNotFoundError        → MISS (autoritativní 404)
        TMDbAuthError            → FAILED + InstallStopped (identita)
        TMDbError / Exception    → FAILED
    """
    now_ts = int(time.time())
    kind = t["kind"]
    try:
        if kind in ("movie", "tv") and t.get("pin"):
            return _do_pinned(p, tmdb, t, now_ts)

        if kind == "movie":
            tmdb_id, m = CollectionsUI._find_movie_tmdb(tmdb, t["title"], t.get("year"))
            entry = _base_entry("movie", m, tmdb_id or 0, now_ts)
            entry.setdefault("title", t["title"])
            year = t.get("year")
            try:
                entry.setdefault("year", int(entry.get("year")
                                             or (int(year) if str(year).isdigit() else 0)))
            except Exception:
                entry.setdefault("year", 0)
            p.meta_items[t["key"]] = entry
            return (OUTCOME_HIT if entry["id"] else OUTCOME_MISS), {t["key"]: entry}

        if kind == "tv":
            tv_id, m = CollectionsUI._find_tv_tmdb(tmdb, t["name"])
            entry = _base_entry("tv", m, tv_id or 0, now_ts)
            entry.setdefault("name", t["name"])
            entry.setdefault("title", t["name"])
            try:
                entry.setdefault("year", int((entry.get("first_air_date") or "0000")[:4]))
            except Exception:
                entry.setdefault("year", 0)
            p.meta_items[t["key"]] = entry
            if entry["id"]:
                p.tv_id_cache[t["name"]] = int(entry["id"])
            return (OUTCOME_HIT if entry["id"] else OUTCOME_MISS), {t["key"]: entry}

        if kind == "season":
            return _do_season(p, tmdb, t, now_ts)

        return OUTCOME_FAILED, {}

    except TMDbNotFoundError:
        # Autoritativní 404 na titul/sezónu → MISS (negativní cache s TTL).
        delta = _record_miss(p, t, now_ts)
        return OUTCOME_MISS, delta
    except TMDbAuthError:
        raise InstallStopped("identity")
    except TMDbError as exc:
        _log(f"[CollectionsInstall] FAILED {t.get('key') or t.get('tv')}: {exc}", xbmc.LOGWARNING)
        return OUTCOME_FAILED, {}
    except InstallStopped:
        raise
    except Exception as exc:
        _log(f"[CollectionsInstall] FAILED {t.get('key') or t.get('tv')}: {exc!r}", xbmc.LOGWARNING)
        return OUTCOME_FAILED, {}


#: Pole detailu TMDb, která patří do záznamu meta (stejný tvar jako výsledek hledání — meta nenabobtná o žánry, štáb…).
_DETAIL_FIELDS = ("id", "title", "name", "original_title", "original_name", "overview", "poster_path", "backdrop_path",
                  "vote_average", "vote_count", "release_date", "first_air_date")


def _do_pinned(p: InstallPlan, tmdb: TMDb, t: Dict[str, Any], now_ts: int) -> Tuple[str, Dict[str, Any]]:
    """Položka s pevným `tmdb_id` z katalogu: detail TMDb PODLE ID (`/movie/{id}`, `/tv/{id}`), nikdy hledání podle názvu
    (to Comebacku přiřadilo cizí seriál). 404 = `TMDbNotFoundError` → MISS v `do_task` (bundle Gate ho pak zahojí);
    přenosová chyba → FAILED, nic se nezapíše (R2)."""
    kind, pin = t["kind"], int(t["pin"])
    params = {"api_key": tmdb.api_key, "language": tmdb.lang}
    raw = tmdb._get_json("/%s/%d" % ("movie" if kind == "movie" else "tv", pin), params)  # může vyhodit → do_task
    found = {k: raw[k] for k in _DETAIL_FIELDS if isinstance(raw, dict) and k in raw}
    if pin_id(found.get("id")) != pin:
        return OUTCOME_FAILED, {}                    # odpověď bez očekávaného id = smlouva nesedí, nic nezapisovat
    entry = _base_entry(kind, found, pin, now_ts)
    date = str(found.get("release_date" if kind == "movie" else "first_air_date") or "")
    entry["year"] = int(date[:4]) if date[:4].isdigit() else int(_keys.year_part(t.get("year")) or 0)
    if kind == "movie":
        entry.setdefault("title", t["title"])
    else:
        entry.setdefault("name", t["name"])
        entry.setdefault("title", entry.get("name") or t["name"])
        p.tv_id_cache[t["name"]] = pin
    p.meta_items[t["key"]] = entry
    return OUTCOME_HIT, {t["key"]: entry}


def _record_miss(p: InstallPlan, t: Dict[str, Any], now_ts: int) -> Dict[str, Any]:
    """Negativní záznam pro autoritativní MISS (404). `_err` prázdné — není to
    selhání, je to odpověď."""
    kind = t["kind"]
    delta: Dict[str, Any] = {}
    if kind == "movie":
        e = _base_entry("movie", {}, 0, now_ts)
        e["title"], e["year"] = t["title"], (int(t["year"]) if str(t.get("year")).isdigit() else 0)
        delta[t["key"]] = e
    elif kind == "tv":
        e = _base_entry("tv", {}, 0, now_ts)
        e["name"] = e["title"] = t["name"]
        e["year"] = 0
        delta[t["key"]] = e
    elif kind == "season":
        for key in t.get("keys") or []:
            try:
                _head, tvn, s, ep = key.split("|", 3)
                delta[key] = {"kind": "ep", "tv": tvn, "season": int(s), "episode": int(ep),
                              "name": "", "overview": "", "air_date": "", "still_path": "",
                              "_ts": now_ts, "_err": ""}
            except Exception:
                continue
    for key, entry in delta.items():
        p.meta_items[key] = entry
    return delta


def _do_season(p: InstallPlan, tmdb: TMDb, t: Dict[str, Any], now_ts: int) -> Tuple[str, Dict[str, Any]]:
    tv_name, s_no = t["tv"], int(t["s"])
    keys = list(t.get("keys") or [])
    tv_id = int(p.tv_id_cache.get(tv_name) or 0)
    if not tv_id:
        tv_id, _m = CollectionsUI._find_tv_tmdb(tmdb, tv_name)
        tv_id = int(tv_id or 0)
        if tv_id:
            p.tv_id_cache[tv_name] = tv_id
    if not tv_id:
        # Seriál na TMDb není (autoritativní prázdný výsledek hledání) → MISS všech dílů.
        return OUTCOME_MISS, _record_miss(p, t, now_ts)

    params = {"api_key": tmdb.api_key, "language": tmdb.lang}
    season_raw = tmdb._get_json(f"/tv/{tv_id}/season/{s_no}", params)  # může vyhodit → viz do_task
    eps_by_no: Dict[int, Dict[str, Any]] = {}
    if isinstance(season_raw, dict):
        for ep in (season_raw.get("episodes") or []):
            try:
                eps_by_no[int(ep.get("episode_number") or 0)] = ep
            except Exception:
                continue

    delta: Dict[str, Any] = {}
    for key in keys:
        try:
            _head, tvn, s, e = key.split("|", 3)
            e_no = int(e)
        except Exception:
            continue
        ep_raw = eps_by_no.get(e_no) or {}
        delta[key] = {
            "kind": "ep", "tv": tvn, "season": s_no, "episode": e_no,
            "name": ep_raw.get("name") or "",
            "overview": ep_raw.get("overview") or "",
            "air_date": ep_raw.get("air_date") or "",
            "still_path": ep_raw.get("still_path") or "",
            "_ts": now_ts, "_err": "",
        }
    for key, entry in delta.items():
        p.meta_items[key] = entry
    hit = any((v.get("name") or v.get("overview")) for v in delta.values())
    return (OUTCOME_HIT if hit else OUTCOME_MISS), delta


# --------------------------------------------------------------------------- #
# Stop-signály (stavy, ne počítadla)
# --------------------------------------------------------------------------- #
def _stop_reason() -> str:
    """"" = pokračuj; jinak důvod, proč další request nemá smysl."""
    try:
        if _identity.is_rejected():
            return "identity_rejected:%s" % _identity.rejection_reason()
        if not _identity.allow_gate_request():
            return "no_identity"
    except Exception:
        pass
    try:
        if not _netstate.allow_request():
            return "offline"
    except Exception:
        pass
    return ""


def _claim_ttl_s(p: InstallPlan) -> float:
    """TTL guardu odvozené z horního odhadu trvání: preflight (bundle per kolekce,
    profil `bulk`) + jednotky práce (profil `foreground`, max 2 volání na sezónu).
    Žádná konstanta „od oka" — když se změní HTTP profily, změní se i TTL."""
    try:
        bulk = _rm_http.profile_bulk().budget_s if _rm_http is not None else 60.0
        fg = _rm_http.profile_foreground().budget_s if _rm_http is not None else 20.0
    except Exception:
        bulk, fg = 60.0, 20.0
    calls = sum(2 if t.get("kind") == "season" else 1 for t in p.work)
    return float(len(p.collections)) * bulk + float(calls) * fg + bulk


# --------------------------------------------------------------------------- #
# run()
# --------------------------------------------------------------------------- #
def run(addon: Optional[xbmcaddon.Addon] = None,
        profile_dir: Optional[Path] = None,
        *,
        monitor: Optional[Any] = None,
        collections: Optional[Iterable[Tuple[str, Dict[str, Any]]]] = None,
        tmdb_factory: Optional[Callable[[], TMDb]] = None,
        show_progress: bool = True) -> Dict[str, Any]:
    """Celý běh instalátoru. Bezpečné volat z vlákna i opakovaně (guard).

    Returns: souhrn {"started", "total", "hit", "miss", "failed", "stopped"}.
    """
    summary = {"started": False, "total": 0, "hit": 0, "miss": 0, "failed": 0,
               "stopped": "", "bundle_hits": 0, "reason": ""}
    addon = addon or xbmcaddon.Addon()

    t_plan = time.monotonic()
    p = plan(addon, profile_dir, collections=collections)
    _log(f"[CollectionsInstall] PLAN units={p.total_units} collections={len(p.collections)} "
         f"PLAN_MS={int((time.monotonic() - t_plan) * 1000)}", xbmc.LOGINFO)
    summary["total"] = p.total_units

    if p.total_units == 0:
        summary["reason"] = "nothing_to_do"
        # Artwork ság: v ustáleném stavu 0 requestů; ale nikdy bez identity. Hojení „nenalezeno“ z bundlů (1× za den) —
        # pod TÝMŽ zámkem jako plný běh (zápis meta souboru jen jedním během; audit Fable F53 V10).
        heal_token = None if _stop_reason() else _guard.claim(GUARD_NAME, _claim_ttl_s(p))
        if heal_token is not None:
            try:
                if p.changed_on_disk():
                    # Plán je z doby PŘED zámkem: mezitím soubor zapsal jiný běh → načíst znovu, jinak by `persist()`
                    # přepsal jeho práci starým snímkem (cross-check 28.11.2026 B H4). Když teď práce je, udělá ji
                    # příští běh služby — tenhle drží zámek jen na hojení a obrázky.
                    p = plan(addon, profile_dir, collections=collections)
                tmdb = (tmdb_factory or _default_tmdb)()
                healed, changed = _heal_misses_from_bundles(p, tmdb, time.strftime("%Y-%m-%d"))
                summary["bundle_hits"] = healed
                save = bool(_fetch_collection_artwork(p, tmdb)) or changed
                # „Nic k práci" je taky dokončený běh — bez markeru by zařízení s cache z bundlu vypadalo navždy jako
                # „nikdy nedokončeno" a ztráta souboru by se příště hlásila jako čerstvá instalace. Zapisuje se JEN
                # pod zámkem (dřív i když zámek držel jiný běh → mohl přepsat jeho soubor; audit Fable F54 D1).
                if p.runs_done <= 0:
                    p.mark_run_done()
                    save = True
                if save:
                    p.persist()
            except InstallStopped as stop:
                summary["stopped"] = str(stop)
            except Exception as exc:
                _log(f"[CollectionsInstall] Collection art / heal error: {exc}", xbmc.LOGWARNING)
            finally:
                _guard.release(GUARD_NAME, heal_token)
        return summary

    reason = _stop_reason()
    if reason:
        summary["reason"] = reason
        _log(f"[CollectionsInstall] SKIP units={p.total_units} reason={reason}", xbmc.LOGWARNING,
             context={"units": p.total_units, "reason": reason})
        return summary

    token = _guard.claim(GUARD_NAME, _claim_ttl_s(p))
    if token is None:
        summary["reason"] = "already_running"
        _log("[CollectionsInstall] SKIP reason=already_running", xbmc.LOGINFO)
        return summary

    summary["started"] = True
    mon = monitor if monitor is not None else xbmc.Monitor()
    dlg_bg = None
    try:
        if p.changed_on_disk():
            # Plán vznikl PŘED zámkem a soubor mezitím zapsal jiný běh (cross-check 28.11.2026 B H4) → znovu pod zámkem.
            p = plan(addon, profile_dir, collections=collections)
            summary["total"] = p.total_units
            if p.total_units == 0:
                summary["reason"] = "done_by_other_run"
                return summary
        tmdb = (tmdb_factory or _default_tmdb)()

        # Preflight — jen když JE co instalovat (do 3.5.117 běžel při každém
        # vykreslení root menu, 21 živých GET bez ohledu na stav cache).
        hits = _apply_bundles_from_gate(p, tmdb)
        summary["bundle_hits"] = hits
        if hits:
            _log(f"[CollectionsInstall] Gate bundle pre-populated {hits} items", xbmc.LOGINFO)
            p.persist()
            p.work = _compute_work(p)
            summary["total"] = p.total_units

        try:
            if _fetch_collection_artwork(p, tmdb):
                p.persist()
        except InstallStopped:
            raise

        if p.total_units == 0:
            summary["reason"] = "bundle_complete"
            return summary

        if show_progress:
            try:
                dlg_bg = xbmcgui.DialogProgressBG()
                dlg_bg.create("RichMovie", f"Instaluji kolekce ({p.total_units})...")
            except Exception:
                dlg_bg = None

        processed = 0
        since_flush = 0
        for t in p.work:
            # Φ4: uživatel právě kliká → úloha počká (strop `richmovie_activity.YIELD_MAX_S`) a claim se
            # prodlouží — TTL je odhad trvání práce, čekání na uživatele do něj nepatří
            if _activity.should_yield()[0]:
                if not _activity.wait_while_busy(mon):
                    summary["stopped"] = "abort"
                    break
                if not _guard.renew(GUARD_NAME, token, _claim_ttl_s(p)):
                    summary["stopped"] = "claim_lost"
                    break
            if mon is not None and mon.abortRequested():
                _log("[CollectionsInstall] Abort requested — persisting state and exiting",
                     xbmc.LOGINFO)
                summary["stopped"] = "abort"
                break
            processed += 1
            _progress(dlg_bg, processed, p.total_units, t)

            outcome, _delta = do_task(p, tmdb, t)
            summary[outcome] += 1

            if outcome == OUTCOME_FAILED:
                reason = _stop_reason()
                if reason:
                    summary["stopped"] = reason
                    _log(f"[CollectionsInstall] STOPPED reason={reason} "
                         f"processed={processed}/{p.total_units}", xbmc.LOGWARNING,
                         context={"reason": reason, "processed": processed,
                                  "total": p.total_units, "failed": summary["failed"]})
                    break
            else:
                since_flush += 1
                if since_flush >= SAVE_EVERY_UNITS:
                    since_flush = 0
                    p.persist()
                    # Claim je signál živosti, ne odhad délky práce: prodluž ho
                    # při každém flushi. Když už ho drží jiný proces (náš vypršel
                    # a byl převzat), skonči — dva zapisovatelé téhož JSONu =
                    # poslední vyhrává a zničí postup druhého (Pro Q3).
                    if not _guard.renew(GUARD_NAME, token, _claim_ttl_s(p)):
                        summary["stopped"] = "claim_lost"
                        _log("[CollectionsInstall] STOPPED reason=claim_lost "
                             f"processed={processed}/{p.total_units}", xbmc.LOGWARNING)
                        break

    except InstallStopped as stop:
        summary["stopped"] = str(stop)
        _log(f"[CollectionsInstall] STOPPED reason={stop}", xbmc.LOGWARNING,
             context={"reason": str(stop)})
    except Exception as exc:
        summary["stopped"] = "error"
        _log(f"[CollectionsInstall] RUN_ERROR {exc!r}", xbmc.LOGERROR)
    finally:
        try:
            # Marker „běh dokončen" až po absolutním úspěchu (All-or-Nothing):
            # žádný stop, žádná selhaná jednotka. Slouží jen diagnostice plné
            # reinstalace (`_warn_if_full_reinstall`), o práci rozhodují `items`.
            if not summary["stopped"] and summary["failed"] == 0:
                p.mark_run_done()
            p.persist()
        except Exception as exc:
            _log(f"[CollectionsInstall] Final save error: {exc}", xbmc.LOGWARNING)
        if dlg_bg is not None:
            try:
                dlg_bg.close()
            except Exception:
                pass
        _guard.release(GUARD_NAME, token)
        _log(
            f"[CollectionsInstall] DONE total={summary['total']} hit={summary['hit']} "
            f"miss={summary['miss']} failed={summary['failed']} "
            f"bundle_hits={summary['bundle_hits']} stopped={summary['stopped'] or '-'}",
            xbmc.LOGINFO, context=dict(summary),
        )
    return summary


def _default_tmdb() -> TMDb:
    try:
        key = richmovie_settings.get_tmdb_api_key()
    except Exception:
        key = ""
    return TMDb(key, lang="cs-CZ")


def _progress(dlg_bg: Any, processed: int, total: int, t: Dict[str, Any]) -> None:
    if dlg_bg is None:
        return
    kind = t.get("kind")
    if kind == "movie":
        line = f"Film: {t.get('title')}"
    elif kind == "tv":
        line = f"Serial: {t.get('name')}"
    else:
        line = f"Epizody: {t.get('tv')} - S{int(t.get('s') or 0):02d}"
    try:
        pct = int(processed * 100 / total) if total else 0
        dlg_bg.update(pct, "RichMovie", f"Kolekce {processed}/{total}: {line}")
    except Exception:
        pass


# --------------------------------------------------------------------------- #
# Start na pozadí (volá plugin.py po úspěšném gate_auth)
# --------------------------------------------------------------------------- #
def start_background(addon: Optional[xbmcaddon.Addon] = None) -> Optional[threading.Thread]:
    """Spustí `run()` v non-daemon vlákně (memory `feedback_daemon_threads_kodi`:
    HTTP + zápis JSON nesmí být killnut bez abort handlingu). Vlákno je levné —
    když není co dělat nebo už běží jinde, vrátí se v milisekundách bez sítě."""
    try:
        th = threading.Thread(
            target=run, args=(addon,), daemon=False, name="CollectionsInstall",
        )
        th.start()
        return th
    except Exception as exc:
        _log(f"[CollectionsInstall] Start-error: {exc}", xbmc.LOGWARNING)
        return None
