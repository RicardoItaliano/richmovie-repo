# -*- coding: utf-8 -*-
# ============================================================================ #
# richmovie_helpers.py
# Pomocné třídy a funkce – SearchCache + UI utility  (upraveno: 24.01.2026 19:30 CET, Europe/Prague)
# ⚠️ KODI PLUGIN: Proces-based architektura, lazy init pro session!
# ============================================================================ #
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Pomocné třídy a funkce
───────────────────────────────────────────────────────────────────────────────
Tento modul obsahuje:

  • **SearchCache**     – Perzistentní JSON cache s TTL (30 dní)
  • **UI utility**      – keyboard_input, modal, notif, progress, format_*

Centralizované utility pro použití napříč celým doplňkem.

API:
    SEARCH_CACHE.get(key)  -> Optional[Any]
    SEARCH_CACHE.put(key, value)
    build_key(prefix, *parts)  -> str

    keyboard_input(heading, hidden) -> str | None
    modal(msg, heading, block) -> None
    notif(msg, icon, ms, heading) -> None
    progress(total) -> xbmcgui.DialogProgress
    format_int_spaced(n) -> str
    format_mediainfo(mi) -> str

Autor: Richie – vytvořeno 28-07-2025, rozšířeno 24-01-2026
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY  (abecedně dle skupin)
# ─────────────────────────────────────────────────────────────────────────────
# — Standardní knihovna —
from __future__ import annotations

import datetime
import hashlib
import json
import os
import threading
from pathlib import Path
from typing import Any, List, Optional, Tuple

# — Kodi API —
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
_TTL_SECS: int = 30 * 24 * 60 * 60          # 30 dní
_ADDON      = xbmcaddon.Addon()
_PROFILE    = Path(
    xbmcvfs.translatePath(f"special://profile/addon_data/{_ADDON.getAddonInfo('id')}")
)
_PROFILE.mkdir(parents=True, exist_ok=True)
_CACHE_PATH = _PROFILE / "search_cache.json"


# ─────────────────────────────────────────────────────────────────────────────
#  TŘÍDA  SearchCache
# ─────────────────────────────────────────────────────────────────────────────
class SearchCache:
    """
    Perzistentní JSON cache s TTL (30 dní).

    Klíčem je libovolný hash‑friendly string, hodnota může být jakýkoliv
    JSON‑serializovatelný objekt (typicky list slovníků → Release).
    """

    # 2025‑07‑28 08:42 CEST  – __init__
    def __init__(self, path: Path = _CACHE_PATH, ttl: int = _TTL_SECS) -> None:
        self._path = path
        self._ttl  = ttl
        self._data: dict[str, dict[str, Any]] = {}
        self._loaded = False
        self._lock   = threading.Lock()
        self._stamp: Optional[tuple] = None     # otisk souboru (mtime_ns, velikost), ze kterého je `_data`


    # – interní – -------------------------------------------------------------
    def _now(self) -> int:
        return int(datetime.datetime.now().timestamp())


    # Φ-C (30.09.2026, E4-F04): cache sdílí VÍC procesů — každá invokace pluginu je nový interpret a služba
    # žije dny. Dřív si každý proces načetl soubor jednou a při zápisu ho CELÝ přepsal svou kopií (neatomicky,
    # s odsazením = 88 ms na Kodi 3.8): služba tak mazala záznamy, které mezitím zapsal plugin, a plugin
    # neviděl, co zapsala služba. Teď: čtení si hlídá otisk souboru, zápis nejdřív sloučí čerstvý stav disku
    # a píše atomicky a kompaktně (`richmovie_atomic.write_json`).
    def _file_stamp(self) -> Optional[tuple]:
        try:
            st = os.stat(str(self._path))
            return (int(st.st_mtime_ns), int(st.st_size))
        except OSError:
            return None

    _UNREADABLE = ("unreadable",)      # otisk „soubor se nepodařilo přečíst“ → příští čtení to zkusí znovu

    def _read_disk(self) -> Optional[dict]:
        """Obsah souboru cache. {} = soubor není nebo není JSON slovník (začíná se načisto);
        **None = soubor existuje, ale teď nejde přečíst** (zámek jiného procesu, antivirus). None se NESMÍ
        brát jako prázdná cache — zápis by pak přepsal záznamy všech procesů (cross-check Pro C2-P1)."""
        try:
            with open(self._path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            return data if isinstance(data, dict) else {}
        except FileNotFoundError:
            return {}
        except ValueError as exc:
            self._warn("search cache is not valid JSON, starting fresh: %r" % (exc,))
            return {}
        except OSError as exc:
            self._warn("search cache unreadable now: %r" % (exc,))
            return None

    @staticmethod
    def _warn(text: str) -> None:
        try:
            xbmc.log("[RichMovie] %s" % text, xbmc.LOGWARNING)
        except Exception:
            pass

    def _load(self) -> None:
        """Načte soubor při prvním použití a znovu pokaždé, když ho mezitím změnil jiný proces."""
        stamp = self._file_stamp()
        if self._loaded and (self._stamp_current(stamp) or (stamp is None and self._stamp is None)):
            return
        with self._lock:
            stamp = self._file_stamp()
            if self._loaded and (self._stamp_current(stamp) or (stamp is None and self._stamp is None)):
                return
            disk = self._read_disk()
            if disk is None:
                # nečitelný soubor: pracuje se s tím, co je v paměti (poprvé s ničím), otisk zůstává
                # „nepřečteno“ → příští čtení i zápis si disk vyžádají znovu
                self._stamp = self._UNREADABLE
                self._loaded = True
                return
            self._data = disk
            self._stamp = stamp
            self._loaded = True
            self._purge_locked()


    def _flush_locked(self, changed: Optional[dict] = None) -> None:
        """Zapíše cache. `changed` = {klíč: záznam | None (smazat)} — změny TOHOTO procesu; aplikují se
        na ČERSTVÝ stav disku, takže se neztratí nic, co mezitím zapsal jiný proces."""
        import richmovie_atomic as _atomic
        # Φ-E (30.09.2026, cross-check Flash F16): „přečti disk → slouč → zapiš“ pod MEZIPROCESOVÝM zámkem —
        # bez něj mohl druhý proces zapsat mezi čtením a zápisem a jeho záznam se ztratil. Zámek je
        # best-effort (krátké čekání, UI nesmí stát); bez něj se zapíše jako dřív.
        with _atomic.FileLock(str(self._path) + ".lock", wait_s=self.LOCK_WAIT_S):
            self._flush_under_lock(changed, _atomic)

    def _flush_under_lock(self, changed: Optional[dict], _atomic: Any) -> None:
        try:
            if changed is not None and not self._stamp_current(self._file_stamp()):
                disk = self._read_disk()
                if disk is None:
                    self._warn("search cache write skipped (file unreadable, nothing overwritten)")
                    return
                for k, rec in changed.items():
                    if rec is None:
                        disk.pop(k, None)
                    else:
                        disk[k] = rec
                self._data = disk
                self._purge_locked()
            if _atomic.write_json(str(self._path), self._data, separators=(",", ":")):
                self._stamp = self._file_stamp()
        except Exception as exc:
            # zápis cache nesmí shodit doplněk — ale nesmí ani zmizet beze stopy
            self._warn("search cache write failed: %r" % (exc,))


    LOCK_WAIT_S = 0.5
    # Souborové systémy s hrubým časem (FAT / exFAT na TV boxech: 2 s): zápis jiného procesu se stejnou
    # velikostí by otisk nezměnil. Otisk mladší než tohle okno se proto nebere jako důkaz „beze změny“
    # (stejné pravidlo jako snímek nastavení, 3.5.163; audit Fable F1-V10).
    STAMP_TRUST_AFTER_S = 2.0

    def _stamp_current(self, stamp: Optional[tuple]) -> bool:
        """Je `self._data` jistě totéž co soubor s otiskem `stamp`?"""
        if stamp != self._stamp or not stamp or len(stamp) != 2:
            return False
        import time as _time
        return (_time.time() - stamp[0] / 1e9) >= self.STAMP_TRUST_AFTER_S

    def _expired(self, rec: Any, now: int) -> bool:
        """Záznam je po platnosti: obecné TTL cache, nebo vlastní kratší `ttl` záznamu (neúplný výsledek)."""
        if not isinstance(rec, dict):
            return True
        try:
            ttl = min(self._ttl, int(rec["ttl"])) if rec.get("ttl") else self._ttl
            return (now - int(rec.get("ts", 0) or 0)) > ttl
        except (TypeError, ValueError):
            return True

    def _purge_locked(self) -> None:
        """Odstraní všechny položky po platnosti."""
        now = self._now()
        stale = [k for k, v in self._data.items() if self._expired(v, now)]
        for k in stale:
            del self._data[k]


    # – veřejné API – ---------------------------------------------------------
    # 2025‑07‑28 08:42 CEST  – get()
    def get(self, key: str) -> Optional[Any]:
        """
        Vrátí hodnotu z cache nebo ``None`` (nenalezeno či expirované).
        """
        self._load()
        with self._lock:
            rec = self._data.get(key)
            if not rec:
                return None
            if self._expired(rec, self._now()):
                # Expirace → smazat a vrátit None
                del self._data[key]
                self._flush_locked({key: None})
                return None
            return rec.get("val")


    # 2025‑07‑28 08:42 CEST  – put()
    def is_partial(self, key: str) -> bool:
        """Záznam byl uložen s vlastní (kratší) platností = výsledek, který nebyl úplný."""
        self._load()
        with self._lock:
            rec = self._data.get(key)
            return bool(isinstance(rec, dict) and rec.get("ttl"))

    def put(self, key: str, value: Any, ttl_s: Optional[int] = None) -> None:
        """
        Zapíše (key, value) do cache a automaticky provede očistu starých
        záznamů. `ttl_s` = vlastní (kratší) platnost záznamu — pro výsledek, který není úplný.
        """
        self._load()
        with self._lock:
            rec = {"ts": self._now(), "val": value}
            if ttl_s:
                rec["ttl"] = int(ttl_s)
            self._data[key] = rec
            self._purge_locked()
            self._flush_locked({key: rec})


    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_helpers.py › class SearchCache # clear (vytvořeno: 13.12.2025 11:39 CET, Europe/Prague)
    # ---------------------------------------------------------------------------- #
    def clear(self) -> None:
        """
        Vymaže celou cache (RAM i disk).

        Důvod:
            Pro ruční „Reset cache vyhledávání" potřebujeme cache opravdu vyčistit
            hned v běžícím procesu (nečekat až do restartu Kodi).

        Bezpečnost:
            Mazání nesmí shodit doplněk – případné chyby disk I/O ignorujeme.
        """
        self._load()
        with self._lock:
            self._data = {}
            try:
                self._flush_locked()
            except Exception:
                # best effort – diskový zápis může selhat, ale RAM je vyčištěná
                pass


    # 2025-08-19 14:04 CEST (Europe/Prague) – build_key(): verze‑aware „cache bust"
    @staticmethod
    def build_key(prefix: str, *parts: str) -> str:
        """
        Vytvoří deterministický klíč pro perzistentní hledací cache.

        🔁 Verze v klíči:
            - Klíč nově zahrnuje i *verzi doplňku* získanou z addon.xml.
            - Po aktualizaci doplňku (nová verze) se změní i klíče → žádný
              „cache hit" a následuje plné nové vyhledání s uložením čerstvých
              výsledků.  Tím se obejde dlouhé TTL (30 dní) bez nutnosti ručně
              mazat cache.

        🔁 Jádro v klíči (16.11.2026): v cache je VÝSTUP FILTRU (`rm_core`) — klíč nese i identitu jádra
            (`richmovie_core_path.core_cache_tag`: verze + otisk bajtů). Jiné jádro = jiný klíč, i když verze doplňku
            zůstala (incident: Ebenezer z cache jádra 1.1.0 po nasazení 1.2.0 — balast a CAM bez stupně).

        Formát:
            "{prefix}:v<addon_version>+c<core_version>.<core_sha12>:<sha1(prefix|generace|parts...)>"

        Pozn.:
            - Zbylé části klíče (roky apod.) se mohou vně ještě doplnit
              (viz engine: movie/allowed_years přidává sufix), to zůstává.
            - Staré položky s jinou verzí klíče jsou nedosažitelné a
              `SearchCache` je odstraní běžným TTL úklidem.
        """
        try:
            # _ADDON je definováno na úrovni modulu; načtení verze je levné
            ver = (_ADDON.getAddonInfo("version") or "").strip()
        except Exception:
            ver = ""  # bezpečný fallback (nezpůsobí výjimku)
        try:
            import richmovie_core_path
            core_tag = richmovie_core_path.core_cache_tag()
        except Exception:
            core_tag = "c0"

        gen = (f"v{ver}" if ver else "v0") + "+" + core_tag
        # zahrňte prefix i generaci do hashovaného „blobu", aby změna verze
        # jednoznačně vedla na odlišný digest klíče
        blob = "||".join([prefix, gen] + [str(p) for p in parts])
        digest = hashlib.sha1(blob.encode("utf-8")).hexdigest()
        return f"{prefix}:{gen}:{digest}"


# — veřejná singleton instance —
SEARCH_CACHE = SearchCache()




# ═══════════════════════════════════════════════════════════════════════════════
#  UI UTILITY FUNKCE  (přidáno: 24.01.2026 19:30 CET, Europe/Prague)
# ═══════════════════════════════════════════════════════════════════════════════


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# keyboard_input  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def keyboard_input(heading: str, hidden: bool = False) -> str | None:
    """
    Zobrazí Kodi klávesnici a vrátí zadaný text nebo None při zrušení.

    Args:
        heading: Nadpis klávesnice
        hidden: True pro skryté zadávání (hesla)

    Returns:
        Zadaný text (stripped) nebo None pokud uživatel zrušil
    """
    kb = xbmc.Keyboard("", heading, hidden)
    kb.doModal()
    return kb.getText().strip() if kb.isConfirmed() else None




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# modal  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def modal(msg: str, heading: str = "RichMovie", block: bool = True) -> None:
    """
    Zobrazí modální dialog nebo toast notifikaci.

    Args:
        msg: Text zprávy
        heading: Nadpis dialogu
        block: True = blokující OK dialog, False = toast notifikace
    """
    if block:
        xbmcgui.Dialog().ok(heading, msg)
    else:
        notif(msg, xbmcgui.NOTIFICATION_INFO, None, heading)   # Φ2: jediné volání toastu je `notif`




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# notif  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague – bezpečná toast notifikace)
# ---------------------------------------------------------------------------- #
# Φ2 (29.09.2026, plán ux_latency D7, audit A10 F7): JEDNA řeč toastů. Dřív 58 přímých volání
# s 10 různými délkami a 115 z nich cinkalo i u běžné informace. Délka se odvozuje z textu:
# Kodi toast drží nejméně 1,5 s (`GUIDialogKaiToast.cpp:89`), čtení z TV ~60 ms na znak
# (≈ 17 znaků/s — běžné tempo čtení titulků); strop, aby dlouhá věta nevisela věčně.
TOAST_BASE_MS = 1500
TOAST_MS_PER_CHAR = 60
TOAST_MIN_MS = 2500
TOAST_MAX_MS = 8000


def toast_ms(msg: str) -> int:
    """Doba zobrazení toastu podle délky textu (SSOT, viz konstanty výše)."""
    n = len(str(msg or ""))
    return max(TOAST_MIN_MS, min(TOAST_MAX_MS, TOAST_BASE_MS + TOAST_MS_PER_CHAR * n))


def toast_sound(icon: int, sound: Optional[bool] = None) -> bool:
    """Cinknout? Výslovná volba volajícího platí; jinak jen varování a chyba (něco je špatně
    a chce to pozornost). Informace a průběh jsou tiché (D7: „žádné otravné cinkání“)."""
    if sound is not None:
        return bool(sound)
    return icon in (xbmcgui.NOTIFICATION_WARNING, xbmcgui.NOTIFICATION_ERROR)


#: Znaky, které písmo upozornění Kodi neumí: vše mimo základní rovinu Unicode (emoji 🎄🔔🕯 — Kodi je ukáže jako DVA
#: obdélníky, polovinu po polovině) + spojovač a výběr varianty emoji. Richie 28.11.2026: „v toastu jsou dva obdélníky na
#: výšku, ten skin neumí ty cizí znaky, emoji“.
_TOAST_ZERO_WIDTH = frozenset({0x200D, 0xFE0E, 0xFE0F, 0x20E3})   # + rámeček klávesy „1️⃣“ (cross-check 28.11.2026)
#: Znaky ZÁKLADNÍ roviny, které Unicode kreslí jako barevné emoji (vlastnost Emoji_Presentation=Yes: ⏩ ⭐ ✨ ✅ ❌ …)
#: + šipky ⬅⬆⬇ a ℹ (audit Fable F53 V3). Textové symboly (★ ✔ ✓ ▶ ← → ·) do sady NEPATŘÍ — jsou v doplňku roky a písmo
#: je kreslí. SSOT pro `toast_safe` i pro lint scénáře 136 (žádné emoji v textech doplňku).
EMOJI_BMP = frozenset(
    [0x231A, 0x231B, 0x23E9, 0x23EA, 0x23EB, 0x23EC, 0x23F0, 0x23F3, 0x25FD, 0x25FE, 0x2614, 0x2615]
    + list(range(0x2648, 0x2654))
    + [0x267F, 0x2693, 0x26A1, 0x26AA, 0x26AB, 0x26BD, 0x26BE, 0x26C4, 0x26C5, 0x26CE, 0x26D4, 0x26EA, 0x26F2, 0x26F3,
       0x26F5, 0x26FA, 0x26FD, 0x2705, 0x270A, 0x270B, 0x2728, 0x274C, 0x274E, 0x2753, 0x2754, 0x2755, 0x2757, 0x2795,
       0x2796, 0x2797, 0x27B0, 0x27BF, 0x2B1B, 0x2B1C, 0x2B50, 0x2B55, 0x2B05, 0x2B06, 0x2B07, 0x2139])


def _code_points(*spans: Tuple[int, ...]) -> List[int]:
    out: List[int] = []
    for span in spans:
        out.extend(range(span[0], span[-1] + 1))
    return out


#: Textové symboly, které doplněk VĚDOMĚ používá, ač je Unicode vede jako emoji s výchozí TEXTOVOU prezentací — zůstávají.
#: Fakt 28.11.2026 (fontTools nad písmy Kodi 21 na PC): NotoSans-Regular vzhledu Estuary má ™ ↔, NEMÁ ✔ ▶ ◀ ⏸ ⚠ ⌨ (záložní
#: `arial.ttf` Kodi je má kromě ⏸) — přesto se kreslí: Richie 28.11.2026 na dotaz, zda v seznamu dílů vidí ✔: „jo, fajfku
#: vidím“. Tabulka znaků písma tedy nerozhoduje; nový symbol mimo tuto sadu = ověřit na obrazovce TV.
TEXT_SYMBOLS_KEPT = frozenset({0x2122, 0x2194, 0x2328, 0x23F8, 0x25B6, 0x25C0, 0x26A0, 0x2714})
#: Emoji ZÁKLADNÍ roviny s výchozí TEXTOVOU prezentací (Unicode emoji-data: Emoji=Yes, Emoji_Presentation=No; bez ASCII
#: `#*0-9` a © ®) — ❄ ☃ ❤ ⚙ ✉ ✏ ✂ ☑ ➡ ⏹ ⏭ ☀ ♻ …: po nich jde výběr varianty emoji a písmo Kodi je nemá. Mimo
#: `TEXT_SYMBOLS_KEPT` (cross-check 28.11.2026 A3 N5 + B H5: „❄ a ☃ projdou“).
EMOJI_TEXT_BMP = frozenset(_code_points(
    (0x203C,), (0x2049,), (0x2122,), (0x2139,), (0x2194, 0x2199), (0x21A9, 0x21AA), (0x2328,), (0x23CF,), (0x23ED, 0x23EF),
    (0x23F1, 0x23F2), (0x23F8, 0x23FA), (0x24C2,), (0x25AA, 0x25AB), (0x25B6,), (0x25C0,), (0x25FB, 0x25FC),
    (0x2600, 0x2604), (0x260E,), (0x2611,), (0x2618,), (0x261D,), (0x2620,), (0x2622, 0x2623), (0x2626,), (0x262A,),
    (0x262E, 0x262F), (0x2638, 0x263A), (0x2640,), (0x2642,), (0x265F, 0x2660), (0x2663,), (0x2665, 0x2666), (0x2668,),
    (0x267B,), (0x267E,), (0x2692,), (0x2694, 0x2697), (0x2699,), (0x269B, 0x269C), (0x26A0,), (0x26A7,), (0x26B0, 0x26B1),
    (0x26C8,), (0x26CF,), (0x26D1,), (0x26D3,), (0x26E9,), (0x26F0, 0x26F1), (0x26F4,), (0x26F7, 0x26F9), (0x2702,),
    (0x2708, 0x2709), (0x270C, 0x270D), (0x270F,), (0x2712,), (0x2714,), (0x2716,), (0x271D,), (0x2721,), (0x2733, 0x2734),
    (0x2744,), (0x2747,), (0x2763, 0x2764), (0x27A1,), (0x2934, 0x2935), (0x3030,), (0x303D,), (0x3297,), (0x3299,),
)) - EMOJI_BMP - TEXT_SYMBOLS_KEPT


def is_emoji_char(ch: str) -> bool:
    """Znak, který písmo Kodi nezobrazí (obdélník): mimo základní rovinu, spojovač / výběr varianty / rámeček klávesy,
    `EMOJI_BMP` nebo `EMOJI_TEXT_BMP` (vědomě používané textové symboly `TEXT_SYMBOLS_KEPT` zůstávají)."""
    o = ord(ch)
    return o > 0xFFFF or o in _TOAST_ZERO_WIDTH or o in EMOJI_BMP or o in EMOJI_TEXT_BMP


def toast_safe(text: Any) -> str:
    """Text upozornění bez znaků, které písmo upozornění Kodi nezobrazí (`is_emoji_char`); mezery po nich se sloučí.
    Čisté, nikdy nevyhodí. Volá ho JEN `notif` (jediné místo upozornění) — zdrojové texty emoji mít nemají."""
    s = "".join(ch for ch in str(text if text is not None else "") if not is_emoji_char(ch))
    return " ".join(s.split())


def notif(
    msg: str,
    icon: int = xbmcgui.NOTIFICATION_INFO,
    ms: Optional[int] = None,
    heading: str = "RichMovie",
    sound: Optional[bool] = None,
) -> None:
    """
    Jednotný helper pro toast notifikace — JEDINÉ místo, které volá `Dialog().notification`
    (harness scénář 73 hlídá, že jinde přímé volání nepřibude).

    • Primárně: xbmcgui.Dialog().notification(...)
    • Fallback: zapíše hlášku do kodi.log (aby se nic neztratilo)

    Args:
        msg: Text notifikace
        icon: Ikona (NOTIFICATION_INFO, NOTIFICATION_WARNING, NOTIFICATION_ERROR)
        ms: Doba zobrazení v milisekundách; None = podle délky textu (`toast_ms`)
        heading: Nadpis notifikace
        sound: None = politika `toast_sound` (tiše info, zvuk u varování a chyb)
    """
    try:
        msg, heading = toast_safe(msg), (toast_safe(heading) or "RichMovie")
        xbmcgui.Dialog().notification(heading, msg, icon,
                                      int(ms) if ms else toast_ms(msg), toast_sound(icon, sound))
    except Exception as exc:
        try:
            lvl = xbmc.LOGERROR if icon == xbmcgui.NOTIFICATION_ERROR else xbmc.LOGINFO
            try:
                from richmovie_logging import make_legacy_logger as _mll
                _mll("richmovie.notif", "RichMovie/NOTIF")(
                    f"{msg} (toast failed: {exc})", lvl,
                )
            except Exception:
                xbmc.log(f"[RichMovie/NOTIF] {msg} (toast failed: {exc})", lvl)
        except Exception:
            pass




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# net_error_message  (vytvořeno: 08.08.2026 13:05 CEST, Europe/Prague – Φ5)
# ---------------------------------------------------------------------------- #
def net_error_message(exc: BaseException) -> tuple[str, bool]:
    """Přeloží síťovou výjimku na lidskou českou hlášku.

    PROČ: 08.08.2026 dostal uživatel na obrazovku doslova
    ``Chyba TMDb: <urlopen error [Errno 101] Network is unreachable>``. To není
    chybová hláška, to je výpis pro vývojáře. Technický detail patří do logu
    (kde ho od Φ0 skutečně máme), na obrazovku patří věta, ze které je jasné,
    co se stalo a co s tím.

    Hláška se odvozuje z TŘÍDY chyby, ne z jejího textu — text se mění mezi
    platformami i verzemi Pythonu, třída ne.

    Args:
        exc: Zachycená výjimka. Rozbaluje se `__cause__` řetěz, protože moduly
             chybu obvykle přebalují (`TMDbError(str(e)) from e`) a původní typ
             je jediné, co nese použitelnou informaci.

    Returns:
        (hláška, je_přechodná). `je_přechodná=True` znamená „samo se to nejspíš
        spraví" → volající má použít nenápadnou notifikaci, ne blokující dialog.
    """
    # Rozbal na kořenovou příčinu (max 4 úrovně — hlouběji se reálná hierarchie
    # urllib/http.client/ssl nedostane a cyklická vazba by tu zacyklila smyčku).
    root: BaseException = exc
    for _ in range(4):
        cause = getattr(root, "__cause__", None)
        if not isinstance(cause, BaseException):
            break
        root = cause

    err_class = "permanent"
    is_local = False
    is_offline = False
    try:
        import richmovie_http as _http
        err_class = _http.classify(root)
        is_local = _http.is_local_network_error(root)
        is_offline = isinstance(root, _http.OfflineError) or isinstance(exc, _http.OfflineError)
    except Exception:
        pass

    # Breaker ví o výpadku i tehdy, když konkrétní chyba vypadá nevinně
    # (např. timeout na jednom volání uprostřed dlouhého výpadku).
    try:
        import richmovie_netstate as _ns
        if _ns.is_offline():
            is_offline = True
    except Exception:
        pass

    if is_offline or is_local:
        return ("Zařízení nemá připojení k internetu.", True)

    # 3.5.120: nepřečtené nastavení má přednost přede vším ostatním — je to
    # porucha zařízení, ne serveru, a rada „zkus to znovu" by byla k ničemu.
    # Hláška musí říct jediné, co uživateli reálně pomůže (a co u bandoga
    # 27.08.2026 nikdo nevěděl): restartovat Kodi.
    try:
        from richmovie_gate_transport import IdentityUnavailableError \
            as _IdentityUnavailable
        if isinstance(exc, _IdentityUnavailable) or isinstance(root, _IdentityUnavailable):
            return ("Nepodařilo se načíst přihlášení. Restartuj prosím Kodi.", True)
    except Exception:
        pass

    # 3.5.118: zamítnutá identita má přednost před obecným „data se nepodařilo
    # načíst" — uživatel potřebuje vědět, že má jít změnit heslo, ne zkoušet
    # to znovu. Až ZA offline větví: bez sítě je skutečná příčina výpadek.
    try:
        import richmovie_identity_state as _ident
        if _ident.is_rejected():
            return _ident.user_message()
    except Exception:
        pass

    # Φ2 (29.09.2026): výjimka, která už nese hotovou českou větu pro uživatele (Webshare
    # `APIError.user_message`, CLAUDE.md „texty do UI jen z … APIError.user_message“), ji dostane
    # beze změny — obecné „Data se nepodařilo načíst“ by zahodilo jediný užitečný údaj.
    for _cand in (exc, root):
        _um = getattr(_cand, "user_message", None)
        if isinstance(_um, str) and _um.strip():
            return (_um.strip(), False)

    if err_class == "ratelimit":
        # Není to výpadek — server nás jen brzdí. Opakovat hned nemá smysl.
        return ("Server je právě vytížený. Zkus to prosím za chvíli.", False)

    if err_class == "transient":
        text = ""
        try:
            text = ("%s %s" % (root, exc)).lower()
        except Exception:
            text = ""
        if "timed out" in text or "timeout" in text:
            return ("Server neodpovídá. Zkus to prosím znovu.", True)
        return ("Spojení se serverem se nepovedlo. Zkus to prosím znovu.", True)

    return ("Data se nepodařilo načíst.", False)




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# progress  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def progress(total: int) -> xbmcgui.DialogProgress:
    """
    Vytvoří a vrátí progress dialog pro vyhledávání.

    Args:
        total: Celkový počet kroků (pro procenta)

    Returns:
        Inicializovaný DialogProgress
    """
    dlg = xbmcgui.DialogProgress()
    dlg.create("RichMovie", "Probíhá vyhledávání…")
    dlg.update(0)
    return dlg




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# format_int_spaced  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# parse_server_datetime / format_local_datetime / format_local_date
# (vytvořeno: 05.09.2026 08:15 CEST, Europe/Prague – 3.5.133, Richie: „last: 2026-09-05T05:00 je neintuitivní")
# ---------------------------------------------------------------------------- #
_CZ_MONTHS_GEN = ("ledna", "února", "března", "dubna", "května", "června", "července",
                  "srpna", "září", "října", "listopadu", "prosince")


def parse_server_datetime(value: Any) -> Optional[datetime.datetime]:
    """ISO 8601 z Gate/Postgresu (`2026-09-05T05:00:11.9+00:00`, `…Z`, s mezerou
    místo `T`, i bez zóny = UTC) → aware datetime v LOKÁLNÍM čase zařízení.
    None = prázdné/neparsovatelné (volající rozhodne o fallbacku)."""
    if value is None:
        return None
    if isinstance(value, datetime.datetime):
        dt = value
    else:
        raw = str(value).strip()
        if not raw:
            return None
        raw = raw.replace("Z", "+00:00")
        if "T" not in raw and " " in raw[:11]:
            raw = raw.replace(" ", "T", 1)
        try:
            dt = datetime.datetime.fromisoformat(raw)
        except ValueError:
            try:
                dt = datetime.datetime.fromisoformat(raw[:19])
            except ValueError:
                return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone.utc)
    try:
        return dt.astimezone()
    except (ValueError, OverflowError):
        return None


def format_local_datetime(value: Any, default: str = "nikdy", *,
                          now: Optional[datetime.datetime] = None) -> str:
    """SSOT lidského zápisu času pro UI: `dnes 07:00`, `včera 21:14`,
    `5. září 07:00` (letos), `5. 9. 2025 07:00` (jiný rok). Lokální čas."""
    dt = parse_server_datetime(value)
    if dt is None:
        return default
    ref = (now or datetime.datetime.now(datetime.timezone.utc)).astimezone(dt.tzinfo)
    hm = "{:02d}:{:02d}".format(dt.hour, dt.minute)
    delta_days = (ref.date() - dt.date()).days
    if delta_days == 0:
        return "dnes " + hm
    if delta_days == 1:
        return "včera " + hm
    if dt.year == ref.year:
        return "{}. {} {}".format(dt.day, _CZ_MONTHS_GEN[dt.month - 1], hm)
    return "{}. {}. {} {}".format(dt.day, dt.month, dt.year, hm)


def format_local_date(value: Any, default: str = "?") -> str:
    """Jen datum, lokální čas: `5. 9. 2026`."""
    dt = parse_server_datetime(value)
    if dt is None:
        return default
    return "{}. {}. {}".format(dt.day, dt.month, dt.year)


def format_int_spaced(n: int) -> str:
    """
    Formátuje celé číslo s mezerami jako oddělovači tisíců.

    Příklad:
        10000 → '10 000'

    Args:
        n: Celé číslo k formátování

    Returns:
        Formátovaný řetězec
    """
    return f"{n:,}".replace(",", " ")




# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_helpers.py
# format_mediainfo  (vytvořeno: 24.01.2026 19:30 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def format_mediainfo(mi: dict) -> str:
    """
    Převod MediaInfo slovníku na čitelný blok textu.
    Zobrazujeme jen to podstatné – container, video, audio, titulky.

    Args:
        mi: Slovník s MediaInfo daty (duration, tracks)

    Returns:
        Formátovaný textový blok nebo fallback zpráva
    """
    if not mi:
        return "MediaInfo nebyla k dispozici."

    out = []

    # – container / délka –
    dur = mi.get("duration", 0)
    if dur:
        out.append(f"CONTAINER  …  {dur//60} min {dur%60:02d} s")

    # – tracky –
    for t in mi.get("tracks", []):
        tt = t.get("track_type", "")
        if tt == "Video":
            out.append(
                "VIDEO      …  "
                f"{t.get('format', '')} {t.get('bit_depth', '')}‑bit  "
                f"{t.get('width', '')}×{t.get('height', '')}@{t.get('frame_rate', '')}fps  "
                f"{t.get('hdr_format', '')}".strip()
            )
        elif tt == "Audio":
            lang = t.get("language", "").upper() or "und"
            out.append(
                "AUDIO      …  "
                f"{t.get('format', '')} {t.get('channel_s', '')}  "
                f"{lang}"
            )
        elif tt == "Text":
            lang = t.get("language", "").upper() or "und"
            out.append(f"SUBTITLES …  {lang}  ({t.get('format', '')})")

    return "\n".join(out) or "Žádná MediaInfo data."




# ═══════════════════════════════════════════════════════════════════════════════
#  ALIASY PRO ZPĚTNOU KOMPATIBILITU
# ═══════════════════════════════════════════════════════════════════════════════
# Tyto aliasy umožňují použít funkce s prefixem _ jako dříve v plugin.py
# Po dokončení refaktoringu (Fáze 2) je můžeme odstranit.

_keyboard_input = keyboard_input
_modal = modal
_notif = notif
_progress = progress
_format_int_spaced = format_int_spaced
_format_mediainfo = format_mediainfo


# ─────────────────────────────────────────────────────────────────────────────
#  ŠTÍTEK NAHRÁVKY Z KINA (jádro 1.2.0, 15.11.2026, D-4)
# ─────────────────────────────────────────────────────────────────────────────
# Stupeň určuje SSOT `rm_core.source_grade` (filtr ho zapíše do `Release.source_grade`); tady jen barva a tvar pro Kodi.
# Jistý záznam z kina červeně (táž červená jako „VIP vypršel“ v novém vzhledu), pravděpodobný a zvuk z kina oranžově.
CAM_LABEL_COLORS = {"cam": "FFE53935", "cam?": "FFE8875A", "audio": "FFE8A33D", "audio?": "FFE8A33D"}


def cam_label_text(grade: Any) -> str:
    """„[COLOR …]CAM-RIP[/COLOR]“ (klasický výpis i nový vzhled); prázdné = bez štítku (nic, SCREENER). Kosmetický prvek
    nesmí shodit stavbu výpisu (audit Fable F19 V10: jádro bez `source_grade` po částečné kopii) → chyba = bez štítku."""
    g = str(grade or "")
    if not g:
        return ""
    try:
        import richmovie_core_path  # noqa: F401
        from rm_core.source_grade import label
        text = label(g)
    except Exception as exc:
        xbmc.log("[RichMovie] CAM_LABEL_ERR %r" % (exc,), xbmc.LOGWARNING)
        return ""
    return "[COLOR %s]%s[/COLOR]" % (CAM_LABEL_COLORS.get(g, "FFE53935"), text) if text else ""


def cam_label_markup(grade: Any) -> str:
    """Předpona řádku klasického výpisu („CAM-RIP · “), prázdné = bez štítku."""
    text = cam_label_text(grade)
    return text + " · " if text else ""


# Jádro 1.2.3 (21.11.2026, Richie: „musíme před ty šedé tyky napsat červeně "Nesedí stopáž!"“ → týž den: „nesedí stopáž -
# možný fake by mělo být napsáno“): stream, kterému délka nesedí k titulu (`runtime_mismatch` z `plugin._apply_runtime_sanity`
# — TMDb ±10 % i shoda délek kopií), má šedý řádek a jde na konec; červená věta vysvětlí proč a co to nejspíš je (šedá sama
# nic neříká — padělek „Hunger Games“ = trailer ve smyčce). Táž červená jako jistý CAM.
# „Možný fake“ JEN u celého filmu (audit Fable F37g N1 / N2, rozhodnutí session jako D-1 u seriálů): díl seriálu se měří
# proti stopáži dílu z TMDb, která často lže (`rm_core.ranking` — Griffinovi 50 min × skutečných 22), a dělený soubor
# (CD1 / part) je půlka pravého filmu — u obou by slovo „fake“ označilo pravé streamy → neutrální ranní text Richieho.
RUNTIME_MISMATCH_TEXT = "Nesedí stopáž – možný fake!"
RUNTIME_MISMATCH_SHORT = "⚠ fake?"           # nový vzhled: místo pro 8 znaků vedle ★ (RichMovieStreams.xml)
RUNTIME_MISMATCH_TEXT_NEUTRAL = "Nesedí stopáž!"     # díl seriálu / dělený soubor
RUNTIME_MISMATCH_SHORT_NEUTRAL = "⚠ stopáž"


def _mismatch_may_be_fake(kind: Any, name: Any) -> bool:
    """Smí věta o nesedící stopáži tvrdit „možný fake“? Jen celý film: ne díl seriálu (`kind == "tv"`), ne dělený soubor
    (`rm_core.ranking.is_split_file` — TÁŽ funkce, kterou jádro dělený soubor pozná). Chyba importu jádra = neutrální
    text (kosmetika nesmí shodit výpis a „fake“ bez jistoty neříkáme)."""
    if str(kind or "") == "tv":
        return False
    try:
        import richmovie_core_path  # noqa: F401
        from rm_core.ranking import is_split_file
        return not is_split_file(name)
    except Exception as exc:
        xbmc.log("[RichMovie] MISMATCH_TEXT_ERR %r" % (exc,), xbmc.LOGWARNING)
        return False


def runtime_mismatch_short_markup(mismatch: Any, kind: Any = "", name: Any = "") -> str:
    """Štítek nového vzhledu (vlastnost `rm_mismatch_label`): „⚠ fake?“ u celého filmu, jinak „⚠ stopáž“ — ve stejné červené
    jako věta klasického výpisu, barva v textu ze SSOT, skin ji nemá natvrdo (audit Fable F37 P5); bez nesouladu prázdné."""
    if not mismatch:
        return ""
    text = RUNTIME_MISMATCH_SHORT if _mismatch_may_be_fake(kind, name) else RUNTIME_MISMATCH_SHORT_NEUTRAL
    return "[COLOR %s]%s[/COLOR]" % (CAM_LABEL_COLORS["cam"], text)


def runtime_mismatch_markup(mismatch: Any, kind: Any = "", name: Any = "") -> str:
    """Předpona řádku klasického výpisu u streamu, kterému nesedí délka: „Nesedí stopáž – možný fake! · “ u celého filmu,
    „Nesedí stopáž! · “ u dílu seriálu a děleného souboru (červeně); jinak prázdné."""
    if not mismatch:
        return ""
    text = RUNTIME_MISMATCH_TEXT if _mismatch_may_be_fake(kind, name) else RUNTIME_MISMATCH_TEXT_NEUTRAL
    return "[COLOR %s]%s[/COLOR] · " % (CAM_LABEL_COLORS["cam"], text)


# Jádro 1.2.3 / doplněk 4.5.4 (Richie 21.11.2026: „poklad to našlo, ale proč to u toho stream není napsaný i název filmu a rok
# pokud stopáž sedí - uživatel by měl na první dobrou vidět, že ten stream bude na 99% pravý“): stream z vlny podle herců
# (D-6, dotaz „Kubařová 2024“) filtr pustí jen se jménem titulu v souboru (`rm_core.cascade.movie_cast_wave`), ale název se
# ztrácí mezi herci („Poklad - Veronika Khek Kubařová, Jiří Langmajer 2024 Cz.-.mkv“, 21.11.2026) a divák neví, že hledání
# šlo oklikou. Když mu sedí stopáž (`runtime_confirmed`, D9: potvrzená délka proti TMDb; shoda kopií verdikt jen snižuje,
# nikdy nezvyšuje — `rm_core.ranking.with_consensus`), dostane zeleně „<název> (<rok>) · “ = potvrzená identita filmu:
# klasický výpis na začátku řádku (první řádek s kvalitou, jméno souboru je na druhém), nový vzhled před jménem souboru.
# Jen tahle kombinace: bez potvrzené délky by zelená tvrdila víc, než víme; u ostatních vln nese řádek ★ shody délky a jméno
# začíná názvem. Prodloužená verze (do +50 %) je pořád tentýž film (audit Fable F37g N3 vědomě). Material Green 600 = pár
# k červené CAM (Red 600).
TITLE_CONFIRMED_COLOR = "FF43A047"


def cast_title_hint(wave: Any, runtime_confirmed: Any, movie: Any) -> str:
    """„Poklad (2024)“ pro stream z vlny herců s potvrzenou délkou (viz výše), jinak prázdné. JEDNO rozhodnutí pro
    klasický výpis (`plugin._build_stream_li`) i nový vzhled (`plugin._rv_release_dict` → `title_hint`)."""
    try:
        import richmovie_core_path  # noqa: F401
        from rm_core.cascade import WAVE_CAST
    except Exception as exc:
        xbmc.log("[RichMovie] CAST_TITLE_ERR %r" % (exc,), xbmc.LOGWARNING)
        return ""
    if str(wave or "") != WAVE_CAST or not runtime_confirmed or not isinstance(movie, dict):
        return ""
    title = str(movie.get("title") or "").strip()
    if not title:
        return ""
    year = str(movie.get("year") or "").strip()
    return "%s (%s)" % (title, year) if year else title


def cast_title_markup(hint: Any) -> str:
    """Předpona jména souboru („[COLOR zelená]Poklad (2024)[/COLOR] · “) z `cast_title_hint`; prázdné = nic."""
    text = str(hint or "").strip()
    return "[COLOR %s]%s[/COLOR] · " % (TITLE_CONFIRMED_COLOR, text) if text else ""
