# -*- coding: utf-8 -*-
"""
richmovie_season_ui — vykreslení rozcestníku „Vánoce“ (4.5.6, Vánoce 2026 fáze 2; Richie 28.11.2026: „Udělat více sexy,
více s atmosférou … Zvlášť oddělené vánoční epizody seriálů a hlavně oblíbených seriálů“).

Model (řádky, pořadí, texty) je v čistém `richmovie_season_hub`; tady jen ListItemy přes `RmDir` (klasický výpis i nový
vzhled) a paměť upozornění na zařízení. BEZ SÍTĚ (D3): katalog z doplňku, offline meta kolekcí (`collections_meta_cache.json`,
plní instalátor), historie profilu z lokálních souborů. Klik vede na existující cesty `collections_browse` / `collections_tv`
(D6) — žádná druhá cesta k přehrání ani k dalšímu dílu. Chybí-li meta, řádky zůstanou (bez plakátů), nikdy chybový dialog.
"""
from __future__ import annotations

import os
import time
from typing import Any, Dict, Optional

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import richmovie_season_hub as _hub

#: Kurátorovaný vánoční katalog (SSOT v doplňku; Gate dostává při nasazení kopii — D4).
CATALOG_NAME = "vanoce_master_structured.json"
#: Paměť upozornění na ZAŘÍZENÍ (ne profil): kolikrát a kdy se ukázal toast adventního týdne (`addon_data/season_toast.json`).
TOAST_MARK = "season_toast.json"
#: Zámek rozhodnutí o upozornění mezi procesy (`richmovie_guard`, Window property + TTL).
TOAST_GUARD = "season_toast"
TOAST_GUARD_TTL_S = 30
#: Malá paměť pozadí tipu týdne pro řádek v menu (zapisuje rozcestník; `addon_data/season_menu_art.json`).
MENU_ART = "season_menu_art.json"


def _log(msg: str, level: int = xbmc.LOGDEBUG) -> None:
    try:
        import richmovie_logging as _rl
        lg = _rl.get_logger("richmovie.season")
        (lg.warning if level >= xbmc.LOGWARNING else lg.debug)(msg)
    except Exception:
        try:
            xbmc.log("[RichMovie/Season] %s" % msg, level)
        except Exception:
            pass


def catalog_path(addon: Any) -> str:
    return os.path.join(addon.getAddonInfo("path") or "", "resources", "collections", CATALOG_NAME)


def _activity() -> Dict[str, int]:
    """Kdy profil naposledy sledoval který seriál (historie startů + ✔) — z lokálních souborů profilu, bez sítě."""
    try:
        import richmovie_history as _hist
        return _hub.series_activity(_hist.watch_load(), _hist.watched_load())
    except Exception as exc:                     # noqa: BLE001 — bez historie rozcestník funguje, jen bez „mých“ seriálů
        _log("SEASON_HUB activity unavailable: %s" % type(exc).__name__, xbmc.LOGWARNING)
        return {}


def _stats(catalog: Any, meta: Any, today: Any) -> str:
    """„Tvoje vánoční sezóna: 3 filmy · 2 díly“ od začátku Vánoc — soboty před 1. adventní nedělí (místní čas zařízení)."""
    try:
        import richmovie_history as _hist
        since = _hub.season_start_ts(today, lambda d: int(time.mktime(d.timetuple())))
        films, eps = _hub.season_stats(catalog, meta, _hist.watch_load(), _hist.watched_load(), since)
        return _hub.stats_text(films, eps)
    except Exception as exc:                     # noqa: BLE001
        _log("SEASON_HUB stats unavailable: %s" % type(exc).__name__, xbmc.LOGWARNING)
        return ""


def _url(addon: Any, file_path: str, target: Dict[str, str]) -> str:
    from richmovie_collections import CollectionsUI
    params = dict(target)
    if params.get("action") in ("collections_browse", "collections_tv"):
        params["file"] = file_path
    return CollectionsUI._url(addon, **params)


#: Zvýraznění řádků rozcestníku barvou (písmo Kodi emoji neumí — Richie 28.11.2026): tip týdne a moje seriály zlatě.
_HIGHLIGHT = {_hub.ROW_TIP: "gold", _hub.SECTION_MINE: "gold"}


def _listitem(row: Dict[str, Any], addon_base: str, mediatype: str) -> xbmcgui.ListItem:
    color = _HIGHLIGHT.get(row.get("key"))
    li = xbmcgui.ListItem("[COLOR %s]%s[/COLOR]" % (color, row["label"]) if color else row["label"])
    info = {"title": row["label"], "mediatype": mediatype}
    if row.get("plot"):
        info["plot"] = row["plot"]
    li.setInfo("video", info)
    art = dict(row.get("art") or {})
    img = str(row.get("image") or "").strip()
    if img and addon_base:
        full = os.path.join(addon_base, img.lstrip("/\\"))
        try:
            if xbmcvfs.exists(full):
                art.update(poster=full, thumb=full, icon=full)
        except Exception:
            pass
    if "icon" not in art:
        art["icon"] = art.get("thumb") or "DefaultFolder.png"
    li.setArt(art)
    return li


def show_hub(addon: Any, handle: int, today: Any, section: str = "") -> None:
    """Rozcestník (bez `section`) nebo sekce seriálů (`mine` / `series`). `today` = sezónní datum (`plugin._season_today`)."""
    import richmovie_rmdir
    from richmovie_collections import CollectionsUI
    path = catalog_path(addon)
    catalog = CollectionsUI._load_json(path)
    if not isinstance(catalog, dict):
        _log("SEASON_HUB catalog unreadable: %s" % CATALOG_NAME, xbmc.LOGWARNING)
        CollectionsUI.browse_collection(path, addon, handle)      # dnešní výpis kolekce (sám řekne, co je špatně)
        return
    meta = CollectionsUI.load_meta_items(addon)
    activity = _activity()
    title = _hub.hub_category(today)
    if section:
        rows = _hub.section_rows(catalog, meta, activity, section)
        title = "%s / %s" % (title, _hub.SECTION_TITLES.get(section, ""))
        mediatype, content = "tvshow", "tvshows"
    else:
        rows = _hub.hub_rows(catalog, meta, activity, today, _stats(catalog, meta, today))
        mediatype, content = "set", "videos"
    rmdir = richmovie_rmdir.RmDir(handle, title)
    xbmcplugin.setContent(handle, content)
    xbmcplugin.setPluginCategory(handle, title)
    fanart = next((r["art"]["fanart"] for r in rows if (r.get("art") or {}).get("fanart")), "")
    if fanart:
        try:
            xbmcplugin.setPluginFanart(handle, fanart)
        except Exception:
            pass
    base = addon.getAddonInfo("path") or ""
    import richmovie_routes as _routes
    for row in rows:
        rmdir.add(_url(addon, path, row["target"]), _listitem(row, base, mediatype),
                  _routes.is_folder(row["target"]["action"]))          # isFolder jen z registru (past 3.5.153, F53 V8)
    if not section:
        _remember_menu_art(rows)
    _log("SEASON_HUB section=%s rows=%d mine=%d" % (section or "-", len(rows),
                                                    sum(1 for r in rows if r["key"] == _hub.SECTION_MINE)), xbmc.LOGINFO)
    rmdir.finish()


def _menu_art_path() -> str:
    import richmovie_paths as _paths
    return str(_paths.addon_data_dir() / MENU_ART)


def _remember_menu_art(rows: Any) -> None:
    """Pozadí tipu týdne pro řádek Vánoc v hlavním menu — zapíše ho rozcestník, který offline meta už načetl, aby menu
    nemuselo číst 2,6 MB meta při každém vykreslení (audit Fable F53 V2). Zápis jen při změně."""
    try:
        import richmovie_atomic as _atomic
        tip = next((r for r in rows if r.get("key") == _hub.ROW_TIP), None)
        want = {"tip": str(((tip or {}).get("target") or {}).get("node") or ""),
                "fanart": str(((tip or {}).get("art") or {}).get("fanart") or "")}
        have, _state = _atomic.read_json(_menu_art_path(), {}, expected_type=dict)
        if have != want:
            _atomic.write_json(_menu_art_path(), want)
    except Exception as exc:                     # noqa: BLE001 — ozdoba, rozcestník nesmí shodit
        _log("SEASON_MENU art not stored: %s" % type(exc).__name__)


def menu_extras(addon: Any, today: Any, *, in_period: bool) -> Dict[str, str]:
    """Vše, co řádek Vánoc v hlavním menu potřebuje, s JEDNÍM čtením katalogu (95 kB) a BEZ offline meta (audit Fable
    F53 V2: dřív 2,6 MB + katalog dvakrát = ~28 ms na každé menu): pozadí tipu týdne z malé paměti rozcestníku
    (`season_menu_art.json`, platí jen pro tentýž tip) a upozornění týdne — jen ve SKUTEČNÉM období (`in_period`; náhled
    z nastavení mimo období klíč upozornění nespotřebuje, F53 V5). Vrací art řádku ({} = jen ikona). Nikdy nevyhodí."""
    try:
        from richmovie_collections import CollectionsUI
        import richmovie_atomic as _atomic
        catalog = CollectionsUI._load_json(catalog_path(addon))
        if in_period:
            maybe_toast(addon, today, catalog)
        tip = _hub.advent_tip(catalog, today)
        if tip is None:
            return {}
        cached, _state = _atomic.read_json(_menu_art_path(), {}, expected_type=dict)
        if isinstance(cached, dict) and cached.get("tip") == tip[0] and cached.get("fanart"):
            return {"fanart": str(cached["fanart"])}
        return {}
    except Exception as exc:                     # noqa: BLE001 — menu se kreslí i bez obrázku
        _log("SEASON_MENU extras unavailable: %s" % type(exc).__name__)
        return {}


def _shown_keys(mark: str) -> Optional[list]:
    """Klíče už ukázaných upozornění; nečitelná značka = None (toto vykreslení nic neukáže). `richmovie_atomic` ji přesune
    do karantény, takže další vykreslení začne s čistou pamětí — upozornění aktuálního týdne se po poškození souboru může
    ukázat ještě JEDNOU, nikdy opakovaně (samo se zahojí; trvalé ticho celé sezóny by bylo horší — audit Fable F54 D3)."""
    import richmovie_atomic as _atomic
    data, state = _atomic.read_json(mark, {}, expected_type=dict)
    if state not in (_atomic.STATE_OK, _atomic.STATE_NO_FILE):
        return None
    return list(data.get("shown") or []) if isinstance(data, dict) else []


def maybe_toast(addon: Any, today: Any, catalog: Any = None) -> Optional[str]:
    """Upozornění adventního týdne / Štědrého dne / konce období NEJVÝŠ JEDNOU na zařízení (`season_toast.json`).
    Mezi procesy pod zámkem `richmovie_guard` (dvě invokace menu naráz = nejvýš jeden toast, F53 V4); značka se zapíše PŘED
    zobrazením (selhání zápisu = žádný toast); nečitelná značka = toto vykreslení nic, pak jednou znovu (`_shown_keys`).
    Vrací klíč ukázaného upozornění.
    Už ukázaný klíč se pozná BEZ zámku (každé další vykreslení menu v týdnu = jen čtení malého souboru); zámek a druhé
    čtení jen ve chvíli, kdy je upozornění opravdu na řadě (cross-check 28.11.2026 B H2)."""
    token = None
    try:
        from richmovie_collections import CollectionsUI
        import richmovie_guard as _guard
        import richmovie_paths as _paths
        if catalog is None:
            catalog = CollectionsUI._load_json(catalog_path(addon))
        found = _hub.toast_for(today, catalog)
        if found is None:
            return None
        key, text = found
        mark = str(_paths.addon_data_dir() / TOAST_MARK)
        shown = _shown_keys(mark)
        if shown is None or key in shown:        # už ukázané / nečitelná značka: bez zámku, menu se jen kreslí
            return None
        token = _guard.claim(TOAST_GUARD, TOAST_GUARD_TTL_S)
        if token is None:
            return None                          # jiná invokace právě rozhoduje — ta upozornění ukáže
        shown = _shown_keys(mark)                # pod zámkem znovu: mezitím ho mohla ukázat jiná invokace
        if shown is None or key in shown:
            return None
        import richmovie_atomic as _atomic
        if not _atomic.write_json(mark, {"shown": (shown + [key])[-20:]}):
            return None
        import richmovie_feedback as _fb
        _fb.info(text, heading=_hub.TOAST_HEADING)   # bez emoji: písmo upozornění Kodi je neumí (dva obdélníky)
        return key
    except Exception as exc:                     # noqa: BLE001 — upozornění je ozdoba, menu nesmí shodit
        _log("SEASON_TOAST failed: %s" % type(exc).__name__, xbmc.LOGWARNING)
        return None
    finally:
        if token is not None:
            try:
                import richmovie_guard as _guard
                _guard.release(TOAST_GUARD, token)
            except Exception:
                pass
