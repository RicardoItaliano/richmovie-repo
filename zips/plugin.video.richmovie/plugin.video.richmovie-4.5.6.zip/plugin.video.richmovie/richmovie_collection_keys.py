# -*- coding: utf-8 -*-
"""
richmovie_collection_keys — SSOT klíčů offline meta kolekcí (`collections_meta_cache.json`, 4.5.6).

Klíče `movie|název|rok`, `tv|název`, `ep|seriál|řada|díl` a `coll|id` skládalo do 4.5.5 deset míst ve třech modulech
(výpis kolekce, popularita ság, instalátor — plán i položky bundlu Gate, rozcestník Vánoc), každé s jiným čtením roku
(cross-check 28.11.2026 B H1). Rozdíl by tiše rozpojil zápis a čtení: instalátor by uložil `movie|X|1990`, výpis by
hledal `movie|X|` a plakát by nikdy nenašel. Ověřeno 28.11.2026 nad všemi 4 357 položkami katalogů doplňku: nové funkce
dávají TÉŽ klíče jako všechna dosavadní místa (0 rozdílů).

Čistý modul (bez Kodi, bez sítě), Python 3.8.
"""
from __future__ import annotations

from typing import Any, Dict


def year_part(year: Any) -> str:
    """Rok v klíči: kladné celé číslo (int, celé float z JSONu Gate, číslice v textu) → „1990“; jinak „“."""
    if isinstance(year, bool):
        return ""
    try:
        if isinstance(year, (int, float)):
            n = int(year)
        else:
            text = str(year if year is not None else "").strip()
            n = int(text) if text.isdigit() else 0
    except (TypeError, ValueError, OverflowError):
        return ""
    return str(n) if n > 0 else ""


def movie_key(title: Any, year: Any) -> str:
    return "movie|%s|%s" % (str(title or "").strip(), year_part(year))


def tv_key(name: Any) -> str:
    return "tv|%s" % str(name or "").strip()


def ep_key(tv_name: Any, season: Any, episode: Any) -> str:
    return "ep|%s|%d|%d" % (str(tv_name or "").strip(), int(season), int(episode))


def ep_prefix(tv_name: Any) -> str:
    """Začátek klíčů všech dílů seriálu (`ep|<název>|`) — koncové `|` odliší „Comeback“ od „Comeback 2“."""
    return "ep|%s|" % str(tv_name or "").strip()


def coll_key(coll_id: Any) -> str:
    return "coll|%s" % coll_id


def item_kind(item: Dict[str, Any], default: str = "movie") -> str:
    """Druh položky katalogu (`type`, jinak `kind`) malými písmeny; chybí-li obojí, `default`."""
    return str(item.get("type") or item.get("kind") or default).strip().lower()


def item_title(item: Dict[str, Any]) -> str:
    return str(item.get("title") or item.get("name") or "").strip()


def item_year(item: Dict[str, Any]) -> Any:
    return item.get("year") or item.get("release_year") or None


def item_key(item: Dict[str, Any], default_kind: str = "movie") -> str:
    """Klíč položky katalogu: film `movie|název|rok`, seriál `tv|název`; jiný druh = „“."""
    kind = item_kind(item, default_kind)
    if kind == "movie":
        return movie_key(item_title(item), item_year(item))
    if kind == "tv":
        return tv_key(item_title(item))
    return ""
