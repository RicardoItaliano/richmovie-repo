# -*- coding: utf-8 -*-
"""RichMovie 4.0 — custom Stream-picker window (WindowXMLDialog) — Φ1 SRDCE.

Φ-R1+R2 (2026-06-12) — picker-first + live poll architektura:
  • Okno se otevírá OKAMŽITĚ po kliku (stav „Hledám streamy…"), search běží
    v jiném invokeru a persistuje `addon_data/release_view.json`.
  • Poll loop (non-daemon vlákno, 1 s tick): heartbeat ping (liveness pro
    plugin.py — nahrazuje křehký boolean guard) + re-read JSON při změně mtime
    → list se plní/aktualizuje ŽIVĚ (vč. MI2 enrichment od draineru).
  • Token párování: picker otevřený s tokenem ignoruje payloady cizích hledání
    (race: klik A → zpět → klik B). Fallback otevření bez tokenu bere poslední.
  • MI2 re-sort: finální seřazení se aplikuje JEN pokud uživatel ještě
    nebrouzdá v listu (předvídatelnost > čerstvost řazení pod kurzorem).
  • Lifecycle úklid VŽDY ve finally (incident: viset property = mrtvé kliky).

Přehrávání přes `PlayMedia(plugin://...?action=play&...)`. Starý directory tok
zůstává jako fallback (rm_classic_ui). XML: RichMovieStreams.xml. Best-effort.
"""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.parse

import xbmc
import xbmcgui

import richmovie_ui_common as uc
import richmovie_modal as _modal  # 4.5.3: okno jen přes do_modal (zavřené Kodi uvolní doModal)
from richmovie_helpers import cam_label_text as _cam_label_text  # jádro 1.2.0 (D-4): štítek nahrávky z kina
from richmovie_helpers import runtime_mismatch_short_markup as _mismatch_short  # jádro 1.2.3: „⚠ fake?“ červeně
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/Streams] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.streams", "RichMovie/Streams")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "Streams] " + str(msg), level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"
_XML = "RichMovieStreams.xml"
_RES = "1080i"
_BASE = f"plugin://{_ADDON_ID}/"

_LIST = 9100
_AUTO = 8001
_CLOSE = 8002
_CHIP_ALL = 8010
_CHIP_DAB = 8011
_CHIP_TIT = 8012
_CHIP_HD = 8013
_OFF_TOGGLE = 8014   # jádro 1.2.0 (D-2): „Skryto N · délkou nesedí — Zobrazit / Skrýt“ (cesta ven, audit Fable F19 V2)

# Per-tier barva quality badge (ARGB) — 4K zlatá, FHD Estoril, HD ocel, SD šedá
_TIER_COLORS = (
    (2160, "FFC9A227"),
    (1080, "FF0E63C8"),
    (720, "FF5A7184"),
    (0, "FF4A5160"),
)


def _quality_color(quality) -> str:
    q = str(quality or "").upper()
    try:
        import re as _re
        m = _re.match(r"^(\d{3,4})P$", q)
        if m:
            h = int(m.group(1))
            for floor, color in _TIER_COLORS:
                if h >= floor:
                    return color
    except Exception:
        pass
    return _TIER_COLORS[-1][1]

_POLL_TICK_S = 1.0
_SEARCH_TIMEOUT_S = 75.0   # strop „Hledám…" — pak zobraz prázdný stav s vysvětlením

# CZ kódy (audio/titulky) — normalizace
_CZ = {"cs", "cze", "ces", "cz", "czech", "cesky", "český", "cey"}


def _has_cz(langs) -> bool:
    for l in (langs or []):
        if str(l).strip().lower() in _CZ:
            return True
    return False


# Jazykové kódy (ISO/heuristika z názvu) → krátký display (CZ/SK/EN/…). Mirror
# starého GUI (LabelFormatter) — picker dřív zahazoval vše kromě CZ.
_LANG_DISP = {
    "cs": "CZ", "cz": "CZ", "ces": "CZ", "cze": "CZ", "cesky": "CZ",
    "czech": "CZ", "cey": "CZ", "český": "CZ",
    "sk": "SK", "slk": "SK", "slo": "SK", "svk": "SK", "slovak": "SK", "slovensky": "SK",
    "en": "EN", "eng": "EN", "english": "EN",
    "de": "DE", "ger": "DE", "deu": "DE", "german": "DE",
    "ru": "RU", "rus": "RU", "pl": "PL", "pol": "PL", "hu": "HU", "hun": "HU",
    "fr": "FR", "fre": "FR", "fra": "FR", "es": "ES", "spa": "ES",
    "it": "IT", "ita": "IT", "ja": "JP", "jpn": "JP", "ko": "KR", "kor": "KR",
    "zh": "CN", "chi": "CN", "zho": "CN", "uk": "UA", "ukr": "UA",
    "ro": "RO", "bg": "BG", "hr": "HR", "sr": "SR", "nl": "NL", "pt": "PT", "tr": "TR",
    "ar": "AR", "ara": "AR", "el": "GR", "ell": "GR", "gre": "GR", "gr": "GR",
    "he": "HE", "heb": "HE", "iw": "HE", "hi": "HI", "hin": "HI",
    "th": "TH", "tha": "TH", "vi": "VI", "vie": "VI", "sv": "SV", "swe": "SV",
    "no": "NO", "nor": "NO", "da": "DA", "dan": "DA", "fi": "FI", "fin": "FI",
}
# Pořadí: CZ → SK → EN → ostatní abecedně (relevance pro CZ uživatele)
_LANG_ORDER = {"CZ": 0, "SK": 1, "EN": 2}
_LANG_UNKNOWN = {"", "?", "UN", "UND"}


def _norm_lang_list(codes) -> list:
    out = []
    for c in (codes or []):
        s = str(c).strip().lower()
        d = _LANG_DISP.get(s) or _LANG_DISP.get(s[:3]) or _LANG_DISP.get(s[:2])
        if not d:
            u = s.upper()[:2]
            d = u if u not in _LANG_UNKNOWN else None
        if d and d not in out:
            out.append(d)
    out.sort(key=lambda x: (_LANG_ORDER.get(x, 9), x))
    return out


def _langs_markup(audios, subs) -> str:
    """Barevný popisek dabing/titulky pro VŠECHNY jazyky (bílé kódy = čitelné
    na tmavém i focus pozadí; warm „Dabing", teal „Titulky"). Textový fallback
    pro stavy bez vlajek (XML primárně renderuje vlaječky přes _bind_lang_slots)."""
    parts = []
    aud = _norm_lang_list(audios)
    sub = _norm_lang_list(subs)
    if aud:
        parts.append("[COLOR FFE0A93B]Dabing[/COLOR] [COLOR FFF2F5FA]" + " ".join(aud) + "[/COLOR]")
    if sub:
        parts.append("[COLOR FF4FB8C7]Titulky[/COLOR] [COLOR FFF2F5FA]" + " ".join(sub) + "[/COLOR]")
    return "      ".join(parts)


# Display kódy, pro které máme bundlovanou vlaječku (resources/.../media/flags/<code>.png).
# Sada flag-icons (public domain) stažená přes flagcdn — jednotný styl. EN→vlajka GB.
_FLAG_CODES = {
    "CZ", "SK", "EN", "DE", "RU", "PL", "HU", "FR", "ES", "IT", "JP",
    "KR", "CN", "UA", "RO", "BG", "HR", "SR", "NL", "PT", "TR",
    "AR", "GR", "HE", "HI", "TH", "VI", "SV", "NO", "DA", "FI",
}
_MAX_FLAG_SLOTS = 4  # max jazyků na skupinu (dab/tit) zobrazených jako vlajka

# 3.5.129 (incident PeterFM): prefix názvu Webshare streamu, který Free účet
# nepřehraje — SSOT textu je richmovie_account_state (sdílí legacy výpis; F-05).
from richmovie_account_state import WS_BLOCKED_LABEL_PREFIX as _WS_BLOCKED_NAME_PREFIX  # noqa: E402
from richmovie_helpers import cast_title_markup as _cast_title_markup  # noqa: E402  (doplněk 4.5.4: „Poklad (2024) · “)


def _row_label(r) -> str:
    """Popisek řádku: [předpona Free účtu] + [zeleně „<název> (<rok>) · “ u streamu z vlny herců se sedící stopáží] +
    jméno souboru. JEDNO místo pro naplnění seznamu i průběžné doplnění MI2 — stopáž se potvrdí až po MediaInfo, takže
    `_update_items` musí popisek přepsat taky (dřív se jméno nastavovalo jen při naplnění). Text `title_hint` rozhodl
    `richmovie_helpers.cast_title_hint` (Richie 21.11.2026: „…uživatel by měl na první dobrou vidět, že ten stream bude na
    99% pravý“)."""
    name = _cast_title_markup(r.get("title_hint")) + (r.get("name") or "stream")
    if r.get("ws_blocked"):
        name = _WS_BLOCKED_NAME_PREFIX + name   # 3.5.129: Free účet
    return name


def _flag_for(code) -> str:
    """Cesta k vlaječce (relativní do skin media) nebo '' když nemáme."""
    return f"flags/{code.lower()}.png" if code in _FLAG_CODES else ""


# Kvalita (rm_quality) → ikona rozlišení v resources/media/quality/. Reuse
# existující sady (SSOT) přes special:// — bez duplikace do skin media.
_QUALITY_ICON = {
    "4320P": "8k", "2160P": "4k", "1440P": "2k", "1080P": "1080p",
    "720P": "720p", "576P": "480p", "480P": "480p", "360P": "360p",
    "320P": "360p", "240P": "240p", "144P": "144p",
}


def _quality_icon(quality) -> str:
    """special:// cesta k ikoně rozlišení nebo '' (pak XML použije text chip)."""
    name = _QUALITY_ICON.get(str(quality or "").strip().upper())
    return (f"special://home/addons/{_ADDON_ID}/resources/media/quality/{name}.png"
            if name else "")


def _bind_lang_slots(li, prefix, codes) -> None:
    """Naplní vlaječkové sloty rm_<prefix>1..N_flag + textový fallback
    rm_<prefix>i_txt (kód jazyka, když pro něj nemáme vlajku). rm_<prefix>_has
    = '1' když skupina (dabing/titulky) má aspoň jeden jazyk."""
    li.setProperty(f"rm_{prefix}_has", "1" if codes else "")
    for i in range(1, _MAX_FLAG_SLOTS + 1):
        code = codes[i - 1] if (i - 1) < len(codes) else ""
        flag = _flag_for(code) if code else ""
        li.setProperty(f"rm_{prefix}{i}_flag", flag)
        li.setProperty(f"rm_{prefix}{i}_txt", code if (code and not flag) else "")


def _fmt_size(mb) -> str:
    try:
        mb = int(mb or 0)
    except Exception:
        return ""
    if mb <= 0:
        return ""
    if mb >= 1024:
        return f"{mb / 1024:.1f} GB"
    return f"{mb} MB"


class RichMovieStreamsWindow(uc.RMNavMixin, xbmcgui.WindowXMLDialog):

    def __init__(self, *a, token="", poster="", title="", kind="", still="", overview="", **kw):
        super().__init__(*a, **kw)
        self._token = token or ""
        self._open_poster = poster or ""   # plakát z click-site → vidět HNED
        self._open_title = title or ""      # titulek z click-site → vidět HNED
        self._open_kind = kind or ""        # "tv" → náhled epizody místo plakátu
        self._open_still = still or ""      # still epizody (TMDb path/URL)
        self._open_overview = overview or ""  # popis epizody
        self._movie = {}
        self._releases = []
        self._best = 0
        self._filled = False
        self._user_browsed = False     # uživatel hnul výběrem → nepřeskupovat list
        self._rm_closed = False
        self._poll_thr = None
        self._rv_path = os.path.join(uc.profile_dir(), "release_view.json")
        self._rv_mtime = 0.0
        self._filter = "all"           # all | dab | tit | hd (in-memory chipy)
        # jádro 1.2.0 (D-2): streamy „časově totálně mimo“ přijdou zvlášť (`hidden_off` payloadu) a okno je ukáže
        # jen na přání (`_OFF_TOGGLE`) — šedé, na konci; data se nemažou, jde jen o viditelnost
        self._hidden_off: list = []
        self._show_off = False

    # ------------------------------------------------------------------ init
    def onInit(self) -> None:
        try:
            self.setProperty("rm_sp_state", "searching")
            self.setProperty("rm_sp_title", self._open_title or "Hledám streamy…")
            self.setProperty("rm_sp_count", "")
            self.setProperty("rm_sp_status", "")
            self.setProperty("rm_sp_filter", "all")
            # Plakát/náhled epizody z click-site → zobraz HNED (jinak svítí modrý
            # glow fallback po celou dobu hledání). _set_header po načtení
            # release_view.json přepíše čerstvými daty z payloadu.
            if self._open_poster:
                self.setProperty("rm_sp_poster", uc.img(self._open_poster, "w500"))
            self.setProperty("rm_sp_kind", self._open_kind)
            if self._open_still:
                self.setProperty("rm_sp_still", uc.img(self._open_still, "w780"))
            if self._open_overview:
                self.setProperty("rm_sp_overview", self._open_overview)
            uc.streams_mark_seen(self._token)
            # Fallback otevření bez tokenu: zkus rovnou poslední persist.
            if not self._token:
                self._try_consume(initial=True)
            if not self._filled:
                uc.focus_first(self, [_CLOSE])
            self._start_poll()
        except Exception as exc:
            _log(f"onInit: {exc}", xbmc.LOGWARNING)

    # ------------------------------------------------------------------ poll
    def _start_poll(self) -> None:
        if self._poll_thr is not None:
            return
        self._poll_thr = threading.Thread(
            target=self._poll_loop, name="RMStreamsPoll", daemon=False)
        self._poll_thr.start()

    def _poll_loop(self) -> None:
        mon = xbmc.Monitor()
        t0 = time.time()
        while not self._rm_closed and not mon.abortRequested():
            uc.streams_ping()  # heartbeat — plugin.py podle něj pozná živý picker
            try:
                self._try_consume()
            except Exception as exc:
                _log(f"poll: {exc}", xbmc.LOGWARNING)
            if (not self._filled) and (time.time() - t0) > _SEARCH_TIMEOUT_S:
                self._show_empty("Hledání trvá příliš dlouho. Zkus to prosím znovu.")
                # dál už jen heartbeat (uživatel vidí stav, Back zavře)
            if mon.waitForAbort(_POLL_TICK_S):
                break

    def _try_consume(self, initial: bool = False) -> None:
        """Načti release_view.json, pokud se změnil a patří našemu hledání."""
        try:
            mtime = os.path.getmtime(self._rv_path)
        except Exception:
            return
        if mtime <= self._rv_mtime and not initial:
            return
        try:
            with open(self._rv_path, encoding="utf-8") as fh:
                data = json.load(fh) or {}
        except Exception:
            return
        self._rv_mtime = mtime
        payload_token = str(data.get("token") or "")
        if self._token and payload_token and payload_token != self._token:
            return  # payload cizího hledání — ignoruj, čekej na svůj
        if self._token and not payload_token and not initial:
            return  # starý formát bez tokenu během čekání — neber cizí data
        if self._rm_closed:
            return
        status = data.get("status") or ("ready" if data.get("releases") else "")
        if status == "empty":
            self._movie = data.get("movie") or {}
            # S31: výpadek Webshare = pravdivá věta od pluginu (`empty_msg`), jinak výchozí (audit Fable S-6)
            self._show_empty(str(data.get("empty_msg") or "") or "Nenašel jsem žádný vyhovující stream.")
            return
        releases = data.get("releases") or []
        if not releases:
            return
        self._movie = data.get("movie") or {}
        self._apply(releases, data)

    # ------------------------------------------------------------------ stavy
    def _show_empty(self, message: str) -> None:
        if self._filled:
            return
        self.setProperty("rm_sp_state", "empty")
        self.setProperty("rm_sp_empty_msg", message)
        self._set_header()
        try:
            uc.focus_first(self, [_CLOSE])
        except Exception:
            pass

    def _apply(self, releases, data) -> None:
        """První naplnění, nebo živý update (MI2 enrichment / finální re-sort)."""
        resort = bool(data.get("resort"))
        mi2_running = bool(data.get("mi2_running"))
        hidden_raw = data.get("hidden_off")
        hidden = [r for r in hidden_raw if isinstance(r, dict)] if isinstance(hidden_raw, list) else []
        if not self._filled:
            self._hidden_off = hidden
            self._releases = releases
            self._fill_list()
            self._filled = True
            self.setProperty("rm_sp_state", "ready")
            self._set_header()
            try:
                uc.focus_first(self, [_AUTO, _LIST])
            except Exception:
                pass
        else:
            # skryté jsou součást množiny: jejich změna při „Zobrazit“ mění řádky pod kurzorem (audit Fable F20 N6)
            same_set = ({r.get("ident") for r in releases} == {r.get("ident") for r in self._releases}
                        and {r.get("ident") for r in hidden} == {r.get("ident") for r in self._hidden_off})
            # Refill (= přeskupení pozic) NIKDY, když je uživatel přímo v listu —
            # klik by trefil jinou položku, než na kterou mířil.
            user_in_list = False
            try:
                user_in_list = self.getFocusId() == _LIST
            except Exception:
                pass
            if same_set and (not resort or self._user_browsed or user_in_list):
                # update na místě — badge/piluky se obnoví, pořadí pod kurzorem drží (i u skrytých)
                self._releases = self._reorder_like_current(releases)
                by_hidden = {r.get("ident"): r for r in hidden}
                self._hidden_off = [by_hidden.get(r.get("ident"), r) for r in self._hidden_off]
                self._update_items()
            else:
                pos = self._selected_pos()
                # kotva PŘED výměnou skrytých — jinak by se četla z nového seznamu (F20 N6)
                anchor = self._selected_ident() if (self._user_browsed or user_in_list) else ""
                self._hidden_off = hidden
                if anchor and not same_set:
                    # jádro 1.2.0 (audit Fable F19 V1): množina se změnila (MI2 doměřila ukázku → skrytá, nové
                    # streamy) a divák je v listu → pořadí pod kurzorem drží: zmizelé pryč, nové na konec, kurzor
                    # zůstane na TÉMŽE streamu (dřív na stejném indexu = klik trefil jiný stream)
                    by_ident = {r.get("ident"): r for r in releases}
                    kept = [by_ident[r.get("ident")] for r in self._releases if r.get("ident") in by_ident]
                    seen = {r.get("ident") for r in kept}
                    self._releases = kept + [r for r in releases if r.get("ident") not in seen]
                else:
                    self._releases = releases
                self._fill_list()
                if anchor:
                    self._restore_ident(anchor, pos)
                else:
                    self._restore_pos(pos if self._user_browsed else 0)
        self._best = self._best_index()
        self.setProperty(
            "rm_sp_status",
            "Analyzuji kvalitu a zvukové stopy…" if mi2_running else "")
        self._set_header()

    def _reorder_like_current(self, releases):
        by_ident = {r.get("ident"): r for r in releases}
        return [by_ident.get(r.get("ident"), r) for r in self._releases]

    def _selected_ident(self) -> str:
        """Ident streamu pod kurzorem (viditelný pohled); prázdný = žádný."""
        vis = self._visible()
        pos = self._selected_pos()
        return str(vis[pos].get("ident") or "") if 0 <= pos < len(vis) else ""

    def _restore_ident(self, ident: str, fallback_pos: int) -> None:
        """Kurzor na stream `ident`; když zmizel, na řádek, který zaujal jeho místo (nejbližší následující)."""
        vis = self._visible()
        for i, r in enumerate(vis):
            if r.get("ident") == ident:
                self._restore_pos(i)
                return
        self._restore_pos(fallback_pos)

    def _selected_pos(self) -> int:
        try:
            return int(self.getControl(_LIST).getSelectedPosition())
        except Exception:
            return 0

    def _restore_pos(self, pos: int) -> None:
        try:
            lst = self.getControl(_LIST)
            n = lst.size()
            if n > 0:
                lst.selectItem(max(0, min(pos, n - 1)))
        except Exception:
            pass

    # ------------------------------------------------------------------ data
    def _best_index(self) -> int:
        # Auto nejlepší = nejlepší CELKOVĚ (ignoruje filtr — záměr uživatele
        # „prostě pusť to nejlepší" filtr nemění)
        # Smí ho automat pustit, rozhoduje JEN plugin (`_autoplay_eligible` → `autoplay_ok` v payloadu; jádro 1.2.2, audit
        # Fable F28 V9): ne „časově totálně mimo“ (ukázka) a nejistý díl (možná jiný pořad) jen potvrzený kontinuitou.
        # -1 = „Auto nejlepší“ nemá co pustit (parita s `plugin._pick_best_release`)
        for i, r in enumerate(self._releases):
            if r.get("autoplay_ok") and not r.get("runtime_mismatch"):
                return i
        for i, r in enumerate(self._releases):
            if r.get("autoplay_ok"):
                return i
        return -1

    def _no_auto_text(self) -> str:
        """Proč „Auto nejlepší“ nemá co pustit — pravdivě podle důvodu z payloadu (`autoplay_block` počítá plugin; audit Fable
        F28 V8c, F30 V6)."""
        if any(r.get("autoplay_block") == "unsure" for r in self._releases):
            return "Žádný soubor není jistě tenhle díl — vyber ručně."
        return "Žádný soubor délkou neodpovídá — vyber ručně."

    def _release_visible(self, r) -> bool:
        if self._filter == "dab":
            return _has_cz(r.get("audios"))
        if self._filter == "tit":
            return _has_cz(r.get("subs"))
        if self._filter == "hd":
            # jádro 1.2.0 (D-4): 1080p nahrávka z kina není HD obraz — čip „HD“ ji neukáže
            if str(r.get("source_grade") or "") == "cam":
                return False
            try:
                import re as _re
                m = _re.match(r"^(\d{3,4})P$", str(r.get("quality") or "").upper())
                return bool(m) and int(m.group(1)) >= 1080
            except Exception:
                return False
        return True

    def _rows(self) -> list:
        """Streamy výpisu: z payloadu + skryté „časově totálně mimo“, když je divák chce vidět (na konci)."""
        return list(self._releases) + (list(self._hidden_off) if self._show_off else [])

    def _visible(self) -> list:
        return [r for r in self._rows() if self._release_visible(r)]

    def _set_filter(self, name: str) -> None:
        if name == self._filter:
            return
        self._filter = name
        self.setProperty("rm_sp_filter", name)
        if self._filled:
            self._fill_list()
            self._set_header()
            uc.focus_first(self, [_LIST, _AUTO])

    def _set_header(self) -> None:
        m = self._movie
        self.setProperty("rm_sp_poster", uc.img(m.get("poster_path"), "w500"))
        # Episode-specific náhled + popis (kind=tv) — picker ukáže still epizody
        # místo plakátu seriálu a popis epizody pod názvem.
        self.setProperty("rm_sp_kind", m.get("kind") or "")
        self.setProperty("rm_sp_still", uc.img(m.get("ep_still"), "w780") if m.get("ep_still") else "")
        self.setProperty("rm_sp_overview", m.get("ep_overview") or "")
        title = m.get("title") or ""
        if self._filled:
            self.setProperty("rm_sp_title", title or "Streamy")
            vis = self._visible()
            n = len(vis)
            total = len(self._rows())
            suffix = f" (z {total})" if n != total else ""
            self.setProperty("rm_sp_count", f"{n} stream{'ů' if n != 1 else ''}{suffix} · vyber kvalitu")
            self.setProperty("rm_sp_filter_empty", "" if vis else "1")
            n_off = len(self._hidden_off)
            self.setProperty("rm_sp_off_label",
                             "" if not n_off else (f"Skrýt {n_off} · délkou nesedí" if self._show_off
                                                   else f"Skryto {n_off} · délkou nesedí — Zobrazit"))
        elif title:
            self.setProperty("rm_sp_title", title)

    def _li_bind(self, li, r) -> None:
        li.setLabel(_row_label(r))       # doplněk 4.5.4: i při doplnění MI2 (potvrzená stopáž → název filmu)
        q = (r.get("quality") or "?").upper()
        li.setProperty("rm_quality", q)
        li.setProperty("rm_qcolor", _quality_color(q))
        li.setProperty("rm_qicon", _quality_icon(q))  # ikona rozlišení (fallback text chip)
        # Zdroj (Webshare / Fastshare) — uživatel chce vidět odkud stream je.
        if (r.get("source") or "webshare") == "fastshare":
            li.setProperty("rm_src", "FS")
            li.setProperty("rm_srccolor", "FF6D4C9F")   # fialová = Fastshare
        elif r.get("ws_blocked"):
            # 3.5.129 (incident PeterFM): Free účet → Webshare stream nejde přehrát.
            # Položka zůstává vidět (uživatel má vědět proč), chip zčervená,
            # `rm_blocked` je pro skin; klik končí dialogem místo Kodi „Přehrávání selhalo".
            li.setProperty("rm_src", "WS")
            li.setProperty("rm_srccolor", "FFE05050")   # červená = zablokované (VIP vypršel)
        else:
            li.setProperty("rm_src", "WS")
            li.setProperty("rm_srccolor", "FF2D6E7E")   # teal = Webshare
        li.setProperty("rm_blocked", "1" if r.get("ws_blocked") else "")
        # Všechny jazyky (dabing + titulky) — vlaječky + textový fallback (parita
        # se starým GUI, které ukazovalo CZ/SK/EN dab i tit). rm_langs = fallback.
        _bind_lang_slots(li, "a", _norm_lang_list(r.get("audios")))
        _bind_lang_slots(li, "s", _norm_lang_list(r.get("subs")))
        li.setProperty("rm_langs", _langs_markup(r.get("audios"), r.get("subs")))
        li.setProperty("rm_size", _fmt_size(r.get("size_mb")))
        li.setProperty("rm_match", "1" if r.get("match") else "")
        li.setProperty("rm_mismatch", "1" if r.get("runtime_mismatch") else "")
        # jádro 1.2.3 (21.11.2026, „Nesedí stopáž – možný fake!“): text štítku délky ze SSOT `richmovie_helpers` (8 znaků vedle ★)
        li.setProperty("rm_mismatch_label", _mismatch_short(r.get("runtime_mismatch"), r.get("kind"), r.get("name")))
        # jádro 1.2.0 (D-4): „CAM-RIP“ červeně / „CAM-RIP?“ a „ZVUK Z KINA“ oranžově (barva v textu štítku)
        li.setProperty("rm_cam", _cam_label_text(r.get("source_grade")))
        # jádro 1.2.2 (audit Fable F28 V8): nejistý díl, který automat nepustí — proč (text skládá `plugin._unsure_label`)
        li.setProperty("rm_unsure", str(r.get("unsure_label") or ""))

    def _fill_list(self) -> None:
        lst = self.getControl(_LIST)
        lst.reset()
        for r in self._visible():
            li = xbmcgui.ListItem(_row_label(r))     # popisek = `_row_label` (tentýž i při doplnění MI2)
            self._li_bind(li, r)
            lst.addItem(li)

    def _update_items(self) -> None:
        if self._filter != "all":
            # filtrovaný pohled se může MI2 updatem změnit (release získá CZ
            # dabing → vstoupí do filtru) → refill se zachováním pozice
            pos = self._selected_pos()
            self._fill_list()
            self._restore_pos(pos)
            return
        try:
            lst = self.getControl(_LIST)
            vis = self._visible()
            n = min(lst.size(), len(vis))
            for i in range(n):
                self._li_bind(lst.getListItem(i), vis[i])
        except Exception as exc:
            _log(f"update_items: {exc}", xbmc.LOGDEBUG)

    # ------------------------------------------------------------------ input
    def onClick(self, controlId: int) -> None:
        try:
            if controlId in (_CLOSE, 9000):
                self.close()
            elif controlId == _AUTO:
                if self._releases and 0 <= self._best < len(self._releases):
                    self._play(self._releases[self._best])
                elif self._releases:
                    _rm_notif(self._no_auto_text(), xbmcgui.NOTIFICATION_INFO, 5000, "RichMovie")
            elif controlId == _OFF_TOGGLE:
                self._show_off = not self._show_off
                self._fill_list()
                self._set_header()
                uc.focus_first(self, [_LIST, _AUTO])
            elif controlId in (_CHIP_ALL, _CHIP_DAB, _CHIP_TIT, _CHIP_HD):
                self._set_filter({_CHIP_ALL: "all", _CHIP_DAB: "dab",
                                  _CHIP_TIT: "tit", _CHIP_HD: "hd"}[controlId])
            elif controlId == _LIST:
                vis = self._visible()
                pos = self._selected_pos()
                if 0 <= pos < len(vis):
                    self._play(vis[pos])
        except Exception as exc:
            uc.notify_error("Přehrání se nepodařilo spustit.", log_tag="Streams")
            _log(f"onClick {controlId}: {exc}", xbmc.LOGWARNING)

    def _play(self, rel) -> None:
        qs = {"action": "play", "ident": rel.get("ident") or ""}
        if not qs["ident"]:
            return
        if rel.get("ws_blocked"):
            # 3.5.129 (incident PeterFM): Free účet — dialog rovnou tady, okno
            # zůstává otevřené (uživatel si vybere Fastshare). Text i rozhodnutí
            # jsou SSOT v richmovie_account_state; plugin `_play` má tutéž bránu
            # pro cesty mimo picker (autoplay, CW).
            try:
                import richmovie_account_state as _account
                heading, text = _account.free_block_message(_account.load())
                xbmcgui.Dialog().ok(heading, text)
                _log(f"PLAY_BLOCKED reason={_account.PLAY_BLOCK_WS_FREE} "
                     f"ident={qs['ident']} where=streams_window", xbmc.LOGWARNING)
            except Exception as exc:
                _log(f"ws_blocked dialog: {exc}", xbmc.LOGWARNING)
            return
        import richmovie_play_params as _play_params
        qs.update(_play_params.source_params(rel.get("source"), rel.get("fs_url"), rel.get("fs_hash")))
        m = self._movie
        if (m.get("kind") or "") == "tv":
            # Epizoda: předej TV kontext, aby action=play zapsal ✔ markery,
            # watch_events telemetrii (kind="tv") a správné Continue Watching.
            if m.get("tv_id"):
                qs["tv_id"] = str(m["tv_id"])
            tv_name = m.get("tv_name") or m.get("name")
            if tv_name:
                qs["tv_name"] = tv_name
            if str(m.get("season") or "") != "":
                qs["season"] = str(m["season"])
            if str(m.get("episode") or "") != "":
                qs["episode"] = str(m["episode"])
            if m.get("ep_title"):
                qs["ep_title"] = m["ep_title"]
        else:
            if m.get("title"):
                qs["m_title"] = m["title"]
            if m.get("tmdb_id"):
                qs["tmdb"] = str(m["tmdb_id"])
        url = _BASE + "?" + urllib.parse.urlencode(qs)
        # Po skončení/zastavení se uživatel vrátí do RichMovie Home (P0-3),
        # ne do holého Kodi (řeší service_nextup podle tohoto flagu).
        uc.mark_play_from_ui()
        self.close()
        # Přehrávání NESMÍ běžet pod dialog stackem — picker je modal NAD
        # Detail/Episodes/Home; ty by zůstaly otevřené a zakryly video
        # (incident: zvuk hrál, obraz schovaný za Detailem). Složit VŠE.
        _modal.close_all_dialogs("rm_streams_play")
        # Φ1 (29.09.2026): přes pojistku jednoho startu (druhý požadavek = „Už to spouštím…“)
        import richmovie_playback_dispatch as _rm_dispatch
        _rm_dispatch.request(url, source="rm_streams", noresume=False)

    def on_window_action(self, action) -> None:
        # Back/Stop/device latch řeší uc.RMNavMixin.onAction (Φ1 DRY)
        aid = action.getId()
        if aid == xbmcgui.ACTION_CONTEXT_MENU:
            self._context_menu()
            return
        # POZN. (P2): ACTION_MOUSE_MOVE ZÁMĚRNĚ vynechán — pouhý pohyb myší nad
        # oknem není „uživatel prohlíží", blokoval by MI2 re-sort pro PC navždy.
        if aid in (xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN,
                   xbmcgui.ACTION_MOUSE_WHEEL_UP, xbmcgui.ACTION_MOUSE_WHEEL_DOWN):
            if self._filled and self.getFocusId() == _LIST:
                self._user_browsed = True

    def _context_menu(self) -> None:
        """Context akce na release (parita s legacy directory listingem):
        Přehrát / Stáhnout stream / Detail streamu."""
        try:
            if not self._filled or self.getFocusId() != _LIST:
                return
            vis = self._visible()
            pos = self._selected_pos()
            if not (0 <= pos < len(vis)):
                return
            rel = vis[pos]
            sel = xbmcgui.Dialog().contextmenu(
                ["Přehrát", "Stáhnout stream", "Detail streamu"])
            if sel == 0:
                self._play(rel)
            elif sel == 1:
                m = self._movie
                qs = {"action": "download", "ident": rel.get("ident") or "",
                      "name": rel.get("name") or "",
                      "m_title": m.get("title") or "",
                      "m_year": str(m.get("year") or ""),
                      "source": rel.get("source") or "webshare"}
                xbmc.executebuiltin(
                    f"RunPlugin({_BASE}?{urllib.parse.urlencode(qs)})")
            elif sel == 2:
                qs = {"action": "detail", "ident": rel.get("ident") or ""}
                xbmc.executebuiltin(
                    f"RunPlugin({_BASE}?{urllib.parse.urlencode(qs)})")
        except Exception as exc:
            uc.notify_error("Akce se nepodařila.", log_tag="Streams")
            _log(f"context: {exc}", xbmc.LOGWARNING)

    def close(self):  # noqa: A003 — Kodi API jméno
        self._rm_closed = True
        super().close()


def open_streams(addon, token="", poster="", title="", kind="", still="", overview="") -> None:
    """Otevře custom Stream-picker. Lifecycle properties VŽDY uklidí (finally).

    `poster`/`title` (z click-site) se zobrazí HNED, než search doběhne —
    odstraňuje modrý glow fallback během stavu „Hledám streamy…". `kind="tv"` +
    `still`/`overview` → picker ukáže náhled a popis konkrétní epizody."""
    try:
        w = RichMovieStreamsWindow(_XML, addon.getAddonInfo("path"), "default", _RES,
                                   token=token, poster=poster, title=title,
                                   kind=kind, still=still, overview=overview)
        try:
            _modal.do_modal(w, _XML, tag="rm_streams")
        finally:
            w._rm_closed = True
            thr = w._poll_thr
            if thr is not None and thr.is_alive():
                thr.join(timeout=3.0)
            del w
    except Exception as exc:
        _log(f"open_streams: {exc}", xbmc.LOGWARNING)
        try:
            _rm_notif("Stream-picker se nepodařilo otevřít.", xbmcgui.NOTIFICATION_INFO, 5000, "RichMovie")
        except Exception:
            pass
    finally:
        uc.streams_clear_lifecycle()
