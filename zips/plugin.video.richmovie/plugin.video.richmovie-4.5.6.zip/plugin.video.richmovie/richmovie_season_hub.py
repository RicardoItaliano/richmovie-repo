# -*- coding: utf-8 -*-
"""
richmovie_season_hub — MODEL rozcestníku „Vánoce“ (4.5.6, Vánoce 2026 fáze 2; Richie 28.11.2026: „ať ten Vánoční
režim stojí za to … Zvlášť oddělené vánoční epizody seriálů a hlavně oblíbených seriálů“).

Čisté funkce bez Kodi a bez sítě (Python 3.8): vstupem je kurátorovaný katalog (`resources/collections/
vanoce_master_structured.json`), offline meta kolekcí (`collections_meta_cache.json`, klíče `movie|název|rok` / `tv|název`)
a lokální historie profilu (`watch_history.json`, `watched_episodes.json`). Vykreslení dělá `richmovie_season_ui` přes
`RmDir` (klasický výpis i nový vzhled), klik vede na existující cesty `collections_browse` / `collections_tv` — žádná druhá
cesta k přehrávání ani k dalšímu dílu (D6).
"""
from __future__ import annotations

import datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple

import richmovie_collection_keys as _keys
import richmovie_season as _season

#: Klíč katalogu s tipy adventních nedělí: {"1": "<cesta uzlu>", …, "4": …, "eve": …}; cesta = id uzlů oddělené „/“.
ADVENT_SHELVES_KEY = "advent_shelves"
EVE_KEY = "eve"


def node_by_path(catalog: Any, path: str) -> Optional[Dict[str, Any]]:
    """Uzel stromu katalogu podle cesty `id/id`; neplatná cesta / nečitelný katalog = None."""
    if not isinstance(catalog, dict):
        return None
    nodes = catalog.get("tree")
    node: Optional[Dict[str, Any]] = None
    for seg in [s for s in str(path or "").split("/") if s.strip()]:
        found = None
        for ch in nodes if isinstance(nodes, list) else []:
            if isinstance(ch, dict) and str(ch.get("id") or "").strip() == seg.strip():
                found = ch
                break
        if found is None:
            return None
        node = found
        nodes = found.get("children")
    return node


def path_title(catalog: Any, path: str) -> str:
    """Název uzlu i s rodiči („Pohádky – ČR/ČSSR · Klasika“) — samotné „Klasika“ bez kontextu nic neřekne.
    Segmenty cesty čte STEJNĚ jako `node_by_path` (prázdné vynechá — cross-check 28.11.2026 A2 N4)."""
    titles = []
    segs = [s.strip() for s in str(path or "").split("/") if s.strip()]
    for i in range(1, len(segs) + 1):
        node = node_by_path(catalog, "/".join(segs[:i]))
        if node is None:
            return ""
        titles.append(str(node.get("title") or node.get("id") or "").strip())
    return " · ".join(t for t in titles if t)


def top_nodes(catalog: Any) -> List[Tuple[str, Dict[str, Any]]]:
    """Kategorie první úrovně v KURÁTORSKÉM pořadí katalogu: [(cesta, uzel)] (bez uzlů bez id a názvu)."""
    out: List[Tuple[str, Dict[str, Any]]] = []
    for ch in (catalog.get("tree") if isinstance(catalog, dict) else None) or []:
        if isinstance(ch, dict) and str(ch.get("id") or "").strip() and str(ch.get("title") or "").strip():
            out.append((str(ch["id"]).strip(), ch))
    return out


def iter_items(node: Any, path: str = "") -> Iterable[Tuple[str, Dict[str, Any]]]:
    """Všechny položky uzlu i jeho podstromu: (cesta uzlu, ve kterém položka leží, položka)."""
    if not isinstance(node, dict):
        return
    for it in node.get("items") or []:
        if isinstance(it, dict):
            yield path, it
    for ch in node.get("children") or []:
        if isinstance(ch, dict) and str(ch.get("id") or "").strip():
            child_path = (path + "/" if path else "") + str(ch["id"]).strip()
            yield from iter_items(ch, child_path)


def all_items(catalog: Any) -> List[Tuple[str, Dict[str, Any]]]:
    out: List[Tuple[str, Dict[str, Any]]] = []
    for path, node in top_nodes(catalog):
        out.extend(iter_items(node, path))
    return out


def meta_key(item: Dict[str, Any]) -> str:
    """Klíč offline meta (`collections_meta_cache.json`) — JEDINÁ pravda `richmovie_collection_keys.item_key` (týž klíč
    zapisuje instalátor a čte výpis kolekce; dřív vlastní kopie — cross-check 28.11.2026 B H1)."""
    return _keys.item_key(item)


def _meta(meta_items: Any, item: Dict[str, Any]) -> Dict[str, Any]:
    m = meta_items.get(meta_key(item)) if isinstance(meta_items, dict) else None
    return m if isinstance(m, dict) else {}


def display_name(item: Dict[str, Any], meta_items: Any) -> str:
    """Zobrazovaný název: u seriálu český název z offline meta (`name` — „Přátelé“, „Kancl“), u filmu `title` z meta;
    jinak název z katalogu. Odkazy dál nesou název z KATALOGU (podle něj `collections_tv` seriál v katalogu najde)."""
    m = _meta(meta_items, item)
    kind = str(item.get("type") or item.get("kind") or "movie").strip().lower()
    shown = m.get("name") if kind == "tv" else m.get("title")
    for cand in (shown, item.get("title"), item.get("name")):     # první NEPRÁZDNÝ po ořezu („   “ z meta nevyhraje)
        text = str(cand or "").strip()
        if text:
            return text
    return ""


def _int(v: Any) -> int:
    try:
        return int(v or 0)
    except (TypeError, ValueError, OverflowError):
        return 0


def node_art(node: Any, meta_items: Any) -> Dict[str, str]:
    """Plakát a pozadí kategorie bez vlastního obrázku = nejznámější titul (hlasy) jejího podstromu s plakátem."""
    best: Optional[Dict[str, Any]] = None
    for _p, it in iter_items(node):
        m = _meta(meta_items, it)
        if m.get("poster_path") and (best is None or _int(m.get("votes")) > _int(best.get("votes"))):
            best = m
    if best is None:
        return {}
    art = {"poster": "https://image.tmdb.org/t/p/w342%s" % best["poster_path"],
           "thumb": "https://image.tmdb.org/t/p/w185%s" % best["poster_path"]}
    art["icon"] = art["thumb"]
    if best.get("backdrop_path"):
        art["fanart"] = "https://image.tmdb.org/t/p/original%s" % best["backdrop_path"]
    return art


def advent_tip(catalog: Any, today: Any) -> Optional[Tuple[str, Dict[str, Any], str]]:
    """Tip týdne: (cesta uzlu, uzel, nadpis) podle `advent_shelves` katalogu — sobota před adventem tip 1. týdne („Tip na
    1. adventní neděli“), 1.–4. adventní týden (v neděli „Tip N. adventní neděle“, ve všední den „Tip N. adventního
    týdne“ — stejně jako `hub_category` / `toast_for`, audit Fable F53 V7), 24.12. „eve“ (Štědrý den má přednost i před
    4. adventní nedělí). Jindy / bez záznamu / neplatná cesta = None (sekce se nekreslí)."""
    shelves = catalog.get(ADVENT_SHELVES_KEY) if isinstance(catalog, dict) else None
    if not isinstance(shelves, dict):
        return None
    phase = _season.christmas_phase(today)
    if phase == _season.PHASE_EVE:
        key, heading = EVE_KEY, "Tip na Štědrý den"
    elif phase == _season.PHASE_ADVENT_EVE:                 # sobota před adventem: tip na zítřek
        key, heading = "1", "Tip na 1. adventní neděli"
    else:
        k = _season.advent_number(today)
        if not k or phase not in (_season.PHASE_ADVENT, _season.PHASE_EVE_TOMORROW):
            return None
        key = str(k)
        heading = ("Tip %d. adventní neděle" % k) if today.weekday() == 6 else ("Tip %d. adventního týdne" % k)
    path = str(shelves.get(key) or "").strip()
    node = node_by_path(catalog, path) if path else None
    if node is None:
        return None
    return path, node, heading


def curated_series(catalog: Any) -> List[Tuple[str, Dict[str, Any]]]:
    """Kurátorované seriály s vybranými vánočními díly: [(cesta uzlu, položka)] v pořadí katalogu, bez duplicit názvu."""
    out: List[Tuple[str, Dict[str, Any]]] = []
    seen = set()
    for path, it in all_items(catalog):
        name = str(it.get("title") or "").strip()
        if str(it.get("type") or "").strip().lower() == "tv" and name and it.get("episodes") and name not in seen:
            seen.add(name)
            out.append((path, it))
    return out


def series_activity(watch_history: Any, watched: Any) -> Dict[str, int]:
    """{tv_id: poslední aktivita profilu (unix s)} z historie sledování (start dílu) a z ✔ (dokoukání)."""
    out: Dict[str, int] = {}
    rows = []
    rows += [(e.get("tv_id"), e.get("ts")) for e in ((watch_history or {}).get("episodes") or []) if isinstance(e, dict)]
    rows += [(e.get("tv_id"), e.get("watched_at")) for e in ((watched or {}).get("episodes") or []) if isinstance(e, dict)]
    for tid, ts in rows:
        key = str(tid or "").strip()
        if key and key != "0":
            out[key] = max(out.get(key, 0), _int(ts))
    return out


def my_series(catalog: Any, meta_items: Any, activity: Dict[str, int]) -> List[Dict[str, Any]]:
    """Kurátorované vánoční seriály, které profil sleduje (aktivita v historii), naposledy sledované první.
    [{"name", "tv_id", "path", "episodes", "last"}] — `tv_id` z offline meta (bez id seriál vynechá: nejde otevřít)."""
    out: List[Dict[str, Any]] = []
    for path, it in curated_series(catalog):
        tv_id = _int(_meta(meta_items, it).get("id"))
        if tv_id and str(tv_id) in activity:
            out.append({"name": str(it.get("title") or "").strip(), "label": display_name(it, meta_items),
                        "tv_id": tv_id, "path": path,
                        "episodes": len(it.get("episodes") or []), "last": activity[str(tv_id)]})
    out.sort(key=lambda r: (-r["last"], r["name"].lower()))
    return out


def season_start_ts(today: Any, to_ts: Any) -> int:
    """Začátek letošního vánočního období (sobota před 1. adventní nedělí, 00:00 místního času) jako unix s; `to_ts` převádí
    `datetime.date` → unix s (volající dodá `lambda d: int(time.mktime(d.timetuple()))`, test pevnou funkci). Mimo Vánoce 0."""
    today = today.date() if isinstance(today, datetime.datetime) else today
    if not _season.is_christmas(today):
        return 0
    year = today.year if today.month in (11, 12) else today.year - 1
    return _int(to_ts(_season.christmas_start(year)))


def season_stats(catalog: Any, meta_items: Any, watch_history: Any, watched: Any, since_ts: int) -> Tuple[int, int]:
    """(vánoční filmy, vánoční díly) zhlédnuté od `since_ts`: film = start v historii a TMDb id titulu katalogu; díl =
    ✔ dílu z kurátorovaného seznamu. `since_ts` 0 = (0, 0)."""
    if since_ts <= 0:
        return 0, 0
    movie_ids = set()
    episodes = set()
    for _p, it in all_items(catalog):
        m = _meta(meta_items, it)
        kind = str(it.get("type") or "movie").strip().lower()
        if kind == "movie" and _int(m.get("id")):
            movie_ids.add(_int(m.get("id")))
        elif kind == "tv" and _int(m.get("id")):
            for ep in it.get("episodes") or []:
                if isinstance(ep, dict):
                    episodes.add((_int(m.get("id")), _int(ep.get("season")), _int(ep.get("episode"))))
    films = {_int(e.get("tmdb")) for e in ((watch_history or {}).get("movies") or [])
             if isinstance(e, dict) and _int(e.get("ts")) >= since_ts and _int(e.get("tmdb")) in movie_ids}
    eps = {(_int(e.get("tv_id")), _int(e.get("season")), _int(e.get("episode")))
           for e in ((watched or {}).get("episodes") or [])
           if isinstance(e, dict) and _int(e.get("watched_at")) >= since_ts}
    return len(films), len(eps & episodes)


def stats_text(films: int, episodes: int) -> str:
    """„Tvoje vánoční sezóna: 3 filmy · 2 díly“; nic zhlédnutého = pozvánka (žádné „0 filmů“)."""
    import richmovie_cz as _cz
    if films <= 0 and episodes <= 0:
        return "Tvoje vánoční sezóna právě začíná — co si pustíš jako první?"
    parts = []
    if films > 0:
        parts.append(_cz.count(films, "film", "filmy", "filmů"))
    if episodes > 0:
        parts.append(_cz.count(episodes, "díl", "díly", "dílů"))
    return "Tvoje vánoční sezóna: " + " · ".join(parts)


def series_label(name: str, episodes: int) -> str:
    """„Přátelé · 4 vánoční díly“ (místo dřívějšího „(Pouze vybrané epizody)“)."""
    import richmovie_cz as _cz
    return "%s · %s" % (name, _cz.count(episodes, "vánoční díl", "vánoční díly", "vánočních dílů"))


# ── Rozcestník: řádky jako DATA (vykreslí `richmovie_season_ui`; čisté, testovatelné bez Kodi) ─────────────────────────
SECTION_MINE = "mine"        # vánoční díly seriálů, které profil sleduje
SECTION_SERIES = "series"    # všechny kurátorované vánoční díly seriálů (moje nahoře)
SECTIONS = (SECTION_MINE, SECTION_SERIES)
#: Názvy sekcí — JEDINÉ místo (řádek rozcestníku i nadpis otevřené sekce; cross-check 28.11.2026 B H1).
SECTION_TITLES = {SECTION_MINE: "Vánoční díly tvých seriálů", SECTION_SERIES: "Vánoční díly seriálů"}
#: Klíč řádku tipu týdne (zvýraznění a pozadí řádku v menu čte UI podle něj).
ROW_TIP = "tip"
#: Nadpis upozornění sezóny.
TOAST_HEADING = "Vánoce"


def season_year(today: Any) -> int:
    """Rok vánočního období („Vánoce 2026“ platí i 3.1.2027)."""
    today = today.date() if isinstance(today, datetime.datetime) else today
    return today.year if today.month in (11, 12) else today.year - 1


def hub_category(today: Any) -> str:
    """Nadpis rozcestníku: sobota před adventem „Vánoce 2026 · zítra 1. adventní neděle“, v adventu „Vánoce 2026 ·
    2. adventní neděle“ (neděle) / „· 2. adventní týden“ (všední den), 24.12. „Vánoce 2026 · Štědrý den“, jinak „Vánoce 2026“.
    Volá se jen v období (router mimo něj rozcestník nekreslí)."""
    title = "Vánoce %d" % season_year(today)
    phase = _season.christmas_phase(today)
    if phase == _season.PHASE_EVE:
        return title + " · Štědrý den"
    if phase == _season.PHASE_ADVENT_EVE:
        return title + " · zítra 1. adventní neděle"
    k = _season.advent_number(today)
    if not k:
        return title
    # v neděli „neděle“, ve všední den „týden“ (dřív „2. adventní neděle“ i ve středu — audit Fable F53 V7)
    return title + (" · %d. adventní neděle" % k if today.weekday() == 6 else " · %d. adventní týden" % k)


def _only_series(node: Any) -> bool:
    """Podstrom uzlu má položky a všechny jsou seriály (uzel „seriálové speciály“ nahrazuje sekce seriálů — žádná kopie)."""
    kinds = [str(it.get("type") or "movie").strip().lower() for _p, it in iter_items(node)]
    return bool(kinds) and all(k == "tv" for k in kinds)


def _plot(*parts: str) -> str:
    return "\n\n".join(p.strip() for p in parts if p and p.strip())


def _row(key: str, label: str, plot: str, art: Dict[str, str], target: Dict[str, str],
         image: str = "") -> Dict[str, Any]:
    return {"key": key, "label": label, "plot": plot, "art": dict(art), "image": image, "target": dict(target)}


def hub_rows(catalog: Any, meta_items: Any, activity: Dict[str, int], today: Any, stats: str = "") -> List[Dict[str, Any]]:
    """Řádky rozcestníku shora: tip týdne → vánoční díly MÝCH seriálů (jen když nějaké jsou) → kategorie katalogu v kurátorském
    pořadí (bez uzlu, který obsahuje jen seriály) → vánoční díly všech seriálů. `stats` (`stats_text`) jde do popisu řádků.
    `target` = parametry cesty bez `file` (doplní UI); `image` = obrázek uzlu z katalogu (cesta v doplňku), jinak `art`."""
    import richmovie_cz as _cz
    rows: List[Dict[str, Any]] = []
    tip = advent_tip(catalog, today)
    if tip is not None:
        path, node, heading = tip
        rows.append(_row(ROW_TIP, "%s: %s" % (heading, path_title(catalog, path)),
                         _plot(str(node.get("description") or node.get("subtitle") or ""), stats),
                         node_art(node, meta_items), {"action": "collections_browse", "node": path},
                         str(node.get("image") or "").strip()))
    mine = my_series(catalog, meta_items, activity)
    if mine:
        n_eps = sum(r["episodes"] for r in mine)
        names = ", ".join(r["label"] for r in mine[:3]) + (" a další" if len(mine) > 3 else "")
        rows.append(_row(SECTION_MINE, "%s · %s" % (SECTION_TITLES[SECTION_MINE], _cz.count(n_eps, "díl", "díly", "dílů")),
                         _plot(names, stats), _series_art(catalog, meta_items, [r["name"] for r in mine]),
                         {"action": "season_hub", "section": SECTION_MINE}))
    for path, node in top_nodes(catalog):
        if _only_series(node):
            continue
        rows.append(_row("node", str(node.get("title") or "").strip(),
                         _plot(str(node.get("description") or node.get("subtitle") or ""), stats),
                         node_art(node, meta_items), {"action": "collections_browse", "node": path},
                         str(node.get("image") or "").strip()))
    series = curated_series(catalog)
    if series:
        rows.append(_row(SECTION_SERIES, "%s · %s" % (SECTION_TITLES[SECTION_SERIES],
                                                     _cz.count(len(series), "seriál", "seriály", "seriálů")),
                         _plot("Vánoční a sváteční díly oblíbených seriálů — od Bylo nás pět po Přátele.", stats),
                         _series_art(catalog, meta_items, [str(it.get("title") or "") for _p, it in series]),
                         {"action": "season_hub", "section": SECTION_SERIES}))
    return rows


def _series_art(catalog: Any, meta_items: Any, names: List[str]) -> Dict[str, str]:
    """Plakát a pozadí sekce seriálů = nejznámější z vyjmenovaných seriálů (stejné pravidlo jako `node_art`)."""
    wanted = set(n.strip() for n in names)
    pseudo = {"items": [it for _p, it in curated_series(catalog) if str(it.get("title") or "").strip() in wanted]}
    return node_art(pseudo, meta_items)


def section_rows(catalog: Any, meta_items: Any, activity: Dict[str, int], section: str) -> List[Dict[str, Any]]:
    """Seriály sekce: `mine` = sledované (naposledy sledované první), `series` = všechny podle počtu hodnocení na ČSFD
    (`csfd_votes` v katalogu — Richie 28.11.2026: „ty seriály seřadil podle počtu hodnocení na csfd“), bez něj podle hlasů TMDb.
    Klik = vybrané díly (`collections_tv` s uzlem, kde seriál v katalogu leží — D6: žádná druhá cesta k přehrání);
    seriál bez TMDb id (chybí offline meta) = hledání podle názvu (fallback jako ve výpisu kolekce)."""
    if section not in SECTIONS:
        return []
    mine = {r["name"]: r for r in my_series(catalog, meta_items, activity)}
    entries = []
    for path, it in curated_series(catalog):
        name = str(it.get("title") or "").strip()
        if section == SECTION_MINE and name not in mine:
            continue
        m = _meta(meta_items, it)
        if section == SECTION_MINE:
            order = (-mine[name]["last"], 0, name.lower())
        else:
            order = (-_int(it.get("csfd_votes")), -_int(m.get("votes")), name.lower())
        entries.append((order, path, it, m))
    entries.sort(key=lambda e: e[0])
    out: List[Dict[str, Any]] = []
    for _order, path, it, m in entries:
        name = str(it.get("title") or "").strip()
        tv_id = _int(m.get("id"))
        art: Dict[str, str] = {"icon": "DefaultTVShows.png"}
        if m.get("poster_path"):
            art.update(poster="https://image.tmdb.org/t/p/w342%s" % m["poster_path"],
                       thumb="https://image.tmdb.org/t/p/w185%s" % m["poster_path"])
        if m.get("backdrop_path"):
            art["fanart"] = "https://image.tmdb.org/t/p/original%s" % m["backdrop_path"]
        target = ({"action": "collections_tv", "tv_id": str(tv_id), "tv_name": name, "node": path} if tv_id
                  else {"action": "tv_search", "q": name})
        out.append(_row("tv", series_label(display_name(it, meta_items), len(it.get("episodes") or [])),
                        str(m.get("overview") or "").strip(), art, target))
    return out


def toast_for(today: Any, catalog: Any) -> Optional[Tuple[str, str]]:
    """Upozornění, které se ukáže NEJVÝŠ JEDNOU (klíč si pamatuje zařízení): sobota před adventem (= klíč 1. týdne), každý
    adventní týden, Štědrý den a poslední den období. (klíč, text) nebo None. Čisté — paměť klíče řeší
    `richmovie_season_ui.maybe_toast`. Texty BEZ emoji (písmo upozornění Kodi je ukáže jako obdélníky — Richie 28.11.2026);
    v neděli „Dnes je N. adventní neděle“, ve všední den „N. adventní týden“ (audit Fable F53 V7)."""
    today = today.date() if isinstance(today, datetime.datetime) else today
    if not _season.is_christmas(today):
        return None
    year = season_year(today)
    phase = _season.christmas_phase(today)
    if phase == _season.PHASE_EVE:
        return "%d-eve" % year, "Veselé Vánoce!"
    if today.month == 1 and today.day == _season.CHRISTMAS_LAST_JANUARY_DAY:
        nxt = _season.christmas_start(year + 1)          # po D8 sobota před 1. adventní nedělí (F53 V6)
        return ("%d-last" % year, "Vánoční režim dnes končí — vrátí se %d. %d. %d, den před 1. adventní nedělí."
                % (nxt.day, nxt.month, nxt.year))
    tip = advent_tip(catalog, today)
    if phase == _season.PHASE_ADVENT_EVE:                   # sobota: TÝŽ klíč jako 1. týden → v neděli se neopakuje
        text = "Zítra je 1. adventní neděle"
        if tip is not None:
            text += " — tip týdne: %s" % path_title(catalog, tip[0])
        return "%d-advent-1" % year, text
    k = _season.advent_number(today)
    if not k:
        return None
    text = ("Dnes je %d. adventní neděle" % k) if today.weekday() == 6 else ("%d. adventní týden" % k)
    if tip is not None:
        text += " — tip týdne: %s" % path_title(catalog, tip[0])
    return "%d-advent-%d" % (year, k), text
