# -*- coding: utf-8 -*-
"""
richmovie_cz — SSOT české gramatiky čísel v textech RichMovie (4.5.6, Vánoce 2026 fáze 0b).

Česky se tvar podstatného jména řídí CELÝM číslem, ne poslední číslicí: 1 den · 2–4 dny · 0 a 5+ dní (tedy i 21 dní,
22 dní, 101 dní). Do 4.5.5 počítal `plugin._cz_days` podle poslední číslice jako ve slovenštině / ruštině („21 den“,
„22 dny“) — v adventním odpočtu by to bylo vidět každý den. Shoda slovesa: zbývá 1 den · zbývají 2 dny · zbývá 5 dní.

Čistý modul (bez Kodi), Python 3.8 — testuje ho harness (`_tools/net_resilience_sim`, scénář 135).
"""
from __future__ import annotations

from typing import Any


def _as_int(n: Any) -> int:
    try:
        return abs(int(n))
    except (TypeError, ValueError, OverflowError):
        return 0


def plural(n: Any, one: str, few: str, many: str) -> str:
    """Tvar slova k číslu `n`: 1 → `one`, 2–4 → `few`, jinak (0, 5+, nečitelné) → `many`. Záporné jako kladné."""
    k = _as_int(n)
    if k == 1:
        return one
    if 2 <= k <= 4:
        return few
    return many


def count(n: Any, one: str, few: str, many: str) -> str:
    """„5 dní“, „1 den“, „3 dny“ — číslo + správný tvar. Záporné číslo si znaménko nechá („-1 den“; tvar podle
    absolutní hodnoty), nečitelné = 0 (cross-check 28.11.2026 A1 N4: dřív `days(-1)` = „1 den“)."""
    try:
        shown = int(n)
    except (TypeError, ValueError, OverflowError):
        shown = 0
    return "%d %s" % (shown, plural(n, one, few, many))


def days(n: Any) -> str:
    """„1 den“ / „2 dny“ / „5 dní“."""
    return count(n, "den", "dny", "dní")


def remains(n: Any) -> str:
    """Sloveso ve shodě s počtem: „zbývá“ (1, 0, 5+) / „zbývají“ (2–4)."""
    return plural(n, "zbývá", "zbývají", "zbývá")
