# -*- coding: utf-8 -*-
"""
RichMovie Gate client — communicates with the centralized auth server.

Handles:
- Authentication via Gate /auth endpoint
- Local caching of secrets with lease-based expiry (72h grace period)
- Accessor functions for secrets, permissions, and config
"""

from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from datetime import datetime, timezone
from typing import Optional, Tuple

import xbmc
import xbmcaddon
import xbmcvfs
import richmovie_settings  # SSOT čtení i ověřeného zápisu nastavení (3.5.124)
import richmovie_breadcrumb as _rbc  # Φ0: měřený krok gate_auth

import richmovie_gate_transport  # SSOT identity (detect_platform)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
# Gate server URL — SSOT je `richmovie_gate_transport.GATE_URL`.
# Φ3 (2026-08-08): tady byla vlastní kopie stejného řetězce. Když už tenhle modul
# posílá všechna volání přes transportní vrstvu, nemá smysl držet druhou definici
# adresy, která se může rozejít (DRY/SSOT je v Rich* projektech povinné).
_GATE_URL = richmovie_gate_transport.GATE_URL

_CACHE_FILENAME = "gate_cache.json"
_LEASE_GRACE_SECONDS = 3 * 24 * 3600  # 72 hours (čerstvé „tiché" okno)
# Offline-grace: dříve ověřené zařízení smí fungovat v OMEZENÉM režimu až 30 dní
# od posledního ÚSPĚŠNÉHO připojení, pokud je Gate NEDOSTUPNÝ. Aktivuje se JEN na
# unreachable path — NIKDY nepřebíjí explicitní zamítnutí z dostupného Gate
# (revocation při běžícím NASu zůstává okamžitá + maže cache).
_OFFLINE_GRACE_SECONDS = 30 * 24 * 3600  # 30 dní

_ADDON_ID = "plugin.video.richmovie"

# ---------------------------------------------------------------------------
# Module state
# ---------------------------------------------------------------------------
_cache = None  # type: Optional[dict]  # in-memory cache for current session


# 3.4.0: Migrated to richmovie_logging pipeline (Phase 9 batch 1).
# Backwards-compat kodi.log prefix [RichMovie/Gate] preserved via
# XBMCFormatter logger-name mapping. Events flow into user_logs telemetry.
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.gate", "RichMovie/Gate")
except Exception:
    def _log(msg: str, level: int = xbmc.LOGINFO, *, context: dict | None = None) -> None:
        try:
            xbmc.log(f"[RichMovie/Gate] {msg}", level)
        except Exception:
            pass


def _note_identity(authenticated: bool, value: str) -> None:
    """3.5.118: propíše výsledek `/auth` do SSOT stavu identity
    (`richmovie_identity_state`). Best-effort — auth NIKDY nesmí spadnout kvůli
    diagnostickému stavu. `value` = zdroj potvrzení (online/lease/grace) nebo
    Gate kód zamítnutí."""
    try:
        import richmovie_identity_state as _identity
        if authenticated:
            _identity.note_authenticated(value)
        else:
            _identity.note_rejected(value)
    except Exception:
        pass


def _cache_path() -> str:
    """Path to gate_cache.json in addon profile directory."""
    profile = xbmcvfs.translatePath(
        f"special://profile/addon_data/{_ADDON_ID}/"
    )
    return os.path.join(profile, _CACHE_FILENAME)


# ---------------------------------------------------------------------------
# Cache I/O (atomic writes)
# ---------------------------------------------------------------------------
_cache_stamp = None  # type: Optional[tuple]  # (mtime_ns, size) souboru, ze kterého je `_cache`


def _read_cache() -> dict | None:
    """Read cached Gate response from disk. Returns None if missing/corrupt.

    3.5.156: paměťová kopie platí jen dokud se soubor na disku nezmění (`mtime_ns`, velikost).
    Služba (`service_nextup`) žije dny a `/auth` dělá jiný proces (plugin) — bez téhle kontroly
    služba do restartu Kodi neviděla nový blok `permissions` (smoke 27.09.2026: archiv logu
    zapnutý na Gate, worker služby dál četl včerejší odpověď). Jeden `os.stat` per čtení.
    """
    global _cache, _cache_stamp

    path = _cache_path()
    try:
        st = os.stat(path)
        stamp = (getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)), st.st_size)
    except OSError:
        _cache = None
        _cache_stamp = None
        return None
    if _cache is not None and _cache_stamp == stamp:
        return _cache
    try:
        with open(path, "r", encoding="utf-8") as f:
            _cache = json.load(f)
        _cache_stamp = stamp
        return _cache
    except Exception as exc:
        # poškozený soubor = žádná cache (ani stará paměťová kopie — volající by jinak střídal stav)
        _cache = None
        _cache_stamp = None
        _log(f"Cache read error: {exc}", xbmc.LOGWARNING)
        return None


def _write_cache(data: dict) -> None:
    """Write Gate response to cache — trvanlivý atomický zápis přes SSOT
    `richmovie_atomic` (3.5.123). Lease cache kryje 72 h výpadku Gate; kdyby
    po výpadku napájení zůstala prázdná, zařízení by ztratilo i offline-grace."""
    global _cache, _cache_stamp
    _cache = data
    import richmovie_atomic as _atomic
    if not _atomic.write_json(_cache_path(), data, indent=2):
        _log("Cache write error", xbmc.LOGWARNING)
        return
    try:
        st = os.stat(_cache_path())
        _cache_stamp = (getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)), st.st_size)
    except OSError:
        _cache_stamp = None   # příští čtení sáhne na disk (cross-check Pro B 1: bez razítka = zbytečný reload)


def _clear_cache() -> None:
    """Smaže lokální gate cache (in-memory i na disku). Volá se při explicitním
    zamítnutí z DOSTUPNÉHO Gate → zamítnutý uživatel se nemůže schovat offline
    a jet na offline-grace. Best-effort."""
    global _cache
    _cache = None
    try:
        path = _cache_path()
        if os.path.isfile(path):
            os.remove(path)
            _log("Gate cache cleared (explicit rejection from reachable server)")
    except Exception as exc:
        _log(f"Cache clear error: {exc}", xbmc.LOGWARNING)


# ---------------------------------------------------------------------------
# Lease validation
# ---------------------------------------------------------------------------
def _is_lease_valid(cache: dict | None) -> bool:
    """Check if cached lease hasn't expired (72h čerstvé okno)."""
    if not cache:
        return False
    expires_str = cache.get("lease_expires", "")
    if not expires_str:
        return False
    try:
        expires = datetime.fromisoformat(expires_str)
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return datetime.now(timezone.utc) < expires
    except (ValueError, TypeError):
        return False


def _is_offline_grace_valid(cache: dict | None) -> bool:
    """Dříve ověřené zařízení v offline-grace okně (30 dní od posledního úspěšného
    připojení, dle `fetched_at`). Slouží JEN pro fallback při nedostupném Gate."""
    if not cache:
        return False
    fetched_str = cache.get("fetched_at", "")
    if not fetched_str:
        return False
    try:
        fetched = datetime.fromisoformat(fetched_str)
        if fetched.tzinfo is None:
            fetched = fetched.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - fetched).total_seconds()
        return 0 <= age < _OFFLINE_GRACE_SECONDS
    except (ValueError, TypeError):
        return False


def _cache_usable(cache: dict | None) -> bool:
    """Cache je použitelná, pokud platí lease NEBO offline-grace okno.
    Sdílená validita pro všechny accessory (secrets/permissions/config) — aby
    addon v offline režimu měl k dispozici naposledy uložené secrets."""
    return _is_lease_valid(cache) or _is_offline_grace_valid(cache)


# 3.5.130 (dluh z 3.5.118: `/auth` 2× při každém otevření root menu — legacy
# `_root()` i `_ensure_gate_cache_fresh()` volaly Gate nezávisle, páry 2–5 s
# od sebe u všech uživatelů). Čerstvý ÚSPĚŠNÝ online auth pro stejného
# uživatele se v tomhle okně nevolá znovu — vrátí se disková cache.
AUTH_REUSE_WINDOW_S = 60


def _token_fingerprint(ws_token: str) -> str:
    """Otisk WS tokenu do cache (ne token sám — cache je na disku)."""
    return hashlib.sha256(("tok:%s" % (ws_token or "")).encode("utf-8")).hexdigest()[:16]


def auth_reuse_ok(cache: dict | None, ws_username: str, *, ws_token: str = "", addon_version: str = "",
                  window_s: float = AUTH_REUSE_WINDOW_S, now: float | None = None) -> bool:
    """Čistá logika: smí se poslední online auth (`fetched_at`, `auth_user`,
    `auth_token_fp`, `auth_addon_version`, `auth_online=True`) znovu použít místo dalšího HTTP `/auth`?
    Jen platná lease + stejný uživatel + STEJNÝ token (otisk; Pro PB1: po
    reloginu se token mění a Gate má vidět nový) + STEJNÁ verze doplňku + stáří < okno. Cache
    z offline-grace (`auth_online` chybí/False) se nikdy „nerecykluje".

    4.0.1 (Sony BRAVIA 09.10.2026): po aktualizaci 3.5.151 → 4.0.0 nová verze do 60 s recyklovala `/auth`
    staré verze (`Auth reuse` 20:15:08) → Gate nikdy neviděl `addon_version` 4.0.0 (`user_devices` zůstalo na
    3.5.151, hlášení zpoždění verzí flotily lhalo). Jiná verze = vždy skutečný `/auth`; cache bez verze (zapsaná
    do 4.0.0) se tím po aktualizaci jednou obnoví."""
    if window_s <= 0 or not _is_lease_valid(cache):
        return False
    if not cache.get("auth_online"):
        return False
    if (cache.get("auth_user") or "").strip().lower() != (ws_username or "").strip().lower():
        return False
    if (cache.get("auth_token_fp") or "") != _token_fingerprint(ws_token):
        return False
    if (cache.get("auth_addon_version") or "") != (addon_version or ""):
        return False
    fetched_str = cache.get("fetched_at", "")
    try:
        fetched = datetime.fromisoformat(fetched_str)
        if fetched.tzinfo is None:
            fetched = fetched.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return False
    now_dt = datetime.now(timezone.utc) if now is None else datetime.fromtimestamp(now, timezone.utc)
    age = (now_dt - fetched).total_seconds()
    return 0 <= age < window_s


def lease_first_ok(cache: dict | None, ws_username: str, *, ws_token: str = "") -> bool:
    """Čistá logika D5 (Φ3, 29.09.2026): smí se hlavní menu vykreslit z uložené lease BEZ čekání
    na `/auth` (ověření doběhne na pozadí)? Jen platná lease (≤ 72 h) z ONLINE ověření téhož
    uživatele a téhož WS tokenu — tedy přesně to, co by `/auth` v tu chvíli stejně vrátilo, kdyby
    Gate neodpověděl. Offline-grace (bez `auth_online`) ani jiný token/uživatel NE → čeká se.

    Proč: `/auth` blokoval každé otevření menu p50 1,5 s, DNS výpadek až 41 s (audit A07 F3/F5).
    Cena (Richie D5): zamítnutí účtu se v menu projeví o jedno otevření později; přehrávání a
    `/v1/*` blokuje stav identity hned, jak odpověď z pozadí dorazí."""
    if not _is_lease_valid(cache) or not cache.get("auth_online"):
        return False
    if (cache.get("auth_user") or "").strip().lower() != (ws_username or "").strip().lower():
        return False
    return (cache.get("auth_token_fp") or "") == _token_fingerprint(ws_token)


def lease_first(ws_username: str, ws_token: str) -> dict | None:
    """Uložená lease pro menu podle `lease_first_ok`, nebo None (volající musí na `/auth` počkat).
    Zamítnutá identita (REJECTED) vždy None — cesta zotavení je synchronní `/auth`."""
    try:
        import richmovie_identity_state as _ident
        if _ident.is_rejected():
            return None
    except Exception:
        return None
    cache = _read_cache()
    if not lease_first_ok(cache, ws_username, ws_token=ws_token):
        return None
    _note_identity(True, "lease_first")   # = richmovie_identity_state.SOURCE_LEASE_FIRST
    return cache


# ---------------------------------------------------------------------------
# Auth result codes
# ---------------------------------------------------------------------------
AUTH_OK = "ok"
AUTH_OK_OFFLINE = "ok_offline"        # Gate down, ale platná offline-grace cache (omezený režim)
AUTH_TOKEN_INVALID = "token_invalid"  # WS token expired/invalid — retry with fresh
AUTH_REJECTED = "rejected"            # user not whitelisted / inactive
AUTH_UNREACHABLE = "unreachable"      # server down, no usable cache


# ---------------------------------------------------------------------------
# Gate auth call
# ---------------------------------------------------------------------------
# Φ0 (29.09.2026): doba do TRACE (`step=gate_auth`, zapíše se jen ≥ 50 ms = když šel opravdu
# požadavek). `/auth` blokoval hlavní menu p50 1,5 s (audit A07 F3).
@_rbc.timed_step("gate_auth", result_fields=lambda r: {"code": r[0]})
def gate_auth(
    ws_username: str,
    ws_token: str,
    addon: xbmcaddon.Addon,
    ws_password: str = "",
    reuse_within_s: float = AUTH_REUSE_WINDOW_S,
) -> tuple:
    """
    Authenticate with Gate server.

    `reuse_within_s` (3.5.130): čerstvý online auth téhož uživatele a tokenu (disková
    cache, `auth_reuse_ok`) se v tomhle okně nevolá znovu → root menu = 1× `/auth`
    místo 2×. Volající, který potřebuje ZARUČENĚ čerstvý výsledek (např. budoucí
    „ověřit účet" akce), předá 0; dnešní login akce v nastavení `gate_auth` nevolá.

    Returns (result_code, data_or_none):
        (AUTH_OK, dict)            — success, secrets in dict
        (AUTH_OK_OFFLINE, dict)    — Gate down, ale platná offline-grace cache (omezený režim)
        (AUTH_TOKEN_INVALID, None) — WS token rejected, caller should retry
        (AUTH_REJECTED, None)      — user not authorized (reachable Gate said no; cache purged)
        (AUTH_UNREACHABLE, None)   — server down, no usable cache (lease+grace expired / never authed)
    """
    if not ws_username:
        _log("No Webshare credentials, skipping Gate auth", xbmc.LOGWARNING)
        cache = _read_cache()
        if _cache_usable(cache):
            return AUTH_OK, cache
        return AUTH_REJECTED, None

    # 3.5.130: čerstvý online auth téhož uživatele → bez dalšího HTTP (dedup 2× /auth).
    # 4.0.1: a téže verze doplňku — po aktualizaci musí Gate novou verzi uvidět (Sony 09.10.2026).
    addon_version = addon.getAddonInfo("version") or ""
    cached = _read_cache()
    if auth_reuse_ok(cached, ws_username, ws_token=ws_token, addon_version=addon_version,
                     window_s=reuse_within_s):
        _log("Auth reuse (online auth před < %ds, lease do %s)"
             % (int(reuse_within_s), cached.get("lease_expires", "?")))
        _note_identity(True, "reuse")   # pravdivý důvod: recyklace čerstvého online auth (Pro PB2)
        return AUTH_OK, cached

    platform = _detect_platform()

    # Identity proof: SHA256(username:password) — proves addon has valid WS creds
    ws_proof = ""
    if ws_username and ws_password:
        ws_proof = hashlib.sha256(
            ("%s:%s" % (ws_username.lower(), ws_password)).encode("utf-8")
        ).hexdigest()

    # Detect if user has their own FastShare credentials
    has_own_fs = bool(
        richmovie_settings.get_str("fs_username").strip()
        and richmovie_settings.get_str("fs_password").strip()
    )

    payload_body = {
        "ws_username": ws_username,
        "ws_token": ws_token,
        "ws_proof": ws_proof,
        "addon_version": addon_version,
        "platform": platform,
        "device_hash": _get_device_hash(),  # per-device gate (custom_ui override)
        "has_own_fastshare": has_own_fs,
    }
    # Profily (3.5.134, D4): otisk zařízení → Gate umí spárovat historii zařízení s profilem.
    try:
        from richmovie_player_hook import _compute_device_cluster_id
        payload_body["device_cluster_id"] = _compute_device_cluster_id()
    except Exception:
        pass
    # Φ6 (3.5.130, Gate mig 0022): stav Webshare VIP ze stale-first stavu účtu —
    # 0 síťových volání; bez platného stavu se klíče neposílají (Gate NULL nepřepisuje).
    try:
        import richmovie_account_state as _account
        _acc = _account.load()
        if _account.is_valid(_acc):
            payload_body["vip_active"] = bool(_acc.get("vip"))
            payload_body["vip_days"] = min(36500, max(0, int(_acc.get("vip_days") or 0)))  # rozsah Gate schématu (N3)
            payload_body["vip_until"] = (_acc.get("vip_until") or "")[:40]
    except Exception as _acc_exc:
        _log("auth: stav účtu pro VIP telemetrii nedostupný: %r" % (_acc_exc,), xbmc.LOGWARNING)
    # 3.5.155 (Gate mig 0034): odhlášení TOHOTO zařízení z archivu kodi.log — Gate ho eviduje
    # jako `user_devices.kodi_log_archive_override`; bez klíče (chyba čtení) se nic nemění.
    try:
        import richmovie_log_archive as _archive
        payload_body["kodi_log_archive_opt_out"] = bool(_archive.opted_out())
    except Exception as _arch_exc:
        _log("auth: opt-out archivu logu nečitelný: %r" % (_arch_exc,), xbmc.LOGWARNING)

    try:
        # Φ3 (2026-08-08): transport sjednocen na `gate_transport.post_json()` —
        # dřív tu bylo vlastní `urlopen()` mimo SSOT, takže auth jako jediný Gate
        # endpoint neměl retry ani fail-fast. `/auth` je ve whitelistu
        # idempotentních POSTů (čte lease, nic nemění), takže se smí zopakovat.
        #
        # Rozdělení chyb zůstává beze změny: post_json vrací `(status, data)` i pro
        # 4xx/5xx (→ větev „server odpověděl") a vyhazuje jen při selhání transportu
        # (→ větev „Gate unreachable" s fallbackem na lease/grace). To přesně
        # odpovídá původnímu dělení HTTPError vs. Exception.
        _status, data = richmovie_gate_transport.post_json(
            "/auth", payload_body, timeout=8,
        )
        if not isinstance(data, dict):
            data = {}

        if _status >= 400:
            # Gate mluví JSONem se `status`/`error`. HTML 401/403/5xx od Cloudflare (Bot Fight,
            # „browser's signature", 52x) NENÍ zamítnutí uživatele — je to edge = transport
            # (cross-check T2 Pro P5, 05.09.2026: dřív smazalo lease cache celé rodiny).
            gate_json = isinstance(data, dict) and bool(data) and "error" in data
            if not data:
                data = {"status": "error", "error": "http_%d" % _status}
            error = data.get("error", "")
            _log("Auth HTTP %d: %s%s" % (_status, error, "" if gate_json else " (bez Gate JSON = edge)"),
                 xbmc.LOGWARNING)
            if error == "ws_verify_failed":
                # Stale WS token — NE zamítnutí uživatele; caller udělá re-login.
                return AUTH_TOKEN_INVALID, None
            if _status in (401, 403) and gate_json:
                # AUTORITATIVNÍ zamítnutí uživatele z DOSTUPNÉHO serveru
                # (not_whitelisted / inactive / proof). Blok okamžitý I TRVALÝ →
                # smazat cache, aby se zamítnutý nemohl schovat offline na grace.
                _clear_cache()
                _note_identity(False, str(error or "not_authorized"))
                return AUTH_REJECTED, None

            # Jiné HTTP chyby (429 rate-limit, 5xx server fault) NEJSOU zamítnutí
            # uživatele — transientní problém serveru. Chovej se jako nedostupný
            # server: fallback na lokální kopii (lease → grace), cache NEMAZAT.
            cache = _read_cache()
            if _is_lease_valid(cache):
                _note_identity(True, "lease")
                return AUTH_OK, cache
            if _is_offline_grace_valid(cache):
                _note_identity(True, "grace")
                return AUTH_OK_OFFLINE, cache
            return AUTH_UNREACHABLE, None

        if data.get("status") == "ok":
            data["fetched_at"] = datetime.now(timezone.utc).isoformat()
            # 3.5.130: značky pro `auth_reuse_ok` — komu a jak (online) auth patří.
            data["auth_user"] = ws_username
            data["auth_token_fp"] = _token_fingerprint(ws_token)
            data["auth_addon_version"] = addon_version   # 4.0.1: reuse jen v téže verzi doplňku
            data["auth_online"] = True
            _write_cache(data)
            _log("Auth OK, lease until %s" % data.get("lease_expires", "?"))
            # Profily (3.5.134): mód účtu z Gate → stav profilu (SSOT richmovie_profile).
            try:
                import richmovie_profile
                richmovie_profile.apply_auth_block(data.get("profiles"))
            except Exception as _prof_exc:
                _log("profiles block apply failed: %r" % (_prof_exc,), xbmc.LOGWARNING)
            _note_identity(True, "online")
            return AUTH_OK, data

        # Neočekávaná 200 odpověď se status != ok (Gate posílá zamítnutí jako 403,
        # ne 200 — tohle je defenzivní větev). Zamítnout, ale cache NEMAZAT
        # (purge jen u autoritativního 403 výše — ať ambiguózní 200 nezničí grace).
        _log("Auth rejected (200/non-ok): %s" % data.get("error", "?"), xbmc.LOGWARNING)
        return AUTH_REJECTED, None

    except Exception as exc:
        # Gate NEDOSTUPNÝ (síť/server). Fallback na lokální kopii:
        #   • lease platí (≤72h) → AUTH_OK (plný režim)
        #   • jinak offline-grace (≤30 dní od poslední úspěšné auth) → AUTH_OK_OFFLINE (omezený režim)
        #   • jinak → AUTH_UNREACHABLE (blok)
        # POZN.: grace se aktivuje JEN tady (unreachable), NIKDY nepřebíjí explicitní
        # zamítnutí výše (to cache maže).
        _log("Gate unreachable: %s" % exc, xbmc.LOGWARNING)
        cache = _read_cache()
        if _is_lease_valid(cache):
            _log("Using cached secrets (lease valid until %s)" % cache.get("lease_expires", "?"))
            _note_identity(True, "lease")
            return AUTH_OK, cache
        if _is_offline_grace_valid(cache):
            _log("Offline-grace active (last auth %s, ≤30d) — omezený režim"
                 % cache.get("fetched_at", "?"))
            _note_identity(True, "grace")
            return AUTH_OK_OFFLINE, cache
        _log("No usable cache (lease+grace expired / never authed)", xbmc.LOGWARNING)
        return AUTH_UNREACHABLE, None


# ---------------------------------------------------------------------------
# Status report (fire-and-forget, called from background thread)
# ---------------------------------------------------------------------------
def report_status(
    ws_username: str,
    ws_login_ok: bool = True,
    fs_login_ok: bool | None = None,
) -> None:
    """
    Send login status to Gate. Best-effort — never raises.
    Called from a daemon thread so it doesn't block UI.
    """
    try:
        # Φ3 (2026-08-08): sjednoceno na `gate_transport.post_json()` — hlavičky
        # (včetně povinného User-Agent proti Cloudflare Bot Fight Mode) staví
        # transportní vrstva na jednom místě. `/status` je idempotentní: hlásí
        # aktuální stav přihlášení, takže poslední zápis vyhrává a zopakování
        # nemůže nic pokazit.
        # 3.5.142: `/status` vyžaduje doložení zapisovatele (Gate `_verify_writer`,
        # stejná brána jako user_logs/crash) — bez proof/device by Gate vrátil 403
        # a stav v adminu by zůstal poslední známý. Proof je z nastavení (alias
        # i kanonické jméno ověří Gate proti témuž uloženému hashi).
        _ident_user, _ident_proof = richmovie_gate_transport.get_identity()
        _payload = {
            "ws_username": ws_username,
            "ws_login_ok": ws_login_ok,
            "fs_login_ok": fs_login_ok,
            "ws_proof": _ident_proof,
            "device_hash": richmovie_gate_transport.get_device_hash(),
        }
        # Noc 03.11.2026 (Gate mig 0044): prostředí zařízení — systémový filtr obsahu, HDR schopnosti, autostart.
        # Pole None (služba prostředí ještě nezjistila) se neposílá → Gate sloupec nemění. Starý Gate pole ignoruje.
        try:
            import richmovie_device_env as _denv
            for _k, _v in _denv.telemetry_fields().items():
                if _v is not None:
                    _payload[_k] = _v
        except Exception:
            pass
        try:
            import richmovie_autostart as _auto
            _payload["autostart"] = bool(_auto.enabled())
        except Exception:
            pass
        _status, _data = richmovie_gate_transport.post_json("/status", _payload, timeout=8)
        _log("Status reported: ws=%s fs=%s" % (ws_login_ok, fs_login_ok))
    except Exception as exc:
        _log("Status report failed (best-effort): %s" % exc, xbmc.LOGWARNING)


# ---------------------------------------------------------------------------
# Platform detection (simplified version of richmovie_webshare.py logic)
# ---------------------------------------------------------------------------
def _get_device_hash() -> str:
    """Stabilní per-install device id (uuid4 hex). Deleguje na SSOT
    `richmovie_gate_transport.get_device_hash()` — konsolidováno 2026-06-27 (dřív
    zde byla duplicitní implementace). Jméno zachováno kvůli volání v gate_auth
    payloadu. Použití: per-device custom_ui override + per-device logging (mig 0016)."""
    return richmovie_gate_transport.get_device_hash()


def _detect_platform() -> str:
    """Detect platform string for Gate auth request.

    Deleguje na SSOT `richmovie_gate_transport.detect_platform()` — drive zde byla
    plna (a duplicitni) implementace; konsolidovano 2026-06-23 aby `auth_logs` a
    `user_logs`/telemetrie sdilely jediny zdroj pravdy. Jmeno `_detect_platform`
    zachovano kvuli stavajicimu volani v _post_auth (zpetna kompat)."""
    return richmovie_gate_transport.detect_platform()


# ---------------------------------------------------------------------------
# Accessor functions
# ---------------------------------------------------------------------------
def get_cached_secrets() -> dict | None:
    """Returns cached secrets dict if cache je použitelná (lease NEBO offline-grace),
    None otherwise."""
    cache = _read_cache()
    if _cache_usable(cache):
        return cache.get("secrets")
    return None


def get_tmdb_api_key() -> str:
    """Returns TMDb API key from Gate cache, or empty string."""
    secrets = get_cached_secrets()
    return (secrets or {}).get("tmdb_api_key", "")


def get_titulky_credentials() -> tuple[str, str] | None:
    """Returns (username, password) for Titulky.com, or None."""
    secrets = get_cached_secrets()
    if not secrets:
        return None
    user = secrets.get("titulky_user", "")
    pwd = secrets.get("titulky_pass", "")
    if user and pwd:
        return user, pwd
    return None


def get_permissions() -> dict:
    """Returns permissions dict from cache (lease NEBO offline-grace), or empty defaults."""
    cache = _read_cache()
    if _cache_usable(cache):
        return cache.get("permissions", {})
    return {}


def get_config() -> dict:
    """Config dict z cache (`/auth` → `config`), nebo {} bez použitelné cache."""
    cache = _read_cache()
    if _cache_usable(cache):
        cfg = cache.get("config")
        return cfg if isinstance(cfg, dict) else {}
    return {}


def get_cache_tuning_max_mb() -> int | None:
    """Serverový STROP adaptivní filecache (Φ2, 3.5.128) — `config.cache_tuning_max_mb`.

    Sémantika = POUZE BRZDA: addon dělá `min(network_cap, strop)`. Chybějící klíč
    (starší Gate, nenastavený řádek, nepoužitelná cache) → None = bez clampu.
    Nikdy nezvyšuje, nikdy nepřebíjí `user_custom`."""
    try:
        value = get_config().get("cache_tuning_max_mb")
        if value is None:
            return None
        value = int(value)
        return value if value > 0 else None
    except (TypeError, ValueError):
        return None


def get_fastshare_credentials() -> dict | None:
    """Returns {username, password} for FastShare if permitted, or None."""
    perms = get_permissions()
    if perms.get("fastshare"):
        return perms.get("fastshare_credentials")
    return None


def is_local_filmoteka_allowed() -> bool:
    """Check if current user has local filmotéka permission."""
    return bool(get_permissions().get("local_filmoteka"))


def is_custom_ui_allowed() -> bool:
    """Per-user povolení RM 4.0 custom UI (Netflix-like), řízené z RichMovie Gate.

    Gate vrací v permissions dictu klíč ``custom_ui`` (per-user toggle, jako
    local_filmoteka/ai_enabled — nastavitelné v Gate SQLAdmin).

    FAIL-SAFE = legacy (False). Custom UI se zapne JEN při pozitivním povolení
    z POUŽITELNÉ cache (lease 72h / offline-grace). Rozlišení (incident bandog
    2026-06-24 — fail-open zapnul beta UI + confirm smyčku rodinnému účtu):
      • cache NEpoužitelná (žádný auth / purge na 401-403 / expirovaný lease+grace)
        → False. NIKDY nezapínat beta UI na prázdné cache. (Dřív: chybějící klíč
        v prázdném {} → True = fail-open, kořen incidentu.)
      • cache použitelná, klíč ``custom_ui`` CHYBÍ (authnuto proti starému Gate
        před flagem) → True = zpětná kompat (zachová dnešní chování těch zařízení).
      • cache použitelná, klíč PŘÍTOMEN → respektuj (richiefm/beta=true, rodina=false)."""
    cache = _read_cache()
    if not _cache_usable(cache):
        return False  # bez použitelné cache → fail-safe legacy (žádný fail-open)
    perms = cache.get("permissions", {}) or {}
    if "custom_ui" not in perms:
        return True  # starý Gate bez flagu (cache JE použitelná) → zpětná kompat
    return bool(perms.get("custom_ui"))


def is_debug_logs_enabled() -> bool:
    """Per-user DEBUG logging gate (observability program 2026-07-01).

    Gate vrací v permissions dictu klíč ``debug_logs``
    (users.debug_logs_enabled, default TRUE od mig 0018 = „DEBUG always-on";
    per-user killswitch = admin toggle na FALSE).

    Konzument: bootstrap plugin.py / service_nextup.py →
    richmovie_logging.set_debug(). FAIL-SAFE = False (INFO):
      • cache NEpoužitelná (žádný auth / purge / expirace) → False — bez
        serverového povolení se objem nezvyšuje (guardrail proti floodu
        ze zařízení, které se k Gate nedostane a nemá jak dostat killswitch),
      • klíč ``debug_logs`` CHYBÍ (auth proti staršímu Gate) → False —
        starý Gate nezná per-level drop, DEBUG by nešel server-side vypnout,
      • klíč PŘÍTOMEN → respektuj hodnotu ze serveru.
    Defense-in-depth: Gate /v1/user_logs/batch DEBUG eventy při flagu FALSE
    zahazuje i server-side (okamžitě, bez čekání na další /auth)."""
    cache = _read_cache()
    if not _cache_usable(cache):
        return False
    perms = cache.get("permissions", {}) or {}
    if "debug_logs" not in perms:
        return False
    return bool(perms.get("debug_logs"))


def get_log_pull_request() -> tuple[bool, str]:
    """Vyžádal si admin z tohoto zařízení kodi.log? → (ano/ne, log_pull_id).

    Zdroj: `/auth` → `permissions.log_pull_requested` + `log_pull_id`
    (mig 0019, per-device sloupce v `user_devices`). Konzument:
    `richmovie_diag_upload.start_if_requested()`.

    FAIL-SAFE = (False, ""):
      • cache nepoužitelná (žádný auth / purge / expirace) — bez serverového
        pokynu se nic neodesílá,
      • klíč CHYBÍ (auth proti staršímu Gate) — starý server o funkci neví.

    `log_pull_id` je zároveň jednorázové pověření pro upload bez `ws_proof`:
    zařízení, kterému se rozbilo čtení nastavení, se jinak nemá čím prokázat —
    a právě takové zařízení potřebujeme dostat k logu nejvíc.

    POZOR: tahle cesta vyžaduje funkční `/auth`. Ruční spuštění z menu addonu
    (`run_pull(interactive=True)`) si `log_pull_id` bere z TÉTO cache — Gate bez
    serverem vydaného id upload neautorizuje (3.5.145, cross-check 09.09.2026 F15.1).
    """
    cache = _read_cache()
    if not _cache_usable(cache):
        return False, ""
    perms = cache.get("permissions", {}) or {}
    if "log_pull_requested" not in perms:
        return False, ""
    pull_id = str(perms.get("log_pull_id") or "").strip()
    return bool(perms.get("log_pull_requested")) and bool(pull_id), pull_id


def get_log_archive() -> tuple[bool, dict | None]:
    """Průběžný archiv kodi.log (3.5.155, Gate mig 0034) → (zapnuto, kurzor Gate | None).

    Zdroj: `/auth` → `permissions.kodi_log_archive = {enabled, cursor:{session_key, filename,
    byte_to}}`. Zapnuto = souhlas MAJITELE ÚČTU (Gate) a zařízení se neodhlásilo. Konzument:
    `richmovie_log_archive` (worker služby). FAIL-SAFE = (False, None): cache nepoužitelná
    nebo klíč chybí (starší Gate) → nic se neposílá.
    """
    cache = _read_cache()
    if not _cache_usable(cache):
        return False, None
    perms = cache.get("permissions", {}) or {}
    block = perms.get("kodi_log_archive")
    if not isinstance(block, dict):
        return False, None
    cursor = block.get("cursor")
    return bool(block.get("enabled")), (cursor if isinstance(cursor, dict) else None)


SEARCH_FETCH_PARALLEL_MAX = 6   # = CHECK Gate mig 0043 a strop `richmovie_engine._fetch_wave`


def search_fetch_parallel() -> int | None:
    """Souběžná stažení dotazů jedné vlny hledání na TOMTO zařízení, jak je nastavil správce (Gate mig 0043, S2):
    1–6, nebo None = výchozí podle platformy. Zdroj `/auth` → `permissions.search_fetch_parallel`. FAIL-SAFE = None
    (cache nepoužitelná, klíč chybí u staršího Gate, hodnota mimo rozsah) — nikdy víc, než by zařízení dělalo samo."""
    cache = _read_cache()
    if not _cache_usable(cache):
        return None
    raw = (cache.get("permissions", {}) or {}).get("search_fetch_parallel")
    if isinstance(raw, bool) or not isinstance(raw, int):
        return None
    return raw if 1 <= raw <= SEARCH_FETCH_PARALLEL_MAX else None


def get_auth_fingerprint() -> str:
    """Otisk poslední odpovědi `/auth` (čas načtení) — „spánek do příštího /auth" v archivu
    logu se pozná změnou otisku, ne počítadlem."""
    cache = _read_cache()
    if not isinstance(cache, dict):
        return ""
    return str(cache.get("fetched_at") or "")


def get_smb_config() -> dict:
    """Returns SMB config dict {host, share, user, pass} from Gate cache, or empty."""
    secrets = get_cached_secrets()
    if not secrets:
        return {"host": "", "share": "", "user": "", "pass": ""}
    host = secrets.get("smb_host", "")
    if not host:
        return {"host": "", "share": "", "user": "", "pass": ""}
    return {
        "host": host,
        "share": secrets.get("smb_share", ""),
        "user": secrets.get("smb_user", ""),
        "pass": secrets.get("smb_pass", ""),
    }


def get_config() -> dict:
    """Returns config dict from cache (lease NEBO offline-grace), or empty defaults."""
    cache = _read_cache()
    if _cache_usable(cache):
        return cache.get("config", {})
    return {}


def get_min_version() -> str:
    """Returns minimum required addon version, or empty string."""
    return get_config().get("min_version", "")


def _parse_semver(v: str) -> tuple:
    """Parse a semver-ish string like ``3.2.0-beta.1`` into a comparable tuple.

    Returns ``(major, minor, patch, pre_release_rank, pre_release_num)`` where:
      - pre_release_rank: 3 for GA (no ``-``), 2 for "rc", 1 for "beta", 0 for "alpha"
      - pre_release_num: integer after the suffix (``beta.5`` → 5)
    Numeric ordering means ``3.2.0 > 3.2.0-rc.1 > 3.2.0-beta.2 > 3.2.0-beta.1``.
    Unparseable pieces default to 0 / None so comparison never raises.
    """
    s = (v or "").strip().lower()
    if not s:
        return (0, 0, 0, -1, 0)
    core, _, pre = s.partition("-")
    parts = core.split(".")
    try:
        major = int(parts[0])
    except (ValueError, IndexError):
        major = 0
    try:
        minor = int(parts[1])
    except (ValueError, IndexError):
        minor = 0
    try:
        patch = int(parts[2])
    except (ValueError, IndexError):
        patch = 0
    if not pre:
        return (major, minor, patch, 3, 0)
    pre_rank = 0
    if pre.startswith("rc"):
        pre_rank = 2
    elif pre.startswith("beta"):
        pre_rank = 1
    elif pre.startswith("alpha"):
        pre_rank = 0
    # Extract trailing integer ("beta.5" → 5)
    pre_num = 0
    for token in pre.replace(".", " ").replace("-", " ").split():
        if token.isdigit():
            pre_num = int(token)
            break
    return (major, minor, patch, pre_rank, pre_num)


def version_is_older(current: str, minimum: str) -> bool:
    """True iff ``current`` < ``minimum``. Safe (never raises) for invalid input."""
    if not minimum:
        return False
    try:
        return _parse_semver(current) < _parse_semver(minimum)
    except Exception:
        return False


def is_gate_active() -> bool:
    """Returns True if Gate auth has succeeded (cache je použitelná — lease NEBO offline-grace)."""
    cache = _read_cache()
    return _cache_usable(cache)


def get_gate_url() -> str:
    """Returns Gate base URL (for crash reports etc.)."""
    return _GATE_URL
