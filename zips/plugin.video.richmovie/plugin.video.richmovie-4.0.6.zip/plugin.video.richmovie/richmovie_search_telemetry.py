# -*- coding: utf-8 -*-
"""
richmovie_search_telemetry — měření hledání a výběru streamu pro CELOU flotilu (SSOT).

Proč (výzkum 29.09.2026, agenti E1–E5): flotila uměla říct, JESTLI hledání skončilo přehráním, ale ne
který dotaz / vlna / stránka přehraný stream přinesly, na kterém místě výpisu byl a co filtr zamítl tam,
kde divák odešel s prázdnou. Bez toho nejde žádný dotaz ani vlnu bezpečně zlevnit (pravidlo Richieho:
„nikdy méně nalezených streamů“ → vypnout smíme jen to, co měření prokáže jako bez přínosu).

Co modul dělá:
  • `SearchRun` — sběrač jednoho hledání. Nic neměří sám: POSLOUCHÁ události, které engine a plugin stejně
    píšou do per-search logu (`observe`), takže formát logu ani engine se kvůli měření nemění.
  • `payload()` — jeden řádek `SEARCH_PHASES` do user_logs (fáze v ms, požadavky, výtěžnost dotazů a vln,
    důvody zamítnutí, záchrany, výsledek).
  • snímek výpisu (`build_snapshot`) + `pick_from_snapshot` — pozice a původ streamu, který divák pustil
    (`PLAY_PICK`). Snímek žije ve vlastnosti okna Kodi (přežije invokace pluginu), NE v URL přehrání
    (Kodi podle URL drží záložky a ✔).
Modul je čistý (žádný import `plugin`, `xbmc` jen přes `richmovie_winprops`).
"""
from __future__ import annotations

import json
import threading
import time
import uuid
from typing import Any, Callable, Dict, List, Optional, Sequence

SCHEMA = 1
SNAPSHOT_PROP = "richmovie.listing.snapshot"
SNAPSHOT_MAX_ITEMS = 50           # první obrazovky výpisu; dál divák prakticky nevybírá (E5: vždy top 10)
SNAPSHOT_MAX_AGE_S = 3600         # výběr z výpisu staršího než hodinu už není „výběr z hledání“
REJECT_SAMPLE_MAX_LIST = 3        # D3: vzorek zamítnutých jen když výpis má nejvýš tolik streamů
REJECT_SAMPLE_ROWS = 20
REJECT_NAME_MAX = 80
MAX_QUERY_ROWS = 48               # strop řádků výtěžnosti v jednom hledání (nejdelší kaskáda flotily: 42 dotazů)
MAX_QUERY_CHARS = 60

_LOCK = threading.Lock()
_CURRENT: Optional["SearchRun"] = None


def new_sid() -> str:
    return uuid.uuid4().hex[:12]


def norm_reason(reason: str) -> str:
    """`token_ser_miss_1/2` → `token_ser_miss`, `token_miss_0/2` → `token_miss` (jako replay)."""
    r = str(reason or "")
    if r.startswith("token_ser_miss"):
        return "token_ser_miss"
    if r.startswith("token_miss_"):
        return "token_miss"
    return r


class SearchRun(object):
    """Sběrač jednoho hledání (film, díl, předstažení dílu)."""

    def __init__(self, kind: str, key: str, ctx: str, sid: str = "",
                 clock: Callable[[], float] = time.monotonic) -> None:
        self.sid = sid or new_sid()
        self.kind = kind            # movie | tv
        self.key = key              # movie:<tmdb> | tv:<tv_id>:<S>:<E>
        self.ctx = ctx              # click | prefetch | reentry
        self._clock = clock
        self._t0 = clock()
        self._phase = ""
        self._phase_t0 = self._t0
        self.ms: Dict[str, int] = {}
        self.http = {"ws": 0, "fs": 0}
        self.queries: List[list] = []
        self.waves: List[str] = []
        self._wave = ""
        self.rej: Dict[str, int] = {}
        self.rej_sample: Dict[str, List[str]] = {}     # důvod → první názvy (nejvýš REJECT_SAMPLE_ROWS)
        self.n_raw = 0
        self.n_union = 0
        self.n_acc = 0
        self.cache_hits = 0
        self.errors = 0
        self.observe_errors = 0
        self.cancel = False
        self.rescue: Dict[str, Any] = {}
        self.mi2_reason = ""
        self.searched = False       # proběhlo SEARCH_BEGIN (čerstvé hledání), jinak výpis z cache
        self.outcome = ""           # list | empty | cancelled | error | skt | prefetch | prefetch_empty
        self.n_list = 0             # počet streamů ve vykresleném výpisu
        self.log_path = ""          # per-search log tohoto hledání (řádek SEARCH_PHASES patří do něj)
        self.pool = 0               # S2: největší souběžnost stahování vlny v tomto hledání (0 = nic se nestahovalo)
        self.pool_src = ""          # gate | fallback | android | default (`richmovie_engine._fetch_pool_size`)
        self.pool_fallback = False  # S2: během hledání se zařízení vrátilo na výchozí (429 / paměť)
        # události chodí i z vláken stahování dotazů (`WS_RESULTS`, `FETCH_STATS`…) → čítače pod zámkem
        self._obs_lock = threading.RLock()

    # ------------------------------------------------------------------ fáze
    def mark(self, phase: str) -> None:
        """Začátek fáze (ukončí předchozí). Fáze: tmdb (příprava před hledáním), search (vlny: stažení +
        filtr; rozpad v `fetch` / `filter` z `WAVE_TIMING`), mi2 (čekání na MediaInfo), render, enrich,
        post (zbytek mezi fázemi)."""
        with self._obs_lock:
            now = self._clock()
            if self._phase:
                self.ms[self._phase] = self.ms.get(self._phase, 0) + int((now - self._phase_t0) * 1000)
            self._phase = phase
            self._phase_t0 = now

    def set_wave(self, tag: str) -> None:
        self._wave = str(tag or "")
        if self._wave and self._wave not in self.waves:
            self.waves.append(self._wave)

    # ------------------------------------------------------------------ události
    def observe(self, event: str, params: Sequence[Any]) -> None:
        """Volá `plugin._log_event` pro KAŽDOU událost (parametry v původním tvaru, před doplněním dotazu)."""
        with self._obs_lock:
            try:
                self._observe(event, params)
            except Exception:
                # měření nesmí nikdy shodit hledání; počet chyb sběru jde do výsledku (`obs_err`)
                self.observe_errors += 1

    def _observe(self, event: str, params: Sequence[Any]) -> None:
        if event == "FILTER_REJECT":
            if len(params) >= 2:
                reason = norm_reason(params[1])
                self.rej[reason] = self.rej.get(reason, 0) + 1
                kept = self.rej_sample.setdefault(reason, [])
                if len(kept) < REJECT_SAMPLE_ROWS:
                    kept.append(str(params[-1])[:REJECT_NAME_MAX])
        elif event == "FILTER_ACCEPT":
            self.n_acc += 1
        elif event == "FETCH_STATS":
            d = json.loads(params[0])
            self.http["ws"] += int(d.get("pages") or 0)
            self.http["fs"] += int(d.get("fs_calls") or 0)
        elif event == "WAVE_UNION":
            self.n_raw += int(params[0])
            self.n_union += int(params[1])
        elif event == "WAVE_YIELD":
            for row in json.loads(params[0]):
                if len(self.queries) >= MAX_QUERY_ROWS:
                    break
                self.queries.append([
                    self._wave, str(row.get("q") or "")[:MAX_QUERY_CHARS], int(row.get("ws") or 0),
                    int(row.get("fs") or 0), int(row.get("pages") or 0), int(row.get("new") or 0),
                    int(row.get("acc") or 0), int(row.get("excl") or 0), int(row.get("acc_p2") or 0),
                    int(row.get("ms") or 0),
                ])
        elif event == "SEARCH_BEGIN":
            self.searched = True
            self.mark("search")
        elif event == "SEARCH_END":
            res = params[1] if len(params) > 1 else ""
            if isinstance(res, int) and not isinstance(res, bool):
                self.outcome = "list" if res > 0 else "empty"
            elif str(res) == "CANCELLED":
                self.outcome = "cancelled"
                self.cancel = True
            else:
                self.outcome = "error"
        elif event == "SEARCH_END_SKT":
            self.outcome = "skt"
        elif event == "WAVE_TIMING":
            d = json.loads(params[0])
            self.ms["fetch"] = self.ms.get("fetch", 0) + int(d.get("fetch_ms") or 0)
            self.ms["filter"] = self.ms.get("filter", 0) + int(d.get("filter_ms") or 0)
        elif event == "WAVE_BEGIN":
            d = params[0] if params and isinstance(params[0], dict) else {}
            self.set_wave(d.get("wave") or "")
        elif event == "FETCH_POOL":
            self.pool = max(self.pool, int(params[0]))
            self.pool_src = str(params[1]) if len(params) > 1 else self.pool_src
        elif event == "FETCH_PARALLEL_FALLBACK":
            self.pool_fallback = True
        elif event == "CACHE_HIT":
            self.cache_hits += 1
        elif event in ("WAVE_QUERY_ERR", "FS_ERROR", "WAVE_ERR"):
            self.errors += 1
        elif event == "WAVE_CANCELLED":
            self.cancel = True
        elif event == "SEARCH_FALLBACK":
            self.rescue["alt"] = True
            self.set_wave("ALT")
        elif event == "RESCUE_NUMERIC_OK":
            self.rescue["num"] = int(params[1]) if len(params) > 1 else 1
        elif event == "RESCUE_NUMERIC_EMPTY":
            self.rescue["num"] = 0
        elif event == "RESCUE_NUMERIC_ERR":
            self.rescue["num"] = -1
        elif event == "SKT_FALLBACK":
            self.rescue["skt"] = int(params[0]) if params else 0
        elif event == "MI2_WAIT_END":
            for p in params:
                s = str(p)
                if s.startswith("reason="):
                    self.mi2_reason = s[7:]

    # ------------------------------------------------------------------ výsledek
    def payload(self, n_list: int, outcome: str = "list") -> Dict[str, Any]:
        """Jeden řádek `SEARCH_PHASES`. `outcome`: list | empty | cancelled | error | skt | prefetch."""
        with self._obs_lock:       # po zrušení mohou vlákna stahování ještě dobíhat a hlásit události
            return self._payload_locked(n_list, outcome)

    def _payload_locked(self, n_list: int, outcome: str) -> Dict[str, Any]:
        self.mark("")
        total = int((self._clock() - self._t0) * 1000)
        ms = dict(self.ms)
        ms["total"] = total
        out: Dict[str, Any] = {
            "v": SCHEMA, "sid": self.sid, "kind": self.kind, "key": self.key, "ctx": self.ctx,
            "src": "fresh" if (self.searched and (self.http["ws"] or self.http["fs"])) else "cache",
            "outcome": outcome, "ms": ms, "http": dict(self.http), "waves": list(self.waves),
            "q": [list(row) for row in self.queries], "rej": dict(self.rej), "n_raw": self.n_raw, "n_union": self.n_union,
            "n_acc": self.n_acc, "n_list": int(n_list), "rescue": dict(self.rescue),
            "mi2": self.mi2_reason, "errors": self.errors, "cancel": bool(self.cancel),
            "obs_err": self.observe_errors,
        }
        if self.pool:   # S2 (10.10.2026): souběžnost stahování — jen když se stahovalo (výpis z cache klíče nemá)
            out["pool"] = self.pool
            out["pool_src"] = self.pool_src
            if self.pool_fallback:
                out["pool_fallback"] = True
        if int(n_list) <= REJECT_SAMPLE_MAX_LIST and self.rej_sample and outcome != "cancelled":
            out["rej_sample"] = reject_sample({k: list(v) for k, v in self.rej_sample.items()})
        return out


def reject_sample(by_reason: Dict[str, Sequence[str]], limit: int = REJECT_SAMPLE_ROWS) -> List[list]:
    """Vzorek zamítnutých pro případ „výpis má ≤ 3 streamy“ (D3): důvody podle názvu, roku a zákazu
    rovnoměrně na střídačku; `quick` (přípona / velikost) jen do zbylých míst."""
    out: List[list] = []

    def _round_robin(reasons: List[str]) -> None:
        queues = {r: list(by_reason.get(r) or ()) for r in reasons}
        while len(out) < limit and any(queues.values()):
            for r in reasons:
                if queues[r] and len(out) < limit:
                    out.append([r, queues[r].pop(0)])

    _round_robin(sorted(r for r in by_reason if r != "quick"))
    _round_robin([r for r in by_reason if r == "quick"])
    return out


# ---------------------------------------------------------------------- aktuální hledání procesu
def begin(kind: str, key: str, ctx: str, sid: str = "") -> SearchRun:
    global _CURRENT
    run = SearchRun(kind, key, ctx, sid=sid)
    with _LOCK:
        _CURRENT = run
    return run


def current() -> Optional[SearchRun]:
    return _CURRENT


def end(run: Optional[SearchRun]) -> None:
    global _CURRENT
    with _LOCK:
        if run is not None and _CURRENT is run:
            _CURRENT = None


def observe(event: str, params: Sequence[Any]) -> None:
    run = _CURRENT
    if run is not None:
        run.observe(event, params)


def compact(payload: Dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


# ---------------------------------------------------------------------- snímek výpisu a výběr
def build_snapshot(sid: str, key: str, rels: Sequence[Any], now: Optional[float] = None,
                   mi2_known: Optional[Callable[[str], bool]] = None) -> Dict[str, Any]:
    """Snímek výpisu V POŘADÍ, v jakém ho divák vidí: identy první(ch) obrazovek + původ každého."""
    items = []
    for r in list(rels or [])[:SNAPSHOT_MAX_ITEMS]:
        ident = str(getattr(r, "ident", "") or "")
        known = False
        if mi2_known is not None:
            try:
                known = bool(mi2_known(ident))
            except Exception:
                known = False
        items.append([ident, str(getattr(r, "wave", "") or ""), str(getattr(r, "origin", "") or ""),
                      str(getattr(r, "source", "") or "")[:2], 1 if known else 0])
    return {"v": SCHEMA, "sid": sid, "key": key, "ts": float(time.time() if now is None else now),
            "n": len(list(rels or [])), "items": items}


def pick_from_snapshot(snapshot: Optional[Dict[str, Any]], ident: str, key: str = "",
                       now: Optional[float] = None) -> Dict[str, Any]:
    """Pozice a původ přehrávaného identu ve snímku výpisu. Bez snímku / cizí titul / starý snímek →
    `pos` = 0 (neznámá) a důvod v `why`."""
    out: Dict[str, Any] = {"pos": 0, "n": 0, "sid": "", "wave": "", "origin": "", "mi2": 0, "age_s": -1,
                           "why": ""}
    if not isinstance(snapshot, dict) or not snapshot.get("items"):
        out["why"] = "no_snapshot"
        return out
    out["sid"] = str(snapshot.get("sid") or "")
    out["n"] = int(snapshot.get("n") or 0)
    ts = float(snapshot.get("ts") or 0.0)
    age = (time.time() if now is None else now) - ts
    out["age_s"] = int(age) if ts else -1
    if key and snapshot.get("key") and snapshot.get("key") != key:
        out["why"] = "other_title"
        out["sid"] = ""
        return out
    if ts and age > SNAPSHOT_MAX_AGE_S:
        out["why"] = "stale"
        return out
    for i, it in enumerate(snapshot.get("items") or [], 1):
        if it and it[0] == ident:
            out.update({"pos": i, "wave": it[1], "origin": it[2], "mi2": int(it[4])})
            return out
    out["why"] = "not_in_top"
    return out


def save_snapshot(snapshot: Dict[str, Any]) -> bool:
    try:
        import richmovie_winprops as _wp
        _wp.set_prop(SNAPSHOT_PROP, compact(snapshot))
        return True
    except Exception:
        return False


def load_snapshot() -> Optional[Dict[str, Any]]:
    try:
        import richmovie_winprops as _wp
        raw = _wp.get_prop(SNAPSHOT_PROP)
        return json.loads(raw) if raw else None
    except Exception:
        return None
