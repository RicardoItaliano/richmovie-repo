# -*- coding: utf-8 -*-
"""RichMovie 4.0 — custom home window (WindowXMLDialog) — Φ1 spine.

Plně vlastní UI (NE Kodi reskin). Levý vertikální nav rail (SSOT NAV_DESTINATIONS)
+ hero (auto-bind na #1 rozkoukaný titul) + horizontální poster rails.
XML: resources/skins/default/1080i/RichMovieHome.xml. Estoril Blau.

Φ-R1 (2026-06-12):
  • Home ZŮSTÁVÁ otevřený pod custom okny (Grid/Hub/Detail/Episodes) — Back
    se vždy vrací domů (Netflix stack), žádný flash staré Kodi directory.
  • Klik na nav/dlaždici = okamžitá odezva (busy feedback, child okno ho zavře).
  • Focus fallback SSOT (uc.focus_first): default focus na obsah, který
    EXISTUJE — prázdný rail nikdy nedrží neviditelný focus (mrtvá tlačítka).
  • Chyby kliků viditelné (uc.notify_error), žádné tiché spolknutí.
  • Container destinace přes uc.goto_container (Dialog stack by Container.Update
    schoval pod okna).

Data PŘÍMO z lokálních JSON (žádné importy plugin.py → bez cyklů). Best-effort.
PC vs TV: jeden codepath, runtime flag rm_device (auto-detect, override v settings).
SSOT: richmovie_ui_common (img/load_json/url/focus/busy/notify).
"""
from __future__ import annotations

import urllib.parse

import xbmc
import xbmcgui

import richmovie_ui_common as uc
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.82): UI exception handlery přepnuty
# z přímého xbmc.log na ROUTOVANÝ logger → WARNING z custom UI oken tečou na
# NAS (Gate user_logs). Prefix [RichMovie/Home] v kodi.log doplňuje formatter
# (lokální grepy fungují dál). Fallback = přímý xbmc.log (pipeline nedostupná
# nesmí okno shodit — best-effort, viz richmovie_logging).
try:
    from richmovie_logging import make_legacy_logger as _uiw_make_legacy_logger
    _log = _uiw_make_legacy_logger("richmovie.ui.home", "RichMovie/Home")
except Exception:
    def _log(msg, level=xbmc.LOGWARNING, *, context=None):
        try:
            xbmc.log("[RichMovie/" + "Home] " + str(msg), level)
        except Exception:
            pass

_ADDON_ID = "plugin.video.richmovie"
_XML = "RichMovieHome.xml"
_RES = "1080i"
_BASE = f"plugin://{_ADDON_ID}/"

# ── SSOT navigace (rail) — sekce se přidá/přesune JEN tady ──────────────────
# mode: "win"=RunPlugin custom okno (Home zůstává pod ním) | "container"=Kodi
#       directory přes goto_container | "settings"=OpenSettings | None=Domů.
NAV_DESTINATIONS = [
    {"id": "home",     "label": "Domů",      "mode": None},
    {"id": "search_movie", "label": "Hledat film",   "action": "rm_search", "kind": "movie", "mode": "win"},
    {"id": "search_tv",    "label": "Hledat seriál", "action": "rm_search", "kind": "tv",    "mode": "win"},
    {"id": "ai",       "label": "Pro tebe",  "action": "rm_grid", "feed": "ai_recs", "title": "Pro tebe (AI tipy)", "mode": "win"},
    {"id": "movies",   "label": "Filmy",     "action": "rm_grid", "feed": "browse_movies", "title": "Filmy",   "mode": "win"},
    {"id": "tv",       "label": "Seriály",   "action": "rm_grid", "feed": "browse_tv",     "title": "Seriály", "mode": "win"},
    {"id": "mine",     "label": "Moje",      "action": "rm_hub", "hub": "mine",     "mode": "win"},
    {"id": "sources",  "label": "Zdroje",    "action": "rm_hub", "hub": "sources",  "mode": "win"},
    {"id": "settings", "label": "Nastavení", "mode": "settings"},
]

# Control IDs (sedí s RichMovieHome.xml)
_NAV = 8000
_HERO_PLAY = 7001
_CW = 5001
_AI = 5002
_RECENT = 5003
_EMPTY_SEARCH = 8100
_EMPTY_MOVIES = 8101
_EMPTY_TV = 8102


class RichMovieHomeWindow(uc.RMNavMixin, xbmcgui.WindowXMLDialog):

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._rm_closed = False
        self._hero_cw_key = ""   # klíč položky Pokračovat v hero (Codex C3)

    # ------------------------------------------------------------------ init
    def onInit(self) -> None:
        try:
            self._set_device()
        except Exception:
            pass
        self.setProperty("rm_active", "home")  # persistentní marker aktivní sekce v railu
        # Φ5 (2026-08-08): indikátor offline režimu. Tlumená pilulka v patě railu —
        # obsah se renderuje z uložených dat (Φ4), tohle jen vysvětluje, proč
        # nejsou čerstvé novinky. Žádný dialog, žádná červená.
        try:
            uc.apply_offline_state(self)
        except Exception:
            pass
        # Φ1a: rail + hero + 2 rails (CW, AI). _fill_recent zůstává NEzapojen —
        # Φ3 rozhodnutí (2026-07-06): 3. rail vyžaduje scroll-iteraci layoutu
        # (RichMovieHome.xml je plné: hero 24–344, CW 396–696, AI 748–1048)
        # a hlavní díru řeší cw_advance_episode (seriály už z CW nemizí);
        # „Naposledy sledované seriály" žijí v Hubu Moje (feed=recent_series).
        for fn in (self._build_nav, self._fill_hero, self._fill_cw, self._fill_ai):
            try:
                fn()
            except Exception as exc:
                _log(f"{fn.__name__}: {exc}", xbmc.LOGWARNING)
        # P0-4: první spuštění / prázdný stav — hero i raily prázdné → pravá část
        # obrazovky by byla mrtvá čerň. Zobraz uvítací kartu s CTA.
        try:
            empty = (self.getProperty("rm_hero") != "1"
                     and self.getControl(_CW).size() == 0
                     and self.getControl(_AI).size() == 0)
            self.setProperty("rm_empty", "1" if empty else "")
        except Exception:
            empty = False
        # Default focus: empty-state → CTA „Hledat"; jinak první existující obsah.
        if empty:
            uc.focus_first(self, [_EMPTY_SEARCH, _NAV])
        else:
            uc.focus_first(self, [_HERO_PLAY, _CW, _AI, _NAV])

    def _set_device(self) -> None:
        # SSOT: uc.device_mode (default TV, override settingem rm_device_mode)
        self.setProperty("rm_device", uc.device_mode())

    # ------------------------------------------------------------------ rail
    def _build_nav(self) -> None:
        lst = self.getControl(_NAV)
        for d in NAV_DESTINATIONS:
            li = xbmcgui.ListItem(d["label"])
            li.setProperty("rm_nav_id", d["id"])
            li.setProperty("rm_nav_action", d.get("action") or "")
            li.setProperty("rm_nav_mode", d.get("mode") or "")
            li.setProperty("rm_nav_feed", d.get("feed") or "")
            li.setProperty("rm_nav_title", d.get("title") or "")
            li.setProperty("rm_nav_hub", d.get("hub") or "")
            li.setProperty("rm_nav_kind", d.get("kind") or "")
            lst.addItem(li)

    def _load_cw(self):
        """SSOT čtení Pokračovat — POHLED `richmovie_history.cw_view_load` (4.0.3: za seriál jeden řádek;
        index v odkazu = index v pohledu, stejně jako `plugin._cw_locate`)."""
        try:
            import richmovie_history as hist
            return hist.cw_view_load().get("items") or []
        except Exception:
            return []

    # ------------------------------------------------------------------ hero
    def _fill_hero(self) -> None:
        items = self._load_cw()
        if not items:
            self.setProperty("rm_hero", "")
            return
        it = items[0]
        self._hero_cw_key = uc.cw_key_of(it)
        if it.get("type") == "episode":
            tv = it.get("tv_name") or it.get("title") or "Seriál"
            title = f"{tv}  S{int(it.get('season') or 0):02d}E{int(it.get('episode') or 0):02d}"
        else:
            yr = it.get("year") or ""
            title = f"{it.get('title') or ''}{f'  ({yr})' if yr else ''}"
        pos = float(it.get("position") or 0)
        dur = float(it.get("duration") or 1)
        pct = int((pos / dur) * 100) if dur > 0 else 0
        # w1280 (ne original) — Chromecast/2GB výkon (P1-l)
        fan = uc.img(it.get("backdrop_path"), "w1280") or uc.img(it.get("poster_path"), "w780")
        self.setProperty("rm_hero", "1")
        self.setProperty("rm_hero_title", title)
        self.setProperty("rm_hero_fanart", fan)
        self.setProperty("rm_hero_sub", f"Pokračovat · {pct} %")

    # ------------------------------------------------------------------ rails
    def _fill_cw(self) -> None:
        items = self._load_cw()
        lst = self.getControl(_CW)
        for idx, it in enumerate(items):
            if it.get("type") == "episode":
                tv = it.get("tv_name") or it.get("title") or "Seriál"
                label = f"{tv} S{int(it.get('season') or 0):02d}E{int(it.get('episode') or 0):02d}"
            else:
                yr = it.get("year") or ""
                label = f"{it.get('title') or 'Bez názvu'}{f' ({yr})' if yr else ''}"
            li = xbmcgui.ListItem(label)
            poster = uc.img(it.get("poster_path"))
            if poster:
                li.setArt({"poster": poster, "thumb": poster, "icon": poster})
            li.setProperty("rm_kind", "cw")
            li.setProperty("rm_arg", str(idx))
            li.setProperty("rm_cw_key", uc.cw_key_of(it))
            # 2026-07-07: obohať CW dlaždici o identitu titulu, aby kontextové
            # menu mohlo nabídnout Sezóny a epizody / Detail (dřív jen play/remove)
            _is_ep = it.get("type") == "episode"
            li.setProperty("rm_mtype", "tv" if _is_ep else "movie")
            if _is_ep:
                li.setProperty("rm_tv_id", str(it.get("tv_id") or it.get("tmdb_id") or ""))
                li.setProperty("rm_tv_name", it.get("tv_name") or it.get("title") or "")
            li.setProperty("rm_tmdb", str(it.get("tmdb_id") or it.get("tv_id") or ""))
            lst.addItem(li)

    def _fill_ai(self) -> None:
        # Φ5 SWR (audit A09): bez legacy skin widgetu byla cache zamrzlá navždy
        # (jediný writer byl widget endpoint). Render cache HNED; při stale se
        # na pozadí fetchne nová → rev bump "ai" → on_data_changed rail obnoví.
        try:
            import richmovie_feed as _feed
            _feed.ai_rail_refresh_if_stale()
        except Exception:
            pass
        items = uc.dedup_media(uc.load_json("rail_ai_cache.json").get("items") or [])
        try:
            import richmovie_history as hist
            dismissed = hist.ai_dismissed_ids()
        except Exception:
            dismissed = set()
        lst = self.getControl(_AI)
        for rec in items:
            _rk = (rec.get("kind") or rec.get("media_type") or "movie").lower()
            if "{}:{}".format(_rk, rec.get("tmdb_id")) in dismissed:
                continue  # „už jsem viděl" — skryto z railu
            label = rec.get("title_cs") or rec.get("title") or rec.get("name") or "—"
            li = xbmcgui.ListItem(label)
            poster = uc.img(rec.get("poster_path"), "w500")
            if poster:
                li.setArt({"poster": poster, "thumb": poster, "icon": poster})
            li.setProperty("rm_kind", "ai")
            li.setProperty("rm_tmdb", str(rec.get("tmdb_id") or ""))
            li.setProperty("rm_mtype", (rec.get("kind") or rec.get("media_type") or "movie"))
            lst.addItem(li)

    def _fill_recent(self) -> None:
        """Naposledy sledované seriály z watch_history.json (dedup tv_id),
        poster z rail_series_posters.json cache (plněno rail endpointem)."""
        wh = uc.load_json("watch_history.json")
        eps = wh.get("episodes") or []
        pcache = uc.load_json("rail_series_posters.json")
        lst = self.getControl(_RECENT)
        seen = set()
        for it in eps:
            tid = str(it.get("tv_id") or "")
            if not tid or tid in seen:
                continue
            seen.add(tid)
            name = (it.get("tv_name") or "Seriál").strip()
            li = xbmcgui.ListItem(name)
            entry = pcache.get(tid) or {}
            poster = uc.img(entry.get("p"))
            if poster:
                li.setArt({"poster": poster, "thumb": poster, "icon": poster})
            else:
                li.setArt({"icon": "DefaultTVShows.png", "thumb": "DefaultTVShows.png"})
            li.setProperty("rm_kind", "recent")
            li.setProperty("rm_tv_id", tid)
            li.setProperty("rm_tv_name", name)
            li.setProperty("rm_season", str(int(it.get("season") or 1)))
            lst.addItem(li)
            if len(seen) >= 12:
                break

    # ------------------------------------------------------------------ input
    def onClick(self, controlId: int) -> None:
        try:
            if controlId == _EMPTY_SEARCH:
                # okno NAD Home (Back vrací domů) — konzistentní s nav railem
                xbmc.executebuiltin(f"RunPlugin({_BASE}?action=rm_search)")
            elif controlId == _EMPTY_MOVIES:
                xbmc.executebuiltin(
                    f"RunPlugin({_BASE}?action=rm_grid&feed=browse_movies"
                    f"&title={urllib.parse.quote('Filmy')})")
            elif controlId == _EMPTY_TV:
                xbmc.executebuiltin(
                    f"RunPlugin({_BASE}?action=rm_grid&feed=browse_tv"
                    f"&title={urllib.parse.quote('Seriály')})")
            elif controlId == _NAV:
                self._click_nav()
            elif controlId == _HERO_PLAY:
                if not uc.play_debounce():
                    return  # rychlý dvojklik (P0-2)
                # Φ2: descriptor s plným NavStackem PŘED zavřením Home (close
                # stack vyprázdní → snapshot by byl prázdný = návrat jen na Home)
                uc.mark_play_from_ui()
                # přehrávání → zavřít Home (video nesmí běžet pod dialogem)
                self.close()
                xbmc.executebuiltin(f"RunPlugin({uc.cw_link(0, self._hero_cw_key)})")
            elif controlId in (_CW, _AI, _RECENT):
                self._click_item(controlId)
        except Exception as exc:
            uc.notify_error("Akce se nepodařila spustit.", log_tag="Home")
            _log(f"onClick {controlId}: {exc}", xbmc.LOGWARNING)

    def _click_nav(self) -> None:
        li = self.getControl(_NAV).getSelectedItem()
        if not li:
            return
        mode = li.getProperty("rm_nav_mode")
        nav_id = li.getProperty("rm_nav_id") or "home"
        if mode == "settings":
            xbmc.executebuiltin(f"Addon.OpenSettings({_ADDON_ID})")
            return
        action = li.getProperty("rm_nav_action")
        if not mode or not action:
            return  # Domů — už tu jsme
        qs = {"action": action}
        feed = li.getProperty("rm_nav_feed")
        if feed:
            qs["feed"] = feed
        title = li.getProperty("rm_nav_title")
        if title:
            qs["title"] = title
        hub = li.getProperty("rm_nav_hub")
        if hub:
            qs["hub"] = hub
        kind = li.getProperty("rm_nav_kind")
        if kind:
            qs["kind"] = kind
        url = _BASE + "?" + urllib.parse.urlencode(qs)
        self.setProperty("rm_active", nav_id)
        if mode == "win":
            # custom okno NAD Home (Back vrací domů). Φ2 (29.09.2026): dřívější „busy = okamžitá
            # odezva“ (`busy_open`) Kodi 21 z doplňku ignoruje — odstraněno (audit A10 F4).
            xbmc.executebuiltin(f"RunPlugin({url})")
        else:
            # Kodi directory destinace — dialog stack se musí složit.
            # Φ1: breadcrumb v legacy listingu vede zpět na Home (parent routa).
            uc.goto_container(url, parent_action="home_window")

    def _click_item(self, control_id: int) -> None:
        li = self.getControl(control_id).getSelectedItem()
        if not li:
            return
        kind = li.getProperty("rm_kind")
        if kind == "cw":
            if not uc.play_debounce():
                return  # rychlý dvojklik (P0-2)
            # Φ2: descriptor PŘED zavřením Home (viz hero — snapshot integrita)
            uc.mark_play_from_ui()
            # přehrávání → zavřít Home (video nesmí běžet pod dialogem)
            self.close()
            xbmc.executebuiltin(
                f"RunPlugin({uc.cw_link(li.getProperty('rm_arg'), li.getProperty('rm_cw_key'))})")
        elif kind == "ai":
            tmdb = li.getProperty("rm_tmdb")
            mtype = li.getProperty("rm_mtype") or "movie"
            ttl = li.getLabel()
            if tmdb:
                # Detail NAD Home (Back vrací domů)
                q = urllib.parse.urlencode({"action": "rm_detail", "tmdb_id": tmdb,
                                            "kind": mtype, "title": ttl})
                xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
            else:
                # Φ-NOFLASH (2026-06-13): AI dlaždice bez tmdb → custom AI grid NAD
                # Home (dřív goto_container → Kodi „Doplňky" okno). Konzistentní
                # s hlavním menu „Pro tebe" (rm_grid feed=ai_recs).
                q = urllib.parse.urlencode({"action": "rm_grid", "feed": "ai_recs",
                                            "title": "Pro tebe (AI tipy)"})
                xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
        elif kind == "recent":
            # custom Episodes NAD Home (dřív Container.Update na Kodi listing)
            q = urllib.parse.urlencode({"action": "rm_episodes",
                                        "tv_id": li.getProperty("rm_tv_id"),
                                        "tv_name": li.getProperty("rm_tv_name")})
            xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")

    def on_window_action(self, action) -> None:
        # Back/Stop/device latch řeší uc.RMNavMixin.onAction (Φ1 DRY)
        if action.getId() == xbmcgui.ACTION_CONTEXT_MENU:
            self._context_menu()

    def _refill_rail(self, cid: int, fill_fn) -> None:
        """R3-P1-5 (re-audit): refill railu se ZACHOVÁNÍM selekce — refresh běží
        v onAction téhož stisku, kterým uživatel právě naviguje; holý reset()
        by mu uprostřed interakce skočil na index 0 (klik by otevřel jinou
        dlaždici)."""
        lst = self.getControl(cid)
        pos = -1
        try:
            if self.getFocusId() == cid:
                pos = int(lst.getSelectedPosition())
        except Exception:
            pos = -1
        lst.reset()
        fill_fn()
        try:
            if pos >= 0 and lst.size() > 0:
                lst.selectItem(max(0, min(pos, lst.size() - 1)))
        except Exception:
            pass

    def on_data_changed(self, domains) -> None:
        """Φ5 (audit A09): refresh dirty railů — Home zůstává otevřený pod child
        okny a mutace v nich (CW, ai_seen, nový AI fetch) se dřív nepropsaly."""
        try:
            if "cw" in domains:
                self._refill_rail(_CW, self._fill_cw)
                self._fill_hero()
            if "ai" in domains:
                self._refill_rail(_AI, self._fill_ai)
            if "watch" in domains:   # 3.5.144: watch_history.json se mění i sloučením z jiného zařízení
                self._refill_rail(_RECENT, self._fill_recent)
        except Exception as exc:
            _log(f"on_data_changed: {exc}", xbmc.LOGWARNING)

    def _context_menu(self) -> None:
        """Context menu na dlaždici (long-press/C/pravý klik) — nejčastější akce
        rovnou, bez mezikroku přes Detail."""
        try:
            cid = self.getFocusId()
            if cid not in (_CW, _AI, _RECENT):
                return
            li = self.getControl(cid).getSelectedItem()
            if not li:
                return
            kind = li.getProperty("rm_kind")
            tmdb = li.getProperty("rm_tmdb")
            mtype = li.getProperty("rm_mtype") or "movie"
            label = li.getLabel()

            opts, acts = [], []
            if kind == "cw":
                opts.append("▶ Pokračovat"); acts.append(("cw_play", li.getProperty("rm_arg")))
                opts.append("Přehrát od začátku"); acts.append(("cw_restart", li.getProperty("rm_arg")))
                # 2026-07-07: u seriálu i skok na sezóny/epizody + Detail
                if li.getProperty("rm_mtype") == "tv" and li.getProperty("rm_tv_id"):
                    opts.append("Sezóny a epizody"); acts.append(("episodes", None))
                if tmdb:
                    opts.append("Detail"); acts.append(("detail", None))
                opts.append("Odebrat z Pokračovat"); acts.append(("cw_remove", li.getProperty("rm_arg")))
            elif kind == "recent":
                opts.append("Sezóny a epizody"); acts.append(("episodes", None))
            elif kind == "ai":
                if mtype == "tv":
                    opts.append("Sezóny a epizody"); acts.append(("episodes_ai", None))
                else:
                    opts.append("▶ Vybrat stream"); acts.append(("play_movie", None))
                opts.append("Detail"); acts.append(("detail", None))
                opts.append("+ Můj seznam"); acts.append(("mylist", None))
                opts.append("Už jsem viděl (skrýt tip)"); acts.append(("ai_seen", None))
            if not opts:
                return
            sel = xbmcgui.Dialog().contextmenu(opts)
            if sel < 0:
                return
            self._run_ctx(acts[sel], li, kind, tmdb, mtype, label)
        except Exception as exc:
            uc.notify_error("Akce se nepodařila.", log_tag="Home")
            _log(f"context: {exc}", xbmc.LOGWARNING)

    def _run_ctx(self, act, li, kind, tmdb, mtype, label) -> None:
        name, arg = act
        if name == "cw_play":
            if uc.play_debounce():
                uc.mark_play_from_ui()  # Φ2: PŘED close (snapshot integrita)
                self.close()
                xbmc.executebuiltin(f"RunPlugin({uc.cw_link(arg, li.getProperty('rm_cw_key'))})")
        elif name == "cw_restart":
            if uc.play_debounce():
                uc.mark_play_from_ui()  # Φ2: PŘED close (snapshot integrita)
                self.close()
                xbmc.executebuiltin(
                    f"RunPlugin({uc.cw_link(arg, li.getProperty('rm_cw_key'), restart=True)})")
        elif name == "cw_remove":
            # Φ5 (audit A09): in-process místo race dvou RunPlugin invokerů
            # (cw_remove + reopen Home mohly doběhnout v libovolném pořadí →
            # znovuotevřené Home ukazovalo smazanou položku). Okno zůstává,
            # raily se přeplní na místě (rm_arg indexy se přepočítají).
            try:
                import richmovie_history as hist
                view = hist.cw_view_load().get("items") or []
                key = li.getProperty("rm_cw_key")
                # klíč je pravda (Codex C3): pohled se mezi vykreslením a klikem mohl přeřadit
                idx = next((i for i, v in enumerate(view) if uc.cw_key_of(v) == key), -1) if key else int(arg)
                # 4.0.3: seriál se skryje celý (rozkoukanost dílů zůstává), film se odebere (`cw_dismiss`)
                if 0 <= idx < len(view) and hist.cw_dismiss(view[idx]):
                    self.getControl(_CW).reset()
                    self._fill_cw()
                    self._fill_hero()
            except Exception:
                uc.notify_error("Odebrání se nepodařilo.", log_tag="Home")
        elif name in ("episodes", "episodes_ai"):
            tv_id = li.getProperty("rm_tv_id") or tmdb
            tv_name = li.getProperty("rm_tv_name") or label
            q = urllib.parse.urlencode({"action": "rm_episodes", "tv_id": tv_id, "tv_name": tv_name})
            xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
        elif name == "play_movie" and tmdb:
            import xbmcaddon
            uc.play_picker_first(
                xbmcaddon.Addon(_ADDON_ID), action="auto",
                poster=li.getArt("poster"), title=label, tmdb=tmdb)
        elif name == "detail" and tmdb:
            q = urllib.parse.urlencode({"action": "rm_detail", "tmdb_id": tmdb,
                                        "kind": mtype, "title": label})
            xbmc.executebuiltin(f"RunPlugin({_BASE}?{q})")
        elif name == "mylist" and tmdb:
            try:
                import richmovie_history as hist
                now_in = hist.my_list_toggle(tmdb_id=tmdb, kind=mtype, title=label)
                _rm_notif(
                    "Přidáno do Mého seznamu" if now_in else "Odebráno",
                    xbmcgui.NOTIFICATION_INFO,
                    2000,
                    "RichMovie",
                    sound=False,
                )
            except Exception:
                pass
        elif name == "ai_seen" and tmdb:
            try:
                import richmovie_history as hist
                hist.ai_dismiss(tmdb, mtype)
                # refresh AI railu — dismissed se odfiltruje (ControlList nemá
                # removeItem, takže reset + znovu naplnit)
                self.getControl(_AI).reset()
                self._fill_ai()
                _rm_notif("Tip skryt", xbmcgui.NOTIFICATION_INFO, 1500, "RichMovie", sound=False)
            except Exception:
                pass

    def close(self):  # noqa: A003 — Kodi API jméno
        self._rm_closed = True
        super().close()


def open_home(addon) -> None:
    """Otevře custom home okno. Best-effort."""
    try:
        w = RichMovieHomeWindow(_XML, addon.getAddonInfo("path"), "default", _RES)
        _nav_id = uc.nav_push("home_window")  # Φ1 NavStack (finally = integrita)
        try:
            w.doModal()
        finally:
            uc.nav_remove(_nav_id)
        w._rm_closed = True
        del w
    except Exception as exc:
        _log(f"open_home selhalo: {exc}", xbmc.LOGWARNING)
        try:
            _rm_notif("Nový vzhled se nepodařilo otevřít.", xbmcgui.NOTIFICATION_INFO, 5000, "RichMovie")
        except Exception:
            pass
