# -*- coding: utf-8 -*-
"""
RichMovie NetState — SSOT stavu síťové konektivity pro celý addon.

PROČ TENHLE MODUL EXISTUJE
--------------------------
Addon do 08.08.2026 neměl ponětí o tom, jestli zařízení vůbec je online. Důsledky:

    • Každý modul čekal na svůj vlastní timeout. Uživatel na mrtvé Wi-Fi zaplatil
      5 sekund zmrzlého UI za KAŽDÉ volání, protože nikdo nikde neevidoval, že
      předchozí tři requesty selhaly ze stejného důvodu.
    • Offline-grace (3.4.11) sice existovala, ale property ``richmovie.offline_mode``
      se jen zapisovala (``plugin.py:5306``) a mazala (``:5321``) — **nikdo ji nečetl**.
      Uživatel tedy o omezeném režimu nevěděl a UI se podle něj nechovalo.

Tenhle modul je jediná autorita na otázku „jsme online?". Stav se drží ve
``Window(10000)`` properties, takže ho vidí všechny plugin invokery i služba
(stejný IPC vzor, jaký addon používá pro ``richmovie.rev.*`` nebo streams lifecycle).

TŘI STAVY
---------
    ONLINE     poslední kontakt se sítí vyšel
    DEGRADED   něco selhalo, ale ještě nevíme, jestli je to síť nebo jeden server
    OFFLINE    zařízení je bez konektivity → transport fail-fastuje bez pokusu o síť

JAK SE POZNÁ „SÍŤ JE DOLE" OD „JEDEN SERVER JE DOLE"
----------------------------------------------------
Naivní pravidlo „3 selhání = offline" by shodilo celý addon do offline režimu pokaždé,
když je dole jeden scraper (SOSAC umí být mrtvý týden), zatímco Gate i Webshare běží.
Proto se rozhoduje ze dvou nezávislých signálů:

    1. **Víc různých hostů** — ≥3 selhání a ≥2 různé domény. Když nefunguje Gate
       *i* Webshare, není to náhoda serveru.
    2. **Typ chyby** — ``ENETUNREACH``/``ENETDOWN``/``EHOSTUNREACH`` a DNS selhání
       nejsou výroky o serveru, ale o lokální síti. „Nemám routu" nemůže poslat
       vzdálený stroj. Dvě takové chyby stačí, i kdyby byly ze stejné domény.

Bod 2 je v praxi ten důležitý: veškerý provoz addonu kromě BYOC zdrojů teče přes
jediný host ``gate.svcnode.org``, takže na bod 1 by se u běžného prohlížení nedošlo.

Naopak HTTP 429 se jako selhání **nepočítá vůbec** — server odpověděl, síť tedy
funguje. Kdyby se počítal, tři rate-limity by addon odstřihly od všeho, což je přesný
opak toho, co po incidentu 12.07.2026 chceme.

Python 3.8 kompat (Kodi bundled CPython).
"""

from __future__ import annotations

# ──────────────  STANDARD LIBRARY  ──────────────
import json
import threading
import time
from typing import Any, Dict, Optional

# ──────────────  KODI API  ──────────────
# Modul musí být importovatelný i mimo Kodi (offline harness Φ6).
try:
    import xbmc  # type: ignore
except Exception:  # pragma: no cover
    xbmc = None  # type: ignore

try:
    import xbmcgui  # type: ignore
except Exception:  # pragma: no cover
    xbmcgui = None  # type: ignore

# ──────────────  RICHMOVIE  ──────────────
try:
    from richmovie_logging import make_legacy_logger as _make_legacy_logger
    _log = _make_legacy_logger("richmovie.netstate", "RichMovie/NetState")
except Exception:  # pragma: no cover
    def _log(msg, level=1, *, context=None):
        # type: (str, int, Optional[Dict[str, Any]]) -> None
        try:
            if xbmc is not None:
                xbmc.log("[RichMovie/NetState] %s" % msg, level)
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Stavy
# --------------------------------------------------------------------------- #
STATE_ONLINE = "online"
STATE_DEGRADED = "degraded"
STATE_OFFLINE = "offline"

# --------------------------------------------------------------------------- #
# Window(10000) properties — IPC mezi plugin invokery a službou
# --------------------------------------------------------------------------- #
_PROP_STATE = "richmovie.net.state"
_PROP_SINCE = "richmovie.net.since"
_PROP_FAILS = "richmovie.net.fails"
_PROP_PROBE_NEXT = "richmovie.net.probe_next"
_PROP_PROBE_STEP = "richmovie.net.probe_step"
_PROP_GRACE = "richmovie.offline_mode"   # zpětná kompatibilita s 3.4.11

# --------------------------------------------------------------------------- #
# Prahy
# --------------------------------------------------------------------------- #
# Selhání starší než tohle okno se zapomínají. Krátká paměť je záměr: chceme
# odpovědět na otázku „jsme offline TEĎ", ne „měli jsme dnes výpadek".
_FAIL_WINDOW_S = 120.0

# Cesta A — víc různých hostů (viz docstring modulu).
_OFFLINE_MULTIHOST_STREAK = 3
_OFFLINE_MULTIHOST_DISTINCT = 2

# Cesta B — chyby, které může vyrobit jen lokální síť.
_OFFLINE_LOCAL_STREAK = 2

# Backoff zdravotní sondy. Začíná svižně (výpadek Wi-Fi bývá otázka sekund), ale
# rychle se prodlužuje, aby zařízení v letadle nebušilo do sítě každých 5 s celou noc.
_PROBE_BACKOFF_S = (5.0, 15.0, 30.0, 60.0)

# Sonda musí být rychlá — běží v service tiku a nesmí ho zdržet.
_PROBE_TIMEOUT_S = 4.0

# In-process zámek. Window properties nejsou atomické; tohle drží konzistenci
# aspoň v rámci jednoho procesu (MediaInfo workery jedou v 5 vláknech naráz).
_lock = threading.Lock()

# Přístup k `Window(10000)` + fallback mimo Kodi (harness) je od 3.5.118 SSOT
# v `richmovie_winprops` — dřív tu byla vlastní kopie `_win/_get_prop/_set_prop`,
# kterou by `richmovie_identity_state` musel duplikovat. Aliasy drží původní
# jména, aby zbytek modulu zůstal beze změny (harness Φ6 ho pokrývá 67 asercemi).
from richmovie_winprops import (  # noqa: E402
    clear_prop as _clear_prop,
    get_prop as _get_prop,
    set_prop as _set_prop,
)
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# get_state  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def get_state():
    # type: () -> str
    """Aktuální stav konektivity. Výchozí (nic se ještě nestalo) je ONLINE.

    Optimistický výchozí stav je záměr: dokud nemáme důkaz o výpadku, nesmíme
    uživateli omezovat funkce. Pesimistický start by po každém restartu Kodi na
    chvíli vypnul síť, dokud by ji něco „nepovolilo".
    """
    value = _get_prop(_PROP_STATE, STATE_ONLINE)
    return value if value in (STATE_ONLINE, STATE_DEGRADED, STATE_OFFLINE) else STATE_ONLINE


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# state_since  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def state_since():
    # type: () -> float
    """Unixový čas, kdy addon vstoupil do aktuálního stavu (0 = neznámo).

    Používá UI (Φ5) pro rozhodnutí, jestli má cenu hlásit „jsme offline" —
    dvousekundový výpadek při přepínání AP nikoho zajímat nemusí.
    """
    try:
        return float(_get_prop(_PROP_SINCE, "0") or 0)
    except Exception:
        return 0.0


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# is_offline  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def is_offline():
    # type: () -> bool
    """True, když je addon v offline režimu (breaker otevřen NEBO auth grace).

    Sjednocuje dva dřív nezávislé signály: náš breaker a offline-grace z ``/auth``
    (3.4.11). Pro UI je to jedna a tatáž informace — „jedeme z uložených dat".
    """
    if get_state() == STATE_OFFLINE:
        return True
    return _get_prop(_PROP_GRACE, "") == "1"


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# allow_request  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def allow_request(probe=False):
    # type: (bool) -> bool
    """Smí transport zkusit síť?

    Ve stavu OFFLINE vrací False — a to je celý pocitový rozdíl pro uživatele:
    místo pěti sekund zmrzlého UI dostane odpověď do jednotek milisekund a addon
    může okamžitě sáhnout po uložených datech.

    Args:
        probe: True u zdravotní sondy. Ta musí projít i otevřeným breakerem,
               jinak by se stav nikdy nemohl vrátit na ONLINE (klasická past
               circuit breakeru, který si sám zavře cestu k zotavení).

    Returns:
        True = zkus to; False = jsme offline, nezkoušej.
    """
    if probe:
        return True
    return get_state() != STATE_OFFLINE


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# _os_filter_active  (vytvořeno: 03.11.2026 21:20 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _os_filter_active():
    # type: () -> bool
    """Stojí v cestě systémový filtr obsahu? SSOT `richmovie_device_env.filtered()`; chyba = ne (beze změny chování)."""
    try:
        import richmovie_device_env as _denv
        return bool(_denv.filtered())
    except Exception:
        return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# _load_fails / _store_fails  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _load_fails():
    # type: () -> Dict[str, Any]
    """Načte evidenci posledních selhání z Window property.

    Tvar: ``{"events": [[ts, host, local_bool], ...]}``. Držíme seznam, ne jen
    čítač, protože potřebujeme odpovědět na dvě různé otázky (kolik různých hostů,
    kolik lokálních chyb) a obě s časovým oknem.
    """
    raw = _get_prop(_PROP_FAILS, "")
    if not raw:
        return {"events": []}
    try:
        data = json.loads(raw)
        if isinstance(data, dict) and isinstance(data.get("events"), list):
            return data
    except Exception:
        pass
    return {"events": []}


def _store_fails(data):
    # type: (Dict[str, Any]) -> None
    """Uloží evidenci selhání. Ořezává na 20 záznamů (víc k rozhodnutí netřeba)."""
    try:
        events = list(data.get("events") or [])[-20:]
        _set_prop(_PROP_FAILS, json.dumps({"events": events}))
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# report_success  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def report_success(host=""):
    # type: (str) -> None
    """Ohlásí úspěšný kontakt se sítí — jediná cesta zpátky do ONLINE.

    Vymaže evidenci selhání celou, ne jen pro daný host: když projde jeden
    request, síť prokazatelně funguje, a starší selhání jiných hostů už o stavu
    konektivity nic nevypovídají (byly to výpadky serverů, ne linky).
    """
    with _lock:
        previous = get_state()
        _store_fails({"events": []})
        if previous != STATE_ONLINE:
            _enter_state(STATE_ONLINE, reason="uspesny request", host=host)
        _set_prop(_PROP_PROBE_STEP, "0")
        _set_prop(_PROP_PROBE_NEXT, "0")


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# report_failure  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def report_failure(err_class, host="", local=False):
    # type: (str, str, bool) -> None
    """Ohlásí neúspěšný pokus o spojení a případně překlopí stav.

    Args:
        err_class: Třída z ``richmovie_http.classify()``. Jiná než ``transient``
                   se ignoruje — trvalá chyba (404, TLS) o konektivitě nic neříká
                   a rate-limit dokonce dokazuje, že síť funguje.
        host:      Doména, na které se to stalo (rozlišení „síť" vs „jeden server").
        local:     True, když chyba může pocházet jen z lokální sítě
                   (``ENETUNREACH`` a spol., DNS) — viz docstring modulu.
    """
    if err_class != "transient":
        return

    with _lock:
        now = time.time()
        data = _load_fails()
        events = [e for e in (data.get("events") or [])
                  if isinstance(e, (list, tuple)) and len(e) >= 3
                  and (now - float(e[0])) <= _FAIL_WINDOW_S]
        events.append([now, str(host or ""), bool(local)])
        _store_fails({"events": events})

        streak = len(events)
        distinct_hosts = len({str(e[1]) for e in events if e[1]})
        local_count = sum(1 for e in events if bool(e[2]))

        multihost_trip = (streak >= _OFFLINE_MULTIHOST_STREAK
                          and distinct_hosts >= _OFFLINE_MULTIHOST_DISTINCT)
        local_trip = local_count >= _OFFLINE_LOCAL_STREAK

        # Noc 03.11.2026 (Φ1, Bětčin Mac): přes systémový filtr obsahu (`richmovie_device_env.filtered`)
        # vypadají timeouty na několika hostech stejně jako výpadek sítě, ale síť jede — filtr jen zdržuje.
        # „Více hostů“ proto při filtru NENÍ důkaz offline (jinak fail-fast odřízne Webshare, TMDb i kolekce).
        # Lokální chyby (DNS, ENETUNREACH) vznikají PŘED filtrem → dál platí.
        if multihost_trip and not local_trip and _os_filter_active():
            multihost_trip = False
            _log("NETSTATE_FILTERED streak=%d hosts=%d — selhání přes systémový filtr, ne výpadek sítě"
                 % (streak, distinct_hosts), 1)

        if multihost_trip or local_trip:
            if get_state() != STATE_OFFLINE:
                _enter_state(
                    STATE_OFFLINE,
                    reason=("lokalni sit" if local_trip else "vice hostu"),
                    host=host, streak=streak, distinct_hosts=distinct_hosts,
                    local_count=local_count,
                )
                # Sondu naplánuj hned na první krok backoffu, ne až za minutu.
                _set_prop(_PROP_PROBE_STEP, "0")
                _set_prop(_PROP_PROBE_NEXT, str(now + _PROBE_BACKOFF_S[0]))
        elif get_state() == STATE_ONLINE:
            _enter_state(STATE_DEGRADED, reason="prvni selhani", host=host,
                         streak=streak)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# _enter_state  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _enter_state(state, reason="", host="", **extra):
    # type: (str, str, str, Any) -> None
    """Přepne stav, zaloguje přechod a při návratu na ONLINE probudí UI.

    Volá se VÝHRADNĚ zevnitř modulu pod ``_lock``. Log úrovně WARNING u OFFLINE
    je záměr — přesně tenhle záznam v ``user_logs`` odpoví na otázku „jak často
    a komu vypadává síť", kterou jsme do 08.08.2026 neuměli zodpovědět vůbec.
    """
    previous = get_state()
    if previous == state:
        return

    _set_prop(_PROP_STATE, state)
    _set_prop(_PROP_SINCE, str(time.time()))

    context = {"state": state, "previous": previous, "reason": reason,
               "host": host or ""}
    try:
        context.update({k: v for k, v in extra.items() if v is not None})
    except Exception:
        pass

    if state == STATE_OFFLINE:
        _log("NETSTATE_OFFLINE duvod=%s host=%s" % (reason, host or "-"),
             xbmc.LOGWARNING if xbmc else 2, context=context)
    elif state == STATE_ONLINE:
        _log("NETSTATE_RECOVERED z=%s duvod=%s" % (previous, reason),
             xbmc.LOGINFO if xbmc else 1, context=context)
        if previous == STATE_OFFLINE:
            _wake_ui_after_recovery()
    else:
        _log("NETSTATE_DEGRADED host=%s" % (host or "-"),
             xbmc.LOGINFO if xbmc else 1, context=context)


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# _wake_ui_after_recovery  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _wake_ui_after_recovery():
    # type: () -> None
    """Po návratu online řekne UI, že se má překreslit z čerstvých dat.

    Používá stávající mechanismus ``ui_common.data_rev_bump()`` — tentýž, kterým
    si RM 4.0 okna hlídají změny „Pokračovat", zhlédnutých a AI doporučení. Žádný
    nový signál se nezavádí: obrazovky, které už umí reagovat na změnu revize, se
    obnoví samy a ostatní to ignorují.

    Best-effort. Když se nepovede, uživatel prostě uvidí čerstvá data až při
    dalším vstupu do sekce — což je pořád lepší než dnešní stav.
    """
    try:
        import richmovie_ui_common as _uc
        for domain in getattr(_uc, "DATA_REV_DOMAINS", ()):
            try:
                _uc.data_rev_bump(domain)
            except Exception:
                pass
    except Exception:
        pass

    # Jednorázový nenápadný toast. Uživatel, který zrovna kouká na uloženou
    # nabídku, se má dozvědět, že je zase živá — ale jen jednou a bez blokování.
    # Nikdy se nezobrazuje během přehrávání: přerušit film hláškou „zpět online"
    # by bylo přesně to obtěžování, kterému se tahle práce vyhýbá.
    try:
        if xbmc is not None and xbmc.getCondVisibility("Player.HasVideo"):
            return
    except Exception:
        pass
    try:
        if xbmcgui is not None:
            _rm_notif("Připojení obnoveno", xbmcgui.NOTIFICATION_INFO, 3000, "RichMovie")
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# note_auth_offline_grace  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def note_auth_offline_grace(active):
    # type: (bool) -> None
    """Zaznamená, že ``/auth`` jede na offline-grace (Gate nedostupný, lease platí).

    Do 08.08.2026 se property ``richmovie.offline_mode`` sice nastavovala, ale nikdo
    ji nečetl. Nechávám ji zapisovat pod původním jménem kvůli zpětné kompatibilitě
    (a protože ji čte admin diagnostika), ale autoritou pro UI je od teď
    ``is_offline()``, které kombinuje grace i breaker.
    """
    try:
        if active:
            _set_prop(_PROP_GRACE, "1")
        else:
            _clear_prop(_PROP_GRACE)
    except Exception:
        pass


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# probe_now  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def probe_now(timeout_s=_PROBE_TIMEOUT_S):
    # type: (float) -> bool
    """Zdravotní sonda na Gate ``/health``. True = síť je zpátky.

    Jde vědomě na Gate, ne na obecný internet: kdyby byl dostupný internet, ale ne
    náš server, přepnutí na ONLINE by uživateli nepomohlo — addon stejně potřebuje
    Gate. Sonda běží s ``probe=True``, takže projde otevřeným breakerem.

    Výjimka (3.5.151, Fable F1/N4): navázání přehrávání Gate NEPOTŘEBUJE (resolve jde na
    Webshare/Fastshare, stream na jejich CDN). Služba proto před navázáním sonduje CDN
    streamu (``richmovie_webshare.validate_stream_link(probe=True)``, rozhodnutí
    ``richmovie_resume.resume_route``) a úspěšná odpověď CDN přepne netstate do ONLINE
    i při nedostupném Gate — v souladu s ``report_success`` („síť prokazatelně funguje").
    Tahle funkce zůstává sondou Gate; pro navázání je jen druhou volbou, když CDN mlčí.

    Jeden pokus, žádný retry (``max_attempts=1``) — od opakování je tu backoff
    v ``recovery_tick()``; dvojité opakování by jen prodloužilo service tik.

    Returns:
        True při HTTP 200, jinak False. Nikdy nevyhodí.
    """
    try:
        import richmovie_http as _http
        from richmovie_gate_transport import GATE_URL as _gate_url

        profile = _http.RetryProfile("probe", budget_s=timeout_s + 1.0,
                                     timeout_s=timeout_s, max_attempts=1)
        status, _body, _headers = _http.request(
            "%s/health" % _gate_url, profile=profile, tag="netprobe", probe=True,
        )
        return int(status) == 200
    except Exception:
        return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# recovery_tick  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def recovery_tick():
    # type: () -> bool
    """Jeden krok automatického zotavení. Volá ``service_nextup`` ve své smyčce.

    PROČ NE VLASTNÍ VLÁKNO: služba už tiká každých 5 s a má korektní abort
    handling. Další vlákno by znamenalo další objekt, který se musí správně
    ukončit v pětisekundovém okně, které Kodi dává na shutdown (viz memory
    ``feedback_daemon_threads_kodi`` — daemon vlákna s HTTP jsou v Kodi zakázaná).
    Tik je levný: mimo OFFLINE stav se okamžitě vrátí.

    Backoff 5 → 15 → 30 → 60 s. Zařízení, které leží celou noc bez sítě, se tak
    ptá jednou za minutu, ne dvanáctkrát.

    Returns:
        True, pokud sonda právě obnovila spojení (užitečné pro testy a log).
    """
    if get_state() != STATE_OFFLINE:
        return False

    now = time.time()
    try:
        due = float(_get_prop(_PROP_PROBE_NEXT, "0") or 0)
    except Exception:
        due = 0.0
    if now < due:
        return False

    try:
        step = int(_get_prop(_PROP_PROBE_STEP, "0") or 0)
    except Exception:
        step = 0

    if probe_now():
        with _lock:
            _store_fails({"events": []})
            _enter_state(STATE_ONLINE, reason="sonda /health")
            _set_prop(_PROP_PROBE_STEP, "0")
            _set_prop(_PROP_PROBE_NEXT, "0")
        return True

    next_step = min(step + 1, len(_PROBE_BACKOFF_S) - 1)
    _set_prop(_PROP_PROBE_STEP, str(next_step))
    _set_prop(_PROP_PROBE_NEXT, str(now + _PROBE_BACKOFF_S[next_step]))
    return False


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# snapshot  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def snapshot():
    # type: () -> Dict[str, Any]
    """Kompletní stav pro diagnostiku, UI a testy.

    Sestavuje se ze stejných properties, jaké čte zbytek addonu — žádný paralelní
    zdroj pravdy, který by se mohl rozejít.
    """
    since = state_since()
    fails = _load_fails().get("events") or []
    return {
        "state": get_state(),
        "since": since,
        "age_s": round(time.time() - since, 1) if since else None,
        "offline": is_offline(),
        "auth_grace": _get_prop(_PROP_GRACE, "") == "1",
        "recent_failures": len(fails),
        "distinct_hosts": len({str(e[1]) for e in fails
                               if isinstance(e, (list, tuple)) and len(e) >= 2 and e[1]}),
    }


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_netstate.py
# reset  (vytvořeno: 08.08.2026 11:40 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def reset():
    # type: () -> None
    """Vrátí stav do výchozího ONLINE a zahodí evidenci selhání.

    Určeno pro offline harness (Φ6), aby scénáře nezačínaly se stavem po
    předchozím testu. V produkci se nevolá.
    """
    with _lock:
        _set_prop(_PROP_STATE, STATE_ONLINE)
        _set_prop(_PROP_SINCE, str(time.time()))
        _set_prop(_PROP_PROBE_STEP, "0")
        _set_prop(_PROP_PROBE_NEXT, "0")
        _store_fails({"events": []})
