# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 RichMovie – Vyhledávací a filtrační **ENGINE**
───────────────────────────────────────────────────────────────────────────────
Tento modul koncentruje *veškeré* know‑how doplňku RichMovie týkající se:

  • sestavení dotazů a paralelního volání API Webshare.cz  
  • heuristické filtrace a rankingu releaseů (kvalita, velikost, délka filmu)  
  • deduplikace a označení ★ MATCH (±5 min od cílové stopáže)  
  • parsování jazyků, bitrate a normalizace názvů  
  • čisté datové objekty → **žádná** závislost na Kodi!  
    (GUI si řeší až plugin.py pomocí `LabelFormatter`).

Při refaktoru (06/2025) jsme zachovali 100 % původní logiku i výstupní formát,
pouze kód rozdělili na srozumitelné třídy:

* `SearchEngine` – orchestrace dotazů; veřejné API `search_one()` a `search_wave()`  
* `ReleaseFilter` – statická pravidla pro vyřazení/obohacení WS souborů  
* `LabelFormatter` – převod `Release` → slovník s texty pro GUI  
* pomocné util‑funkce `norm()`, `base_title_key()`, `quality()`, `parse_langs()`

Autor: Richie (2023–2025), refaktor © VİÝVOJ  
Licence: MIT
═══════════════════════════════════════════════════════════════════════════════
"""

# ─────────────────────────────────────────────────────────────────────────────
#  IMPORTY
# ─────────────────────────────────────────────────────────────────────────────
from __future__ import annotations

# — Standard lib —
import concurrent.futures as _f
import datetime
import functools  
import json
import os
import random
import re
import threading
import time
import unicodedata
from dataclasses import asdict, dataclass, field, fields as _dc_fields
from typing import TYPE_CHECKING, Any, Callable, Iterable, List, Optional, Sequence, Tuple

if TYPE_CHECKING:  # jen pro anotace (Φ5A: pyflakes „undefined name“ brána bez výjimek)
    from richmovie_fastshare import FastshareClient  # noqa: F401

from collections.abc import Callable  # přidejte jednou mezi importy
from collections import OrderedDict        # pořadí bez duplicit v QueryBuilder





# – Kodi GUI (pouze pro _SearchProgress) –
import xbmcgui  # type: ignore
import xbmcaddon  # type: ignore
import xbmcvfs    # type: ignore
import xbmc      # type: ignore  # PRIORITA A: abortRequested/Android detekce

# – Lokální moduly –
from richmovie_helpers import SEARCH_CACHE         # ← NOVÝ modul
import richmovie_quality as _rm_quality            # Φ-D (30.09.2026): SSOT kvality (štítek = třída řazení)
import richmovie_winprops as _winprops             # S2 (10.10.2026): Window(10000) jen přes SSOT (audit Fable F-2)
from richmovie_webshare import (
    PAGE_SIZE as WS_PAGE_SIZE,
    RateLimited as WsRateLimited,
    WebshareClient,
)

from tmdb_client import TMDb, TMDbError
from richmovie_helpers import net_error_message  # Φ2: česká věta místo technického textu
from richmovie_helpers import notif as _rm_notif  # Φ2 (29.09.2026): SSOT toastů (zvuk, délka)

# ---------------------------------------------------------------------------
# Observability program 2026-07-02 (3.5.83): diagnosticky logger pro dřív
# TICHÁ except místa (spin_tokens heuristika, probe futures, tip-state I/O).
# Event log self._log (per-search soubor) zůstává NEDOTČEN — tohle je druhý,
# NAS-routovaný kanál pro problémy. Fallback = no-op (engine nesmí spadnout
# kvůli diagnostice; best-effort filozofie).
try:
    from richmovie_logging import make_legacy_logger as _eng_make_legacy_logger
    _diag_log = _eng_make_legacy_logger("richmovie.engine", "RichMovie/Engine")
except Exception:
    def _diag_log(msg, level=1, *, context=None):
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  DALŠÍ KONSTANTY
# ─────────────────────────────────────────────────────────────────────────────
# Slova, která se ve jménech epizod vyskytují extrémně často a sama o sobě
# nejsou pro vyhledávání směrodatná („Episode 1“, „Pilot“, „Úvod“ apod.).
GENERIC_EP: set[str] = {
    # — anglicky —
    "episode", "ep", "pilot", "part", "chapter", "segment", "beginning", "start",
    # — česky/slovensky —
    "epizoda", "pilotní", "pilotni", "díl", "dil", "část", "cast",
    "úvod", "uvod", "od", "zacatek", "začátek", "zacatku", "začátku",
    # — další jazyky (běžné “Episode 1”) —
    "capitulo", "capitolo",
}


def _pool_size(requested: int) -> int:
    """Vraci pool size omezeny na 2 workery na Androidu (prevence OOM/CPU saturation)."""
    try:
        if xbmc.getCondVisibility("system.platform.android"):
            return max(1, min(2, requested))
    except Exception:
        pass
    return requested


# ── S2 (10.10.2026, Gate mig 0043): souběžnost STAHOVÁNÍ dotazů vlny hledání per zařízení ─────────────────────────
# Vlna hledání stahuje dotazy souběžně, filtr běží JEDNOU nad sjednocením (Φ-B) — Androidí strop 2 (21.02.2026) vznikl
# kvůli CPU filtru ×N, který už neběží. Kolik smí konkrétní zařízení, nastaví správce na Gate (A/B na jednom zařízení,
# rozhodnutí Richieho 10.10.2026); výchozí chování flotily se NEMĚNÍ. Když zařízení s vyšší souběžností narazí na
# brzdění Webshare (HTTP 429) nebo na nedostatek paměti, vrátí se samo na výchozí na `FETCH_FALLBACK_S`.
FETCH_PARALLEL_MAX = 6
ANDROID_FETCH_DEFAULT = 2
FETCH_FALLBACK_S = 24 * 3600.0
_FETCH_FALLBACK_PROP = "richmovie.search.fetch_fallback_until"   # time.time() konce návratu (Window(10000), Kodi běh)


def fetch_parallel_limit(gate_value: Optional[int], android: bool, fallback_active: bool) -> Optional[int]:
    """ČISTÁ: strop souběžných stažení vlny. Hodnota správce (1–6) platí, dokud zařízení nebylo vráceno na výchozí;
    výchozí = Android 2, jinak None (bez zvláštního stropu — jen `FETCH_PARALLEL_MAX`). Návrat po 429 / paměti NIKDY
    nezvýší souběžnost: výchozí platformy, nejvýš hodnota správce (cross-check Codex #3 — desktop se 3 by skočil na 6)."""
    default = ANDROID_FETCH_DEFAULT if android else None
    if gate_value is None or not 1 <= int(gate_value) <= FETCH_PARALLEL_MAX:
        return default
    if not fallback_active:
        return int(gate_value)
    return min(int(gate_value), default if default else FETCH_PARALLEL_MAX)


def _fetch_fallback_active(now: Optional[float] = None) -> bool:
    try:
        until = float(_winprops.get_prop(_FETCH_FALLBACK_PROP, "") or 0.0)
    except (TypeError, ValueError):
        return False
    return until > (time.time() if now is None else now)


def _fetch_pool_size(requested: int) -> Tuple[int, str, bool]:
    """(velikost poolu vlny, zdroj stropu `gate` | `fallback` | `android` | `default`, sníží návrat na výchozí STROP
    zařízení?) — zdroj jde do `SEARCH_PHASES`; třetí hodnota rozhoduje `_note_fetch_pressure`. Porovnávají se stropy,
    ne velikost této vlny: krátká vlna (2 dotazy) by jinak 429 spolkla a další dlouhá jela dál na stropu správce
    (ověřovací kolo Fable N-1)."""
    try:
        import richmovie_gate as _rm_gate
        gate_value = _rm_gate.search_fetch_parallel()
    except Exception:
        gate_value = None
    try:
        android = bool(xbmc.getCondVisibility("system.platform.android"))
    except Exception:
        android = False
    fallback = gate_value is not None and _fetch_fallback_active()

    def _cap(limit: Optional[int]) -> int:
        return min(FETCH_PARALLEL_MAX, limit if limit else FETCH_PARALLEL_MAX)
    cap = _cap(fetch_parallel_limit(gate_value, android, fallback))
    fallback_reduces = _cap(fetch_parallel_limit(gate_value, android, True)) < cap
    size = max(1, min(int(requested), cap))
    if gate_value is not None and not fallback:
        return size, "gate", fallback_reduces
    return size, ("fallback" if fallback else ("android" if android else "default")), fallback_reduces


def _note_fetch_pressure(exc: BaseException, pool_size: int, source: str, fallback_reduces: bool,
                         log: Callable[..., Any]) -> None:
    """Brzdění Webshare (429) / nedostatek paměti při souběžnosti nastavené správcem → návrat na výchozí na
    `FETCH_FALLBACK_S` (jen v tomto běhu Kodi). Rozhoduje TYP výjimky. Návrat se zapíše JEN když sníží STROP zařízení
    (audit Fable F-3: desktop se správcovskou hodnotou ≤ výchozí by jinak hlásil `pool_fallback`, který nenastal, a A/B
    měření by lhalo; N-1: rozhoduje strop, ne velikost vlny). Nikdy nevyhazuje."""
    if source != "gate" or not isinstance(exc, (WsRateLimited, MemoryError)):
        return
    if not fallback_reduces:
        try:
            _diag_log.info("FETCH_PRESSURE_NOOP reason=%s pool=%d (návrat by nic nesnížil)"
                           % (type(exc).__name__, pool_size))
        except Exception:
            pass
        return
    try:
        _winprops.set_prop(_FETCH_FALLBACK_PROP, repr(time.time() + FETCH_FALLBACK_S))
        log("FETCH_PARALLEL_FALLBACK", type(exc).__name__, pool_size)
        _diag_log.warning("FETCH_PARALLEL_FALLBACK reason=%s pool=%d → výchozí na %d h"
                          % (type(exc).__name__, pool_size, int(FETCH_FALLBACK_S // 3600)))
    except Exception as exc2:
        try:   # návrat se nezapsal → příští vlna pojede se souběžností správce; musí to být vidět (Codex #3)
            _diag_log.warning("FETCH_PARALLEL_FALLBACK_FAILED reason=%s err=%r" % (type(exc).__name__, exc2))
        except Exception:
            pass







# ─────────────────────────────────────────────────────────────────────────────
#  KONSTANTY  (sdílené i s plugin.py – ten je může importovat odsud)
# ─────────────────────────────────────────────────────────────────────────────
QUALITY_RANK = {               # nižší index = lepší
    "2160p": 0,
    "1080p": 1,
    "720p":  2,
    "480p":  3,
    "webrip": 4,
    "other":  5,
    "cam":    6,
}

# HΦ-D P2-1 (2026-07-07, re-audit night2): `BITRATE_MBPS` SMAZÁN — byl MRTVÝ
# KÓD (0 použití; `_bytes_to_minutes` nikdy neexistoval). HΦ-C len_out korektnost
# STOJÍ na tom, že est_min je VŽDY měřený (žádný odhad z bitrate) — smazání
# konstanty ten invariant zamyká (nikdo ji omylem nezapojí zpět).

# — filtry —
ALLOWED_VIDEO_EXTS = {
    ".mkv", ".mp4", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".webm",
    ".m4v",   # HΦ2 (2026-07-07, analýza H1 §6.2): Apple kontejner, kontejnerově
              # shodný s .mp4 — chyběl → správné 1080p soubory (Kingsman, Zloba)
              # padaly na `quick`. Legitimní video přípona, 0 riziko pro precision.
    # Φ-B (30.09.2026, E3-F08): starší a DVD kontejnery, které Kodi přehraje — chyběly, takže správné
    # soubory („Kravataci-S01E01.mpg“, „Poslední samuraj … .flv“) padaly na `quick`. Zvukové přípony
    # (.mka/.m4a/.wma) a nedostažené soubory (.part/.crdownload) sem NEpatří.
    ".mpg", ".mpeg", ".vob", ".divx", ".flv", ".m2v",
}
# Přípona oddělená od názvu mezerou („Tiché místo 2018 1080p CZE cz.forced  mkv“) — nahrávač přišel o tečku.
# „ts“ sem nepatří: na konci názvu bez přípony je to značka zdroje (telesync, „… 2019 CAM TS“), ne kontejner
# (audit Fable F1-V11, 30.09.2026).
_EXT_AFTER_SPACE_RE = re.compile(
    r"\s(%s)$" % "|".join(sorted(e[1:] for e in ALLOWED_VIDEO_EXTS if e != ".ts")), re.I)
# Stránkování Webshare („po dvou stránkách žádné video → stáhni další“) se řídí sadou přípon z doby PŘED
# rozšířením: nová přípona nesmí stahování dalších stránek ukončit dřív (R-A; audit Fable F1-V6).
PAGING_VIDEO_EXTS = frozenset({".mkv", ".mp4", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".webm", ".m4v"})


def sane_item(item: object) -> Optional[dict]:
    """Syrová položka zdroje v tvaru, se kterým filtr počítá: slovník s textovým `ident` a `name`
    a ČÍSELNOU velikostí (nečitelná velikost = 0, o položce rozhodne filtr). None = položku nelze použít."""
    if not isinstance(item, dict):
        return None
    ident, name = item.get("ident"), item.get("name")
    if not ident or not isinstance(name, str) or not name.strip():
        return None
    size = item.get("size", 0)
    if isinstance(size, bool) or not isinstance(size, (int, float)):
        try:
            size = int(float(str(size).strip()))
        except (TypeError, ValueError):
            size = 0
        item = dict(item, size=size)
    if not isinstance(ident, str):
        item = dict(item, ident=str(ident))
    return item


def video_ext_of(name: str) -> str:
    """SSOT: přípona videa v názvu souboru (malými písmeny, s tečkou), nebo "" když název video příponu
    nenese. Bere i příponu oddělenou mezerou místo tečky."""
    nm = str(name or "").strip()
    ext = os.path.splitext(nm)[1].lower()
    if ext in ALLOWED_VIDEO_EXTS:
        return ext
    m = _EXT_AFTER_SPACE_RE.search(nm)
    return ("." + m.group(1).lower()) if m else ""


# ── SSOT normalizace epizodního kódu → (season:int, episode:int) ────────────
# HΦ3 (2026-07-07, analýza H1 §6.3): dřív se kódy porovnávaly jako stripnuté
# STRINGY (`code_re` literal match), takže `s1e01` ≠ `s01e01` → has_code=False
# → správná epizoda zabita (zero-padding bug, Babylon 5). Kanonická dvojice
# sjednocuje s01e01 / s1e01 / 1x01 / 01x01 / s01.e01 / 1x1. Jeden zdroj pravdy
# pro has_code, other_code i ep_token_miss skip.
# Φ-B (30.09.2026, E3-F05/F06): třetí tvar = hybrid „S08x06“ (písmeno S + x). Dřív ho kanonický regex
# neznal: cílový díl zachránil jen doslovný podřetězec a JINÝ díl v tomto tvaru („S12x23“) se nepoznal vůbec.
_CODE_CANON_RE = re.compile(
    r"s0?(\d{1,2})\W*e0?(\d{1,2})|(?<![a-z0-9])0?(\d{1,2})\W*x\W*0?(\d{1,2})(?![a-z0-9])"
    r"|(?<![a-z0-9])s0?(\d{1,2})\W*x\W*0?(\d{1,2})(?![a-z0-9])",
    re.I,
)


def canon_ep_codes(text: str) -> set:
    """Vrátí množinu kanonických (season, episode) dvojic nalezených v textu.
    Prázdná množina = žádný epizodní kód. SSOT — používá filtr i harness."""
    out = set()
    if not text:
        return out
    for m in _CODE_CANON_RE.finditer(text):
        if m.group(1) is not None:
            out.add((int(m.group(1)), int(m.group(2))))
        elif m.group(3) is not None:
            out.add((int(m.group(3)), int(m.group(4))))
        elif m.group(5) is not None:
            out.add((int(m.group(5)), int(m.group(6))))
    return out


# ── Φ5B (29.09.2026, audit A06 F05/R06): kód JINÉHO dílu bez výčtu 20 511 ban tokenů ──────────
# Plugin dřív banoval jiný díl výčtem VŠECH kombinací řada×díl 1–99 ve třech tvarech (`sNNeNN`, `NxNN`,
# `NNxNN`) → jeden regex s 20 511 alternativami, kompilovaný a procházený pro každý dotaz (benchmark
# +1 031 ms / 200 souborů, PC v Kodi 12–16 s na první vlnu seriálu). Tenhle regex pozná PŘESNĚ tytéž
# tokeny (stejné tvary, stejné rozsahy, stejné hranice slov v normalizovaném názvu) — rozhodnutí filtru i
# důvod `other_part` zůstávají; mění se jen cena. Brána: heuristics_replay (cases + validate flip 0).
_OTHER_EP_RE = re.compile(r"(?<![0-9a-z])(?:s(\d{2})e(\d{2})|(\d{1,2})x(\d{2}))(?![0-9a-z])")


def other_episode_code_hit(n_norm: str, target_canon: set, exclude_tokens=()) -> Optional[Tuple[int, str]]:
    """(pozice, token) PRVNÍHO kódu dílu mimo cíl v normalizovaném názvu, nebo None. Čistá, SSOT.

    Tvary a rozsahy = dřívější výčet v `plugin._tv_play` (řada i díl 1–99, cílová dvojice vynechána);
    `exclude_tokens` = tokeny názvu seriálu z TMDb (ban je nikdy nesmí zasáhnout — jako `banned_keys_eff`)."""
    if not n_norm:
        return None
    for m in _OTHER_EP_RE.finditer(n_norm):
        if m.group(1) is not None:
            sn, en = int(m.group(1)), int(m.group(2))
        else:
            sn, en = int(m.group(3)), int(m.group(4))
        if not (1 <= sn <= 99 and 1 <= en <= 99) or (sn, en) in target_canon:
            continue
        tok = m.group(0)
        if tok in exclude_tokens:
            continue
        return m.start(), tok
    return None


# ── HΦ-D (2026-07-07): ban hygiena + sdílené helpery ────────────────────────
# Stopwords a římské číslice, které NESMÍ samostatně banovat (H4: spin_tokens
# banoval přes „the/of/a/ii" → „Černé zrcadlo II" odstřeleno tokenem „ii").
_BAN_STOP = {
    # CZ drobky
    "v", "ve", "s", "z", "na", "do", "u", "o", "a", "i", "se", "k", "ke", "za",
    # EN drobky
    "the", "of", "in", "on", "and", "to", "for", "at", "by", "an", "or",
    # FR/ES/IT drobky
    "de", "le", "la", "du", "el", "los", "las", "il", "un", "una",
}
_ROMAN = {"i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x",
          "xi", "xii", "xiii", "xiv", "xv"}


def _phrase_contains(haystack_norm: str, phrase: str) -> bool:
    """SSOT (HΦ-D P2-3): fráze `phrase` jako sousedící sekvence slov v už
    normalizovaném `haystack_norm`. Nahrazuje 4× opakovaný `f' {x} ' in f' {y} '`
    idiom u nových cest (veto, spin guard). Pre-existující výskyty ponechány
    (neměnit fungující kód bez důvodu)."""
    return f" {phrase} " in f" {haystack_norm} "


def _alpha_word_count(phrase: str) -> int:
    """Počet ČISTĚ ABECEDNÍCH tokenů ve frázi (HΦ-D P2-2 guard sibling veta)."""
    return sum(1 for w in phrase.split() if w.isalpha())


def sanitize_ban_tokens(tokens) -> set:
    """SSOT hygiena ban tokenů (HΦ-D, analýza H4). VÍCESLOVNÉ fráze (sibling
    veto z spin_tokens, „suits la") PROJDOU beze změny — jsou specifické.
    JEDNOSLOVNÉ bany filtruj: musí mít ≥4 znaky, nebýt čistá číslice, stopword
    ani římská číslice — jinak „ii"/„the"/„la"/„of" odstřelovaly správné díly.
    Krátký distinguisher spin-offu („la") kryje víceslovná fráze (HΦ-B)."""
    out = set()
    for t in (tokens or ()):
        if not t:
            continue
        if " " in t:                      # víceslovná fráze — ponech
            out.add(t)
            continue
        tl = t.lower()
        if len(tl) < 4 or tl.isdigit() or tl in _BAN_STOP or tl in _ROMAN:
            continue
        out.add(t)
    return out

# HΦ-D (2026-07-07): franšízový film v epizodním hledání. Odstranění stopword
# banů (hygiena výše) odhalilo, že fallback akceptuje soubory bez epizodního
# kódu jen na shodu seriálových tokenů → Babylon 5 „[Movie 5] The Legend of the
# Rangers", „[Movie 3] The River of Souls" (TV filmy, ne díly) prosákly do
# hledání S01E01. Precizní guard: bracketovaná anotace franšízového filmu s
# pořadovým číslem, na SYROVÉM názvu (norm() závorky strhne). Aplikuje se jen v
# fallbacku (kód nesedí / chybí) u coded-search → nulové riziko false-rejectu
# správných dílů (ty „[Movie N]" nenesou). Generalizuje (Stargate, Babylon…).
_FRANCHISE_FILM_RE = re.compile(r"[\[(]\s*(?:movie|film)\s*\d", re.I)

MIN_FILE_MB_BY_QUALITY = {
    "2160p": 2000, "1080p": 700, "720p": 350,
    "webrip": 300, "other": 250, "cam": 0,
}

MATCH_TOL         = 5      # ± minut pro ★ MATCH
# Φ5B: jak často filtr hlásí pokrok do dialogu („Třídím nalezené (n/N)…“). Film ~800 souborů ≈ 16 kroků;
# častěji by jen zdržovalo (každé hlášení = překreslení dialogu), řidčeji by na TV text stál vteřiny.
FILTER_PROGRESS_EVERY = 50
LEN_TOL_SHORT     = 10
LEN_TOL_LONG      = 40
PROBE_MAX_RESULTS = 15
MAX_WS_RESULTS    = 120

# 2025‑07‑27 23:58 CEST  – úprava: regex zachytí i „_2017_“, „.2011.“
YEAR_RE = re.compile(r"(?<!\d)(19[5-9]\d|20[0-4]\d)(?!\d)")




PROBE_CHUNK_KB  = 512      # kolik dat stáhneme v jednom „kusu“
PROBE_MAX_KB    = 10_240   # hard-limit ≈ 10 MB


_BAD_REGEX_DEFAULT = re.compile(r"\b(trailer|sample|clip|preview)\b", re.I)


# 2025-08-23 08:43 CEST – rozšíření epizodického regexu pro filmy:
# • zachytí i tvary "01E03" (E místo x) a "s01 e03" (s mezerou),
# • navíc detekuje i případy, kdy po kódu epizody ihned následuje písmeno/slovo (např. "s01 e03Alien").
#   Ostatní logika zůstává NEMĚNNÁ.
# ── filmové epizody (SxxEyy / 01x02[a‑z] / 01E02 / s01 e02) – u filmů je zakážeme úplně ──
_BAD_REGEX_MOVIE = re.compile(
    r'(?:'
    r'\b(?:s\d{1,2}\s*e\d{1,2}[a-z]?|\d{1,2}x\d{1,2}[a-z]?|\d{1,2}[eE]\d{1,2}[a-z]?)\b'
    r'|\bs\d{1,2}\s*e\d{1,2}(?=[A-Za-z])'
    r'|\b\d{1,2}[eE]\d{1,2}(?=[A-Za-z])'
    r'|\b(?:NBA|NHL|NFL|EPL)\b'
    r')',
    re.I,
)






# ─────────────────────────────────────────────────────────────────────────────
#  UTIL FUNKCE – veřejné, aby je mohl používat i plugin.py
# ─────────────────────────────────────────────────────────────────────────────
def norm(s: str) -> str:
    """Odstraní diakritiku, lower‑case, ne‑alfa znaky → mezera, kolaps mezer."""
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    s = re.sub(r"[^0-9a-z]+", " ", s.lower()).strip()
    return re.sub(r"\s{2,}", " ", s)

# ––– kompatibilní alias pro staré volání –––
_norm = norm      # ← ⬅⬅⬅  **PŘIDEJTE TENTO ŘÁDEK**


def base_title_key(name: str) -> str:
    """
    Normalizovaný “kořen” názvu bez koncové číslovky/římské číslice.
    Usnadňuje deduplikaci různých releasů téhož filmu.
    """
    key = norm(name)
    key = re.sub(r'\b(?:part|episode|d[ií]l)\s+[0-9ivx]+$', '', key)
    key = re.sub(r'\s+(?:(?:[2-9]|1[0-9])(?!\d)|[ivx]{2,5})$', '', key)
    return re.sub(r'\s+', ' ', key).strip()


# --------------------------------------------------------------------------- #
# 2025‑07‑19 16:27  _is_adult_title() – final FIX (jediná verze v souboru)
# --------------------------------------------------------------------------- #
def _is_adult_title(title: str) -> bool:
    """
    Heuristicky odhadne, zda `title` naznačuje erotický obsah.

    Postup:
    1) Odstraní čtyřciferné roky a kódy SxxEyy / 01x02.
    2) Normalizuje řetězec (bez diakritiky, lowercase, kolaps mezer).
    3) Vrací True, pokud zůstane alespoň jedno erotické klíčové slovo.
    """
    # 1 • čistění
    cleaned = _RE_SXXEYY.sub("", title)
    cleaned = _RE_XXYY.sub("", cleaned)
    cleaned = re.sub(r"\b\d{4}\b", "", cleaned)

    # 2 • normalizace
    title_norm = norm(cleaned)

    # 3 • test klíčových slov
    return any(kw in title_norm for kw in (norm(w) for w in EROTIC_KEYWORDS))




@functools.lru_cache(maxsize=128)
def spin_tokens(
    tv_id: str,
    tmdb_key: str | None,
    *,
    lang: str = "en-US",
    logger: 'Callable[..., None]' | None = None,
) -> tuple[set[str], set[str]]:
    """
    2025-08-08 23:40 CEST – BUGFIX: bezpečný výběr root_word + preferuj „name“ před „original_name“ u ne‑latinky.

    Vrátí dvojici množin **(allow_tokens, ban_tokens)**, které spolehlivě
    rozlišují spin‑offy v rámci jedné franšízy (Stargate SG‑1 / Atlantis /
    Universe …).

    Parametry
    ---------
    tv_id      : TMDb ID aktuálního seriálu.
    tmdb_key   : TMDb API klíč.
    lang       : Jazyk pro TMDb dotazy (výchozí "en-US").
    logger     : Volitelný log handler (event, *params).

    Návrat
    ------
    (allow, ban) – dvojice *set(str)*, každá tokeny v lower‑case bez diakritiky.

    • **allow** – slova charakteristická pro _aktuální_ seriál
    • **ban**   – slova charakteristická pro _ostatní_ spin‑offy
    """
    # – 0) příprava loggeru ---------------------------------------------------
    log = logger or (lambda *_, **__: None)

    # – 1) validace vstupů ----------------------------------------------------
    if not (tv_id and tmdb_key):
        return set(), set()

    tmdb = TMDb(tmdb_key, lang=lang, logger=log)

    # – 2) zjistíme „kořenové“ slovo franšízy (bez pádu na prázdném řetězci) --
    try:
        # Φ-C (30.09.2026, A06 F07): vstupy spin-off filtru z lokální cache TMDb (30 d) — dřív ~9 dotazů
        # přes Gate při KAŽDÉM hledání dílu (detail + alt. názvy každého sourozence).
        me = tmdb._get_json_cached(f"/tv/{tv_id}", {"api_key": tmdb_key, "language": lang},
                                   key=f"spin_me:{tv_id}:{lang}", ttl_s=tmdb.STATIC_META_TTL_S,
                                   what="spin_tokens")
        # Preferujeme `name` (lokalizovaný/EN), protože `original_name` může
        # obsahovat znaky mimo latinku (např. korejština) → po `norm()` by zbylo "".
        candidates = [me.get("name", ""), me.get("original_name", "")]
        root_word = ""
        for cand in candidates:
            words = norm(cand).split()
            if words:
                root_word = words[0]
                break

        # Fallback: zkusíme alternativní názvy, dokud nenajdeme první latinský token
        if not root_word:
            try:
                for rec in tmdb.tv_alternative_titles(int(tv_id)):
                    words = norm(rec.get("title", "")).split()
                    if words:
                        root_word = words[0]
                        break
            except TMDbError as _st_e:
                # Dřív tiché: degradace spin-filtru (kořen bez alt-titles).
                _diag_log(f"spin_tokens root alt-titles fail: {_st_e}", 0)

        if not root_word:
            return set(), set()
    except TMDbError as _st_e:
        # Dřív tiché: spin-off filtr se celý vypne → do výsledků můžou
        # proklouznout epizody cizích spin-offů. Za WARNING (viditelné).
        _diag_log(f"spin_tokens disabled (TMDb fail): {_st_e}", 3)
        return set(), set()

    # – 3) najdeme všechny seriály se stejným kořenem ------------------------
    try:
        siblings = tmdb.search_tv(root_word, limit=30)
    except TMDbError as _st_e:
        _diag_log(f"spin_tokens siblings search fail: {_st_e}", 0)
        siblings = []

    def _tokens(title: str) -> set[str]:
        """Normalizované tokeny – bez kořenového slova („stargate“…)."""
        return {w for w in norm(title).split() if w and w != root_word}

    def _phrase(title: str) -> str:
        """HΦ-B (2026-07-07): CELÁ normalizovaná fráze názvu (s kořenem). Pro
        sibling VETO — spin-off jako „Suits LA" sdílí základní titul + kód a
        prochází přes rule_a; jednoznačně ho identifikuje až celá víceslovná
        fráze („suits la" / cz alt „kravataci la"). Distinguisher je často
        krátký token („la"), který NELZE bezpečně banovat samostatně."""
        return norm(title).strip()

    allow: set[str] = set()
    ban:   set[str] = set()
    ban_phrases: set[str] = set()
    allow_phrases: set[str] = set()   # HΦ-B: celé tituly aktuálního seriálu

    for show in siblings:
        show_id = str(show["id"])
        toks    = _tokens(show.get("name") or show.get("original_name", ""))

        if show_id == str(tv_id):            # ➜ aktuální seriál → allow
            allow |= toks
            _me_ph = _phrase(show.get("name") or show.get("original_name", ""))
            if _me_ph:
                allow_phrases.add(_me_ph)
            # + alternativní názvy (cz/sk/…)
            try:
                for rec in tmdb.tv_alternative_titles(int(show_id)):
                    allow |= _tokens(rec.get("title", ""))
                    _me_alt = _phrase(rec.get("title", ""))
                    if _me_alt:
                        allow_phrases.add(_me_alt)
            except TMDbError as _st_e:
                _diag_log(f"spin_tokens allow alt-titles fail: {_st_e}", 0)
            continue

        # jiné spin‑offy → ban (tokeny) + víceslovná fráze (veto)
        ban |= toks
        _sib_ph = _phrase(show.get("name") or show.get("original_name", ""))
        if " " in _sib_ph:
            ban_phrases.add(_sib_ph)
        try:
            for rec in tmdb.tv_alternative_titles(int(show_id)):
                ban |= _tokens(rec.get("title", ""))
                _alt_ph = _phrase(rec.get("title", ""))
                if " " in _alt_ph:
                    ban_phrases.add(_alt_ph)
        except TMDbError as _st_e:
            _diag_log(f"spin_tokens ban alt-titles fail: {_st_e}", 0)

    # – 4) vzájemné vyloučení + návrat ---------------------------------------
    ban -= allow
    # HΦ-B: víceslovné sibling fráze → do ban setu (banned_keys je bere jako
    # fráze; filtr je aplikuje jako VETO nad rule matchem, viz search_one).
    # Dva guardy proti falešnému vetu SPRÁVNÉHO seriálu:
    #  (1) fráze tvořená VÝHRADNĚ allow tokeny — patří aktuálnímu seriálu;
    #  (2) fráze je ADJACENT PODŘETĚZEC některého titulu aktuálního seriálu —
    #      kritické pro seriály, co OBSAHUJÍ kratší sibling jako prefix
    #      (aktuální „Law and Order SVU“, sibling „Law and Order“ → fráze
    #      „law and order“ by vetovala i správný SVU soubor). Delší sibling
    #      fráze (obsahující aktuální titul) se NEchává — správný základní
    #      díl ji nenese.
    for ph in ban_phrases:
        if set(ph.split()) <= allow:
            continue
        if any(_phrase_contains(ap, ph) for ap in allow_phrases):
            continue
        ban.add(ph)
    # HΦ-D: hygiena ban tokenů NENÍ tady — dělá se u POINTU POUŽITÍ v search_one
    # (banned_keys_eff), aby pokryla VŠECHNY zdroje banů (spin_tokens, kolekce,
    # budoucí) jedním SSOT místem a byla testovatelná replay harnessem.
    log("SPIN_TOKENS", tv_id,
        f"allow={len(allow)} ban={len(ban)} phrases={len(ban_phrases)}")
    return allow, ban



# --------------------------------------------------------------------------- #
#  ADULT / EROTIC FILTER
# --------------------------------------------------------------------------- #
EROTIC_KEYWORDS: set[str] = {
    "porno", "porn", "xxx", "hentai", "bdsm", "lesb", "gay",
    "amateur", "orgasm", "anal", "cum", "cream", "hardcore",
    "fetish", "milf", "teen", "schoolgirl", "gangbang",
    "péčko", "erot", "sex",
}

_RE_SXXEYY = re.compile(r"[Ss]\d{1,2}[Ee]\d{1,2}")
_RE_XXYY   = re.compile(r"\d{1,2}[xX]\d{1,2}")






# ── ALT-TITLE FALLBACK KONSTANTY ───────────────────────────────────────
_ALT_THRESHOLD           = 4      # kolik releasů stačí k ukončení fallbacku
_ALT_MAX_TITLES          = 6      # max. alternativních názvů, které zkoušíme
_ALT_COUNTRY_WHITELIST   = {"CZ", "SK", "US", "GB", "CA", "PL", "RU", "IT"}
_NON_LATIN_RE            = re.compile(r"[\u0400-\u04FF\u4E00-\u9FFF]")
# ───────────────────────────────────────────────────────────────────────











# --------------------------------------------------------------------------- #
#  _LANG_MAP (upraveno: 14.12.2025 11:50 CET (Europe/Prague) – rozšíření o časté jazyky; opatrně s “it/no/da” kvůli falešným shodám)
# --------------------------------------------------------------------------- #
_LANG_MAP: dict[str, str] = {
    # čeština
    "cz": "CZ", "cs": "CZ", "cze": "CZ", "ces": "CZ",
    "czech": "CZ", "čes": "CZ", "cesky": "CZ", "cestina": "CZ", "čeština": "CZ",

    # slovenština
    "sk": "SK", "slk": "SK", "slo": "SK",
    "slovak": "SK", "slovensky": "SK", "slovenčina": "SK", "slovencina": "SK",

    # angličtina
    "en": "EN", "eng": "EN", "english": "EN",

    # němčina
    "de": "DE", "deu": "DE", "ger": "DE",
    "german": "DE", "deutsch": "DE",

    # francouzština
    "fr": "FR", "fra": "FR", "fre": "FR",
    "french": "FR",

    # španělština
    "es": "ES", "spa": "ES",
    "spanish": "ES", "espanol": "ES",

    # italština (NEPŘIDÁVÁM klíč "it" – je to běžné slovo a dělá falešné shody)
    "ita": "IT", "italian": "IT", "italiano": "IT",

    # portugalština
    "pt": "PT", "por": "PT", "portuguese": "PT",
    "ptbr": "PT", "portugues": "PT",

    # ruština
    "ru": "RU", "rus": "RU", "russian": "RU",

    # polština
    "pl": "PL", "pol": "PL", "polish": "PL",

    # maďarština
    "hu": "HU", "hun": "HU", "hungarian": "HU",

    # japonština
    "ja": "JA", "jpn": "JA", "japanese": "JA",

    # korejština
    "ko": "KO", "kor": "KO", "korean": "KO",

    # čínština
    "zh": "ZH", "zho": "ZH", "chi": "ZH",
    "chinese": "ZH", "mandarin": "ZH", "cantonese": "ZH",

    # arabština
    "ar": "AR", "ara": "AR", "arabic": "AR",

    # hindština (NEPŘIDÁVÁM klíč "hi" – může být slovo; většinou bývá HIN/HINDI)
    "hin": "HI", "hindi": "HI",

    # turečtina
    "tur": "TR", "turkish": "TR",
}


_SUB_HINT = re.compile(r"\b(sub|srt|tit|titulky|titles?)\b", re.I)
_DUB_HINT = re.compile(r"\b(dab|dub|dubbing|audio)\b",       re.I)


# suffixy, které určují typ stopy (audio vs titulky) ve slepeném tvaru „czdab“, „engsub“…
# Φ-C (30.09.2026, E4-F06): vzory předkompilované JEDNOU — dřív se řetězec vzoru skládal a hledal v cache
# `re` u každého slova každého názvu (65 % ceny `enrich`). Vzory jsou tytéž.
_LANG_AUD_SUFFIX = ("dab", "dub", "dubbing", "dabing", "audio")
_LANG_SUB_SUFFIX = ("sub", "subs", "tit", "titulky", "title", "titles", "srt", "vobsub", "ass", "ssa", "idx")
_LANG_AUD_GLUED_RE = re.compile(r"^([a-z]{2,3})(" + "|".join(_LANG_AUD_SUFFIX) + r")$")
_LANG_SUB_GLUED_RE = re.compile(r"^([a-z]{2,3})(" + "|".join(_LANG_SUB_SUFFIX) + r")$")
_LANG_SPLIT_RE = re.compile(r"[\W_]+")


def parse_langs(name: str) -> Tuple[List[str], List[str]]:
    """
    14.12.2025 11:50 CET (Europe/Prague)

    Detekuje ISO kódy jazyků (audio, titulky) v názvu souboru.
    Vrací dvojici `(audios, subs)` – seznamy dvoupísmenných kódů (např. 'CZ','EN','JA'…).

    Zachováno:
      • původní logika přes `_LANG_MAP` + `_SUB_HINT` / `_DUB_HINT`

    Nově:
      • rozpozná i slepené tvary typu:
          - czdab, engdub, jpnsub, korsrt, zhtit …
        a v tom případě rozhodne audio/sub přímo podle suffixu (dab/sub),
        bez globální heuristiky (_SUB_HINT/_DUB_HINT).
    """
    n = (name or "").lower()
    aud, sub = set(), set()

    tokens = [w for w in _LANG_SPLIT_RE.split(n) if w]

    # globální heuristika (stejně jako dřív) – jen pro “čisté” jazykové tokeny
    global_sub_mode = bool(_SUB_HINT.search(n) and not _DUB_HINT.search(n))

    for word in tokens:
        # 1) čistý jazykový token → původní chování
        code = _LANG_MAP.get(word)
        if code:
            if global_sub_mode:
                sub.add(code)
            else:
                aud.add(code)
            continue

        # 2) slepený tvar: <lang><suffix>
        #    např. "czdab" / "jpnsub" / "engsubs" …
        m = _LANG_AUD_GLUED_RE.match(word)
        if m:
            lang_key = m.group(1)
            code2 = _LANG_MAP.get(lang_key)
            if code2:
                aud.add(code2)
            continue

        m = _LANG_SUB_GLUED_RE.match(word)
        if m:
            lang_key = m.group(1)
            code2 = _LANG_MAP.get(lang_key)
            if code2:
                sub.add(code2)
            continue

    return sorted(aud), sorted(sub)





# 2025-09-07 15:14 CEST (Europe/Prague)
def extract_langs_from_mediainfo(mi: dict) -> Tuple[List[str], List[str]]:
    """
    ÚČEL: Z přinesené MediaInfo struktury (výstup WebshareClient.probe_mediainfo)
    vytáhne jazyky AUDIO a SUBTITLE jako dvoupísmenné kódy ('CZ','SK','EN'…),
    konzistentně s parse_langs().

    POZN.: Spoléhá na to, že `mi['tracks']` je seznam slovníků z `to_data()`
    knihovny pymediainfo (klíče jako 'track_type', 'language', 'language_code',
    'other_language', 'title'). Výstupem jsou dvě *seřazené* množiny kódů.
    """
    aud, sub = set(), set()
    try:
        for t in mi.get("tracks", []) or []:
            ttype = (t.get("track_type") or t.get("track type") or "").strip().lower()
            if not ttype:
                continue

            # posbírej všechny kandidáty textů s jazykem
            tokens: set[str] = set()
            for key in ("language", "language_code", "other_language", "title"):
                v = t.get(key)
                if v is None:
                    continue
                if isinstance(v, (list, tuple)):
                    for x in v:
                        tokens |= set(re.split(r"[\W_]+", str(x).strip().lower()))
                else:
                    tokens |= set(re.split(r"[\W_]+", str(v).strip().lower()))

            # namapuj přes stejnou mapu jako parse_langs()
            codes = { _LANG_MAP.get(tok) for tok in tokens if _LANG_MAP.get(tok) }
            if ttype in ("text", "subtitle", "subtitles"):
                sub |= codes
            elif ttype == "audio":
                aud |= codes
    except Exception:
        # jakákoliv anomálie v MI – raději mlčky ignorujeme (bez pádu)
        pass

    return sorted(aud), sorted(sub)






_QUAL_PATTERNS = [
    ("2160p", re.compile(r'(2160p|\b4k\b|\buhd\b)', re.I)),
    ("1080p", re.compile(r'(1080p|full\.?hd)',       re.I)),
    ("720p",  re.compile(r'720p',                    re.I)),
    ("480p",  re.compile(r'(480p|\bsd\b)',           re.I)),
    ("webrip",re.compile(r'(webrip|web[-_.]?dl|hdrip|dvdrip)', re.I)),
    ("cam",   re.compile(r'\b(cam|hd[-_.]?ts|telesync|ts)\b',  re.I)),
]


def quality(name: str) -> str:
    """Heuristicky odhadne kvalitu release (‘2160p’, ‘1080p’, … ‘cam’)."""
    for q, pat in _QUAL_PATTERNS:
        if pat.search(name):
            return q
    return "other"


















# ─────────────────────────────────────────────────────────────────────────────
#  DATOVÉ TŘÍDY
# ─────────────────────────────────────────────────────────────────────────────
@dataclass(unsafe_hash=True)
class Release:
    """
    2025-10-12 07:42 CEST (Europe/Prague)
    Rozšířený datový objekt releasu. Kromě stávajících polí (ident, name, size,
    quality, audios, subs, est_min, match, score) nově nese i *nepovinná* pole
    s metadaty z Webshare `/search` – využíváme je pouze pro diagnostiku/log.

    ws_width   … šířka videa (px) z Webshare API (pokud je k dispozici)
    ws_height  … výška videa (px)
    ws_len_s   … délka v sekundách (video_length)
    ws_pos     … kladné hlasy (positive_votes)
    ws_neg     … záporné hlasy (negative_votes)
    """
    ident:   str
    name:    str
    size:    int                       # B
    quality: str                       # viz quality()
    audios:  List[str] = field(default_factory=list)
    subs:    List[str] = field(default_factory=list)
    est_min: Optional[int] = None      # odhad délky (min)
    match:   bool = False              # ★ MATCH?
    score:   int = 0                   # agregované pořadí (nižší = lepší)

    # — NOVĚ: volitelná meta z Webshare `/search` (pouze pro log) —
    ws_width:  Optional[int] = None
    ws_height: Optional[int] = None
    ws_len_s:  Optional[int] = None
    ws_pos:    Optional[int] = None
    ws_neg:    Optional[int] = None
    runtime_mismatch: bool = False   # mimo ±10 % TMDb runtime (TV) → šedé + na konec listu
    title_penalty: int = 0          # penalizace názvu (SPEC: jednoslovné seriály) → tlačí balast dolů už před MI2
    len_penalty: int = 0            # HΦ-C (2026-07-07): mírný délkový nesoulad → penalta řazení (dřív tvrdý drop len_out)
    ws_rel: int = 0                 # P2 #11 (2026-07-07): relevance k termínu ručního WS hledání (0 = neutrální; plní jen _ws_search) → řadí přesný zásah nad velký cizí soubor

    # — NOVĚ: multi-source podpora (Fastshare integrace 21.01.2026) —
    source: str = "webshare"                  # "webshare" | "fastshare"
    fs_download_url: Optional[str] = None     # přímá URL pro Fastshare streaming
    fs_hash: Optional[str] = None             # Fastshare cookie hash

    # — Φ-A (30.09.2026): měření hledání + E1-F01 —
    uncertain: bool = False   # přijato jen záložní cestou filtru (dřív atribut mimo dataclass → do cache se neuložil)
    origin: str = ""          # dotazy a stránky, které soubor vrátily: "0:1,2:fs" (index dotazu vlny : stránka WS | fs | fsy)
    wave: str = ""            # vlna, která soubor přinesla do výpisu (W1…WX+, RESCUE; film: P = primární, ALT)


    # – derived –
    @property
    def size_mb(self) -> int:
        return round(self.size / 1_048_576)



# --------------------------------------------------------------------------- #
# 2025‑07‑20 10:45 CEST  class QueryBuilder  – centrální generátor dotazů
# --------------------------------------------------------------------------- #
class QueryBuilder:
    """
    **Jediné místo**, kde se sestavují vyhledávací řetězce pro Webshare.

    ▸ *Bez* závislosti na Kodi ani Webshare SDK  
    ▸ Vrací **list** v pořadí, jak bylo požadováno, ale se 100 % deduplikací  
    ▸ Metoda `tv()` implementuje všech 26 variant z vašeho scénáře  
      („S04E06 Window of Opportunity“, „Stargate SG‑1 4x06“, …)  
    ▸ Dotazy FILMU staví `plugin._query_variants` (zde jen seriály).
    """

    # ––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    @staticmethod
    def _unique_seq() -> tuple[list[str], set[str]]:
        """Pomocný factory: (ordered list, seen‑set)."""
        return ([], set())




    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class QueryBuilder
    # tv (upraveno: 13.12.2025 21:33 CET (Europe/Prague) – Vlna 1 = celý název seriálu + kód; Vlna 2 = epizodní název / kód-napřed; Vlna 3 = další aliasy; “pilot” nikdy)
    # ---------------------------------------------------------------------------- #
    @staticmethod
    def tv(
        tv_names: Sequence[str],
        ep_names: Sequence[str],
        season: int,
        episode: int,
    ) -> list[str]:
        """
        Sestaví **unikátní** sadu dotazů pro TV epizodu.

        DŮLEŽITÉ (co se mění proti staré verzi):
          • První vlna už NENÍ "s01e03 Pri" / "s01e03 Útě".
            První vlna je vždy: "<celý název seriálu> + (SxxEyy / 1xYY / 01xYY)".
          • “pilot” v dotazech nikdy (ani “pilotní”).
          • Dotazy jsou seřazené tak, aby plugin.py mohl bezpečně řezat po blocích 6/6/6:
              - queries[0:6]   = Vlna 1 (nejpřísnější, nejjistější)
              - queries[6:12]  = Vlna 2 (ep title / kód-napřed)
              - queries[12:18] = Vlna 3 (další aliasy seriálu + kód; fallback short-token)
              - queries[18:]   = “soft” dotazy (jen když je opravdu málo výsledků)

        Pozn.: Pokud je k dispozici jen 1 seriálový název, nebo chybí epizodní názvy,
        některé bloky budou kratší – plugin slicing to zvládne. Priorita pořád platí.
        """

        # --- lokální helpery -------------------------------------------------
        def _short_token(name: str) -> str:
            """První 2–3 písmena z 1. slova – fallback až do pozdějších vln."""
            m = re.match(r"\w{2,3}", name)
            return m.group(0) if m else ""

        def _is_generic(ep: str) -> bool:
            """Je epizodní název příliš obecný (Epizoda 1, Episode 1, apod.)?"""
            for w in re.split(r"[^\w]+", ep.lower()):
                if w.isdigit():
                    return True
                if w in GENERIC_EP:  # obsahuje mj. "pilot", "pilotní" apod.
                    return True
            return False

        def _has_pilot(ep: str) -> bool:
            """Obsahuje název epizody zakázané slovo 'pilot' (vč. 'pilotní')?"""
            for w in re.split(r"[^\w]+", ep.lower()):
                if w in {"pilot", "pilotni", "pilotní"}:
                    return True
            return False

        # --- příprava aliasů -------------------------------------------------
        tv_names = [t.strip() for t in tv_names if t and t.strip()]
        ep_names = [e.strip() for e in ep_names if e and e.strip()]

        # dedupe (case-insensitive), zachovej pořadí
        _seen_tv: set[str] = set()
        _tv_u: list[str] = []
        for t in tv_names:
            k = t.casefold()
            if k in _seen_tv:
                continue
            _seen_tv.add(k)
            _tv_u.append(t)
        tv_names = _tv_u

        _seen_ep: set[str] = set()
        _ep_u: list[str] = []
        for e in ep_names:
            k = e.casefold()
            if k in _seen_ep:
                continue
            _seen_ep.add(k)
            _ep_u.append(e)
        ep_names = _ep_u

        # Klíčové: *vyřadíme* jakékoliv epizodní názvy obsahující "pilot"
        ep_names_no_pilot = [e for e in ep_names if not _has_pilot(e)]
        ep_names_non_generic = [e for e in ep_names_no_pilot if not _is_generic(e)]

        # --- kódy epizody ----------------------------------------------------
        sxe  = f"s{season:02d}e{episode:02d}"
        xep1 = f"{season}x{episode:02d}"
        xep2 = f"{season:02d}x{episode:02d}"
        codes = (sxe, xep1, xep2)

        # Rozdělení aliasů:
        #   • primární = první 2 názvy (typicky CZ + EN/orig)
        #   • alternativní = zbytek
        primary_tv = tv_names[:2]
        alt_tv_all = tv_names[2:]

        # --- sestavení vln ---------------------------------------------------
        wave1: list[str] = []
        wave2: list[str] = []
        wave3: list[str] = []
        wave4: list[str] = []

        # VLNA 1 (6): <celý seriál> + kód
        for ser in primary_tv:
            for code in codes:
                wave1.append(f"{ser} {code}")

        # VLNA 2 (6): <celý seriál> + epizodní název (nejlepší 1–3) + doplnění “kód-napřed”
        for ser in primary_tv:
            for ep in ep_names_non_generic[:3]:
                wave2.append(f"{ser} {ep}")

        # doplň do 6: kód-napřed (někdy Webshare líp matchuje, když je kód na začátku)
        if len(wave2) < 6:
            for code in codes:
                for ser in primary_tv:
                    wave2.append(f"{code} {ser}")
                    if len(wave2) >= 6:
                        break
                if len(wave2) >= 6:
                    break

        # VLNA 3 (6): další aliasy seriálu + kód (max 2 aliasy → 6 dotazů)
        for ser in alt_tv_all[:2]:
            for code in codes:
                wave3.append(f"{ser} {code}")

        # Pokud nemáme dost alternativních aliasů, doplň fallback short-token dotazy (poslední záchrana přísné části)
        if len(wave3) < 6:
            _tok_seen: set[str] = set()
            for nm in tv_names:
                tok = _short_token(nm)
                if not tok or tok in _tok_seen:
                    continue
                _tok_seen.add(tok)
                for code in codes:
                    wave3.append(f"{code} {tok}")
                    if len(wave3) >= 6:
                        break
                if len(wave3) >= 6:
                    break

        # VLNA 4 (soft, jen když je opravdu málo výsledků):
        #  • zbytek alternativních aliasů + kód
        #  • seriál + název epizody (všechny, bez “pilot”)
        #  • short-token dotazy (všechny unikátní tokeny)
        for ser in alt_tv_all[2:]:
            for code in codes:
                wave4.append(f"{ser} {code}")

        for ser in tv_names:
            for ep in ep_names_no_pilot:
                wave4.append(f"{ser} {ep}")

        _tok_seen2: set[str] = set()
        for nm in tv_names:
            tok = _short_token(nm)
            if not tok or tok in _tok_seen2:
                continue
            _tok_seen2.add(tok)
            for code in codes:
                wave4.append(f"{code} {tok}")

        # --- finální unikátní pořadí -----------------------------------------
        out = OrderedDict()  # zachová pořadí přidání + eliminuje duplicity
        for q in (wave1 + wave2 + wave3 + wave4):
            q = (q or "").strip()
            if not q:
                continue
            out.setdefault(q, None)

        return list(out.keys())












    # `QueryBuilder.movie()` a obálka `build_movie_queries()` ODSTRANĚNY (Φ-C, 30.09.2026, E2 inventura):
    # nikdo je nevolal. Dotazy filmu staví `plugin._query_variants` (přesun do QueryBuilderu je kandidát
    # samostatné změny — mění pořadí dotazů, proto až s měřením původu).


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_engine.py
# score_sort_key / score_text  (vytvořeno: 29.09.2026 14:44 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
# Φ0 (plán ux_latency, audit A06 F12): `Release.score` je od ranking v2 N-TICE (`tuple(base_score) +
# (penalty,)`, řazení vzestupně = nižší je lepší), dataclass ale deklaruje `int = 0` a volající
# s ním zacházeli jako s číslem: `int(score)` v logu STREAM_ORDER_FINAL i v SEARCH SUMMARY
# vyhodil TypeError, který `except: pass` tiše spolkl (0 řádků za 60 dní), a řazení pickeru
# nového UI (`-float(score)`) spadlo celé. Jedno pravidlo pro řazení a jedno pro text.

# Neúplný výsledek vlny (selhal dotaz) smí v cache žít jen po dobu práce s jedním výpisem.
PARTIAL_RESULT_TTL_S = 600


def releases_from_records(records: object, log: Optional[Callable[..., None]] = None) -> Optional[List["Release"]]:
    """Streamy ze záznamů cache (`asdict(Release)` uložené jako JSON) — SSOT pro cache hledání i cache
    předstaženého dílu.

    Cache sdílí víc verzí doplňku (aktualizace za běhu: služba stará, plugin nový; návrat ke starší verzi).
    Klíč, který tahle verze nezná, se proto zahodí (a zaloguje), chybějící pole má výchozí hodnotu.
    Záznam, ze kterého stream postavit NEJDE, znehodnotí celý seznam → vrací None a volající hledá znovu
    (tichým vynecháním jednoho záznamu by se z výpisu ztratil stream). None i pro vstup, který není seznam."""
    if not isinstance(records, list):
        return None
    known = {f.name for f in _dc_fields(Release)}
    out: List[Release] = []
    dropped: set = set()
    for rec in records:
        if not isinstance(rec, dict):
            if log:
                log("CACHE_RECORD_BAD", "not_dict", type(rec).__name__)
            return None
        extra = [k for k in rec if k not in known]
        dropped.update(extra)
        try:
            out.append(Release(**{k: v for k, v in rec.items() if k in known}))
        except Exception as exc:
            if log:
                log("CACHE_RECORD_BAD", repr(exc)[:200], str(rec.get("ident") or ""))
            return None
    if dropped and log:
        log("CACHE_RECORD_UNKNOWN_KEYS", ",".join(sorted(str(k) for k in dropped)), len(out))
    return out


def score_sort_key(score: object) -> tuple:
    """Řadicí klíč skóre releasu (nižší = lepší) pro všechny tvary, které se v kódu vyskytují:
    n-tice z rankingu, list po průchodu JSONem (`release_view.json`), číslo (výchozí `0`), None."""
    if isinstance(score, (tuple, list)):
        return tuple(score)
    if isinstance(score, (int, float)):
        return (score,)
    return ()


def score_text(score: object) -> str:
    """Čitelný tvar skóre pro logy: `(0, 1, 3)` → `0/1/3`; prázdné → `-`."""
    key = score_sort_key(score)
    if not key:
        return "-"
    return "/".join(str(int(v)) if isinstance(v, (int, float)) and float(v).is_integer() else str(v)
                    for v in key)


# ─────────────────────────────────────────────────────────────────────────────
#  FILTR
# ─────────────────────────────────────────────────────────────────────────────
class ReleaseFilter:
    """
    **Statické** metody pro vyřazení nevyhovujících souborů,
    enrich metadat a výpočet konečného *score*.
    """



    # 2025-08-19 11:27 CEST (Europe/Prague) – ReleaseFilter.enrich(): EP_RE nově dovolí i tvary „1x4“ (dříve jen „1x04“)
    @staticmethod
    def enrich(item: dict) -> Optional[Release]:
        r"""
        Převede syrovou dict strukturu z `WebshareClient.search()` na objekt
        `Release` nebo vrátí `None`, pokud release neprošel základními filtry
        (ext, min-size, přípona…).

        ✦ Úpravy 07/2025 – TV epizody:
            • pokud název obsahuje vzor SxxEyy nebo 1xYY → size-check se
              zjemní na 50 MB, aby epizody kolem 100 MB nepadaly
            • pro ostatní releasy zůstávají (snížené) limity z MIN_FILE_MB_BY_QUALITY

        ✦ Aktualizace 2025-08-19 11:27 CEST (Europe/Prague):
            • `EP_RE` sjednoceno na `(?:s\d{1,2}e\d{1,2}|\d{1,2}[xX]\d{1,2})` – zachytí i „1x4“,
              nejen „1x04“. Velikostní práh 50 MB pro epizody tím bude správně uplatněn i na tyto releasy.
        """
        name     = item["name"]
        size_mb  = item.get("size", 0) / 1_048_576
        # – 1) přípona (SSOT `video_ext_of`) –
        if not video_ext_of(name):
            return None

        # – 2) minimální velikost (dynamicky) –
        EP_RE        = re.compile(r"(?:s\d{1,2}e\d{1,2}|\d{1,2}[xX]\d{1,2})", re.I)
        is_episode   = bool(EP_RE.search(name))

        q            = quality(name)
        min_size_mb  = 50 if is_episode else MIN_FILE_MB_BY_QUALITY.get(q, 250)
        if size_mb < min_size_mb:
            return None

        # – 3) jazyky, kvalita, konstrukce Release –
        aud, sub = parse_langs(name)
        return Release(
            ident   = item["ident"],
            name    = name,
            size    = item["size"],
            quality = q,
            audios  = aud,
            subs    = sub,
            est_min = int(item.get("video_length", 0) / 60) or None,

            # — NOVĚ: metadata z Webshare `/search` pro logovací summary —
            ws_width  = int(item.get("video_width") or 0) or None,
            ws_height = int(item.get("video_height") or 0) or None,
            ws_len_s  = int(item.get("video_length") or 0) or None,
            ws_pos    = (int(item.get("positive_votes") or 0)
                         if "positive_votes" in item else None),
            ws_neg    = (int(item.get("negative_votes") or 0)
                         if "negative_votes" in item else None),

            # — NOVĚ: multi-source podpora (Fastshare integrace 21.01.2026) —
            source         = item.get("source", "webshare"),
            fs_download_url = item.get("fs_download_url"),
            fs_hash        = item.get("fs_hash"),
        )




    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    @staticmethod
    def compute_score(r: Release) -> tuple[int, int, int]:
        """
        Lexikografické skóre pro řazení release-listu.

        1) ★ MATCH   – 0 (ano) / 1 (ne)                → potvrzené shody napřed
        2) kvalita   – QUALITY_RANK (0 = 2160p …)       → lepší rozlišení výš
        3) velikost  – -r.size (větší soubor = lepší)   → bitrate ve stejné řadě
        """
        star_flag = 0 if r.match else 1
        qual_rank = QUALITY_RANK.get(r.quality, 99)
        return (star_flag, qual_rank, -r.size)



# ─────────────────────────────────────────────────────────────────────────────
#  SEARCH ENGINE
# ─────────────────────────────────────────────────────────────────────────────
# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_engine.py
# _dedupe_multi_source  (vytvořeno: 21.01.2026 23:15 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _dedupe_multi_source(
    ws_items: List[dict],
    fs_items: List[dict],
    size_tolerance: float = 0.05,
) -> List[dict]:
    """
    Sloučí výsledky z Webshare a Fastshare s deduplikací.

    Pravidla:
      • Webshare má vždy přednost (všechny WS výsledky se zachovají)
      • Fastshare výsledek se přidá JEN pokud neexistuje duplicita
      • Duplicita = normalizovaný název shodný + velikost ±5%

    Args:
        ws_items: Seznam výsledků z Webshare (dict s klíči: name, size, ...)
        fs_items: Seznam výsledků z Fastshare (dict s klíči: name, size, source="fastshare", ...)
        size_tolerance: Tolerance velikosti pro duplicitu (default 5%)

    Returns:
        Sloučený seznam (WS + unikátní FS)
    """
    if not fs_items:
        return ws_items

    if not ws_items:
        return fs_items

    # Normalizace názvu pro porovnání
    def _norm_name(name: str) -> str:
        """Normalizuje název: lowercase, bez speciálních znaků, bez mezer."""
        if not name:
            return ""
        # Lowercase
        n = name.lower()
        # Odstraníme příponu
        n = re.sub(r"\.(mkv|avi|mp4|m4v|mov|wmv|flv|webm|ts|m2ts)$", "", n, flags=re.I)
        # Pouze alfanumerické znaky
        n = re.sub(r"[^a-z0-9]", "", n)
        return n

    # Vytvoříme index WS výsledků: (norm_name, size) → True
    ws_index: dict[tuple[str, int], bool] = {}
    for item in ws_items:
        try:
            norm = _norm_name(item.get("name", ""))
            size = int(item.get("size", 0) or 0)
            if norm:
                ws_index[(norm, size)] = True
        except Exception:
            continue

    # Filtrujeme FS výsledky
    merged = list(ws_items)  # Kopie WS

    for fs_item in fs_items:
        try:
            fs_norm = _norm_name(fs_item.get("name", ""))
            fs_size = int(fs_item.get("size", 0) or 0)

            if not fs_norm:
                continue

            # Kontrola duplicity: hledáme WS s podobným názvem a velikostí
            is_dupe = False
            for (ws_norm, ws_size), _ in ws_index.items():
                # Název musí být shodný
                if ws_norm != fs_norm:
                    continue
                # Velikost musí být v toleranci ±5%
                if ws_size > 0 and fs_size > 0:
                    ratio = abs(fs_size - ws_size) / max(ws_size, 1)
                    if ratio <= size_tolerance:
                        is_dupe = True
                        break
                elif ws_size == fs_size:
                    # Oba mají 0 nebo stejnou velikost
                    is_dupe = True
                    break

            if not is_dupe:
                merged.append(fs_item)

        except Exception:
            # Φ-E (30.09.2026, cross-check Flash F5): položku, kterou nejde POROVNAT (vadná velikost),
            # nezahazujeme — jen ji nelze označit za duplicitu. Rozhodne o ní filtr jako o každé jiné.
            if isinstance(fs_item, dict):
                merged.append(fs_item)
            continue

    return merged


# ---------------------------------- SSOT ------------------------------------ #
# richmovie_engine.py
# Kontext filtru dílu + penalizace názvu (Φ-A 30.09.2026, plán PLAN_search_efficiency_20260929, E3-F04)
# ---------------------------------------------------------------------------- #
# Dřív se tytéž odvozeniny (STOP, kódy, varianty názvu seriálu, „jednoslovný seriál“) počítaly dvakrát:
# v `search_one` a znovu — bez výjimky HΦ5 — ve větvi CACHE_HIT `search_wave`. Druhá kopie vracela
# správnému souboru s cizojazyčným názvem penaltu, kterou mu první odpustila. Jedno místo = jedna pravda.
_TV_STOP = frozenset({
    # CZ
    "v", "ve", "s", "z", "na", "do", "u", "o", "a", "i", "se",
    # EN
    "the", "of", "in", "on", "and", "to", "for", "at", "by",
    # FR/ES drobky
    "de", "le", "la", "du",
})
_TV_SE_RE = re.compile(r"^(?:s0?\d{1,2}\s*e0?\d{1,2}|0?\d{1,2}\s*x\s*0?\d{1,2}|e\d{2,3})$", re.I)
# prefix = část před ep-kódem (SxxEyy / 1x01). Tam chceme být u jednoslovných seriálů nejpřísnější.
_TV_CODE_POS_RE = re.compile(
    r"\b(?:s0?\d{1,2}\s*e0?\d{1,2}|0?\d{1,2}\s*x\s*0?\d{1,2}|0?\d{1,2}x0?\d{1,2})\b",
    re.I,
)
# Obecné "bezpečné" tokeny, které často patří do technického suffixu releasu.
_TV_META_OK = frozenset({
    # rozlišení / formát
    "2160p", "1080p", "720p", "576p", "480p", "360p", "320p", "240p",
    "4k", "uhd", "fhd", "hd", "sd",
    # zdroj / typ
    "bluray", "bdrip", "brrip", "bd", "bdremux", "remux", "bdmv",
    "web", "webrip", "webdl", "web-dl", "hdrip", "dvdrip", "dvd", "hdtv", "ts",
    # kodeky
    "x264", "x265", "h264", "h265", "hevc", "avc", "av1", "10bit", "8bit",
    # audio (tokeny po norm: dts hd ma / ddp / eac3 / truehd / atmos)
    "aac", "ac3", "dd", "ddp", "eac3", "dts", "truehd", "atmos", "flac", "mp3",
    "hdma", "ma",
    # edice
    "proper", "repack", "rerip", "internal", "complete", "uncut", "extended", "limited", "remastered",
    "directors", "director", "cut", "dc",
    # jazyky / subs
    "cz", "cze", "czech", "sk", "svk", "slovak", "en", "eng", "pl", "hun", "de", "ger", "ita", "fre", "spa",
    "multi", "dual", "dub", "dubbed", "dab", "dabing",
    "sub", "subs", "subtitles", "titulky",
})


class TvFilterContext(object):
    """Odvozeniny vstupů filtru dílu — počítají se JEDNOU na vlnu (`tv_filter_context`)."""

    __slots__ = ("codes", "words", "short_only", "ep_title_variants", "epi_all", "ser_variants",
                 "ser_tokens", "ep_sets", "target_canon", "generic_ep", "tmdb_title_tokens",
                 "one_word_set")


def tv_filter_context(
    title_norms: Sequence[str],
    ser_title_variants: Sequence[Sequence[str]] = (),
    ep_title_variants: Sequence[Sequence[str]] = (),
) -> TvFilterContext:
    """Čistá funkce: z tokenů titulu, variant názvu seriálu a variant názvu dílu odvodí vše, co filtr dílu
    a penalizace názvu potřebují. Logika 1 : 1 z `search_one` (3.5.169), jen na jednom místě."""
    fc = TvFilterContext()
    tokens = [t for t in (title_norms or ()) if t and t not in _TV_STOP]
    codes = [t for t in tokens if _TV_SE_RE.fullmatch(t)]
    words = [t for t in tokens if t not in codes]

    # Heuristika „krátký seriálový token“
    short_only = (not ep_title_variants) and (len(words) == 1 and len(words[0]) <= 3)
    if not ep_title_variants:
        ep_title_variants = [] if short_only else [words[-2:] if len(words) >= 2 else words]

    epi_all = {w for v in ep_title_variants for w in v}

    # 26.12.2025 – OR přes varianty názvu seriálu:
    #   • ser_title_variants je seznam variant, každá varianta je seznam tokenů
    #   • ser_full = True, pokud sedí *alespoň jedna* varianta (tj. tokeny jedné varianty všechny)
    ser_variants: List[List[str]] = []
    if ser_title_variants:
        try:
            for v in ser_title_variants:
                if not v:
                    continue
                vv = [t for t in v if t and t not in _TV_STOP]
                vv = [t for t in vv if t not in epi_all]  # pojistka: ep slova nesmí být seriálové tokeny
                # pojistka proti šumu: 1 krátký token (<=3) ignoruj
                if len(vv) == 1 and len(vv[0]) <= 3:
                    continue
                if vv:
                    ser_variants.append(vv)
        except Exception:
            ser_variants = []

    # Fallback: původní chování (ser_tokens jako „sloučené“ seriálové tokeny)
    ser_tokens = [w for w in words if w not in epi_all]
    if ser_variants:
        # union tokenů pro logging + numerické signatury + fallback heuristiky
        ser_tokens = sorted({t for v in ser_variants for t in v})

    ep_sets = [set(v) for v in ep_title_variants if v]
    # HΦ3: kanonické cílové kódy (SSOT) — sjednotí padding varianty s cílem
    target_canon = canon_ep_codes(" ".join(codes)) if codes else set()

    # „globální“ příznak – dříve používaný (ponechán pro logging/kompat.)
    generic_ep = (bool(ep_sets) and all((w in GENERIC_EP or w.isdigit()) for v in ep_sets for w in v))

    # SANITIZE (TMDb title tokeny) – používáme:
    #   • pro odfiltrování banned_keys (ban token nikdy nesmí zabanovat token z TMDb názvu)
    #   • pro title_penalty (TMDb tokeny nikdy nesmí být “bad”)
    try:
        if ser_variants:
            tmdb_title_tokens = {t for v in ser_variants for t in v if t}
        else:
            tmdb_title_tokens = {t for t in ser_tokens if t}
    except Exception:
        tmdb_title_tokens = set()

    # SPEC: jednoslovné seriály (Lost, You, Dark…) – penalizace "balastu" v title-bloku.
    #   • title_penalty jen pokud je seriál skutečně “one-word” (primary varianta po STOP/epi filtraci)
    is_one_word_series = False
    try:
        if ser_variants:
            _primary = ser_variants[0]
            if len(_primary) == 1:
                is_one_word_series = True
            elif len(_primary) == 2 and _primary[0] and _primary[1].isdigit() and len(_primary[1]) == 4:
                # např. "lost 2004" → core token stále jednoslovný
                is_one_word_series = True
        else:
            if len(ser_tokens) == 1 and ser_tokens[0]:
                is_one_word_series = True
    except Exception:
        is_one_word_series = False

    one_word_set: set = set()
    if is_one_word_series:
        one_word_tokens: List[str] = []
        try:
            if ser_variants:
                _seen_ow: set = set()
                for v in ser_variants:
                    if not v:
                        continue
                    if len(v) == 1:
                        t0 = v[0]
                        if t0 and t0 not in _seen_ow:
                            one_word_tokens.append(t0)
                            _seen_ow.add(t0)
                        continue
                    if len(v) == 2 and v[0] and v[1].isdigit() and len(v[1]) == 4:
                        t0 = v[0]
                        if t0 and t0 not in _seen_ow:
                            one_word_tokens.append(t0)
                            _seen_ow.add(t0)
                        continue
            if (not one_word_tokens) and (len(ser_tokens) == 1) and ser_tokens[0]:
                one_word_tokens = [ser_tokens[0]]
        except Exception:
            one_word_tokens = []
        one_word_set = {t for t in one_word_tokens if t}

    fc.codes = codes
    fc.words = words
    fc.short_only = short_only
    fc.ep_title_variants = ep_title_variants
    fc.epi_all = epi_all
    fc.ser_variants = ser_variants
    fc.ser_tokens = ser_tokens
    fc.ep_sets = ep_sets
    fc.target_canon = target_canon
    fc.generic_ep = generic_ep
    fc.tmdb_title_tokens = tmdb_title_tokens
    fc.one_word_set = one_word_set
    return fc


def tv_title_penalty(name: str, fc: TvFilterContext) -> Tuple[int, List[Tuple[str, str]]]:
    """Penalizace názvu u jednoslovných seriálů (jen ŘAZENÍ, nikdy filtr). Vrací (penalta, události do logu
    jako dvojice (událost, JSON)). Čistá funkce — volá ji hlavní cesta filtru i větev CACHE_HIT.

    Výjimka HΦ5 (07.07.2026): soubor s PŘESNÝM kódem cíle A epizodní frází (≥ 2 slova) penaltu nedostane
    (cizojazyčný alt-titul jako prefix „Priatelia Friends S04E06…“ je správný soubor, ne balast)."""
    events: List[Tuple[str, str]] = []
    if not (fc.one_word_set and fc.codes):
        return 0, events
    n = norm(name)
    m = _TV_CODE_POS_RE.search(n)
    if not m:
        return 0, events

    penalty = 0
    bad: List[str] = []
    prefix = n[:m.start()].strip()
    ptoks = [t for t in prefix.split() if t]

    # "významové" tokeny v title-bloku (ignorujeme stopwords a roky)
    meaningful = [
        t for t in ptoks
        if (t not in _TV_STOP) and not (t.isdigit() and len(t) == 4)
    ]

    _rcanon = canon_ep_codes(n)
    _code_exact = bool(_rcanon and fc.target_canon and (_rcanon & fc.target_canon))
    _ep_phr = [" ".join([t for t in v if t]).strip() for v in fc.ep_title_variants if v]
    _ep_phr = [p for p in _ep_phr if len(p.split()) >= 2]
    _waived = bool(_code_exact and _ep_phr and any(_phrase_contains(n, p) for p in _ep_phr))

    if _waived:
        events.append(("TITLE_PENALTY_WAIVED",
                       json.dumps({"reason": "code+ep_phrase", "prefix": prefix}, ensure_ascii=False)))
        return 0, events

    # 1) musí se objevit seriálový token (lost / ztraceni / …) – jinak je to podezřelé
    series_pos = [i for i, t in enumerate(meaningful) if t in fc.one_word_set]
    if not series_pos:
        penalty += 3
    else:
        # seriálový token má být první významový token v prefixu (jinak to často znamená "The Lost Symbol" apod.)
        if series_pos[0] != 0:
            penalty += 2

    # 2) cizí slova v prefixu (kromě ep-title tokenů, generik, TMDb title tokenů a technických meta tokenů)
    allowed = set(fc.one_word_set) | set(fc.epi_all) | set(fc.tmdb_title_tokens) | GENERIC_EP | _TV_META_OK
    for t in meaningful:
        if t in allowed:
            continue
        if t.isdigit():
            continue
        if len(t) <= 1:
            continue
        bad.append(t)
    if bad:
        penalty += min(6, len(bad))

    if penalty:
        events.append(("TITLE_PENALTY", json.dumps(
            {
                "penalty": penalty,
                "one_word_tokens": sorted(list(fc.one_word_set)),
                "prefix": prefix,
                "meaningful": meaningful,
                "bad": bad[:12],
            },
            ensure_ascii=False,
        )))
    return penalty, events


class FetchResult(object):
    """Syrový výsledek JEDNOHO dotazu (jen síť, žádné rozhodování filtru) + čísla pro měření.

    `page_of[ident]` = odkud položka přišla: "1".."5" = stránka Webshare, "fs" = Fastshare,
    "fsy" = Fastshare po opakování bez roku."""

    __slots__ = ("query", "items", "ws_raw", "ws_pages", "fs_raw", "fs_calls", "ms", "page_of", "error",
                 "reused")

    def __init__(self, query: str) -> None:
        self.query = query
        self.reused = False     # výsledek převzat z paměti hledání (žádný požadavek na síť)
        self.items: List[dict] = []
        self.ws_raw = 0
        self.ws_pages = 0
        self.fs_raw = 0
        self.fs_calls = 0
        self.ms = 0
        self.page_of: dict = {}
        self.error = ""

    def as_reused(self) -> "FetchResult":
        """Tentýž výsledek pro další vlnu téhož hledání — položky sdílené, čísla sítě nulová."""
        r = FetchResult(self.query)
        r.items, r.page_of = self.items, self.page_of
        r.ws_raw, r.fs_raw = self.ws_raw, self.fs_raw
        r.reused = True
        return r


# ---------------------------------- SSOT ------------------------------------ #
# richmovie_engine.py
# movie_ban_hit  (Φ-B 30.09.2026 — zákaz ostatních dílů kolekce bez ztráty správných filmů, E3-F01)
# ---------------------------------------------------------------------------- #
# Zákaz kolekce chrání před pokračováními bez roku v názvu („Nezvratný osud 2“, „Matrix Reloaded“). Banovala
# se ale i slova SPOLEČNÁ celé franšíze („star“, „wars“, „epizoda“) — při hledání „Návrat Jediho“ tak filtr
# zahodil ~45 správných souborů „Star Wars … Návrat Jediho (1983)“ a prošly 4. Dvě pojistky:
#   (a) obecné slovo pokračování („část“, „part“, „díl“…) samo nezakazuje soubor, který nese POVOLENÝ ROK;
#   (b) soubor, který nese cílový titul jako sousedící frázi (≥ 2 významová slova), a ten titul NENÍ
#       podfrází názvu žádného sourozence, je jednoznačně cílový film → zákaz se nepoužije.
# Pokračování zůstávají zamítnutá: „nezvratný osud“ i „hunger games“ JSOU podfrází názvů sourozenců.
MOVIE_BAN_GENERIC = frozenset({
    "part", "cast", "dil", "chapter", "kapitola", "episode", "epizoda", "vol", "volume", "film", "movie",
})
_MOVIE_TITLE_STOP = frozenset({
    "the", "a", "an", "of", "and", "z", "o", "s", "v", "ve", "na", "do", "u", "i", "se", "de", "le", "la", "du",
})
MOVIE_UNAMBIGUOUS_MIN_WORDS = 2


def movie_ban_hit(n_norm: str, banned_keys: Sequence[str], title_norms: Sequence[str],
                  has_allowed_year: bool = False) -> Tuple[Optional[str], str]:
    """Rozhodnutí zákazu kolekce pro film. Vrací (zásah | None, důvod): zásah = ban token, který soubor
    zamítá; None = soubor zákaz nezamítá. Důvod: "" (žádný ban token v názvu), "generic" / "unambiguous"
    (token v názvu je, ale platí pojistka), "ban" (zamítnout). Čistá funkce."""
    if not banned_keys:
        return None, ""
    nn = " %s " % n_norm
    hits = [bk for bk in banned_keys if bk and (" %s " % bk) in nn]
    if not hits:
        return None, ""
    real = [h for h in hits if h not in MOVIE_BAN_GENERIC]
    if not real and has_allowed_year:
        return None, "generic"
    phrases = [" %s " % b for b in banned_keys if b and " " in b]
    for t in (title_norms or ()):
        words = [w for w in str(t or "").split() if w and w not in _MOVIE_TITLE_STOP]
        if len(words) < MOVIE_UNAMBIGUOUS_MIN_WORDS:
            continue
        needle = " %s " % t
        if needle in nn and not any(needle in ph for ph in phrases):
            return None, "unambiguous"
    return (real[0] if real else hits[0]), "ban"


class SearchCancelled(Exception):
    """Uživatel hledání zrušil (Zrušit / Zpět v dialogu) — Φ5A, 29.09.2026, audit A06 R10.

    Vlna se ukončí BEZ zápisu do cache a bez spuštění MediaInfo: částečný výsledek se nesmí uložit jako
    hotový (R2 — marker „hotovo“ až po absolutním úspěchu). Dřív engine zrušení nečetl vůbec a seznam se
    po „Zrušit“ stejně vykreslil."""


def _cancel_fn(progress_cb: Any) -> Optional[Callable[[], bool]]:
    """`iscanceled` dialogu hledání, pokud ho `progress_cb` má (jinak None = nelze zrušit)."""
    fn = getattr(progress_cb, "iscanceled", None)
    return fn if callable(fn) else None


def _raise_if_cancelled(cancel_check: Optional[Callable[[], bool]]) -> None:
    if cancel_check is None:
        return
    try:
        cancelled = bool(cancel_check())
    except Exception:
        cancelled = False
    if cancelled:
        raise SearchCancelled()


class SearchEngine:
    """
    Orchestrace vyhledávání na Webshare (+ volitelně Fastshare).

    Parametry
    ---------
    get_client      : Callable[[], WebshareClient]
        Funkce, která kdykoliv vrátí *přihlášenou* instanci klienta.
        (plugin.py předá např. `lambda: _SESSION.client`)
    logger          : Callable[[str, object], None]
        Centralizovaný logger – používáme `plugin._log_event`.
    get_fastshare_client : Callable[[], FastshareClient | None]  (volitelné)
        Callback vracející přihlášený FastshareClient nebo None.
        Pokud je None nebo vrátí None, Fastshare se nepoužije.
    """

    # ------------------------------------------------------------------ #
    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › třída SearchEngine
    # __init__  (upraveno: 21.01.2026 23:15 CET, Europe/Prague – přidán get_fastshare_client)
    # ---------------------------------------------------------------------------- #
    def __init__(
        self,
        get_client: Callable[[], WebshareClient],
        logger: Callable[..., None],
        *,                       # parametry za * jsou pouze pojmenované
        enable_probe: bool = True,
        get_fastshare_client: Callable[[], "FastshareClient | None"] | None = None,
    ) -> None:
        """
        Inicializace vyhledávacího enginu.

        • `get_client`           – callback vracející přihlášený `WebshareClient`
        • `logger`               – funkce pro logování (plugin._log_event)
        • `enable_probe`         – globální přepínač MediaInfo sondování
        • `get_fastshare_client` – callback vracející přihlášený `FastshareClient` nebo None
                                   (Fastshare integrace 21.01.2026)
        """
        self._get_client   = get_client
        self._log          = logger
        self._enable_probe = enable_probe

        # — NOVĚ: Fastshare integrace (21.01.2026) —
        self._get_fs_client = get_fastshare_client

        # RAM ‑ cache pro již zjištěné MediaInfo bloky
        self._mi_cache: dict[str, dict] = {}
        self._lock = threading.Lock()

        # ⚡ NOVĚ: cache před‑kompilovaných regexů na základě id(banned_keys)
        #         → minimalizuje režii při opakovaném vyhledávání dílů
        self._banned_re_cache: dict[int, re.Pattern] = {}







    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # search_one (upraveno: 27.12.2025 19:49 CET (Europe/Prague) – SANITIZE: (1) banned_keys nikdy nesmí “banovat” token, který je součástí některé TMDb varianty názvu seriálu,
    #  (2) title_penalty: TMDb title tokeny nikdy nesmí být “bad”,
    #  (3) title_penalty se spouští pouze pro skutečně “one-word” seriály (primary TMDb varianta po STOP/epi filtraci); zachováno vše ostatní včetně numeric signature a guardů)
    # ---------------------------------------------------------------------------- #
    def search_one(  # noqa: C901
        self,
        query: str,
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        ser_title_variants: Sequence[Sequence[str]] = (),  # 26.12.2025 – OR přes varianty názvu seriálu (hlavní/alt)
        banned_keys: Sequence[str] = (),
        ep_title_variants: Sequence[Sequence[str]] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] | None = None,   # 2025-08-19 10:39 CEST (Europe/Prague)
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
        probe: bool = True,
        ep_soft: bool = False,  # 15.11.2025 19:07 CET, Europe/Prague – SOFT režim pro Vlnu X
        stats: Optional[dict] = None,   # Φ-E: `errors` += 1, když zdroj dotazu selhal (výsledek není úplný)
        ban_other_episodes: bool = False,  # Φ5B: zákaz jiného dílu kódem (místo 20k ban tokenů)
    ) -> List["Release"]:
        """
        Jeden `/search` dotaz → filtrovaný, seřazený seznam `Release`.

        [Aktualizováno: 2025-08-10 13:56 CEST] – DETAILNÍ LOGOVÁNÍ příčin odmítnutí (FILTER_REJECT) beze změny logiky.
        [Aktualizováno: 2025-08-19 08:03 CEST] – FIX: fallback `uncertain` kontroluje příponu z `rel.name` (splitext) proti `ALLOWED_VIDEO_EXTS`.
        [Aktualizováno: 2025-08-19 08:14 CEST] – FIX: fallback odmítne releasy s jiným ep-kódem (SxxEyy/xxXyy vč. „S01.E01“) nebo „E##“ bez sezóny.
        [Aktualizováno: 2025-08-19 08:34 CEST] – FIX (Rule C): pokud se chytne jen **generická** ep sada („episode 3“ apod.), je nutný i `ser_part`.
        [Aktualizováno: 2025-08-19 10:05 CEST] – SPEC: Jednoslovné názvy – Rule A (zpřísnění adjacency) používáme jen u krátkých názvů (≤5 znaků).
        [Aktualizováno: 2025-08-19 10:39 CEST] – Filtr roku: podpora `allowed_years` (seriál + série + epizoda); zpětně kompatibilní s `movie_year`.
        [Aktualizováno: 2025-12-26 16:35 CET] – FIX: numeric/alias názvy (11.22.63 vs Dallas 63) + Guard proti falešným průchodům Rule C bez tokenu seriálu.
        [Aktualizováno: 2025-12-26 21:06 CET] – FIX: ser_full (AND přes alt názvy) → OR přes varianty názvu seriálu (ser_title_variants).
        [Aktualizováno: 2025-12-27 19:49 CET] – SANITIZE: banned_keys a title_penalty „bad“ ignorují TMDb title tokeny; title_penalty běží jen pro “one-word” seriály.
        [Aktualizováno: 2026-09-30] – Φ-A: stažení (`_fetch_query`) a filtr (`_tv_filter`) jsou oddělené;
            vlna (`search_wave`) stahuje dotazy souběžně a filtruje sjednocení JEDNOU.
        """
        fetched = self._fetch_query(query, raw_event="RAW_SEARCH", cancel_check=cancel_check)
        if fetched.error and stats is not None:
            stats["errors"] = int(stats.get("errors", 0) or 0) + 1
        _items = [it for it in (sane_item(x) for x in fetched.items) if it is not None]
        return self._tv_filter(
            _items, label=query, runtimes=runtimes, title_norms=title_norms,
            ser_title_variants=ser_title_variants, banned_keys=banned_keys,
            ep_title_variants=ep_title_variants, movie_year=movie_year, allowed_years=allowed_years,
            bad_regex=bad_regex, progress_cb=progress_cb, probe=probe, ep_soft=ep_soft,
            ban_other_episodes=ban_other_episodes,
        )

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # _fetch_query / _fetch_wave / _union_fetched / _log_wave_yield
    # (Φ-A 30.09.2026 — SSOT stahování pro film i seriál + původ identu; plán PLAN_search_efficiency_20260929)
    # ---------------------------------------------------------------------------- #
    def _fetch_query(
        self,
        query: str,
        *,
        raw_event: str,
        cancel_check: Optional[Callable[[], bool]] = None,
    ) -> FetchResult:
        """Syrové položky jednoho dotazu: stránky Webshare + Fastshare, sloučené (`_dedupe_multi_source`).
        Jen síť a logy dotazu — žádné rozhodování filtru. `raw_event` = `RAW_SEARCH` (seriál) nebo
        `RAW_MOVIE_SEARCH` (film); formát řádků logu je stejný jako před rozdělením."""
        res = FetchResult(query)
        _t0 = time.monotonic()
        self._log(raw_event, query)

        # ❶ Webshare /search (smart pagination: min 2, max 5 stránek)
        #    Po 2 stránkách zkontrolujeme, zda máme video soubory.
        #    Pokud ne (API category filtr selhal), stahujeme další stránky.
        cli = self._get_client()
        ws_items: List[dict] = []
        # D4 (4.0.0): stránka má `WS_PAGE_SIZE` = 200 položek (dřív 100) → první požadavek přinese, co dřív dva;
        # strop 3 stránky = 600 položek (dřív 5 × 100 = 500 — nikdy méně).
        _WS_MAX_PAGES = 3
        for _pg in range(_WS_MAX_PAGES):
            _raise_if_cancelled(cancel_check)   # Φ5A: Zrušit mezi stránkami
            page = cli.search(query, offset=_pg * WS_PAGE_SIZE)
            res.ws_pages += 1
            if not page:
                break
            clean = self._sane_items(page)
            for it in clean:
                res.page_of.setdefault(it.get("ident"), str(_pg + 1))
            ws_items.extend(clean)
            if len(page) < WS_PAGE_SIZE:
                break
            # po první stránce (= dřívějších 200 položkách ze dvou stránek): další jen když ještě není žádné video
            has_video = any(os.path.splitext(str(it.get("name", "") or ""))[1].lower() in PAGING_VIDEO_EXTS
                            for it in ws_items)
            if has_video:
                break
            self._log("WS_NO_VIDEO_YET", query, len(ws_items))
        res.ws_raw = len(ws_items)
        self._log("WS_RESULTS", query, len(ws_items))

        # — Fastshare integrace (21.01.2026) —
        _raise_if_cancelled(cancel_check)       # Φ5A: Zrušit před Fastshare
        fs_items: List[dict] = []
        if self._get_fs_client:
            try:
                fs_cli = self._get_fs_client()
                if fs_cli:
                    res.fs_calls = 1
                    fs_items = self._sane_items(fs_cli.search(query, limit=200))
                    self._log("FS_RESULTS", query, len(fs_items))
            except Exception as fs_err:
                res.error = "fs"
                self._log("FS_ERROR", query, str(fs_err))
                # Toast při chybě - ale nerozbijeme flow
                try:
                    # Φ2: česká věta podle třídy chyby (detail je v FS_ERROR výše)
                    _rm_notif(net_error_message(fs_err)[0], xbmcgui.NOTIFICATION_WARNING, 3000, "Fastshare")
                except Exception:
                    pass
        res.fs_raw = len(fs_items)
        for it in fs_items:
            res.page_of.setdefault(
                it.get("ident"), "fsy" if it.get("_fs_match_mode") == "year_stripped" else "fs")
        if any(it.get("_fs_match_mode") == "year_stripped" for it in fs_items):
            res.fs_calls = 2

        # Sloučení výsledků (WS + unikátní FS)
        res.items = _dedupe_multi_source(ws_items, fs_items)
        self._log("MERGED_RESULTS", query, len(res.items))
        res.ms = int((time.monotonic() - _t0) * 1000)
        try:
            self._log("FETCH_STATS", json.dumps(
                {"q": query, "pages": res.ws_pages, "ws": res.ws_raw, "fs": res.fs_raw,
                 "fs_calls": res.fs_calls, "merged": len(res.items), "ms": res.ms}, ensure_ascii=False))
        except Exception:
            pass
        _raise_if_cancelled(cancel_check)       # Φ5A: Zrušit před filtrem (CPU)
        return res

    def _sane_items(self, items: object) -> List[dict]:
        """Položky zdroje v použitelném tvaru (`sane_item`); nepoužitelné jdou do logu, ne do výjimky —
        jedna vadná položka nesmí shodit dotaz ani vlnu (audit Fable F1-V5)."""
        out: List[dict] = []
        for raw in (items if isinstance(items, (list, tuple)) else []):
            it = sane_item(raw)
            if it is None:
                self._log("FILTER_REJECT", "", "item_error", repr(raw)[:160])
            else:
                out.append(it)
        return out

    def _fetch_wave(
        self,
        queries: Sequence[str],
        *,
        raw_event: str,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        stats: Optional[dict] = None,
        memo: Optional[dict] = None,
    ) -> Optional[List[FetchResult]]:
        """Stáhne dotazy vlny souběžně (jen síť). Vrací výsledky v pořadí DOTAZŮ, nebo None při zrušení.
        Selhání jednoho dotazu vlnu nepřeruší (prázdný výsledek + `WAVE_QUERY_ERR`); počet selhání jde do
        `stats["errors"]` — volající podle něj pozná, že „nic nenalezeno“ není autoritativní (R2)."""
        _cancel_check = _cancel_fn(progress_cb)   # Φ5A: Zrušit v dialogu
        fetched: List[FetchResult] = [FetchResult(q) for q in queries]
        # Φ-C (30.09.2026, E1-F04 / E2-F04): TENTÝŽ dotaz se v jednom hledání stahuje JEDNOU. Vlna WX+ skládá
        # znovu dotazy z W1/W3/WX a záložní vlna filmu znovu primární dotazy — výsledek je týž, jen se podruhé
        # platilo sítí (8 % všech volání Webshare, špička 132 volání za minutu z jednoho zařízení). Shoda
        # je DOSLOVNÁ (stejný řetězec), paměť žije jen po dobu jednoho hledání a výsledek s chybou se do ní
        # neukládá (R2: selhání se neperzistuje).
        todo: dict = {}
        for i, q in enumerate(queries):
            if memo is not None and q in memo:
                fetched[i] = memo[q].as_reused()
            elif q in todo:
                todo[q].append(i)
            else:
                todo[q] = [i]
        for i, r in enumerate(fetched):
            if r.reused:
                self._log("FETCH_REUSED", r.query, len(r.items))
        total_q = len(todo)
        # S2 (10.10.2026): strop souběžných stažení = hodnota správce z Gate, jinak výchozí (Android 2) — `_fetch_pool_size`
        pool_size, pool_src, pool_fallback_reduces = _fetch_pool_size(max(1, min(FETCH_PARALLEL_MAX, total_q)))
        if todo:
            self._log("FETCH_POOL", pool_size, pool_src)   # → `SEARCH_PHASES` (`pool`, `pool_src`) — A/B měření S2
        errors = 0
        _cancelled = False
        if todo:
            with _f.ThreadPoolExecutor(max_workers=pool_size) as pool:
                futs = {pool.submit(self._fetch_query, q, raw_event=raw_event, cancel_check=_cancel_check): q
                        for q in todo}
                for idx, f in enumerate(_f.as_completed(list(futs)), 1):
                    q = futs[f]
                    first = todo[q][0]
                    try:
                        fetched[first] = f.result()
                    except SearchCancelled:
                        _cancelled = True
                    except Exception as _wave_exc:
                        # Beta.7 fix: log per-query exception místo silent
                        # swallow. Když všechny queries selžou, plugin pak může
                        # rozlišit "0 výsledků" vs "selhání" pro user-facing
                        # error message. Legacy behavior (no raise) zachováno —
                        # jednotlivé selhání nesmí přerušit celou vlnu.
                        errors += 1
                        fetched[first].error = "query"
                        self._log("WAVE_QUERY_ERR", repr(_wave_exc)[:200])
                        _note_fetch_pressure(_wave_exc, pool_size, pool_src, pool_fallback_reduces, self._log)
                    if _cancelled:
                        # Φ5A: čekající dotazy se už nespustí (běžící dojedou do svého timeoutu)
                        for _pending in futs:
                            _pending.cancel()
                        break
                    if progress_cb:
                        progress_cb(idx, total_q, "search")
        for q, idxs in todo.items():
            src = fetched[idxs[0]]
            if memo is not None and not src.error and not _cancelled:
                memo[q] = src
            for dup in idxs[1:]:
                fetched[dup] = src.as_reused()
                fetched[dup].error = src.error
                self._log("FETCH_REUSED", q, len(src.items))
        errors += sum(1 for x in fetched if x.error == "fs" and not x.reused)
        if stats is not None:
            stats["errors"] = int(stats.get("errors", 0)) + errors
        if _cancelled or (_cancel_check is not None and _cancel_check()):
            # Φ5A (R2): zrušená vlna NIC nekešuje a nespouští MI2 — částečný výsledek není hotový
            self._log("WAVE_CANCELLED", sum(len(x.items) for x in fetched))
            if stats is not None:
                stats["cancelled"] = True
            return None
        return fetched

    def _note_partial_hit(self, cache_key: str, stats: Optional[dict]) -> None:
        """Výsledek z cache pochází z vlny, ve které selhal dotaz → volající ho MUSÍ vidět jako neúplný
        (`stats["errors"]`), jinak by se z něj odvozený závěr bral jako autoritativní (R2; cross-check Pro A1)."""
        try:
            if not SEARCH_CACHE.is_partial(cache_key):
                return
            self._log("CACHE_HIT_PARTIAL", cache_key)
            if stats is not None:
                stats["errors"] = int(stats.get("errors", 0) or 0) + 1
                stats["cache_partial"] = True
        except Exception as exc:
            self._log("CACHE_HIT_PARTIAL_ERR", cache_key, repr(exc)[:200])

    def _cache_wave_result(self, cache_key: str, result: Sequence["Release"], wave_errors: int) -> None:
        """Uloží výsledek vlny do cache hledání. Vlna, ve které selhal některý dotaz (Webshare nebo
        Fastshare), je NEÚPLNÁ: uloží se jen na `PARTIAL_RESULT_TTL_S` — to stačí na překreslení téhož
        výpisu (obnova po MediaInfo spouští hledání znovu a čte cache), ale výpadek zdroje se tím
        nezapamatuje na 30 dní (R2: selhání se neperzistuje; cross-check Flash F3/F4, 30.09.2026)."""
        try:
            if wave_errors > 0:
                SEARCH_CACHE.put(cache_key, [asdict(r) for r in result], ttl_s=PARTIAL_RESULT_TTL_S)
                self._log("CACHE_PUT_PARTIAL", cache_key, len(result), "errors=%d" % wave_errors,
                          "ttl_s=%d" % PARTIAL_RESULT_TTL_S)
            else:
                SEARCH_CACHE.put(cache_key, [asdict(r) for r in result])
                self._log("CACHE_PUT", cache_key, len(result))
        except Exception as exc:
            self._log("CACHE_PUT_ERR", cache_key, repr(exc)[:200])

    def _union_fetched(self, fetched: Sequence[FetchResult]) -> Tuple[List[dict], dict]:
        """Sjednotí syrové položky dotazů podle identu (první výskyt v pořadí DOTAZŮ — deterministické).
        Vrací (položky, původ): původ[ident] = ["<index dotazu>:<stránka|fs|fsy>", …] = VŠECHNY dotazy,
        které ident vrátily. Do logu jde `WAVE_UNION` (součty) a `WAVE_ORIGIN` (dotazy + původ)."""
        union: List[dict] = []
        origin: dict = {}
        for qi, res in enumerate(fetched):
            for raw in res.items:
                it = sane_item(raw)
                if it is None:
                    self._log("FILTER_REJECT", "", "item_error", repr(raw)[:160])
                    continue
                ident = it.get("ident")
                tag = "%d:%s" % (qi, res.page_of.get(ident, "?"))
                if ident in origin:
                    origin[ident].append(tag)
                    continue
                origin[ident] = [tag]
                union.append(it)
        self._log("WAVE_UNION", sum(len(x.items) for x in fetched), len(union))
        try:
            self._log("WAVE_ORIGIN", json.dumps(
                {"queries": [x.query for x in fetched], "origin": origin}, ensure_ascii=False))
        except Exception as exc:
            self._log("WAVE_ORIGIN_ERR", repr(exc)[:200])
        return union, origin

    def _log_wave_yield(self, fetched: Sequence[FetchResult], origin: dict,
                        accepted: Sequence["Release"]) -> None:
        """Výtěžnost dotazů vlny do logu (`WAVE_YIELD`): co který dotaz stáhl, kolik z toho bylo nového,
        kolik přijal filtr a kolik přijatých našel JEN on. Nahrazuje dřívější řádky `WS_RESULTS <dotaz> <přijato>`
        (filtr už neběží po dotazech) a je podkladem pro rozhodnutí o dotazech (plán Φ-F)."""
        try:
            acc_ids = {r.ident for r in accepted}
            rows = []
            for qi, res in enumerate(fetched):
                mine = [i for i, tags in origin.items() if any(t.split(":", 1)[0] == str(qi) for t in tags)]
                first = [i for i in mine if origin[i][0].split(":", 1)[0] == str(qi)]
                acc = [i for i in mine if i in acc_ids]
                excl = [i for i in acc if len({t.split(":", 1)[0] for t in origin[i]}) == 1]
                rows.append({
                    "q": res.query, "ws": res.ws_raw, "pages": res.ws_pages, "fs": res.fs_raw,
                    "fs_calls": res.fs_calls, "ms": res.ms, "merged": len(res.items),
                    "new": len(first), "acc": len(acc), "excl": len(excl), "err": res.error,
                    "reused": bool(res.reused),
                    "acc_p2": sum(1 for i in acc if all(t.endswith(":2") for t in origin[i])),
                })
            self._log("WAVE_YIELD", json.dumps(rows, ensure_ascii=False))
        except Exception as exc:
            self._log("WAVE_YIELD_ERR", repr(exc)[:200])

    def _log_wave_timing(self, t_fetch: float, t_filter: float) -> None:
        """Rozpad času vlny do logu: stažení (souběžně, čas na hodinách) a filtr (CPU)."""
        try:
            self._log("WAVE_TIMING", json.dumps({
                "fetch_ms": int((t_filter - t_fetch) * 1000),
                "filter_ms": int((time.monotonic() - t_filter) * 1000)}))
        except Exception:
            pass

    @staticmethod
    def _apply_origin(releases: Sequence["Release"], origin: dict) -> None:
        """Původ (dotazy a stránky) na přijaté položky — nese se v cache až k výběru streamu."""
        for r in releases:
            try:
                r.origin = ",".join(origin.get(r.ident) or ())
            except Exception:
                pass

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # _tv_filter  (Φ-A 30.09.2026 — tělo filtru dílu vyčleněné ze `search_one`, rozhodnutí beze změny)
    # ---------------------------------------------------------------------------- #
    def _tv_filter(  # noqa: C901
        self,
        ws_items: List[dict],
        *,
        label: str,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        ser_title_variants: Sequence[Sequence[str]] = (),
        banned_keys: Sequence[str] = (),
        ep_title_variants: Sequence[Sequence[str]] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] | None = None,
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        probe: bool = True,
        ep_soft: bool = False,
        ban_other_episodes: bool = False,
        scope: bool = False,
    ) -> List["Release"]:
        """ReleaseFilter pro díl seriálu nad syrovými položkami. Rozhodnutí je ČISTĚ po položkách —
        dotaz (`label`) jde jen do logu; proto smí vlna filtrovat sjednocení položek všech dotazů jednou.
        `scope=True` (volá vlna) zapíše `FILTER_SCOPE`, aby řádky FILTER_* nesly označení vlny stejně,
        jako dřív nesly dotaz (formát per-search logu pro replay zůstává)."""
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT
        probe = probe and self._enable_probe
        query = label
        if scope:
            self._log("FILTER_SCOPE", label)

        if not ws_items:
            return []

        fc = tv_filter_context(title_norms, ser_title_variants, ep_title_variants)
        codes = fc.codes
        words = fc.words
        short_only = fc.short_only
        ep_title_variants = fc.ep_title_variants
        ser_variants = fc.ser_variants
        ser_tokens = fc.ser_tokens
        ep_sets = fc.ep_sets
        # Φ-B (E3-F05): doslovný kód s hranicí proti ČÍSLICÍM — bez ní cíl S01E01 („1x01“) chytil „11x01“,
        # „21x01“ (jiný díl u seriálů s ≥ 10 řadami prošel pravidlem A). Hybrid „S08x06“ řeší kanonický regex.
        # Φ-E (audit Fable F1-V1): hranice NESMÍ být proti písmenům — kód slepený s textem („1x01CZ“,
        # „1x01v2“, „Pratele1x01“) je tentýž díl a před Φ-B prošel (pravidlo „nikdy méně streamů“).
        code_re = (re.compile(r"(?<![0-9])(?:%s)(?![0-9])" % "|".join(map(re.escape, codes)), re.I)
                   if codes else None)
        target_canon = fc.target_canon
        generic_ep = fc.generic_ep
        tmdb_title_tokens = fc.tmdb_title_tokens

        # Efektivní banned_keys (bez TMDb title tokenů)
        banned_keys_eff: List[str] = []
        try:
            if banned_keys:
                for k in banned_keys:
                    nk = norm(str(k))
                    if nk and (nk not in tmdb_title_tokens):
                        banned_keys_eff.append(nk)
        except Exception:
            banned_keys_eff = list(banned_keys) if banned_keys else []
        # HΦ-D (2026-07-07, analýza H4): SSOT hygiena u POINTU POUŽITÍ — odstraní
        # jednoslovné bany typu „ii"/„the"/„la"/„of" (řady seriálů / stopwords),
        # co odstřelovaly správné díly (Černé zrcadlo II). Víceslovné sibling
        # fráze (HΦ-B veto) projdou. Pokrývá VŠECHNY zdroje banů (spin_tokens i
        # kolekce) jedním místem; testovatelné replay harnessem.
        banned_keys_eff = list(sanitize_ban_tokens(banned_keys_eff))

        # 1) blacklist regex (cache) -------------------------------------------
        banned_re: re.Pattern | None = None
        if banned_keys_eff and len(banned_keys_eff) > 300:
            # Cache klíč musí odlišit “stejné banned_keys” pro různé seriály (jiné tmdb tokeny ⇒ jiné sanitizace)
            try:
                _ban_ctx = hash(frozenset(tmdb_title_tokens))
            except Exception:
                _ban_ctx = 0
            key = (id(banned_keys), int(_ban_ctx))
            banned_re = self._banned_re_cache.get(key)
            if banned_re is None:
                pat = r"(?<![0-9A-Za-z])(?:%s)(?![0-9A-Za-z])" % "|".join(re.escape(k) for k in banned_keys_eff)
                banned_re = re.compile(pat, re.I)
                self._banned_re_cache[key] = banned_re

        # kontext do logu (informativní)
        try:
            ctx = {
                "query": query,
                "title_norms": list(title_norms),
                "codes": list(codes),
                "ser_tokens": list(ser_tokens),
                "ser_title_variants": [list(v) for v in ser_variants] if ser_variants else [],
                "ep_title_variants": [list(v) for v in ep_title_variants] if ep_title_variants else [],
                "generic_ep": bool(generic_ep),
            }
            self._log("FILTER_CTX", json.dumps(ctx, ensure_ascii=False))
        except Exception:
            pass

        releases: List[Release] = []
        probe_cand: List[Release] = []

        # 3) hlavní filtrace ----------------------------------------------------
        _total_items = len(ws_items)
        for _fi, itm in enumerate(ws_items):
            if progress_cb and _fi % FILTER_PROGRESS_EVERY == 0:
                progress_cb(_fi, _total_items, "filter")
            try:
                rel = ReleaseFilter.enrich(itm)
            except Exception as _itm_exc:
                # Filtr běží JEDNOU nad sjednocením → výjimka jedné položky by shodila celou vlnu
                # (dřív jen jeden dotaz). Položka jde do logu, vlna pokračuje (audit Fable F1-V5).
                self._log("FILTER_REJECT", str(itm.get("ident") or ""), "item_error", str(itm.get("name") or ""),
                          repr(_itm_exc)[:160])
                continue
            if not rel:
                # velikost do detailu: log ji dřív zjišťoval dotazem `file_info` (síť), teď ji nese událost
                self._log("FILTER_REJECT", itm["ident"], "quick", {"size": itm.get("size", 0)}, itm["name"])
                continue

            n = norm(rel.name)
            name_words = set(n.split())

            # NEW 2025-09-10: čísla s/bez počátečních nul ber jako ekvivalent (01 ↔ 1)
            _num_variants = set()
            for _w in list(name_words):
                if _w.isdigit():
                    _s = _w.lstrip("0") or "0"  # "01" -> "1", "00" -> "0"
                    _num_variants.add(_s)
                    # pro jednociferná čísla přidej i variantu s nulou ("1" -> "01")
                    if len(_s) == 1:
                        _num_variants.add(_s.zfill(2))
            name_words |= _num_variants

            # 26.12.2025 – FIX: víceslovné tokeny z _norm() ("11.22.63" → "11 22 63") + „silná“ číselná signatura seriálu
            _n_words = n.split()
            _digits_only = re.sub(r"\D+", "", n)

            def _tok_hit(tok: str) -> bool:
                """
                True, pokud `tok` odpovídá názvu releasu.
                Podporuje i víceslovné tokeny (musí sedět jako sousedící sekvence slov),
                a numerickou pojistku ("11 22 63" může být i jako "112263").
                """
                if not tok:
                    return False

                # 1) jednoslovný token – původní chování
                if tok in name_words:
                    return True

                # 2) víceslovný token – sousedící sekvence slov v normalizovaném `n`
                if " " in tok:
                    tok_norm = re.sub(r"\s{2,}", " ", tok).strip()
                    if not tok_norm:
                        return False
                    tok_parts = tok_norm.split(" ")
                    for i in range(len(_n_words) - len(tok_parts) + 1):
                        if _n_words[i:i + len(tok_parts)] == tok_parts:
                            return True

                    # 3) numerická pojistka: "11 22 63" může být i jako "112263"
                    if tok_parts and all(p.isdigit() for p in tok_parts):
                        compact = "".join(tok_parts)
                        if compact and compact in _digits_only:
                            return True

                return False

            def _is_numeric_signature_token(tok: str) -> bool:
                # „Silný“ číselný token seriálu – povolíme jen >=4 číslice (např. 1899, 112263)
                if not tok:
                    return False
                t = tok.replace(" ", "")
                return t.isdigit() and len(t) >= 4

            # HΦ3 (2026-07-07): has_code kanonicky — literal `code_re` míjel
            # padding varianty (s1e01 vs s01e01). ADITIVNÍ (literal NEBO canon):
            # rozpoznává VÍC kódů jako shodných → jen mění rejecty na accepty
            # (recall zisk), nikdy nový reject. `name_canon` použije i other_code
            # a ep_token_miss níž (jeden výpočet per release).
            name_canon = canon_ep_codes(rel.name)
            has_code_lit = bool(code_re.search(n)) if code_re else False
            has_code_canon = bool(target_canon and (name_canon & target_canon))
            has_code = has_code_lit or has_code_canon
            same_code = has_code if code_re else True

            if ser_variants:
                ser_full = any(all(_tok_hit(w) for w in v) for v in ser_variants)
                ser_part = any(any(_tok_hit(w) for w in v) for v in ser_variants)
            else:
                ser_full = all(_tok_hit(w) for w in ser_tokens) if ser_tokens else False
                ser_part = any(_tok_hit(w) for w in ser_tokens) if ser_tokens else False

            ep_full = any(all(w in name_words for w in v) for v in ep_sets)

            # Pokud máme „silnou“ číselnou signaturu seriálu a ta sedí, bereme to jako dostatečné pro Rule A
            # i když chybí aliasové slovo (typicky: "Dallas 63" vs "11.22.63").
            sig_tokens = [t for t in ser_tokens if _is_numeric_signature_token(t)]
            sig_hit = any(_tok_hit(t) for t in sig_tokens) if sig_tokens else False
            ser_full_for_rule_a = ser_full or sig_hit

            # Rozliš, zda se v názvu chytila jen „generická“ ep-sada
            ep_full_generic = any(
                all(w in name_words for w in v) and all((w in GENERIC_EP or w.isdigit()) for w in v)
                for v in ep_sets
            )
            ep_full_nongeneric = any(
                all(w in name_words for w in v) and not all((w in GENERIC_EP or w.isdigit()) for w in v)
                for v in ep_sets
            )

            # Původní A/B/C – jemně zpřesněné C pro generické „Episode N“
            rule_a = same_code and ser_full_for_rule_a and has_code
            rule_b = same_code and ser_part and ep_full
            rule_c = (same_code and ser_part and ep_full and has_code) if generic_ep else (same_code and ep_full and has_code)

            # 26.12.2025 16:35 CET (Europe/Prague) – Guard:
            # Rule C bez ser_part je rizikové (běžná slova z názvu epizody mohou trefit cizí pořad).
            # Pokud v názvu releasu není žádný token seriálu (ser_part=False), vyžaduj celou epizodní FRÁZI (aspoň 2 slova)
            # jako sousedící sekvenci v normalizovaném názvu.
            if rule_c and (not generic_ep) and (not ser_part) and ep_title_variants:
                _n_pad = f" {n} "
                _phrases = [" ".join(v).strip() for v in ep_title_variants if v]
                _phrases = [p for p in _phrases if " " in p]  # jen víceslovné fráze
                if _phrases and not any(f" {p} " in _n_pad for p in _phrases):
                    rule_c = False

            # 26.12.2025 15:31 CET (Europe/Prague) – SPEC: jednoslovné názvy (jen krátké)
            # U krátkých jednoslovných názvů (typicky kolizní: "You", "Dark", …) zpřísníme Rule A:
            # token musí být na ZAČÁTKU názvu a okamžitě za ním musí následovat kód SxxEyy nebo xxXyy.
            # U delších jednoslovných názvů (např. "Pluribus") tohle zpřísnění nepoužíváme – zbytečně to
            # shazuje správné releasy typu "Pluribus.2025.S01E02...".
            if len(ser_tokens) == 1 and rule_a and len(ser_tokens[0]) <= 5:
                t = ser_tokens[0]
                _ADJ_RE = re.compile(
                    rf"^{re.escape(t)}(?:\W+)?(?:s0?\d{{1,2}}\W*e0?\d{{1,2}}|0?\d{{1,2}}\W*x\W*0?\d{{1,2}})\b",
                    re.I,
                )
                if not _ADJ_RE.search(n):
                    rule_a = False

            # ★ NOVĚ: pokud se chytla jen generická ep-sada (např. „episode 3“),
            #          vyžaduj i ser_part, aby neprocházely cizí seriály.
            if ep_full_generic and not ep_full_nongeneric:
                rule_c = rule_c and ser_part

            allow_hit = rule_a or rule_b or rule_c
            if short_only and codes:
                allow_hit = False

            # HΦ-B (2026-07-07): SIBLING VETO. Spin-off (Suits LA / Kravaťáci LA)
            # sdílí základní titul + kód → projde přes rule_a a obejde fallback
            # ban check. Víceslovné ban fráze (banned_keys s mezerou = celý
            # sibling titul, viz spin_tokens) proto VETUJÍ i rule match: pokud
            # název nese sibling frázi jako sousedící sekvenci, zamítni „spinoff“.
            # Jednoslovné bany zůstávají fallback-only (stopword riziko „la“).
            # Safe-by-construction: víceslovná fráze matchne jen soubor, co ji
            # nese adjacent = přesně spin-off; správný díl základního seriálu
            # tu frázi nemá (Richie 2026-07-07, „Kravaťáci LA“ v Suits).
            if banned_keys_eff:
                # HΦ-D P2-2 (re-audit): veto bere jen VÍCESLOVNÉ fráze se ≥2
                # ABECEDNÍMI tokeny — numerický artefakt (např. „11 22 63" z
                # tečkovaného titulu po norm()) tak NEzíská veto sílu, i kdyby
                # se dostal do banned_keys. Sibling fráze („suits la") projde.
                _veto_ph = next(
                    (k for k in banned_keys_eff
                     if " " in k and _alpha_word_count(k) >= 2
                     and _phrase_contains(n, k)),
                    None,
                )
                if _veto_ph:
                    self._log("FILTER_REJECT", rel.ident, "spinoff",
                              json.dumps({"sibling_phrase": _veto_ph}, ensure_ascii=False),
                              rel.name)
                    continue

            rel.uncertain = bool(codes) and (not allow_hit)

            # ----------------------- Fallback (jen když A/B/C selžou) --------
            if not allow_hit:
                # 0) bez ser_tokens fallback nedává smysl
                if not ser_tokens:
                    self._log(
                        "FILTER_REJECT", rel.ident, "no_ser_tokens",
                        json.dumps({"ser_tokens": [], "name_words": sorted(name_words)}, ensure_ascii=False),
                        rel.name
                    )
                    continue

                # 1) blacklist (SANITIZE: používáme jen banned_keys_eff)
                banned_hit = ((banned_re and banned_re.search(n))
                              or (banned_keys_eff and not banned_re and any(f" {bk} " in f" {n} " for bk in banned_keys_eff)))
                # Φ5B: kód jiného dílu = TENTÝŽ zákaz jako dřívější výčet 20k tokenů (viz `other_episode_code_hit`)
                _oe_hit = (other_episode_code_hit(n, target_canon, tmdb_title_tokens)
                           if (ban_other_episodes and target_canon) else None)
                if banned_hit or _oe_hit:
                    bk = None
                    bk_pos = None
                    if banned_re:
                        m = banned_re.search(n)
                        if m:
                            bk, bk_pos = m.group(0), m.start()
                    elif banned_keys_eff:
                        for k in banned_keys_eff:
                            if f" {k} " in f" {n} ":
                                bk, bk_pos = k, f" {n} ".find(f" {k} ")
                                break
                    # do logu první zásah v textu (jako dřív jeden regex přes všechny tokeny)
                    if _oe_hit and (bk is None or _oe_hit[0] < bk_pos):
                        bk = _oe_hit[1]
                    self._log("FILTER_REJECT", rel.ident, "other_part",
                              json.dumps({"ban_hit": bk}, ensure_ascii=False), rel.name)
                    continue

                # 1a-franchise) HΦ-D: franšízový film v epizodním hledání.
                # coded-search (target_canon) + bez kódu (fallback) + bracketová
                # anotace „[Movie N]"/„(Film N)" na syrovém názvu = TV film, ne
                # díl. Viz Babylon 5 [Movie 5]/[Movie 3] (analýza po hygieně banů).
                _fr_m = _FRANCHISE_FILM_RE.search(rel.name) if (target_canon and not has_code) else None
                if _fr_m:
                    self._log("FILTER_REJECT", rel.ident, "franchise_movie",
                              json.dumps({"marker": _fr_m.group(0)},
                                         ensure_ascii=False), rel.name)
                    continue

                # 1a) 2025-08-19 08:14 CEST – pojistka „jiný díl“ (S01.E01/E## …)
                # HΦ3 (2026-07-07): kanonické porovnání (SSOT) místo string-strip
                # → padding varianta cílového kódu (s1e01) UŽ NENÍ „jiný díl“.
                _E_ONLY_RE = re.compile(r"(?<![a-z0-9])e0?\d{1,2}(?![a-z0-9])", re.I)
                e_only_hits = [m.group(0).lower() for m in _E_ONLY_RE.finditer(n)]
                if name_canon and target_canon and not (name_canon & target_canon):
                    self._log("FILTER_REJECT", rel.ident, "other_code",
                              json.dumps({"found": sorted(map(list, name_canon)),
                                          "target": sorted(map(list, target_canon))}, ensure_ascii=False),
                              rel.name)
                    continue
                if e_only_hits and target_canon and not name_canon:
                    self._log("FILTER_REJECT", rel.ident, "other_code_e_only",
                              json.dumps({"found_e": e_only_hits,
                                          "target": sorted(map(list, target_canon))}, ensure_ascii=False),
                              rel.name)
                    continue

                # 2) *words* bez GENERIC_EP → musí být aspoň 2 čisté tokeny
                clean_tokens = [t for t in words if t not in GENERIC_EP]
                if len(clean_tokens) < 2:
                    self._log("FILTER_REJECT", rel.ident, "few_tokens",
                              json.dumps({"clean_tokens": clean_tokens, "len": len(clean_tokens)}, ensure_ascii=False),
                              rel.name)
                    continue

                # 3) seriálové tokeny — GENERICKÉ epizody → musí padnout VŠECHNY seriálové tokeny
                if generic_ep:
                    ser_needed = len(ser_tokens) if ser_tokens else 1
                else:
                    ser_needed = 1 if has_code or len(ser_tokens) < 2 else 2

                # token může být víceslovný ("11 22 63"), proto testujeme přes _tok_hit()
                hit_ser_tokens = [t for t in ser_tokens if _tok_hit(t)]
                if len(hit_ser_tokens) < ser_needed:
                    self._log(
                        "FILTER_REJECT", rel.ident, f"token_ser_miss_{len(hit_ser_tokens)}/{ser_needed}",
                        json.dumps({
                            "ser_tokens": ser_tokens,
                            "hit_ser_tokens": hit_ser_tokens,
                            "name_words": sorted(name_words),
                            "has_code": bool(has_code)
                        }, ensure_ascii=False),
                        rel.name
                    )
                    continue

                # dlouhé tokeny (≥5) – aspoň jeden musí padnout
                long_tokens = [t for t in ser_tokens if len(t) >= 5]
                if long_tokens and not any(_tok_hit(t) for t in long_tokens):
                    self._log("FILTER_REJECT", rel.ident, "token_ser_long_miss",
                              json.dumps({"long_tokens": long_tokens, "name_words": sorted(name_words)}, ensure_ascii=False),
                              rel.name)
                    continue

                # 4) epizodní tokeny – u ne-generických epizod musí padnout ≥1 shoda
                #    SOFT režim (Vlna X): když ep_soft=True, tuhle podmínku přeskočíme.
                if not ep_soft:
                    if (not generic_ep) and ep_sets:
                        # Φ-B (E3-F06): stopslovo z názvu dílu („the“) NENÍ shoda názvu dílu — jinak prošel
                        # cizí díl „… The Waldo Moment“ při hledání dílu „The National Anthem“
                        hit_ep_tokens = sorted({w for v in ep_sets for w in v
                                                if w in name_words and w not in _TV_STOP})
                        # HΦ4 (2026-07-07, analýza H1 §6.3 + H5): přesný kód cílové
                        # epizody v názvu je SILNĚJŠÍ důkaz než přítomnost TMDb
                        # názvu epizody. Uploadeři TMDb název epizody do jmen
                        # nedávají → „Ano, - S08E01.mkv“ (správný díl) padal, i
                        # když kód s08e01 přesně sedí. Skip ep_token_miss při
                        # kanonické shodě kódu s cílem. (Jiný kód řeší other_code.)
                        _code_matches_target = bool(name_canon and target_canon
                                                    and (name_canon & target_canon))
                        if not hit_ep_tokens and not _code_matches_target:
                            self._log("FILTER_REJECT", rel.ident, "ep_token_miss",
                                      json.dumps({
                                          "ep_sets": [sorted(list(v)) for v in ep_sets],
                                          "found": hit_ep_tokens,
                                          "name_words": sorted(name_words)
                                      }, ensure_ascii=False),
                                      rel.name)
                            continue

                # 5) globální limit shod — (s kódem stačí 1 „clean“ token)
                min_needed = 1 if has_code else (3 if generic_ep else 2)
                min_needed = min(min_needed, len(clean_tokens))
                hit_tokens = [t for t in clean_tokens if _tok_hit(t)]
                if len(hit_tokens) < min_needed:
                    self._log(
                        "FILTER_REJECT", rel.ident, f"token_miss_{len(hit_tokens)}/{min_needed}",
                        json.dumps({
                            "clean_tokens": clean_tokens,
                            "hit_tokens": hit_tokens,
                            "name_words": sorted(name_words),
                            "generic_ep": bool(generic_ep),
                            "has_code": bool(has_code)
                        }, ensure_ascii=False),
                        rel.name
                    )
                    continue

                # 6) uncertain → min velikost + přípona videa  (OPRAVENO 2025-08-19)
                if rel.uncertain:
                    video_ext_ok = bool(video_ext_of(rel.name))
                    if (rel.size_mb is not None and rel.size_mb < 200) or (not video_ext_ok):
                        self._log("FILTER_REJECT", rel.ident, "uncertain_small_or_ext",
                                  json.dumps({"size_mb": rel.size_mb, "video_ext_ok": video_ext_ok}, ensure_ascii=False),
                                  rel.name)
                        continue

            # regex / rok / další rychlé filtry (beze změny)
            if bad_regex.search(rel.name):
                try:
                    self._log("FILTER_REJECT", rel.ident, "bad_regex",
                              json.dumps({"pattern": bad_regex.pattern}, ensure_ascii=False), rel.name)
                except Exception:
                    self._log("FILTER_REJECT", rel.ident, "bad_regex", rel.name)
                continue

            # Větev `bad_ep` (kód epizody u filmu) tu byla mrtvá — filtr dílu se s `movie_year` nevolá;
            # filmy ji mají ve `_movie_filter`. Odstraněno ve Φ-C (E3, pravidlo T17).

            # 2025-08-19 10:39 CEST (Europe/Prague) – Kontrola roku (set povolených let)
            years_allowed = set(allowed_years or ([] if movie_year is None else [movie_year]))
            if years_allowed:
                yrs = {int(y) for y in YEAR_RE.findall(rel.name)}
                # HΦ3 (2026-07-07, analýza H3): „extra-year kill“ fix — dřív
                # `len(yrs) > 1` zabíjel správný soubor, který kromě cílového roku
                # nesl i rok dabingu/remasteru (Conan 1982 + 1994 + 2000). Nově:
                # reject JEN když ŽÁDNÝ rok v názvu není povolený (disjoint).
                # Soubor s aspoň jedním povoleným rokem projde (cizí roky ignorace).
                if yrs and yrs.isdisjoint(years_allowed):
                    payload = {
                        "allowed_years": sorted(years_allowed),
                        "yrs_in_name": sorted(yrs),
                    }
                    # pro zpětnou kompatibilitu přidáme i movie_year, je-li použit
                    if movie_year is not None:
                        payload["movie_year"] = movie_year
                    self._log("FILTER_REJECT", rel.ident, "year_miss",
                              json.dumps(payload, ensure_ascii=False), rel.name)
                    continue

            # kandidáti na MediaInfo probe (22.01.2026 – nyní podporuje i Fastshare)
            if probe and rel.est_min is None and len(probe_cand) < PROBE_MAX_RESULTS:
                probe_cand.append(rel)

            releases.append(rel)
            self._log(
                "FILTER_ACCEPT", rel.ident,
                f"a={int(rule_a)} b={int(rule_b)} c={int(rule_c)} u={int(rel.uncertain)}",
                rel.quality, rel.size_mb, rel.name
            )

        # 4) MediaInfo probe (paralelně) ---------------------------------------
        if probe and probe_cand:
            total = len(probe_cand)

            def _wrap(r: "Release", idx: int) -> None:
                self._probe(r)
                if progress_cb:
                    progress_cb(idx, total, "probe")

            with _f.ThreadPoolExecutor(max_workers=_pool_size(5)) as pool:
                for f in (pool.submit(_wrap, r, i) for i, r in enumerate(probe_cand, 1)):
                    try:
                        f.result()
                    except Exception as _pf_e:
                        # Dřív tiché: pád probe workeru (MI hint chybí).
                        _diag_log(f"probe future fail: {_pf_e}", 0)

        # 5) seřazení -----------------------------------------------------------
        self._log("WS_RESULTS", query, len(releases))

        # 5a) SPEC: jednoslovné seriály (Lost, You, Dark…) – penalizace "balastu" v title-bloku
        #     Cíl: už před MI2 poslat releasy typu "Dan Browns The Lost Symbol S01E01" níž,
        #          ale NIC nevyhazovat (jen řazení). SSOT = `tv_title_penalty` (i pro CACHE_HIT).
        for r in releases:
            base_score = ReleaseFilter.compute_score(r)
            penalty = 0
            try:
                penalty, _pen_events = tv_title_penalty(r.name, fc)
                for _ev, _payload in _pen_events:
                    self._log(_ev, r.ident, _payload, r.name)
            except Exception as _e:
                try:
                    self._log("TITLE_PENALTY_ERR", getattr(r, "ident", "?"), str(_e), getattr(r, "name", "?"))
                except Exception:
                    pass
                penalty = 0

            try:
                r.title_penalty = int(penalty)
            except Exception:
                pass

            r.score = tuple(base_score) + (int(penalty),)

        releases.sort(key=lambda x: x.score)
        return releases






    def search_movie_one(  # 2025-09-27 12:03 CEST (Europe/Prague)               # noqa: C901


        self,
        query: str,
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] = (),
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        cancel_check: Optional[Callable[[], bool]] = None,
        probe: bool = True,
    ) -> List["Release"]:
        """
        FILMOVÁ varianta search_one() – logiku zachovává, ALE:
        • `banned_keys` už se běžně používá (předává plugin)
        • NOVĚ: `FILTER_ACCEPT` loguje **důvod průchodu** (JSON),
            abychom v ladicím logu přesně viděli, co rozhodlo.

        Sprint 2026-05-02 (P0) — Gate /v1/search PATH DROPPED:
          Phase 3c experiment (2026-04-19 → 2026-04-30) byla odstraněna.
          Důvod: Gate-side ranking/filter nedosahoval parity s addon-side
          ReleaseFilter (banned_keys z TMDb collection_parts, year_whitelist
          z release_dates per country, title_penalty token-aware match,
          runtime_sanity ±10%) — half-year-tuned heuristics. Aktivace Gate
          path (test 2026-04-30 14:42, Metráček 1972) vrátila 71 releases
          zaplavených 1972-junk filmy s actual Metráček.avi na pozici #47.
          Filter parity port (option B, ~3 dny) nedával ROI smysl pro hobby
          projekt — option A (drop) gives clean SSOT (single ReleaseFilter
          implementation in addon). Plan: Handoff/session_2026-05-02_drop_
          gate_search_settings_ssot.md.
        """
        items = self._movie_fetch(query, cancel_check=cancel_check)
        return self._movie_filter(
            items, label=query, runtimes=runtimes, title_norms=title_norms, banned_keys=banned_keys,
            movie_year=movie_year, allowed_years=allowed_years, bad_regex=bad_regex,
            progress_cb=progress_cb, probe=probe,
        )

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # _movie_fetch / _movie_filter  (Φ5B, 29.09.2026 — rozděleno ze search_movie_one, audit A06 R05)
    # ---------------------------------------------------------------------------- #
    def _movie_fetch(self, query: str, *, cancel_check: Optional[Callable[[], bool]] = None) -> List[dict]:
        """Syrové položky jednoho dotazu: stránky Webshare + Fastshare, sloučené (`_dedupe_multi_source`).
        Jen síť a logy dotazu — žádné rozhodování filtru."""
        return self._fetch_query(query, raw_event="RAW_MOVIE_SEARCH", cancel_check=cancel_check).items

    def _movie_filter(
        self,
        ws_items: List[dict],
        *,
        label: str,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] = (),
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        probe: bool = True,
    ) -> List["Release"]:
        """ReleaseFilter pro film nad syrovými položkami. Rozhodnutí je ČISTĚ po položkách — dotaz (`label`)
        jde jen do logu; proto smí vlna filtrovat sjednocení položek všech dotazů jednou (Φ5B)."""
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT
        probe = probe and self._enable_probe

        if not ws_items:
            return []

        # ❷ roky z titulových tokenů (např. film „2012“ apod.)
        title_year_tokens: set[int] = {
            int(tok) for tok in title_norms if tok.isdigit() and len(tok) == 4
        }
        extra_years = {int(y) for y in allowed_years if isinstance(y, int)}

        # ❸ filtry + enrich
        releases: list[Release] = []
        probe_cand: list[Release] = []

        _total_items = len(ws_items)
        for _fi, itm in enumerate(ws_items):
            if progress_cb and _fi % FILTER_PROGRESS_EVERY == 0:
                progress_cb(_fi, _total_items, "filter")
            try:
                rel = ReleaseFilter.enrich(itm)
            except Exception as _itm_exc:
                # Filtr běží JEDNOU nad sjednocením → výjimka jedné položky by shodila celou vlnu
                # (dřív jen jeden dotaz). Položka jde do logu, vlna pokračuje (audit Fable F1-V5).
                self._log("FILTER_REJECT", str(itm.get("ident") or ""), "item_error", str(itm.get("name") or ""),
                          repr(_itm_exc)[:160])
                continue
            if not rel:
                # velikost do detailu: log ji dřív zjišťoval dotazem `file_info` (síť), teď ji nese událost
                self._log("FILTER_REJECT", itm["ident"], "quick", {"size": itm.get("size", 0)}, itm["name"])
                continue

            n = norm(rel.name)

            # — BAN klíče (ostatní díly série apod.) —
            # 2025-09-27 12:03 CEST (Europe/Prague) – fix falešných zásahů:
            # Dříve: prostý substring `bk in n` → např. "equalizer 2" ⊂ "equalizer 2014".
            # Nyní: „mezerovaný“ substring (simulace word‑boundaries), jako v jiné větvi enginu.
            # Φ-B (30.09.2026, E3-F01): SSOT `movie_ban_hit` — zákaz s pojistkami (obecné slovo pokračování,
            # jednoznačný cílový titul). Do logu jde, KTERÝ token zakázal, a když pojistka zákaz odvrátila.
            if banned_keys:
                _yrs_b = {int(y) for y in YEAR_RE.findall(rel.name)}
                _allowed_b = ({movie_year} | title_year_tokens | extra_years) if movie_year else set()
                _ban, _ban_why = movie_ban_hit(n, banned_keys, title_norms,
                                               has_allowed_year=bool(_yrs_b & _allowed_b))
                if _ban is not None:
                    self._log("FILTER_REJECT", rel.ident, "other_part",
                              json.dumps({"ban_hit": _ban}, ensure_ascii=False), rel.name)
                    continue
                if _ban_why:
                    self._log("MOVIE_BAN_WAIVED", rel.ident, _ban_why, rel.name)


            # — Titulní shoda (per-title; 2026-03-01) —
            # Vyhodnocuj shodu pro KAŽDÝ title_norm zvlášť.
            # Pokud soubor matchne dostatečně tokeny jakéhokoliv jednoho názvu
            # (CZ nebo EN), projde.  Řeší případ jednoslovného CZ názvu
            # s víceslovným EN názvem (např. "Zálesák" vs "Forest Warrior").
            _STOP = {
                # CZ
                "v", "ve", "s", "z", "na", "do", "u", "o", "a", "i", "se",
                # EN (základ)
                "the", "of", "in", "on", "and", "to", "for", "at", "by",
                # FR/ES drobky
                "de", "le", "la", "du",
            }
            name_words = {w for w in n.split() if w}  # n = norm(rel.name)

            any_title_ok = False
            all_query_tokens = set()   # pro log
            best_hits = set()          # pro log
            for t in (title_norms or ()):
                t_tokens = set()
                for w in (t or "").split():
                    if w and len(w) >= 3 and not w.isdigit() and w not in _STOP:
                        t_tokens.add(w)
                # Σ-audit Φ3.15: krátké (≤2 znaky) nebo čistě číselné názvy
                # ("IT", "Up", "1984", "9", "Vši") by jinak měly t_tokens prázdné
                # (striktní len>=3 + not-digit filtr je všechny zahodí) → 0
                # výsledků (recall bug). Lenient fallback: když striktní filtr nic
                # nenechal, ponech i krátké/číselné tokeny (jen stopwords pryč),
                # ať se takový název dá vůbec matchnout proti name_words.
                if not t_tokens:
                    t_tokens = {w for w in (t or "").split() if w and w not in _STOP}
                all_query_tokens |= t_tokens
                if not t_tokens:
                    continue
                t_min = 2 if len(t_tokens) >= 2 else 1
                t_hits = {w for w in t_tokens if w in name_words}
                best_hits |= t_hits
                if len(t_hits) >= t_min:
                    any_title_ok = True
                    break

            if not any_title_ok:
                try:
                    self._log(
                        "FILTER_REJECT", rel.ident, "token_miss",
                        json.dumps(
                            {
                                "per_title": True,
                                "hits": sorted(list(best_hits)),
                                "query_tokens": sorted(list(all_query_tokens)),
                                "name_words": sorted(list(name_words))[:24],
                            },
                            ensure_ascii=False,
                        ),
                        rel.name,
                    )
                except Exception:
                    self._log("FILTER_REJECT", rel.ident, "token_miss", rel.name)
                continue


            # — Nežádoucí regexy —
            if _BAD_REGEX_MOVIE.search(rel.name) or bad_regex.search(rel.name):
                self._log("FILTER_REJECT", rel.ident, "bad_regex", rel.name)
                continue

            # — Whitelist ROKŮ (aplikuje se jen, když je rok v názvu) —
            yrs_in_name = {int(y) for y in YEAR_RE.findall(rel.name)}
            if movie_year and yrs_in_name:
                allowed = ({movie_year} | title_year_tokens | extra_years)
                # HΦ3 (2026-07-07, analýza H3): „extra-year kill“ fix — dřív
                # `yrs_in_name - allowed` zabil soubor s cílovým rokem, který
                # nesl i cizí rok (dabing/remaster/group tag „EDGE2020“, DVD/VHS
                # rok). Nově: reject JEN když disjoint (žádný rok nesedí).
                if yrs_in_name.isdisjoint(allowed):
                    self._log(
                        "FILTER_REJECT",
                        rel.ident,
                        "year_miss",
                        json.dumps(
                            {
                                "movie_year": movie_year,
                                "tmdb_allowed": sorted(extra_years),
                                "yrs_in_name": sorted(yrs_in_name),
                            },
                            ensure_ascii=False,
                        ),
                        rel.name,
                    )
                    continue

            # — MediaInfo fronta (22.01.2026 – nyní podporuje i Fastshare) —
            if probe and rel.est_min is None and len(probe_cand) < PROBE_MAX_RESULTS:
                probe_cand.append(rel)

            # — Prošlo: přidej a zaloguj DŮVOD PRŮCHODU —
            #
            # 3.4.7 (2026-05-17, audit Π5): odstraněny `token_min` / `token_hits` /
            # `hit_tokens` z movie path. Tyto proměnné existují jen v TV branch
            # (`search_one`, řádky ~1585-1587 této metody), v `search_movie_one`
            # nikdy nebyly definovány → každý přijatý movie release vyvolal NameError,
            # zachycený `except Exception` níže → tichá ztráta diagnostiky.
            # Movie path nemá token-min/token-hit semantiku (heuristic je založena
            # na year+title penalty, ne token bucket), takže drop je správný.
            releases.append(rel)
            try:
                accept_ctx = {
                    "yrs_in_name": sorted(yrs_in_name) if yrs_in_name else [],
                    "years_allowed": (
                        sorted({movie_year} | title_year_tokens | extra_years)
                        if movie_year else []
                    ),
                    "banned_hit": False,
                    "bad_regex": False,
                }
                self._log(
                    "FILTER_ACCEPT",
                    rel.ident,
                    json.dumps(accept_ctx, ensure_ascii=False),
                    rel.quality,
                    rel.size_mb,
                    rel.name,
                )

            except Exception:
                self._log("FILTER_ACCEPT", rel.ident, rel.quality, rel.size_mb, rel.name)

        # ❹ MediaInfo probe (paralelně)
        if probe and probe_cand:
            total = len(probe_cand)

            def _wrap(r: "Release", idx: int) -> None:
                self._probe(r)
                if progress_cb:
                    progress_cb(idx, total, "probe")

            with _f.ThreadPoolExecutor(max_workers=_pool_size(5)) as pool:
                for f in (pool.submit(_wrap, r, i) for i, r in enumerate(probe_cand, 1)):
                    try:
                        f.result()
                    except Exception as _pf_e:
                        # Dřív tiché: pád probe workeru (MI hint chybí).
                        _diag_log(f"probe future fail: {_pf_e}", 0)

        self._log("WS_RESULTS", label, len(releases))

        # ❺ Délkový filtr + ★ MATCH
        # HΦ-C (2026-07-07, analýza H1 §6.1 — NEJHORŠÍ nález, 98 % zabití len_out
        # vypadalo jako správný film): dřív TVRDÝ DROP při jakémkoli nesouladu
        # měřené délky. Problém: FS/API metadata bývají chybná (Mission Impossible
        # 1996 zabit špatnou délkou), a cut/PAL verze legitimně kratší. Nově
        # DROPuje jen HRUBÝ nesoulad (< 0,5× délky = useknutý/rozbitý soubor);
        # MÍRNÝ nesoulad (mimo ±tol, ale ≥ půlka) = PENALTA řazení, ne drop
        # (filozofie „penalizovat > vyhazovat"). Monotónně bezpečné: striktně
        # MÉNĚ dropů než dřív → recall může jen růst.
        if runtimes:
            lo_rt, hi_rt = min(runtimes), max(runtimes)
            keep: list[Release] = []
            for r in releases:
                est = r.est_min or 0
                if est:
                    out_of_band = est < lo_rt - LEN_TOL_SHORT or est > hi_rt + LEN_TOL_LONG
                    gross = est < 0.5 * lo_rt   # < půlka nejkratší verze = vadný
                    if gross:
                        self._log("FILTER_REJECT", r.ident, "len_out",
                                  json.dumps({"est": est, "lo": lo_rt, "hi": hi_rt,
                                              "band": "gross_short"}, ensure_ascii=False),
                                  r.name)
                        continue
                    if out_of_band:
                        r.len_penalty = 1
                        self._log("LEN_SOFT_PENALTY", r.ident,
                                  json.dumps({"est": est, "lo": lo_rt, "hi": hi_rt},
                                             ensure_ascii=False), r.name)
                if any(abs(est - rt) <= MATCH_TOL for rt in runtimes):
                    r.match = True
                keep.append(r)
            releases = keep

        # ❻ Scoring + řazení
        # 2025-08-23 09:10 CEST – Jednoslovné názvy bez roku: jemná penalizace pořadí (žádný ban).
        # Pravidla platí pouze, pokud:
        #   • title_norms obsahuje aspoň jeden jednoslovný titulek (např. "alien", "vetrelec"),
        #   • v názvu release NENÍ uveden rok (jinak se spoléháme na stávající whitelist roků).
        # Penalizace je malá a pouze mění pořadí kandidátů na shodné bázi; nikdy nic nevyhazuje.
        SAFE_SUFFIX = {
            # rozlišení a edice
            "2160p", "1080p", "720p", "480p", "4k", "uhd", "remastered", "extended", "directors", "cut",
            # zdroje / ripy
            "web", "webrip", "webdl", "bluray", "bdrip", "brrip", "hdrip", "dvdrip", "hdtv",
            # kodeky / profily
            "x264", "x265", "h264", "h265", "hevc", "av1", "10bit", "8bit",
            # audio
            "aac", "ac3", "eac3", "dts", "truehd", "atmos",
            # hdr/dolby vision
            "hdr", "sdr", "dv", "dolby", "vision",
            # jazyk / titulky
            "cz", "sk", "en", "eng", "pl", "czdub", "czdab", "dabing", "titulky", "subs", "sub"
        }
        for r in releases:
            base_score = ReleaseFilter.compute_score(r)
            penalty = 0
            try:
                # HΦ5 (2026-07-07, analýza H4 §5.4): odseknout příponu kontejneru
                # PŘED tokenizací — jinak `norm("Matrix.avi")` → „matrix avi" a
                # přípona „avi" (∉ SAFE_SUFFIX) penalizovala PŘESNÝ název filmu
                # (Matrix.avi, Pinocchio.avi, The Matrix.mkv). avi/mkv/mp4 nejsou
                # obsah, ale kontejner.
                _stem = os.path.splitext(r.name)[0]
                n = norm(_stem)
                has_year = bool(YEAR_RE.search(r.name))
                # uvažujeme jen jednoslovné varianty cílového titulu
                single_targets = [t for t in title_norms if " " not in t]
                if single_targets and not has_year:
                    tokens = n.split()
                    hit_ix = None
                    hit_token = None
                    # najdi nejčasnější výskyt jakéhokoli jednoslovného titulku
                    for idx, tok in enumerate(tokens):
                        for t in single_targets:
                            if tok == t:
                                if hit_ix is None or idx < hit_ix:
                                    hit_ix = idx
                                    hit_token = t
                                break
                        if hit_ix == idx:
                            break

                    if hit_ix is not None:
                        # 1) pozice shody: chceme ji v prvních ~3 tokenech
                        if hit_ix >= 3:
                            penalty += 1
                        # 2) "suffix" za shodou – následující token by měl být bezpečný (nebo rok)
                        next_tok = tokens[hit_ix + 1] if (hit_ix + 1) < len(tokens) else ""
                        is_year_tok = next_tok.isdigit() and len(next_tok) == 4
                        if next_tok and (next_tok not in SAFE_SUFFIX) and not is_year_tok:
                            penalty += 1

                        if penalty:
                            try:
                                ctx = {
                                    "penalty": penalty,
                                    "reason": [
                                        "pos>=3" if hit_ix >= 3 else None,
                                        "bad_suffix" if (next_tok and (next_tok not in SAFE_SUFFIX) and not is_year_tok) else None,
                                    ],
                                    "hit_token": hit_token,
                                    "hit_index": hit_ix,
                                    "next_token": next_tok or "",
                                    "has_year_in_name": has_year,
                                    "title_norms": list(single_targets),
                                }
                                # odfiltruj None z reason
                                ctx["reason"] = [x for x in ctx["reason"] if x]
                                self._log("SCORE_PENALTY", r.ident, json.dumps(ctx, ensure_ascii=False), r.name)
                            except Exception:
                                self._log("SCORE_PENALTY", r.ident, penalty, r.name)
            except Exception as e:
                # nechceme spadnout na výjimce – penalizace je "best effort"
                self._log("SCORE_PENALTY_ERR", getattr(r, "ident", "?"), str(e), getattr(r, "name", "?"))

            # rozšíříme lexikografické skóre o 4. složku (=penalizace); 0 znamená "bez penalizace"
            # HΦ-C: + délková soft-penalta (mírný nesoulad délky řadí níž, nedropuje)
            r.score = tuple(base_score) + (penalty + int(getattr(r, "len_penalty", 0)),)

        releases.sort(key=lambda x: x.score)
        return releases








    def search_movie_wave(  # 14.12.2025 20:36 CET (Europe/Prague)               # noqa: C901
        self,
        queries: Sequence[str],
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        banned_keys: Sequence[str] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] = (),      # ← NOVĚ: posíláme z pluginu
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        max_quick_probe: int = 0,
        top_full_probe: int = 15,
        stats: Optional[dict] = None,          # Φ-A: výstup pro volajícího (errors, cancelled, cache_hit)
        fetch_memo: Optional[dict] = None,     # Φ-C: paměť stažených dotazů TOHOTO hledání (viz `_fetch_wave`)
    ) -> List["Release"]:
        """
        14.12.2025 20:36 CET (Europe/Prague)

        Filmová vlna s 30denní cache. Cache-klíč nově zahrnuje i whitelist roků,
        aby se nepletly výsledky mezi různými pravidly povolených roků.
        """
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT

        # 1) CACHE – klíč = dotazy + (rok) + (seznam povolených roků)
        extra = f":{movie_year}" if movie_year else ""
        years_tag = f":{','.join(str(y) for y in sorted(set(allowed_years)))}" if allowed_years else ""
        cache_key = SEARCH_CACHE.build_key("movie", *sorted(queries)) + extra + years_tag
        cached = SEARCH_CACHE.get(cache_key)
        _from_cache = releases_from_records(cached, self._log) if cached else None
        if _from_cache is not None:
            self._log("CACHE_HIT", cache_key, len(_from_cache))
            if stats is not None:
                stats["cache_hit"] = True
            self._note_partial_hit(cache_key, stats)
            return _from_cache

        # 2) Paralelní hledání
        # Φ5B (29.09.2026, audit A06 R05): dotazy se STÁHNOU souběžně (jen síť), syrové položky se sjednotí
        # podle identu a filtr proběhne JEDNOU. Dřív každý dotaz filtroval sám → tytéž soubory ~3,3× a na
        # Androidu (2 vlákna) filtr blokoval síť dalších dotazů (4 dotazy: 12,3 s oproti 0,6 s na desktopu).
        # Φ-A (30.09.2026): stahování i sjednocení = SSOT společné se seriálem; sjednocení drží PŮVOD identu.
        _t_fetch = time.monotonic()
        _wstats = stats if stats is not None else {}
        _err0 = int(_wstats.get("errors", 0) or 0)
        fetched = self._fetch_wave(queries, raw_event="RAW_MOVIE_SEARCH", progress_cb=progress_cb, stats=_wstats,
                                   memo=fetch_memo)
        if fetched is None:
            return []
        _t_filter = time.monotonic()
        union, origin = self._union_fetched(fetched)
        all_items: List[Release] = self._movie_filter(
            union, label=" | ".join(queries), runtimes=runtimes, title_norms=title_norms,
            banned_keys=banned_keys, movie_year=movie_year, allowed_years=allowed_years,
            bad_regex=bad_regex, progress_cb=progress_cb, probe=False,
        )
        self._apply_origin(all_items, origin)
        self._log_wave_yield(fetched, origin, all_items)
        self._log_wave_timing(_t_fetch, _t_filter)

        # 3) Deduplikace ID → (size, ext)
        #    Řazení: WS má přednost před FS (při shodném score WS vyhraje dedupe)
        seen_ids: set[str] = set()
        uniq_id: List[Release] = []
        for r in sorted(all_items, key=lambda x: (x.score, 0 if x.source == "webshare" else 1)):
            if r.ident not in seen_ids:
                uniq_id.append(r)
                seen_ids.add(r.ident)

        seen_sig: dict[tuple[int, str], int] = {}   # sig → index v uniq_final
        uniq_final: List[Release] = []
        for r in uniq_id:
            ext = os.path.splitext(r.name)[1].lower()
            sig = (r.size, ext)
            if sig in seen_sig:
                # Duplicita: WS nahradí FS pokud stávající je FS a nový je WS
                idx = seen_sig[sig]
                _kept, _gone = uniq_final[idx], r
                if uniq_final[idx].source != "webshare" and r.source == "webshare":
                    uniq_final[idx] = r
                    _kept, _gone = r, _kept
                self._log("DEDUP_DROP", _gone.ident, "size_ext", _kept.ident, _gone.name)
                continue
            seen_sig[sig] = len(uniq_final)
            uniq_final.append(r)

        result = uniq_final

        # 4) Uložit do cache
        self._cache_wave_result(cache_key, result, int(_wstats.get("errors", 0) or 0) - _err0)

        # 5) MI2 lazy-enrichment: rozjeď krokové zjišťování MediaInfo (FILMY parity se SERIÁLY)
        #    Pozn.: richmovie_mi2 importuje richmovie_engine → proto lazy import až tady, aby nevznikl circular import.
        try:
            from richmovie_mi2 import MediaInfoSecondEdition as _MI2
            _MI2.start(
                releases=result[:32],        # skenuj jen rozumný „viditelný” výřez
                client_factory=self._get_client,
                fs_client_factory=self._get_fs_client,  # 21.02.2026 – Fastshare MI2 podpora
                first_batch=8,               # první refresh po ~8 položkách
                max_items=32,
                refresh=True,
                key=_listing_key(),
            )
            # Log pro rychlou diagnostiku – uvidíš v kodi.log
            self._log(
                "MI2_START",
                f"count={min(len(result), 32)} first_batch=8 refresh=True",
            )
        except Exception as _mi2_err:
            self._log("MI2_KICK_FAIL", str(_mi2_err))

        return result








    # `_quick_duration` (HTTP HEAD pro odhad stopáže) ODSTRANĚNA ve Φ4 (29.09.2026): nikdo ji nevolal
    # a kvůli ní se při každém kliku importoval `requests` (audit A08 F2).

    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class SearchEngine
    # search_wave (upraveno: 27.12.2025 19:52 CET (Europe/Prague) – SANITIZE: CACHE_HIT title_penalty:
    #   (1) title_penalty se dopočítá jen pro skutečně “one-word” seriály (primary TMDb varianta po STOP/epi filtraci),
    #   (2) tokeny z TMDb variant názvu seriálu nikdy nesmí být penalizovány jako “bad”,
    #   (3) zachováno: title_penalty i na CACHE_HIT + MI2 kick i na CACHE_HIT + ser_title_variants (OR přes varianty názvu))
    # ---------------------------------------------------------------------------- #
    def search_wave(  # noqa: C901
        self,
        queries: Sequence[str],
        *,
        runtimes: Sequence[int] = (),
        title_norms: Sequence[str] = (),
        ser_title_variants: Sequence[Sequence[str]] = (),  # 26.12.2025 – OR přes varianty názvu seriálu
        banned_keys: Sequence[str] = (),
        ep_title_variants: Sequence[Sequence[str]] = (),
        movie_year: int | None = None,
        allowed_years: Sequence[int] | None = None,   # 2025-08-19 10:39 CEST (Europe/Prague)
        bad_regex: re.Pattern | None = None,
        progress_cb: Optional[Callable[[int, int, str], None]] = None,
        max_quick_probe: int = 0,
        top_full_probe: int = 15,
        ep_soft: bool = False,  # 2025-11-15 19:16 CET (Europe/Prague) – SOFT režim pro Vlnu X
        ban_other_episodes: bool = False,   # Φ5B: zákaz jiného dílu kódem
        stats: Optional[dict] = None,       # Φ-A: výstup pro volajícího (errors, cancelled, cache_hit)
        fetch_memo: Optional[dict] = None,  # Φ-C: paměť stažených dotazů TOHOTO hledání (viz `_fetch_wave`)
    ) -> List["Release"]:
        """
        Paralelní vlna vyhledávání + dvojí deduplikace **S PODPOROU CACHE**.

        Nově (07/2025)
        ---------------
        • Před samotným hledáním zkusí načíst výsledek z `SEARCH_CACHE`
          (TTL 30 dní).
        • Po úspěšném hledání uloží seřazený list do cache.

        Úprava (2025-09-07)
        -------------------
        • Po sestavení výsledků se **asynchronně** startne MI2 (MediaInfo
          „second edition“) pro **lazy** doplnění „CZ dabing / CZ titulky“,
          a zapíše se log `MI2_START …`. GUI refresh zajišťuje MI2 modul.

        Úprava (2025-11-15 20:52 CET)
        ------------------------------
        • Cache klíč pro TV hledání rozšířen o příznak režimu `:strict`/`:soft`,
          aby se nepletly výsledky přísných a tolerantních vln (důležité pro
          kombinaci „TV dotaz“ + následná Vlna X s `ep_soft=True`).

        Úprava (26.12.2025)
        -------------------
        • Při `CACHE_HIT` se nově **také** provede MI2 kick, jinak u seriálů po
          cache-hitu často nevzniknou toasty + finální refresh.
        • Forwardujeme `ser_title_variants` až do `search_one` (OR přes varianty názvu).

        Úprava (27.12.2025)
        -------------------
        • SANITIZE (CACHE_HIT title_penalty):
          - title_penalty se dopočítá jen pro skutečně “one-word” seriály (primary TMDb varianta),
          - tokeny z TMDb variant názvu seriálu se nikdy nesmí penalizovat jako “bad”.
        """
        bad_regex = bad_regex or _BAD_REGEX_DEFAULT

        # 🔸 1) CACHE – zkusíme nejprve rychle vrátit uložené výsledky
        years_tag = (
            f":{','.join(str(y) for y in sorted(set(allowed_years or ())))}"
            if allowed_years else ""
        )
        soft_tag = ":soft" if ep_soft else ":strict"
        cache_key = (
            SEARCH_CACHE.build_key("tv", *sorted(queries))
            + years_tag
            + soft_tag   # 2025-11-15 20:52 CET (Europe/Prague) – rozlišení strict/soft režimu
        )
        cached = SEARCH_CACHE.get(cache_key)
        result = releases_from_records(cached, self._log) if cached else None
        if result is not None:
            self._log("CACHE_HIT", cache_key, len(result))

            if stats is not None:
                stats["cache_hit"] = True
            self._note_partial_hit(cache_key, stats)

            # 🔸 1b) SPEC: jednoslovné seriály – title_penalty i na CACHE_HIT
            # Stará cache (bez title_penalty) se dopočítá i tady — STEJNOU funkcí jako hlavní cesta
            # (`tv_title_penalty`, včetně výjimky HΦ5; dřív druhá kopie výpočtu bez ní — E3-F04).
            try:
                fc = tv_filter_context(title_norms, ser_title_variants, ep_title_variants)
                if fc.one_word_set and fc.codes:
                    for r in result:
                        try:
                            penalty, _pen_events = tv_title_penalty(getattr(r, "name", "") or "", fc)
                        except Exception as _pen_exc:
                            penalty = 0
                            self._log("TITLE_PENALTY_ERR", getattr(r, "ident", ""), repr(_pen_exc)[:200])
                        try:
                            setattr(r, "title_penalty", int(penalty))
                        except Exception:
                            pass
                        try:
                            base_score = ReleaseFilter.compute_score(r)
                            setattr(r, "score", tuple(base_score) + (int(penalty),))
                        except Exception:
                            pass
                    try:
                        result.sort(key=lambda x: score_sort_key(getattr(x, "score", None)))
                    except Exception:
                        pass
            except Exception:
                pass

            # ✅ MI2 kick i na CACHE_HIT (jinak u seriálů po cache-hitu často chybí toasty + finální refresh)
            try:
                from richmovie_mi2 import MediaInfoSecondEdition as _MI2
                _MI2.start(
                    releases=result[:32],
                    client_factory=self._get_client,
                    fs_client_factory=self._get_fs_client,  # 21.02.2026 – Fastshare MI2 podpora
                    first_batch=8,
                    max_items=32,
                    refresh=True,
                    key=_listing_key(),
                )
                self._log("MI2_START", "ctx=search_wave_cache", f"count={min(len(result), 32)}")
            except Exception as _mi2_err:
                self._log("MI2_KICK_FAIL", str(_mi2_err))

            return result

        # 🔸 2) Stažení dotazů vlny souběžně → sjednocení podle identu → filtr JEDNOU -------------
        # Φ-A (30.09.2026, E4-F02): dřív každý dotaz filtroval sám (`search_one` ve vlákně) → tentýž soubor
        # se posuzoval až 6× (82 % posouzení opakovaných). Rozhodnutí na dotazu nezávisí, výsledek je shodný
        # (brána `full_replay diff`); který dotaz soubor našel, drží `WAVE_ORIGIN` a `Release.origin`.
        _t_fetch = time.monotonic()
        _wstats = stats if stats is not None else {}
        _err0 = int(_wstats.get("errors", 0) or 0)
        fetched = self._fetch_wave(queries, raw_event="RAW_SEARCH", progress_cb=progress_cb, stats=_wstats,
                                   memo=fetch_memo)
        if fetched is None:
            return []
        _t_filter = time.monotonic()
        union, origin = self._union_fetched(fetched)
        all_items: List[Release] = self._tv_filter(
            union, label=" | ".join(queries), scope=True, runtimes=runtimes, title_norms=title_norms,
            ser_title_variants=ser_title_variants, banned_keys=banned_keys,
            ep_title_variants=ep_title_variants, movie_year=movie_year, allowed_years=allowed_years,
            bad_regex=bad_regex, progress_cb=progress_cb,
            probe=(top_full_probe > 0 or max_quick_probe > 0),
            ep_soft=ep_soft, ban_other_episodes=ban_other_episodes,
        )
        self._apply_origin(all_items, origin)
        self._log_wave_yield(fetched, origin, all_items)
        self._log_wave_timing(_t_fetch, _t_filter)

        # ––– (DE-DUP #1 a #2) –––  WS má přednost před FS při shodném score
        self._log("DEDUP_BEGIN", len(all_items))
        seen_ids: set[str] = set()
        uniq_id: List[Release] = []
        for r in sorted(all_items, key=lambda x: (x.score, 0 if x.source == "webshare" else 1)):
            if r.ident not in seen_ids:
                uniq_id.append(r)
                seen_ids.add(r.ident)

        self._log("DEDUP2_BEGIN", len(uniq_id))
        seen_sig: dict[tuple[int, str], int] = {}   # sig → index v uniq_final
        uniq_final: List[Release] = []
        for r in uniq_id:
            sig = (r.size, r.quality)
            if sig in seen_sig:
                # Duplicita: WS nahradí FS pokud stávající je FS a nový je WS
                idx = seen_sig[sig]
                _kept, _gone = uniq_final[idx], r
                if uniq_final[idx].source != "webshare" and r.source == "webshare":
                    uniq_final[idx] = r
                    _kept, _gone = r, _kept
                self._log("DEDUP_DROP", _gone.ident, "size_quality", _kept.ident, _gone.name)
                continue
            seen_sig[sig] = len(uniq_final)
            uniq_final.append(r)

        result = uniq_final

        # 4) Uložit do cache
        self._cache_wave_result(cache_key, result, int(_wstats.get("errors", 0) or 0) - _err0)

        # 5) MI2 lazy-enrichment: rozjeď krokové zjišťování MediaInfo (FILMY parity se SERIÁLY)
        #    Pozn.: richmovie_mi2 importuje richmovie_engine → proto lazy import až tady, aby nevznikl circular import.
        try:
            from richmovie_mi2 import MediaInfoSecondEdition as _MI2
            _MI2.start(
                releases=result[:32],        # skenuj jen rozumný „viditelný” výřez
                client_factory=self._get_client,
                fs_client_factory=self._get_fs_client,  # 21.02.2026 – Fastshare MI2 podpora
                first_batch=8,               # první refresh po ~8 položkách
                max_items=32,
                refresh=True,
                key=_listing_key(),
            )
            self._log(
                "MI2_START",
                f"count={min(len(result), 32)} first_batch=8 refresh=True",
            )
        except Exception as _mi2_err:
            self._log("MI2_KICK_FAIL", str(_mi2_err))

        return result









    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    #  INTERNALS
    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    # 2025-09-07 15:14 CEST (Europe/Prague)
    def _probe(self, r: Release) -> None:
        """
        ÚČEL: Jediným síťovým dotazem vytáhnout MediaInfo (± pár MB, Range) a
        doplnit:
          • odhad délky (minuty) do `r.est_min`
          • syrové MI do `r.mediainfo` (+ RAM cache)
          • NOVĚ: sloučit jazyky z MI do `r.audios` / `r.subs` (super‑set)

        Zachována původní logika a limity (bez změny paralelizace).
        """
        if getattr(r, "mediainfo", None):
            return  # už máme

        mi = self._get_client().probe_mediainfo(r.ident)
        if not mi:
            return

        # – délka (sekundy → minuty) –
        if mi.get("duration"):
            r.est_min = mi["duration"] // 60

        # – jazyky z MediaInfo (sloučení s tím, co padlo z názvu souboru) –
        try:
            aud_mi, sub_mi = extract_langs_from_mediainfo(mi)
            if aud_mi:
                r.audios = sorted(set(r.audios) | set(aud_mi))
            if sub_mi:
                r.subs   = sorted(set(r.subs)   | set(sub_mi))
        except Exception:
            # selhání extrakce jazyků nesmí shodit sondu
            pass

        # – ulož do objektu i do sdílené RAM cache –
        r.mediainfo = mi
        with self._lock:
            self._mi_cache[r.ident] = mi



    # ------------------------------------------------------------------ #
    def get_mediainfo(self, ident: str) -> Optional[dict]:
        """
        Vrátí MediaInfo z RAM cache; pokud tam není, stáhne je jednorázově
        a uloží do cache.  Nikdy nestahuje víc než oněch ≈ 5 MB.
        """
        with self._lock:
            if ident in self._mi_cache:
                return self._mi_cache[ident]

        mi = self._get_client().probe_mediainfo(ident)
        if mi:
            with self._lock:
                self._mi_cache[ident] = mi
        return mi




# 2025-09-07 16:46 CEST (Europe/Prague)
# ─────────────────────────────────────────────────────────────────────────────
#  MediaInfo 2nd-pass – thread-safe hinty pro LabelFormatter (CZ dabing/titulky)
#  13.12.2025 17:19 CET – NOVĚ: perzistence na disk (mi2_cache.json) + robustní normalizace
# ─────────────────────────────────────────────────────────────────────────────
_MI2_HINTS: dict[str, dict] = {}
_MI2_LOCK  = threading.Lock()

# disková cache (kvůli Container.Refresh, které často spustí listing v nové instanci)
_MI2_DISK: dict[str, dict] = {}
_MI2_DISK_LOADED: bool = False
_MI2_DISK_STAMP: Optional[tuple] = None     # otisk souboru (mtime_ns, velikost), ze kterého je `_MI2_DISK`


def _mi2_file_stamp() -> Optional[tuple]:
    if not _MI2_CACHE_PATH:
        return None
    try:
        st = os.stat(_MI2_CACHE_PATH)
        return (int(st.st_mtime_ns), int(st.st_size))
    except OSError:
        return None


def _log_mi2_warning(text: str) -> None:
    try:
        xbmc.log("[RichMovie] %s" % text, xbmc.LOGWARNING)
    except Exception:
        pass
_MI2_TTL_SECS: int = 180 * 24 * 60 * 60  # 180 dní (metadata jazyků se prakticky nemění)

#  21.12.2025 17:58 CET (Europe/Prague)
# FÁZE 2: debounce zápisu mi2_cache.json (disk I/O optimalizace)
_MI2_DISK_DIRTY: bool = False
_MI2_DISK_DIRTY_COUNT: int = 0
_MI2_DISK_LAST_FLUSH_TS: int = 0

# Debounce flush – disk je pomalý a mi2_publish může běžet ve smyčce nad 20+ releasy.
# Hodnoty jsou konzervativní: chceme výrazně snížit I/O, ale pořád průběžně perzistovat.
_MI2_DISK_FLUSH_MIN_INTERVAL_SECS: int = 1          # max 1× za sekundu
_MI2_DISK_FLUSH_EVERY_N_CHANGES: int = 10           # nebo po 10 změnách

# 21.02.2026 – FÁZE B: retry politika pro negativní cache (exponenciální backoff)
# Formát: {reason: (base_delay_secs, multiplier, max_retries, permanent_after_days)}
#   base_delay_secs     – čekání před prvním retry (po retry_count=0)
#   multiplier          – delay = base * multiplier^retry_count (s capem)
#   max_retries         – po vyčerpání je fail permanentní
#   permanent_after_days – absolutní strop od prvního selhání (pojistka)
_MI2_RETRY_POLICY: dict[str, tuple[int, float, int, int]] = {
    #                    base_delay  mult  max_retries  permanent_after_days
    "timeout":          (   3600,    2.0,      5,             30),   # 1h→2h→4h→8h→16h → permanent
    "error":            (   7200,    2.0,      4,             30),   # 2h→4h→8h→16h → permanent
    "empty":            (  86400,    3.0,      2,             14),   # 1d→3d → permanent
    "skip_mp4":         (      0,    0,        0,              0),   # permanent, nikdy retry
    # 3.5.129 (incident PeterFM): odkaz autoritativně nevydal médium (HTML stránka
    # Free účtu, CDN 4xx). Je to vlastnost ÚČTU/IP/odkazu, ne souboru — po obnovení
    # VIP soubor hraje. Proto prakticky nikdy permanentní: backoff 1h→2h→…→ strop
    # 7 dní (_MI2_RETRY_MAX_DELAY_SECS) a pak týdenní opakování; permanentní až po
    # 365 pokusech (~7 let), permanent_after_days=0 = absolutní strop vypnutý.
    "not_media":        (   3600,    2.0,    365,              0),
}
_MI2_RETRY_MAX_DELAY_SECS: int = 7 * 24 * 60 * 60   # cap 7 dní (pojistka proti přetečení)
_MI2_RETRY_DEFAULT_POLICY: tuple[int, float, int, int] = (7200, 2.0, 3, 30)  # pro neznámé reason
_MI2_MAX_ENTRIES: int = 5000  # max počet záznamů v disk cache (ochrana proti OOM)



try:
    _MI2_ADDON_ID = xbmcaddon.Addon().getAddonInfo("id")
    _MI2_PROFILE_DIR = xbmcvfs.translatePath(f"special://profile/addon_data/{_MI2_ADDON_ID}")
except Exception:
    _MI2_PROFILE_DIR = ""

_MI2_CACHE_PATH = os.path.join(_MI2_PROFILE_DIR, "mi2_cache.json") if _MI2_PROFILE_DIR else ""







def _mi2_now_ts() -> int:
    try:
        return int(datetime.datetime.now().timestamp())
    except Exception:
        return 0


# 21.02.2026 – FÁZE B: retry helper funkce
def _mi2_compute_next_retry_ts(reason: str, retry_count: int, last_fail_ts: int) -> int:
    """Vypocita next_retry_ts pro fail marker.  Vraci 0 = permanentni (zadne dalsi retry)."""
    policy = _MI2_RETRY_POLICY.get(reason, _MI2_RETRY_DEFAULT_POLICY)
    base_delay, multiplier, max_retries, _perm_days = policy
    if max_retries <= 0 or base_delay <= 0:
        return 0
    if retry_count >= max_retries:
        return 0
    delay = base_delay * (multiplier ** retry_count)
    delay = int(min(delay, _MI2_RETRY_MAX_DELAY_SECS))
    return last_fail_ts + delay


def _mi2_fail_is_retryable(fail: dict, disk_ts: int = 0) -> bool:
    """Rozhodne, zda je fail marker zpusobily pro re-probe (retry je na rade).

    Args:
        fail:    sub-dict "fail" z MI2 cache val
        disk_ts: casovy razitko obalu na disku (fallback pro stare zaznamy)

    Returns:
        True  = ident by se mel znovu probovat
        False = jeste v backoff okne nebo permanentne selhal
    """
    if not isinstance(fail, dict):
        return False

    reason = str(fail.get("reason", "")).strip()
    policy = _MI2_RETRY_POLICY.get(reason, _MI2_RETRY_DEFAULT_POLICY)
    base_delay, multiplier, max_retries, permanent_after_days = policy

    # Permanentni reason (skip_mp4) nebo nulova konfigurace
    if max_retries <= 0 or base_delay <= 0:
        return False

    # Metadata z fail markeru (zpetne kompatibilni defaulty)
    retry_count = int(fail.get("retry_count", 0) or 0)
    first_fail_ts = int(fail.get("first_fail_ts", 0) or 0)
    last_fail_ts = int(fail.get("last_fail_ts", 0) or 0)
    next_retry_ts = int(fail.get("next_retry_ts", 0) or 0)

    # Backward compat: stare zaznamy nemaji timestampy → pouzij disk_ts
    if not last_fail_ts:
        last_fail_ts = disk_ts or 0
    if not first_fail_ts:
        first_fail_ts = last_fail_ts

    now = _mi2_now_ts()

    # Pojistka: absolutni strop od prvniho selhani
    if permanent_after_days > 0 and first_fail_ts > 0:
        ceiling = first_fail_ts + (permanent_after_days * 86400)
        if now > ceiling:
            return False

    # Max retries vycerpany
    if retry_count >= max_retries:
        return False

    # Preferovana cesta: predpocitane next_retry_ts
    if next_retry_ts > 0:
        return now >= next_retry_ts

    # Fallback: vypocet z last_fail_ts + backoff (pro stare zaznamy)
    if last_fail_ts <= 0:
        return True  # zadne casove info → povol retry
    delay = base_delay * (multiplier ** retry_count)
    delay = int(min(delay, _MI2_RETRY_MAX_DELAY_SECS))
    return now >= (last_fail_ts + delay)


def _mi2_ensure_dir() -> None:
    """Best-effort vytvoření profilu doplňku (pro zápis mi2_cache.json)."""
    try:
        if _MI2_PROFILE_DIR and (not xbmcvfs.exists(_MI2_PROFILE_DIR)):
            xbmcvfs.mkdirs(_MI2_PROFILE_DIR)
    except Exception:
        pass





def _mi2_load_disk_locked() -> None:
    """Načte mi2_cache.json do RAM (jen jednou) + provede TTL purge.

    21.12.2025 17:58 CET (Europe/Prague)

    FÁZE 2 – optimalizace:
      • TTL purge už při načtení může odstranit staré položky.
        Původně se tím jen zmenšila RAM reprezentace, ale soubor na disku zůstal
        “nafouknutý”.
      • NOVĚ: při purge označíme diskovou cache jako “dirty” a necháme ji
        zapsat až debouncovaně (nebo force před Container.Refresh).
    """
    global _MI2_DISK_LOADED, _MI2_DISK, _MI2_DISK_STAMP
    global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT

    # Φ-E (30.09.2026, audit Fable F2-V2): MediaInfo je od 3.5.173 vstupem řazení (kvalita, dabing, délka).
    # Služba žije dny a plugin je nový proces na každé kliknutí — co změřil jeden, musí vidět druhý, jinak
    # automatický výběr a první řádek výpisu vyjdou různě. Soubor se proto čte znovu, když ho mezitím
    # změnil jiný proces (otisk); záznamy TOHOTO procesu, které ještě nejsou na disku, zůstávají.
    stamp = _mi2_file_stamp()
    if _MI2_DISK_LOADED and stamp == _MI2_DISK_STAMP:
        return

    mine = dict(_MI2_DISK) if (_MI2_DISK_LOADED and _MI2_DISK_DIRTY) else {}
    _MI2_DISK_LOADED = True
    _MI2_DISK_STAMP = stamp
    if stamp is None:
        _MI2_DISK = mine
        return

    try:
        with open(_MI2_CACHE_PATH, "r", encoding="utf-8") as fh:
            raw = json.load(fh) or {}
        disk = raw if isinstance(raw, dict) else {}
    except Exception as exc:
        # nečitelný soubor (zámek jiného procesu): pracuje se s tím, co je v paměti, příště znovu
        _MI2_DISK_STAMP = ("unreadable",)
        _log_mi2_warning("mi2 cache unreadable now: %r" % (exc,))
        return
    for k, v in mine.items():
        if (v or {}).get("ts", 0) >= (disk.get(k) or {}).get("ts", 0):
            disk[k] = v
    _MI2_DISK = disk

    # TTL purge
    try:
        cut = _mi2_now_ts() - _MI2_TTL_SECS
        stale = [k for k, v in (_MI2_DISK or {}).items() if (v or {}).get("ts", 0) < cut]
        for k in stale:
            _MI2_DISK.pop(k, None)

        # FÁZE 2: purge označíme jako “dirty”, ale NEflushujeme hned (aby listing neškubal diskem)
        if stale:
            _MI2_DISK_DIRTY = True
            _MI2_DISK_DIRTY_COUNT += len(stale)
    except Exception:
        pass

    # Max size cap to prevent OOM on low-memory devices
    try:
        if len(_MI2_DISK) > _MI2_MAX_ENTRIES:
            # Evict oldest entries by timestamp
            sorted_keys = sorted(
                _MI2_DISK,
                key=lambda k: float((_MI2_DISK[k] or {}).get("ts", 0) or 0),
            )
            for _ek in sorted_keys[:len(_MI2_DISK) - _MI2_MAX_ENTRIES]:
                _MI2_DISK.pop(_ek, None)
            _MI2_DISK_DIRTY = True
            _MI2_DISK_DIRTY_COUNT += len(sorted_keys) - _MI2_MAX_ENTRIES
    except Exception:
        pass





def _mi2_flush_disk_locked(*, force: bool = False) -> bool:
    """Zapíše mi2_cache.json (atomicky přes .tmp).

    21.12.2025 17:58 CET (Europe/Prague)

    FÁZE 2 – optimalizace:
      • Původně se flushovalo na disk po KAŽDÉ `mi2_publish()` → při 20 releasích = 20 zápisů celého JSON.
      • NOVĚ:
          - držíme “dirty” flag + počítadlo změn
          - flush je **debouncovaný** (max 1× za ~1s) nebo po N změnách
          - `force=True` obejde debounce (použijeme pro „kritické“ body)

    Pozn.:
      • Tato funkce předpokládá, že volající drží `_MI2_LOCK`.
    """
    global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT, _MI2_DISK_LAST_FLUSH_TS

    if not _MI2_CACHE_PATH:
        return False

    # Pokud není co zapisovat, nic nedělej (typicky: cache se jen četla)
    if (not force) and (not _MI2_DISK_DIRTY):
        return False

    now_ts = _mi2_now_ts()

    # Debounce: pokud jsme flushovali “před chvílí” a změn je málo, odlož zápis
    if not force:
        try:
            min_int = int(_MI2_DISK_FLUSH_MIN_INTERVAL_SECS or 1)
        except Exception:
            min_int = 1
        try:
            every_n = int(_MI2_DISK_FLUSH_EVERY_N_CHANGES or 10)
        except Exception:
            every_n = 10

        if _MI2_DISK_LAST_FLUSH_TS and (now_ts - int(_MI2_DISK_LAST_FLUSH_TS)) < max(1, min_int):
            if int(_MI2_DISK_DIRTY_COUNT or 0) < max(1, every_n):
                return False

    _mi2_ensure_dir()

    try:
        # 3.5.123: trvanlivý atomický zápis přes SSOT. Dřívější „fallback na
        # přímý zápis, když os.replace selže" byl přesně ten neatomický zápis,
        # před kterým měl replace chránit — selhání se teď hlásí, ne obchází.
        import richmovie_atomic as _atomic
        # Φ-C (30.09.2026, E4-F05): kompaktně — odsazení na Pythonu 3.8 vypíná rychlý kodér (59 → 16 ms na flush)
        if not _atomic.write_json(_MI2_CACHE_PATH, _MI2_DISK or {}, separators=(",", ":")):
            return False

        # Flush OK → reset “dirty”
        _MI2_DISK_DIRTY = False
        _MI2_DISK_DIRTY_COUNT = 0
        _MI2_DISK_LAST_FLUSH_TS = now_ts
        return True
    except Exception:
        return False







# ---------------------------------- METODA ---------------------------------- #
# richmovie_engine.py › mi2_flush_disk
# (vytvořeno: 21.12.2025 17:58 CET (Europe/Prague) – FÁZE 2: veřejný flush pro MI2; force=True pro „kritické“ body)
# ---------------------------------------------------------------------------- #
def mi2_flush_disk(*, force: bool = False) -> bool:
    """
    21.12.2025 17:58 CET (Europe/Prague)

    Veřejný flush pro MI2 disk cache (`mi2_cache.json`).

    Proč existuje:
      • Ve FÁZI 2 už `mi2_publish()` NEflushuje disk po každé položce.
      • Když Kodi udělá `Container.Refresh()`, často se listing vykreslí v nové instanci.
        Proto je občas potřeba umět disk flushnout “teď hned”.

    Použití:
      • MI2 worker volá před `Container.Refresh` (force=True)
      • kdokoli jiný může volat bez force – uplatní se debounce v `_mi2_flush_disk_locked`.
    """
    with _MI2_LOCK:
        _mi2_load_disk_locked()
        return _mi2_flush_disk_locked(force=bool(force))







def _mi2_norm_code(token: str) -> str:
    """
    14.12.2025 11:50 CET (Europe/Prague)

    Normalizace jazyků z MI2/MediaInfo na dvoupísmenné kódy pro UI:
      CZ, SK, EN, DE, FR, ES, IT, PL, RU, HU, PT, JA, KO, ZH, AR, HI, TR, …
    """
    s = (token or "").strip()
    if not s:
        return ""

    up = s.upper()

    # různé „ne-jazykové“ tokeny, které se objevují v metadata
    if up in {"FULL", "DEFAULT", "UND", "UNKNOWN"}:
        return ""

    # forced titulky
    if "FORCED" in up or up == "FU":
        return "FU"

    # Czech – ISO 639-1 je CS, ale v UI chceme CZ
    if re.search(r"\b(CZ|CZE|CES)\b", up) or ("CZECH" in up) or re.search(r"\bCS\b", up):
        return "CZ"

    # Slovak
    if re.search(r"\b(SK|SLK|SLO)\b", up) or ("SLOVAK" in up) or ("SLOVEN" in up):
        return "SK"

    # English
    if re.search(r"\b(EN|ENG)\b", up) or ("ENGLISH" in up):
        return "EN"

    # German
    if re.search(r"\b(DE|DEU|GER)\b", up) or ("GERMAN" in up):
        return "DE"

    # French / Spanish / Italian / Portuguese
    if re.search(r"\b(FR|FRA|FRE)\b", up) or ("FRENCH" in up):   return "FR"
    if re.search(r"\b(ES|SPA)\b", up) or ("SPANISH" in up):      return "ES"
    if re.search(r"\b(IT|ITA)\b", up) or ("ITALIAN" in up):      return "IT"
    if re.search(r"\b(PT|POR)\b", up) or ("PORTUG" in up):       return "PT"

    # Polish / Russian / Hungarian
    if re.search(r"\b(PL|POL)\b", up) or ("POLISH" in up):       return "PL"
    if re.search(r"\b(RU|RUS)\b", up) or ("RUSSIAN" in up):      return "RU"
    if re.search(r"\b(HU|HUN)\b", up) or ("HUNGAR" in up):       return "HU"

    # Japanese / Korean / Chinese
    if re.search(r"\b(JA|JPN)\b", up) or ("JAPAN" in up):        return "JA"
    if re.search(r"\b(KO|KOR)\b", up) or ("KOREAN" in up):       return "KO"
    if re.search(r"\b(ZH|ZHO|CHI)\b", up) or ("CHINESE" in up) or ("MANDARIN" in up):
        return "ZH"

    # Arabic / Hindi / Turkish
    if re.search(r"\b(AR|ARA)\b", up) or ("ARAB" in up):         return "AR"
    if re.search(r"\b(HI|HIN)\b", up) or ("HINDI" in up):        return "HI"
    if re.search(r"\b(TR|TUR)\b", up) or ("TURK" in up):         return "TR"

    # fallback: pokud obsahuje aspoň 2 písmena v kuse, vezmi první dvě
    m = re.search(r"[A-Z]{2}", up)
    return m.group(0) if m else ""




# ---------------------------------- METODA ---------------------------------- #
# richmovie_engine.py › mi2_publish
# (upraveno: 22.12.2025 20:58 CET (Europe/Prague) – FÁZE A: negativní MI2 cache (fail marker) + merge-safe zachování původní logiky)
# ---------------------------------------------------------------------------- #
def mi2_publish(
    ident: str,
    aud_langs: Iterable[str] = (),
    sub_langs: Iterable[str] = (),
    *,
    video_w: int | None = None,
    video_h: int | None = None,
    sub_present: bool | None = None,
    duration_s: int | None = None,
    fail_reason: str | None = None,
    fail_detail: str | None = None,
    hdr: str | None = None,
    dv_profile: int | None = None,
    dv_compat: str | None = None,
) -> None:
    """
    22.12.2025 20:58 CET (Europe/Prague)

    Noc 03.11.2026 (4.0.6, Φ3): `hdr` ('DOVI', 'HDR10'…), `dv_profile` (5, 7, 8…) a `dv_compat` ('hdr10', 'sdr',
    'hlg', 'none') — Dolby Vision ve výpisu streamů podle schopností zařízení (`richmovie_quality.dv_playability`).
    Stejná zásada jako u videa: „nevím“ nepřepíše známé.

    Uloží „hinty“ z MI2 (MediaInfo) pro daný ident – pro listing (LabelFormatter)
    i pro finální logiku v pluginu.

    ZÁSADY:
      • Merge-safe: nové info jen doplňuje / zpřesňuje. “Nevím” nesmí přepsat stav.
      • Video rozměry (video_w/video_h) ukládáme i když aud/sub nevyšly.
      • sub_present=False znamená: titulky prokazatelně nejsou → listing nemá ukazovat “CZ tit?”.
      • duration_s (sekundy) – využije runtime sanity (TMDb runtime ±10 %).

    NOVĚ (FÁZE A – stabilita / Android / “žádné re-probe po dokončení”):
      • fail_reason uloží “fail marker” do MI2 cache (mi2_cache.json).
        To se bere jako cache-hit → MI2 už daný ident znovu neprobuje,
        dokud uživatel nedá „Reset cache“ (mi2_clear_cache).
      • Při úspěšném publish (aud/sub/video/duration/sub_present) se existující fail marker
        odstraní (aby nezůstal “negativní” stav, když už data máme).

    FÁZE 2 – výkon/IO:
      • Původně: `mi2_publish()` flushoval disk po každém identu.
      • NOVĚ: `mi2_publish()` jen označí disk cache jako “dirty” a flushuje debouncovaně.
        Když potřebuješ “flush hned” (např. před Container.Refresh), zavolej `mi2_flush_disk(force=True)`.
    """
    ident = str(ident or "").strip()
    if not ident:
        return

    # --- normalizace jazyků (používáme existující helper) ---
    try:
        aud = {_mi2_norm_code(str(s)) for s in (aud_langs or ()) if s}
        sub = {_mi2_norm_code(str(s)) for s in (sub_langs or ()) if s}
        aud.discard("")
        sub.discard("")
    except Exception:
        aud, sub = set(), set()

    # --- video rozměry ---
    try:
        vw = int(video_w) if isinstance(video_w, (int, float)) and int(video_w) > 0 else None
    except Exception:
        vw = None
    try:
        vh = int(video_h) if isinstance(video_h, (int, float)) and int(video_h) > 0 else None
    except Exception:
        vh = None

    # --- duration (sekundy) ---
    try:
        ds = int(duration_s) if isinstance(duration_s, (int, float)) and int(duration_s) > 0 else None
    except Exception:
        ds = None

    # --- fail marker (negativní cache) ---
    try:
        fr = str(fail_reason or "").strip()
    except Exception:
        fr = ""
    fr = fr or None

    try:
        fd = str(fail_detail or "").strip()
    except Exception:
        fd = ""
    if fd:
        # zmenši riziko “rozjetí” jsonu / logů; drž to krátké
        fd = fd.replace("\r", " ").replace("\n", " ").strip()
        if len(fd) > 240:
            fd = fd[:240] + "…"
    else:
        fd = ""

    # --- Dolby Vision / HDR (Φ3) — jen známé hodnoty, krátké řetězce ---
    hdr_v = str(hdr or "").strip().upper()[:12] or None
    try:
        dvp = int(dv_profile) if dv_profile is not None and 0 <= int(dv_profile) <= 20 else None
    except (TypeError, ValueError):
        dvp = None
    dvc = str(dv_compat or "").strip().lower()[:12] or None

    has_lang_info = bool(aud or sub)
    has_video_info = bool(vw or vh or hdr_v or dvp is not None or dvc)
    has_sub_presence_info = (sub_present is True) or (sub_present is False)
    has_duration_info = bool(ds)
    has_fail_info = bool(fr)

    # Když nemáme vůbec nic, nedává smysl ukládat.
    if (not has_lang_info) and (not has_video_info) and (not has_sub_presence_info) and (not has_duration_info) and (not has_fail_info):
        return

    ts = _mi2_now_ts()

    with _MI2_LOCK:
        global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT

        # načti disk (kvůli merge)
        _mi2_load_disk_locked()

        existing_disk = None
        try:
            existing_disk = _MI2_DISK.get(ident, {}).get("val")
        except Exception:
            existing_disk = None

        existing_ram = _MI2_HINTS.get(ident) if isinstance(_MI2_HINTS.get(ident), dict) else None

        base: dict = {}
        if isinstance(existing_disk, dict):
            base.update(existing_disk)
        elif isinstance(existing_ram, dict):
            base.update(existing_ram)

        new_val = dict(base)

        # --- Fail marker: nastav (nebo odstraň při úspěšném publish) ---
        # FÁZE B (21.02.2026): retry-aware fail marker s exponenciálním backoffem
        if fr:
            fv = {"reason": fr}
            if fd:
                fv["detail"] = fd

            # Retry counter management: inkrementuj pokud stejný reason, jinak fresh
            existing_fail = None
            try:
                existing_fail = base.get("fail") if isinstance(base.get("fail"), dict) else None
            except Exception:
                existing_fail = None

            now_ts_f = _mi2_now_ts()

            if existing_fail and str(existing_fail.get("reason", "")) == fr:
                # Stejný reason jako předtím → retry selhal znovu → inkrementuj
                prev_count = int(existing_fail.get("retry_count", 0) or 0)
                fv["retry_count"] = prev_count + 1
                fv["first_fail_ts"] = int(existing_fail.get("first_fail_ts", 0) or 0) or now_ts_f
                fv["last_fail_ts"] = now_ts_f
            else:
                # První selhání (nebo jiný reason) → fresh fail marker
                fv["retry_count"] = 0
                fv["first_fail_ts"] = now_ts_f
                fv["last_fail_ts"] = now_ts_f

            # Předpočítej next_retry_ts pro rychlý check v mi2_get_flags()
            fv["next_retry_ts"] = _mi2_compute_next_retry_ts(
                fr, fv["retry_count"], fv["last_fail_ts"]
            )

            new_val["fail"] = fv
        else:
            # pokud jsme získali nějaká data, fail už nedává smysl → smaž ho
            if "fail" in new_val and (has_lang_info or has_video_info or has_sub_presence_info or has_duration_info):
                try:
                    del new_val["fail"]
                except Exception:
                    pass

        # --- Audio: zapisuj jen když něco víme (jinak “nevím” nepřepisujeme) ---
        if aud:
            new_val["aud"] = sorted(aud)
            new_val["cz_dub"] = ("CZ" in aud)

        # --- Subtitles: sub_present je klíčové pro “jistě nejsou” ---
        if sub_present is False:
            new_val["sub_present"] = False
            new_val["sub"] = []
            new_val["cz_sub"] = False
        elif sub_present is True:
            prev_sub_present = new_val.get("sub_present", None)
            new_val["sub_present"] = True

            if sub:
                new_val["sub"] = sorted(sub)
                new_val["cz_sub"] = ("CZ" in sub)
            else:
                # titulky existují, ale jazyk jsme nevytáhli → nesmíme tvrdit “ne”
                if prev_sub_present is False:
                    new_val["sub"] = []
                    if "cz_sub" in new_val:
                        try:
                            del new_val["cz_sub"]
                        except Exception:
                            pass

        # --- Video: merge (nikdy nemažeme) ---
        if vw:
            new_val["video_w"] = vw
        if vh:
            new_val["video_h"] = vh
        if hdr_v:
            new_val["hdr"] = hdr_v
        if dvp is not None:
            new_val["dv_profile"] = dvp
        if dvc:
            new_val["dv_compat"] = dvc

        # --- Duration: merge (nikdy nemažeme; “nevím” nepřepisuje) ---
        if ds:
            new_val["duration_s"] = ds

        # RAM + DISK
        _MI2_HINTS[ident] = dict(new_val)
        _MI2_DISK[ident] = {"ts": ts, "val": dict(new_val)}

        # FÁZE 2: označ jako dirty; samotný flush je debouncovaný
        _MI2_DISK_DIRTY = True
        try:
            _MI2_DISK_DIRTY_COUNT = int(_MI2_DISK_DIRTY_COUNT or 0) + 1
        except Exception:
            _MI2_DISK_DIRTY_COUNT = 1

        # Bezpečnostní “lazy flush”: max 1× za ~1s nebo po N změnách.
        _mi2_flush_disk_locked(force=False)








# ---------------------------------- METODA ---------------------------------- #
# richmovie_engine.py › mi2_get_flags
# (upraveno: 21.02.2026 – FÁZE B: retry logika pro fail markery s exponenciálním backoffem)
# ---------------------------------------------------------------------------- #
def mi2_get_flags(ident: str) -> dict:
    """Vrátí slovník s MI2 hinty (cz_dub, cz_sub, aud, sub, video_h, video_w, sub_present, duration_s).
    Může vracet i klíč "fail" (negativní cache).

    Čte: 1) RAM _MI2_HINTS  2) diskovou cache mi2_cache.json (s TTL)

    FÁZE A (22.12.2025): fail marker = cache-hit (neprobuje se znovu).
    FÁZE B (21.02.2026): fail marker s retry logikou – transientní selhání (timeout, error)
      se po exponenciálním backoffu zkusí znovu. Permanentní selhání (skip_mp4, vyčerpané
      retries) zůstávají cache-hit navždy. Viz _mi2_fail_is_retryable().
    """
    ident = str(ident or "").strip()
    if not ident:
        return {}

    with _MI2_LOCK:
        global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT

        # 1) RAM
        rec = _MI2_HINTS.get(ident)
        if isinstance(rec, dict) and rec:
            return dict(rec)

        # 2) DISK
        _mi2_load_disk_locked()
        disk_rec = (_MI2_DISK or {}).get(ident) or {}
        ts = int((disk_rec or {}).get("ts", 0) or 0)
        val = (disk_rec or {}).get("val") or {}

        # FÁZE B (21.02.2026): fail marker s retry logikou
        is_fail = False
        fail_obj = None
        try:
            fail_obj = val.get("fail") if isinstance(val, dict) else None
            is_fail = isinstance(fail_obj, dict) and bool(fail_obj)
        except Exception:
            is_fail = False

        if is_fail:
            if _mi2_fail_is_retryable(fail_obj, disk_ts=ts):
                # Retry je na řadě: smaž z RAM (ale NE z disku – tam zůstane retry_count
                # pro mi2_publish(), který ho přečte a inkrementuje při dalším selhání)
                _MI2_HINTS.pop(ident, None)
                return {}   # vypadá jako "není v cache" → MI2 znovu probuje
            else:
                # Ještě v backoff okně nebo permanentně selhal → cache-hit
                if isinstance(val, dict) and val:
                    _MI2_HINTS[ident] = dict(val)
                    return dict(val)
                return {}

        # TTL pro pozitivní cache (beze změny)
        if ts and (_mi2_now_ts() - ts) > _MI2_TTL_SECS:
            _MI2_DISK.pop(ident, None)
            _MI2_DISK_DIRTY = True
            try:
                _MI2_DISK_DIRTY_COUNT = int(_MI2_DISK_DIRTY_COUNT or 0) + 1
            except Exception:
                _MI2_DISK_DIRTY_COUNT = 1
            return {}

        if isinstance(val, dict) and val:
            _MI2_HINTS[ident] = dict(val)
            return dict(val)

        return {}







# ---------------------------------- METODA ---------------------------------- #
# richmovie_engine.py › mi2_clear_cache
# (upraveno: 21.12.2025 17:58 CET (Europe/Prague) – FÁZE 2: mi2_clear_cache vždy force flushne disk (jinak by debounce mohl přeskočit smazání souboru))
# ---------------------------------------------------------------------------- #
def mi2_clear_cache() -> dict:
    """
    21.12.2025 17:58 CET (Europe/Prague)

    Vymaže MI2 cache (RAM + disk).

    Použití:
      • voláno z plugin.py v „Reset cache vyhledávání“, aby se dalo testovat „od nuly“.
    """
    with _MI2_LOCK:
        global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT

        ram_before = len(_MI2_HINTS)
        _MI2_HINTS.clear()

        _mi2_load_disk_locked()
        disk_before = len(_MI2_DISK)
        _MI2_DISK.clear()

        # po clear je disk jednoznačně dirty → force flush (musí fyzicky přepsat soubor)
        _MI2_DISK_DIRTY = True
        _MI2_DISK_DIRTY_COUNT = max(int(_MI2_DISK_DIRTY_COUNT or 0), 1)

        ok = _mi2_flush_disk_locked(force=True)

    return {"mi2_ram_before": ram_before, "mi2_disk_before": disk_before, "mi2_file_ok": ok}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_engine.py
# mi2_clear_fail_reason  (vytvořeno: 02.09.2026 23:05 CEST, Europe/Prague – 3.5.129)
# ---------------------------------------------------------------------------- #
def mi2_clear_fail_reason(reason: str) -> int:
    """Smaže z MI2 cache (RAM + disk) VŠECHNY fail markery s daným `reason`,
    ostatní hinty (aud/sub/video/duration) položek zachová. Vrací počet.

    PROČ (Fable audit 03.09.2026, F-06): marker `not_media` je vlastnost ÚČTU
    (Free), ne souboru. Po obnovení VIP by jinak exponenciální backoff držel
    MI2 metadata (dabing/titulky/délka) mimo výpis až 7 dní. Volá
    `richmovie_account_state.refresh_now` při přechodu Free → VIP.
    """
    reason = str(reason or "").strip()
    if not reason:
        return 0
    cleared_idents: set = set()
    with _MI2_LOCK:
        global _MI2_DISK_DIRTY, _MI2_DISK_DIRTY_COUNT
        _mi2_load_disk_locked()
        for ident, val in list(_MI2_HINTS.items()):
            fail = val.get("fail") if isinstance(val, dict) else None
            if isinstance(fail, dict) and str(fail.get("reason", "")) == reason:
                del val["fail"]
                cleared_idents.add(ident)
                if not val:
                    _MI2_HINTS.pop(ident, None)   # prázdný obal bez hintů
        for ident, wrapper in list(_MI2_DISK.items()):
            val = wrapper.get("val") if isinstance(wrapper, dict) else None
            fail = val.get("fail") if isinstance(val, dict) else None
            if isinstance(fail, dict) and str(fail.get("reason", "")) == reason:
                del val["fail"]
                cleared_idents.add(ident)
                if not val:
                    _MI2_DISK.pop(ident, None)
        if cleared_idents:
            _MI2_DISK_DIRTY = True
            _MI2_DISK_DIRTY_COUNT = max(int(_MI2_DISK_DIRTY_COUNT or 0), 1)
            _mi2_flush_disk_locked(force=True)
    return len(cleared_idents)





# --------------------------------------------------------------------------- #
# 2025‑07‑20 20:27 CEST  LabelFormatter.format() – pouze rozlišení + velikost
# --------------------------------------------------------------------------- #
class LabelFormatter:
    """
    Připraví dvouřádkový popisek + pravý sloupec (jazyky) pro GUI.
    Nově na prvním řádku zobrazuje **pouze** rozlišení v hranatých závorkách
    a velikost souboru v MB; zbytek (název release) zůstává na druhém řádku.
    """



    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class LabelFormatter # format
    # (upraveno: 27.12.2025 16:19 CET (Europe/Prague) – fallback (uncertain) „do šeda“, dokud runtime není potvrzen (runtime_confirmed); zachováno runtime_mismatch šedění)
    # ---------------------------------------------------------------------------- #
    # Beta.7 (2026-04-25): tabular alignment helpers.
    # U+2007 FIGURE SPACE = digit-width space v tabular figures fontech
    # (Kodi default Estuary používá NotoSans-Regular, který tabular figures má).
    # Ostatní mezery v label by se s proporcionálním fontem nezarovnaly.
    _DIGIT_SPACE = " "

    @staticmethod
    def _pad_left(s: str, width: int, pad_char: str = " ") -> str:
        """Right-align `s` v `width` znacích pomocí U+2007 (digit-width space)."""
        if width <= 0:
            return s
        return pad_char * max(0, width - len(s)) + s

    @staticmethod
    def quality_label(release: "Release", flags: Optional[dict] = None) -> str:
        """Štítek kvality v hranatých závorkách — SSOT pro popisek i pro šířku sloupce ve výpisu."""
        q_raw = (getattr(release, "quality", "") or "").strip().lower()
        label = _rm_quality.quality_rank(
            flags if isinstance(flags, dict) else {}, getattr(release, "ws_width", None),
            getattr(release, "ws_height", None), q_raw, getattr(release, "name", ""))[1]
        if label == _rm_quality.LABEL_OTHER and q_raw and q_raw != "other":
            label = q_raw.upper()              # značka zdroje, kterou SSOT nezná (např. „HDTV“)
        return label

    @staticmethod
    def format(
        release: "Release",
        *,
        show_source_prefix: bool = False,
        size_pad_width: int = 0,
        quality_pad_width: int = 0,
        **kwargs,
    ) -> dict[str, str]:
        """
        Beta.7 (2026-04-25) — tabular column alignment + source prefix:

          • show_source_prefix=True → WS/FS prefix u všech releasů (užitečné
            když user má FS i WS sources mixed → vidí, odkud je který stream).
            Detekce v plugin.py: any(r.source == "fastshare" for r in rels).
          • size_pad_width=N → padding U+2007 vlevo k size sloupci, aby čísla
            byla pod sebou. Caller spočítá max šířku napříč listingem.
          • quality_pad_width=N → padding kvality (1080P / 720P / WEBRip)
            uvnitř `[]` na fixní šířku.

        27.12.2025 16:19 CET (Europe/Prague):

        FINÁL Varianta A (listing):

        1) Kvalita v []:
           • vždy jen: 2160P / 1080P / 720P / 576P / 480P / 360P / 320P / 240P
           • když známe výšku videa (WS nebo MI2), nikdy neukazujeme OTHER
           • DVDRip / WEBRip / CAM necháváme, pokud je to jisté z názvu/heuristiky

        2) Badge (NOVĚ – bez placeholderů):
           • CZ dab:
               - MI2 cz_dub=True  → zobraz
               - MI2 cz_dub=False → nezobrazuj nic (žádná “negativní” informace)
               - MI2 neví         → zobraz CZ dab? jen když heuristika názvu naznačuje CZ audio
               - jinak            → nezobrazuj nic
           • CZ tit:
               - sub_present=False → nezobrazuj nic
               - MI2 cz_sub=True   → zobraz CZ tit
               - MI2 cz_sub=False  → nezobrazuj nic
               - MI2 neví          → zobraz CZ tit? jen když heuristika názvu naznačuje CZ titulky
               - jinak             → nezobrazuj nic
           • EN dab (jen když je jisté z MI2)
           • ORIG dab (např. KOR dab) jen když TMDb říká originál ≠ CZ/EN a MI2 má jisté audio

        3) Runtime sanity (TV):
           • pokud release.runtime_mismatch=True → celý label je šedý (žádné zlaté/modré zvýraznění),
             aby “špatná stopáž” stream nebila do očí (a současně je stejně řazen na konec seznamu).

        4) NOVĚ: Fallback sanity (TV):
           • pokud release.uncertain=True a máme runtime_ref_available=True a runtime_confirmed!=True → celý label šedě.
             (tj. „vidím to, ale stopáž to nepotvrdila“)
        """
        # ---------- MI2 flags ----------
        flags: dict = {}
        try:
            flags = mi2_get_flags(getattr(release, "ident", "")) or {}
        except Exception:
            flags = {}

        # ---------- 1. řádek: kvalita + velikost ----------
        # Φ-D (30.09.2026): štítek kvality = TŘÍDA, podle které se řadí (SSOT `richmovie_quality`): rozměry
        # obrazu (MediaInfo, pak Webshare; šířka i výška) mají přednost před názvem souboru. Dřív se štítek
        # bral z názvu a řadilo se podle výšky → „1080P“ pod „720P“ a širokoúhlý film 1920×800 jako 720p.
        display_q = LabelFormatter.quality_label(release, flags)

        # Source prefix (Beta.7 — multi-source viditelnost).
        # show_source_prefix=True (set by caller když user má FS) → WS/FS u všech
        # show_source_prefix=False (legacy) → jen FS prefix u Fastshare releasů
        source = getattr(release, "source", "webshare")
        if show_source_prefix:
            prefix = (
                "[COLOR FF888888]FS[/COLOR] " if source == "fastshare"
                else "[COLOR FF888888]WS[/COLOR] "
            )
        else:
            prefix = "[COLOR FF888888]FS[/COLOR] " if source == "fastshare" else ""

        # Quality block — natural width uvnitř `[]` + padding U+2007 ZA `]`
        # (čisté vizuálně: `[1080P]` `[720P]  ` `[WEBRip] ` — žádné mezery
        # uvnitř závorek). Padding dorovná total šířku quality bloku včetně
        # závorek na `quality_pad_width + 2` (= max content width + brackets).
        quality_block = f"[{display_q}]"
        if quality_pad_width > 0:
            target_total = quality_pad_width + 2  # `[` + content + `]`
            quality_block += LabelFormatter._DIGIT_SPACE * max(
                0, target_total - len(quality_block),
            )
        first_line = prefix + quality_block

        # Size column — right-align celého "X XXX MB" stringu na size_pad_width
        # chars pomocí U+2007 (digit-width space).
        try:
            if getattr(release, "size", None):
                size_str = f"{release.size_mb:,}".replace(",", " ") + " MB"
                if size_pad_width > 0:
                    size_str = LabelFormatter._pad_left(
                        size_str, size_pad_width, LabelFormatter._DIGIT_SPACE,
                    )
                first_line += " - " + size_str
        except Exception:
            pass

        # ---------- Badges (Beta.7 rozšíření 2026-04-25) ----------
        # Pravidlo: každá detekovaná stopa s jasným language tagem dostane
        # badge. Neznámé jazyky ('?', 'und', 'Undefined') se IGNORUJÍ — user
        # explicitně nechce zobrazovat "neumíme rozeznat". Heuristika z názvu
        # (Release.audios/subs vyplněné parsingem release tagů) přidává jen
        # `CZ dab?`/`CZ tit?` (šedé "?") když MI2 nezná stopy vůbec.
        badges: list[str] = []

        # Heuristika z názvu (release tag parser → uppercase 2-letter codes)
        try:
            name_aud = {str(x).strip().upper()[:2] for x in (getattr(release, "audios", None) or []) if x}
        except Exception:
            name_aud = set()
        try:
            name_sub = {str(x).strip().upper()[:2] for x in (getattr(release, "subs", None) or []) if x}
        except Exception:
            name_sub = set()

        # MI2 detekované jazyky (lowercase ISO codes z mediainfo)
        try:
            aud_list = flags.get("aud") or []
            aud_set = {str(x).strip().lower()[:2] for x in aud_list if x}
        except Exception:
            aud_set = set()
        try:
            sub_list = flags.get("sub") or []
            sub_set = {str(x).strip().lower()[:2] for x in sub_list if x}
        except Exception:
            sub_set = set()

        # Vyloučit neznámé tagy ('?', 'un' from "und"/"Undefined")
        _UNKNOWN_LANG = {"", "?", "un"}
        aud_set -= _UNKNOWN_LANG
        sub_set -= _UNKNOWN_LANG

        # ─── AUDIO badges ────────────────────────────────────────────────
        # CZ dab — preferuj engine flag `cz_dub` (preprocessed); fallback
        # na heuristiku z názvu pokud MI2 neumí.
        if "cz_dub" in flags:
            if bool(flags.get("cz_dub")):
                badges.append("[COLOR gold]CZ dab[/COLOR]")
        elif not aud_set:  # MI2 nezná žádné audio → heuristika z názvu
            if "CZ" in name_aud:
                badges.append("[COLOR grey]CZ dab?[/COLOR]")

        # SK dab — Slovak audio (CZ users to chápou; common v CZ/SK rip)
        if "sk" in aud_set:
            badges.append("[COLOR FFADD8E6]SK dab[/COLOR]")

        # EN dab — anglické audio
        if "en" in aud_set:
            badges.append("[COLOR FF87CEFA]EN dab[/COLOR]")

        # ORIG dab — TMDb original_language ≠ CZ/EN/SK + MI2 audio v tom jazyce
        movie = kwargs.get("movie")
        if isinstance(movie, dict):
            orig_iso = (movie.get("original_language") or "").strip().lower()
            if orig_iso in {"cs", "cz"}:
                orig_iso = "cs"
            if orig_iso and orig_iso not in {"cs", "en", "sk"}:
                iso_to_disp = {
                    "ko": "KOR", "ja": "JPN", "zh": "CHN",
                    "de": "GER", "fr": "FR", "es": "ESP",
                    "it": "ITA", "ru": "RUS", "pl": "POL",
                }
                disp = iso_to_disp.get(orig_iso, orig_iso.upper())
                if orig_iso[:2] in aud_set:
                    badges.append(f"[COLOR FF32CD32]{disp} dab[/COLOR]")

        # ─── SUBTITLE badges ──────────────────────────────────────────────
        # sub_present=False → MI2 jistě říká "žádné titulky" → vůbec nic
        sub_present = flags.get("sub_present", None)
        if sub_present is not False:
            # CZ tit — preferuj engine flag `cz_sub`; fallback heuristika
            if "cz_sub" in flags:
                if bool(flags.get("cz_sub")):
                    badges.append("[COLOR deepskyblue]CZ tit[/COLOR]")
            elif not sub_set:  # MI2 nezná → heuristika z názvu
                if "CZ" in name_sub:
                    badges.append("[COLOR grey]CZ tit?[/COLOR]")

            # SK tit — slovenské titulky
            if "sk" in sub_set:
                badges.append("[COLOR FF9FCFE3]SK tit[/COLOR]")

            # EN tit — anglické titulky (common pro mezinárodní rip + user
            # může doplnit CZ titulky přes RichSubtitles)
            if "en" in sub_set:
                badges.append("[COLOR FF87CEEB]EN tit[/COLOR]")

        if badges:
            first_line += " | " + " | ".join([b for b in badges if b])

        # ---------- 2. řádek: název releasu ----------
        second_line = f"[COLOR grey]\t\t\t{release.name}[/COLOR]"
        left = f"{first_line}\n{second_line}"

        # Runtime sanity (TV) + Fallback sanity (TV):
        #   • runtime_mismatch=True → vše šedě
        #   • fallback (uncertain) + máme runtime_ref_available + runtime_confirmed != True → vše šedě
        force_grey = bool(getattr(release, "runtime_mismatch", False))
        if not force_grey:
            try:
                if (
                    bool(getattr(release, "uncertain", False))
                    and bool(getattr(release, "runtime_ref_available", False))
                    and (not bool(getattr(release, "runtime_confirmed", False)))
                ):
                    force_grey = True
            except Exception:
                pass

        if force_grey:
            try:
                # odstraníme vnořené barvy (gold/deepskyblue/…), aby bylo VŠE šedé
                plain = re.sub(r"\[/?COLOR[^\]]*\]", "", left)
                left = f"[COLOR FF9E9E9E]{plain}[/COLOR]"
            except Exception:
                left = f"[COLOR FF9E9E9E]{left}[/COLOR]"

        # Varianta A: Label2 nepoužíváme (skin to často nezobrazuje)
        return {"label_left": left, "label_right": ""}







class _SearchProgress:
    """
    Jediný DialogProgress sdílený všemi vlákny *během jednoho hledání*.
    Čítače jsou kumulativní, takže procenta **nikdy neklesají** ani když
    paralelní vlákna hlásí své lokální rozsahy (Search / Probe).
    """
    _TXT = {"search": "Vyhledávání", "probe": "Analýza stopáže"}

    def __init__(self, heading: str = "RichMovie – Vyhledávání") -> None:
        self._dlg   = xbmcgui.DialogProgress()
        self._dlg.create("RichMovie", heading)
        self._last_pct: int           = -1
        self._totals: dict[str, int]  = {}
        self._done:   dict[str, int]  = {}
        self._lock   = threading.Lock()

    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def __call__(self, current: int, total: int, stage: str = "") -> None:
        """
        Callback z SearchEngine:
            current – aktuální index (1-based)
            total   – lokální limit v daném vlákně
            stage   – 'search' nebo 'probe'
        """
        with self._lock:
            # první blok daného typu → přičteme *total* jen jednou
            if stage not in self._totals or current == 1:
                self._totals[stage] = self._totals.get(stage, 0) + total
                self._done.setdefault(stage, 0)

            # přírůstek od minula (vlákno může skočit z 1→15 rovnou)
            if current > self._done[stage]:
                self._done[stage] = current

            done_all  = sum(self._done.values())
            total_all = sum(self._totals.values())
            pct       = int(done_all / total_all * 100) if total_all else 0
            pct       = max(pct, self._last_pct)        # procenta jen rostou
            self._last_pct = pct

            label = (
                f"{self._TXT.get(stage, stage)}: "
                f"{self._done[stage]} / {self._totals[stage]}"
            )
            self._dlg.update(pct, label)




    # –––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    def close(self) -> None:
        self._dlg.close()


# ═══════════════════════════════════════════════════════════════════════════════
#  SEARCH TIPS  – Sims-like rotujici hlasky pro vyhledavani
# ═══════════════════════════════════════════════════════════════════════════════


def _load_search_tips(addon_dir: str, ws_username: str, seed: int) -> list[str]:
    """
    Nacte search tips z JSON (bez persistence – zpetna kompatibilita).
    Pro persistenci pouzij _load_tip_persistent_state + _TipRotator(persistent_state=...).

    Vzdy nacte default.json. Pokud existuje <username>.json, primícha
    personalizovane tipy do defaultnich (ale jen pro daneho uzivatele).
    """
    tips_dir = os.path.join(addon_dir, "resources", "search_tips")
    loaded: list[str] = []

    # -- vzdy nacti defaultni tipy --
    default_file = os.path.join(tips_dir, "default.json")
    try:
        with open(default_file, encoding="utf-8") as f:
            data = json.load(f)
        loaded = data.get("tips", [])
    except Exception as _tp_e:
        _diag_log(f"search tips default load fail: {_tp_e}", 0)
        loaded = []

    # -- primichej personalizovane tipy pro uzivatele (pomer 2:1) --
    if ws_username:
        user_file = os.path.join(tips_dir, ws_username.lower() + ".json")
        if os.path.isfile(user_file):
            try:
                with open(user_file, encoding="utf-8") as f:
                    data = json.load(f)
                user_tips = data.get("tips", [])
                if user_tips and loaded:
                    # Zopakuj osobni tipy, aby pomer byl ~2 osobni : 1 obecna
                    repeat = max(1, round(2 * len(loaded) / len(user_tips)))
                    loaded.extend(user_tips * repeat)
                elif user_tips:
                    loaded = list(user_tips)
            except Exception as _tp_e:
                _diag_log(f"search tips user load fail: {_tp_e}", 0)

    if not loaded:
        return ["Hledám…"]

    rnd = random.Random(seed)
    tips = list(loaded)
    rnd.shuffle(tips)
    return tips


def _save_tip_state(profile_dir: str, order: list[int],
                    seen_count: int, pool_size: int, interleave_seen: int = 0) -> None:
    """Atomicky ulozi stav tipu do tip_state.json (+ `interleave_seen`, 3.5.157)."""
    if not profile_dir:
        return
    state_path = os.path.join(profile_dir, "tip_state.json")
    try:
        payload = {"order": order, "seen_count": seen_count,
                   "pool_size": pool_size, "interleave_seen": int(interleave_seen or 0)}
        import richmovie_atomic as _atomic
        if not _atomic.write_json(state_path, payload):
            _diag_log("tip_state save fail", 0)
    except Exception as _tp_e:
        _diag_log(f"tip_state save fail: {_tp_e}", 0)


def _load_tip_persistent_state(addon_dir: str, ws_username: str,
                               profile_dir: str = "") -> dict:
    """
    Nacte tips a persistent stav. Vraci dict s klici:
      tips, order, seen_count, pool_size, profile_dir
    Pro pouziti v _TipRotator.

    Vzdy nacte default.json. Pokud existuje <username>.json, primícha
    personalizovane tipy do defaultnich (ale jen pro daneho uzivatele).
    """
    tips_dir = os.path.join(addon_dir, "resources", "search_tips")
    loaded: list[str] = []
    interleave: dict = {}

    # -- vzdy nacti defaultni tipy --
    default_file = os.path.join(tips_dir, "default.json")
    try:
        with open(default_file, encoding="utf-8") as f:
            data = json.load(f)
        loaded = data.get("tips", [])
    except Exception as _tp_e:
        _diag_log(f"search tips default load fail: {_tp_e}", 0)
        loaded = []

    # -- primichej personalizovane tipy pro uzivatele (pomer 2:1) --
    if ws_username:
        user_file = os.path.join(tips_dir, ws_username.lower() + ".json")
        if os.path.isfile(user_file):
            try:
                with open(user_file, encoding="utf-8") as f:
                    data = json.load(f)
                user_tips = data.get("tips", [])
                if user_tips and loaded:
                    # Zopakuj osobni tipy, aby pomer byl ~2 osobni : 1 obecna
                    repeat = max(1, round(2 * len(loaded) / len(user_tips)))
                    loaded.extend(user_tips * repeat)
                elif user_tips:
                    loaded = list(user_tips)
                # 3.5.157 (Richie 27.09.2026, Robišek): `interleave` = vlastní seznam, ze kterého jde
                # KAŽDÁ N-tá zobrazená hláška (vlastní pořadí, bez opakování, přežije restart).
                interleave = parse_interleave(data.get("interleave"))
            except Exception as _tp_e:
                _diag_log(f"search tips user load fail: {_tp_e}", 0)

    if not loaded:
        return {"tips": loaded, "order": [], "seen_count": 0,
                "pool_size": 0, "profile_dir": profile_dir, "interleave": interleave, "interleave_seen": 0}

    pool_size = len(loaded)
    state_path = os.path.join(profile_dir, "tip_state.json") if profile_dir else ""
    order: list[int] = []
    seen_count: int = 0
    interleave_seen: int = 0

    if state_path:
        try:
            if os.path.isfile(state_path):
                with open(state_path, encoding="utf-8") as f:
                    st = json.load(f)
                saved_pool = st.get("pool_size", 0)
                saved_order = st.get("order", [])
                saved_seen = st.get("seen_count", 0)
                if (saved_pool == pool_size
                        and len(saved_order) == pool_size
                        and 0 <= saved_seen <= pool_size):
                    order = saved_order
                    seen_count = saved_seen
                try:
                    interleave_seen = max(0, int(st.get("interleave_seen") or 0))
                except (TypeError, ValueError):
                    interleave_seen = 0
        except Exception:
            pass

    if not order or len(order) != pool_size:
        rnd = random.Random(int(time.time()))
        order = list(range(pool_size))
        rnd.shuffle(order)
        seen_count = 0

    # Pokud uz vsechny videl, reshuffluj
    if seen_count >= pool_size:
        rnd = random.Random(int(time.time()))
        order = list(range(pool_size))
        rnd.shuffle(order)
        seen_count = 0

    return {"tips": loaded, "order": order, "seen_count": seen_count,
            "pool_size": pool_size, "profile_dir": profile_dir,
            "interleave": interleave, "interleave_seen": interleave_seen}


def parse_interleave(raw: object) -> dict:
    """Čistá (3.5.157): `{"every": N ≥ 2, "tips": [str, …]}` → {"every", "tips"}; jinak {} (žádné prokládání)."""
    if not isinstance(raw, dict):
        return {}
    try:
        every = int(raw.get("every") or 0)
    except (TypeError, ValueError):
        return {}
    tips = [str(t).strip() for t in (raw.get("tips") or []) if isinstance(t, str) and str(t).strip()]
    if every < 2 or not tips:
        return {}
    return {"every": every, "tips": tips}


class _TipRotator:
    """
    Sdileny stav tipu mezi vlnami (W1 -> W2 -> ... -> WX+).
    Index se nikdy neresetuje – kazda dalsi vlna pokracuje kde predchozi skoncila.
    Persistuje stav do tip_state.json – pamatuje si, ktere tipy uz byly zobrazeny.
    """

    def __init__(self, tips: list[str], switch_every: float = 3.0,
                 persistent_state: dict = None) -> None:
        self._switch_every = switch_every
        self._lock = threading.Lock()
        self._last_switch = time.time()

        if persistent_state and persistent_state.get("tips"):
            raw_tips = persistent_state["tips"]
            self._order = list(persistent_state.get("order", []))
            self._seen_count = persistent_state.get("seen_count", 0)
            self._pool_size = persistent_state.get("pool_size", len(raw_tips))
            self._profile_dir = persistent_state.get("profile_dir", "")
            # Sestav seznam: nejdriv nezobrazene, pak zobrazene
            unseen = [raw_tips[self._order[i]]
                      for i in range(self._seen_count, self._pool_size)]
            seen = [raw_tips[self._order[i]]
                    for i in range(0, self._seen_count)]
            self._tips = unseen + seen if unseen else (seen if seen else ["Hledám…"])
            self._persistent = True
            _inter = persistent_state.get("interleave") or {}
            self._inter_tips = list(_inter.get("tips") or [])
            self._inter_every = int(_inter.get("every") or 0) if self._inter_tips else 0
            self._inter_seen = int(persistent_state.get("interleave_seen") or 0)
        else:
            self._tips = tips if tips else ["Hledám…"]
            self._order = []
            self._seen_count = 0
            self._pool_size = len(self._tips)
            self._profile_dir = ""
            self._persistent = False
            self._inter_tips = []
            self._inter_every = 0
            self._inter_seen = 0

        self._idx = 0
        self._shown_in_session = 0      # zobrazených hlášek z POOLU v této session (pro persistenci)
        self._display_no = 0            # pořadové číslo zobrazení v této session (kadence prokládání)
        self._current = self._tips[0]
        self._saved = False

    def current_tip(self) -> str:
        with self._lock:
            return self._current

    def maybe_advance(self) -> str:
        """Posune tip pokud ubehl dostatecny cas. Vraci aktualni tip.

        3.5.157: každé `interleave.every`-té zobrazení bere hlášku z prokládaného seznamu (vlastní
        cyklus `_inter_seen`, přežívá restart); pool se přitom NEposune, takže žádná hláška z poolu
        nepropadne. Kadence počítá zobrazení v session — přesně „každá pátá", jak Richie chtěl.
        """
        with self._lock:
            now = time.time()
            if now - self._last_switch >= self._switch_every:
                self._last_switch = now
                self._display_no += 1
                if self._inter_every and self._display_no % self._inter_every == 0:
                    self._current = self._inter_tips[self._inter_seen % len(self._inter_tips)]
                    self._inter_seen += 1
                else:
                    self._idx = (self._idx + 1) % len(self._tips)
                    self._shown_in_session += 1
                    self._current = self._tips[self._idx]
            return self._current

    @property
    def last_switch_time(self) -> float:
        with self._lock:
            return self._last_switch

    def save_final_state(self) -> None:
        """Ulozi finalni stav pri zavreni. Volat jednou na konci."""
        if not self._persistent or not self._profile_dir or self._saved:
            return
        self._saved = True
        with self._lock:
            # +1 protoze prvni tip (idx=0) se taky zobrazil
            total_shown = self._shown_in_session + 1
            new_seen = self._seen_count + total_shown
            order = list(self._order)
            pool_size = self._pool_size
            profile_dir = self._profile_dir
            inter_seen = self._inter_seen % len(self._inter_tips) if self._inter_tips else 0
        # File I/O mimo lock
        try:
            if new_seen >= pool_size:
                rnd = random.Random(int(time.time()))
                new_order = list(range(pool_size))
                rnd.shuffle(new_order)
                _save_tip_state(profile_dir, new_order, 0, pool_size, inter_seen)
            else:
                _save_tip_state(profile_dir, order, new_seen, pool_size, inter_seen)
        except Exception:
            pass


def _listing_key():
    """
    Klic listingu, pro ktery MI2 davka bezi.

    MUSI to byt URL invokace pluginu (`sys.argv`), NE `Container.FolderPath` —
    engine startuje MI2 uvnitr stavby adresare, kde je FolderPath jeste cesta,
    ze ktere se odchazi. Presne to vyrobilo 19.09.2026 klic
    `?action=show_recommendations` u vypisu streamu Terminatora 2.

    Runtime smoke 19.09.2026 20:04 odhalil, ze tyhle tri call sites v enginu
    klic nepredavaly a padaly do legacy fallbacku (`KEY_FALLBACK` v kodi.log).
    """
    try:
        import richmovie_listing as _L
        return _L.current_listing_key()
    except Exception:
        return None


class _SearchProgressWithTips:
    """
    JEDEN pravdivý průběh od kliknutí do seznamu streamů (Φ5A, 29.09.2026 — audit A06 R01/R03).

    Hlavní řádek = co se právě děje, česky a s počty („Hledám na Webshare a Fastshare (2/4)…“,
    „Zjišťuji dabing a kvalitu (3/10)…“); druhý řádek = hláška (tip), která se střídá sama.
    Procenta patří AKTUÁLNÍ fázi — dřív stála na 100 % celých až 12 s čekání na MediaInfo a dialog
    se pak ještě 0–4 s držel „kvůli hlášce“ (`close_with_min_display`, zrušeno — D4: tip běží jen
    po dobu skutečné práce; kontinuitu hlášek drží `tip_state.json`).

    Volání: engine `progress_cb(current, total, stage)` (fáze hledání), plugin `set_phase(text, done,
    total)` (názvy, třídění, MediaInfo, příprava seznamu). `iscanceled()` čtou engine i plugin —
    Zrušit opravdu ukončí hledání (A06 R10). `close()` je idempotentní.
    """
    #: Fáze, které hlásí engine přes `progress_cb` (stage) → text hlavního řádku.
    STAGE_TEXT = {"search": "Hledám na Webshare a Fastshare", "filter": "Třídím nalezené",
                  "probe": "Zjišťuji stopáž"}

    def __init__(self, heading: str, rotator: Optional[_TipRotator],
                 first_phase: str = "Připravuji hledání…") -> None:
        self._dlg = xbmcgui.DialogProgress()
        # 3.5.131: rotátor sestavuje `richmovie_search_tips.build_rotator` (SSOT);
        # None = sestavení selhalo → dialog jede s jednou neutrální hláškou,
        # hledání nikdy nespadne kvůli UX ozdobě.
        self._rotator = rotator if rotator is not None else _TipRotator([])
        self._heading = heading
        self._lock = threading.Lock()
        self._closed = False
        self._phase = first_phase
        self._pct = 0
        self._totals: dict[str, int] = {}
        self._done: dict[str, int] = {}
        self._dlg.create("RichMovie", self._message_locked(self._rotator.current_tip()))
        self._timer_stop = threading.Event()
        self._timer = threading.Thread(
            target=self._tip_loop,
            name="RichMovie.TipRotator",
            daemon=True,
        )
        self._timer.start()

    def _message_locked(self, tip: str) -> str:
        return f"{self._phase}\n{tip}" if tip else self._phase

    def _render_locked(self) -> None:
        try:
            self._dlg.update(max(0, min(100, int(self._pct))), self._message_locked(self._rotator.current_tip()))
        except Exception:
            pass

    def _tip_loop(self) -> None:
        """Background thread: střídá hlášku (druhý řádek); fázi a procenta nemění."""
        while not self._timer_stop.is_set():
            self._timer_stop.wait(0.5)
            if self._timer_stop.is_set():
                break
            self._rotator.maybe_advance()
            with self._lock:
                if self._closed:
                    break
                self._render_locked()

    def set_phase(self, text: str, done: Optional[int] = None, total: Optional[int] = None) -> None:
        """Nová fáze (hlavní řádek). S `done/total` se text doplní o „(done/total)“ a procenta jsou
        podíl téhle fáze; bez nich procenta zůstanou (fáze bez měřitelného pokroku)."""
        with self._lock:
            if self._closed:
                return
            if done is not None and total:
                self._phase = "%s (%d/%d)…" % (text.rstrip("…").rstrip(), int(done), int(total))
                self._pct = int(100 * max(0, min(int(done), int(total))) / int(total))
            else:
                self._phase = text
            self._render_locked()

    def __call__(self, current: int, total: int, stage: str = "") -> None:
        """Callback z SearchEngine — pokrok fáze hledání (součet přes dotazy vlny)."""
        with self._lock:
            if self._closed:
                return
            if stage not in self._totals or current == 1:
                self._totals[stage] = self._totals.get(stage, 0) + total
                self._done.setdefault(stage, 0)
            if current > self._done[stage]:
                self._done[stage] = current
            done_s = self._done.get(stage, 0)
            total_s = self._totals.get(stage, 0)
            label = self.STAGE_TEXT.get(stage, "Hledám")
            self._phase = "%s (%d/%d)…" % (label, done_s, total_s) if total_s else "%s…" % label
            self._pct = int(100 * done_s / total_s) if total_s else 0
            self._render_locked()

    def iscanceled(self) -> bool:
        """
        Zmackl uzivatel Zrusit / Zpet?

        `xbmcgui.DialogProgress` to umi odjakziva, ale cekaci smycky se ho
        neptaly - na Sony BRAVIA 19.09.2026 se stisk Zpet ignoroval po celou
        dobu 60s cekani na MediaInfo (plugin.py `_wait_for_mi2_window`).
        Best-effort: po zavreni dialogu vracime False, at se volajici smycka
        nechyti na mrtvem okne.
        """
        with self._lock:
            if self._closed:
                return False
        try:
            return bool(self._dlg.iscanceled())
        except Exception:
            return False

    def close(self) -> None:
        """Zastav timer, uloz stav tipu a zavri dialog. Idempotentní."""
        self._timer_stop.set()
        with self._lock:
            if self._closed:
                return
            self._closed = True
        try:
            self._timer.join(timeout=1.0)
        except Exception:
            pass
        try:
            self._rotator.save_final_state()
        except Exception:
            pass
        try:
            self._dlg.close()
        except Exception:
            pass

