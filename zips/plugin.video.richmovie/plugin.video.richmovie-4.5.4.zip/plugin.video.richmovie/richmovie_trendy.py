# -*- coding: utf-8 -*-
"""richmovie_trendy — „Filmy – Trendy dnes“ jen s filmy, ke kterým noc ověřila stream (4.5.2 Róbertův nápad, 4.5.3).

PROČ
----
Róbert (bandog) prochází Trendy stránku za stránkou a u každého sedmého filmu hledání nic nenajde (z Trendů 159 prázdných
hledání z 1 055 za 31 dní, `Handoff/PLAN_trendy_dostupnost_20261112.md`). Nevadí mu, že film není — vadí mu, že je
v Trendech vidět. Gate v noci prohledá Trendy STEJNÝM jádrem `rm_core` a stejnou kaskádou jako doplněk po kliknutí
a ke každému titulu si uloží verdikt „dostupné“ / „nic“. Doplněk se při vykreslení stránky na verdikty zeptá a podle
režimu účtu (zapíná správce na Gate) film skryje, označí, nebo nedělá nic.

KONTRAKT (SSOT = plán noci `Handoff/PLAN_noc_20261113_trendy.md` §3b)
---------------------------------------------------------------------
    POST /v1/tmdb/availability   tělo = identita (`identity_body`) + {"kind": "movie", "tmdb_ids": [int, … ≤ 100]}
    200 {"status": "ok", "mode": "off"|"mark"|"hide", "core": "<verze>+<otisk>" | null,
         "verdicts": {"<tmdb_id>": "available"|"none"},
         "sources": {"<tmdb_id>": "cam"|"orig"}}          # jádro 1.2.3 (mig 0060), volitelné — viz `parse_sources`
`sources` = třída zdroje „dostupné“ filmu: `cam` = noc našla jen záznamy z kina → v Trendech / TV tipech červené „CAM“
před názvem a `CAM_PLOT_TEXT` („Aktuálně máme k dispozici pouze amatérský záznam natočený v kině“) v popisu (všechny
režimy, jen při shodě jádra).
Chybějící id = neověřeno (noc film ještě nepočítala / nejistý výsledek). Cokoli jiného než platná odpověď (síť, 4xx, 5xx,
429, jiný tvar, pomalá odpověď) = režim `off` = přesně dnešní výpis. Nic se nikam neukládá (R2): verdikt je čerstvý jen na
Gate, doplněk ho drží jen po dobu vykreslení stránky.

REŽIMY
------
    off   výpis beze změny (výchozí pro všechny účty; jen se změří, kolik by se skrylo — řádek `TRENDY_FILTER`)
    mark  film „nic“ dostane v popisku „⚠ zatím není ke stažení“ a jde na konec stránky; neověřené zůstávají
    hide  JEN ověřeně „dostupné“ (Richie 16.11.2026: „filmy v trendy se objeví, až budou k dispozici přes noc nalezené
          fakt odpovídající streamy“; do 16.11. se skrývalo jen „nic“) — neověřené i „nic“ se vynechají, stránka se
          doplní z dalších stránek TMDb (nejvýš +2) a na konci je položka „Skryto N filmů bez ověřeného streamu —
          zobrazit“ = tatáž stránka bez skrývání (`show_hidden=1`: dostupné, neověřené, na konci „nic“ s označením)

POJISTKA JÁDRA: skrýt smí jen verdikt spočítaný STEJNÝM jádrem, jaké má tohle zařízení (`core` = `<RM_CORE_VERSION>+<prefix
core_sha>`, zrcadlo `RichMovie-nas/services/gate/app/go/core.info`). Jiné jádro (novější / starší Gate, flotila na jiné verzi)
by mohlo schovat film, který filtr TOHOTO zařízení najde → hide se lokálně zmírní na mark (návrh §3.7, P-F).

STRÁNKOVÁNÍ PŘI SKRÝVÁNÍ: doplnění bere celé další stránky TMDb a další stránka výpisu pokračuje ZA nimi (parametr
`tmdb_page`), jinak by se doplněné filmy na další stránce zopakovaly. Bez doplnění zůstává dnešní `page=N+1`.

Modul je čistý (bez Kodi); síť jen ve `query_gate` přes `richmovie_gate_transport` (lazy import, SSOT identity a retry).
Python 3.8 (Kodi 21 Windows) — `from __future__ import annotations`, žádné `X | None` za běhu.
"""
from __future__ import annotations

import re
from typing import Any, Callable, Dict, FrozenSet, Iterable, List, Optional, Sequence, Tuple

ENDPOINT = "/v1/tmdb/availability"       # pod prefixem tunelu `v1/tmdb` a v `_IDEMPOTENT_POST_PATHS` (čtení bez vedlejších účinků)
KIND_MOVIE = "movie"
MAX_IDS = 100                            # strop těla požadavku (§3b)

MODE_OFF = "off"
MODE_MARK = "mark"
MODE_HIDE = "hide"
MODES = frozenset({MODE_OFF, MODE_MARK, MODE_HIDE})
APPLIED_SHOW = "show"                    # hide + „zobrazit skryté“: okno jako hide, skryté označené na konci

VERDICT_AVAILABLE = "available"
VERDICT_NONE = "none"
VERDICTS = frozenset({VERDICT_AVAILABLE, VERDICT_NONE})

TMDB_PAGE_SIZE = 20                      # TMDb vrací 20 titulů na stránku (stejné číslo jako `tmdb_client.trending`)
TMDB_MAX_PAGE = 500                      # strop TMDb pro /trending
MAX_EXTRA_PAGES = 2                      # doplnění stránky nejvýš o 2 stránky TMDb (§3b)

# Rozpočet dotazu: filtr je vylepšení, výpis bez něj funguje → divák nesmí čekat. Timeout 3 s na pokus, celý dotaz
# nejvýš 4 s: rychlá chyba (ENETUNREACH) dostane jeden další pokus, timeout ne (3 + backoff + 3 > 4). 429 se nikdy
# neopakuje (`richmovie_http`).
REQUEST_TIMEOUT_S = 3.0
REQUEST_BUDGET_S = 4.0
REQUEST_MAX_ATTEMPTS = 2

PARAM_TMDB_PAGE = "tmdb_page"            # první stránka TMDb tohoto výpisu (jen po doplnění, jinak se odvodí z `page`)
PARAM_SHOW_HIDDEN = "show_hidden"        # „zobrazit“ z položky Skryto N — tatáž stránka bez skrývání
PARAM_EXTRA = "extra"                    # „zobrazit“: kolik stránek TMDb skrývající stránka doplnila (tatáž okna, F24 V5)
PARAM_EMPTY = "empty"                    # „Další stránka“: kolik spolehlivě prázdných stránek hide bylo těsně před touto
MAX_EMPTY_RUN = 2                        # konec výpisu až po 2 prázdných stránkách za sebou (= 160 filmů bez ověřeného, F25 N1)

MARK_TEXT = "⚠ zatím není ke stažení"
MARK_SUFFIX = "  [COLOR FF9E9E9E]%s[/COLOR]" % MARK_TEXT
PROP_AVAILABILITY = "richmovie.availability"    # vlastnost položky pro skin („none“ u označeného filmu)

# Štítek CAM (jádro 1.2.3, mig 0060, 21.11.2026; Richie: „už v trendy by mělo být ještě před názvem, ale za hodnocením
# červeně tlustě "CAM" a vlevo v popisu - Amatérský záznam kamerou v kině červeně“ + „pokud tedy není jistý stream
# originální“ + „štítek ke všem“). Gate pošle třídu zdroje „dostupné“ (`sources`: `cam` = noc našla jen záznamy z kina,
# `orig` = doložený originál); štítek jen u `cam`, ve VŠECH režimech (i off), jen při shodě jádra (pojistka jako u
# skrývání). Barvu dodá volající ze SSOT `richmovie_helpers.CAM_LABEL_COLORS` (tenhle modul je bez Kodi).
# Věta v popisu: Richie týž den po náhledu na PC: „a vlevo by mělo být napsáno "Aktuálně máme k dispozici pouze amatérský
# záznam natočený v kině".“ (dřív „Amatérský záznam kamerou v kině“).
SOURCE_CAM = "cam"
SOURCE_ORIG = "orig"
SOURCES = frozenset({SOURCE_CAM, SOURCE_ORIG})
CAM_TAG_TEXT = "CAM"
CAM_PLOT_TEXT = "Aktuálně máme k dispozici pouze amatérský záznam natočený v kině"
# vlastnost položky pro skin („cam“ u filmu jen ze záznamu z kina); `richmovie.source` už nese jiný údaj (upoutávky ČSFD,
# audit Fable F37 P2)
PROP_SOURCE = "richmovie.source_class"
SOURCES_INVALID = "invalid"                     # `sources` přišlo ve špatném tvaru → bez štítků (verdikty platí dál)

REASON_OK = "ok"
REASON_NO_IDS = "no_ids"
REASON_NO_IDENTITY = "no_identity"
REASON_UNAVAILABLE = "unavailable"       # modul transportu se nenačetl (poškozená instalace)
REASON_INVALID = "invalid"               # 200, ale jiný tvar než §3b

FILL_NONE = "none"                       # doplnění nebylo potřeba / režim nedoplňuje
FILL_FULL = "full"                       # stránka doplněná na cíl
FILL_LIMIT = "limit"                     # vyčerpáno MAX_EXTRA_PAGES
FILL_END = "end"                         # TMDb už nic nevrátil (konec seznamu nebo chyba stránky — stránka se NEspotřebuje)
FILL_ERROR = "error"                     # dotaz na verdikty doplnění selhal — doplněné filmy zůstanou neověřené (hide: Skryto N)
FILL_FIXED = "fixed"                     # „zobrazit“: okno přesně podle skrývající stránky (`PARAM_EXTRA`)

_ID_RE = re.compile(r"^[1-9][0-9]{0,9}$")
_CORE_RE = re.compile(r"^([0-9]+(?:\.[0-9]+)*)\+([0-9a-f]{6,64})$")
_CORE_MAX_LEN = 100

QueryFn = Callable[[Sequence[int]], Tuple[Optional["Verdicts"], str]]


# ── identifikátory ───────────────────────────────────────────────────────────────────────────────────────────────────
def as_id(raw: Any) -> int:
    """TMDb id jako kladné celé číslo, jinak 0. Jen `int` nebo řetězec číslic (bool a desetinná čísla ne)."""
    if isinstance(raw, bool):
        return 0
    if isinstance(raw, int):
        return raw if raw > 0 else 0
    if isinstance(raw, str) and _ID_RE.match(raw.strip()):
        return int(raw.strip())
    return 0


def item_id(item: Any) -> int:
    return as_id(item.get("id")) if isinstance(item, dict) else 0


def clean_ids(ids: Iterable[Any]) -> List[int]:
    """Kladná id bez duplicit, v původním pořadí."""
    out: List[int] = []
    seen = set()
    for raw in ids or ():
        mid = as_id(raw)
        if mid and mid not in seen:
            seen.add(mid)
            out.append(mid)
    return out


def build_request(ids: Iterable[Any], has_fastshare: bool = True) -> Dict[str, Any]:
    """Věcná část těla §3b (identitu přidá `query_gate`). Víc než `MAX_IDS` se neposílá — delší okno dělí na dávky
    `build_page` (F24 V6; jinak by zbytek zůstal neověřený = v hide navždy skrytý).
    `has_fastshare` = vlastní Fastshare TOHOTO zařízení: Gate pak „nic“ nevrátí (Fastshare ve v1 neověřuje — audit Fable T1
    V1; stav účtu `users.has_own_fastshare` patří jen poslednímu přihlášenému zařízení). Výchozí True = nevíme = opatrně."""
    return {"kind": KIND_MOVIE, "tmdb_ids": clean_ids(ids)[:MAX_IDS], "has_fastshare": bool(has_fastshare)}


def device_has_fastshare() -> bool:
    """Má TOTO zařízení vlastní přihlášení k Fastshare? SSOT nastavení (`richmovie_settings.get_fs_credentials`).
    Nečitelné nastavení = True (opatrně: Gate pak „nic“ nepošle a nic se neskryje — R2)."""
    try:
        import richmovie_settings
        return richmovie_settings.get_fs_credentials() is not None
    except Exception:
        return True


# ── odpověď ──────────────────────────────────────────────────────────────────────────────────────────────────────────
class Verdicts(object):
    """Platná odpověď Gate: režim účtu / zařízení, otisk jádra verdiktů a verdikty jen pro tituly s čerstvým výsledkem;
    `sources` = třída zdroje „dostupné“ filmů (jádro 1.2.3; prázdné = Gate ji neposlal / starý Gate / vadný tvar)."""

    __slots__ = ("mode", "core", "by_id", "sources", "sources_note")

    def __init__(self, mode: str, core: Optional[str], by_id: Dict[int, str],
                 sources: Optional[Dict[int, str]] = None, sources_note: str = "") -> None:
        self.mode = mode
        self.core = core
        self.by_id = by_id
        self.sources = dict(sources or {})
        self.sources_note = sources_note


def parse_response(status: Any, body: Any, requested: Sequence[int]) -> Optional[Verdicts]:
    """Přesný tvar §3b, jinak None (= režim off). Neznámé klíče navíc se tolerují (Gate je smí přidat), známé ne:
    jiný stav než 200, `status` ≠ "ok", režim mimo výčet, chybějící `core`, verdikt jiné hodnoty nebo pro titul, na který
    se doplněk neptal — to vše je chyba kontraktu, ne vlastnost titulu, a nesmí nic skrýt."""
    if type(status) is not int or status != 200:
        return None
    if not isinstance(body, dict) or body.get("status") != "ok":
        return None
    mode = body.get("mode")
    if not isinstance(mode, str) or mode not in MODES:
        return None
    if "core" not in body:
        return None
    core = body["core"]
    if core is not None and not (isinstance(core, str) and 0 < len(core) <= _CORE_MAX_LEN):
        return None
    raw = body.get("verdicts")
    asked = set(clean_ids(requested))
    if not isinstance(raw, dict) or len(raw) > len(asked):
        return None
    by_id: Dict[int, str] = {}
    for key, value in raw.items():
        if not isinstance(key, str) or not _ID_RE.match(key):
            return None
        mid = int(key)
        if mid not in asked:
            return None
        if not isinstance(value, str) or value not in VERDICTS:
            return None
        by_id[mid] = value
    sources, note = parse_sources(body.get("sources"), by_id)
    return Verdicts(mode, core, by_id, sources, note)


def parse_sources(raw: Any, by_id: Dict[int, str]) -> Tuple[Dict[int, str], str]:
    """`sources` odpovědi (jádro 1.2.3, volitelné): `{"<id>": "cam"|"orig"}` jen pro filmy, které Gate v téže odpovědi vrátil
    jako „dostupné“. Chybí = ({}, "") (starý Gate / vypínač). Cokoli jiného než přesný tvar = ({}, "invalid"): štítek je
    doplněk výpisu, ne kontrakt filtru — vadná třída nesmí vzít verdikty ani skrývání (a nesmí nic označit)."""
    if raw is None:
        return {}, ""
    if not isinstance(raw, dict) or len(raw) > len(by_id):
        return {}, SOURCES_INVALID
    out: Dict[int, str] = {}
    for key, value in raw.items():
        if not isinstance(key, str) or not _ID_RE.match(key):
            return {}, SOURCES_INVALID
        mid = int(key)
        if by_id.get(mid) != VERDICT_AVAILABLE or not isinstance(value, str) or value not in SOURCES:
            return {}, SOURCES_INVALID
        out[mid] = value
    return out, ""


def cam_tag(color: str) -> str:
    """„CAM“ červeně tučně před názvem (za hodnocením) — `color` = `richmovie_helpers.CAM_LABEL_COLORS["cam"]`."""
    return "[B][COLOR %s]%s[/COLOR][/B]  " % (color, CAM_TAG_TEXT)


def with_cam_plot(overview: Any, color: str) -> str:
    """Popis filmu s prvním řádkem `CAM_PLOT_TEXT` červeně (pod ním děj beze změny)."""
    head = "[COLOR %s]%s[/COLOR]" % (color, CAM_PLOT_TEXT)
    text = str(overview or "").strip()
    return head + ("\n" + text if text else "")


# ── pojistka jádra ───────────────────────────────────────────────────────────────────────────────────────────────────
def local_core() -> Optional[Tuple[str, str]]:
    """(verze, celý SHA-256) sdíleného jádra TOHOTO doplňku; None = jádro se nenačetlo. SSOT `richmovie_core_path.core_identity`
    (táž identita je i v klíči mezipaměti hledání)."""
    try:
        import richmovie_core_path
    except Exception:
        return None
    return richmovie_core_path.core_identity()


def core_matches(server_core: Any, local: Optional[Tuple[str, str]]) -> bool:
    """Spočítal Gate verdikty STEJNÝM jádrem? `<verze>+<prefix SHA>` (Gate `go.core.info`: 6 znaků; delší prefix se přijme).
    Neznámé jádro na kterékoli straně = ne (hide se zmírní na mark)."""
    if not isinstance(server_core, str) or local is None:
        return False
    m = _CORE_RE.match(server_core)
    if m is None:
        return False
    version, sha = local
    return m.group(1) == version and str(sha).startswith(m.group(2))


# ── dotaz na Gate ────────────────────────────────────────────────────────────────────────────────────────────────────
def request_profile(http_mod: Any) -> Any:
    """Profil popředí s krátkým rozpočtem (viz REQUEST_*)."""
    return http_mod.profile_foreground().replace(
        budget_s=REQUEST_BUDGET_S, timeout_s=REQUEST_TIMEOUT_S, max_attempts=REQUEST_MAX_ATTEMPTS)


def query_gate(ids: Sequence[Any]) -> Tuple[Optional[Verdicts], str]:
    """Verdikty pro tituly stránky: (Verdicts, "ok"), nebo (None, důvod) = režim off. Nikdy nevyhodí výjimku a nic neukládá."""
    req = build_request(ids, has_fastshare=device_has_fastshare())
    if not req["tmdb_ids"]:
        return None, REASON_NO_IDS
    try:
        import richmovie_gate_transport as _gt
        import richmovie_http as _http
        from richmovie_sync_queue import identity_body
    except Exception:
        return None, REASON_UNAVAILABLE
    try:
        body = identity_body(req)
        if not body.get("ws_proof"):
            return None, REASON_NO_IDENTITY          # bez identity by Gate odmítl — nic neposílat
        status, resp = _gt.post_json(ENDPOINT, body, profile=request_profile(_http))
    except Exception as exc:                         # síť, offline, jistič hostu, zrušení, nepřečtená identita
        return None, "transport:%s" % type(exc).__name__
    verdicts = parse_response(status, resp, req["tmdb_ids"])
    if verdicts is None:
        return None, (REASON_INVALID if status == 200 else "http_%s" % (status,))
    return verdicts, REASON_OK


# ── stránka ──────────────────────────────────────────────────────────────────────────────────────────────────────────
class TrendyPage(object):
    """Výsledek pro jednu stránku výpisu: co vykreslit, co označit, kolik je skryto a kde začne další stránka."""

    def __init__(self, base_items: Sequence[Any], start_tmdb_page: int, base_pages: int) -> None:
        self.window: List[Any] = list(base_items)    # všechny filmy, které stránka spotřebovala (základ + doplnění)
        self.items: List[Any] = list(self.window)    # co se vykreslí, v tomto pořadí
        self.marked: FrozenSet[int] = frozenset()    # id filmů s „⚠ zatím není ke stažení“
        # jádro 1.2.3: třída zdroje ze VŠECH dávek a doplnění (`sources`), štítek CAM jen při shodě jádra (`labels`)
        self.sources: Dict[int, str] = {}
        self.labels = False
        self.sources_note = ""
        self.cam: FrozenSet[int] = frozenset()       # id vykreslených filmů s červeným „CAM“
        self.hidden_count = 0
        self.mode = MODE_OFF                         # režim z Gate (off i při chybě dotazu)
        self.applied = MODE_OFF                      # co se opravdu stalo: off / mark / hide / show
        self.reason = REASON_OK
        self.skew = False
        self.available = self.none = self.unknown = 0
        self.extra_pages = 0
        self.queries = 0
        self.fill = FILL_NONE
        self.fill_reason = ""
        self.partial = ""                            # další dávka prvního dotazu selhala (okno > MAX_IDS) — důvod
        self.start_tmdb_page = int(start_tmdb_page)
        self.base_pages = int(base_pages)
        self.next_tmdb_page = self.start_tmdb_page + self.base_pages

    def next_cursor(self, explicit: bool) -> Optional[int]:
        """TMDb stránka, od které začne další stránka výpisu — jen když se okno posunulo (doplnění) nebo už jedeme po
        kurzoru (`explicit`); jinak None = dnešní `page=N+1` (režim off nemění ani URL)."""
        if explicit or self.extra_pages > 0:
            return self.next_tmdb_page
        return None

    @property
    def exhausted(self) -> bool:
        """Režim hide a v celém okně (i po doplnění) ani jeden ověřený film → řádek „zobrazit“ řekne proč a kolik filmů ukáže
        (audit Fable F24 V2). O konci výpisu rozhoduje `ends_listing` (až druhá spolehlivě prázdná stránka za sebou)."""
        return self.applied == MODE_HIDE and not self.items and self.hidden_count > 0

    @property
    def reliably_empty(self) -> bool:
        """Prázdná stránka, na kterou je spoleh: verdikty celého okna došly (doplnění bez chyby, všechny dávky prvního
        dotazu). Prázdnota po chybě dotazu je síť, ne noc → do konce výpisu se nepočítá (audit Fable F25, poznámka)."""
        return self.exhausted and self.fill != FILL_ERROR and not self.partial

    def finish(self, by_id: Dict[int, str]) -> "TrendyPage":
        """Režim hide = v Trendech JEN filmy, ke kterým noc ověřila skutečně odpovídající stream („dostupné“) — Richie
        16.11.2026: „filmy v trendy se objeví, až budou k dispozici přes noc nalezené fakt odpovídající streamy“. Neověřené
        (noc je ještě nepočítala / nejistý výsledek) i ověřené „nic“ se schovají za řádek „Skryto N — zobrazit“; po
        „zobrazit“ (show) jdou dostupné, pak neověřené, pak „nic“ s označením. Režim mark beze změny (označí jen „nic“)."""
        available: List[Any] = []
        unknown: List[Any] = []
        none: List[Any] = []
        self.available = self.none = self.unknown = 0
        for m in self.window:
            verdict = by_id.get(item_id(m))
            if verdict == VERDICT_NONE:
                self.none += 1
                none.append(m)
            elif verdict == VERDICT_AVAILABLE:
                self.available += 1
                available.append(m)
            else:
                self.unknown += 1
                unknown.append(m)
        if self.applied == MODE_HIDE:
            self.items, self.hidden_count = available, len(unknown) + len(none)
        elif self.applied == APPLIED_SHOW:
            self.items = available + unknown + none
            self.marked = frozenset(item_id(m) for m in none)
        elif self.applied == MODE_MARK:
            kept = [m for m in self.window if by_id.get(item_id(m)) != VERDICT_NONE]
            self.items = kept + none
            self.marked = frozenset(item_id(m) for m in none)
        else:
            self.items = list(self.window)
        # Štítek CAM (jádro 1.2.3): ve VŠECH režimech, jen u vykresleného „dostupné“ s třídou cam a jen při shodě jádra
        self.cam = frozenset(
            item_id(m) for m in self.items
            if self.labels and by_id.get(item_id(m)) == VERDICT_AVAILABLE and self.sources.get(item_id(m)) == SOURCE_CAM)
        self.next_tmdb_page = self.start_tmdb_page + self.base_pages + self.extra_pages
        return self

    def log_fields(self, page_no: int) -> Dict[str, Any]:
        return {"mode": self.mode, "applied": self.applied, "shown": len(self.items), "hidden": self.hidden_count,
                "unknown": self.unknown, "available": self.available, "none": self.none, "page": int(page_no),
                "tmdb_page": self.start_tmdb_page, "extra": self.extra_pages, "queries": self.queries,
                "fill": self.fill + (":" + self.fill_reason if self.fill_reason else ""), "skew": int(self.skew),
                "reason": self.reason, "partial": self.partial or "-", "exhausted": int(self.exhausted),
                "cam": len(self.cam), "sources": self.sources_note or ("ok" if self.labels else "skew")}

    def cam_log_line(self, ms: int) -> str:
        """Řádek logu štítku CAM mřížky (`cam_page`, audit Fable F37b N5): kolik filmů, kolik CAM, proč případně žádný."""
        return ("TRENDY_CAM ids=%d cam=%d available=%d reason=%s partial=%s sources=%s queries=%d ms=%d"
                % (len(self.window), len(self.cam), self.available, self.reason or "-", self.partial or "-",
                   self.sources_note or ("ok" if self.labels else "skew"), self.queries, int(ms)))

    def log_line(self, page_no: int, ms: int) -> str:
        f = self.log_fields(page_no)
        return ("TRENDY_FILTER mode=%(mode)s applied=%(applied)s shown=%(shown)d hidden=%(hidden)d unknown=%(unknown)d "
                "available=%(available)d none=%(none)d page=%(page)d tmdb_page=%(tmdb_page)d extra=%(extra)d "
                "queries=%(queries)d fill=%(fill)s skew=%(skew)d reason=%(reason)s partial=%(partial)s "
                "exhausted=%(exhausted)d cam=%(cam)d sources=%(sources)s" % f) + " ms=%d" % int(ms)


def _visible(items: Iterable[Any], by_id: Dict[int, str]) -> int:
    """Kolik filmů režim hide ukáže = ověřeně dostupné (16.11.2026; dřív vše kromě „nic“) — doplňování stránek cílí na ně."""
    return sum(1 for m in items if by_id.get(item_id(m)) == VERDICT_AVAILABLE)


def _fill(page: TrendyPage, by_id: Dict[int, str], target: int, fetch_tmdb_page: Callable[[int], Any],
          query: QueryFn, core: Optional[str], fixed_pages: Optional[int] = None) -> str:
    """Doplní okno stránky celými dalšími stránkami TMDb, dokud není `target` viditelných filmů (nejvýš MAX_EXTRA_PAGES).

    Každá spotřebovaná stránka TMDb skončí v okně celá (zobrazená nebo spočítaná jako skrytá) — další stránka výpisu
    začíná až za ní, takže nic nezmizí bez stopy. Prázdná / chybná stránka se nespotřebuje. Selhaný dotaz na verdikty
    doplnění: doplněné filmy zůstanou neověřené (= v hide schované za „Skryto N“, 16.11.2026) a doplňování skončí (další
    dotaz by jen prodloužil čekání).

    `fixed_pages` („zobrazit“ s `PARAM_EXTRA`): vezme PŘESNĚ tolik stránek, kolik doplnila skrývající stránka, bez ohledu na
    verdikty — okno je pak stejné i po selhaném dotazu (audit Fable F24 V5); verdikty slouží jen k pořadí a označení."""
    seen = set(clean_ids(item_id(m) for m in page.window))
    visible = _visible(page.window, by_id)
    fixed = fixed_pages is not None
    limit = max(0, min(int(fixed_pages), MAX_EXTRA_PAGES)) if fixed else MAX_EXTRA_PAGES
    if not fixed and visible >= target:
        return FILL_NONE
    query_ok = True
    while page.extra_pages < limit:
        tmdb_page = page.start_tmdb_page + page.base_pages + page.extra_pages
        if tmdb_page > TMDB_MAX_PAGE:
            return FILL_END
        try:
            more = list(fetch_tmdb_page(tmdb_page) or [])
        except Exception:
            return FILL_END
        if not more:
            return FILL_END
        page.extra_pages += 1
        fresh: List[Any] = []
        for m in more:
            mid = item_id(m)
            if mid and mid in seen:                  # TMDb přeleje titul přes hranu stránky — jednou stačí
                continue
            if mid:
                seen.add(mid)
            fresh.append(m)
        page.window.extend(fresh)
        ids = clean_ids(item_id(m) for m in fresh)
        if ids and query_ok:
            got, reason = query(ids)
            page.queries += 1
            # Gate mezi dotazy změnil jádro (nasazení): verdikty doplnění nejsou ověřené pojistkou jádra první odpovědi
            # → nepoužít, doplněné filmy zůstanou neověřené (cross-check Codex 13.11.2026)
            failure = reason if got is None else ("core_changed" if got.core != core else "")
            if failure:
                page.fill_reason = failure
                if not fixed:
                    return FILL_ERROR
                query_ok = False                     # „zobrazit“: okno dobrat i bez verdiktů, další dotazy už neposílat
            else:
                by_id.update(got.by_id)
                _merge_sources(page, got)
        visible += _visible(fresh, by_id)
        if not fixed and visible >= target:
            return FILL_FULL
    if fixed:
        return FILL_FIXED if query_ok else FILL_ERROR
    return FILL_LIMIT


def _query_window(ids: List[int], query: QueryFn, page: TrendyPage) -> Tuple[Optional[Verdicts], Dict[int, str]]:
    """První dotaz na celé okno po dávkách ≤ `MAX_IDS` (Gate víc nepřijme; F24 V6 — TV tipy mohou mít víc). Režim a jádro
    určuje PRVNÍ dávka; další dávka s chybou nebo s jiným jádrem se nepoužije a zbytek okna zůstane neověřený
    (`page.partial` = důvod, další dávky se už neposílají)."""
    verdicts, reason = query(ids[:MAX_IDS])
    page.queries = 1
    page.reason = reason
    if verdicts is None:
        return None, {}
    by_id = dict(verdicts.by_id)
    _merge_sources(page, verdicts)
    for start in range(MAX_IDS, len(ids), MAX_IDS):
        got, why = query(ids[start:start + MAX_IDS])
        page.queries += 1
        failure = why if got is None else ("core_changed" if got.core != verdicts.core else "")
        if failure:
            page.partial = failure
            break
        by_id.update(got.by_id)
        _merge_sources(page, got)
    return verdicts, by_id


def cam_page(tmdb_ids: Iterable[Any], *, query: Optional[QueryFn] = None,
             local_core_fn: Optional[Callable[[], Optional[Tuple[str, str]]]] = None) -> "TrendyPage":
    """Štítek CAM pro výpis, který Trendy NEfiltruje (mřížka Trendů v novém vzhledu, Richie 21.11.2026: „normálně v rámci
    skinu tak jak teď, jen to tam doplnit“): `page.cam` = jen id dostupných filmů s třídou zdroje cam — nic se neskrývá,
    nepřeskládá ani nedoplňuje. Tatáž pravidla jako `build_page` (dávky ≤ `MAX_IDS`, pojistka jádra, vadné `sources` = bez
    štítků); chyba Gate = prázdné `cam` a důvod v `page.reason` (výpis beze změny). Řádek logu `cam_log_line`."""
    page = TrendyPage([{"id": i} for i in clean_ids(tmdb_ids)], 1, 1)
    page.applied = MODE_OFF
    ids = clean_ids(item_id(m) for m in page.window)
    if not ids:
        page.reason = REASON_NO_IDS
        return page.finish({})
    verdicts, by_id = _query_window(ids, query or query_gate, page)
    if verdicts is None:
        return page.finish({})
    page.labels = core_matches(verdicts.core, (local_core_fn or local_core)())
    return page.finish(by_id)


def _merge_sources(page: TrendyPage, got: Verdicts) -> None:
    """Třída zdroje dávky do stránky (jádro 1.2.3); vadné `sources` kterékoli dávky = poznámka do logu (štítky té dávky
    chybí, verdikty platí)."""
    page.sources.update(got.sources)
    if got.sources_note and not page.sources_note:
        page.sources_note = got.sources_note


def build_page(base_items: Sequence[Any], *, start_tmdb_page: int, target: int,
               fetch_tmdb_page: Callable[[int], Any], query: QueryFn, show_hidden: bool = False,
               show_extra: Optional[int] = None,
               local_core_fn: Optional[Callable[[], Optional[Tuple[str, str]]]] = None) -> TrendyPage:
    """Stránka Trendů podle režimu z Gate.

    `base_items` = dnešní stránka (`tmdb.trending(limit=target, page=start_tmdb_page)`), `fetch_tmdb_page(p)` = jedna
    další stránka TMDb, `query(ids)` = `query_gate`. Režim off / chyba = `items` je `base_items` beze změny.
    `show_extra` = `PARAM_EXTRA` z odkazu „zobrazit“ (None = starý odkaz bez něj → doplnění podle verdiktů)."""
    base_pages = max(1, int(target) // TMDB_PAGE_SIZE)
    page = TrendyPage(list(base_items or []), start_tmdb_page, base_pages)
    ids = clean_ids(item_id(m) for m in page.window)
    if not ids:
        page.reason = REASON_NO_IDS
        return page.finish({})
    verdicts, by_id = _query_window(ids, query, page)
    if verdicts is None:
        return page.finish({})
    page.mode = applied = verdicts.mode
    same_core = core_matches(verdicts.core, (local_core_fn or local_core)())
    # štítek CAM jen z verdiktu TÉHOŽ jádra (třída zdroje závisí na pravidlech délky a stupně záznamu v jádru) — všechny režimy
    page.labels = same_core
    if applied == MODE_HIDE and not same_core:
        applied, page.skew = MODE_MARK, True        # jiné jádro na Gate: nic neskrývat, jen označit (pojistka jádra)
    if applied == MODE_HIDE and show_hidden:
        applied = APPLIED_SHOW
    page.applied = applied
    if applied == MODE_HIDE:
        page.fill = _fill(page, by_id, int(target), fetch_tmdb_page, query, verdicts.core)
    elif applied == APPLIED_SHOW:
        page.fill = _fill(page, by_id, int(target), fetch_tmdb_page, query, verdicts.core, fixed_pages=show_extra)
    return page.finish(by_id)


# ── texty a parametry výpisu ─────────────────────────────────────────────────────────────────────────────────────────
def hidden_label(count: int) -> str:
    """Položka na konci stránky v režimu hide (čeština: 1 film / 2–4 filmy / 5+ filmů)."""
    n = int(count)
    if n == 1:
        return "Skryt 1 film bez ověřeného streamu — zobrazit"
    if 2 <= n <= 4:
        return "Skryty %d filmy bez ověřeného streamu — zobrazit" % n
    return "Skryto %d filmů bez ověřeného streamu — zobrazit" % n


def _show_all(n: int) -> str:
    if n == 1:
        return "zobrazit 1 film"
    if 2 <= n <= 4:
        return "zobrazit všechny %d filmy" % n
    return "zobrazit všech %d filmů" % n


def ends_listing(page: TrendyPage, empty_before: int) -> bool:
    """Konec výpisu (bez „Další stránka“) až po `MAX_EMPTY_RUN` spolehlivě prázdných stránkách za sebou. Verdikt
    „available“ žije 21 dní a noc bere čelo Trendů, takže ověřené filmy mohou být i za jednou prázdnou stránkou (audit Fable
    F25 N1); dvě za sebou = 160 filmů Trendů bez jediného ověřeného → dál by se klikalo naprázdno (F24 V2)."""
    return page.reliably_empty and int(empty_before) + 1 >= MAX_EMPTY_RUN


def empty_params(page: TrendyPage, empty_before: int) -> Dict[str, str]:
    """Parametr odkazu „Další stránka“: počet spolehlivě prázdných stránek za sebou; stránka s filmy (nebo nespolehlivě
    prázdná) počítadlo nuluje = nic (dnešní URL)."""
    return {PARAM_EMPTY: str(int(empty_before) + 1)} if page.reliably_empty else {}


def empty_run_param(raw: Any) -> int:
    """`PARAM_EMPTY` z URL: číslice 0–9, cokoli jiného = 0 (nikdy výjimka)."""
    text = str(raw or "").strip()
    return int(text) if len(text) == 1 and text in "0123456789" else 0


def hidden_row_label(page: TrendyPage, first_page: bool, empty_before: int = 0) -> str:
    """Text řádku „zobrazit“ na konci stránky v hide. Stránka bez jediného ověřeného filmu (`exhausted`) řekne proč a kolik
    filmů ukáže — „Skryto 80“ by sugerovalo, že doplněk něco schovává (audit Fable F24 V2); „Dál zatím…“ jen tam, kde
    výpis končí (`ends_listing`), jinak „Tady zatím…“ (o dalších stránkách nic netvrdí, F25 N1)."""
    n = int(page.hidden_count)
    if not page.exhausted:
        return hidden_label(n)
    if ends_listing(page, empty_before):
        head = "Dál zatím bez ověřeného streamu"
    elif first_page:
        head = "Zatím bez ověřeného streamu"
    else:
        head = "Tady zatím bez ověřeného streamu"
    return "%s — %s" % (head, _show_all(n))


def tmdb_page_param(raw: Any, default: int) -> Tuple[int, bool]:
    """(první stránka TMDb, přišla v URL?) — neplatná hodnota = odvozená z `page` (nikdy výjimka)."""
    text = str(raw or "").strip()
    if _ID_RE.match(text) and int(text) <= TMDB_MAX_PAGE:
        return int(text), True
    return int(default), False


def show_hidden_param(raw: Any) -> bool:
    return str(raw or "").strip() == "1"


def show_hidden_params(page_no: int, tmdb_page: int, extra_pages: Optional[int] = None) -> Dict[str, str]:
    """Parametry odkazu „zobrazit“: tatáž stránka (stejné okno TMDb — `PARAM_EXTRA` = počet doplněných stránek) bez
    skrývání."""
    out = {"page": str(int(page_no)), PARAM_TMDB_PAGE: str(int(tmdb_page)), PARAM_SHOW_HIDDEN: "1"}
    if extra_pages is not None:
        out[PARAM_EXTRA] = str(max(0, min(int(extra_pages), MAX_EXTRA_PAGES)))
    return out


def extra_param(raw: Any) -> Optional[int]:
    """`PARAM_EXTRA` z URL: 0–MAX_EXTRA_PAGES, cokoli jiného = None (= doplnit podle verdiktů, nikdy výjimka)."""
    text = str(raw or "").strip()
    if len(text) == 1 and text in "0123456789" and int(text) <= MAX_EXTRA_PAGES:
        return int(text)
    return None


def cursor_params(next_tmdb_page: Optional[int]) -> Dict[str, str]:
    """Parametr další stránky po doplnění; bez kurzoru prázdné (= dnešní URL)."""
    return {} if next_tmdb_page is None else {PARAM_TMDB_PAGE: str(int(next_tmdb_page))}


__all__ = [
    "ENDPOINT", "MODES", "MODE_OFF", "MODE_MARK", "MODE_HIDE", "APPLIED_SHOW", "VERDICT_AVAILABLE", "VERDICT_NONE",
    "MARK_TEXT", "MARK_SUFFIX", "PROP_AVAILABILITY", "PARAM_TMDB_PAGE", "PARAM_SHOW_HIDDEN", "TMDB_PAGE_SIZE",
    "Verdicts", "TrendyPage", "as_id", "item_id", "clean_ids", "build_request", "parse_response", "local_core",
    "core_matches", "request_profile", "query_gate", "device_has_fastshare", "build_page", "hidden_label", "hidden_row_label",
    "tmdb_page_param", "show_hidden_param", "show_hidden_params", "extra_param", "cursor_params", "PARAM_EXTRA",
    "PARAM_EMPTY", "MAX_EMPTY_RUN", "ends_listing", "empty_params", "empty_run_param",
]
