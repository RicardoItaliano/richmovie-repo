# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_source_health — vadný soubor = opakovaný konec na stejném místě (3.5.158)
───────────────────────────────────────────────────────────────────────────────
PROČ
  Incident 27.09.2026 (Chromecast ložnice, Lioness S02E08, Fastshare 2160p 1,6 GB):
  soubor končí / je poškozený kolem 36:15. Kodi ohlásil konec souboru v 36:15, auto-resume
  navázal na 36:15 a stream po 5 s skončil znovu (36:14). Čítač pokusů auto-resume žije jen
  v paměti služby a nuluje se po restartu Kodi i po ručním „Pokračovat" — Petra tak
  dostávala stále „Zdroj přerušil stream – navazuji (1/3)" a nabídka jiného streamu po
  vyčerpání pokusů nikdy nepřišla.

PRAVIDLO (SSOT)
  Utnutí sítí nastane pokaždé jinde. Soubor, který na STEJNÉ pozici (± tolerance) skončil
  aspoň dvakrát, je vadný od té pozice — navazovat na totéž místo nemá smysl.
  • Záznam je TRVALÝ (přežije restart Kodi i ruční Pokračovat) a patří ZAŘÍZENÍ
    (kořen dat, ne profil): vadný soubor je vadný pro kohokoli.
  • Vadný ident se NIKDY nefiltruje (filter parity — feedback_addon_release_filter_is_ssot),
    jen jde v pořadí za ostatní, výpis ho označí a Next-Up / auto výběr ho přeskočí, když
    existuje jiná verze.
  • Φ6 (29.09.2026): navázání na pozici, které se ani po `richmovie_start_watch.STALL_OFFER_S`
    neotevře, se počítá jako konec na tom místě (`note_open_stall`) — utnutí + zaseknuté navázání
    rozhodne o vadném souboru hned při prvním pokusu.
  • Čisté funkce (`evaluate`, `rank`) bez Kodi → harness scénář 70. Python 3.8.
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional

try:
    import xbmc as _xbmc
    _LOGINFO, _LOGWARNING = _xbmc.LOGINFO, _xbmc.LOGWARNING
except Exception:  # mimo Kodi (harness)
    _xbmc = None
    _LOGINFO, _LOGWARNING = 1, 2

HEALTH_FILE = "broken_sources.json"   # soubor zařízení (kořen dat)
SCHEMA = 1
MIN_REPEATS = 2                        # kolikrát na stejném místě = vadný soubor
TOLERANCE_MIN_S = 30.0                 # pozice checkpointu je přesná na jednotky sekund
TOLERANCE_PCT = 0.01                   # u dlouhých souborů 1 % délky
EOF_KEEP = 6                           # posledních N konců per ident (stačí na rozhodnutí)
START_KEEP = MIN_REPEATS + 2           # posledních N zaseknutých startů od začátku per ident (4.5.1)
RECORD_TTL_S = 30 * 24 * 3600          # CDN soubor se může opravit / zmizet
MAX_IDENTS = 300                       # strop souboru (nejstarší pryč)
# 4.5.3 (B2-01, audit flotily A5-1): Webshare odmítl ODKAZ kódem o souboru (smazaný, dočasně nedostupný, chráněný) nebo se
# soubor vůbec neotevřel → stačí JEDNOU (odpověď zdroje, ne odhad ze sítě), ale jen na pár hodin: „dočasně nedostupný“
# se vrací. Jen pořadí a popisek „⚠ nejde spustit“, nikdy filtr; úspěšný start záznam maže (`note_started`).
LINK_FAIL_TTL_S = 6 * 3600
LINK_FAIL_KEEP = 3
LABEL_PREFIX = "[COLOR FFE06060]⚠ vadný od %s[/COLOR] "


def _log(msg: str, level: int = _LOGINFO) -> None:
    if _xbmc is not None:
        try:
            _xbmc.log("[RichMovie/SourceHealth] " + msg, level)
        except Exception:
            pass


# Φ6 (29.09.2026): jeden formát času pro všechny texty navazování a zdraví zdroje (dřív kopie)
from richmovie_resume import format_time  # noqa: E402  (re-export: `richmovie_source_health.format_time`)


def tolerance_s(duration: float) -> float:
    try:
        d = float(duration or 0)
    except (TypeError, ValueError):
        d = 0.0
    return max(TOLERANCE_MIN_S, d * TOLERANCE_PCT)


# ─────────────────────────────────────────────────────────────────────────────
#  ČISTÉ ROZHODNUTÍ
# ─────────────────────────────────────────────────────────────────────────────
def _clean_eofs(record: Optional[Dict[str, Any]], now: float) -> List[Dict[str, float]]:
    out: List[Dict[str, float]] = []
    for e in (record or {}).get("eofs") or []:
        try:
            pos, ts = float(e.get("pos")), float(e.get("ts"))
        except (TypeError, ValueError, AttributeError):
            continue
        if pos > 0 and 0 <= now - ts <= RECORD_TTL_S:
            out.append({"pos": pos, "ts": ts})
    return out


def _clean_starts(record: Optional[Dict[str, Any]], now: float) -> List[float]:
    """Časy zaseknutých startů od začátku v okně `RECORD_TTL_S` (4.5.1)."""
    out: List[float] = []
    for t in (record or {}).get("start_stalls") or []:
        try:
            t = float(t)
        except (TypeError, ValueError):
            continue
        if 0 <= now - t <= RECORD_TTL_S:
            out.append(t)
    return out[-START_KEEP:]


def _clean_link_fails(record: Optional[Dict[str, Any]], now: float) -> List[float]:
    """Časy odmítnutých / neotevřených odkazů v okně `LINK_FAIL_TTL_S` (4.5.3)."""
    out: List[float] = []
    for t in (record or {}).get("link_fails") or []:
        try:
            t = float(t)
        except (TypeError, ValueError):
            continue
        if 0 <= now - t <= LINK_FAIL_TTL_S:
            out.append(t)
    return out[-LINK_FAIL_KEEP:]


def evaluate(record: Optional[Dict[str, Any]], position: float, duration: float,
             now: float, *, at_start: bool = False) -> Dict[str, Any]:
    """Přidá konec souboru na `position` a rozhodne. Vrací NOVÝ záznam
    `{"eofs": [...], "duration": d, "broken_at": pos|None, "ts": now}`.
    Vadný = aspoň `MIN_REPEATS` konců v okně ± tolerance kolem téhož místa; `broken_at` =
    nejnižší pozice v tom shluku (odtud dál soubor nejde).
    Pozice 0 se u konce souboru NEpočítá (neznámá pozice po `onPlayBackEnded`). Zaseknutý START od začátku
    (`at_start=True`, `note_open_stall`, audit flotily A3-02) je SAMOSTATNÝ údaj `start_stalls` → `start_broken`: jen pro
    pořadí a popisek výpisu, NIKDY ve shluku konců (audit Fable 12.11.2026 V2: dvě pomalé starty + pozdější utnutí ve
    45:00 vracely „vadný od 0:00“ a zabily automatické navázání). `broken_at` = jen z konců souboru."""
    eofs = _clean_eofs(record, now)
    starts = _clean_starts(record, now)
    try:
        pos = float(position or 0)
    except (TypeError, ValueError):
        pos = 0.0
    dur = float(duration or (record or {}).get("duration") or 0)
    if at_start and pos == 0:
        starts = (starts + [float(now)])[-START_KEEP:]
    elif pos > 0:
        eofs.append({"pos": pos, "ts": float(now)})
    return _decide(eofs, starts, dur, _clean_link_fails(record, now), now)


def _decide(eofs: List[Dict[str, float]], starts: List[float], dur: float, link_fails: List[float],
            now: float) -> Dict[str, Any]:
    """Rozhodnutí z očištěných údajů (jediná kopie pravidla pro zápis `evaluate` i vrácení `retract_open_stall`)."""
    eofs = eofs[-EOF_KEEP:]
    tol = tolerance_s(dur)
    broken_at: Optional[float] = None
    for e in eofs:
        cluster = [x["pos"] for x in eofs if abs(x["pos"] - e["pos"]) <= tol]
        if len(cluster) >= MIN_REPEATS:
            low = min(cluster)
            broken_at = low if broken_at is None else min(broken_at, low)
    return {"eofs": eofs, "start_stalls": starts, "start_broken": len(starts) >= MIN_REPEATS,
            "link_fails": link_fails,     # 4.5.3: záznam odkazu přežije konec / zaseknutí téhož souboru
            "duration": dur, "broken_at": broken_at, "ts": float(now)}


def evaluate_link_failed(record: Optional[Dict[str, Any]], now: float) -> Dict[str, Any]:
    """Přidá odmítnutý / neotevřený odkaz (4.5.3). Ostatní údaje záznamu beze změny; čistá funkce (harness 70)."""
    base = dict(record) if isinstance(record, dict) else {"eofs": [], "start_stalls": [], "start_broken": False,
                                                          "duration": 0.0, "broken_at": None}
    base["link_fails"] = (_clean_link_fails(record, now) + [float(now)])[-LINK_FAIL_KEEP:]
    base["ts"] = float(now)
    return base


def broken_at_in(data: Optional[Dict[str, Any]], ident: str, now: float) -> Optional[float]:
    """Pozice, od které je `ident` vadný, nebo None (záznam prošlý / nerozhodnutý). Opakovaně zaseknutý start od začátku
    (`start_broken`) = 0.0 („⚠ nejde spustit“) — jen pro pořadí a popisek výpisu (plugin `broken_map`)."""
    rec = ((data or {}).get("idents") or {}).get(str(ident or ""))
    if not isinstance(rec, dict):
        return None
    try:
        ts = float(rec.get("ts") or 0)
        at = rec.get("broken_at")
        at = float(at) if at is not None else None
    except (TypeError, ValueError):
        return None
    if not (0 <= now - ts <= RECORD_TTL_S):
        return None
    if bool(rec.get("start_broken")) or _clean_link_fails(rec, now):
        return 0.0
    return at


def rank(ident: str, broken: Dict[str, float]) -> int:
    """Pořadí pro výběr streamu: 1 = vadný (za ostatní), 0 = v pořádku. Nikdy filtr."""
    return 1 if str(ident or "") in broken else 0


def _prune(idents: Dict[str, Any], now: float) -> Dict[str, Any]:
    live = {}
    for k, v in idents.items():
        try:
            if isinstance(v, dict) and 0 <= now - float(v.get("ts") or 0) <= RECORD_TTL_S:
                live[k] = v
        except (TypeError, ValueError):
            continue
    if len(live) > MAX_IDENTS:
        keep = sorted(live.items(), key=lambda kv: float(kv[1].get("ts") or 0))[-MAX_IDENTS:]
        live = dict(keep)
    return live


# ─────────────────────────────────────────────────────────────────────────────
#  PERSISTENCE (zapisuje služba; od 4.5.3 i plugin `note_link_failed` — vše pod `FileLock`, čte-mění-zapisuje v zámku)
# ─────────────────────────────────────────────────────────────────────────────
def _path() -> str:
    import richmovie_paths
    return str(richmovie_paths.account_path(HEALTH_FILE))


def _load() -> Dict[str, Any]:
    path = _path()
    if not os.path.isfile(path):
        return {}   # většina zařízení — žádný READ_NO_FILE při každém výpisu
    import richmovie_atomic as _atomic
    data, _state = _atomic.read_json(path, {}, name="broken_sources", expected_type=dict)
    return data if isinstance(data, dict) else {}


def note_unexpected_eof(ident: str, position: float, duration: float,
                        now: Optional[float] = None) -> Optional[float]:
    """Služba po UNEXPECTED_EOF. Vrací pozici, od které je soubor vadný, nebo None.
    Selhání zápisu = None (R2: nic se nepředstírá; auto-resume jede jako dřív)."""
    return _note(ident, position, duration, now, "SOURCE_EOF")


def note_open_stall(ident: str, position: float, duration: float,
                    now: Optional[float] = None) -> Optional[float]:
    """Φ6 (29.09.2026, audit A05 F8): navázání na `position` se ani po `richmovie_start_watch.STALL_OFFER_S`
    neotevřelo. Počítá se jako konec souboru na tom místě — soubor tam nejde přehrát. Navázání po utnutí
    tak rozhodne o vadném souboru už při PRVNÍM pokusu (utnutí + zaseknutí na témže místě), ne až po dalších
    75–90 s a druhém utnutí. Za 60 dní se nad 30 s nespustil žádný zdravý soubor (7/7 = vadné), falešný záznam jen mění
    pořadí. Od 4.5.1 se počítá i start OD ZAČÁTKU (pozice 0): 23 ze 42 zaseknutí ve flotile bylo na začátku a rozbitý díl
    pak chodil nahoru i do autoplaye (audit 10.11.2026 A3-02); vadný je až po `MIN_REPEATS` zaseknutích, jen pořadí."""
    return _note(ident, position, duration, now, "SOURCE_STALL", at_start=True)


def retract_open_stall(ident: str, stamp: float, now: Optional[float] = None) -> bool:
    """Zaseknuté otevření nakonec dostalo obraz (souběh: obraz naskočil během kontroly CDN nebo zápisu, cross-check Codex
    13.11.2026 U7) → vrátit PŘESNĚ ten záznam (`ts` = `stamp`, se kterým ho zapsal `note_open_stall`) a znovu rozhodnout.
    Ostatní konce, zaseknutí i odmítnuté odkazy zůstávají — `note_started` konce souboru nemaže, takže zaseknuté NAVÁZÁNÍ
    (pozice > 0 = konec na tom místě) by jinak zůstalo a se skutečným utnutím na témže místě označilo hratelný soubor
    za vadný. True = vráceno a uloženo."""
    if not ident:
        return False
    now = time.time() if now is None else float(now)
    try:
        stamp = float(stamp)
        import richmovie_atomic as _atomic
        from richmovie_paths import LOCK_STALE_S
        with _atomic.FileLock(_path() + ".lock", stale_s=LOCK_STALE_S):
            data = _load()
            idents = _prune(dict(data.get("idents") or {}), now)
            rec = idents.get(str(ident))
            if not isinstance(rec, dict):
                return False
            eofs, starts = _clean_eofs(rec, now), _clean_starts(rec, now)
            keep_eofs = [e for e in eofs if e["ts"] != stamp]
            keep_starts = [t for t in starts if t != stamp]
            if len(keep_eofs) == len(eofs) and len(keep_starts) == len(starts):
                return False
            fails = _clean_link_fails(rec, now)
            if keep_eofs or keep_starts or fails:
                idents[str(ident)] = _decide(keep_eofs, keep_starts, float(rec.get("duration") or 0), fails, now)
            else:
                idents.pop(str(ident), None)    # nic nezbylo → záznam pryč (nezabírá místo ve stropu MAX_IDENTS, Fable F6 P2)
            ok = bool(_atomic.write_json(_path(), {"schema": SCHEMA, "idents": idents}))
        _log("SOURCE_STALL_RETRACTED ident=%s → záznam zaseknutí vrácen (otevření dostalo obraz) saved=%s" % (ident, ok),
             _LOGINFO if ok else _LOGWARNING)
        return ok
    except Exception as exc:
        _log("SOURCE_STALL_RETRACTED failed: %r" % (exc,), _LOGWARNING)
        return False


def open_failure_counts(cdn_status: int) -> bool:
    """Smí se neotevřený stream připsat SOUBORU podle kontroly CDN (`service_nextup._cdn_status`)? Čistá funkce.
    0 = CDN neodpovídá (síť) → ne; 429 a 5xx = CDN je přetížená / v poruše, to je vlastnost služby, ne souboru → ne
    (cross-check Codex 13.11. P-H3: dřív stačila jakákoli odpověď); jinak (soubor se vydává, nebo ho CDN odmítá 4xx) ano."""
    status = int(cdn_status or 0)
    return 0 < status < 500 and status != 429


def note_link_failed(ident: str, code: str = "", now: Optional[float] = None) -> bool:
    """4.5.3 (B2-01): Webshare odmítl odkaz kódem o SOUBORU (`richmovie_webshare.FILE_LINK_FILE_CODES`, zapisuje plugin), nebo
    se stream vůbec neotevřel a trasa ke zdroji funguje (zapisuje služba). Soubor jde ve výpisu dolů s „⚠ nejde spustit“ na
    `LINK_FAIL_TTL_S`. Vrací True = zapsáno. Selhání zápisu = False (R2: jen pořadí, nic dalšího na tom nestojí)."""
    if not ident:
        return False
    now = time.time() if now is None else float(now)
    try:
        import richmovie_atomic as _atomic
        from richmovie_paths import LOCK_STALE_S
        with _atomic.FileLock(_path() + ".lock", stale_s=LOCK_STALE_S):
            data = _load()
            idents = _prune(dict(data.get("idents") or {}), now)
            idents[str(ident)] = evaluate_link_failed(idents.get(str(ident)), now)
            ok = bool(_atomic.write_json(_path(), {"schema": SCHEMA, "idents": idents}))
        _log("SOURCE_LINK_FAILED ident=%s code=%s → ve výpisu dolů na %d h saved=%s"
             % (ident, code or "-", LINK_FAIL_TTL_S // 3600, ok), _LOGWARNING)
        return ok
    except Exception as exc:
        _log("SOURCE_LINK_FAILED failed: %r" % (exc,), _LOGWARNING)
        return False


def _note(ident: str, position: float, duration: float, now: Optional[float], tag: str,
          at_start: bool = False) -> Optional[float]:
    if not ident:
        return None
    now = time.time() if now is None else float(now)
    try:
        import richmovie_atomic as _atomic
        from richmovie_paths import LOCK_STALE_S
        # jediný zapisovatel je služba, zámek hlídá souběh vláken téhož procesu i čtení pluginem
        with _atomic.FileLock(_path() + ".lock", stale_s=LOCK_STALE_S):
            data = _load()
            idents = _prune(dict(data.get("idents") or {}), now)
            rec = evaluate(idents.get(ident), position, duration, now, at_start=at_start)
            idents[ident] = rec
            ok = bool(_atomic.write_json(_path(), {"schema": SCHEMA, "idents": idents}))
        # zaseknutý START od nuly → výsledek jen ze startů; zaseknuté NAVÁZÁNÍ (pozice > 0) i konec souboru → jen ze shluku konců
        is_start = bool(at_start) and float(position or 0) == 0.0
        at = (0.0 if rec.get("start_broken") else None) if is_start else rec.get("broken_at")
        _log("%s ident=%s pos=%s repeats=%d broken_at=%s saved=%s" % (
            tag, ident, format_time(position), len(rec["start_stalls"] if is_start else rec["eofs"]),
            format_time(at) if at is not None else "-", ok),
            _LOGWARNING if at is not None else _LOGINFO)
        return at if ok else None
    except Exception as exc:
        _log("%s failed: %r" % (tag, exc), _LOGWARNING)
        return None


def note_started(ident: str, now: Optional[float] = None) -> bool:
    """Obraz naskočil → záznamy ZASEKNUTÉHO STARTU a ODMÍTNUTÉHO ODKAZU (4.5.3) tohoto souboru pryč (audit Fable 12.11.2026
    V2: soubor, který se dvakrát pomalu rozjel a potřetí hraje, nesmí dál svítit „⚠ nejde spustit“). Konce souboru zůstávají.
    Zapisuje jen když je co mazat (služba volá na každý `onAVStarted`). Vrací True = smazáno."""
    if not ident:
        return False
    now = time.time() if now is None else float(now)
    try:
        data = _load()
        rec = (data.get("idents") or {}).get(str(ident))
        if not isinstance(rec, dict) or not (rec.get("start_stalls") or rec.get("link_fails")):
            return False
        import richmovie_atomic as _atomic
        from richmovie_paths import LOCK_STALE_S
        with _atomic.FileLock(_path() + ".lock", stale_s=LOCK_STALE_S):
            data = _load()
            idents = _prune(dict(data.get("idents") or {}), now)
            rec = idents.get(str(ident))
            if not isinstance(rec, dict) or not (rec.get("start_stalls") or rec.get("link_fails")):
                return False
            # 4.5.3: obraz naskočil = odkaz funguje → i záznam odmítnutého / neotevřeného odkazu pryč
            rec = dict(rec, start_stalls=[], start_broken=False, link_fails=[])
            idents[str(ident)] = rec
            ok = bool(_atomic.write_json(_path(), {"schema": SCHEMA, "idents": idents}))
        _log("SOURCE_STARTED ident=%s → zaseknuté starty smazány saved=%s" % (ident, ok), _LOGINFO)
        return ok
    except Exception as exc:
        _log("SOURCE_STARTED failed: %r" % (exc,), _LOGWARNING)
        return False


def broken_map(now: Optional[float] = None) -> Dict[str, float]:
    """{ident: broken_at} všech živých vadných souborů (plugin: pořadí a popisek výpisu)."""
    now = time.time() if now is None else float(now)
    try:
        data = _load()
    except Exception:
        return {}
    out: Dict[str, float] = {}
    for ident in (data.get("idents") or {}):
        at = broken_at_in(data, ident, now)
        if at is not None:
            out[ident] = at
    return out


LABEL_PREFIX_START = "[COLOR FFE06060]⚠ nejde spustit[/COLOR] "   # vadný od začátku (4.5.1) — „od 0:00“ by nic neřeklo


def label_prefix(ident: str, broken: Dict[str, float]) -> str:
    at = broken.get(str(ident or ""))
    if at is None:
        return ""
    return LABEL_PREFIX_START if at <= 0 else (LABEL_PREFIX % format_time(at))
