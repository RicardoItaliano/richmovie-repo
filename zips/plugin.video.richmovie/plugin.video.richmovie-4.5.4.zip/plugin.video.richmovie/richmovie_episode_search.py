# -*- coding: utf-8 -*-
"""
richmovie_episode_search — SSOT hledání streamů DÍLU seriálu (kontext filtru + kaskáda vln + záchrana).

Proč (výzkum 29.09.2026, nálezy E1-F01 a E3-F03): hledání dílu existovalo DVAKRÁT — `plugin._tv_play_run`
(ruční výpis, co divák vidí) a `plugin._search_episode` (předstažení dalšího dílu ve službě: ~89 % výpisů
dílů a VŠECHNY autoplaye). Docstring druhé kopie sliboval „totožnou kaskádu“, kopie se ale rozešly:
předstažení nepředávalo varianty názvu seriálu, slova názvu dílu, rok premiéry seriálu ani zákaz jiného
dílu, erotiku banovalo bezpodmínečně a nemělo alternativní názvy. Důsledek: autoplay vybíral z JINÉ množiny,
než jakou divák vidí ve výpisu (liší se 750 z 2 117 přijetí), a u seriálů s krátkým názvem („The OA“)
předstažení nenašlo nic → žádný autoplay a ruční hledání 110 s.

Pravda je ruční cesta (`_tv_play_run`, ověřená replayem nad produkčními logy) — tenhle modul je její
přesun 1 : 1 na jedno místo; obě cesty ho volají.

Modul nesmí importovat `plugin` (knihovna). Python 3.8 (Kodi).
"""
from __future__ import annotations

import datetime
import re
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from richmovie_engine import (
    Release,
    SearchCancelled,
    norm as _norm,
    score_sort_key as _score_sort_key,
    search_sources_text as _search_sources_text,
    spin_tokens,
)
from tmdb_client import TMDb

import richmovie_core_path  # noqa: F401
from rm_core.cascade import (  # noqa: F401  (rozhodnutí kaskády jsou SSOT v rm_core, G1)
    RESCUE_MIN_BYTES,
    RESCUE_NEAR_WORDS,
    RESCUE_NO_EPCODE_RE,
    THRESH_W2,
    THRESH_W3,
    THRESH_WX,
    EpisodeCascade,
    episode_empty_is_authoritative as empty_is_authoritative,
    episode_result_cacheable as result_cacheable,   # jádro 1.2.2 (F28 V5): smí výsledek do cache dílu
    episode_wave_plan as wave_plan,
    rescue_near_enough,
    rescue_queries,
)
from rm_core.context import (  # noqa: F401
    _yr,
    EpisodeBase,
    EpisodeSearchContext,
    air_date,
    build_episode_context,
    episode_key,
    label_for,
    load_episode_base,
    note_episode_tmdb_failure as _note_tmdb_failure,
    search_key,
)

# Φ-C (30.09.2026, E1-F08/F09/F10): předstažení a výpis se nepředhánějí
PREFETCH_CLAIM_TTL_S = 180.0     # claim = signál živosti; prodlužuje se po každé vlně (nejdelší vlna flotily < 100 s)
PREFETCH_WAIT_MAX_S = 180.0      # výpis čeká na běžící předstažení nejdéle tak dlouho, pak hledá sám
PREFETCH_WAIT_STEP_S = 0.25
EMPTY_MEMO_TTL_S = 6 * 3600      # D5 (Richie 29.09.2026): prázdné předstažení pamatovat do konce běhu Kodi, nejdéle 6 h
PHASE_WAIT_PREFETCH = "Dokončuji hledání dílu z pozadí…"

PHASE_MORE = "Hledám i pod dalšími názvy…"
PHASE_RESCUE = "Zkouším ještě číselné značení dílu…"

LogFn = Callable[..., None]












def episode_numbers(args: Dict[str, Sequence[str]]) -> Tuple[int, int]:
    """(řada, díl) z parametrů URL ve tvaru `parse_qs`: výpis epizod posílá `ep_no`, starší odkazy `episode`.
    JEDINÉ čtení pro `plugin._tv_play` (klíč měření) i `_tv_play_run` (hledání). Nečíselná hodnota = (0, 0)."""
    def _first(name: str) -> str:
        vals = args.get(name) or [""]
        return str(vals[0] or "").strip()
    try:
        return int(_first("season") or 0), int(_first("ep_no") or _first("episode") or 0)
    except ValueError:
        return 0, 0


def prefetch_claim_name(tv_id: Any, season_no: Any, ep_no: Any) -> str:
    """Jméno claimu „tenhle díl se právě hledá na pozadí“ (`richmovie_guard`, sdílí služba i plugin)."""
    return "episode_search:" + episode_key(tv_id, season_no, ep_no)




class EmptyMemo(object):
    """Paměť „předstažení tohoto dílu nic nenašlo“. Jen v RAM procesu (služba žije po dobu běhu Kodi),
    platnost `EMPTY_MEMO_TTL_S`. Ruční otevření dílu ji NEČTE — divák hledá vždy."""

    def __init__(self, ttl_s: float = EMPTY_MEMO_TTL_S, clock: Callable[[], float] = None) -> None:
        import time as _time
        self._ttl = float(ttl_s)
        import threading as _threading
        self._clock = clock or _time.monotonic
        self._seen: Dict[str, float] = {}
        self._lock = _threading.Lock()      # předstažení běží ve vláknech služby

    def remember(self, key: str) -> None:
        with self._lock:
            self._seen[str(key)] = self._clock()
        publish_empty(str(key), True)

    def is_fresh(self, key: str) -> bool:
        with self._lock:
            ts = self._seen.get(str(key))
            if ts is None:
                return False
            if (self._clock() - ts) > self._ttl:
                self._seen.pop(str(key), None)
                return False
            return True

    def forget(self, key: str) -> None:
        with self._lock:
            self._seen.pop(str(key), None)
        publish_empty(str(key), False)


# 4.5.3 (B3-02, audit flotily A4-03/A2): seznam dílů ukáže „zatím bez streamu“ u dílu, jehož předstažení AUTORITATIVNĚ nic
# nenašlo (jen to, co si pamatuje `EMPTY_MEMO`, tatáž platnost). Plugin běží v jiném procesu než služba → stav jde přes
# vlastnost okna Kodi (žije do konce běhu Kodi = stejně jako paměť služby; nic na disk). Jen NÁPOVĚDA: díl se nikdy
# neskrývá ani nepřeskakuje, klik hledá vždy (pravidlo „neubrat streamy“).
EMPTY_PROP = "richmovie.episodes.empty"
EMPTY_PROP_MAX = 200


def _parse_empty(raw: Any, now: float) -> Dict[str, float]:
    import json as _json
    try:
        data = _json.loads(raw) if raw else {}
    except (TypeError, ValueError):
        return {}
    out: Dict[str, float] = {}
    if isinstance(data, dict):
        for k, v in data.items():
            try:
                ts = float(v)
            except (TypeError, ValueError):
                continue
            if 0 <= now - ts <= EMPTY_MEMO_TTL_S:
                out[str(k)] = ts
    return out


def publish_empty(key: str, empty: bool, now: Optional[float] = None) -> None:
    """Zapsat / smazat díl v `EMPTY_PROP` (služba). Best-effort, nikdy nevyhazuje."""
    import json as _json
    import time as _time
    try:
        import richmovie_winprops as _wp
        now = _time.time() if now is None else float(now)
        cur = _parse_empty(_wp.get_prop(EMPTY_PROP, ""), now)
        if empty:
            cur[str(key)] = now
        else:
            cur.pop(str(key), None)
        if len(cur) > EMPTY_PROP_MAX:
            cur = dict(sorted(cur.items(), key=lambda kv: kv[1])[-EMPTY_PROP_MAX:])
        _wp.set_prop(EMPTY_PROP, _json.dumps(cur, sort_keys=True))
    except Exception:
        pass


def empty_episode_keys(now: Optional[float] = None) -> set:
    """Klíče dílů (`episode_key` — tvar, který píše služba), u kterých předstažení nedávno autoritativně nic nenašlo
    (plugin, seznam dílů)."""
    import time as _time
    try:
        import richmovie_winprops as _wp
        return set(_parse_empty(_wp.get_prop(EMPTY_PROP, ""), _time.time() if now is None else float(now)))
    except Exception:
        return set()


EMPTY_MEMO = EmptyMemo()


def wait_for_running(is_running: Callable[[], bool], read_result: Callable[[], Any],
                     cancelled: Callable[[], bool], wait_abort: Callable[[float], bool],
                     max_s: float = PREFETCH_WAIT_MAX_S, step_s: float = PREFETCH_WAIT_STEP_S,
                     clock: Callable[[], float] = None) -> Tuple[Any, str]:
    """Výpis dílu čeká na hledání téhož dílu, které už běží na pozadí (služba), místo aby spustil druhé
    stejné. Vrací (výsledek | None, důvod): done (předstažení doběhlo a něco uložilo), empty (doběhlo bez
    výsledku → volající hledá sám), timeout, cancelled, abort, idle (nic neběželo)."""
    import time as _time
    now = clock or _time.monotonic
    if not is_running():
        return None, "idle"
    t0 = now()
    while is_running():
        # Výsledek se čte V KAŽDÉM kroku: služba ho zapíše hned po hledání, ale claim drží ještě při výběru
        # streamu pro automatické přehrání (síť) — na to už výpis nečeká (audit Fable F1-V8).
        early = read_result()
        if early:
            return early, "done"
        if cancelled():
            return None, "cancelled"
        if (now() - t0) >= float(max_s):
            return None, "timeout"
        if wait_abort(float(step_s)):
            return None, "abort"
    res = read_result()
    return (res, "done") if res else (None, "empty")


def load_base(tv_id: str, tv_name: str, season_no: int, ep_no: int, ep_title: str = "",
              tmdb_key: str = "") -> EpisodeBase:
    """Detail seriálu a dílu z TMDb — SSOT `rm_core.context.load_episode_base` nad `tmdb_client.TMDb`."""
    return load_episode_base(tv_id, tv_name, season_no, ep_no, ep_title, tmdb_key,
                             tmdb_factory=lambda lang: TMDb(tmdb_key, lang=lang))


def build_context(base: EpisodeBase, log_event: Optional[LogFn] = None) -> EpisodeSearchContext:
    """Dotazy a parametry filtru pro díl — SSOT `rm_core.context.build_episode_context`."""
    return build_episode_context(base, tmdb_factory=lambda lang: TMDb(base.tmdb_key, lang=lang),
                                 spin_tokens_fn=spin_tokens, log_event=log_event)


def rescue_numeric(engine: Any, tv_name: str, season_no: int, ep_no: int, *, title_norms: Sequence[str],
                   ser_title_variants: Sequence[Sequence[str]] = (), banned_keys: Sequence[str] = (),
                   stats: Optional[Dict[str, Any]] = None,
                   homonym_variants: Sequence[Sequence[str]] = ()) -> List[Release]:
    """Záchrana pro staré seriály s názvy jako „Esmeralda 01.avi“ — jen když kaskáda nenašla NIC. Pravidla a dotazy
    jsou SSOT `rm_core.cascade`, tady je vykonání přes engine. `stats["errors"]` = počet dotazů záchrany, které selhaly.

      – soubor s běžným kódem dílu (SxxEyy / 1xYY / E##) se tu nebere (ten by našla kaskáda),
      – číslo dílu musí být do 3 slov za názvem seriálu, soubor ≥ 120 MB (klipy pryč).
    """
    qs = rescue_queries(tv_name, ep_no)
    if not qs:
        return []
    tv_words = [_norm(w) for w in (tv_name or "").strip().split() if _norm(w)]

    def _note(event: str, *params: Any) -> None:
        # log hledání (R-B): záchrana nesmí zahazovat kandidáty ani chyby beze stopy
        try:
            engine._log(event, *params)
        except Exception:
            pass

    out: Dict[str, Release] = {}
    for q in qs:
        try:
            found = engine.search_one(
                q,
                title_norms=title_norms,
                ser_title_variants=ser_title_variants,
                banned_keys=banned_keys,
                bad_regex=RESCUE_NO_EPCODE_RE,
                progress_cb=None,
                probe=False,
                ban_other_episodes=True,   # Φ5B: jiný díl (dřív součást 20k banned_keys)
                stats=stats,
                homonym_variants=homonym_variants,   # jádro 1.2.2 F2
            )
        except Exception as exc:
            found = []
            if stats is not None:
                stats["errors"] = int(stats.get("errors", 0) or 0) + 1
            _note("RESCUE_QUERY_ERR", q, repr(exc)[:200])

        for r in found:
            n = _norm(r.name)
            if not rescue_near_enough(n, tv_words, ep_no):
                _note("RESCUE_DROP", r.ident, "number_not_near_title", r.name)
                continue
            try:
                if (r.size or 0) < RESCUE_MIN_BYTES:
                    _note("RESCUE_DROP", r.ident, "too_small", r.name)
                    continue
            except Exception as exc:
                _note("RESCUE_SIZE_ERR", r.ident, repr(exc)[:200])
            out.setdefault(str(r.ident), r)

    res = list(out.values())
    try:
        res.sort(key=lambda x: (_score_sort_key(getattr(x, "score", None)), -(getattr(x, "size", 0) or 0)))
    except Exception:
        pass
    return res


def run_cascade(engine: Any, ctx: EpisodeSearchContext, *, ctx_name: str, log_event: LogFn,
                progress: Any = None, top_full_probe: int = 0,
                on_wave_end: Optional[Callable[[], None]] = None,
                kick_mi2: bool = True) -> Tuple[List[Release], Dict[str, Any]]:
    """Kaskáda vln + záchrana číslem. Vrací (streamy, info): info = {waves, cancelled, errors, rescue}.
    Rozhodnutí vln drží automat `rm_core.cascade.EpisodeCascade`, tady je vykonání přes `SearchEngine`.

    `errors` > 0 znamená, že některý dotaz selhal (síť) → prázdný výsledek NENÍ autoritativní (R2).
    `progress` = dialog hledání (nebo None); Zrušit ukončí kaskádu před další vlnou."""
    b = ctx.base
    machine = EpisodeCascade(ctx)
    bucket = machine.bucket
    info = machine.info
    if info["ctx_errors"]:
        log_event("EP_CTX_DEGRADED", label_for(b), info["ctx_errors"])
    fetch_memo: Dict[str, Any] = {}     # Φ-C: tentýž dotaz se v jednom hledání stahuje jen jednou (WX+ bez sítě)
    label = f"{b.tv_name} S{b.season_no:02d}E{b.ep_no:02d}"

    def _cancelled() -> bool:
        try:
            return progress is not None and bool(progress.iscanceled())
        except Exception:
            return False

    while True:
        wave = machine.next_wave(cancelled=_cancelled())
        if wave is None:
            break
        wave_tag, qs, ep_soft = wave.tag, wave.queries, wave.ep_soft
        if progress is not None:
            try:
                progress.set_phase((_search_sources_text() + "…") if wave_tag == "W1" else PHASE_MORE)
            except Exception:
                pass
        bucket_before = len(bucket)
        log_event("WAVE_BEGIN", {
            "ctx": ctx_name, "tv_id": b.tv_id, "season": b.season_no, "episode": b.ep_no,
            "wave": wave_tag, "qs_total": len(qs), "qs_preview": qs[:12],
            "ep_soft": bool(ep_soft), "bucket_before": bucket_before,
        })
        stats: Dict[str, Any] = {}
        try:
            found = engine.search_wave(
                qs,
                title_norms=ctx.title_norms,
                ser_title_variants=ctx.ser_title_variants,
                banned_keys=ctx.banned_keys,
                ep_title_variants=ctx.ep_title_variants,
                allowed_years=list(ctx.allowed_years),
                progress_cb=progress,
                top_full_probe=top_full_probe,
                max_quick_probe=0,
                ep_soft=ep_soft,
                ban_other_episodes=True,
                stats=stats,
                fetch_memo=fetch_memo,
                kick_mi2=kick_mi2,
                homonym_variants=getattr(ctx, "homonym_variants", None) or (),   # jádro 1.2.2 F2
            )
        except SearchCancelled:
            info["cancelled"] = True
            break
        except Exception as e:
            log_event("WAVE_ERR", {
                "ctx": ctx_name, "tv_id": b.tv_id, "season": b.season_no, "episode": b.ep_no,
                "wave": wave_tag, "err": str(e),
            })
            raise
        found_count = len(found)
        machine.wave_done(wave, found, stats)
        log_event("WAVE_END", {
            "ctx": ctx_name, "tv_id": b.tv_id, "season": b.season_no, "episode": b.ep_no,
            "wave": wave_tag, "found": found_count,
            "bucket_after": len(bucket), "added": len(bucket) - bucket_before,
        })
        if on_wave_end is not None:
            try:
                on_wave_end()
            except Exception:
                pass

    if _cancelled():
        info["cancelled"] = True
    rels = list(bucket.values())
    if info["cancelled"] or rels:
        return rels, info

    if progress is not None:
        try:
            progress.set_phase(PHASE_RESCUE)
        except Exception:
            pass
    rescue_stats: Dict[str, Any] = {}
    try:
        rescue = rescue_numeric(
            engine, b.tv_name, b.season_no, b.ep_no,
            title_norms=ctx.title_norms, ser_title_variants=ctx.ser_title_variants,
            banned_keys=ctx.banned_keys, stats=rescue_stats,
            homonym_variants=getattr(ctx, "homonym_variants", None) or (),
        )
        info["errors"] += int(rescue_stats.get("errors") or 0)
        if rescue:
            log_event("RESCUE_NUMERIC_OK", label, len(rescue))
            for r in rescue:
                try:
                    r.wave = "RESCUE"
                except Exception:
                    pass
            rels = rescue
            info["rescue"] = len(rescue)
        else:
            log_event("RESCUE_NUMERIC_EMPTY", label)
            info["rescue"] = 0
    except Exception as _e:
        log_event("RESCUE_NUMERIC_ERR", str(_e))
        info["rescue"] = -1
        info["errors"] += 1
    return rels, info
