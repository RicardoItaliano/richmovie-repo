# -*- coding: utf-8 -*-
"""
richmovie_playback_end.py — SSOT klasifikace KONCE přehrávání (3.5.119)
=======================================================================

Proč modul existuje (incident Zelňačka 23.08.2026):
    Webshare CDN uzel přestal posílat data → Kodi curl timeout → CFileCache
    `EndOfInput()` → VideoPlayer skončil „přirozeně" → `onPlayBackEnded`.
    Addon měl v tu chvíli DVĚ nezávislá místa, která `onPlayBackEnded` brala
    jako „dokoukáno":
      • service_nextup._save_cw_position(completed=True)  → cw_remove + ✔ watched
      • richmovie_player_hook._finalize(natural_end=True) → drop_point_s=None
    Film označený jako dokoukaný při 40 % a watch event s „přirozeným koncem".
    Navíc každé místo mělo vlastní práh (0.93 vs 0.95).

Kontrakt:
    `onPlayBackEnded` z Kodi NENÍ důkaz dokoukání. Důkaz je POZICE vůči délce.
    Tohle je jediné místo, kde se o tom rozhoduje — service i hook se ptají sem.

Modul je záměrně bez závislosti na Kodi (čistá funkce), aby byl testovatelný
v offline harnessu `_tools/net_resilience_sim` (scénář 26).

Implementace čistých funkcí je od G1 v `resources/lib/rm_core/playback_end.py` (sdílí ji Gate); tady zůstává
`classify_end_shared` (Window properties) a `player_ctx_key` (kontext přehrávače v Kodi).
"""

from __future__ import annotations

import richmovie_core_path  # noqa: F401

from rm_core.playback_end import (  # noqa: F401
    COMPLETION_THRESHOLD,
    EndKind,
    MIN_DURATION_S,
    TAIL_MAX_S,
    TAIL_MIN_RATIO,
    TAIL_MIN_S,
    classify_end,
    completion_ratio,
    ctx_key,
    is_completed,
    is_completed_position,
)

VERDICT_PROP = "RichMovie.PlayerCtx.end_verdict"   # sdílený verdikt: "kind|key|epoch"
VERDICT_FRESH_S = 20.0


def classify_end_shared(key, **kwargs):
    # type: (str, ...) -> EndKind
    """SSOT verdiktu napříč oběma Player subclassy (cross-check T3 Pro P2): kdo klasifikuje
    první, zveřejní verdikt do Window property; druhý (jiný checkpoint, jiný lag) ho pro
    stejný `key` (tmdb:s:e) a čerstvost ≤ VERDICT_FRESH_S převezme místo vlastního výpočtu.
    Bez klíče nebo mimo Kodi = obyčejný `classify_end`."""
    try:
        import richmovie_winprops as _wp
        import time as _time
        raw = _wp.get_prop(VERDICT_PROP, "") if key else ""
        if raw:
            parts = raw.split("|")
            if len(parts) == 3 and parts[1] == key:
                try:
                    if _time.time() - float(parts[2]) <= VERDICT_FRESH_S:
                        return EndKind(parts[0])
                except (TypeError, ValueError):
                    pass
        kind = classify_end(**kwargs)
        if key:
            _wp.set_prop(VERDICT_PROP, "%s|%s|%.3f" % (kind.value, key, _time.time()))
        return kind
    except Exception:
        return classify_end(**kwargs)


def player_ctx_key():
    # type: () -> str
    """Klíč aktuálního titulu z PlayerCtx props (`plugin._play`): 'tv:id:s:e' / 'movie:id:0:0' / ''.
    Stejný formát jako klíče stavu (`richmovie_state_sync`), jedna funkce (Fable P3-5)."""
    try:
        import richmovie_player_hook as _ph
        return ctx_key(_ph._read_player_context())
    except Exception:
        return ""
