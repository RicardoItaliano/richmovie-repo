# -*- coding: utf-8 -*-
"""Diagnostika přibalených knihoven (requests, urllib3, certifi, idna, chardet) — jednou za běh Kodi, NA POZADÍ.

Proč samostatný modul (4.5.1, 12.11.2026): do 4.5.0 běžela kontrola při IMPORTU `plugin.py` (i synchronní HTTPS GET
`/health` přes `requests`). Služba importuje plugin při startu Kodi, takže kontrola zdržela start služby — a s ním
i autostart RichMovie a výběr profilu: Chromecast medián 3,3 s, p90 4,5 s, max 9 s (PC 0,6 s; user_logs 30 dní,
`[Vendor] === Vendor Health Check` → `Health Check DONE`). Richie 12.11.: „na chromecastu se spustí kodi a nějakou dobu trvá,
než se spustí richmovie a zobrazí výběr profilů. Na PC je to rychle.“

Teď: volá ji jen pracovník warm-upu služby po `BOOT_GRACE_S` (`richmovie_warm.start_worker`), mimo cestu diváka. Síťový
dotaz vypuštěn — TLS a dostupnost Gate hlídají skutečné požadavky přes `richmovie_http` (zrušitelné při vypnutí Kodi, S23;
spojení mimo `richmovie_http` je zakázané). Zůstává to, co nic jiného neukáže: odkud se knihovny načetly (přibalené vs.
systémové), jejich verze a verze OpenSSL. Bez Kodi = nic (harness).
"""
from __future__ import annotations

import importlib
import sys
from pathlib import Path
from typing import Callable, List, Optional, Tuple

PROP_DONE = "RichMovie.VendorHealth"            # Window(10000): v tomto běhu Kodi už proběhlo
LIBS = ("requests", "urllib3", "certifi", "idna", "chardet")
VENDOR_DIR = Path(__file__).resolve().parent / "resources" / "lib" / "vendor"


def describe(libs: Tuple[str, ...] = LIBS, vendor_dir: Path = VENDOR_DIR,
             importer: Callable[[str], object] = importlib.import_module) -> List[str]:
    """Čistá (bez Kodi): řádky diagnostiky — u každé knihovny VENDOR_OK / SYSTEM_FALLBACK / IMPORT FAILED, verze, cesta;
    na konci OpenSSL. Nikdy nevyhodí."""
    out = ["VENDOR_DIR: %s (exists=%s)" % (vendor_dir, vendor_dir.exists()),
           "sys.path[0]: %s" % (sys.path[0] if sys.path else "(empty)")]
    vendor_lower = str(vendor_dir).lower().replace("\\", "/")
    for name in libs:
        try:
            mod = importer(name)
        except Exception as exc:
            out.append("IMPORT FAILED | %s | %s" % (name, exc))
            continue
        path = str(getattr(mod, "__file__", "?") or "?")
        marker = "VENDOR_OK" if vendor_lower in path.lower().replace("\\", "/") else "SYSTEM_FALLBACK"
        out.append("%s | %s %s | %s" % (marker, name, getattr(mod, "__version__", "?"), path))
    try:
        import ssl as _ssl
        out.append("OpenSSL: %s" % _ssl.OPENSSL_VERSION)
    except Exception as exc:
        out.append("SSL check failed: %s" % exc)
    # Balík certifikátů pro `requests` (stahování) BEZ sítě — za vypuštěný TLS dotaz (audit Fable 12.11. P1): chybějící
    # nebo prázdný soubor certifi by se jinak ukázal až chybou stahování u diváka.
    try:
        certifi = importer("certifi")
        where = str(certifi.where())
        size = Path(where).stat().st_size if Path(where).is_file() else 0
        out.append("%s | certifi bundle %s (%d B)" % ("CA_OK" if size > 0 else "CA_MISSING", where, size))
    except Exception as exc:
        out.append("CA_MISSING | certifi bundle: %s" % exc)
    return out


def run_once(log: Callable[[str], None], *, get_prop: Optional[Callable[[str], str]] = None,
             set_prop: Optional[Callable[[str, str], None]] = None, addon_version: str = "?") -> bool:
    """Jednou za běh Kodi (Window prop `PROP_DONE`): zapíše diagnostiku do logu. Vrací True = proběhla teď."""
    try:
        if get_prop is not None and get_prop(PROP_DONE) == "1":
            return False
        if set_prop is not None:
            set_prop(PROP_DONE, "1")
        log("[Vendor] === Vendor Health Check (%s) ===" % addon_version)
        for line in describe():
            log("[Vendor] " + line)
        log("[Vendor] === Health Check DONE ===")
        return True
    except Exception as exc:   # diagnostika nikdy nesmí shodit pracovníka služby
        try:
            log("[Vendor] Health Check failed: %r" % (exc,))
        except Exception:
            pass
        return False
