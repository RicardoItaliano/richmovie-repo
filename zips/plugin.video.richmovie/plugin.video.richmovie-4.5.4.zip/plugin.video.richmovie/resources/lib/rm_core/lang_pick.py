# -*- coding: utf-8 -*-
"""rm_core.lang_pick — SSOT výběru zvukové a titulkové stopy (přesun 1 : 1 z `richmovie_localization`, G1).
Čisté funkce nad seznamy stop z přehrávače (Kodi JSON-RPC; TV pošle stejný tvar); žádná závislost na Kodi."""
from __future__ import annotations


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _norm_lang  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _norm_lang(val: str) -> str:
    """
    Normalizace jazykového kódu/labelu na zkrácený kód:
    cs (cze/ces/cz/čeština/czech), en (eng/english/anglicky), sk (slk/slo/slovak),
    pl (pol/polish/polski/polština) …
    """
    s = (val or "").strip().lower()
    if not s:
        return ""
    # základní synonymní slova (CZ/EN/SK/PL)
    s = (s.replace("čeština", "czech")
           .replace("angličtina", "english")
           .replace("anglicky", "english")
           .replace("slovenčina", "slovak")
           .replace("polština", "polish")
           .replace("polsky", "polish"))

    # mapování na 2písmenné kódy
    if s in {"cs","cze","ces","cz","czech"}:   return "cs"
    if s in {"en","eng","english"}:           return "en"
    if s in {"sk","slk","slo","slovak"}:      return "sk"
    if s in {"pl","pol","polish","polski"}:   return "pl"
    # poslední pokus – když je to delší název, vezmeme první 2 znaky
    return s[:2]


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _stream_index  (vytvořeno: 09.10.2026 21:00 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _stream_index(st: dict):
    """Index stopy z JSON-RPC (`Player.GetProperties`) jako int; nečíselný se vrací beze změny (fallback
    `Player.SetSubtitle` podle jména si s ním poradí)."""
    try:
        return int(st.get("index"))
    except Exception:
        return st.get("index")


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _is_forced_sub  (vytvořeno: 09.10.2026 21:00 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _is_forced_sub(st: dict) -> bool:
    """JEDNA definice „vynucená titulková stopa“ (jen nápisy / cizojazyčné pasáže, ne dialogy): příznak Kodi
    `isforced` (JSON-RPC, Kodi 20+), nebo název u releasů bez příznaku — „Forced“, „Only forced“,
    „Czech [ForcedNarrative]“, „vynucené“. Název je záměr (releasy bez příznaku; cross-check Pro P7 zamítnut).
    Položka, která není slovník, vynucená není (zpevnění dle cross-checku Flash F8)."""
    if not isinstance(st, dict):
        return False
    name = str(st.get("name") or "").lower()
    return bool(st.get("isforced")) or "forced" in name or "vynucen" in name


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _sub_matches_lang  (vytvořeno: 09.10.2026 21:00 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _sub_matches_lang(st: dict, want: str) -> bool:
    """Je titulková stopa v jazyce `want` (kód z `_norm_lang`)? Jazyk stopy, jinak název; u češtiny i název
    stopy („… Czech“, „čeština“) — sémantika beze změny proti původnímu `_pick_sub_index.by_lang`."""
    if not want or not isinstance(st, dict):
        return False
    lang = _norm_lang(str(st.get("language") or st.get("name") or ""))
    name = str(st.get("name") or "").lower()
    return lang == want or (want == "cs" and (" czech" in name or "češtin" in name))


#: Vynucené nápisy v „sousedním“ jazyce, když v jazyce zvuku žádné nejsou (cross-check Pro P10, 09.10.2026): čeština
#: a slovenština jsou vzájemně srozumitelné. Jazyk zvuku má VŽDY přednost (= volba Kodi); soused jen zaplní mezeru,
#: kdy by Kodi nezapnulo nic — proti kladné volbě Kodi se tím nikdy nepřepíná.
_FORCED_SUB_LANGS = {"cs": ("cs", "sk"), "sk": ("sk", "cs")}


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _find_forced_sub  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague; jazyk zvuku 09.10.2026 21:00 CEST)
# ---------------------------------------------------------------------------- #
def _find_forced_sub(subtitles: list, audio_lang: str, current: dict | None = None) -> int | None:
    """Index vynucené titulkové stopy V JAZYCE ZVUKU, jinak None (= titulky vypnout).

    Zrcadlo pravidla Kodi (`PredicateSubtitlePriority`, Kodi 21.2 `VideoPlayer.cpp:265–268`): při vypnutých
    titulcích / `locale.subtitlelanguage = forced_only` má přednost vynucená stopa v jazyce zvuku. Priming
    (`desired_kodi_settings`) nastaví Kodi přesně tak, worker proto musí chtít totéž — jinak přepíná proti volbě
    Kodi (přepnutí za běhu = zbytečná práce přehrávače).

    4.0.1 (Sony BRAVIA 09.10.2026 20:16:48): dřív se brala PRVNÍ vynucená stopa bez ohledu na jazyk → u českého
    dabingu „Hry na oliheň“ worker přepnul Kodi z „Czech [ForcedNarrative]“ na anglické „Forced“. Jiný jazyk než
    zvuk se nevybírá (anglické nápisy k českému dabingu nedávají smysl — plán D7); výjimkou je jen vzájemně
    srozumitelný soused (`_FORCED_SUB_LANGS`: cs ↔ sk) jako DRUHÁ volba, když v jazyce zvuku vynucená stopa není.

    `current` (Player.GetProperties: `currentsubtitle`, `subtitleenabled`) — audit Fable F-5: když Kodi už UKAZUJE
    vynucenou stopu ve vybraném jazyce, vrátí se ta (Kodi má vlastní prioritu — externí stopa, příznak default);
    worker by jinak při dvou vhodných stopách přepnul na první v seznamu.
    """
    want = _norm_lang(audio_lang or "")
    if not want:
        return None
    candidates = [st for st in (subtitles or []) if _is_forced_sub(st)]
    cur_idx = None
    if isinstance(current, dict) and current.get("subtitleenabled"):
        cur = current.get("currentsubtitle")
        if isinstance(cur, dict):
            cur_idx = _stream_index(cur)
    for lang in _FORCED_SUB_LANGS.get(want, (want,)):
        in_lang = [st for st in candidates if _sub_matches_lang(st, lang)]
        if not in_lang:
            continue
        if cur_idx is not None and any(_stream_index(st) == cur_idx for st in in_lang):
            return cur_idx
        return _stream_index(in_lang[0])
    return None


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _pick_sub_index  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague; plné stopy 09.10.2026 21:00 CEST)
# ---------------------------------------------------------------------------- #
def _pick_sub_index(subtitles: list, prefer: str, *, fallback_chain: list[str]) -> int | None:
    """
    Vybere index PLNÉ titulkové stopy (dialogy) s danou preferencí a fallbackem.
    • prefer == "cs" → řetězce např. ["cs", "sk", "en"]
    • prefer == "en" → řetězce např. ["en", "cs", "sk"]

    4.0.1 (plán D8): PLNÁ stopa v jazycích diváka má přednost před vynucenou — u releasů, kde „Czech forced“ leží
    před plnými českými, by divák originálu neměl titulky k dialogům. Pořadí: plná v řetězci jazyků → vynucená
    v řetězci jazyků (cross-check Pro P9: ripy, kde jediná česká stopa je — často chybně — označená „forced“; dřív
    se vybrala, „nic“ by byl regres) → první plná v jiném jazyce → None (volbu nechat Kodi, nic nepřepínat).
    """
    if not isinstance(subtitles, list) or not subtitles:
        return None
    full = [st for st in subtitles if isinstance(st, dict) and not _is_forced_sub(st)]
    forced = [st for st in subtitles if _is_forced_sub(st)]
    for group in (full, forced):
        for code in fallback_chain or []:
            for st in group:
                if _sub_matches_lang(st, code):
                    return _stream_index(st)
    # nouzový fallback: první PLNÁ stopa v jiném jazyce (vynucená v cizím jazyce by divákovi nepomohla)
    if full:
        return _stream_index(full[0])
    return None


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _pick_audio_index  (vytvořeno: 24.01.2026 20:00 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _pick_audio_index(audiostreams: list, audio_pref: str, orig_lang: str | None) -> int | None:
    """
    Vrátí index audio stopy dle preference.
    • audio_pref == "cz_dub": zkus cs → jinak necháme originál/EN (řeší se v _apply_…).
    • audio_pref == "original": zkus orig_lang (TMDb) → jinak EN → jinak první dostupnou.
    """
    if not isinstance(audiostreams, list) or not audiostreams:
        return None

    def by_lang(want: str) -> int | None:
        if not want:
            return None
        for st in audiostreams:
            try:
                idx = int(st.get("index"))
            except Exception:
                idx = st.get("index")
            lang = _norm_lang(st.get("language") or st.get("name") or "")
            name = (st.get("name") or "").lower()
            # přímá shoda kódu
            if lang == want:
                return idx
            # heuristiky podle jména stopy
            if want == "cs" and (" czech" in name or "češtin" in name):
                return idx
            if want == "en" and (" eng" in name or "english" in name or "angl" in name):
                return idx
        return None

    if audio_pref == "cz_dub":
        i = by_lang("cs")
        if i is not None:
            return i
        # když není CZ, nech konečný výběr na _apply_… (zohlední titulky)
        return None

    # original
    i = by_lang(_norm_lang(orig_lang or ""))
    if i is None:
        i = by_lang("en")
    if i is not None:
        return i

    # fallback: první dostupná
    try:
        return int(audiostreams[0].get("index"))
    except Exception:
        return audiostreams[0].get("index")


# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_localization.py
# _current_audio_lang  (vytvořeno: 09.10.2026 21:00 CEST, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _current_audio_lang(current: dict) -> str:
    """Jazyk právě hrající zvukové stopy (`currentaudiostream` z `Player.GetProperties`) — pro vynucené titulky,
    když worker zvuk sám nepřepíná (Kodi porovnává s jazykem hrající stopy)."""
    if not isinstance(current, dict):
        return ""
    cur = current.get("currentaudiostream") or {}
    if not isinstance(cur, dict):
        return ""
    return _norm_lang(str(cur.get("language") or cur.get("name") or ""))


def plan_switches(current: dict, *, audio_idx=None, sub_idx=None) -> dict:
    """Čistá: co se má opravdu přepnout. `current` = Player.GetProperties
    (currentaudiostream, currentsubtitle, subtitleenabled). Přepnutí = flush dekodéru,
    takže se dělá JEN když stopa nesedí (Chromecast 26.09.2026). Zapnutí titulků nese `sub_idx` samo
    (`"off"` = vypnout, index = zapnout tuto stopu) — S13 (10.10.2026): zrušen nepoužitý parametr `sub_enable`."""
    out = {"audio": False, "subs": False}
    if audio_idx is not None:
        try:
            cur_a = int((current.get("currentaudiostream") or {}).get("index"))
        except Exception:
            cur_a = None
        out["audio"] = cur_a != int(audio_idx)
    if sub_idx is not None:
        cur_on = bool(current.get("subtitleenabled"))
        if sub_idx == "off":
            out["subs"] = cur_on
        else:
            try:
                cur_s = int((current.get("currentsubtitle") or {}).get("index"))
            except Exception:
                cur_s = None
            out["subs"] = (not cur_on) or cur_s != int(sub_idx)
    return out
