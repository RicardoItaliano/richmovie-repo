# -*- coding: utf-8 -*-
"""rm_core.filter_tv — filtr dílu seriálu (`filter_tv_items`), kontext filtru a penalizace názvu.

Přesun 1 : 1 z `SearchEngine._tv_filter` (G1). `log` = per-search log (formát FILTER_* beze změny, vstup replay
harnessu), síť a probe jsou injektované (`probe_many`). Čistá standardní knihovna.
"""
from __future__ import annotations

import json
import re
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from rm_core.model import KIND_TV, ReleaseFilter, Release
from rm_core.source_grade import grade_of
from rm_core.title_match import acronym_hit, glued_acronym, is_acronym, title_numerals
from rm_core.text import (
    FILTER_PROGRESS_EVERY,
    GENERIC_EP,
    PROBE_MAX_RESULTS,
    YEAR_RE,
    _BAD_REGEX_DEFAULT,
    bad_word_in_title,
    _FRANCHISE_FILM_RE,
    _alpha_word_count,
    _phrase_contains,
    canon_ep_codes,
    norm,
    other_episode_code_hit,
    sanitize_ban_tokens,
    video_ext_of,
)

LogFn = Callable[..., Any]
ProbeManyFn = Callable[[List[Release], Optional[Callable[[int, int, str], None]]], None]

# ---------------------------------- SSOT ------------------------------------ #
# richmovie_engine.py
# Kontext filtru dílu + penalizace názvu (Φ-A 30.09.2026, plán PLAN_search_efficiency_20260929, E3-F04)
# ---------------------------------------------------------------------------- #
# Dřív se tytéž odvozeniny (STOP, kódy, varianty názvu seriálu, „jednoslovný seriál“) počítaly dvakrát:
# v `search_one` a znovu — bez výjimky HΦ5 — ve větvi CACHE_HIT `search_wave`. Druhá kopie vracela
# správnému souboru s cizojazyčným názvem penaltu, kterou mu první odpustila. Jedno místo = jedna pravda.
_TV_STOP = frozenset({
    # CZ
    "v", "ve", "s", "z", "na", "do", "u", "o", "a", "i", "se",
    # EN
    "the", "of", "in", "on", "and", "to", "for", "at", "by",
    # FR/ES drobky
    "de", "le", "la", "du",
})
_TV_SE_RE = re.compile(r"^(?:s0?\d{1,2}\s*e0?\d{1,2}|0?\d{1,2}\s*x\s*0?\d{1,2}|e\d{2,3})$", re.I)
# prefix = část před ep-kódem (SxxEyy / 1x01). Tam chceme být u jednoslovných seriálů nejpřísnější.
_TV_CODE_POS_RE = re.compile(
    r"\b(?:s0?\d{1,2}\s*e0?\d{1,2}|0?\d{1,2}\s*x\s*0?\d{1,2}|0?\d{1,2}x0?\d{1,2})\b",
    re.I,
)
# Obecné "bezpečné" tokeny, které často patří do technického suffixu releasu.
_TV_META_OK = frozenset({
    # rozlišení / formát
    "2160p", "1080p", "720p", "576p", "480p", "360p", "320p", "240p",
    "4k", "uhd", "fhd", "hd", "sd",
    # zdroj / typ
    "bluray", "bdrip", "brrip", "bd", "bdremux", "remux", "bdmv",
    "web", "webrip", "webdl", "web-dl", "hdrip", "dvdrip", "dvd", "hdtv", "ts",
    # kodeky
    "x264", "x265", "h264", "h265", "hevc", "avc", "av1", "10bit", "8bit",
    # audio (tokeny po norm: dts hd ma / ddp / eac3 / truehd / atmos)
    "aac", "ac3", "dd", "ddp", "eac3", "dts", "truehd", "atmos", "flac", "mp3",
    "hdma", "ma",
    # edice
    "proper", "repack", "rerip", "internal", "complete", "uncut", "extended", "limited", "remastered",
    "directors", "director", "cut", "dc",
    # jazyky / subs
    "cz", "cze", "czech", "sk", "svk", "slovak", "en", "eng", "pl", "hun", "de", "ger", "ita", "fre", "spa",
    "multi", "dual", "dub", "dubbed", "dab", "dabing",
    "sub", "subs", "subtitles", "titulky",
})


class TvFilterContext(object):
    """Odvozeniny vstupů filtru dílu — počítají se JEDNOU na vlnu (`tv_filter_context`)."""

    __slots__ = ("codes", "words", "short_only", "ep_title_variants", "epi_all", "ser_variants",
                 "ser_tokens", "ep_sets", "target_canon", "generic_ep", "tmdb_title_tokens",
                 "one_word_set", "homonym_keys")


#: Veřejný název stop slov názvu seriálu (jádro 1.2.2: `context.homonym_variants` porovnává názvy stejně jako filtr).
TV_TITLE_STOP = _TV_STOP

#: F3 (jádro 1.2.2): token názvu seriálu, který u GENERICKÉHO názvu dílu („Episode 3“) dokládá seriál — aspoň tolik znaků
#: a ne číslo. Kratší slova („all“, „are“, „you“, „one“) mívá v názvu kdekdo („We Are All Trying Here“ × „All of Us Are
#: Dead“, incident 16.11.2026).
SER_STRONG_TOKEN_MIN = 4

#: Důvod nejistoty přijatého dílu (`Release.uncertain_reason`, jádro 1.2.2 — audit Fable F28 V1 / V2 / V4). Automat
#: doplňku nejistý díl pustí jen s potvrzením kontinuitou (`richmovie_continuity.confirms_uncertain`), výpis ho ukáže vždy.
UNCERTAIN_HOMONYM = "homonym"          # celý název seriálu jen přes variantu, kterou nese i jiný seriál TMDb (F2)
UNCERTAIN_WEAK_SERIES = "weak_series"  # generický název dílu („Episode 3“) a jen menšina slov názvu seriálu (V2)
UNCERTAIN_NO_MATCH = "no_match"        # žádné pravidlo A–D, přijato záložní cestou (velikost + přípona)
UNCERTAIN_REASONS = (UNCERTAIN_HOMONYM, UNCERTAIN_WEAK_SERIES, UNCERTAIN_NO_MATCH)

#: Samostatné „E##“ bez řady = kód dílu, který `canon_ep_codes` nezná. Záložní cesta (`other_code_e_only`) i pravidlo D.
E_ONLY_RE = re.compile(r"(?<![a-z0-9])e0?\d{1,2}(?![a-z0-9])", re.I)

# Pravidlo D (soubor bez kódu dílu, celý název seriálu i dílu) NEPLATÍ, když zbytek jména (bez fráze názvu dílu) nese značku
# jiného dílu / části / celé řady — audit Fable F28 V3: „Black Mirror E02 The National Anthem“, „… 102 …“, „Part 2“ dvojdílu,
# „complete S1 …“ (balík řady). Neplatné D = soubor zůstane nejistý (nic se nezamítá). Vstup = `norm()` jména.
# Řada / balík / nosič: „S1“, „complete“, „komplet…“, „pack“, slovo řady / nosiče JEN s číslem („1 serie“, „rada 2“, „disc 2“,
# „vol 1“) — samotné „Web Series“ / „Original Series“ značkou řady není (cross-check Flash 16.11. Q3).
_D_SEASON_WORD = r"(?:seasons?|series|serie|seria|sezona|sezon|rada)"
_D_ORDINAL_WORD = (r"(?:one|two|three|four|five|six|seven|eight|nine|ten|first|second|third|fourth|fifth"
                   r"|prvni|druha|treti|ctvrta|pata)")
D_PACK_RE = re.compile(
    r"(?<![a-z0-9])(?:s\d{1,2}"
    r"|(?:" + _D_SEASON_WORD + r"|disc|disk|dvd|vol|volume)\s?\d{1,2}"
    r"|\d{1,2}\s?" + _D_SEASON_WORD
    + r"|" + _D_SEASON_WORD + r"\s" + _D_ORDINAL_WORD + r"|" + _D_ORDINAL_WORD + r"\s" + _D_SEASON_WORD
    + r"|komplet\w*|complete|pack)(?![a-z0-9])")
# Číslo s jednotkou za ním není číslo dílu ani části (zvuk „640 kbps“, „720 p“, „350 MB“, cross-check Flash 16.11. Q3) —
# JEDNA definice pro `D_NUM3_RE` i `D_NUM_ANY_RE`
_D_NOT_UNIT = r"(?!\s?(?:kbps|kbit|kb|k|mbps|mb|gb|fps|hz|bit|p|i)(?![a-z0-9]))"
# Samostatné číslo zbytku jména (jen když název dílu SÁM nese číslo části — dvojdíl „… (1)“; audit Fable F29 V2) a zvukové
# kanály, které se za číslo nepočítají („5.1“, „DD5.1“, „AAC2.0“ → po `norm()` „5 1“, „dd5 1“, „aac2 0“).
D_NUM_ANY_RE = re.compile(r"(?<![a-z0-9])(?<![hx] )(\d{1,3})(?![a-z0-9])" + _D_NOT_UNIT)
D_AUDIO_CH_RE = re.compile(r"(?<![a-z0-9])[a-z]*[2-7]\s[01](?![a-z0-9])")
D_PART_RE = re.compile(r"(?<![a-z0-9])(?:part|pt|cast|dil|ep|epizoda|episode|chapter|kapitola)\s?(\d{1,4}|[ivx]{1,5})"
                       r"(?![a-z0-9])")
D_PART_PRE_RE = re.compile(r"(?<![a-z0-9])(\d{1,3})\s(?:dil|cast|ep|epizoda)(?![a-z0-9])")
# „102“ (číslo dílu) — ne kodek („h 265“ / „x 265“) ani číslo s jednotkou
D_NUM3_RE = re.compile(r"(?<![a-z0-9])(?<![hx] )[1-9]\d{2}(?![a-z0-9])" + _D_NOT_UNIT)

_ROMAN_VALUES = {r: i for i, r in enumerate(
    ("i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii", "xiii", "xiv", "xv",
     "xvi", "xvii", "xviii", "xix", "xx"), start=1)}


def _num_value(tok: str) -> Optional[int]:
    """Číslo části: arabské („2“, „02“) nebo římské do XX; jinak None."""
    t = str(tok or "").strip().lower()
    if t.isdigit():
        return int(t)
    return _ROMAN_VALUES.get(t)


def d_extra_episode_marker(rest: str, ep_numbers: Any) -> bool:
    """Nese zbytek jména (bez fráze názvu dílu, `norm()`) značku JINÉHO dílu, části nebo celé řady? Číslo části, které je
    i v názvu dílu (`ep_numbers`, „The Best of Both Worlds (1)“ → {1}), značkou jiného dílu není. Čistá funkce (pravidlo D)."""
    text = " %s " % (rest or "")
    if E_ONLY_RE.search(text) or D_PACK_RE.search(text) or D_NUM3_RE.search(text):
        return True
    allowed = set(ep_numbers or ())
    for rx in (D_PART_RE, D_PART_PRE_RE):
        for m in rx.finditer(text):
            if _num_value(m.group(1)) not in allowed:
                return True
    if allowed:
        # název dílu nese číslo části („The Best of Both Worlds (1)“) → každé jiné samostatné číslo ve zbytku je číslo JINÉ
        # části („… Both Worlds 2.avi“, „… (2).avi“); zvukové kanály se nepočítají
        bare = D_AUDIO_CH_RE.sub(" ", text)
        if any(_num_value(m.group(1)) not in allowed for m in D_NUM_ANY_RE.finditer(bare)):
            return True
    return False


def _variant_majority(variant: Sequence[str], tok_hit: Callable[[str], bool]) -> bool:
    """Sedí VĚTŠINA slov jedné varianty názvu seriálu (audit Fable F28 V2)? Bez čísel; jednoslovná varianta = to slovo
    o ≥ `SER_STRONG_TOKEN_MIN` znacích, víceslovná = aspoň 2 zásahy a ≥ 2/3 slov („All of Us Are Dead“ 4/4 ano, „We Are All
    Trying Here“ 2/4 ne, „The Walking Dead“ 1/4 ne). Varianty už jsou bez stop slov a slov názvu dílu (`tv_filter_context`)."""
    toks = [w for w in (variant or ()) if w and not w.replace(" ", "").isdigit()]
    if not toks:
        return False
    hits = sum(1 for w in toks if tok_hit(w))
    if len(toks) == 1:
        return hits == 1 and len(toks[0]) >= SER_STRONG_TOKEN_MIN
    return hits >= 2 and 3 * hits >= 2 * len(toks)


def tv_filter_context(
    title_norms: Sequence[str],
    ser_title_variants: Sequence[Sequence[str]] = (),
    ep_title_variants: Sequence[Sequence[str]] = (),
    homonym_variants: Sequence[Sequence[str]] = (),
) -> TvFilterContext:
    """Čistá funkce: z tokenů titulu, variant názvu seriálu a variant názvu dílu odvodí vše, co filtr dílu
    a penalizace názvu potřebují. Logika 1 : 1 z `search_one` (3.5.169), jen na jednom místě."""
    fc = TvFilterContext()
    tokens = [t for t in (title_norms or ()) if t and t not in _TV_STOP]
    codes = [t for t in tokens if _TV_SE_RE.fullmatch(t)]
    words = [t for t in tokens if t not in codes]

    # Heuristika „krátký seriálový token“
    short_only = (not ep_title_variants) and (len(words) == 1 and len(words[0]) <= 3)
    if not ep_title_variants:
        ep_title_variants = [] if short_only else [words[-2:] if len(words) >= 2 else words]

    epi_all = {w for v in ep_title_variants for w in v}

    # 26.12.2025 – OR přes varianty názvu seriálu:
    #   • ser_title_variants je seznam variant, každá varianta je seznam tokenů
    #   • ser_full = True, pokud sedí *alespoň jedna* varianta (tj. tokeny jedné varianty všechny)
    ser_variants: List[List[str]] = []
    if ser_title_variants:
        try:
            for v in ser_title_variants:
                if not v:
                    continue
                vv = [t for t in v if t and t not in _TV_STOP]
                vv = [t for t in vv if t not in epi_all]  # pojistka: ep slova nesmí být seriálové tokeny
                # pojistka proti šumu: 1 krátký token (<=3) ignoruj
                if len(vv) == 1 and len(vv[0]) <= 3:
                    continue
                if vv:
                    ser_variants.append(vv)
        except Exception:
            ser_variants = []

    # Fallback: původní chování (ser_tokens jako „sloučené“ seriálové tokeny)
    ser_tokens = [w for w in words if w not in epi_all]
    if ser_variants:
        # union tokenů pro logging + numerické signatury + fallback heuristiky
        ser_tokens = sorted({t for v in ser_variants for t in v})

    ep_sets = [set(v) for v in ep_title_variants if v]
    # HΦ3: kanonické cílové kódy (SSOT) — sjednotí padding varianty s cílem
    target_canon = canon_ep_codes(" ".join(codes)) if codes else set()

    # „globální“ příznak – dříve používaný (ponechán pro logging/kompat.)
    generic_ep = (bool(ep_sets) and all((w in GENERIC_EP or w.isdigit()) for v in ep_sets for w in v))

    # SANITIZE (TMDb title tokeny) – používáme:
    #   • pro odfiltrování banned_keys (ban token nikdy nesmí zabanovat token z TMDb názvu)
    #   • pro title_penalty (TMDb tokeny nikdy nesmí být “bad”)
    try:
        if ser_variants:
            tmdb_title_tokens = {t for v in ser_variants for t in v if t}
        else:
            tmdb_title_tokens = {t for t in ser_tokens if t}
    except Exception:
        tmdb_title_tokens = set()

    # SPEC: jednoslovné seriály (Lost, You, Dark…) – penalizace "balastu" v title-bloku.
    #   • title_penalty jen pokud je seriál skutečně “one-word” (primary varianta po STOP/epi filtraci)
    is_one_word_series = False
    try:
        if ser_variants:
            _primary = ser_variants[0]
            if len(_primary) == 1:
                is_one_word_series = True
            elif len(_primary) == 2 and _primary[0] and _primary[1].isdigit() and len(_primary[1]) == 4:
                # např. "lost 2004" → core token stále jednoslovný
                is_one_word_series = True
        else:
            if len(ser_tokens) == 1 and ser_tokens[0]:
                is_one_word_series = True
    except Exception:
        is_one_word_series = False

    one_word_set: set = set()
    if is_one_word_series:
        one_word_tokens: List[str] = []
        try:
            if ser_variants:
                _seen_ow: set = set()
                for v in ser_variants:
                    if not v:
                        continue
                    if len(v) == 1:
                        t0 = v[0]
                        if t0 and t0 not in _seen_ow:
                            one_word_tokens.append(t0)
                            _seen_ow.add(t0)
                        continue
                    if len(v) == 2 and v[0] and v[1].isdigit() and len(v[1]) == 4:
                        t0 = v[0]
                        if t0 and t0 not in _seen_ow:
                            one_word_tokens.append(t0)
                            _seen_ow.add(t0)
                        continue
            if (not one_word_tokens) and (len(ser_tokens) == 1) and ser_tokens[0]:
                one_word_tokens = [ser_tokens[0]]
        except Exception:
            one_word_tokens = []
        one_word_set = {t for t in one_word_tokens if t}

    # F2 (jádro 1.2.2, `Handoff/PLAN_autoplay_jiny_porad_20261116.md`): varianty názvu seriálu, které nese i JINÝ seriál
    # TMDb (stejnojmenný — slovenské „Mesto tieňov“ má česky „Město stínů“ jako španělské „Ciudad de sombras“). Stejná
    # úprava jako `ser_variants` (stop slova, slova názvu dílu), aby šly porovnat.
    homonym_keys: set = set()
    for hv in (homonym_variants or ()):
        hvv = tuple(t for t in (hv or ()) if t and t not in _TV_STOP and t not in epi_all)
        if hvv:
            homonym_keys.add(hvv)

    fc.codes = codes
    fc.words = words
    fc.short_only = short_only
    fc.ep_title_variants = ep_title_variants
    fc.epi_all = epi_all
    fc.ser_variants = ser_variants
    fc.ser_tokens = ser_tokens
    fc.ep_sets = ep_sets
    fc.target_canon = target_canon
    fc.generic_ep = generic_ep
    fc.tmdb_title_tokens = tmdb_title_tokens
    fc.one_word_set = one_word_set
    fc.homonym_keys = homonym_keys
    return fc


def tv_title_penalty(name: str, fc: TvFilterContext) -> Tuple[int, List[Tuple[str, str]]]:
    """Penalizace názvu u jednoslovných seriálů (jen ŘAZENÍ, nikdy filtr). Vrací (penalta, události do logu
    jako dvojice (událost, JSON)). Čistá funkce — volá ji hlavní cesta filtru i větev CACHE_HIT.

    Výjimka HΦ5 (07.07.2026): soubor s PŘESNÝM kódem cíle A epizodní frází (≥ 2 slova) penaltu nedostane
    (cizojazyčný alt-titul jako prefix „Priatelia Friends S04E06…“ je správný soubor, ne balast)."""
    events: List[Tuple[str, str]] = []
    if not (fc.one_word_set and fc.codes):
        return 0, events
    n = norm(name)
    m = _TV_CODE_POS_RE.search(n)
    if not m:
        return 0, events

    penalty = 0
    bad: List[str] = []
    prefix = n[:m.start()].strip()
    ptoks = [t for t in prefix.split() if t]

    # "významové" tokeny v title-bloku (ignorujeme stopwords a roky)
    meaningful = [
        t for t in ptoks
        if (t not in _TV_STOP) and not (t.isdigit() and len(t) == 4)
    ]

    _rcanon = canon_ep_codes(n)
    _code_exact = bool(_rcanon and fc.target_canon and (_rcanon & fc.target_canon))
    _ep_phr = [" ".join([t for t in v if t]).strip() for v in fc.ep_title_variants if v]
    _ep_phr = [p for p in _ep_phr if len(p.split()) >= 2]
    _waived = bool(_code_exact and _ep_phr and any(_phrase_contains(n, p) for p in _ep_phr))

    if _waived:
        events.append(("TITLE_PENALTY_WAIVED",
                       json.dumps({"reason": "code+ep_phrase", "prefix": prefix}, ensure_ascii=False)))
        return 0, events

    # 1) musí se objevit seriálový token (lost / ztraceni / …) – jinak je to podezřelé
    series_pos = [i for i, t in enumerate(meaningful) if t in fc.one_word_set]
    if not series_pos:
        penalty += 3
    else:
        # seriálový token má být první významový token v prefixu (jinak to často znamená "The Lost Symbol" apod.)
        if series_pos[0] != 0:
            penalty += 2

    # 2) cizí slova v prefixu (kromě ep-title tokenů, generik, TMDb title tokenů a technických meta tokenů)
    allowed = set(fc.one_word_set) | set(fc.epi_all) | set(fc.tmdb_title_tokens) | GENERIC_EP | _TV_META_OK
    for t in meaningful:
        if t in allowed:
            continue
        if t.isdigit():
            continue
        if len(t) <= 1:
            continue
        bad.append(t)
    if bad:
        penalty += min(6, len(bad))

    if penalty:
        events.append(("TITLE_PENALTY", json.dumps(
            {
                "penalty": penalty,
                "one_word_tokens": sorted(list(fc.one_word_set)),
                "prefix": prefix,
                "meaningful": meaningful,
                "bad": bad[:12],
            },
            ensure_ascii=False,
        )))
    return penalty, events


def filter_tv_items(  # noqa: C901
    ws_items: List[dict],
    *,
    label: str,
    log: LogFn,
    runtimes: Sequence[int] = (),
    title_norms: Sequence[str] = (),
    ser_title_variants: Sequence[Sequence[str]] = (),
    banned_keys: Sequence[str] = (),
    ep_title_variants: Sequence[Sequence[str]] = (),
    movie_year: Optional[int] = None,
    allowed_years: Optional[Sequence[int]] = None,
    bad_regex: Any = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    probe: bool = False,
    ep_soft: bool = False,
    ban_other_episodes: bool = False,
    scope: bool = False,
    banned_re_cache: Optional[Dict[Any, Any]] = None,
    probe_many: Optional[ProbeManyFn] = None,
    homonym_variants: Sequence[Sequence[str]] = (),
) -> List[Release]:
    """ReleaseFilter pro díl seriálu nad syrovými položkami. Rozhodnutí je ČISTĚ po položkách —
    dotaz (`label`) jde jen do logu; proto smí vlna filtrovat sjednocení položek všech dotazů jednou.
    `scope=True` (volá vlna) zapíše `FILTER_SCOPE`, aby řádky FILTER_* nesly označení vlny stejně,
    jako dřív nesly dotaz (formát per-search logu pro replay zůstává). Přesun 1 : 1 z `SearchEngine._tv_filter`
    (G1); `banned_re_cache` a `probe_many` dodává volající, síť v rm_core není."""
    if banned_re_cache is None:
        banned_re_cache = {}
    bad_regex = bad_regex or _BAD_REGEX_DEFAULT
    query = label
    if scope:
        log("FILTER_SCOPE", label)

    if not ws_items:
        return []

    fc = tv_filter_context(title_norms, ser_title_variants, ep_title_variants, homonym_variants)
    codes = fc.codes
    words = fc.words
    short_only = fc.short_only
    ep_title_variants = fc.ep_title_variants
    ser_variants = fc.ser_variants
    ser_tokens = fc.ser_tokens
    ep_sets = fc.ep_sets
    # Φ-B (E3-F05): doslovný kód s hranicí proti ČÍSLICÍM — bez ní cíl S01E01 („1x01“) chytil „11x01“,
    # „21x01“ (jiný díl u seriálů s ≥ 10 řadami prošel pravidlem A). Hybrid „S08x06“ řeší kanonický regex.
    # Φ-E (audit Fable F1-V1): hranice NESMÍ být proti písmenům — kód slepený s textem („1x01CZ“,
    # „1x01v2“, „Pratele1x01“) je tentýž díl a před Φ-B prošel (pravidlo „nikdy méně streamů“).
    code_re = (re.compile(r"(?<![0-9])(?:%s)(?![0-9])" % "|".join(map(re.escape, codes)), re.I)
               if codes else None)
    target_canon = fc.target_canon
    generic_ep = fc.generic_ep
    tmdb_title_tokens = fc.tmdb_title_tokens

    # Efektivní banned_keys (bez TMDb title tokenů)
    banned_keys_eff: List[str] = []
    try:
        if banned_keys:
            for k in banned_keys:
                nk = norm(str(k))
                if nk and (nk not in tmdb_title_tokens):
                    banned_keys_eff.append(nk)
    except Exception:
        banned_keys_eff = list(banned_keys) if banned_keys else []
    # HΦ-D (2026-07-07, analýza H4): SSOT hygiena u POINTU POUŽITÍ — odstraní
    # jednoslovné bany typu „ii"/„the"/„la"/„of" (řady seriálů / stopwords),
    # co odstřelovaly správné díly (Černé zrcadlo II). Víceslovné sibling
    # fráze (HΦ-B veto) projdou. Pokrývá VŠECHNY zdroje banů (spin_tokens i
    # kolekce) jedním místem; testovatelné replay harnessem.
    banned_keys_eff = list(sanitize_ban_tokens(banned_keys_eff))

    # 1) blacklist regex (cache) -------------------------------------------
    banned_re: re.Pattern | None = None
    if banned_keys_eff and len(banned_keys_eff) > 300:
        # Cache klíč musí odlišit “stejné banned_keys” pro různé seriály (jiné tmdb tokeny ⇒ jiné sanitizace)
        try:
            _ban_ctx = hash(frozenset(tmdb_title_tokens))
        except Exception:
            _ban_ctx = 0
        key = (id(banned_keys), int(_ban_ctx))
        banned_re = banned_re_cache.get(key)
        if banned_re is None:
            pat = r"(?<![0-9A-Za-z])(?:%s)(?![0-9A-Za-z])" % "|".join(re.escape(k) for k in banned_keys_eff)
            banned_re = re.compile(pat, re.I)
            banned_re_cache[key] = banned_re

    # kontext do logu (informativní)
    try:
        ctx = {
            "query": query,
            "title_norms": list(title_norms),
            "codes": list(codes),
            "ser_tokens": list(ser_tokens),
            "ser_title_variants": [list(v) for v in ser_variants] if ser_variants else [],
            "ep_title_variants": [list(v) for v in ep_title_variants] if ep_title_variants else [],
            "generic_ep": bool(generic_ep),
        }
        log("FILTER_CTX", json.dumps(ctx, ensure_ascii=False))
    except Exception:
        pass

    releases: List[Release] = []
    probe_cand: List[Release] = []
    # Jádro 1.2.0: slova názvů seriálu a dílu pro rozpoznání nahrávky z kina (značka, která je slovem názvu, neplatí)
    _grade_titles = (list(title_norms or ()) + [" ".join(v) for v in (ser_variants or ())]
                     + [" ".join(v) for v in (ep_title_variants or ())])

    # 3) hlavní filtrace ----------------------------------------------------
    _total_items = len(ws_items)
    for _fi, itm in enumerate(ws_items):
        if progress_cb and _fi % FILTER_PROGRESS_EVERY == 0:
            progress_cb(_fi, _total_items, "filter")
        try:
            rel = ReleaseFilter.enrich(itm)
        except Exception as _itm_exc:
            # Filtr běží JEDNOU nad sjednocením → výjimka jedné položky by shodila celou vlnu
            # (dřív jen jeden dotaz). Položka jde do logu, vlna pokračuje (audit Fable F1-V5).
            log("FILTER_REJECT", str(itm.get("ident") or ""), "item_error", str(itm.get("name") or ""),
                      repr(_itm_exc)[:160])
            continue
        if not rel:
            # velikost do detailu: log ji dřív zjišťoval dotazem `file_info` (síť), teď ji nese událost
            log("FILTER_REJECT", itm["ident"], "quick", {"size": itm.get("size", 0)}, itm["name"])
            continue
        rel.source_grade, rel.source_marker = grade_of(rel.name, _grade_titles)
        rel.kind = KIND_TV                        # jádro 1.2.3: díl seriálu — nesedící délka v řazení až za preferencemi

        n = norm(rel.name)
        name_words = set(n.split())

        # NEW 2025-09-10: čísla s/bez počátečních nul ber jako ekvivalent (01 ↔ 1)
        _num_variants = set()
        for _w in list(name_words):
            if _w.isdigit():
                _s = _w.lstrip("0") or "0"  # "01" -> "1", "00" -> "0"
                _num_variants.add(_s)
                # pro jednociferná čísla přidej i variantu s nulou ("1" -> "01")
                if len(_s) == 1:
                    _num_variants.add(_s.zfill(2))
        name_words |= _num_variants

        # 26.12.2025 – FIX: víceslovné tokeny z _norm() ("11.22.63" → "11 22 63") + „silná“ číselná signatura seriálu
        _n_words = n.split()
        _digits_only = re.sub(r"\D+", "", n)

        def _tok_hit(tok: str) -> bool:
            """
            True, pokud `tok` odpovídá názvu releasu.
            Podporuje i víceslovné tokeny (musí sedět jako sousedící sekvence slov),
            a numerickou pojistku ("11 22 63" může být i jako "112263").
            """
            if not tok:
                return False

            # 1) jednoslovný token – původní chování
            if tok in name_words:
                return True

            # 2) víceslovný token – sousedící sekvence slov v normalizovaném `n`
            if " " in tok:
                tok_norm = re.sub(r"\s{2,}", " ", tok).strip()
                if not tok_norm:
                    return False
                tok_parts = tok_norm.split(" ")
                # 15.11.2026 (BACKLOG S58, audit Fable F13 V4): název seriálu jako zkratka z písmen („S.W.A.T.“ → `s w a t`,
                # „M*A*S*H“) sedí i slepený (`SWAT.S01E01`, `MASH 1x01`) a se spojkou — SSOT `title_match.acronym_hit`, ale
                # jen v části PŘED kódem dílu (cross-check 2. kola A1-4B: „Chicago.P.D.S05E12.Swat.Team“ = název dílu jiného
                # seriálu). Jen PŘIDÁVÁ shodu: sousedící sekvence i číselná pojistka níž běží dál (A1-4A: „9-1-1“ × `911s03e05`).
                if is_acronym(tok_parts):
                    _code_at = _TV_CODE_POS_RE.search(n)
                    _before = (n[:_code_at.start()] if _code_at else n).split()
                    if not _before and _code_at:
                        # jméno ZAČÍNÁ kódem dílu („3x05 MASH CZ.avi“, audit Fable F14 V3): název seriálu hned za kódem
                        _before = n[_code_at.end():].split()[:len(tok_parts)]
                    if acronym_hit(tok_parts, _before, set(_before))[0]:
                        return True
                for i in range(len(_n_words) - len(tok_parts) + 1):
                    if _n_words[i:i + len(tok_parts)] == tok_parts:
                        return True

                # 3) numerická pojistka: "11 22 63" může být i jako "112263"
                if tok_parts and all(p.isdigit() for p in tok_parts):
                    compact = "".join(tok_parts)
                    if compact and compact in _digits_only:
                        return True

            return False

        def _is_numeric_signature_token(tok: str) -> bool:
            # „Silný“ číselný token seriálu – povolíme jen >=4 číslice (např. 1899, 112263)
            if not tok:
                return False
            t = tok.replace(" ", "")
            return t.isdigit() and len(t) >= 4

        # HΦ3 (2026-07-07): has_code kanonicky — literal `code_re` míjel
        # padding varianty (s1e01 vs s01e01). ADITIVNÍ (literal NEBO canon):
        # rozpoznává VÍC kódů jako shodných → jen mění rejecty na accepty
        # (recall zisk), nikdy nový reject. `name_canon` použije i other_code
        # a ep_token_miss níž (jeden výpočet per release).
        name_canon = canon_ep_codes(rel.name)
        has_code_lit = bool(code_re.search(n)) if code_re else False
        has_code_canon = bool(target_canon and (name_canon & target_canon))
        has_code = has_code_lit or has_code_canon
        same_code = has_code if code_re else True

        if ser_variants:
            ser_full = any(all(_tok_hit(w) for w in v) for v in ser_variants)
            ser_part = any(any(_tok_hit(w) for w in v) for v in ser_variants)
        else:
            ser_full = all(_tok_hit(w) for w in ser_tokens) if ser_tokens else False
            ser_part = any(_tok_hit(w) for w in ser_tokens) if ser_tokens else False

        ep_full = any(all(w in name_words for w in v) for v in ep_sets)

        # Pokud máme „silnou“ číselnou signaturu seriálu a ta sedí, bereme to jako dostatečné pro Rule A
        # i když chybí aliasové slovo (typicky: "Dallas 63" vs "11.22.63").
        sig_tokens = [t for t in ser_tokens if _is_numeric_signature_token(t)]
        sig_hit = any(_tok_hit(t) for t in sig_tokens) if sig_tokens else False
        ser_full_for_rule_a = ser_full or sig_hit

        # Rozliš, zda se v názvu chytila jen „generická“ ep-sada
        ep_full_generic = any(
            all(w in name_words for w in v) and all((w in GENERIC_EP or w.isdigit()) for w in v)
            for v in ep_sets
        )
        ep_full_nongeneric = any(
            all(w in name_words for w in v) and not all((w in GENERIC_EP or w.isdigit()) for w in v)
            for v in ep_sets
        )

        # Původní A/B/C – jemně zpřesněné C pro generické „Episode N“
        rule_a = same_code and ser_full_for_rule_a and has_code
        rule_b = same_code and ser_part and ep_full
        rule_c = (same_code and ser_part and ep_full and has_code) if generic_ep else (same_code and ep_full and has_code)

        # 26.12.2025 16:35 CET (Europe/Prague) – Guard:
        # Rule C bez ser_part je rizikové (běžná slova z názvu epizody mohou trefit cizí pořad).
        # Pokud v názvu releasu není žádný token seriálu (ser_part=False), vyžaduj celou epizodní FRÁZI (aspoň 2 slova)
        # jako sousedící sekvenci v normalizovaném názvu.
        if rule_c and (not generic_ep) and (not ser_part) and ep_title_variants:
            _n_pad = f" {n} "
            _phrases = [" ".join(v).strip() for v in ep_title_variants if v]
            _phrases = [p for p in _phrases if " " in p]  # jen víceslovné fráze
            if _phrases and not any(f" {p} " in _n_pad for p in _phrases):
                rule_c = False

        # 26.12.2025 15:31 CET (Europe/Prague) – SPEC: jednoslovné názvy (jen krátké)
        # U krátkých jednoslovných názvů (typicky kolizní: "You", "Dark", …) zpřísníme Rule A:
        # token musí být na ZAČÁTKU názvu a okamžitě za ním musí následovat kód SxxEyy nebo xxXyy.
        # U delších jednoslovných názvů (např. "Pluribus") tohle zpřísnění nepoužíváme – zbytečně to
        # shazuje správné releasy typu "Pluribus.2025.S01E02...".
        if len(ser_tokens) == 1 and rule_a and len(ser_tokens[0]) <= 5:
            t = ser_tokens[0]
            # 15.11.2026 (audit Fable F14 V2): krátká zkratka („V.I.P.“, „C.S.I.“, „9-1-1“) i slepeně (`VIP.S01E01`)
            _glued_t = glued_acronym(t.split())
            _t_alt = re.escape(t) + ("|" + re.escape(_glued_t) if _glued_t else "")
            _ADJ_RE = re.compile(
                rf"^(?:{_t_alt})(?:\W+)?(?:s0?\d{{1,2}}\W*e0?\d{{1,2}}|0?\d{{1,2}}\W*x\W*0?\d{{1,2}})\b",
                re.I,
            )
            if not _ADJ_RE.search(n):
                rule_a = False

        # ★ NOVĚ: pokud se chytla jen generická ep-sada (např. „episode 3“),
        #          vyžaduj i ser_part, aby neprocházely cizí seriály.
        weak_series = False
        if ep_full_generic and not ep_full_nongeneric:
            # F3 (jádro 1.2.2, incident 16.11.2026: „Eren the Southpaw S01E03 Episode 3 … All …“ u „All of Us Are Dead“
            # S01E03 — TMDb díl „Episode 3“): generická sada dokládá díl, ne SERIÁL → pravidlo B i C chce token názvu
            # seriálu o ≥ `SER_STRONG_TOKEN_MIN` znacích (ne číslo); „all“ / „are“ z cizího názvu nestačí
            _ser_src = ser_variants or [ser_tokens]
            ser_part_strong = any(_tok_hit(w) for v in _ser_src for w in v
                                  if len(w) >= SER_STRONG_TOKEN_MIN and not w.isdigit())
            # Audit Fable F28 V2: jedno silné slovo nestačí („The Walking Dead S01E03 Episode 3“ má „dead“) — JISTÝ je díl
            # jen s VĚTŠINOU slov jedné varianty (`_variant_majority`). Silné slovo bez většiny = přijat jako NEJISTÝ
            # (`weak_series`): seznam beze změny proti 1.2.1 (recall), automat ho bez potvrzení nepustí
            _ser_major = any(_variant_majority(v, _tok_hit) for v in _ser_src)
            weak_series = bool((rule_b or rule_c) and ser_part_strong and not _ser_major)
            rule_b = rule_b and ser_part_strong and _ser_major
            rule_c = rule_c and ser_part_strong and _ser_major

        # Jádro 1.2.2 (D): soubor BEZ JAKÉHOKOLI kódu dílu, ale s CELÝM názvem seriálu a celou NEgenerickou víceslovnou
        # frází názvu dílu jako sousedící sekvencí („Black Mirror - The National Anthem.avi“) je ten díl — dřív jen
        # „nejistý“; od F1 (automat nejisté nevybere) by se takový díl přestal pouštět sám. Soubor s kódem JINÉHO dílu
        # („Firefly.S01E02.Vlaková loupež“ u S01E01, kde TMDb řadí díly jinak) pravidlo D nikdy — jinak by obešel zákaz
        # jiného dílu v záložní cestě (full_replay 16.11.2026: 16 cizích dílů).
        # Audit Fable F28 V3: zbytek jména (bez fráze názvu dílu) nesmí nést „E##“, číslo části, které není v názvu dílu
        # („The Best of Both Worlds Part 2“ u části 1), samostatné číslo dílu („Black Mirror 102 …“) ani značku celé řady
        # („complete S1 …“) — `d_extra_episode_marker`. Takový soubor zůstane nejistý.
        rule_d = False
        _other_code_d = (other_episode_code_hit(n, target_canon, tmdb_title_tokens)
                         if (ban_other_episodes and target_canon) else None)
        if ((not has_code) and (not name_canon) and (not _other_code_d) and ser_full and ep_full_nongeneric
                and ep_title_variants):
            _n_pad_d = f" {n} "
            _d_phrase = next((" ".join(v) for v in ep_title_variants
                              if len(v) >= 2 and not all((w in GENERIC_EP or w.isdigit()) for w in v)
                              and f" {' '.join(v)} " in _n_pad_d), None)
            if _d_phrase:
                # číslo části v názvu dílu = SSOT `title_match.title_numerals` (arabská kdekoli, římská od 2 znaků a slovem
                # jen jako poslední slovo / za slovem části): „i“ ve „What I Did for Love“ (audit Fable F30 V1) ani „one“
                # v „The One in Vegas (2)“ / „dva“ v „Dva světy (1)“ (F31 V1) číslem části nejsou
                _d_ep_nums = set().union(*(title_numerals(" ".join(v)) for v in ep_title_variants))
                _d_rest = _n_pad_d.replace(f" {_d_phrase} ", " ", 1)
                # název seriálu se do zbytku nepočítá — „SG-1“, „Kobra 11“ nejsou čísla jiné části (F30 V2); nejdelší
                # souvislá varianta pryč (jednou)
                for _sv in sorted(ser_variants or (), key=len, reverse=True):
                    _sp = " %s " % " ".join(_sv)
                    if _sp in _d_rest:
                        _d_rest = _d_rest.replace(_sp, " ", 1)
                        break
                rule_d = not d_extra_episode_marker(_d_rest, _d_ep_nums)

        certain_hit = rule_a or rule_b or rule_c or rule_d
        allow_hit = certain_hit or weak_series
        if short_only and codes:
            allow_hit = False
            certain_hit = False

        # HΦ-B (2026-07-07): SIBLING VETO. Spin-off (Suits LA / Kravaťáci LA)
        # sdílí základní titul + kód → projde přes rule_a a obejde fallback
        # ban check. Víceslovné ban fráze (banned_keys s mezerou = celý
        # sibling titul, viz spin_tokens) proto VETUJÍ i rule match: pokud
        # název nese sibling frázi jako sousedící sekvenci, zamítni „spinoff“.
        # Jednoslovné bany zůstávají fallback-only (stopword riziko „la“).
        # Safe-by-construction: víceslovná fráze matchne jen soubor, co ji
        # nese adjacent = přesně spin-off; správný díl základního seriálu
        # tu frázi nemá (Richie 2026-07-07, „Kravaťáci LA“ v Suits).
        if banned_keys_eff:
            # HΦ-D P2-2 (re-audit): veto bere jen VÍCESLOVNÉ fráze se ≥2
            # ABECEDNÍMI tokeny — numerický artefakt (např. „11 22 63" z
            # tečkovaného titulu po norm()) tak NEzíská veto sílu, i kdyby
            # se dostal do banned_keys. Sibling fráze („suits la") projde.
            _veto_ph = next(
                (k for k in banned_keys_eff
                 if " " in k and _alpha_word_count(k) >= 2
                 and _phrase_contains(n, k)),
                None,
            )
            if _veto_ph:
                log("FILTER_REJECT", rel.ident, "spinoff",
                          json.dumps({"sibling_phrase": _veto_ph}, ensure_ascii=False),
                          rel.name)
                continue

        # Nejistý = žádné pravidlo A–D (záložní cesta, `no_match`) nebo jen slabá shoda názvu seriálu u generického dílu
        # (`weak_series`, V2). Důvod nese `uncertain_reason` (audit Fable F28: automat doplňku ho rozlišuje).
        rel.uncertain = (bool(codes) and (not allow_hit)) or (allow_hit and not certain_hit)
        rel.uncertain_reason = ((UNCERTAIN_WEAK_SERIES if allow_hit else UNCERTAIN_NO_MATCH) if rel.uncertain else "")

        # F2 (jádro 1.2.2, incident 16.11.2026 Mesto tieňov × „Město stínů“ 2025): úplná shoda názvu seriálu JEN přes
        # variantu, kterou nese i jiný seriál TMDb (`homonym_variants`), bez vlastní varianty, číselné signatury, povoleného
        # roku a negenerického názvu dílu = nelze rozhodnout, který seriál to je → `uncertain` (výpis ho ukáže, automat ho
        # nevybere — doplněk `_autoplay_eligible`). Nikdy zamítnutí (recall).
        if allow_hit and fc.homonym_keys and not rel.uncertain and ser_variants:
            _own_full = sig_hit or any(all(_tok_hit(w) for w in v) for v in ser_variants
                                       if tuple(v) not in fc.homonym_keys)
            _hom_years = {int(y) for y in YEAR_RE.findall(rel.name)} & set(allowed_years or ())
            if not _own_full and not ep_full_nongeneric and not _hom_years:
                rel.uncertain = True
                rel.uncertain_reason = UNCERTAIN_HOMONYM
                log("FILTER_HOMONYM", rel.ident,
                    json.dumps({"shared": sorted(" ".join(k) for k in fc.homonym_keys)}, ensure_ascii=False),
                    rel.name)

        # ----------------------- Fallback (jen když A/B/C selžou) --------
        if not allow_hit:
            # 0) bez ser_tokens fallback nedává smysl
            if not ser_tokens:
                log(
                    "FILTER_REJECT", rel.ident, "no_ser_tokens",
                    json.dumps({"ser_tokens": [], "name_words": sorted(name_words)}, ensure_ascii=False),
                    rel.name
                )
                continue

            # 1) blacklist (SANITIZE: používáme jen banned_keys_eff)
            banned_hit = ((banned_re and banned_re.search(n))
                          or (banned_keys_eff and not banned_re and any(f" {bk} " in f" {n} " for bk in banned_keys_eff)))
            # Φ5B: kód jiného dílu = TENTÝŽ zákaz jako dřívější výčet 20k tokenů (viz `other_episode_code_hit`)
            _oe_hit = (other_episode_code_hit(n, target_canon, tmdb_title_tokens)
                       if (ban_other_episodes and target_canon) else None)
            if banned_hit or _oe_hit:
                bk = None
                bk_pos = None
                if banned_re:
                    m = banned_re.search(n)
                    if m:
                        bk, bk_pos = m.group(0), m.start()
                elif banned_keys_eff:
                    for k in banned_keys_eff:
                        if f" {k} " in f" {n} ":
                            bk, bk_pos = k, f" {n} ".find(f" {k} ")
                            break
                # do logu první zásah v textu (jako dřív jeden regex přes všechny tokeny)
                if _oe_hit and (bk is None or _oe_hit[0] < bk_pos):
                    bk = _oe_hit[1]
                log("FILTER_REJECT", rel.ident, "other_part",
                          json.dumps({"ban_hit": bk}, ensure_ascii=False), rel.name)
                continue

            # 1a-franchise) HΦ-D: franšízový film v epizodním hledání.
            # coded-search (target_canon) + bez kódu (fallback) + bracketová
            # anotace „[Movie N]"/„(Film N)" na syrovém názvu = TV film, ne
            # díl. Viz Babylon 5 [Movie 5]/[Movie 3] (analýza po hygieně banů).
            _fr_m = _FRANCHISE_FILM_RE.search(rel.name) if (target_canon and not has_code) else None
            if _fr_m:
                log("FILTER_REJECT", rel.ident, "franchise_movie",
                          json.dumps({"marker": _fr_m.group(0)},
                                     ensure_ascii=False), rel.name)
                continue

            # 1a) 2025-08-19 08:14 CEST – pojistka „jiný díl“ (S01.E01/E## …)
            # HΦ3 (2026-07-07): kanonické porovnání (SSOT) místo string-strip
            # → padding varianta cílového kódu (s1e01) UŽ NENÍ „jiný díl“.
            e_only_hits = [m.group(0).lower() for m in E_ONLY_RE.finditer(n)]   # SSOT i pro pravidlo D (F28 V3)
            if name_canon and target_canon and not (name_canon & target_canon):
                log("FILTER_REJECT", rel.ident, "other_code",
                          json.dumps({"found": sorted(map(list, name_canon)),
                                      "target": sorted(map(list, target_canon))}, ensure_ascii=False),
                          rel.name)
                continue
            if e_only_hits and target_canon and not name_canon:
                log("FILTER_REJECT", rel.ident, "other_code_e_only",
                          json.dumps({"found_e": e_only_hits,
                                      "target": sorted(map(list, target_canon))}, ensure_ascii=False),
                          rel.name)
                continue

            # 2) *words* bez GENERIC_EP → musí být aspoň 2 čisté tokeny
            clean_tokens = [t for t in words if t not in GENERIC_EP]
            if len(clean_tokens) < 2:
                log("FILTER_REJECT", rel.ident, "few_tokens",
                          json.dumps({"clean_tokens": clean_tokens, "len": len(clean_tokens)}, ensure_ascii=False),
                          rel.name)
                continue

            # 3) seriálové tokeny — GENERICKÉ epizody → musí padnout VŠECHNY seriálové tokeny
            if generic_ep:
                ser_needed = len(ser_tokens) if ser_tokens else 1
            else:
                ser_needed = 1 if has_code or len(ser_tokens) < 2 else 2

            # token může být víceslovný ("11 22 63"), proto testujeme přes _tok_hit()
            hit_ser_tokens = [t for t in ser_tokens if _tok_hit(t)]
            if len(hit_ser_tokens) < ser_needed:
                log(
                    "FILTER_REJECT", rel.ident, f"token_ser_miss_{len(hit_ser_tokens)}/{ser_needed}",
                    json.dumps({
                        "ser_tokens": ser_tokens,
                        "hit_ser_tokens": hit_ser_tokens,
                        "name_words": sorted(name_words),
                        "has_code": bool(has_code)
                    }, ensure_ascii=False),
                    rel.name
                )
                continue

            # dlouhé tokeny (≥5) – aspoň jeden musí padnout
            long_tokens = [t for t in ser_tokens if len(t) >= 5]
            if long_tokens and not any(_tok_hit(t) for t in long_tokens):
                log("FILTER_REJECT", rel.ident, "token_ser_long_miss",
                          json.dumps({"long_tokens": long_tokens, "name_words": sorted(name_words)}, ensure_ascii=False),
                          rel.name)
                continue

            # 4) epizodní tokeny – u ne-generických epizod musí padnout ≥1 shoda
            #    SOFT režim (Vlna X): když ep_soft=True, tuhle podmínku přeskočíme.
            if not ep_soft:
                if (not generic_ep) and ep_sets:
                    # Φ-B (E3-F06): stopslovo z názvu dílu („the“) NENÍ shoda názvu dílu — jinak prošel
                    # cizí díl „… The Waldo Moment“ při hledání dílu „The National Anthem“
                    hit_ep_tokens = sorted({w for v in ep_sets for w in v
                                            if w in name_words and w not in _TV_STOP})
                    # HΦ4 (2026-07-07, analýza H1 §6.3 + H5): přesný kód cílové
                    # epizody v názvu je SILNĚJŠÍ důkaz než přítomnost TMDb
                    # názvu epizody. Uploadeři TMDb název epizody do jmen
                    # nedávají → „Ano, - S08E01.mkv“ (správný díl) padal, i
                    # když kód s08e01 přesně sedí. Skip ep_token_miss při
                    # kanonické shodě kódu s cílem. (Jiný kód řeší other_code.)
                    _code_matches_target = bool(name_canon and target_canon
                                                and (name_canon & target_canon))
                    if not hit_ep_tokens and not _code_matches_target:
                        log("FILTER_REJECT", rel.ident, "ep_token_miss",
                                  json.dumps({
                                      "ep_sets": [sorted(list(v)) for v in ep_sets],
                                      "found": hit_ep_tokens,
                                      "name_words": sorted(name_words)
                                  }, ensure_ascii=False),
                                  rel.name)
                        continue

            # 5) globální limit shod — (s kódem stačí 1 „clean“ token)
            min_needed = 1 if has_code else (3 if generic_ep else 2)
            min_needed = min(min_needed, len(clean_tokens))
            hit_tokens = [t for t in clean_tokens if _tok_hit(t)]
            if len(hit_tokens) < min_needed:
                log(
                    "FILTER_REJECT", rel.ident, f"token_miss_{len(hit_tokens)}/{min_needed}",
                    json.dumps({
                        "clean_tokens": clean_tokens,
                        "hit_tokens": hit_tokens,
                        "name_words": sorted(name_words),
                        "generic_ep": bool(generic_ep),
                        "has_code": bool(has_code)
                    }, ensure_ascii=False),
                    rel.name
                )
                continue

            # 6) uncertain → min velikost + přípona videa  (OPRAVENO 2025-08-19)
            if rel.uncertain:
                video_ext_ok = bool(video_ext_of(rel.name))
                if (rel.size_mb is not None and rel.size_mb < 200) or (not video_ext_ok):
                    log("FILTER_REJECT", rel.ident, "uncertain_small_or_ext",
                              json.dumps({"size_mb": rel.size_mb, "video_ext_ok": video_ext_ok}, ensure_ascii=False),
                              rel.name)
                    continue

        # regex / rok / další rychlé filtry (beze změny)
        # jádro 1.2.0 (audit Fable F18 V5): slovo názvu seriálu / dílu („Brain Teaser“, „Clip Show“) není balast — jen
        # u výchozího regexu balastu; vlastní regex volajícího (záchrana bez kódu dílu: zásahy = kódy, které title_norms
        # nesou) rozhoduje beze změny
        if bad_regex.search(rel.name) and not (bad_regex is _BAD_REGEX_DEFAULT
                                               and bad_word_in_title(bad_regex, rel.name, _grade_titles)):
            try:
                log("FILTER_REJECT", rel.ident, "bad_regex",
                          json.dumps({"pattern": bad_regex.pattern}, ensure_ascii=False), rel.name)
            except Exception:
                log("FILTER_REJECT", rel.ident, "bad_regex", rel.name)
            continue

        # Větev `bad_ep` (kód epizody u filmu) tu byla mrtvá — filtr dílu se s `movie_year` nevolá;
        # filmy ji mají ve `_movie_filter`. Odstraněno ve Φ-C (E3, pravidlo T17).

        # 2025-08-19 10:39 CEST (Europe/Prague) – Kontrola roku (set povolených let)
        years_allowed = set(allowed_years or ([] if movie_year is None else [movie_year]))
        if years_allowed:
            yrs = {int(y) for y in YEAR_RE.findall(rel.name)}
            # HΦ3 (2026-07-07, analýza H3): „extra-year kill“ fix — dřív
            # `len(yrs) > 1` zabíjel správný soubor, který kromě cílového roku
            # nesl i rok dabingu/remasteru (Conan 1982 + 1994 + 2000). Nově:
            # reject JEN když ŽÁDNÝ rok v názvu není povolený (disjoint).
            # Soubor s aspoň jedním povoleným rokem projde (cizí roky ignorace).
            if yrs and yrs.isdisjoint(years_allowed):
                payload = {
                    "allowed_years": sorted(years_allowed),
                    "yrs_in_name": sorted(yrs),
                }
                # pro zpětnou kompatibilitu přidáme i movie_year, je-li použit
                if movie_year is not None:
                    payload["movie_year"] = movie_year
                log("FILTER_REJECT", rel.ident, "year_miss",
                          json.dumps(payload, ensure_ascii=False), rel.name)
                continue

        # kandidáti na MediaInfo probe (22.01.2026 – nyní podporuje i Fastshare)
        if probe and rel.est_min is None and len(probe_cand) < PROBE_MAX_RESULTS:
            probe_cand.append(rel)

        releases.append(rel)
        log(
            "FILTER_ACCEPT", rel.ident,
            f"a={int(rule_a)} b={int(rule_b)} c={int(rule_c)} d={int(rule_d)} u={int(rel.uncertain)}"
            + (f" r={rel.uncertain_reason}" if rel.uncertain else ""),
            rel.quality, rel.size_mb, rel.name
        )

    # 4) MediaInfo probe (paralelně) ---------------------------------------
    if probe and probe_cand and probe_many is not None:
        probe_many(probe_cand, progress_cb)

    # 5) seřazení -----------------------------------------------------------
    log("WS_RESULTS", query, len(releases))

    # 5a) SPEC: jednoslovné seriály (Lost, You, Dark…) – penalizace "balastu" v title-bloku
    #     Cíl: už před MI2 poslat releasy typu "Dan Browns The Lost Symbol S01E01" níž,
    #          ale NIC nevyhazovat (jen řazení). SSOT = `tv_title_penalty` (i pro CACHE_HIT).
    for r in releases:
        base_score = ReleaseFilter.compute_score(r)
        penalty = 0
        try:
            penalty, _pen_events = tv_title_penalty(r.name, fc)
            for _ev, _payload in _pen_events:
                log(_ev, r.ident, _payload, r.name)
        except Exception as _e:
            try:
                log("TITLE_PENALTY_ERR", getattr(r, "ident", "?"), str(_e), getattr(r, "name", "?"))
            except Exception:
                pass
            penalty = 0

        try:
            r.title_penalty = int(penalty)
        except Exception:
            pass

        r.score = tuple(base_score) + (int(penalty),)

    releases.sort(key=lambda x: x.score)
    return releases
