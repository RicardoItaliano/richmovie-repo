# -*- coding: utf-8 -*-
"""rm_core.source_grade — rozpoznání nahrávky z kina (CAM-RIP) podle jména souboru (SSOT; jádro 1.2.0, 15.11.2026).

Richie 15.11.2026: „zjistit z logů všechny zkratky a indikace nahrávek z kina (cam ripy) a u streamu toto info musí být
červeně "CAM-RIP" … musíme mít ultra chytrou logiku rozpoznání camripu“. Studie s katalogem značek z 42 018 jmen, pastmi
a měřením: `Temp/camrip_20261115/NAVRH.md` (referenční implementace `tools/camrip_detect.py`, na korpusu 247 jistých CAM,
0 omylem po ruční kontrole; rozhodovací logika převzata beze změny, brána P9 `rm_core_gates.py` nad 79 skutečnými jmény).

Stupně (`Release.source_grade`):
  "cam"    — obraz natočený / snímaný v kině (CAM, CAMRip, HDCAM, TS / TELESYNC / HDTS, TC / TELECINE, KinoRip, PreDVD)
  "cam?"   — pravděpodobně z kina (české „kino“ bez určení, slabá značka bez potvrzení)
  "audio"  — obraz odjinud, ZVUK nahraný v kině („zvuk / dabing z kina“, „CAM audio“, MD s jazykem)
  "audio?" — „kino“ u jména se zdrojem obrazu (WEB, BDRip…)
  "scr"    — předpremiérová kopie (DVDSCR, SCREENER, R5) — NENÍ CAM, obraz je dobrý → bez štítku (D-4)
  ""       — nic
Principy: tokeny po složení diakritiky (NFKD) a malými písmeny, oddělovač = cokoli mimo [a-z0-9]; víceznačné značky (ts, tc,
md, kino) jen v ZÓNĚ ZNAČEK (za rokem / rozlišením / kódem dílu / technickým slovem) a nikdy jako přípona souboru ani jméno
skupiny za posledním „-“; žádná značka se nepočítá, když je slovem hledaného NÁZVU (film „Cam“, „Body Cam“, „TS“).
Jen POŘADÍ a štítek, nikdy filtr. Čistá standardní knihovna, Python 3.8.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Iterable, List, NamedTuple, Optional, Sequence, Set, Tuple

GRADE_CAM, GRADE_CAM_MAYBE = "cam", "cam?"
GRADE_AUDIO, GRADE_AUDIO_MAYBE = "audio", "audio?"
GRADE_SCR, GRADE_NONE = "scr", ""
GRADES = (GRADE_CAM, GRADE_CAM_MAYBE, GRADE_AUDIO, GRADE_AUDIO_MAYBE, GRADE_SCR, GRADE_NONE)

#: Štítek výpisu (D-4: SCREENER bez štítku). Barvy kreslí vrstva výpisu doplňku.
LABELS = {
    GRADE_CAM: "CAM-RIP",
    GRADE_CAM_MAYBE: "CAM-RIP?",
    GRADE_AUDIO: "ZVUK Z KINA",
    GRADE_AUDIO_MAYBE: "ZVUK Z KINA?",
}


class Verdict(NamedTuple):
    grade: str      # "cam" | "audio" | "scr" | ""
    sure: bool      # jistá značka / jen pravděpodobné
    marker: str     # co rozhodlo (log, telemetrie)


NONE = Verdict(GRADE_NONE, False, "")

_VIDEO_EXTS = frozenset({"mkv", "mp4", "avi", "mov", "wmv", "ts", "m2ts", "webm", "m4v", "mpg", "mpeg", "vob", "divx",
                         "flv", "m2v"})
_SPLIT_RE = re.compile(r"[^a-z0-9]+")
_YEAR_RE = re.compile(r"^(19[2-9]\d|20[0-4]\d)$")
_RES_RE = re.compile(r"^(2160|1080|720|576|480|360|240)[pi]$|^[1-9]o8op$|^4k$|^uhd$|^fhd$")
_EPI_RE = re.compile(r"^s\d{1,2}e\d{1,3}$|^\d{1,2}x\d{1,3}$")
_TECH = frozenset({
    "x264", "x265", "h264", "h265", "hevc", "avc", "xvid", "divx", "av1", "10bit", "aac", "ac3", "eac3", "ddp",
    "dts", "mp3", "web", "webrip", "webdl", "bluray", "bdrip", "brrip", "dvdrip", "hdtv", "hdrip", "remux",
    "cz", "cze", "czech", "sk", "en", "eng", "dabing", "dab", "titulky", "tit", "multi", "dual", "dubbed",
    "pldub", "plsubbed", "german", "french", "truefrench", "italian", "ita", "rus", "hun", "latino", "dublado",
    "legendado", "internal", "proper", "readnfo"})
# Zdroj obrazu, který vylučuje „obraz z kina“ (když jméno zároveň mluví o kině, jde o ZVUK z kina).
_VIDEO_SOURCE = frozenset({"web", "webrip", "webdl", "bluray", "blueray", "bdrip", "brrip", "bdremux", "remux", "dvdrip",
                           "hdtv", "dcp", "dcprip", "amzn", "nf", "dsnp", "hmax", "atvp"})
_LANG_CTX = frozenset({"pldub", "pl", "german", "ger", "deu", "de", "italian", "ita", "it", "french", "truefrench",
                       "fre", "fr", "hun", "rus", "ru", "ukr", "cz", "cze", "sk", "spa", "latino", "lat", "tur", "hindi"})
_AUDIO_WORDS = frozenset({"zvuk", "audio", "dabing", "dab", "dub", "dubbing", "dabi", "zvukem"})
_SUB_CTX = frozenset({"sc", "tc", "jp", "jpsc", "jptc", "chs", "cht", "big5", "gb"})   # „[SC_TC]“ = čínské titulky

_CAM_SINGLE = {
    "cam": "cam", "hdcam": "hdcam", "camrip": "camrip", "hdcamrip": "hdcamrip", "hqcam": "hqcam",
    "telesync": "telesync", "hdts": "hdts", "tsrip": "tsrip", "hdtsrip": "hdtsrip", "hqts": "hqts",
    "telecine": "telecine", "hdtc": "hdtc", "tcrip": "tcrip", "hdtcrip": "hdtcrip",
    "kinorip": "kinorip", "predvd": "predvd", "predvdrip": "predvd", "pdvd": "predvd", "pdvdrip": "predvd",
    "camcorder": "cam",
}
_CAM_MULTI: Sequence[Tuple[Tuple[str, ...], str]] = (
    (("hd", "cam", "rip"), "hdcamrip"), (("hd", "ts", "rip"), "hdtsrip"),
    (("hd", "cam"), "hdcam"), (("cam", "rip"), "camrip"), (("hq", "cam"), "hqcam"), (("new", "cam"), "cam"),
    (("hd", "ts"), "hdts"), (("ts", "rip"), "tsrip"), (("hq", "ts"), "hqts"), (("tele", "sync"), "telesync"),
    (("hd", "tc"), "hdtc"), (("tele", "cine"), "telecine"), (("kino", "rip"), "kinorip"),
    (("pre", "dvd"), "predvd"), (("pre", "dvdrip"), "predvd"),
)
_AUDIO_MULTI: Sequence[Tuple[Tuple[str, ...], str]] = (
    (("cam", "audio"), "cam_audio"), (("audio", "cam"), "cam_audio"),
    (("zvuk", "z", "kina"), "z_kina"), (("audio", "z", "kina"), "z_kina"), (("dabing", "z", "kina"), "z_kina"),
    (("dab", "z", "kina"), "z_kina"), (("kino", "zvuk"), "kino_zvuk"), (("audio", "kino"), "kino_zvuk"),
    (("kino", "audio"), "kino_zvuk"), (("mic", "dub"), "md"), (("mic", "dubbed"), "md"),
)
_SCR_SINGLE = {"dvdscr": "dvdscr", "bdscr": "bdscr", "webscr": "webscr", "hdscr": "hdscr", "screener": "screener",
               "scr": "scr", "r5": "r5", "r6": "r6"}
_SCR_MULTI: Sequence[Tuple[Tuple[str, ...], str]] = ((("dvd", "scr"), "dvdscr"), (("bd", "scr"), "bdscr"),
                                                    (("web", "scr"), "webscr"))
# „cam“, které o kině nemluví (skrytá / webová / palubní kamera, cam show).
_CAM_NEG_PREV = frozenset({"hidden", "spy", "web", "dash", "body", "nanny", "security", "ip", "cctv", "helmet", "action",
                           "live", "sex", "porn", "home", "baby", "trail", "skrytou", "skryta"})
_CAM_NEG_NEXT = frozenset({"show", "girl", "girls", "boy", "boys", "sex", "chat", "model", "models", "porn", "video"})
# Rok slepený se značkou („Poster Boys 2017cam“, „…poust2013KinoRip“); „CAM00043“ (soubor z mobilu) ne — před značkou ROK.
_GLUED_RE = re.compile(r"(?:19[2-9]\d|20[0-4]\d)(cam|camrip|hdcam|hdcamrip|kinorip|telesync|hdts|hdtsrip|hdtc|telecine)$")
# „kino“, které o nahrávce z kina NEmluví (domácí kino, kinoverze, Kino Barrandov, Kino 5.1 …).
_KINO_NEG_PREV = frozenset({"domaci", "do", "ve", "v", "pro", "letni", "nase", "our", "mobilni", "tv", "super"})
_KINO_NEG_NEXT = frozenset({"box", "tip", "verze", "pohadka", "pohadky", "klub", "kavarna", "barrandov", "no", "svet"})
_EXT_TAIL_RE = re.compile(r"\.\s*[a-z0-9]+\s*$")
_GROUP_RE = re.compile(r"-([a-z0-9]+)\s*$")


def fold(s: str) -> str:
    """NFKD, bez diakritiky, malá písmena (jméno z macOS v rozloženém tvaru dopadne stejně jako složené)."""
    s = unicodedata.normalize("NFKD", str(s or ""))
    return "".join(c for c in s if not unicodedata.combining(c)).lower()


def tokens(name: str) -> List[str]:
    return [t for t in _SPLIT_RE.split(fold(name)) if t]


def title_word_set(titles: Iterable[str]) -> Set[str]:
    """Slova názvů hledaného titulu (normalizované názvy i surové) — značka, která je slovem názvu, se nepočítá."""
    out: Set[str] = set()
    for t in titles or ():
        out.update(tokens(t))
    return out


def _ext_index(toks: List[str], raw: str) -> int:
    """Index tokenu, který je příponou souboru (poslední token za tečkou), jinak -1."""
    if toks and toks[-1] in _VIDEO_EXTS and re.search(r"\.\s*%s\s*$" % re.escape(toks[-1]), fold(raw)):
        return len(toks) - 1
    return -1


def _group_index(toks: List[str], raw: str, ext_i: int) -> int:
    """Index jména skupiny „…x264-TC.mp4“ (token za POSLEDNÍM „-“ těsně před příponou), jinak -1."""
    base = fold(raw)
    if ext_i >= 0:
        base = _EXT_TAIL_RE.sub("", base)
    m = _GROUP_RE.search(base)
    if not m:
        return -1
    last = len(toks) - 1 - (1 if ext_i >= 0 else 0)
    return last if last >= 0 and toks[last] == m.group(1) else -1


def _anchor(toks: List[str], title_words: Set[str]) -> Tuple[int, bool]:
    """Začátek zóny značek: první rok / rozlišení / kód dílu / technický token (mimo první token), který není slovem
    názvu. Vrací (index, kotva nalezena). Bez kotvy = za prvním tokenem."""
    for i, t in enumerate(toks):
        if i == 0:
            continue
        if _YEAR_RE.match(t) or _RES_RE.match(t) or _EPI_RE.match(t) or (t in _TECH and t not in title_words):
            return i, True
    return (1 if len(toks) > 1 else 0), False


def _match_multi(toks: List[str], i: int, table: Sequence[Tuple[Tuple[str, ...], str]]) -> Optional[Tuple[str, int]]:
    for seq, marker in table:
        n = len(seq)
        if tuple(toks[i:i + n]) == seq:
            return marker, n
    return None


def classify(name: str, title_words: Iterable[str] = ()) -> Verdict:
    """Rozhodnutí podle jména souboru. Pořadí: jistý obraz > slabý obraz > zvuk > screener > nic."""
    tw = set(title_words or ())
    toks = tokens(name)
    if not toks:
        return NONE
    ext_i = _ext_index(toks, name)
    grp_i = _group_index(toks, name, ext_i)
    zone, anchored = _anchor(toks, tw)
    cam_sure: List[str] = []
    cam_weak: List[str] = []
    audio: List[str] = []
    scr: List[str] = []
    has_vsrc = any(t in _VIDEO_SOURCE for t in toks if t not in tw)
    n = len(toks)
    i = 0
    while i < n:
        if i == ext_i:
            i += 1
            continue
        t = toks[i]
        in_title = t in tw
        hit = _match_multi(toks, i, _AUDIO_MULTI)
        if hit and not all(x in tw for x in toks[i:i + hit[1]]):
            audio.append(hit[0])
            i += hit[1]
            continue
        hit = _match_multi(toks, i, _CAM_MULTI)
        if hit and not all(x in tw for x in toks[i:i + hit[1]]) and (i + hit[1] - 1) != ext_i:
            cam_sure.append(hit[0])
            i += hit[1]
            continue
        hit = _match_multi(toks, i, _SCR_MULTI)
        if hit:
            scr.append(hit[0])
            i += hit[1]
            continue
        if in_title:
            i += 1
            continue
        if t in _CAM_SINGLE:
            prev = toks[i - 1] if i > 0 else ""
            nxt = toks[i + 1] if i + 1 < n else ""
            if not (t == "cam" and (prev in _CAM_NEG_PREV or nxt in _CAM_NEG_NEXT)):
                cam_sure.append(_CAM_SINGLE[t])
        elif _GLUED_RE.search(t):
            cam_sure.append(_CAM_SINGLE.get(_GLUED_RE.search(t).group(1), "cam"))
        elif t in _SCR_SINGLE and i >= zone and i != grp_i:
            if not (t in ("r5", "r6") and not ((i + 1 < n and toks[i + 1] in (_TECH | {"line", "xvid"}))
                                               or (i > 0 and _YEAR_RE.match(toks[i - 1])))):
                scr.append(_SCR_SINGLE[t])          # „Yamaha R6“, „BMW R5“ = model, ne značka
        elif t == "ts" and anchored and i >= zone and i != grp_i:
            cam_weak.append("ts")
        elif t == "tc" and anchored and i >= zone and i != grp_i and not (
                (i > 0 and toks[i - 1] in _SUB_CTX) or (i + 1 < n and toks[i + 1] in _SUB_CTX)):
            cam_weak.append("tc")
        elif t in ("md", "ld") and anchored and i >= zone and i != grp_i and (
                (i > 0 and toks[i - 1] in _LANG_CTX)
                or (i + 1 < n and toks[i + 1] in (_LANG_CTX | {"ts", "cam", "xvid", "x264", "1080p", "720p", "2160p"}))):
            audio.append(t)
        elif t in ("kino", "kina") and anchored and i >= zone:
            prev = toks[i - 1] if i > 0 else ""
            nxt = toks[i + 1] if i + 1 < n else ""
            if prev in _KINO_NEG_PREV or nxt in _KINO_NEG_NEXT or nxt.isdigit():   # „Kino 5.1“ = mix zvuku
                pass
            elif t == "kina" and prev != "z":
                pass
            elif prev in _AUDIO_WORDS or nxt in _AUDIO_WORDS or (prev == "z" and i > 1 and toks[i - 2] in _AUDIO_WORDS):
                audio.append("kino_dab")
            else:
                cam_weak.append("kino")
        i += 1

    if cam_sure:
        return Verdict(GRADE_CAM, True, cam_sure[0])
    if cam_weak:
        if "kino" in cam_weak and has_vsrc:
            return Verdict(GRADE_AUDIO, False, "kino+zdroj")
        strong_ctx = anchored or any(_RES_RE.match(x) or x in _TECH for x in toks[zone:] if x not in ("ts", "tc"))
        # Odchylka od reference (audit Fable F18 V7): „TS“ / „TC“ vedle zdroje obrazu (WEB-DL, BluRay, HDTV — „TS“ = proud
        # DVB) jistý CAM není → jen „CAM-RIP?“ (řadí se jen v téže kvalitě, ne za všechny streamy)
        return Verdict(GRADE_CAM, bool(strong_ctx and cam_weak[0] in ("ts", "tc") and not has_vsrc), cam_weak[0])
    if audio:
        if "kino_dab" in audio and not has_vsrc:
            return Verdict(GRADE_CAM, False, "kino_dab")     # „CZ dabing kino“ bez zdroje obrazu = v praxi celý záznam
        return Verdict(GRADE_AUDIO, True, audio[0])
    if scr:
        return Verdict(GRADE_SCR, True, scr[0])
    return NONE


def grade_of(name: str, title_norms: Iterable[str] = ()) -> Tuple[str, str]:
    """(stupeň pro `Release.source_grade`, značka) — `title_norms` = normalizované názvy hledaného titulu."""
    v = classify(name, title_word_set(title_norms))
    if v.grade in (GRADE_CAM, GRADE_AUDIO):
        return (v.grade if v.sure else v.grade + "?"), v.marker
    return v.grade, v.marker


def label(grade: str) -> str:
    """Štítek výpisu pro stupeň; prázdný = žádný štítek (nic, SCREENER)."""
    return LABELS.get(str(grade or ""), "")


def is_cam(grade: str) -> bool:
    """Jistý záznam z kina — řadí se za všechny streamy, které z kina nejsou (D-4)."""
    return grade == GRADE_CAM


def has_video_source(name: str, title_norms: Iterable[str] = ()) -> bool:
    """Nese jméno souboru zdroj obrazu (WEB-DL, WEBRip, BluRay, BDRip, Remux, DVDRip, HDTV, služba NF / AMZN / DSNP …)
    mimo slova hledaného názvu? = kladný důkaz, že obraz NENÍ z kina (katalog `_VIDEO_SOURCE` studie camrip). Jádro 1.2.3
    (`ranking.source_class`, štítek CAM v Trendech): padělky mívají holé jméno („Název (2026).mp4“), skutečné vydání zdroj
    uvádí; neznámá délka u takového jména je běžná (MediaInfo Gate zná jen menšinu souborů). Navíc k `_VIDEO_SOURCE`
    (katalog klasifikace beze změny) i „Blu-ray“ / „Blu ray“ (dvě slova po rozdělení) a DVD / TVRip (audit Fable F37 P4)."""
    tw = title_word_set(title_norms)
    toks = [t for t in tokens(name) if t not in tw]
    if any(t in _VIDEO_SOURCE or t in _ORIGIN_EXTRA for t in toks):
        return True
    return any(a == "blu" and b == "ray" for a, b in zip(toks, toks[1:]))


# Jádro 1.2.3 (F37 P4): zdroj obrazu jen pro doklad originálu (`has_video_source`), klasifikaci CAM nemění.
_ORIGIN_EXTRA = frozenset({"dvd", "tvrip", "dvb", "satrip"})
