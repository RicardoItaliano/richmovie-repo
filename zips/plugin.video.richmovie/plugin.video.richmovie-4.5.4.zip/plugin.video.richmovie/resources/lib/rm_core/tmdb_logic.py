# -*- coding: utf-8 -*-
"""rm_core.tmdb_logic — logika nad TMDb pro hledání streamů (přesun 1 : 1 z `tmdb_client.TMDb`, G1).

Kvůli paritě s doplňkem (A5: vstupy filtru = výstup téhož kódu) tahle třída nedělá žádnou síť ani disk: dostane je od
hostitele. `tmdb_client.TMDb` je její podtřída s HTTP (`richmovie_gate_transport`) a diskovou cache; Gate dodá vlastní
`_get_json` nad `app/tmdb/service` (viz `MemoryTmdb`). Hostitel dodává: `api_key`, `lang`, `_log`, `_diag`,
`_get_json(path, params)`, `_cache_get`, `_cache_set`, `_serve_stale`."""
from __future__ import annotations

import datetime  # noqa: F401  (anotace `datetime.date` u fáze vydání)
import json
import re
import time
import unicodedata
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from rm_core.errors import TMDbError, TMDbNotFoundError, TMDbTransientError

# TMDb `/release_dates` typ 1 = Premiere (festival, premiéra); 2 limitovaná, 3 kina, 4 digitál, 5 fyzicky, 6 TV.
RELEASE_TYPE_PREMIERE = 1
# O kolik let DŘÍV smí být premiéra (festivaly) než rok filmu v TMDb, aby rok ve jménu souboru platil (allowed_years).
FESTIVAL_LEAD_MAX_Y = 3

# ── Fáze vydání (jádro 1.2.0, 15.11.2026; `Temp/mi2_mp4_20261115/NAVRH.md` §5.2) ──────────────────────────────────────────
# „Vydaný“ = existuje uvedení typu 2–6 (limitované, kina, digitál, fyzicky, TV) s datem ≤ dnes v KTERÉKOLI zemi; festivalová
# premiéra (typ 1) se nepočítá. Ověřeno na datech 15.11.: Scorpion (digitál 30.10. před primárním datem) = vydaný,
# Avengers: Doomsday (kina 16.12.) a Hunger Games: Úsvit sklizně (kina 18.11.) = nevydané. Bez údajů = „unknown“ (R2: nic
# se kvůli tomu neskrývá). Trendy: nevydaný film je „dostupný“ jen se streamem s potvrzenou délkou (D-5).
RELEASE_PHASE_RELEASED, RELEASE_PHASE_UNRELEASED, RELEASE_PHASE_UNKNOWN = "released", "unreleased", "unknown"
RELEASE_TYPES_OUT = frozenset({2, 3, 4, 5, 6})
UNRELEASED_TTL_S = 24 * 3600


def release_phase_of(data: Any, today: "datetime.date") -> str:
    """Čistá funkce nad odpovědí `/movie/{id}/release_dates`. `today` = datum (místní)."""
    results = data.get("results") if isinstance(data, dict) else None
    if not isinstance(results, list):
        return RELEASE_PHASE_UNKNOWN
    seen = False
    iso_today = today.isoformat()
    for country in results:
        if not isinstance(country, dict):
            continue
        for rd in country.get("release_dates") or ():
            if not isinstance(rd, dict):
                continue
            try:
                rtype = int(float(str(rd.get("type") or "").strip()))
            except ValueError:
                continue
            day = str(rd.get("release_date") or "")[:10]
            if rtype not in RELEASE_TYPES_OUT or len(day) != 10:
                continue
            seen = True
            if day <= iso_today:
                return RELEASE_PHASE_RELEASED
    return RELEASE_PHASE_UNRELEASED if seen else RELEASE_PHASE_UNKNOWN


class TmdbLogic:
    """Odvozená logika TMDb (výběr latinkového názvu, povolené roky, stopáže, překlady, alt. názvy…)."""

    # Hostitel: api_key, lang, _log(event, *params), _diag(msg, level=1, **kw)
    api_key: str = ""
    lang: str = "cs-CZ"
    _log: Callable[..., Any] = staticmethod(lambda *_a, **_k: None)
    _diag: Callable[..., Any] = staticmethod(lambda *_a, **_k: None)

    # Φ5A (29.09.2026): TTL dat, která se u vydaného filmu prakticky nemění (termíny vydání, kolekce) —
    # stejné jako detail filmu (`details`: 30 dní).
    STATIC_META_TTL_S = 30 * 24 * 3600

    # Jazyky oficiálních překladů názvu FILMU, pod kterými se soubory na českých a slovenských úložištích
    # jmenují (pořadí = pořadí v seznamu názvů pro filtr).
    MOVIE_TITLE_LANGS = ("en-US", "en-GB", "en", "cs-CZ", "cs", "sk-SK", "sk", "pl-PL", "pl")

    # 16-08-2025 08:43 CEST (Europe/Prague)
    def _is_latin_text(self, text: str) -> bool:
        """
        Zjistí, zda text obsahuje alespoň jedno písmeno a všechna písmena
        patří do rozsahu 'LATIN' (včetně české/SL diakritiky: č, š, ě, ů …).

        - Používáme `unicodedata.name(ch)`, protože `isascii()` by vyřadilo
          i latinku s diakritikou.
        - Nepísmena (čísla, mezery, interpunkci) ignorujeme.
        """
        has_letter = False
        for ch in text or "":
            if ch.isalpha():
                has_letter = True
                # Pokud Unicode jméno znaku neobsahuje "LATIN", není to latinka.
                if "LATIN" not in unicodedata.name(ch, ""):
                    return False
        return has_letter

    def _prefer_latin_title(self, *, media: str, _id: int, primary: str, original: str = "") -> str:
        """Latinkový název (viz `_prefer_latin_title_ex`); volající, který výsledek ukládá, potřebuje `_ex`."""
        return self._prefer_latin_title_ex(media=media, _id=_id, primary=primary, original=original)[0]

    def _prefer_latin_title_ex(self, *, media: str, _id: int, primary: str, original: str = "") -> Tuple[str, bool]:
        """
        (název, úplný) — `úplný` = False, když se latinka nenašla KVŮLI chybě (síť, 5xx, 429, odmítnutá identita, cokoli
        jiného než autoritativní „nenalezeno“) a vrací se jen nouzový primární název. Takový výsledek se nesmí uložit do
        cache detailu na 30 dní (R2; cross-check G1 13.11.2026 A1-Q1).

        2025-08-17 00:30 CEST (Europe/Prague)

        Vybere latinkový název podle jasného pořadí:
          1) `primary` (aktuální název) – pokud je latinkou,
          2) `original` (originální titul) – pokud je latinkou,
          3) alternativní tituly (preferujeme země: US, GB, CA, AU),
          4) EN detail (`language=en-US`).

        Nové (mikro-cache – „kosmetika" pro omezení síťových volání):
          • Alt‑titles (movie/tv) se ukládají do interní JSON cache na ~3 dny.
          • EN detail (movie/tv) se ukládá do interní JSON cache na ~3 dny.
          • Klíče cache: 
              - alt_titles:movie:{id}  /  alt_titles:tv:{id}
              - detail_en:movie:{id}   /  detail_en:tv:{id}
          • Síťové chyby ponechávají původní tichý fallback – logiku neměníme.

        Pozn.: `_cache_get/_cache_set` používají společný `tmdb_meta_cache.json`
        a již řeší atomický zápis a uzamčení. Zbytek logiky metody zůstává beze změny.
        """
        # 1) primární název (už latinkový?)
        if self._is_latin_text(primary):
            return (primary or "").strip(), True

        # 2) original_name / original_title
        if self._is_latin_text(original):
            return (original or "").strip(), True

        complete = True

        # 3) alternativní tituly – NOVĚ: krátká disková cache
        try:
            ttl = 3 * 24 * 3600  # ~3 dny
            akind = "movie" if media == "movie" else "tv"
            akey  = f"alt_titles:{akind}:{int(_id)}"

            items = self._cache_get(akey, ttl_seconds=ttl)
            if not isinstance(items, list):
                if media == "movie":
                    data = self._get_json(f"/movie/{_id}/alternative_titles", {"api_key": self.api_key})
                    items = [
                        {"title": (t.get("title") or "").strip(), "country": (t.get("iso_3166_1") or "").strip()}
                        for t in (data.get("titles") or [])
                    ]
                else:
                    data = self._get_json(f"/tv/{_id}/alternative_titles", {"api_key": self.api_key})
                    items = [
                        {"title": (t.get("title") or "").strip(), "country": (t.get("iso_3166_1") or "").strip()}
                        for t in (data.get("results") or [])
                    ]
                self._cache_set(akey, items)

            pref_ctrs   = {"US", "GB", "CA", "AU"}
            first_latin = None
            for rec in items or []:
                t = (rec.get("title") or "").strip()
                if not t:
                    continue
                if self._is_latin_text(t) and (rec.get("country") or "") in pref_ctrs:
                    return t, True
                if first_latin is None and self._is_latin_text(t):
                    first_latin = t
            if first_latin:
                return first_latin, True
        except Exception as _alt_e:
            # `_get_json()` už loguje chyby; nouzový název se vrátí, ale „nenalezeno“ jen z autoritativní odpovědi.
            if not isinstance(_alt_e, TMDbNotFoundError):
                complete = False

        # 4) EN detail – NOVĚ: krátká disková cache
        try:
            ttl = 3 * 24 * 3600  # ~3 dny
            dkind = "movie" if media == "movie" else "tv"
            dkey  = f"detail_en:{dkind}:{int(_id)}"

            t = self._cache_get(dkey, ttl_seconds=ttl)
            if not (isinstance(t, str) and t):
                if media == "movie":
                    en = self._get_json(f"/movie/{_id}", {"api_key": self.api_key, "language": "en-US"})
                    t  = (en.get("title") or "").strip()
                else:
                    en = self._get_json(f"/tv/{_id}", {"api_key": self.api_key, "language": "en-US"})
                    t  = (en.get("name") or "").strip()
                self._cache_set(dkey, t)

            if t and self._is_latin_text(t):
                return t, True
        except Exception as _en_e:
            # Dřív tiché: EN-detail fetch selhal → zůstane nelatinkový titul.
            self._diag(f"EN title fallback fetch fail: {_en_e}", 0)
            if not isinstance(_en_e, TMDbNotFoundError):
                complete = False

        # Nic lepšího – vrať původní (aby se aspoň něco zobrazilo)
        return (primary or original or "").strip(), complete

    def search_tv(self, query: str, limit: int = 10) -> List[Dict]:
        """
        2025-09-07 09:10 CEST (Europe/Prague)
        Vyhledání TV seriálů dle `query` s prioritou latinky v `name`.

        Výstupní struktura (beze změny):
        [{"id","name","year","poster_path","backdrop_path","overview","rating","votes"}, …]
        """
        _ttl = 30 * 24 * 3600
        _key = f"search:tv:{self.lang}:{(query or '').strip().lower()}:{int(limit or 10)}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, list):
            return cached

        params = {
            "api_key":       self.api_key,
            "query":         query,
            "language":      self.lang,
            "page":          1,
        }
        try:
            data = self._get_json("/search/tv", params)
        except TMDbTransientError:
            # Φ4 (2026-08-08): stejná degradace jako u filmového hledání.
            _stale = self._serve_stale(_key, "search_tv",
                                       validator=lambda d: isinstance(d, list))
            if _stale is None:
                raise
            return _stale

        out: List[Dict] = []
        all_complete = True
        for r in data.get("results", [])[:limit]:
            name_primary = (r.get("name") or "").strip()
            if not name_primary:
                continue

            name_final, name_complete = self._prefer_latin_title_ex(
                media="tv",
                _id=int(r["id"]),
                primary=name_primary,
                original=(r.get("original_name") or "").strip(),
            )
            all_complete = all_complete and name_complete

            out.append(
                {
                    "id":            r["id"],
                    "name":          name_final,
                    "year":          int((r.get("first_air_date") or "0000")[:4] or 0),
                    "poster_path":   r.get("poster_path") or "",
                    "backdrop_path": r.get("backdrop_path") or "",
                    "overview":      (r.get("overview") or "").strip(),
                    "rating":        round(float(r.get("vote_average") or 0), 1),
                    "votes":         int(r.get("vote_count") or 0),
                }
            )
        # G1 (13.11.2026, R2): výsledek s nouzovým názvem po chybě se vrátí, ale do 30denní cache nejde.
        if all_complete:
            self._cache_set(_key, out)
        return out

    #  2025-08-16 09:24 CEST (Europe/Prague)
    def search_tv_names(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Seriály TMDb pro `query` v jazyce instance: [{"id", "name", "original_name", "first_air_date"}] — jen SUROVÉ
        údaje, bez dotazů na latinku (`search_tv` dělá další dotazy kvůli zobrazení). Jádro 1.2.2 F2: zjištění
        stejnojmenného seriálu (`context.homonym_variants`). Cache 7 dní přes `_get_json_cached` (selhání se nekešuje, R2)."""
        q = str(query or "").strip()
        if not q:
            return []
        params = {"api_key": self.api_key, "query": q, "language": self.lang, "page": 1}
        # audit Fable F29 V7 (R2b): uloží se jen odpověď kontraktního tvaru (`results` = seznam) — jinak by anomálie
        # proxy znamenala „žádní jmenovci“ na 7 dní
        data = self._get_json_cached("/search/tv", params, key="search_tv_names:%s:%s" % (self.lang, q.lower()),
                                     ttl_s=7 * 24 * 3600, what="search_tv_names",
                                     valid=lambda d: isinstance(d.get("results"), list))
        out: List[Dict[str, Any]] = []
        for r in (data.get("results") or [])[:max(1, int(limit or 20))]:
            try:
                out.append({"id": int(r.get("id")), "name": str(r.get("name") or "").strip(),
                            "original_name": str(r.get("original_name") or "").strip(),
                            "first_air_date": str(r.get("first_air_date") or "").strip()})
            except (TypeError, ValueError):
                continue
        return out

    def tv_episode_counts(self, tv_id: int) -> Dict[int, int]:
        """{číslo řady: počet dílů} seriálu z `/tv/{id}` — jádro 1.2.2 (audit Fable F28 V1): stejnojmenný seriál se počítá
        jen tehdy, když hledaný díl MŮŽE mít (ruský „How I Met Your Mother“ se 2 řadami není jmenovec dílu S05E19). Bez
        latinkového názvu (`tv_details` by u nelatinkového jména dotazoval dál). Cache 7 dní; detail bez `seasons`
        (partial) se neuloží a je to `TMDbError`, 404 = `TMDbNotFoundError` (seriál neexistuje — autoritativní)."""
        out: Dict[int, int] = {}
        for se in self._tv_seasons_payload(tv_id).get("seasons") or ():
            try:
                out[int(se.get("season_number"))] = max(0, int(se.get("episode_count") or 0))
            except (TypeError, ValueError, AttributeError):
                continue
        return out

    def tv_airing(self, tv_id: int) -> bool:
        """Vysílá se seriál právě teď (`in_production` nebo ohlášený další díl)? Pak počet dílů poslední řady v TMDb (a v
        cache 7 dní) může být pozadu — audit Fable F29 V3 c. Tatáž odpověď a cache jako `tv_episode_counts` (bez dotazu navíc)."""
        data = self._tv_seasons_payload(tv_id)
        return bool(data.get("in_production")) or isinstance(data.get("next_episode_to_air"), dict)

    def _tv_seasons_payload(self, tv_id: int) -> Dict[str, Any]:
        """`/tv/{id}` pro jmenovce (jádro 1.2.2): cache 7 dní, jen úplný detail (`seasons` = seznam, bez `_partial_from`)."""
        return self._get_json_cached(
            f"/tv/{int(tv_id)}", {"api_key": self.api_key, "language": self.lang},
            key=f"tv_episode_counts:{int(tv_id)}:{self.lang}", ttl_s=7 * 24 * 3600, what="tv_episode_counts",
            valid=lambda d: isinstance(d.get("seasons"), list) and "_partial_from" not in d)

    def episode_details(self, tv_id: int, season_no: int, episode_no: int) -> Dict:
        """
        Detail jedné epizody (/tv/{tv_id}/season/{season_no}/episode/{episode_no})
        Vrací např. {"id":..., "name":"...", "overview":"...", "still_path": "..."}.

        Nové:
        -----
        • disková cache s TTL ≈ 30 dní
        """
        params = {"api_key": self.api_key, "language": self.lang}

        _ttl = 30 * 24 * 3600
        _key = self._episode_cache_key(tv_id, season_no, episode_no)
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, dict):
            return cached

        try:
            data = self._get_json(
                f"/tv/{tv_id}/season/{season_no}/episode/{episode_no}", params
            )
        except TMDbTransientError:
            # Φ4 (2026-08-08): název a popis epizody se nemění vůbec. Když jede
            # autoplay dalšího dílu a zrovna vypadne Wi-Fi, je nesrovnatelně lepší
            # ukázat starý název než přerušit sledování chybou.
            _stale = self._serve_stale(_key, "episode_details",
                                       validator=lambda d: isinstance(d, dict))
            if _stale is None:
                raise
            return _stale

        self._cache_set(_key, data)
        return data

    def episode_translations(self, tv_id: int, season_no: int, episode_no: int) -> Dict[str, str]:
        """
        Překlady názvu epizody → mapování „jazyk(-země) → name".

        10-08-2025 16:31 CEST (Europe/Prague)
        -------------------------------------
        • /tv/{tv_id}/season/{sn}/episode/{ep}/translations
        • Klíč volím jako "iso_639_1-iso_3166_1" (pokud je země známa),
          jinak jen "iso_639_1".  Vždy beru nejdelší dostupné jméno
          pro daný klíč (bývá to plný název typu „The One Where …").

        Vrací:
            {"en-US": "The One Where Monica Gets a Roommate",
             "en-GB": "The One Where Monica Gets a Flatmate",
             "en":    "The One Where Monica Gets a Roommate",
             "cs-CZ": "Zrušená svatba", ...}
        """
        params = {"api_key": self.api_key}
        # Φ-B (30.09.2026): lokální cache (30 d, stale-first). Překlady názvu dílu se nemění a hledání dílu
        # je od 3.5.171 společné pro výpis i předstažení ve službě — bez cache by každé předstažení
        # přidalo dotaz na TMDb.
        data: Dict[str, Any] = self._get_json_cached(
            f"/tv/{tv_id}/season/{season_no}/episode/{episode_no}/translations", params,
            key=f"ep_translations:{int(tv_id)}:{int(season_no)}:{int(episode_no)}",
            ttl_s=self.STATIC_META_TTL_S, what="episode_translations")
        return self._parse_translation_map(data)

    @staticmethod
    def _parse_translation_map(data: Dict[str, Any], field: str = "name") -> Dict[str, str]:
        """SSOT parser odpovědi TMDb /translations (epizoda i seriál mají
        identický tvar, film nese název v `data.title` → `field="title"`).
        Klíč „iso_639_1[-iso_3166_1]" → název; při kolizi klíče preferuj DELŠÍ
        název (bývá plná věta)."""
        out: Dict[str, str] = {}
        for tr in (data.get("translations", []) or []):
            lang = (tr.get("iso_639_1") or "").strip()
            ctry = (tr.get("iso_3166_1") or "").strip()
            dat  = tr.get("data") or {}
            name = (dat.get(field) or "").strip()
            if not (lang and name):
                continue
            key = f"{lang}-{ctry}" if ctry else lang
            if key not in out or len(name) > len(out[key]):
                out[key] = name
        return out

    def tv_translations(self, tv_id: int) -> Dict[str, str]:
        """Překlady názvu SERIÁLU → mapování „jazyk(-země) → name".

        2026-07-07 (HΦ5) – doplňuje alternative_titles: TMDb `alternative_titles`
        je user-curated a nemusí obsahovat každý lokalizovaný název (např. SK
        „Priatelia" pro Friends). `/tv/{id}/translations` nese OFICIÁLNÍ
        lokalizovaný `data.name` per jazyk. Používá se k obohacení
        ser_title_variants → cizojazyčný název už nepenalizuje správný soubor
        a zlepšuje recall u souborů pojmenovaných jen lokálním názvem. Mirror
        episode_translations (stejný tvar odpovědi)."""
        params = {"api_key": self.api_key}
        data: Dict[str, Any] = self._get_json_cached(
            f"/tv/{tv_id}/translations", params, key=f"tv_translations:{int(tv_id)}",
            ttl_s=self.STATIC_META_TTL_S, what="tv_translations")
        return self._parse_translation_map(data)

    def movie_localized_titles(self, movie_id: int) -> List[str]:
        """Oficiální lokalizované názvy FILMU (TMDb `/movie/{id}/translations`, `data.title`) v jazycích
        `MOVIE_TITLE_LANGS`, bez duplicit, jen s latinkou. Lokální cache 30 d.

        Φ-B (30.09.2026, E3-F02): filtr filmu znal jen český a PŮVODNÍ název. U filmu s neanglickým
        originálem („Le Cinquième Élément“) tak zahodil všechny soubory pojmenované anglicky
        („The.Fifth.Element.1997…“ včetně 4K) — seriály tuhle sadu názvů mají od HΦ5."""
        data = self._get_json_cached(
            f"/movie/{int(movie_id)}/translations", {"api_key": self.api_key},
            key=f"movie_translations:{int(movie_id)}", ttl_s=self.STATIC_META_TTL_S,
            what="movie_translations")
        by_lang = self._parse_translation_map(data if isinstance(data, dict) else {}, field="title")
        out: List[str] = []
        seen: set = set()
        for lc in self.MOVIE_TITLE_LANGS:
            nm = (by_lang.get(lc) or "").strip()
            if nm and re.search(r"[A-Za-z]", nm) and nm.casefold() not in seen:
                seen.add(nm.casefold())
                out.append(nm)
        return out

    # Jádro 1.2.3 (21.11.2026, D-5 / D-6 `Handoff/PLAN_cam_trendy_20261121.md`): jiné filmy téhož roku s delším názvem
    # („Poklad“ × „Poklad lásky“) a hlavní herci (vlna hledání podle herců, když Webshare blokuje hledání podle názvu).
    COMPETING_MAX_RESULTS = 20          # jedna stránka `/search/movie` (TMDb vrací 20 na stránku)
    CAST_MAX = 2                        # hlavní herci = první dva podle pořadí v titulcích (`order`)

    def movie_competing_titles(self, movie_id: int, title: str, year: int) -> List[str]:
        """Názvy (lokalizovaný i původní) JINÝCH filmů z `/search/movie` na `title` v roce `year` (TMDb `year` = rok
        kteréhokoli vydání). Vlastní film (`movie_id`) se vynechá. Cache 30 dní. Chyba TMDb propaguje (volající rozhodne:
        bez konkurenčních názvů se nic navíc nevyřadí, R2)."""
        q = str(title or "").strip()
        if not q or not int(year or 0):
            return []
        data = self._get_json_cached(
            "/search/movie", {"api_key": self.api_key, "query": q, "year": int(year), "page": 1, "language": self.lang},
            key=f"competing:{self.lang}:{q.casefold()}:{int(year)}", ttl_s=self.STATIC_META_TTL_S, what="competing_titles",
            valid=lambda d: isinstance(d.get("results"), list))
        out: List[str] = []
        for r in data["results"][:self.COMPETING_MAX_RESULTS]:
            if not isinstance(r, dict):
                continue
            try:
                rid = int(r.get("id") or 0)
            except (TypeError, ValueError):
                continue
            if rid == int(movie_id) or rid <= 0:
                continue
            for field in ("title", "original_title"):
                t = r.get(field)
                if isinstance(t, str) and t.strip() and t not in out:
                    out.append(t)
        return out

    def movie_cast_names(self, movie_id: int, limit: int = 0) -> List[str]:
        """Jména hlavních herců filmu (`/movie/{id}/credits`, pole `cast` podle `order`), nejvýš `limit` (výchozí
        `CAST_MAX`). Cache 30 dní. 404 = `TMDbNotFoundError` (autoritativně žádní), jiná chyba propaguje."""
        data = self._get_json_cached(
            f"/movie/{int(movie_id)}/credits", {"api_key": self.api_key, "language": self.lang},
            key=f"credits:{int(movie_id)}", ttl_s=self.STATIC_META_TTL_S, what="credits",
            # R2 (cross-check Codex N6.1): odpověď bez seznamu `cast` ({} / null / jiný typ) NENÍ „žádní herci“ —
            # neúplná odpověď = `TMDbError` (vlna herců se nevyřeší, prázdno není autoritativní); `cast: []` = autoritativně
            valid=lambda d: isinstance(d.get("cast"), list))
        cast = [c for c in data["cast"] if isinstance(c, dict) and str(c.get("name") or "").strip()]

        def _order(c: Dict[str, Any]) -> int:
            try:
                return int(c.get("order"))
            except (TypeError, ValueError):
                return 10 ** 6
        cast.sort(key=_order)
        out: List[str] = []
        for c in cast:
            nm = str(c.get("name") or "").strip()
            if nm not in out:
                out.append(nm)
            if len(out) >= int(limit or self.CAST_MAX):
                break
        return out

    def tv_alternative_titles(self, tv_id: int) -> List[Dict[str, Any]]:
        """Alternativní názvy SERIÁLU (`/tv/{id}/alternative_titles` → `results`), lokální cache 30 d.

        Φ-B (30.09.2026): dřív je `plugin._tv_play_run` četl přímým `_get_json` při KAŽDÉM hledání dílu
        (bez cache). Položky: {"iso_3166_1": "US", "title": "…", "type": "…"}; filtr zemí dělá volající."""
        data = self._get_json_cached(
            f"/tv/{int(tv_id)}/alternative_titles", {"api_key": self.api_key},
            key=f"tv_alt_titles:{int(tv_id)}", ttl_s=self.STATIC_META_TTL_S, what="tv_alternative_titles")
        res = data.get("results", []) if isinstance(data, dict) else []
        return [r for r in res if isinstance(r, dict)]

    def tv_details(self, tv_id: int) -> Dict[str, Any]:
        """
        Detail seriálu – preferujeme latinkový `name` (alt tituly → EN detail).
        Disková cache s TTL ≈ 30 dní.

        2026-04-30 — Defense-in-depth proti partial-detail cache poisoning
        (Lost incident, viz Handoff/session_2026-04-30_tmdb_partial_cache_
        poisoning.md). Validuje, že payload má tvar plného detailu (`seasons`
        klíč, žádný `_partial_from` marker). Pokud Gate vrátí partial:
          • lokální disková cache se NEPŘEPÍŠE (zůstává předchozí full nebo prázdno)
          • při `cached` jako partial: ignoruj a fetchni znovu
          • zaloguje warning (`TV_DETAIL_PARTIAL_REJECTED`) pro diagnostiku
        Server-side fix v Gate (migration 0006) by měl tento případ eliminovat,
        ale defense-in-depth chrání addon i v přechodném okně před Gate redeploy.
        """
        params = {"api_key": self.api_key, "language": self.lang}

        _ttl = 30 * 24 * 3600
        _key = f"tv_details:{int(tv_id)}:{self.lang}"

        cached = self._cache_get(_key, _ttl)
        cached_is_full = (
            isinstance(cached, dict)
            and "seasons" in cached
            and "_partial_from" not in cached
        )

        served_stale = False
        if cached_is_full:
            data = dict(cached)
        else:
            try:
                data = self._get_json(f"/tv/{tv_id}", params)
            except TMDbTransientError:
                # Φ4 (2026-08-08): stejná degradace jako u filmů, se stejným
                # partial guardem — právě tady „Lost" incident (30.04.2026) začal,
                # takže tudy stará partial data projít NESMÍ.
                _stale = self._serve_stale(
                    _key, "tv_details",
                    validator=lambda d: (isinstance(d, dict)
                                         and "seasons" in d
                                         and "_partial_from" not in d),
                )
                if _stale is None:
                    raise
                data = dict(_stale)
                served_stale = True

        is_partial_payload = (
            "_partial_from" in data
            or "seasons" not in data
        )

        # Apply latin-title preference regardless (caller expects `name` set).
        data["name"], name_complete = self._prefer_latin_title_ex(
            media="tv",
            _id=int(tv_id),
            primary=(data.get("name") or "").strip(),
            original=(data.get("original_name") or "").strip(),
        )

        if is_partial_payload:
            # Don't pollute the local cache. Caller (e.g. _tv_seasons) is
            # responsible for surfacing this to the user — we just hand back
            # the partial unchanged so they can detect and react.
            try:
                self._log(
                    "TV_DETAIL_PARTIAL_REJECTED",
                    "tv_id={} keys={}".format(
                        int(tv_id), sorted(list(data.keys()))[:20],
                    ),
                )
            except Exception:
                pass
            return data

        # Φ4 (2026-08-08): degradovaná data zpět do cache NEUKLÁDAT — zápis by jim
        # dal čerstvé razítko a příštích 30 dní by se tvářila jako aktuální.
        # G1 (13.11.2026): totéž pro detail, jehož latinkový název nedopadl kvůli chybě (R2) — vrátí se, neuloží.
        if not served_stale and name_complete:
            self._cache_set(_key, data)
        return data

    def season_air_date(self, tv_id: int, season_no: int) -> str:
        """Datum premiéry sezóny (`air_date` sezóny, ISO `YYYY-MM-DD`), "" když
        není známé. JEDNA cesta pro obě vyhledávací větve (plán adaptivní cache
        Φ0a, 25.08.2026): do 3.5.125 volala jedna větev `season_details()` a četla
        z něj `.get("air_date")` — jenže `season_details` vrací LIST epizod, takže
        každé volání skončilo `'list' object has no attribute 'get'`, tiše
        spolknuto do DEBUG (186× za 14 dní ve flotile), a `allowed_years` nikdy
        nedostaly rok sezóny. Druhá větev volala `_get_json` napřímo = druhá pravda.
        Výjimky propouští (volající si je řeší jako dosud); disková cache 30 dní."""
        params = {"api_key": self.api_key, "language": self.lang}
        _ttl = 30 * 24 * 3600
        _key = f"season_air_date:{int(tv_id)}:{int(season_no)}:{self.lang}"
        cached = self._cache_get(_key, _ttl)
        if isinstance(cached, dict) and "air_date" in cached:
            return (cached.get("air_date") or "").strip()
        data = self._get_json(f"/tv/{int(tv_id)}/season/{int(season_no)}", params)
        air = ((data or {}).get("air_date") or "").strip() if isinstance(data, dict) else ""
        try:
            self._cache_set(_key, {"air_date": air})
        except Exception:
            pass
        return air

    def details(self, movie_id: int) -> Dict[str, Any]:
        """Detail filmu (viz `details_ex`); volající, který z detailu staví hledání, potřebuje `details_ex`."""
        return self.details_ex(movie_id)[0]

    def details_ex(self, movie_id: int) -> Tuple[Dict[str, Any], bool]:  # 2025-09-27 13:34 CEST (Europe/Prague)

        """
        (detail, úplný) — `úplný` = False u částečného detailu (projekce z hledání, `_partial_from`, bez `genres`) a u detailu,
        jehož obohacení (latinkový název, EN délka) nedopadlo kvůli chybě. Hledání nad neúplným detailem běží s chudšími
        dotazy → jeho prázdný výsledek NENÍ autoritativní (R2; cross-check Codex 13.11.2026, `context.build_movie_context`).

        Detail filmu – rozšířen o preferenci latinky v `title`.
        Další logika beze změny:
          - EN fallback pro `runtime` (pokud chybí v lokalizaci),
          - zajištění klíčů `year` (YYYY z `release_date`) a `original_title`.
        """
        # Lokalizovaný detail (cs-CZ apod.)
        params = {"api_key": self.api_key, "language": self.lang}

        # 2025-09-27 13:34 CEST (Europe/Prague) – disková cache (TTL ≈ 30 dní)
        _ttl = 30 * 24 * 3600
        _key = f"movie_details:{int(movie_id)}:{self.lang}"
        # Σ-audit Φ3.18: stejná obrana proti partial-detail cache poisoning jako
        # tv_details (Lost incident). Plný /movie/{id} detail má klíč `genres`;
        # search-projekce (partial, např. CSFD-resolved poster/plot) ho nemá nebo
        # nese `_partial_from` marker. Partial se NEPŘEPÍŠE do lokální cache a
        # cached-partial se ignoruje + refetchne.
        cached = self._cache_get(_key, _ttl)
        cached_is_full = (
            isinstance(cached, dict)
            and "_partial_from" not in cached
            and "genres" in cached
        )
        served_stale = False
        if cached_is_full:
            data: Dict[str, Any] = dict(cached)  # kopie pro jistotu
        else:
            try:
                data: Dict[str, Any] = self._get_json(f"/movie/{movie_id}", params)
            except TMDbTransientError:
                # Φ4 (2026-08-08): síť je dole → radši detail o pár dní starší než
                # dialog s chybou. Validátor drží TENTÝŽ partial guard jako čerstvá
                # cesta výše — degradace NESMÍ oživit „Lost" incident (30.04.2026),
                # kdy se search-projekce tvářila jako plný detail.
                _stale = self._serve_stale(
                    _key, "movie_details",
                    validator=lambda d: (isinstance(d, dict)
                                         and "_partial_from" not in d
                                         and "genres" in d),
                )
                if _stale is None:
                    raise
                data: Dict[str, Any] = dict(_stale)
                served_stale = True

        # Preferovat latinku v title (alt tituly → EN detail)
        data["title"], enrich_complete = self._prefer_latin_title_ex(
            media="movie",
            _id=int(movie_id),
            primary=(data.get("title") or "").strip(),
            original=(data.get("original_title") or "").strip(),
        )

        # Fallback runtime z EN detailu, pokud chybí
        if not data.get("runtime"):
            try:
                en = self._get_json(f"/movie/{movie_id}", {"api_key": self.api_key, "language": "en-US"})
                if en.get("runtime"):
                    data["runtime"] = en["runtime"]
            except TMDbError as _en_e:
                self._diag(f"EN runtime fallback fail: {_en_e}", 0)
                # G1 (13.11.2026, R2): bez délky kvůli chybě se detail NEULOŽÍ — jinak by kontrola délky filmu
                # 30 dní nefungovala; autoritativní „nenalezeno“ je odpověď (délka opravdu není).
                if not isinstance(_en_e, TMDbNotFoundError):
                    enrich_complete = False

        # Zajisti `year` a `original_title` (stejné chování jako původně)
        if not data.get("year"):
            data["year"] = int((data.get("release_date") or "0000")[:4] or 0)
        if not data.get("original_title"):
            data["original_title"] = data.get("title", "")

        # Σ-audit Φ3.18: NEukládej partial do cache (jinak by se „Lost" poisoning
        # přenesl i na filmy). Vrať ho nezměněný (caller má aspoň title/poster),
        # ale příští volání refetchne plný detail.
        is_partial_payload = ("_partial_from" in data) or ("genres" not in data)
        if is_partial_payload:
            try:
                self._log(
                    "MOVIE_DETAIL_PARTIAL_REJECTED",
                    "movie_id={} keys={}".format(
                        int(movie_id), sorted(list(data.keys()))[:20],
                    ),
                )
            except Exception:
                pass
            return data, False

        # 2025-09-27 13:34 CEST (Europe/Prague) – ulož do cache (read‑through)
        # Φ4 (2026-08-08): degradovaná (stale) data se NEUKLÁDAJÍ zpátky. Zápis by
        # jim nastavil čerstvé razítko, čímž by data „omládla" o svoje skutečné
        # stáří a příštích 30 dní by se tvářila jako aktuální — tichá ztráta
        # informace, kterou by nikdo nezpozoroval.
        # G1 (13.11.2026): ani detail s degradovaným obohacením (název / délka po chybě) — vrátí se, neuloží (R2).
        if not served_stale and enrich_complete:
            try:
                self._cache_set(_key, data)
            except Exception:
                # Cache je „best effort" – nikdy nesmí shodit volání
                pass
        return data, enrich_complete

    # --------------------------------------------------------------- #
    #  ALTERNATIVE TITLES  –  vrací i zemi, abychom mohli filtrovat   #
    # --------------------------------------------------------------- #
    def alternative_titles(self, movie_id: int,
                           *, max_items: int | None = None) -> List[Dict[str, str]]:
        """
        Vrátí seznam alternativních názvů + země původu.

        [{"title": "Cosy Dens", "country": "CA"}, …]
        Duplicitní i prázdné názvy jsou odfiltrovány; pořadí zachováno.
        """
        params = {"api_key": self.api_key}
        data   = self._get_json(f"/movie/{movie_id}/alternative_titles", params)

        out: List[Dict[str, str]] = []
        seen: set[str] = set()

        for rec in data.get("titles", []):
            title = (rec.get("title") or "").strip()
            if not title:
                continue

            norm = unicodedata.normalize("NFKC", title).lower()
            if norm in seen:
                continue
            seen.add(norm)

            out.append({"title": title, "country": rec.get("iso_3166_1", "")})
            if max_items and len(out) >= max_items:
                break
        return out

    def _get_json_cached(self, path: str, params: Dict[str, Any], *, key: str, ttl_s: int,
                         what: str, valid: Optional[Callable[[Dict[str, Any]], bool]] = None) -> Dict[str, Any]:
        """SSOT (Φ5A, 29.09.2026): odpověď TMDb přes lokální cache s TTL a stale-first degradací.

        Dřív šly `/collection/{id}` a `/movie/{id}/release_dates` na síť při KAŽDÉM hledání filmu (i při
        návratu Zpět) a `release_dates` dokonce dvakrát (alt. stopáže + povolené roky) — ~2,4 s kolečka před
        dialogem (audit A06 F08). Ukládá se jen úspěšná odpověď (dict); selhání se nekešuje (R2).

        `valid` (jádro 1.2.2, audit Fable F28 V1): kontrola úplnosti odpovědi. Neúplná odpověď (např. detail seriálu bez
        `seasons` — partial z hledání, incident Lost 30.04.2026) se neuloží ani nepoužije ze staré cache a volající
        dostane `TMDbError` (není to autoritativní „nic“)."""
        def _ok(d: Any) -> bool:
            return isinstance(d, dict) and (valid is None or bool(valid(d)))

        cached = self._cache_get(key, ttl_s)
        if _ok(cached):
            return cached
        try:
            data = self._get_json(path, params)
        except TMDbTransientError:
            stale = self._serve_stale(key, what, validator=_ok)
            if stale is None:
                raise
            return stale
        if valid is not None and not _ok(data):
            raise TMDbError("TMDb: neúplná odpověď (%s)" % what)
        if isinstance(data, dict):
            self._cache_set(key, data)
        return data if isinstance(data, dict) else {}

    def _release_dates(self, movie_id: int, ttl_s: Optional[int] = None) -> Dict[str, Any]:
        """`/movie/{id}/release_dates` z cache — jeden zdroj pro alt. stopáže, povolené roky i fázi vydání."""
        return self._get_json_cached(
            f"/movie/{int(movie_id)}/release_dates", {"api_key": self.api_key},
            key=f"release_dates:{int(movie_id)}", ttl_s=int(ttl_s or self.STATIC_META_TTL_S), what="release_dates")

    def release_phase(self, movie_id: int, today: "datetime.date") -> str:
        """Fáze vydání filmu k datu `today` (`release_phase_of`). U NEVYDANÉHO filmu se `release_dates` čte s kratší
        platností (`UNRELEASED_TTL_S`) — jinak by se pozdní kino / digitální premiéra poznala až za 30 dní."""
        phase = release_phase_of(self._release_dates(movie_id), today)
        if phase != RELEASE_PHASE_RELEASED:
            # nevydaný i bez údajů (ohlášený titul): datum kin / digitálu TMDb doplní později (audit Fable F18 V10)
            phase = release_phase_of(self._release_dates(movie_id, ttl_s=UNRELEASED_TTL_S), today)
        return phase

    # --------------------------------------------------------------- #
    #  COLLECTION PARTS – vrací názvy všech filmů v kolekci          #
    # --------------------------------------------------------------- #
    def collection_parts(self, coll_id: int) -> List[str]:
        """
        Načte /collection/{id} (lokální cache, Φ5A) a vrátí list titulů jednotlivých dílů (lokalizované názvy).
        """
        return self._collection_titles(coll_id, "title")

    def collection_part_originals(self, coll_id: int) -> List[str]:
        """Originální názvy dílů kolekce (jádro 1.2.0 — Hunger Games: zákaz kolekce znal jen „Balada o ptácích a hadech“
        a soubor „the-hunger-games-the-ballad-of-songbirds-and-snake_s“ prošel). Táž odpověď TMDb, žádný dotaz navíc.
        Zvlášť od lokalizovaných: kontext z nich bere jen celé fráze a výrazná slova (audit Fable F18 V2 — „with“, „free“)."""
        return self._collection_titles(coll_id, "original_title")

    def _collection_titles(self, coll_id: int, field: str) -> List[str]:
        params = {"api_key": self.api_key, "language": self.lang}
        data   = self._get_json_cached(f"/collection/{coll_id}", params,
                                       key=f"collection:{int(coll_id)}:{self.lang}",
                                       ttl_s=self.STATIC_META_TTL_S, what="collection")
        out: List[str] = []
        for p in data.get("parts", []) or []:
            t = p.get(field) if isinstance(p, dict) else None
            if isinstance(t, str) and t.strip() and t not in out:
                out.append(t)
        return out

    def get_alt_runtimes(self, movie_id: int) -> List[int]:
        """
        Vrátí alternativní délky filmu (kino / director’s cut …) v minutách.

        Endpoint `/movie/{id}/release_dates` obsahuje pole `runtime`
        jen u některých releasů; všechny hodnoty sjednotíme do seřazeného listu.
        """
        data   = self._release_dates(movie_id)

        runtimes: set[int] = set()
        for rel in data.get("results", []):
            for rd in rel.get("release_dates", []):
                if (rt := rd.get("runtime")):
                    try:
                        runtimes.add(int(rt))
                    except (TypeError, ValueError):
                        pass          # ignorujeme neplatné hodnoty
        return sorted(runtimes)

    # ---------------------------------- METODA ---------------------------------- #
    # tmdb_client.py › class TMDb
    # allowed_years (upraveno: 31.12.2025 13:48 CET (Europe/Prague) – FIX: skutečná tolerance ±margin i bez výskytu roku v release_dates; zachováno: relevantní země + ladicí log TMDB_ALLOWED_YEARS)
    # ---------------------------------------------------------------------------- #
    def allowed_years(  # 31.12.2025 13:48 CET (Europe/Prague)
        self,
        movie_id: int,
        *,
        primary_year: Optional[int] = None,
        major_markets: Sequence[str] = ("US", "GB", "CA", "DE", "FR", "IT", "ES", "AU", "CZ", "SK"),
        margin: int = 1,
    ) -> List[int]:
        """
        31.12.2025 13:48 CET (Europe/Prague)

        Vrátí „povolené roky vydání" pro film podle TMDb s následující logikou:
        • země = produkční země z `/movie/{id}`  ∪  pevný seznam hlavních trhů
        • pro každou z těchto zemí vezme nejčasnější rok z `/movie/{id}/release_dates`
        • do výstupu pustí roky z release_dates v toleranci ±margin oproti `primary_year`
        • NOVĚ: vždy přidá „hard" toleranci `primary_year ± margin` i když daný rok v `/release_dates` vůbec není
          (řeší rozdíly typu ČSFD uvádí 1964, TMDb 1965 → releasy s (1964) by jinak padaly jako `year_miss`)
        • `primary_year` doplní z detailu, pokud není předán

        Výsledek se použije pouze ve FILTRU releasů (dotazy zůstávají s primárním rokem).
        """
        # 1) detail – produkční země a případně primární rok. Φ5A: `details()` (lokální cache, tentýž
        #    `/movie/{id}`), dřív vlastní dotaz na síť navíc při každém hledání filmu.
        det = self.details(movie_id)  # může vyhodit TMDbError
        prod_codes = {c.get("iso_3166_1", "").upper() for c in det.get("production_countries", []) if c.get("iso_3166_1")}
        if primary_year is None:
            primary_year = int((det.get("release_date") or "0000")[:4] or 0)

        # 2) release_dates – sběr roků pro relevantní země (sdílená cache s `get_alt_runtimes`, Φ5A)
        data = self._release_dates(movie_id)
        relevant = prod_codes | {c.upper() for c in major_markets}
        years_by_country: dict[str, int] = {}
        premiere_years: set[int] = set()

        for rec in data.get("results", []):
            cc = (rec.get("iso_3166_1") or "").upper()
            if cc not in relevant:
                continue
            # nejčasnější datum v dané zemi
            years = []
            for rd in rec.get("release_dates", []):
                d = (rd.get("release_date") or "")[:4]
                if d.isdigit():
                    years.append(int(d))
                    if str(rd.get("type") or "").strip() == str(RELEASE_TYPE_PREMIERE):   # TMDb číslo, odolně i "1"
                        premiere_years.add(int(d))
            if years:
                years_by_country[cc] = min(years)

        # 3) sestavíme whitelist roků v toleranci ±margin
        allowed: set[int] = set()
        forced_span: list[int] = []

        # vždy přidej primary_year (pokud existuje) + hard toleranci ±margin
        if primary_year:
            allowed.add(primary_year)
            if margin and margin > 0:
                for y in range(int(primary_year) - int(margin), int(primary_year) + int(margin) + 1):
                    if y > 0:
                        allowed.add(y)
                        forced_span.append(y)

        # roky z relevantních zemí pustíme jen pokud sedí do tolerance
        for y in years_by_country.values():
            if primary_year and abs(y - primary_year) <= margin:
                allowed.add(y)

        # 15.11.2026 (F1 §4.2, Hunting Matthew Nichols: festivaly 10/2024, TMDb rok 2026 → jediný soubor `…2024…` = year_miss):
        # film obíhá festivaly a do kin / na stream jde až později → rok PREMIÉRY (typ 1) téhož filmu v relevantní zemi
        # platí i mimo ±margin, ale jen DŘÍVĚJŠÍ a nejvýš o FESTIVAL_LEAD_MAX_Y let. Pozdější roky ne (reedice, remake).
        festival_years: list[int] = []
        if primary_year:
            for y in sorted(premiere_years):
                if primary_year - FESTIVAL_LEAD_MAX_Y <= y < primary_year - margin:
                    allowed.add(y)
                    festival_years.append(y)

        out = sorted(y for y in allowed if y > 0)

        # log pro ladění
        try:
            self._log(
                "TMDB_ALLOWED_YEARS",
                movie_id,
                json.dumps(
                    {
                        "primary_year": primary_year,
                        "production": sorted(prod_codes),
                        "majors": sorted(relevant - prod_codes),
                        "years_by_country": {k: v for k, v in sorted(years_by_country.items())},
                        "forced_span": sorted(set(forced_span)) if forced_span else [],
                        "festival": festival_years,
                        "allowed": out,
                    },
                    ensure_ascii=False,
                ),
            )
        except Exception:
            pass

        return out

    def _episode_cache_key(self, tv_id: int, season_no: int, episode_no: int) -> str:
        """Klíč diskové cache detailu epizody — jeden pro `episode_details` i `peek_episode_details`."""
        return f"episode:{int(tv_id)}:{int(season_no)}:{int(episode_no)}:{self.lang}"


class MemoryTmdb(TmdbLogic):
    """Hostitel TmdbLogic bez disku: `fetch_json(path, params)` dodá odpověď TMDb, cache je slovník (RAM, TTL).
    Používá ho Gate (`fetch_json` nad `app/tmdb/service`) a brána P3 (zlaté vstupy). Neúspěšná odpověď se neukládá (R2)."""

    def __init__(self, fetch_json: Callable[[str, Dict[str, Any]], Dict[str, Any]], *, api_key: str = "gate",
                 lang: str = "cs-CZ", log: Optional[Callable[..., Any]] = None,
                 diag: Optional[Callable[..., Any]] = None, clock: Callable[[], float] = time.time,
                 cache: Optional[Dict[str, Any]] = None) -> None:
        self.api_key = api_key
        self.lang = lang
        self._fetch_json = fetch_json
        self._log = log or (lambda *_a, **_k: None)
        self._diag = diag or (lambda *_a, **_k: None)
        self._clock = clock
        self._cache = cache if cache is not None else {}

    def _get_json(self, path: str, params: Dict[str, Any]) -> Dict[str, Any]:
        return self._fetch_json(path, params)

    def _cache_get(self, key: str, ttl_seconds: int) -> Optional[Any]:
        rec = self._cache.get(key)
        if rec is None:
            return None
        ts, data = rec
        return data if (self._clock() - ts) <= ttl_seconds else None

    def _cache_set(self, key: str, data: Any) -> None:
        self._cache[key] = (self._clock(), data)

    def _serve_stale(self, key: str, what: str, validator: Any = None) -> Optional[Any]:
        return None
