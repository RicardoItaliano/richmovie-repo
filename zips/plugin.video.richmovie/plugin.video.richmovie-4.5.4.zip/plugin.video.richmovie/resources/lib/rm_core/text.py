# -*- coding: utf-8 -*-
"""rm_core.text — normalizace názvů, přípony, kódy dílů, jazyky a kvalita podle názvu souboru.

Čistá standardní knihovna (Python 3.8); žádný import Kodi ani sítě. Přesun 1 : 1 z `richmovie_engine` (G1).
"""
from __future__ import annotations

import os
import re
import unicodedata
from typing import List, Optional, Sequence, Tuple

# Slova, která se ve jménech epizod vyskytují extrémně často a sama o sobě
# nejsou pro vyhledávání směrodatná („Episode 1“, „Pilot“, „Úvod“ apod.).
GENERIC_EP: set[str] = {
    # — anglicky —
    "episode", "ep", "pilot", "part", "chapter", "segment", "beginning", "start",
    # — česky/slovensky —
    "epizoda", "pilotní", "pilotni", "díl", "dil", "část", "cast",
    "úvod", "uvod", "od", "zacatek", "začátek", "zacatku", "začátku",
    # — další jazyky (běžné “Episode 1”) —
    "capitulo", "capitolo",
}

QUALITY_RANK = {               # nižší index = lepší
    "2160p": 0,
    "1080p": 1,
    "720p":  2,
    "480p":  3,
    "webrip": 4,
    "other":  5,
    "cam":    6,
}

# — filtry —
ALLOWED_VIDEO_EXTS = {
    ".mkv", ".mp4", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".webm",
    ".m4v",   # HΦ2 (2026-07-07, analýza H1 §6.2): Apple kontejner, kontejnerově
              # shodný s .mp4 — chyběl → správné 1080p soubory (Kingsman, Zloba)
              # padaly na `quick`. Legitimní video přípona, 0 riziko pro precision.
    # Φ-B (30.09.2026, E3-F08): starší a DVD kontejnery, které Kodi přehraje — chyběly, takže správné
    # soubory („Kravataci-S01E01.mpg“, „Poslední samuraj … .flv“) padaly na `quick`. Zvukové přípony
    # (.mka/.m4a/.wma) a nedostažené soubory (.part/.crdownload) sem NEpatří.
    ".mpg", ".mpeg", ".vob", ".divx", ".flv", ".m2v",
}
# Přípona oddělená od názvu mezerou („Tiché místo 2018 1080p CZE cz.forced  mkv“) — nahrávač přišel o tečku.
# „ts“ sem nepatří: na konci názvu bez přípony je to značka zdroje (telesync, „… 2019 CAM TS“), ne kontejner
# (audit Fable F1-V11, 30.09.2026).
_EXT_AFTER_SPACE_RE = re.compile(
    r"\s(%s)$" % "|".join(sorted(e[1:] for e in ALLOWED_VIDEO_EXTS if e != ".ts")), re.I)
# Stránkování Webshare („po dvou stránkách žádné video → stáhni další“) se řídí sadou přípon z doby PŘED
# rozšířením: nová přípona nesmí stahování dalších stránek ukončit dřív (R-A; audit Fable F1-V6).
PAGING_VIDEO_EXTS = frozenset({".mkv", ".mp4", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".webm", ".m4v"})


def sane_item(item: object) -> Optional[dict]:
    """Syrová položka zdroje v tvaru, se kterým filtr počítá: slovník s textovým `ident` a `name`
    a ČÍSELNOU velikostí (nečitelná velikost = 0, o položce rozhodne filtr). None = položku nelze použít."""
    if not isinstance(item, dict):
        return None
    ident, name = item.get("ident"), item.get("name")
    if not ident or not isinstance(name, str) or not name.strip():
        return None
    size = item.get("size", 0)
    if isinstance(size, bool) or not isinstance(size, (int, float)):
        try:
            size = int(float(str(size).strip()))
        except (TypeError, ValueError):
            size = 0
        item = dict(item, size=size)
    if not isinstance(ident, str):
        item = dict(item, ident=str(ident))
    return item

def video_ext_of(name: str) -> str:
    """SSOT: přípona videa v názvu souboru (malými písmeny, s tečkou), nebo "" když název video příponu
    nenese. Bere i příponu oddělenou mezerou místo tečky."""
    nm = str(name or "").strip()
    ext = os.path.splitext(nm)[1].lower()
    if ext in ALLOWED_VIDEO_EXTS:
        return ext
    m = _EXT_AFTER_SPACE_RE.search(nm)
    return ("." + m.group(1).lower()) if m else ""

# ── SSOT normalizace epizodního kódu → (season:int, episode:int) ────────────
# HΦ3 (2026-07-07, analýza H1 §6.3): dřív se kódy porovnávaly jako stripnuté
# STRINGY (`code_re` literal match), takže `s1e01` ≠ `s01e01` → has_code=False
# → správná epizoda zabita (zero-padding bug, Babylon 5). Kanonická dvojice
# sjednocuje s01e01 / s1e01 / 1x01 / 01x01 / s01.e01 / 1x1. Jeden zdroj pravdy
# pro has_code, other_code i ep_token_miss skip.
# Φ-B (30.09.2026, E3-F05/F06): třetí tvar = hybrid „S08x06“ (písmeno S + x). Dřív ho kanonický regex
# neznal: cílový díl zachránil jen doslovný podřetězec a JINÝ díl v tomto tvaru („S12x23“) se nepoznal vůbec.
_CODE_CANON_RE = re.compile(
    r"s0?(\d{1,2})\W*e0?(\d{1,2})|(?<![a-z0-9])0?(\d{1,2})\W*x\W*0?(\d{1,2})(?![a-z0-9])"
    r"|(?<![a-z0-9])s0?(\d{1,2})\W*x\W*0?(\d{1,2})(?![a-z0-9])",
    re.I,
)


def canon_ep_codes(text: str) -> set:
    """Vrátí množinu kanonických (season, episode) dvojic nalezených v textu.
    Prázdná množina = žádný epizodní kód. SSOT — používá filtr i harness."""
    out = set()
    if not text:
        return out
    for m in _CODE_CANON_RE.finditer(text):
        if m.group(1) is not None:
            out.add((int(m.group(1)), int(m.group(2))))
        elif m.group(3) is not None:
            out.add((int(m.group(3)), int(m.group(4))))
        elif m.group(5) is not None:
            out.add((int(m.group(5)), int(m.group(6))))
    return out

# ── Φ5B (29.09.2026, audit A06 F05/R06): kód JINÉHO dílu bez výčtu 20 511 ban tokenů ──────────
# Plugin dřív banoval jiný díl výčtem VŠECH kombinací řada×díl 1–99 ve třech tvarech (`sNNeNN`, `NxNN`,
# `NNxNN`) → jeden regex s 20 511 alternativami, kompilovaný a procházený pro každý dotaz (benchmark
# +1 031 ms / 200 souborů, PC v Kodi 12–16 s na první vlnu seriálu). Tenhle regex pozná PŘESNĚ tytéž
# tokeny (stejné tvary, stejné rozsahy, stejné hranice slov v normalizovaném názvu) — rozhodnutí filtru i
# důvod `other_part` zůstávají; mění se jen cena. Brána: heuristics_replay (cases + validate flip 0).
_OTHER_EP_RE = re.compile(r"(?<![0-9a-z])(?:s(\d{2})e(\d{2})|(\d{1,2})x(\d{2}))(?![0-9a-z])")


def other_episode_code_hit(n_norm: str, target_canon: set, exclude_tokens=()) -> Optional[Tuple[int, str]]:
    """(pozice, token) PRVNÍHO kódu dílu mimo cíl v normalizovaném názvu, nebo None. Čistá, SSOT.

    Tvary a rozsahy = dřívější výčet v `plugin._tv_play` (řada i díl 1–99, cílová dvojice vynechána);
    `exclude_tokens` = tokeny názvu seriálu z TMDb (ban je nikdy nesmí zasáhnout — jako `banned_keys_eff`)."""
    if not n_norm:
        return None
    for m in _OTHER_EP_RE.finditer(n_norm):
        if m.group(1) is not None:
            sn, en = int(m.group(1)), int(m.group(2))
        else:
            sn, en = int(m.group(3)), int(m.group(4))
        if not (1 <= sn <= 99 and 1 <= en <= 99) or (sn, en) in target_canon:
            continue
        tok = m.group(0)
        if tok in exclude_tokens:
            continue
        return m.start(), tok
    return None

# ── HΦ-D (2026-07-07): ban hygiena + sdílené helpery ────────────────────────
# Stopwords a římské číslice, které NESMÍ samostatně banovat (H4: spin_tokens
# banoval přes „the/of/a/ii" → „Černé zrcadlo II" odstřeleno tokenem „ii").
_BAN_STOP = {
    # CZ drobky
    "v", "ve", "s", "z", "na", "do", "u", "o", "a", "i", "se", "k", "ke", "za",
    # EN drobky
    "the", "of", "in", "on", "and", "to", "for", "at", "by", "an", "or",
    # FR/ES/IT drobky
    "de", "le", "la", "du", "el", "los", "las", "il", "un", "una",
}
_ROMAN = {"i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x",
          "xi", "xii", "xiii", "xiv", "xv"}


def _phrase_contains(haystack_norm: str, phrase: str) -> bool:
    """SSOT (HΦ-D P2-3): fráze `phrase` jako sousedící sekvence slov v už
    normalizovaném `haystack_norm`. Nahrazuje 4× opakovaný `f' {x} ' in f' {y} '`
    idiom u nových cest (veto, spin guard). Pre-existující výskyty ponechány
    (neměnit fungující kód bez důvodu)."""
    return f" {phrase} " in f" {haystack_norm} "


def _alpha_word_count(phrase: str) -> int:
    """Počet ČISTĚ ABECEDNÍCH tokenů ve frázi (HΦ-D P2-2 guard sibling veta)."""
    return sum(1 for w in phrase.split() if w.isalpha())


def sanitize_ban_tokens(tokens) -> set:
    """SSOT hygiena ban tokenů (HΦ-D, analýza H4). VÍCESLOVNÉ fráze (sibling
    veto z spin_tokens, „suits la") PROJDOU beze změny — jsou specifické.
    JEDNOSLOVNÉ bany filtruj: musí mít ≥4 znaky, nebýt čistá číslice, stopword
    ani římská číslice — jinak „ii"/„the"/„la"/„of" odstřelovaly správné díly.
    Krátký distinguisher spin-offu („la") kryje víceslovná fráze (HΦ-B)."""
    out = set()
    for t in (tokens or ()):
        if not t:
            continue
        if " " in t:                      # víceslovná fráze — ponech
            out.add(t)
            continue
        tl = t.lower()
        if len(tl) < 4 or tl.isdigit() or tl in _BAN_STOP or tl in _ROMAN:
            continue
        out.add(t)
    return out

# HΦ-D (2026-07-07): franšízový film v epizodním hledání. Odstranění stopword
# banů (hygiena výše) odhalilo, že fallback akceptuje soubory bez epizodního
# kódu jen na shodu seriálových tokenů → Babylon 5 „[Movie 5] The Legend of the
# Rangers", „[Movie 3] The River of Souls" (TV filmy, ne díly) prosákly do
# hledání S01E01. Precizní guard: bracketovaná anotace franšízového filmu s
# pořadovým číslem, na SYROVÉM názvu (norm() závorky strhne). Aplikuje se jen v
# fallbacku (kód nesedí / chybí) u coded-search → nulové riziko false-rejectu
# správných dílů (ty „[Movie N]" nenesou). Generalizuje (Stargate, Babylon…).
_FRANCHISE_FILM_RE = re.compile(r"[\[(]\s*(?:movie|film)\s*\d", re.I)

MIN_FILE_MB_BY_QUALITY = {
    "2160p": 2000, "1080p": 700, "720p": 350,
    "webrip": 300, "other": 250, "cam": 0,
}

MATCH_TOL         = 5      # ± minut pro ★ MATCH
# Φ5B: jak často filtr hlásí pokrok do dialogu („Třídím nalezené (n/N)…“). Film ~800 souborů ≈ 16 kroků;
# častěji by jen zdržovalo (každé hlášení = překreslení dialogu), řidčeji by na TV text stál vteřiny.
FILTER_PROGRESS_EVERY = 50
LEN_TOL_SHORT     = 10
LEN_TOL_LONG      = 40
PROBE_MAX_RESULTS = 15
MAX_WS_RESULTS    = 120

# 2025‑07‑27 23:58 CEST  – úprava: regex zachytí i „_2017_“, „.2011.“
YEAR_RE = re.compile(r"(?<!\d)(19[5-9]\d|20[0-4]\d)(?!\d)")

# Jádro 1.2.0 (15.11.2026, Avengers: Doomsday): `\b` mezi „_“ a písmenem NENÍ hranice slova → `…(2026)_TLR-2_…`,
# `…_TEASER-4_…`, `Dune-Part-Three_IMAX_TRAILER-1_…` prošly a trailer 85 s zapsal ✔ celého filmu. Podtržítko je oddělovač;
# za značkou smí stát číslice (`TRAILER-1`, `TRAILER1`), ne písmeno („trailers“, „clipper“ ne). Přidané `teaser`, `tlr`.
# Slovo, které je součástí NÁZVU hledaného filmu, filtr filmu nezamítá (`bad_word_in_title`, např. film „Teaser“).
_BAD_REGEX_DEFAULT = re.compile(r"(?<![a-z0-9])(trailer|teaser|tlr|sample|clip|preview)(?![a-z])", re.I)

# 2025-08-23 08:43 CEST – rozšíření epizodického regexu pro filmy:
# • zachytí i tvary "01E03" (E místo x) a "s01 e03" (s mezerou),
# • navíc detekuje i případy, kdy po kódu epizody ihned následuje písmeno/slovo (např. "s01 e03Alien").
#   Ostatní logika zůstává NEMĚNNÁ.
# ── filmové epizody (SxxEyy / 01x02[a‑z] / 01E02 / s01 e02) – u filmů je zakážeme úplně ──
# Jádro 1.2.0 (15.11.2026, snímky Trendů „April X“ / „Jasné nebezpečí“ / Akta X): díl s TROJMÍSTNÝM číslem
# (`The Bold and the Beautiful S39E137`, `S01E005_Dárky a jasné nebezpečí`), kód dílu u podtržítka a číslování
# „řada-díl - název“ (`Akta X 01-03 - Hnízdo`, `Akta X 05-06 - Vánoční koleda`) filtr filmu nepoznal. Tvar `SxxEyy`:
# před ním nesmí stát písmeno ani číslice (podtržítko je oddělovač), za ním jakékoli nečíslo. „01-03“ jen když za ním hned
# následuje „ - “ a nejde o rok (1999-2003) ani o delší číslo. Poměry stran 16x9, 21x9 a 4x3 kódem dílu nejsou (audit
# Fable F20 N5; skutečné jméno z korpusu „Zeitgeist 3 (2011) Moving Forward (16x9).mp4“) — „2x1“ ano: poměr 2:1 se do jmen
# souborů nepíše, díl S02E01 často (audit Fable F21 V3). Vědomá cena: díl „4x3“ u filmu téhož jména filtr pustí (dál ho
# skryje délka „časově totálně mimo“, je-li známá) — přednost má nalezený film („horší je, když toho najde málo“).
_BAD_REGEX_MOVIE = re.compile(
    r'(?:'
    r'(?<![a-z0-9])s\d{1,2}\s*e\d{1,3}(?!\d)'
    r'|(?<![a-z0-9])(?!(?:16x9|21x9|4x3)(?![a-z0-9]))'
    r'(?:\d{1,2}x\d{1,2}[a-z]?|\d{1,2}[eE]\d{1,2}[a-z]?)(?![a-z0-9])'
    r'|\b\d{1,2}[eE]\d{1,2}(?=[A-Za-z])'
    r'|(?<![\d-])\d{1,2}-\d{2}(?!\d)(?=\s*-\s)'
    r'|\b(?:NBA|NHL|NFL|EPL)\b'
    r')',
    re.I,
)


def bad_word_in_title(bad_regex: "re.Pattern", plain: str, title_norms) -> bool:
    """Všechny zásahy regexu nežádoucích slov (`trailer`, `clip`…) jsou slova NÁZVU hledaného titulu → nezamítat.
    `title_norms` = normalizované názvy (tokeny oddělené mezerou). Vlastní regex volajícího (bez skupin) se posuzuje stejně."""
    words = {w for t in (title_norms or ()) for w in str(t or "").split() if w}
    if not words:
        return False
    hits = [m.group(0).lower() for m in bad_regex.finditer(plain or "")]
    return bool(hits) and all(h in words for h in hits)

# ─────────────────────────────────────────────────────────────────────────────
#  UTIL FUNKCE – veřejné, aby je mohl používat i plugin.py
# ─────────────────────────────────────────────────────────────────────────────
# Apostrofy v názvech (ASCII, typografický ’ a ‘, akcent ´, modifikátor ʼ, zpětný `). `norm` je rozkládá NEJEDNOTNĚ
# (`'` → mezera, `’` zahodí), proto se pro dotaz bez apostrofu odstraní všechny stejně (15.11.2026).
APOSTROPHES = "'’‘´ʼ`"
_APOSTROPHE_TABLE = {ord(c): None for c in APOSTROPHES}


def strip_apostrophes(s: str) -> str:
    """„The Carpenter's Son“ → „The Carpenters Son“, „Don’t“ → „Dont“. Ostatní text beze změny."""
    return (s or "").translate(_APOSTROPHE_TABLE)


def norm(s: str) -> str:
    """Odstraní diakritiku, lower‑case, ne‑alfa znaky → mezera, kolaps mezer."""
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    s = re.sub(r"[^0-9a-z]+", " ", s.lower()).strip()
    return re.sub(r"\s{2,}", " ", s)

# ––– kompatibilní alias pro staré volání –––
_norm = norm      # ← ⬅⬅⬅  **PŘIDEJTE TENTO ŘÁDEK**


def base_title_key(name: str) -> str:
    """
    Normalizovaný “kořen” názvu bez koncové číslovky/římské číslice.
    Usnadňuje deduplikaci různých releasů téhož filmu.
    """
    key = norm(name)
    key = re.sub(r'\b(?:part|episode|d[ií]l)\s+[0-9ivx]+$', '', key)
    key = re.sub(r'\s+(?:(?:[2-9]|1[0-9])(?!\d)|[ivx]{2,5})$', '', key)
    return re.sub(r'\s+', ' ', key).strip()

# --------------------------------------------------------------------------- #
# 2025‑07‑19 16:27  _is_adult_title() – final FIX (jediná verze v souboru)
# --------------------------------------------------------------------------- #
def _is_adult_title(title: str) -> bool:
    """
    Heuristicky odhadne, zda `title` naznačuje erotický obsah.

    Postup:
    1) Odstraní čtyřciferné roky a kódy SxxEyy / 01x02.
    2) Normalizuje řetězec (bez diakritiky, lowercase, kolaps mezer).
    3) Vrací True, pokud zůstane alespoň jedno erotické klíčové slovo.
    """
    # 1 • čistění
    cleaned = _RE_SXXEYY.sub("", title)
    cleaned = _RE_XXYY.sub("", cleaned)
    cleaned = re.sub(r"\b\d{4}\b", "", cleaned)

    # 2 • normalizace
    title_norm = norm(cleaned)

    # 3 • test klíčových slov
    return any(kw in title_norm for kw in (norm(w) for w in EROTIC_KEYWORDS))

# --------------------------------------------------------------------------- #
#  ADULT / EROTIC FILTER
# --------------------------------------------------------------------------- #
EROTIC_KEYWORDS: set[str] = {
    "porno", "porn", "xxx", "hentai", "bdsm", "lesb", "gay",
    "amateur", "orgasm", "anal", "cum", "cream", "hardcore",
    "fetish", "milf", "teen", "schoolgirl", "gangbang",
    "péčko", "erot", "sex",
}

_RE_SXXEYY = re.compile(r"[Ss]\d{1,2}[Ee]\d{1,2}")
_RE_XXYY   = re.compile(r"\d{1,2}[xX]\d{1,2}")

# --------------------------------------------------------------------------- #
#  _LANG_MAP (upraveno: 14.12.2025 11:50 CET (Europe/Prague) – rozšíření o časté jazyky; opatrně s “it/no/da” kvůli falešným shodám)
# --------------------------------------------------------------------------- #
_LANG_MAP: dict[str, str] = {
    # čeština
    "cz": "CZ", "cs": "CZ", "cze": "CZ", "ces": "CZ",
    "czech": "CZ", "čes": "CZ", "cesky": "CZ", "cestina": "CZ", "čeština": "CZ",

    # slovenština
    "sk": "SK", "slk": "SK", "slo": "SK",
    "slovak": "SK", "slovensky": "SK", "slovenčina": "SK", "slovencina": "SK",

    # angličtina
    "en": "EN", "eng": "EN", "english": "EN",

    # němčina
    "de": "DE", "deu": "DE", "ger": "DE",
    "german": "DE", "deutsch": "DE",

    # francouzština
    "fr": "FR", "fra": "FR", "fre": "FR",
    "french": "FR",

    # španělština
    "es": "ES", "spa": "ES",
    "spanish": "ES", "espanol": "ES",

    # italština (NEPŘIDÁVÁM klíč "it" – je to běžné slovo a dělá falešné shody)
    "ita": "IT", "italian": "IT", "italiano": "IT",

    # portugalština
    "pt": "PT", "por": "PT", "portuguese": "PT",
    "ptbr": "PT", "portugues": "PT",

    # ruština
    "ru": "RU", "rus": "RU", "russian": "RU",

    # polština
    "pl": "PL", "pol": "PL", "polish": "PL",

    # maďarština
    "hu": "HU", "hun": "HU", "hungarian": "HU",

    # japonština
    "ja": "JA", "jpn": "JA", "japanese": "JA",

    # korejština
    "ko": "KO", "kor": "KO", "korean": "KO",

    # čínština
    "zh": "ZH", "zho": "ZH", "chi": "ZH",
    "chinese": "ZH", "mandarin": "ZH", "cantonese": "ZH",

    # arabština
    "ar": "AR", "ara": "AR", "arabic": "AR",

    # hindština (NEPŘIDÁVÁM klíč "hi" – může být slovo; většinou bývá HIN/HINDI)
    "hin": "HI", "hindi": "HI",

    # turečtina
    "tur": "TR", "turkish": "TR",
}


_SUB_HINT = re.compile(r"\b(sub|srt|tit|titulky|titles?)\b", re.I)
_DUB_HINT = re.compile(r"\b(dab|dub|dubbing|audio)\b",       re.I)


# suffixy, které určují typ stopy (audio vs titulky) ve slepeném tvaru „czdab“, „engsub“…
# Φ-C (30.09.2026, E4-F06): vzory předkompilované JEDNOU — dřív se řetězec vzoru skládal a hledal v cache
# `re` u každého slova každého názvu (65 % ceny `enrich`). Vzory jsou tytéž.
_LANG_AUD_SUFFIX = ("dab", "dub", "dubbing", "dabing", "audio")
_LANG_SUB_SUFFIX = ("sub", "subs", "tit", "titulky", "title", "titles", "srt", "vobsub", "ass", "ssa", "idx")
_LANG_AUD_GLUED_RE = re.compile(r"^([a-z]{2,3})(" + "|".join(_LANG_AUD_SUFFIX) + r")$")
_LANG_SUB_GLUED_RE = re.compile(r"^([a-z]{2,3})(" + "|".join(_LANG_SUB_SUFFIX) + r")$")
_LANG_SPLIT_RE = re.compile(r"[\W_]+")


def parse_langs(name: str) -> Tuple[List[str], List[str]]:
    """
    14.12.2025 11:50 CET (Europe/Prague)

    Detekuje ISO kódy jazyků (audio, titulky) v názvu souboru.
    Vrací dvojici `(audios, subs)` – seznamy dvoupísmenných kódů (např. 'CZ','EN','JA'…).

    Zachováno:
      • původní logika přes `_LANG_MAP` + `_SUB_HINT` / `_DUB_HINT`

    Nově:
      • rozpozná i slepené tvary typu:
          - czdab, engdub, jpnsub, korsrt, zhtit …
        a v tom případě rozhodne audio/sub přímo podle suffixu (dab/sub),
        bez globální heuristiky (_SUB_HINT/_DUB_HINT).
    """
    n = (name or "").lower()
    aud, sub = set(), set()

    tokens = [w for w in _LANG_SPLIT_RE.split(n) if w]

    # globální heuristika (stejně jako dřív) – jen pro “čisté” jazykové tokeny
    global_sub_mode = bool(_SUB_HINT.search(n) and not _DUB_HINT.search(n))

    for word in tokens:
        # 1) čistý jazykový token → původní chování
        code = _LANG_MAP.get(word)
        if code:
            if global_sub_mode:
                sub.add(code)
            else:
                aud.add(code)
            continue

        # 2) slepený tvar: <lang><suffix>
        #    např. "czdab" / "jpnsub" / "engsubs" …
        m = _LANG_AUD_GLUED_RE.match(word)
        if m:
            lang_key = m.group(1)
            code2 = _LANG_MAP.get(lang_key)
            if code2:
                aud.add(code2)
            continue

        m = _LANG_SUB_GLUED_RE.match(word)
        if m:
            lang_key = m.group(1)
            code2 = _LANG_MAP.get(lang_key)
            if code2:
                sub.add(code2)
            continue

    return sorted(aud), sorted(sub)





# 2025-09-07 15:14 CEST (Europe/Prague)
def extract_langs_from_mediainfo(mi: dict) -> Tuple[List[str], List[str]]:
    """
    ÚČEL: Z přinesené MediaInfo struktury (výstup WebshareClient.probe_mediainfo)
    vytáhne jazyky AUDIO a SUBTITLE jako dvoupísmenné kódy ('CZ','SK','EN'…),
    konzistentně s parse_langs().

    POZN.: Spoléhá na to, že `mi['tracks']` je seznam slovníků z `to_data()`
    knihovny pymediainfo (klíče jako 'track_type', 'language', 'language_code',
    'other_language', 'title'). Výstupem jsou dvě *seřazené* množiny kódů.
    """
    aud, sub = set(), set()
    try:
        for t in mi.get("tracks", []) or []:
            ttype = (t.get("track_type") or t.get("track type") or "").strip().lower()
            if not ttype:
                continue

            # posbírej všechny kandidáty textů s jazykem
            tokens: set[str] = set()
            for key in ("language", "language_code", "other_language", "title"):
                v = t.get(key)
                if v is None:
                    continue
                if isinstance(v, (list, tuple)):
                    for x in v:
                        tokens |= set(re.split(r"[\W_]+", str(x).strip().lower()))
                else:
                    tokens |= set(re.split(r"[\W_]+", str(v).strip().lower()))

            # namapuj přes stejnou mapu jako parse_langs()
            codes = { _LANG_MAP.get(tok) for tok in tokens if _LANG_MAP.get(tok) }
            if ttype in ("text", "subtitle", "subtitles"):
                sub |= codes
            elif ttype == "audio":
                aud |= codes
    except Exception:
        # jakákoliv anomálie v MI – raději mlčky ignorujeme (bez pádu)
        pass

    return sorted(aud), sorted(sub)






_QUAL_PATTERNS = [
    ("2160p", re.compile(r'(2160p|\b4k\b|\buhd\b)', re.I)),
    ("1080p", re.compile(r'(1080p|full\.?hd)',       re.I)),
    ("720p",  re.compile(r'720p',                    re.I)),
    ("480p",  re.compile(r'(480p|\bsd\b)',           re.I)),
    ("webrip",re.compile(r'(webrip|web[-_.]?dl|hdrip|dvdrip)', re.I)),
    ("cam",   re.compile(r'\b(cam|hd[-_.]?ts|telesync|ts)\b',  re.I)),
]


def quality(name: str) -> str:
    """Heuristicky odhadne kvalitu release (‘2160p’, ‘1080p’, … ‘cam’)."""
    for q, pat in _QUAL_PATTERNS:
        if pat.search(name):
            return q
    return "other"
