# -*- coding: utf-8 -*-
"""rm_core.title_match — shoda názvu titulu se jménem souboru u filmu (SSOT; 15.11.2026, incident R.U.R.).

Proč samostatně: dokud byla shoda vložená ve `filter_movie_items`, zkratka z písmen („R.U.R.“ → `r u r`) se v mírné záloze
pro krátké názvy rozpadla na jedno písmeno „r“ (stop slovo „u“ pryč, `t_min = 1`) a prošel každý soubor se samostatným „r“ —
14.11.2026 tak Chromecast ukázal 58 cizích filmů. Obráceně jméno souboru s proloženými písmeny (`N_o_c_n_i-h_l_i_d_k_a_2004`)
nikdy nesedělo na skutečný titul a „Dont.Move“ nesedělo na „Don't Move“. Plán a data: `Handoff/PLAN_filtr_recall_20261115.md`.

Pravidla (jednoslovné a číselné názvy beze změny):
  1. Jméno souboru (`plain_name`): NFC, úsek ≥ LETTER_RUN_MIN samostatných znaků spojených podtržítkem se slepí
     (`H_a_r_r_y` → `Harry`). Z TÉHOŽ tvaru se čte název, rok, kód dílu i zákaz kolekce (audit Fable F13 V1).
  2. Zkratka z písmen (název jsou jen jednoznakové tokeny, aspoň 2): shoda = písmena za sebou ve jménu (`… r u r …`), mezi
     dvěma písmeny smí stát jedna spojka (`q and a`, `x plus y`); slepený tvar (`rur`, `k9`) jen od 3 znaků nebo s číslicí —
     dvojpísmenné slepeniny jsou běžná slova („W.E.“ ≠ „We“). Nikdy jediné písmeno.
  3. Apostrof: na straně NÁZVU se jednoznakové písmeno zkusí přilepit ke slovu před sebou, jinak za sebou
     (`ocean s eleven` → `oceans eleven`, `wall e` → `walle`, `l enfant` → `lenfant`) — druhá varianta téhož názvu.
     Na straně JMÉNA se lepí jen tam, kde apostrof skutečně byl (`Don't` → `Dont`), nikdy české předložky („Alien s CZ“).
  4. Jinak beze změny (Σ-audit Φ3.15): tokeny ≥ 3 znaky bez čísel a stop slov; když nezbude nic, i krátké a číselné tokeny
     bez stop slov („IT“, „9“, „1917“, „Pí“); ze dvou a více tokenů musí sedět aspoň dva, z jednoho ten jeden.
  5. Název jen ze stop slov („O“, „To“): jméno jím musí ZAČÍNAT a hned za ním rok (dřív nesedělo nikdy).
  6. Číslovka dílu v názvu („The Hunger Games 6“, „Rocky II“, „Kill Bill: Vol. 2“, „Dune: Part Two“, jádro 1.2.1;
     `title_numerals`: arabská kdekoli, římská / slovem jen na konci nebo za slovem dílu) rozhoduje: jméno s JINOU
     číslovkou (ne slovem názvu) a bez té názvu při slabé shodě slov (< 3 zásahy) je jiný díl → varianta nesedí; jinak
     (žádná číslovka, nebo slova sedí silně — pořadí ve franšíze × číslo části) → nanejvýš slabá shoda (nový film jen
     s rokem / délkou, starý projde jako dřív). Číslovka hned za slovem názvu se počítá i z „2.0“ („M3GAN 2.0“). Pravidlo 4 číslice z tokenů shody vyřazuje, takže bez tohoto pravidla
     z „the hunger games 6“ zbylo „hunger games“ = úplná shoda s každým dílem (incident 16.11.2026). Vědomé meze: čísla
     nad 20 („21 / 22 Jump Street“), „i“ / „v“ jako římská (česky spojka / předložka), řadové číslovky („Shrek Třetí“).
Vědomá mez: dvojpísmenná zkratka ze stop slov („A.I.“ jako celý název) sedí i na „… a I …“ uprostřed českého jména — chrání
filtr roku; slepené dvojpísmenné tvary („AI“, „WE“) se neberou (běžná slova).
Čistá standardní knihovna, Python 3.8.
"""
from __future__ import annotations

import re
import unicodedata
from typing import FrozenSet, List, Optional, Sequence, Set, Tuple

from rm_core.text import APOSTROPHES, norm, strip_apostrophes

# Stop slova shody názvu filmu (dřív `_STOP` uvnitř `filter_movie_items`, beze změny obsahu).
TITLE_STOP: FrozenSet[str] = frozenset({
    # CZ
    "v", "ve", "s", "z", "na", "do", "u", "o", "a", "i", "se",
    # EN (základ)
    "the", "of", "in", "on", "and", "to", "for", "at", "by",
    # FR/ES drobky
    "de", "le", "la", "du",
})

# Úsek proložených písmen: aspoň LETTER_RUN_MIN samostatných znaků (písmeno nebo číslice, i s diakritikou) oddělených
# jedním podtržítkem, na obou koncích bez dalšího znaku slova. „Harry_Potter“ (slova) ani „x_264“ (vícemístné číslo) ne.
LETTER_RUN_MIN = 3
_LETTER_RUN_RE = re.compile(r"(?<![^\W_])(?:[^\W_]_){%d,}[^\W_](?![^\W_])" % (LETTER_RUN_MIN - 1))

# Zkratka: mezi dvěma písmeny smí ve jménu stát JEDNA spojka („Q.and.A“, „X plus Y“, „Pat a Mat“ ne — to není zkratka).
ACRONYM_CONNECTORS: FrozenSet[str] = frozenset({"and", "plus", "n", "et", "und", "a"})
# Slepený tvar zkratky platí od 3 znaků, nebo když nese číslici (`k9`); `we`, `us`, `it` jsou běžná slova.
ACRONYM_GLUED_MIN = 3

# Jedna varianta názvu: (tokeny, kolik jich musí sedět, fráze | None). Fráze s `need` 0 = zkratka (rozhoduje pořadí písmen),
# s `need` LEADING_NEED = název jen ze stop slov (jméno jím musí začínat a hned za ním rok).
TitleVariant = Tuple[FrozenSet[str], int, Optional[Tuple[str, ...]]]
LEADING_NEED = -1


def despace_letters(name: str) -> str:
    """Slepí úseky proložených písmen ve jménu souboru: `N_o_c_n_i-h_l_i_d_k_a_2004.avi` → `Nocni-hlidka_2004.avi`.
    Jméno v rozloženém Unicode (NFD, macOS) se nejdřív složí (audit Fable F13 V7). Ostatní text beze změny."""
    if not name:
        return ""
    s = unicodedata.normalize("NFC", name)
    if "_" not in s:
        return s
    return _LETTER_RUN_RE.sub(lambda m: m.group(0).replace("_", ""), s)


def plain_name(name: str) -> str:
    """Jméno souboru, ze kterého filtr čte název, rok, kód dílu i zákaz kolekce (pravidlo 1) — SSOT."""
    return despace_letters(name or "")


def name_norm(name: str) -> str:
    """Normalizované jméno souboru pro shodu s názvem, zákaz kolekce a řazení (SSOT)."""
    return norm(plain_name(name))


def _acronym(tokens: Sequence[str]) -> Optional[Tuple[str, ...]]:
    """Zkratka = aspoň 2 tokeny a všechny jednoznakové (`r u r`, `s w a t`, `9 1 1`, `q a`)."""
    if len(tokens) >= 2 and all(len(w) == 1 for w in tokens):
        return tuple(tokens)
    return None


def _is_word(w: str) -> bool:
    return len(w) >= 2 and w.isalpha()


def _glued(tokens: Sequence[str]) -> List[str]:
    """Strana NÁZVU (pravidlo 3): `norm` udělá z „Don't“ dvojici `don t`, soubor bývá „Dont“. Jednoznakové písmeno se
    přilepí ke slovu (≥ 2 písmena) PŘED sebou (`ocean s` → `oceans`, `wall e` → `walle`), a když před ním slovo není,
    ke slovu ZA sebou (`l enfant` → `lenfant`). Dvě písmena za sebou (zkratka) se nelepí."""
    out: List[str] = []
    pending = ""
    for i, w in enumerate(tokens):
        if len(w) == 1 and w.isalpha():
            if out and not pending and _is_word(out[-1]):
                out[-1] = out[-1] + w
                continue
            nxt = tokens[i + 1] if i + 1 < len(tokens) else ""
            if not pending and _is_word(nxt) and (not out or not _is_word(out[-1])):
                pending = w
                continue
        if pending:
            if _is_word(w):
                out.append(pending + w)
                pending = ""
                continue
            out.append(pending)
            pending = ""
        out.append(w)
    if pending:
        out.append(pending)
    return out


def _word_variant(tokens: Sequence[str]) -> Optional[Tuple[FrozenSet[str], int]]:
    """Tokeny shody a minimum (pravidlo 4). None = název bez použitelného tokenu."""
    strict = {w for w in tokens if w and len(w) >= 3 and not w.isdigit() and w not in TITLE_STOP}
    picked = strict or {w for w in tokens if w and w not in TITLE_STOP}
    if not picked:
        return None
    return frozenset(picked), (2 if len(picked) >= 2 else 1)


def title_variants(title_norm: str) -> List[TitleVariant]:
    """Varianty shody jednoho normalizovaného názvu (pravidla 2–4). Prázdný název = žádná varianta."""
    tokens = [w for w in str(title_norm or "").split() if w]
    if not tokens:
        return []
    acr = _acronym(tokens)
    if acr is not None:
        return [(frozenset(), 0, acr)]
    variants: List[TitleVariant] = []
    for toks in (tokens, _glued(tokens)):
        wv = _word_variant(toks)
        if wv is not None:
            v = (wv[0], wv[1], None)
            if v not in variants:
                variants.append(v)
    if not variants:
        # Název jen ze stop slov („O“ 2001, „To“): dřív nesedělo nikdy (žádný použitelný token) → 0 výsledků. Teď přesně:
        # jméno ZAČÍNÁ celým názvem a hned rokem (`o 2001 …`) — cross-check 2. kola A1-5.4, pravidlo 5.
        variants.append((frozenset(), LEADING_NEED, tuple(tokens)))
    return variants


def _has_acronym(name_tokens: Sequence[str], letters: Sequence[str]) -> bool:
    """Písmena zkratky za sebou ve jménu; mezi dvěma písmeny nejvýš jedna spojka (pravidlo 2)."""
    n = len(letters)
    if n == 0:
        return False
    for start, tok in enumerate(name_tokens):
        if tok != letters[0]:
            continue
        pos, k = start + 1, 1
        while k < n and pos < len(name_tokens):
            if name_tokens[pos] == letters[k]:
                pos, k = pos + 1, k + 1
            elif (name_tokens[pos] in ACRONYM_CONNECTORS and pos + 1 < len(name_tokens)
                  and name_tokens[pos + 1] == letters[k]):
                pos, k = pos + 2, k + 1
            else:
                break
        if k == n:
            return True
    return False


def _glued_acronym_ok(glued: str) -> bool:
    return len(glued) >= ACRONYM_GLUED_MIN or any(ch.isdigit() for ch in glued)


def glued_acronym(letters: Sequence[str]) -> Optional[str]:
    """Slepený tvar zkratky (`s w a t` → `swat`), jen když platí pravidlo 2 (≥ 3 znaky nebo číslice); jinak None.
    Pro filtr dílu (`filter_tv` — přísné pravidlo krátkého názvu seriálu)."""
    if _acronym(letters) is None:
        return None
    glued = "".join(letters)
    return glued if _glued_acronym_ok(glued) else None


def is_acronym(letters: Sequence[str]) -> bool:
    """Je normalizovaný název (tokeny) zkratka z písmen? Veřejně pro filtr dílu (`filter_tv`, BACKLOG S58)."""
    return _acronym(letters) is not None


def acronym_hit(letters: Sequence[str], name_tokens: Sequence[str], name_words: Set[str]) -> Tuple[bool, Set[str]]:
    """Shoda zkratky (pravidlo 2) — JEDINÁ definice pro film i díl: slepená (`swat`, `k9`) nebo písmena za sebou
    s nejvýš jednou spojkou mezi nimi. Vrací (shoda, zasažené tokeny pro log)."""
    glued = "".join(letters)
    if _glued_acronym_ok(glued) and glued in name_words:
        return True, {glued}
    if _has_acronym(name_tokens, letters):
        return True, set(letters)
    return False, set()


def _leading_with_year(name_tokens: Sequence[str], phrase: Sequence[str]) -> bool:
    n = len(phrase)
    if n == 0 or len(name_tokens) <= n or tuple(name_tokens[:n]) != tuple(phrase):
        return False
    nxt = name_tokens[n]
    return len(nxt) == 4 and nxt.isdigit()


def variant_hits(variant: TitleVariant, name_tokens: Sequence[str], name_words: Set[str]) -> Tuple[bool, Set[str]]:
    """Sedí varianta na jméno souboru? Vrací (shoda, zasažené tokeny pro log)."""
    toks, need, acr = variant
    if acr is not None and need == LEADING_NEED:
        return (True, set(acr)) if _leading_with_year(name_tokens, acr) else (False, set())
    if acr is not None:
        return acronym_hit(acr, name_tokens, name_words)
    hits = {w for w in toks if w in name_words}
    return len(hits) >= need, hits


def name_tokens_of(name: str) -> Tuple[List[str], Set[str]]:
    """(tokeny jména v pořadí, množina slov pro shodu). Slova navíc z tvaru BEZ apostrofu — jen když jméno apostrof nese
    (`Don't.Move` → i `dont`; název s typografickým `’` je po `norm` slepený). Nikdy z jiných jednopísmenných tokenů."""
    plain = plain_name(name)
    tokens = [w for w in norm(plain).split() if w]
    words = set(tokens)
    if any(c in plain for c in APOSTROPHES):
        words |= set(norm(strip_apostrophes(plain)).split())
    return tokens, words


# ── Úroveň shody (jádro 1.2.0, 15.11.2026) ─────────────────────────────────────────────────────────────────────────────
# Incidenty: „Ebenezer: Vánoční koleda“ (snímek Trendů 20 souborů, ani jeden ten film — „Vánoční koleda u Černé zmije“,
# Akta X, Mickey…), „Hunger Games: Úsvit sklizně“ (díly 1–3 a Balada bez roku), „Predátor: Nebezpečné území“ („14 -
# Nebezpečné území.avi“), Gabriel / „Anděl pomsty“. Společný kořen: pravidlo 4 bere u názvu se ≥ 3 tokeny shodu už ve DVOU
# slovech — a chybějící slovo bývá právě to rozlišující (hlava před dvojtečkou nebo podtitul).
# Měřeno nad korpusem `heuristics_replay` (3 718 přijatých filmových streamů): shoda přesně na minimu 2 tokenů bez povoleného
# roku = 59 streamů, z toho skutečný film jen 7 — všechny se slovem napsaným jinak (slovensky „Diabol / Ďábel“, „Prsteňov“,
# „Čiernej“, překlep „Kingsmann“), nikdy se slovem chybějícím. Proto:
#   • `MATCH_FULL`  — varianta celá, zkratka, název ze stop slov, NEBO ≥ 3 zasažené tokeny, NEBO chybějící token má ve jménu
#                     slovo se stejnou KOSTROU SOUHLÁSEK (`consonant_skeleton`: CZ ↔ SK pravopis, zdvojené písmeno);
#   • `MATCH_WEAK`  — jen minimum 2 tokenů z ≥ 3 a chybějící tokeny ve jménu nemají ani kostru, ani číslovku v jiném
#                     zápisu → filtr filmu ji u NOVÉHO filmu (rok filmu ≥ letos − 1) pustí jen s potvrzením (povolený rok
#                     ve jménu, nebo délka ze zdroje ±5 % — `filter_movie`, důvod `title_weak`); u staršího filmu projde
#                     jako v 1.1.0 (audit Fable F18 V1: „Limonadovy Joe CZ.avi“, „Harry Potter 1“, staré ripy bez roku —
#                     recall se nesmí ztratit, Richie 29.09.2026). Balast ze zadání byl vždy u filmu z letošního roku.
MATCH_FULL = "full"
MATCH_WEAK = "weak"
#: Silná částečná shoda: tolik zasažených tokenů už rozlišuje (dnes nejvíc 2 z „hlavy“ franšízy nebo z podtitulu).
STRONG_HITS_MIN = 3
#: Kostra souhlásek: jen tokeny aspoň této délky a kostra aspoň SKELETON_MIN souhlásek (krátká slova by sedla náhodou).
SKELETON_TOKEN_MIN = 5
SKELETON_MIN = 3
_VOWELS = frozenset("aeiouy")


def consonant_skeleton(word: str) -> str:
    """Souhlásky slova bez samohlásek a bez zdvojení (`kingsmann` → `kngsmn`, `diabol` / `dabel` → `dbl`,
    `cierne` / `cerne` → `crn`). Vstup = normalizovaný token (bez diakritiky, malá písmena)."""
    out: List[str] = []
    for ch in word:
        if ch in _VOWELS or not ch.isalpha():
            continue
        if out and out[-1] == ch:
            continue
        out.append(ch)
    return "".join(out)


# Číslovka zapsaná jinak (audit Fable F18 V1: „Mission Impossible 3“ pro „Mission: Impossible III“, „7 let v Tibetu“ pro
# „Sedm let v Tibetu“): římská (od 2 znaků — „i“ a „v“ jsou česky spojka a předložka), arabská, slovem česky / slovensky /
# anglicky 1–20. Chybějící token názvu s číselnou hodnotou je zasažený, když jméno nese tutéž hodnotu v jiném zápisu.
_ROMAN = {"ii": 2, "iii": 3, "iv": 4, "vi": 6, "vii": 7, "viii": 8, "ix": 9, "xi": 11, "xii": 12, "xiii": 13,
          "xiv": 14, "xv": 15, "xvi": 16, "xvii": 17, "xviii": 18, "xix": 19, "xx": 20}
_NUM_WORDS = {
    "jedna": 1, "jeden": 1, "dva": 2, "dve": 2, "tri": 3, "ctyri": 4, "styri": 4, "pet": 5, "sest": 6, "sedm": 7,
    "sedem": 7, "osm": 8, "osem": 8, "devet": 9, "deset": 10, "desat": 10, "jedenact": 11, "dvanact": 12, "trinact": 13,
    "ctrnact": 14, "patnact": 15, "sestnact": 16, "sedmnact": 17, "osmnact": 18, "devatenact": 19,
    "strnast": 14, "patnast": 15, "sestnast": 16, "sedemnast": 17, "osemnast": 18, "devatnast": 19,
    "dvacet": 20, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
    "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16,
    "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20,
}


def numeral_value(word: str) -> Optional[int]:
    """Hodnota tokenu jako číslovky 1–20 (arabsky, římsky od 2 znaků, slovem); jinak None."""
    if word.isdigit():
        v = int(word)
        return v if 0 < v <= 20 and len(word) <= 2 else None
    return _ROMAN.get(word) or _NUM_WORDS.get(word)


# Čísla ve jménu, která NEJSOU číslovkou názvu: rozložení zvukových kanálů („5.1“, „7.1“, „2.0“) a nosič („CD 3“, „disk 1“)
# — „Noci u Freddyho DD 5.1“ by jinak doplnilo chybějící „pět“ (audit Fable F20 N7). Jen ZNÁMÁ rozložení kanálů (druhá
# číslice 0 / 1): v tečkovaném jménu „Mission.Impossible.3.5.1“ se vyřízne „5.1“, číslovka „3“ zůstane. „Part N“ se NEvyřezává
# — bývá dílem NÁZVU („Dune: Part Three“ × „Dune Part 3 CZ.mkv“), ne značkou děleného souboru (audit Fable F21 V1).
# Jádro 1.2.1 (pravidlo 6 — číslovka NAVÍC ve jménu teď shodu ruší): dál se nevezme bitová hloubka („10-bit“), AC-3 / E-AC-3,
# rozložení kanálů zapsané mezerou za kodekem („Atmos 7 1“, „DTS-HD 5 1“), značka kopie / úseku před příponou („(1).avi“),
# velikost souboru („1.4GB“, „700 MB“) a počet nosičů PŘED značkou („2 CD“, „2 DVD“).
_NOT_NUMERAL_RE = re.compile(
    r"(?<![0-9])[1-7][.,][01](?![0-9])|(?<![a-z0-9])(?:cd|dis[ck])[\s._-]*[0-9]{1,2}(?![0-9])"
    r"|(?<![0-9])(?:8|10|12)[\s._-]?bit(?![a-z])"
    r"|(?<![a-z0-9])e?-?ac-?3(?![0-9])"
    r"|(?<![a-z0-9])(?:atmos|truehd|dts(?:[\s._-]?(?:hd|ma|x))?|ddp?|aac|flac|opus|l?pcm)[\s._-]*[1-7][\s._][01](?![0-9])"
    r"|\(\s*[0-9]{1,2}\s*\)(?=\.[a-z0-9]{2,4}$)"
    r"|(?<![0-9.,])[0-9]{1,2}(?:[.,][0-9]{1,3})?[\s._-]*[gmk]i?b(?![a-z])"
    r"|(?<![0-9])[0-9]{1,2}[\s._-]*(?:cd|dvd)s?(?![a-z0-9])",
    re.I)


def _numeral_tokens(name: str) -> List[Tuple[str, int]]:
    """(token, hodnota) číslovek 1–20 ve jménu souboru po vyříznutí čísel, která dílem nejsou (`_NOT_NUMERAL_RE`)."""
    cleaned = _NOT_NUMERAL_RE.sub(" ", plain_name(name))
    out: List[Tuple[str, int]] = []
    for w in norm(cleaned).split():
        v = numeral_value(w) if w else None
        if v is not None:
            out.append((w, v))
    return out


def name_numerals(name: str) -> Set[int]:
    """Číslovky 1–20 ve jménu souboru (bez rozložení zvukových kanálů a čísla nosiče CD / disk)."""
    return {v for _w, v in _numeral_tokens(name)}


#: Slovo před číslovkou dílu („Part II“, „Epizoda IV“, „Vol. 2“, „Část 3“) — římská / slovem tam platí i uprostřed názvu.
_PART_WORDS: FrozenSet[str] = frozenset({
    "part", "pt", "vol", "volume", "chapter", "episode", "book", "cast", "dil", "diel", "kapitola", "epizoda", "kniha",
})


def title_part_numerals(title_norm: str) -> FrozenSet[int]:
    """Číslovky názvu hned ZA slovem dílu nebo PŘED ním („Part II“, „Vol. 2“, česky „1. část“) = číslo ČÁSTI, ne pořadí
    ve franšíze — jiná číslovka ve jménu („Hunger games 3“ u „Síla vzdoru 1. část“) je pak pořadí franšízy, ne jiný díl
    (audit Fable F27 N1)."""
    toks = [w for w in str(title_norm or "").split() if w]
    out = set()
    for i, w in enumerate(toks):
        v = numeral_value(w)
        if v is None:
            continue
        if (i > 0 and toks[i - 1] in _PART_WORDS) or (i + 1 < len(toks) and toks[i + 1] in _PART_WORDS):
            out.add(v)
    return frozenset(out)


def title_numerals(title_norm: str) -> FrozenSet[int]:
    """Číslovky dílu v normalizovaném NÁZVU pro pravidlo 6: arabská 1–20 kdekoli; římská (od 2 znaků) a slovem jen jako
    POSLEDNÍ slovo názvu nebo hned za slovem dílu (`_PART_WORDS`). Slovo uprostřed bývá běžné slovo nebo součást názvu
    („Ten, kdo…“ = 10, „One Battle After Another“ = 1, „Sedm let v Tibetu“) — číslovkou dílu není (cross-check Flash 16.11.)."""
    toks = [w for w in str(title_norm or "").split() if w]
    out = set()
    for i, w in enumerate(toks):
        v = numeral_value(w)
        if v is None:
            continue
        if w.isdigit() or i == len(toks) - 1 or (i > 0 and toks[i - 1] in _PART_WORDS):
            out.add(v)
    return frozenset(out)


def _skeleton_rescue(missing: Set[str], name_words: Set[str], name_nums: Optional[Set[int]] = None) -> Set[str]:
    """Chybějící tokeny názvu, které jméno nese jinak napsané: stejná kostra souhlásek (CZ ↔ SK, překlep), nebo tatáž
    číslovka v jiném zápisu (iii ↔ 3, sedm ↔ 7; `name_nums` = `name_numerals`). Prázdné = nic."""
    out: Set[str] = set()
    if name_nums is None:
        name_nums = {numeral_value(w) for w in name_words} - {None}
    for w in missing:
        v = numeral_value(w)
        if v is not None and v in name_nums:
            out.add(w)
    cands = [w for w in missing if len(w) >= SKELETON_TOKEN_MIN and not w.isdigit() and w not in out]
    if not cands:
        return out
    sk_name = {consonant_skeleton(w) for w in name_words if len(w) >= SKELETON_TOKEN_MIN - 1 and not w.isdigit()}
    for w in cands:
        sk = consonant_skeleton(w)
        if len(sk) >= SKELETON_MIN and sk in sk_name:
            out.add(w)
    return out


def _title_numeral_present(t_nums: FrozenSet[int], num_toks: Sequence[Tuple[str, int]], name_tokens: Sequence[str],
                           t_words: Set[str]) -> bool:
    """Nese jméno číslovku dílu názvu? Po vyříznutí čísel, která dílem nejsou, NEBO hned za slovem názvu i tam, kde ji
    výjimka vyřízla („M3GAN 2.0“, „Hunger.Games.6.1“ — audit Fable F26 V3)."""
    if any(v in t_nums for _w, v in num_toks):
        return True
    for i in range(1, len(name_tokens)):
        if name_tokens[i - 1] in t_words and numeral_value(name_tokens[i]) in t_nums:
            return True
    return False


def match_title_level(title_norms: Sequence[str], name: str) -> Tuple[Optional[str], Set[str], Set[str]]:
    """Úroveň shody jména souboru s ALESPOŇ jedním názvem titulu: (`MATCH_FULL` | `MATCH_WEAK` | None, zasažené tokeny,
    všechny tokeny dotazu). Úplná shoda kterékoli varianty vyhrává nad slabou shodou jiné varianty."""
    name_tokens, name_words = name_tokens_of(name)
    num_toks = _numeral_tokens(name)
    name_nums = {v for _w, v in num_toks}
    all_tokens: Set[str] = set()
    best: Set[str] = set()
    weak = False
    for t in (title_norms or ()):
        t_nums = title_numerals(t)
        t_words = set(str(t or "").split())
        # hodnoty slov názvu (i „pět“ = 5) a číslovky pořadí (ne čísla části) — F27 N1, N4
        t_word_vals = {val for val in (numeral_value(w) for w in t_words) if val is not None}
        t_order_nums = t_nums - title_part_numerals(t)
        for v in title_variants(t):
            toks, _need, acr = v
            all_tokens |= (set(acr) if acr is not None else set(toks))
            ok, hits = variant_hits(v, name_tokens, name_words)
            best |= hits
            if not ok:
                continue
            if acr is None and t_nums and not _title_numeral_present(t_nums, num_toks, name_tokens, t_words):
                # Pravidlo 6 (jádro 1.2.1, incident 16.11.2026 „Hunger Games: Úsvit sklizně“ × alt. název „The Hunger
                # Games 6“): číslovka dílu názvu ve jménu chybí. JINÁ číslovka (ne slovo názvu ani jeho hodnota — „pět“ / „5“
                # u „Pět nocí…“, F26 V4, F27 N4) u číslovky POŘADÍ (ne čísla části — „část 1“ × „Hunger games 3“, F27 N1)
                # při slabé shodě slov = jiný díl → varianta nesedí; jinak (žádná číslovka, slova sedí silně — „Hunger
                # Games 3 Síla vzdoru“ u „…1. část“, „Harry Potter 7“, F26 V2 — nebo jen číslo části) = slabá shoda.
                other = any(w not in t_words and v_ not in t_word_vals for w, v_ in num_toks)
                if not (other and t_order_nums and len(hits) < STRONG_HITS_MIN):
                    weak = True
                continue
            if acr is not None or hits >= set(toks) or len(hits) >= STRONG_HITS_MIN:
                return MATCH_FULL, best, all_tokens
            if _skeleton_rescue(set(toks) - hits, name_words, name_nums):
                return MATCH_FULL, best, all_tokens
            weak = True
    return (MATCH_WEAK if weak else None), best, all_tokens


def match_title(title_norms: Sequence[str], name: str) -> Tuple[bool, Set[str], Set[str]]:
    """Projde jméno souboru (`name` = jméno, jak ho vrátil zdroj) shodou s ALESPOŇ jedním názvem titulu (úplnou nebo
    slabou)? Vrací (shoda, zasažené tokeny, všechny tokeny dotazu) — poslední dvě jen pro log `token_miss`."""
    level, best, all_tokens = match_title_level(title_norms, name)
    return level is not None, best, all_tokens
