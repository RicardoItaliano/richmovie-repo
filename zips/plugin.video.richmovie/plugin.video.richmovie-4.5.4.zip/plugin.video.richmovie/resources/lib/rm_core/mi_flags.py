# -*- coding: utf-8 -*-
"""rm_core.mi_flags — převod MediaInfo → flags streamu (přesun 1 : 1 z `richmovie_engine`, G1).

Normalizace jazyků a merge polí používá `mi2_publish` v doplňku i Gate nad řádkem z tabulky MediaInfo.
Čistá standardní knihovna."""
from __future__ import annotations

import re
from typing import Any, Iterable


def _mi2_norm_code(token: str) -> str:
    """
    14.12.2025 11:50 CET (Europe/Prague)

    Normalizace jazyků z MI2/MediaInfo na dvoupísmenné kódy pro UI:
      CZ, SK, EN, DE, FR, ES, IT, PL, RU, HU, PT, JA, KO, ZH, AR, HI, TR, …
    """
    s = (token or "").strip()
    if not s:
        return ""

    up = s.upper()

    # různé „ne-jazykové“ tokeny, které se objevují v metadata
    if up in {"FULL", "DEFAULT", "UND", "UNKNOWN"}:
        return ""

    # forced titulky
    if "FORCED" in up or up == "FU":
        return "FU"

    # Czech – ISO 639-1 je CS, ale v UI chceme CZ
    if re.search(r"\b(CZ|CZE|CES)\b", up) or ("CZECH" in up) or re.search(r"\bCS\b", up):
        return "CZ"

    # Slovak
    if re.search(r"\b(SK|SLK|SLO)\b", up) or ("SLOVAK" in up) or ("SLOVEN" in up):
        return "SK"

    # English
    if re.search(r"\b(EN|ENG)\b", up) or ("ENGLISH" in up):
        return "EN"

    # German
    if re.search(r"\b(DE|DEU|GER)\b", up) or ("GERMAN" in up):
        return "DE"

    # French / Spanish / Italian / Portuguese
    if re.search(r"\b(FR|FRA|FRE)\b", up) or ("FRENCH" in up):   return "FR"
    if re.search(r"\b(ES|SPA)\b", up) or ("SPANISH" in up):      return "ES"
    if re.search(r"\b(IT|ITA)\b", up) or ("ITALIAN" in up):      return "IT"
    if re.search(r"\b(PT|POR)\b", up) or ("PORTUG" in up):       return "PT"

    # Polish / Russian / Hungarian
    if re.search(r"\b(PL|POL)\b", up) or ("POLISH" in up):       return "PL"
    if re.search(r"\b(RU|RUS)\b", up) or ("RUSSIAN" in up):      return "RU"
    if re.search(r"\b(HU|HUN)\b", up) or ("HUNGAR" in up):       return "HU"

    # Japanese / Korean / Chinese
    if re.search(r"\b(JA|JPN)\b", up) or ("JAPAN" in up):        return "JA"
    if re.search(r"\b(KO|KOR)\b", up) or ("KOREAN" in up):       return "KO"
    if re.search(r"\b(ZH|ZHO|CHI)\b", up) or ("CHINESE" in up) or ("MANDARIN" in up):
        return "ZH"

    # Arabic / Hindi / Turkish
    if re.search(r"\b(AR|ARA)\b", up) or ("ARAB" in up):         return "AR"
    if re.search(r"\b(HI|HIN)\b", up) or ("HINDI" in up):        return "HI"
    if re.search(r"\b(TR|TUR)\b", up) or ("TURK" in up):         return "TR"

    # fallback: pokud obsahuje aspoň 2 písmena v kuse, vezmi první dvě
    m = re.search(r"[A-Z]{2}", up)
    return m.group(0) if m else ""


def normalize_mi_fields(aud_langs: Iterable[str] = (), sub_langs: Iterable[str] = (), video_w: Any = None,
                        video_h: Any = None, duration_s: Any = None, hdr: Any = None, dv_profile: Any = None,
                        dv_compat: Any = None) -> dict:
    """Normalizace vstupu MediaInfo (doplněk: `mi2_publish`, Gate: tabulka MediaInfo) na hodnoty pro `merge_flags`."""
    try:
        aud = {_mi2_norm_code(str(s)) for s in (aud_langs or ()) if s}
        sub = {_mi2_norm_code(str(s)) for s in (sub_langs or ()) if s}
        aud.discard("")
        sub.discard("")
    except Exception:
        aud, sub = set(), set()

    # --- video rozměry ---
    try:
        vw = int(video_w) if isinstance(video_w, (int, float)) and int(video_w) > 0 else None
    except Exception:
        vw = None
    try:
        vh = int(video_h) if isinstance(video_h, (int, float)) and int(video_h) > 0 else None
    except Exception:
        vh = None

    # --- duration (sekundy) ---
    try:
        ds = int(duration_s) if isinstance(duration_s, (int, float)) and int(duration_s) > 0 else None
    except Exception:
        ds = None

    # --- Dolby Vision / HDR (Φ3) — jen známé hodnoty, krátké řetězce ---
    hdr_v = str(hdr or "").strip().upper()[:12] or None
    try:
        dvp = int(dv_profile) if dv_profile is not None and 0 <= int(dv_profile) <= 20 else None
    except (TypeError, ValueError):
        dvp = None
    dvc = str(dv_compat or "").strip().lower()[:12] or None

    return {"aud": aud, "sub": sub, "vw": vw, "vh": vh, "ds": ds, "hdr_v": hdr_v, "dvp": dvp, "dvc": dvc}


def merge_flags(new_val: dict, aud: Any, sub: Any, sub_present: Any, vw: Any, vh: Any, hdr_v: Any, dvp: Any, dvc: Any,
                ds: Any) -> None:
    """Zapíše do záznamu MediaInfo jen to, co víme („nevím“ nepřepisuje ani nemaže)."""
    # --- Audio: zapisuj jen když něco víme (jinak “nevím” nepřepisujeme) ---
    if aud:
        new_val["aud"] = sorted(aud)
        new_val["cz_dub"] = ("CZ" in aud)

    # --- Subtitles: sub_present je klíčové pro “jistě nejsou” ---
    if sub_present is False:
        new_val["sub_present"] = False
        new_val["sub"] = []
        new_val["cz_sub"] = False
    elif sub_present is True:
        prev_sub_present = new_val.get("sub_present", None)
        new_val["sub_present"] = True

        if sub:
            new_val["sub"] = sorted(sub)
            new_val["cz_sub"] = ("CZ" in sub)
        else:
            # titulky existují, ale jazyk jsme nevytáhli → nesmíme tvrdit “ne”
            if prev_sub_present is False:
                new_val["sub"] = []
                if "cz_sub" in new_val:
                    try:
                        del new_val["cz_sub"]
                    except Exception:
                        pass

    # --- Video: merge (nikdy nemažeme) ---
    if vw:
        new_val["video_w"] = vw
    if vh:
        new_val["video_h"] = vh
    if hdr_v:
        new_val["hdr"] = hdr_v
    if dvp is not None:
        new_val["dv_profile"] = dvp
    if dvc:
        new_val["dv_compat"] = dvc

    # --- Duration: merge (nikdy nemažeme; “nevím” nepřepisuje) ---
    if ds:
        new_val["duration_s"] = ds


def build_flags(aud_langs: Iterable[str] = (), sub_langs: Iterable[str] = (), *, video_w: Any = None,
                video_h: Any = None, duration_s: Any = None, sub_present: Any = None, hdr: Any = None,
                dv_profile: Any = None, dv_compat: Any = None) -> dict:
    """Nový záznam MediaInfo (flags) ve tvaru `mi2_get_flags` — pro Gate nad řádkem z jeho databáze."""
    f = normalize_mi_fields(aud_langs, sub_langs, video_w, video_h, duration_s, hdr, dv_profile, dv_compat)
    out: dict = {}
    merge_flags(out, f["aud"], f["sub"], sub_present, f["vw"], f["vh"], f["hdr_v"], f["dvp"], f["dvc"], f["ds"])
    return out
