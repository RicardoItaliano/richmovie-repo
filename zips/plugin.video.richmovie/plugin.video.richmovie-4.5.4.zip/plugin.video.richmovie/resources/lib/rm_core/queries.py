# -*- coding: utf-8 -*-
"""rm_core.queries — stavba dotazů pro zdroje (Webshare, Fastshare): seriály (`QueryBuilder`) a filmy
(`query_variants`). Čistá standardní knihovna. Přesun 1 : 1 (G1); dotazy Fastshare viz `fastshare_term`.
"""
from __future__ import annotations

import re
import unicodedata
from collections import OrderedDict
from itertools import permutations
from typing import List, Optional, Sequence, Set, Tuple

from rm_core.text import GENERIC_EP, strip_apostrophes

# ── ALT-TITLE FALLBACK KONSTANTY ───────────────────────────────────────
_ALT_THRESHOLD           = 4      # kolik releasů stačí k ukončení fallbacku
_ALT_MAX_TITLES          = 6      # max. alternativních názvů, které zkoušíme
_ALT_COUNTRY_WHITELIST   = {"CZ", "SK", "US", "GB", "CA", "PL", "RU", "IT"}
_NON_LATIN_RE            = re.compile(r"[\u0400-\u04FF\u4E00-\u9FFF]")


# --------------------------------------------------------------------------- #
# 2025‑07‑20 10:45 CEST  class QueryBuilder  – centrální generátor dotazů
# --------------------------------------------------------------------------- #
class QueryBuilder:
    """
    **Jediné místo**, kde se sestavují vyhledávací řetězce pro Webshare.

    ▸ *Bez* závislosti na Kodi ani Webshare SDK  
    ▸ Vrací **list** v pořadí, jak bylo požadováno, ale se 100 % deduplikací  
    ▸ Metoda `tv()` implementuje všech 26 variant z vašeho scénáře  
      („S04E06 Window of Opportunity“, „Stargate SG‑1 4x06“, …)  
    ▸ Dotazy FILMU staví `richmovie_movie_search.query_variants` (zde jen seriály).
    """

    # ––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––––
    @staticmethod
    def _unique_seq() -> tuple[list[str], set[str]]:
        """Pomocný factory: (ordered list, seen‑set)."""
        return ([], set())




    # ---------------------------------- METODA ---------------------------------- #
    # richmovie_engine.py › class QueryBuilder
    # tv (upraveno: 13.12.2025 21:33 CET (Europe/Prague) – Vlna 1 = celý název seriálu + kód; Vlna 2 = epizodní název / kód-napřed; Vlna 3 = další aliasy; “pilot” nikdy)
    # ---------------------------------------------------------------------------- #
    @staticmethod
    def tv(
        tv_names: Sequence[str],
        ep_names: Sequence[str],
        season: int,
        episode: int,
    ) -> list[str]:
        """
        Sestaví **unikátní** sadu dotazů pro TV epizodu.

        DŮLEŽITÉ (co se mění proti staré verzi):
          • První vlna už NENÍ "s01e03 Pri" / "s01e03 Útě".
            První vlna je vždy: "<celý název seriálu> + (SxxEyy / 1xYY / 01xYY)".
          • “pilot” v dotazech nikdy (ani “pilotní”).
          • Dotazy jsou seřazené tak, aby plugin.py mohl bezpečně řezat po blocích 6/6/6:
              - queries[0:6]   = Vlna 1 (nejpřísnější, nejjistější)
              - queries[6:12]  = Vlna 2 (ep title / kód-napřed)
              - queries[12:18] = Vlna 3 (další aliasy seriálu + kód; fallback short-token)
              - queries[18:]   = “soft” dotazy (jen když je opravdu málo výsledků)

        Pozn.: Pokud je k dispozici jen 1 seriálový název, nebo chybí epizodní názvy,
        některé bloky budou kratší – plugin slicing to zvládne. Priorita pořád platí.
        """

        # --- lokální helpery -------------------------------------------------
        def _short_token(name: str) -> str:
            """První 2–3 písmena z 1. slova – fallback až do pozdějších vln."""
            m = re.match(r"\w{2,3}", name)
            return m.group(0) if m else ""

        def _is_generic(ep: str) -> bool:
            """Je epizodní název příliš obecný (Epizoda 1, Episode 1, apod.)?"""
            for w in re.split(r"[^\w]+", ep.lower()):
                if w.isdigit():
                    return True
                if w in GENERIC_EP:  # obsahuje mj. "pilot", "pilotní" apod.
                    return True
            return False

        def _has_pilot(ep: str) -> bool:
            """Obsahuje název epizody zakázané slovo 'pilot' (vč. 'pilotní')?"""
            for w in re.split(r"[^\w]+", ep.lower()):
                if w in {"pilot", "pilotni", "pilotní"}:
                    return True
            return False

        # --- příprava aliasů -------------------------------------------------
        tv_names = [t.strip() for t in tv_names if t and t.strip()]
        ep_names = [e.strip() for e in ep_names if e and e.strip()]

        # dedupe (case-insensitive), zachovej pořadí
        _seen_tv: set[str] = set()
        _tv_u: list[str] = []
        for t in tv_names:
            k = t.casefold()
            if k in _seen_tv:
                continue
            _seen_tv.add(k)
            _tv_u.append(t)
        tv_names = _tv_u

        _seen_ep: set[str] = set()
        _ep_u: list[str] = []
        for e in ep_names:
            k = e.casefold()
            if k in _seen_ep:
                continue
            _seen_ep.add(k)
            _ep_u.append(e)
        ep_names = _ep_u

        # Klíčové: *vyřadíme* jakékoliv epizodní názvy obsahující "pilot"
        ep_names_no_pilot = [e for e in ep_names if not _has_pilot(e)]
        ep_names_non_generic = [e for e in ep_names_no_pilot if not _is_generic(e)]

        # --- kódy epizody ----------------------------------------------------
        sxe  = f"s{season:02d}e{episode:02d}"
        xep1 = f"{season}x{episode:02d}"
        xep2 = f"{season:02d}x{episode:02d}"
        codes = (sxe, xep1, xep2)

        # Rozdělení aliasů:
        #   • primární = první 2 názvy (typicky CZ + EN/orig)
        #   • alternativní = zbytek
        primary_tv = tv_names[:2]
        alt_tv_all = tv_names[2:]

        # --- sestavení vln ---------------------------------------------------
        wave1: list[str] = []
        wave2: list[str] = []
        wave3: list[str] = []
        wave4: list[str] = []

        # VLNA 1 (6): <celý seriál> + kód
        for ser in primary_tv:
            for code in codes:
                wave1.append(f"{ser} {code}")

        # VLNA 2 (6): <celý seriál> + epizodní název (nejlepší 1–3) + doplnění “kód-napřed”
        for ser in primary_tv:
            for ep in ep_names_non_generic[:3]:
                wave2.append(f"{ser} {ep}")

        # doplň do 6: kód-napřed (někdy Webshare líp matchuje, když je kód na začátku)
        if len(wave2) < 6:
            for code in codes:
                for ser in primary_tv:
                    wave2.append(f"{code} {ser}")
                    if len(wave2) >= 6:
                        break
                if len(wave2) >= 6:
                    break

        # VLNA 3 (6): další aliasy seriálu + kód (max 2 aliasy → 6 dotazů)
        for ser in alt_tv_all[:2]:
            for code in codes:
                wave3.append(f"{ser} {code}")

        # Pokud nemáme dost alternativních aliasů, doplň fallback short-token dotazy (poslední záchrana přísné části)
        if len(wave3) < 6:
            _tok_seen: set[str] = set()
            for nm in tv_names:
                tok = _short_token(nm)
                if not tok or tok in _tok_seen:
                    continue
                _tok_seen.add(tok)
                for code in codes:
                    wave3.append(f"{code} {tok}")
                    if len(wave3) >= 6:
                        break
                if len(wave3) >= 6:
                    break

        # VLNA 4 (soft, jen když je opravdu málo výsledků):
        #  • zbytek alternativních aliasů + kód
        #  • seriál + název epizody (všechny, bez “pilot”)
        #  • short-token dotazy (všechny unikátní tokeny)
        for ser in alt_tv_all[2:]:
            for code in codes:
                wave4.append(f"{ser} {code}")

        for ser in tv_names:
            for ep in ep_names_no_pilot:
                wave4.append(f"{ser} {ep}")

        _tok_seen2: set[str] = set()
        for nm in tv_names:
            tok = _short_token(nm)
            if not tok or tok in _tok_seen2:
                continue
            _tok_seen2.add(tok)
            for code in codes:
                wave4.append(f"{code} {tok}")

        # --- finální unikátní pořadí -----------------------------------------
        out = OrderedDict()  # zachová pořadí přidání + eliminuje duplicity
        for q in (wave1 + wave2 + wave3 + wave4):
            q = (q or "").strip()
            if not q:
                continue
            out.setdefault(q, None)

        return list(out.keys())


# --------------------------------------------------------------------------- #
# Dotazy Fastshare (přesun z `richmovie_fastshare.search`, G1; Gate podle nich řídí krok hledání Fastshare)
# --------------------------------------------------------------------------- #
# Fastshare API dělá podřetězcovou shodu nad názvem souboru, proto diakritiku odstraňujeme a při nulovém výsledku se
# zkusí dotaz bez roku — rok v dotazu se s rokem v názvu souboru (premiéra CZ / originál) často liší.
FS_YEAR_TOKEN_RE = re.compile(r"\s*\b(?:19|20)\d{2}\b\s*")


def fastshare_term(query: str) -> str:
    """Dotaz pro Fastshare API: bez diakritiky (web i API porovnávají bez ní; `Zálesák` → `Zalesak`)."""
    term = unicodedata.normalize("NFD", query)
    return "".join(ch for ch in term if unicodedata.category(ch) != "Mn")


def fastshare_year_stripped(term: str) -> str:
    """Dotaz bez tokenu roku pro druhý pokus při nulovém výsledku; "" = rok v dotazu není (druhý pokus nemá smysl)."""
    stripped = FS_YEAR_TOKEN_RE.sub(" ", term).strip()
    stripped = re.sub(r"\s+", " ", stripped)
    return stripped if (stripped and stripped != term) else ""


def query_variants(
    title: str,
    original_title: str,
    year: Optional[int],
    *,
    alt_titles: Sequence[str] = (),
    qualities: Tuple[str, ...] = (),
) -> List[str]:
    """Všechny kombinace dotazů pro film: základní, originální a alternativní názvy, dvojice názvů v obou
    pořadích a pro každý název varianta s rokem + kvalitou a s rokem (bez roku, když rok není)."""
    # ❶ sesbíráme *všechny* relevantní názvy
    names: Set[str] = {title}
    if original_title and original_title.lower() != title.lower():
        names.add(original_title)

    for alt in alt_titles:
        if alt and alt.lower() not in {n.lower() for n in names}:
            names.add(alt)

    base_names = sorted(names)

    # ❷ přidáme obousměrné dvojice ("A B" ↔ "B A")
    for a, b in permutations(base_names, 2):   # G1: sorted — pořadí nezávislé na hash seedu procesu
        names.add(f"{a} {b}")

    # ❷b název s apostrofem i bez něj (15.11.2026, F1 `Temp/filtr_recall_20261115/ZPRAVA_A.md` §4.1): Webshare na
    #     „The Carpenter's Son 2025“ / „Don't Move 2026“ soubory `Carpenters` / `Dont` do prvních 200 nedá, na dotaz bez
    #     apostrofu je dá na první místa. Jen základní názvy (ne dvojice) → nejvýš +1 dotaz na název s apostrofem.
    for name in base_names:
        bare = strip_apostrophes(name)
        if bare != name and bare.lower() not in {n.lower() for n in names}:
            names.add(bare)

    # ❸ finalizujeme dotazy
    variants: List[str] = []
    for name in sorted(names):
        base = f"{name} {year}" if year else name
        variants.extend(f"{base} {q}" for q in qualities)  # + kvalita
        variants.append(base)                              # bez kvality
    return variants
