# -*- coding: utf-8 -*-
"""rm_core.dedupe — sloučení zdrojů, sjednocení výsledků vlny a deduplikace vlny (film i seriál).

Čisté funkce; `log` je injektovaný logger (formát per-search logu beze změny). Přesun 1 : 1 (G1).
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Callable, List, Optional, Sequence, Tuple

from rm_core.model import Release
from rm_core.text import sane_item

LogFn = Callable[..., Any]

# ---------------------------------- FUNKCE ---------------------------------- #
# richmovie_engine.py
# _dedupe_multi_source  (vytvořeno: 21.01.2026 23:15 CET, Europe/Prague)
# ---------------------------------------------------------------------------- #
def _dedupe_multi_source(
    ws_items: List[dict],
    fs_items: List[dict],
    size_tolerance: float = 0.05,
) -> List[dict]:
    """
    Sloučí výsledky z Webshare a Fastshare s deduplikací.

    Pravidla:
      • Webshare má vždy přednost (všechny WS výsledky se zachovají)
      • Fastshare výsledek se přidá JEN pokud neexistuje duplicita
      • Duplicita = normalizovaný název shodný + velikost ±5%

    Args:
        ws_items: Seznam výsledků z Webshare (dict s klíči: name, size, ...)
        fs_items: Seznam výsledků z Fastshare (dict s klíči: name, size, source="fastshare", ...)
        size_tolerance: Tolerance velikosti pro duplicitu (default 5%)

    Returns:
        Sloučený seznam (WS + unikátní FS)
    """
    if not fs_items:
        return ws_items

    if not ws_items:
        return fs_items

    # Normalizace názvu pro porovnání
    def _norm_name(name: str) -> str:
        """Normalizuje název: lowercase, bez speciálních znaků, bez mezer."""
        if not name:
            return ""
        # Lowercase
        n = name.lower()
        # Odstraníme příponu
        n = re.sub(r"\.(mkv|avi|mp4|m4v|mov|wmv|flv|webm|ts|m2ts)$", "", n, flags=re.I)
        # Pouze alfanumerické znaky
        n = re.sub(r"[^a-z0-9]", "", n)
        return n

    # Vytvoříme index WS výsledků: (norm_name, size) → True
    ws_index: dict[tuple[str, int], bool] = {}
    for item in ws_items:
        try:
            norm = _norm_name(item.get("name", ""))
            size = int(item.get("size", 0) or 0)
            if norm:
                ws_index[(norm, size)] = True
        except Exception:
            continue

    # Filtrujeme FS výsledky
    merged = list(ws_items)  # Kopie WS

    for fs_item in fs_items:
        try:
            fs_norm = _norm_name(fs_item.get("name", ""))
            fs_size = int(fs_item.get("size", 0) or 0)

            if not fs_norm:
                continue

            # Kontrola duplicity: hledáme WS s podobným názvem a velikostí
            is_dupe = False
            for (ws_norm, ws_size), _ in ws_index.items():
                # Název musí být shodný
                if ws_norm != fs_norm:
                    continue
                # Velikost musí být v toleranci ±5%
                if ws_size > 0 and fs_size > 0:
                    ratio = abs(fs_size - ws_size) / max(ws_size, 1)
                    if ratio <= size_tolerance:
                        is_dupe = True
                        break
                elif ws_size == fs_size:
                    # Oba mají 0 nebo stejnou velikost
                    is_dupe = True
                    break

            if not is_dupe:
                merged.append(fs_item)

        except Exception:
            # Φ-E (30.09.2026, cross-check Flash F5): položku, kterou nejde POROVNAT (vadná velikost),
            # nezahazujeme — jen ji nelze označit za duplicitu. Rozhodne o ní filtr jako o každé jiné.
            if isinstance(fs_item, dict):
                merged.append(fs_item)
            continue

    return merged


class FetchResult(object):
    """Syrový výsledek JEDNOHO dotazu (jen síť, žádné rozhodování filtru) + čísla pro měření.

    `page_of[ident]` = odkud položka přišla: "1".."5" = stránka Webshare, "fs" = Fastshare,
    "fsy" = Fastshare po opakování bez roku."""

    __slots__ = ("query", "items", "ws_raw", "ws_pages", "fs_raw", "fs_calls", "ms", "page_of", "error",
                 "reused", "ws_error", "fs_error", "ws_exc", "ws_list", "fs_list")

    def __init__(self, query: str) -> None:
        self.query = query
        self.reused = False     # výsledek převzat z paměti hledání (žádný požadavek na síť)
        self.items: List[dict] = []
        self.ws_raw = 0
        self.ws_pages = 0
        self.fs_raw = 0
        self.fs_calls = 0
        self.ms = 0
        self.page_of: dict = {}
        # "" = v pořádku | "ws" / "fs" / "ws+fs" = selhal zdroj (výsledek je NEúplný, R2) | "query" = celý dotaz
        self.error = ""
        self.ws_error = ""      # třída chyby Webshare ("" = bez chyby) — S31: výpadek zdroje nezastaví druhý
        self.fs_error = ""
        # původní výjimka Webshare jen pro vlnu (brzdění 429 / paměť → nižší souběžnost, S2); nikam se neukládá
        self.ws_exc: Optional[BaseException] = None
        # položky zdrojů PŘED sloučením (přímé hledání ořezává každý zdroj zvlášť — `fetch_raw(cap=…)`)
        self.ws_list: List[dict] = []
        self.fs_list: List[dict] = []

    def as_reused(self) -> "FetchResult":
        """Tentýž výsledek pro další vlnu téhož hledání — položky sdílené, čísla sítě nulová."""
        r = FetchResult(self.query)
        r.items, r.page_of = self.items, self.page_of
        r.ws_raw, r.fs_raw = self.ws_raw, self.fs_raw
        r.reused = True
        return r


def union_fetched(fetched: Sequence[FetchResult], log: LogFn) -> Tuple[List[dict], dict]:
    """Sjednotí syrové položky dotazů podle identu (první výskyt v pořadí DOTAZŮ — deterministické).
    Vrací (položky, původ): původ[ident] = ["<index dotazu>:<stránka|fs|fsy>", …] = VŠECHNY dotazy,
    které ident vrátily. Do logu jde `WAVE_UNION` (součty) a `WAVE_ORIGIN` (dotazy + původ)."""
    union: List[dict] = []
    origin: dict = {}
    for qi, res in enumerate(fetched):
        for raw in res.items:
            it = sane_item(raw)
            if it is None:
                log("FILTER_REJECT", "", "item_error", repr(raw)[:160])
                continue
            ident = it.get("ident")
            tag = "%d:%s" % (qi, res.page_of.get(ident, "?"))
            if ident in origin:
                origin[ident].append(tag)
                continue
            origin[ident] = [tag]
            union.append(it)
    log("WAVE_UNION", sum(len(x.items) for x in fetched), len(union))
    try:
        log("WAVE_ORIGIN", json.dumps(
            {"queries": [x.query for x in fetched], "origin": origin}, ensure_ascii=False))
    except Exception as exc:
        log("WAVE_ORIGIN_ERR", repr(exc)[:200])
    return union, origin


def log_wave_yield(fetched: Sequence[FetchResult], origin: dict, accepted: Sequence[Release], log: LogFn) -> None:
    """Výtěžnost dotazů vlny do logu (`WAVE_YIELD`): co který dotaz stáhl, kolik z toho bylo nového,
    kolik přijal filtr a kolik přijatých našel JEN on. Nahrazuje dřívější řádky `WS_RESULTS <dotaz> <přijato>`
    (filtr už neběží po dotazech) a je podkladem pro rozhodnutí o dotazech (plán Φ-F)."""
    try:
        acc_ids = {r.ident for r in accepted}
        rows = []
        for qi, res in enumerate(fetched):
            mine = [i for i, tags in origin.items() if any(t.split(":", 1)[0] == str(qi) for t in tags)]
            first = [i for i in mine if origin[i][0].split(":", 1)[0] == str(qi)]
            acc = [i for i in mine if i in acc_ids]
            excl = [i for i in acc if len({t.split(":", 1)[0] for t in origin[i]}) == 1]
            rows.append({
                "q": res.query, "ws": res.ws_raw, "pages": res.ws_pages, "fs": res.fs_raw,
                "fs_calls": res.fs_calls, "ms": res.ms, "merged": len(res.items),
                "new": len(first), "acc": len(acc), "excl": len(excl), "err": res.error,
                "reused": bool(res.reused),
                "acc_p2": sum(1 for i in acc if all(t.endswith(":2") for t in origin[i])),
            })
        log("WAVE_YIELD", json.dumps(rows, ensure_ascii=False))
    except Exception as exc:
        log("WAVE_YIELD_ERR", repr(exc)[:200])


def apply_origin(releases: Sequence[Release], origin: dict) -> None:
    """Původ (dotazy a stránky) na přijaté položky — nese se v cache až k výběru streamu."""
    for r in releases:
        try:
            r.origin = ",".join(origin.get(r.ident) or ())
        except Exception:
            pass


def _dedupe_wave(all_items: Sequence[Release], sig_of: Callable[[Release], Any], reason: str, log: LogFn,
                 ) -> List[Release]:
    """Deduplikace přijatých položek vlny: nejdřív podle identu, pak podle otisku (velikost + přípona u filmu,
    velikost + kvalita u dílu). Při shodném skóre má Webshare přednost před Fastshare; duplicita, která
    vypadne, jde do logu jmenovitě (`DEDUP_DROP`)."""
    seen_ids: set = set()
    uniq_id: List[Release] = []
    for r in sorted(all_items, key=lambda x: (x.score, 0 if x.source == "webshare" else 1)):
        if r.ident not in seen_ids:
            uniq_id.append(r)
            seen_ids.add(r.ident)
    if reason == "size_quality":
        log("DEDUP2_BEGIN", len(uniq_id))
    seen_sig: dict = {}   # otisk → index ve finálním seznamu
    uniq_final: List[Release] = []
    for r in uniq_id:
        sig = sig_of(r)
        if sig in seen_sig:
            # Duplicita: WS nahradí FS pokud stávající je FS a nový je WS
            idx = seen_sig[sig]
            _kept, _gone = uniq_final[idx], r
            if uniq_final[idx].source != "webshare" and r.source == "webshare":
                uniq_final[idx] = r
                _kept, _gone = r, _kept
            log("DEDUP_DROP", _gone.ident, reason, _kept.ident, _gone.name)
            continue
        seen_sig[sig] = len(uniq_final)
        uniq_final.append(r)
    return uniq_final


def dedupe_movie_wave(all_items: Sequence[Release], log: LogFn) -> List[Release]:
    """Deduplikace filmové vlny: ident, pak (velikost, přípona)."""
    return _dedupe_wave(all_items, lambda r: (r.size, os.path.splitext(r.name)[1].lower()), "size_ext", log)


def dedupe_tv_wave(all_items: Sequence[Release], log: LogFn) -> List[Release]:
    """Deduplikace vlny dílu: ident, pak (velikost, kvalita)."""
    log("DEDUP_BEGIN", len(all_items))
    return _dedupe_wave(all_items, lambda r: (r.size, r.quality), "size_quality", log)
