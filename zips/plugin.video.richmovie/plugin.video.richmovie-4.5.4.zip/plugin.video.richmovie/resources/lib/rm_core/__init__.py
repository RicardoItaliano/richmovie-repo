# -*- coding: utf-8 -*-
"""rm_core — sdílené jádro hledání a výběru streamu RichMovie (SSOT; doplněk i Gate používají TENTÝŽ kód).

Závazná pravidla (AST lint `_tools/heuristics_replay/rm_core_gates.py`): import jen standardní knihovna a `rm_core.*`,
žádné Kodi, žádná síť ani soubor, syntaxe Python 3.8, logování injektované `log(event, *params)` ve formátu
per-search logu, čas a náhoda injektované."""
from __future__ import annotations

import hashlib
import os

RM_CORE_VERSION = "1.2.3"     # 1.2.1 (16.11.2026): číslovka názvu rozhoduje shodu (`title_match` pravidlo 6)
#                               1.2.2 (16.11.2026): stejnojmenný seriál + generický název dílu (`filter_tv` F2 / F3),
#                               po auditu Fable F28: jmenovec musí mít hledaný díl, důvod nejistoty, přísnější D
#                               a většina slov názvu seriálu, `episode_result_cacheable`
#                               1.2.3 (21.11.2026): nesedící délka v řazení před CAM (D-1), shoda délek kopií (D-2),
#                               počítané streamy a třída zdroje orig / cam pro noc Trendů (D-3, D-4) — `ranking`


def core_sha() -> str:
    """SHA-256 obsahu balíku (všechny `.py`, seřazeno podle jména) — Gate ji ukazuje v `/health`, deploy ji porovná."""
    h = hashlib.sha256()
    here = os.path.dirname(os.path.abspath(__file__))
    for name in sorted(fn for fn in os.listdir(here) if fn.endswith(".py")):
        h.update(name.encode("utf-8"))
        with open(os.path.join(here, name), "rb") as fh:
            h.update(fh.read())
    return h.hexdigest()
