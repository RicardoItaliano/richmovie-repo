# -*- coding: utf-8 -*-
"""rm_core.filter_movie — filtr filmu (`filter_movie_items`) a zákaz ostatních dílů kolekce. Přesun 1 : 1 (G1).
`log` = per-search log (formát beze změny), síť a probe jsou injektované. Čistá standardní knihovna.
"""
from __future__ import annotations

import json
import os
from typing import Any, Callable, List, Optional, Sequence, Tuple

from rm_core.filter_tv import LogFn, ProbeManyFn
from rm_core.model import KIND_MOVIE, ReleaseFilter, Release
from rm_core.ranking import RUNTIME_OFF, duration_s, duration_trusted, runtime_class
from rm_core.source_grade import grade_of
from rm_core.title_match import MATCH_WEAK, match_title_level, name_norm, plain_name
from rm_core.text import (
    FILTER_PROGRESS_EVERY,
    LEN_TOL_LONG,
    LEN_TOL_SHORT,
    MATCH_TOL,
    PROBE_MAX_RESULTS,
    YEAR_RE,
    _BAD_REGEX_DEFAULT,
    _BAD_REGEX_MOVIE,
    bad_word_in_title,
)

# ---------------------------------- SSOT ------------------------------------ #
# richmovie_engine.py
# movie_ban_hit  (Φ-B 30.09.2026 — zákaz ostatních dílů kolekce bez ztráty správných filmů, E3-F01)
# ---------------------------------------------------------------------------- #
# Zákaz kolekce chrání před pokračováními bez roku v názvu („Nezvratný osud 2“, „Matrix Reloaded“). Banovala
# se ale i slova SPOLEČNÁ celé franšíze („star“, „wars“, „epizoda“) — při hledání „Návrat Jediho“ tak filtr
# zahodil ~45 správných souborů „Star Wars … Návrat Jediho (1983)“ a prošly 4. Dvě pojistky:
#   (a) obecné slovo pokračování („část“, „part“, „díl“…) samo nezakazuje soubor, který nese POVOLENÝ ROK;
#   (b) soubor, který nese cílový titul jako sousedící frázi (≥ 2 významová slova), a ten titul NENÍ
#       podfrází názvu žádného sourozence, je jednoznačně cílový film → zákaz se nepoužije.
# Pokračování zůstávají zamítnutá: „nezvratný osud“ i „hunger games“ JSOU podfrází názvů sourozenců.
MOVIE_BAN_GENERIC = frozenset({
    "part", "cast", "dil", "chapter", "kapitola", "episode", "epizoda", "vol", "volume", "film", "movie",
})
_MOVIE_TITLE_STOP = frozenset({
    "the", "a", "an", "of", "and", "z", "o", "s", "v", "ve", "na", "do", "u", "i", "se", "de", "le", "la", "du",
})
MOVIE_UNAMBIGUOUS_MIN_WORDS = 2

# Slabá shoda názvu (`title_match.MATCH_WEAK`, jádro 1.2.0): u NOVÉHO filmu projde jen s potvrzením — povolený rok ve jménu,
# nebo délka ze zdroje do ±5 % některé stopáže TMDb (přísněji než ★ MATCH: u slabé shody je délka jediný důkaz, že jde
# o tentýž film). „Nový“ = rok filmu ≥ letos − WEAK_RECENT_YEARS; rok dodá hostitel (`today_year`, čas je v jádře vstříknutý).
# Proč jen nový (audit Fable F18 V1, měření korpusu): u nového titulu jsou soubory bez roku se dvěma slovy názvu skoro vždy
# JINÉ dílo (Vánoční koleda u Ebenezera, díly 1–3 u Hunger Games: Úsvit sklizně, „14 - Nebezpečné území“); u starého filmu
# jsou to běžné staré ripy („Limonadovy Joe CZ.avi“, „Harry Potter 1“), které 1.1.0 přijímalo — ty se ztratit nesmí.
WEAK_LEN_TOL = 0.05
WEAK_RECENT_YEARS = 1


def weak_title_needs_proof(movie_year: Optional[int], today_year: Optional[int]) -> bool:
    """Musí slabá shoda názvu u tohoto filmu dokládat rok nebo délku? Jen u nového filmu a jen se známým letoškem."""
    try:
        return bool(movie_year and today_year and int(movie_year) >= int(today_year) - WEAK_RECENT_YEARS)
    except (TypeError, ValueError):
        return False


def weak_match_corroborated(yrs_in_name: Sequence[int], allowed_years: Sequence[int], len_s: Optional[int],
                            runtimes: Sequence[int]) -> Optional[str]:
    """Čím je slabá shoda názvu potvrzená: "year" (povolený rok ve jménu), "length" (délka ze zdroje ±5 % stopáže TMDb),
    None = nepotvrzená. Čistá funkce."""
    if set(yrs_in_name) & set(allowed_years):
        return "year"
    if len_s and len_s > 0:
        for rt in runtimes or ():
            if rt and rt > 0 and abs(len_s / 60.0 - rt) <= WEAK_LEN_TOL * rt:
                return "length"
    return None


def movie_ban_hit(n_norm: str, banned_keys: Sequence[str], title_norms: Sequence[str],
                  has_allowed_year: bool = False) -> Tuple[Optional[str], str]:
    """Rozhodnutí zákazu kolekce pro film. Vrací (zásah | None, důvod): zásah = ban token, který soubor
    zamítá; None = soubor zákaz nezamítá. Důvod: "" (žádný ban token v názvu), "generic" / "unambiguous"
    (token v názvu je, ale platí pojistka), "ban" (zamítnout). Čistá funkce."""
    if not banned_keys:
        return None, ""
    nn = " %s " % n_norm
    hits = [bk for bk in banned_keys if bk and (" %s " % bk) in nn]
    if not hits:
        return None, ""
    real = [h for h in hits if h not in MOVIE_BAN_GENERIC]
    if not real and has_allowed_year:
        return None, "generic"
    phrases = [" %s " % b for b in banned_keys if b and " " in b]
    for t in (title_norms or ()):
        words = [w for w in str(t or "").split() if w and w not in _MOVIE_TITLE_STOP]
        if len(words) < MOVIE_UNAMBIGUOUS_MIN_WORDS:
            continue
        needle = " %s " % t
        if needle in nn and not any(needle in ph for ph in phrases):
            return None, "unambiguous"
    return (real[0] if real else hits[0]), "ban"


def filter_movie_items(  # noqa: C901
    ws_items: List[dict],
    *,
    label: str,
    log: LogFn,
    runtimes: Sequence[int] = (),
    title_norms: Sequence[str] = (),
    banned_keys: Sequence[str] = (),
    movie_year: Optional[int] = None,
    allowed_years: Sequence[int] = (),
    bad_regex: Any = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    probe: bool = False,
    probe_many: Optional[ProbeManyFn] = None,
    today_year: Optional[int] = None,
) -> List[Release]:
    """ReleaseFilter pro film nad syrovými položkami. Rozhodnutí je ČISTĚ po položkách — dotaz (`label`)
    jde jen do logu; proto smí vlna filtrovat sjednocení položek všech dotazů jednou (Φ5B). Přesun 1 : 1 z
    `SearchEngine._movie_filter` (G1). `today_year` = letošní rok od hostitele (jádro 1.2.0: slabá shoda názvu u nového
    filmu, `weak_title_needs_proof`); None = pravidlo vypnuté (chování 1.1.0)."""
    bad_regex = bad_regex or _BAD_REGEX_DEFAULT
    weak_needs_proof = weak_title_needs_proof(movie_year, today_year)

    if not ws_items:
        return []

    # ❷ roky z titulových tokenů (např. film „2012“ apod.)
    title_year_tokens: set[int] = {
        int(tok) for tok in title_norms if tok.isdigit() and len(tok) == 4
    }
    extra_years = {int(y) for y in allowed_years if isinstance(y, int)}

    # ❸ filtry + enrich
    releases: list[Release] = []
    probe_cand: list[Release] = []

    _total_items = len(ws_items)
    for _fi, itm in enumerate(ws_items):
        if progress_cb and _fi % FILTER_PROGRESS_EVERY == 0:
            progress_cb(_fi, _total_items, "filter")
        try:
            rel = ReleaseFilter.enrich(itm)
        except Exception as _itm_exc:
            # Filtr běží JEDNOU nad sjednocením → výjimka jedné položky by shodila celou vlnu
            # (dřív jen jeden dotaz). Položka jde do logu, vlna pokračuje (audit Fable F1-V5).
            log("FILTER_REJECT", str(itm.get("ident") or ""), "item_error", str(itm.get("name") or ""),
                      repr(_itm_exc)[:160])
            continue
        if not rel:
            # velikost do detailu: log ji dřív zjišťoval dotazem `file_info` (síť), teď ji nese událost
            log("FILTER_REJECT", itm["ident"], "quick", {"size": itm.get("size", 0)}, itm["name"])
            continue

        # 15.11.2026: jméno s proloženými písmeny (`H_a_r_r_y-P_o_t_t_e_r`) se slepí — název, rok, kód dílu i zákaz kolekce
        # se čtou z TÉHOŽ tvaru (SSOT `plain_name`; audit Fable F13 V1: slepený název + syrový rok = cizí rok prošel)
        plain = plain_name(rel.name)
        n = name_norm(rel.name)
        # Jádro 1.2.0: nahrávka z kina (štítek a pořadí, nikdy filtr) — tady, kde je známý název titulu
        rel.source_grade, rel.source_marker = grade_of(plain, title_norms)
        rel.kind = KIND_MOVIE                     # jádro 1.2.3: druh titulu pro řazení nesedící délky (D-1)

        # — BAN klíče (ostatní díly série apod.) —
        # 2025-09-27 12:03 CEST (Europe/Prague) – fix falešných zásahů:
        # Dříve: prostý substring `bk in n` → např. "equalizer 2" ⊂ "equalizer 2014".
        # Nyní: „mezerovaný“ substring (simulace word‑boundaries), jako v jiné větvi enginu.
        # Φ-B (30.09.2026, E3-F01): SSOT `movie_ban_hit` — zákaz s pojistkami (obecné slovo pokračování,
        # jednoznačný cílový titul). Do logu jde, KTERÝ token zakázal, a když pojistka zákaz odvrátila.
        if banned_keys:
            _yrs_b = {int(y) for y in YEAR_RE.findall(plain)}
            _allowed_b = ({movie_year} | title_year_tokens | extra_years) if movie_year else set()
            _ban, _ban_why = movie_ban_hit(n, banned_keys, title_norms,
                                           has_allowed_year=bool(_yrs_b & _allowed_b))
            if _ban is not None:
                log("FILTER_REJECT", rel.ident, "other_part",
                          json.dumps({"ban_hit": _ban}, ensure_ascii=False), rel.name)
                continue
            if _ban_why:
                log("MOVIE_BAN_WAIVED", rel.ident, _ban_why, rel.name)


        # — Titulní shoda (per-title; 2026-03-01) —
        # Shoda pro KAŽDÝ title_norm zvlášť (CZ i EN; „Zálesák“ vs „Forest Warrior“). Pravidla shody jsou od 15.11.2026
        # v SSOT `rm_core.title_match` (zkratky z písmen celé, apostrof a elize, krátké a číselné názvy — Σ-audit Φ3.15).
        name_words = {w for w in n.split() if w}  # pro log
        title_level, best_hits, all_query_tokens = match_title_level(title_norms, rel.name)

        if title_level is None:
            try:
                log(
                    "FILTER_REJECT", rel.ident, "token_miss",
                    json.dumps(
                        {
                            "per_title": True,
                            "hits": sorted(list(best_hits)),
                            "query_tokens": sorted(list(all_query_tokens)),
                            "name_words": sorted(list(name_words))[:24],
                        },
                        ensure_ascii=False,
                    ),
                    rel.name,
                )
            except Exception:
                log("FILTER_REJECT", rel.ident, "token_miss", rel.name)
            continue


        # — Nežádoucí regexy —
        if _BAD_REGEX_MOVIE.search(plain) or (bad_regex.search(plain)
                                               and not (bad_regex is _BAD_REGEX_DEFAULT
                                                        and bad_word_in_title(bad_regex, plain, title_norms))):
            log("FILTER_REJECT", rel.ident, "bad_regex", rel.name)
            continue

        # — Whitelist ROKŮ (aplikuje se jen, když je rok v názvu) —
        yrs_in_name = {int(y) for y in YEAR_RE.findall(plain)}
        if movie_year and yrs_in_name:
            allowed = ({movie_year} | title_year_tokens | extra_years)
            # HΦ3 (2026-07-07, analýza H3): „extra-year kill“ fix — dřív
            # `yrs_in_name - allowed` zabil soubor s cílovým rokem, který
            # nesl i cizí rok (dabing/remaster/group tag „EDGE2020“, DVD/VHS
            # rok). Nově: reject JEN když disjoint (žádný rok nesedí).
            if yrs_in_name.isdisjoint(allowed):
                log(
                    "FILTER_REJECT",
                    rel.ident,
                    "year_miss",
                    json.dumps(
                        {
                            "movie_year": movie_year,
                            "tmdb_allowed": sorted(extra_years),
                            "yrs_in_name": sorted(yrs_in_name),
                        },
                        ensure_ascii=False,
                    ),
                    rel.name,
                )
                continue

        # — Slabá shoda názvu u NOVÉHO filmu jen s potvrzením (jádro 1.2.0; Ebenezer / Hunger Games / Predátor) —
        if title_level == MATCH_WEAK and weak_needs_proof:
            _allowed_w = sorted(({movie_year} if movie_year else set()) | title_year_tokens | extra_years)
            _wdur, _wsrc = duration_s(rel, None)          # délka ze zdroje (Fastshare zaokrouhlené hodiny ne)
            _wlen = int(_wdur) if duration_trusted(_wsrc, None, rel.name) else 0
            if weak_match_corroborated(sorted(yrs_in_name), _allowed_w, _wlen, runtimes) is None:
                log("FILTER_REJECT", rel.ident, "title_weak",
                    json.dumps({"hits": sorted(best_hits), "query_tokens": sorted(all_query_tokens),
                                "yrs_in_name": sorted(yrs_in_name), "len_s": _wlen},
                               ensure_ascii=False),
                    rel.name)
                continue

        # — MediaInfo fronta (22.01.2026 – nyní podporuje i Fastshare) —
        if probe and rel.est_min is None and len(probe_cand) < PROBE_MAX_RESULTS:
            probe_cand.append(rel)

        # — Prošlo: přidej a zaloguj DŮVOD PRŮCHODU —
        #
        # 3.4.7 (2026-05-17, audit Π5): odstraněny `token_min` / `token_hits` /
        # `hit_tokens` z movie path. Tyto proměnné existují jen v TV branch
        # (`search_one`, řádky ~1585-1587 této metody), v `search_movie_one`
        # nikdy nebyly definovány → každý přijatý movie release vyvolal NameError,
        # zachycený `except Exception` níže → tichá ztráta diagnostiky.
        # Movie path nemá token-min/token-hit semantiku (heuristic je založena
        # na year+title penalty, ne token bucket), takže drop je správný.
        releases.append(rel)
        try:
            accept_ctx = {
                "yrs_in_name": sorted(yrs_in_name) if yrs_in_name else [],
                "years_allowed": (
                    sorted({movie_year} | title_year_tokens | extra_years)
                    if movie_year else []
                ),
                "banned_hit": False,
                "bad_regex": False,
            }
            log(
                "FILTER_ACCEPT",
                rel.ident,
                json.dumps(accept_ctx, ensure_ascii=False),
                rel.quality,
                rel.size_mb,
                rel.name,
            )

        except Exception:
            log("FILTER_ACCEPT", rel.ident, rel.quality, rel.size_mb, rel.name)

    # ❹ MediaInfo probe (paralelně)
    if probe and probe_cand and probe_many is not None:
        probe_many(probe_cand, progress_cb)

    log("WS_RESULTS", label, len(releases))

    # ❺ Délkový filtr + ★ MATCH
    # HΦ-C (2026-07-07, analýza H1 §6.1 — NEJHORŠÍ nález, 98 % zabití len_out
    # vypadalo jako správný film): dřív TVRDÝ DROP při jakémkoli nesouladu
    # měřené délky. Problém: FS/API metadata bývají chybná (Mission Impossible
    # 1996 zabit špatnou délkou), a cut/PAL verze legitimně kratší. Nově
    # DROPuje jen HRUBÝ nesoulad (< 0,5× délky = useknutý/rozbitý soubor);
    # MÍRNÝ nesoulad (mimo ±tol, ale ≥ půlka) = PENALTA řazení, ne drop
    # (filozofie „penalizovat > vyhazovat"). Monotónně bezpečné: striktně
    # MÉNĚ dropů než dřív → recall může jen růst.
    # Jádro 1.2.0: hrubý nesoulad rozhoduje JEDNO pravidlo `ranking.runtime_class` (filtr = délka ze zdroje, výpis doplňku
    # = MediaInfo, Trendy = mi_cache). Ve FILTRU (nevratné, divák soubor neuvidí) jen DOLNÍ mez — tu filtr měl už v 1.1.0
    # (`est < 0,5 × lo`), teď mírněji (navíc ≥ 15 min rozdílu, výjimka děleného souboru, Fastshare celé hodiny ne) =
    # monotónně méně zamítnutí. Horní mez (> 2,5× a o hodinu) jen pořadí zde; skryje ji výpis doplňku, kde je „Zobrazit“
    # (audit Fable F18 V3: chybná stopáž TMDb by jinak schovala všechny správné streamy bez cesty ven).
    if runtimes:
        lo_rt, hi_rt = min(runtimes), max(runtimes)
        keep: list[Release] = []
        for r in releases:
            est = r.est_min or 0
            _dur, _src = duration_s(r, None)
            if (_dur and _dur < lo_rt * 60
                    and runtime_class(_dur, duration_trusted(_src, None, r.name), runtimes, "movie",
                                      r.name) == RUNTIME_OFF):
                log("FILTER_REJECT", r.ident, "len_out",
                    json.dumps({"est": est, "dur_s": int(_dur), "lo": lo_rt, "hi": hi_rt, "band": "off_short"},
                               ensure_ascii=False),
                    r.name)
                continue
            if est:
                out_of_band = est < lo_rt - LEN_TOL_SHORT or est > hi_rt + LEN_TOL_LONG
                if out_of_band:
                    r.len_penalty = 1
                    log("LEN_SOFT_PENALTY", r.ident,
                              json.dumps({"est": est, "lo": lo_rt, "hi": hi_rt},
                                         ensure_ascii=False), r.name)
            if any(abs(est - rt) <= MATCH_TOL for rt in runtimes):
                r.match = True
            keep.append(r)
        releases = keep

    # ❻ Scoring + řazení
    # 2025-08-23 09:10 CEST – Jednoslovné názvy bez roku: jemná penalizace pořadí (žádný ban).
    # Pravidla platí pouze, pokud:
    #   • title_norms obsahuje aspoň jeden jednoslovný titulek (např. "alien", "vetrelec"),
    #   • v názvu release NENÍ uveden rok (jinak se spoléháme na stávající whitelist roků).
    # Penalizace je malá a pouze mění pořadí kandidátů na shodné bázi; nikdy nic nevyhazuje.
    SAFE_SUFFIX = {
        # rozlišení a edice
        "2160p", "1080p", "720p", "480p", "4k", "uhd", "remastered", "extended", "directors", "cut",
        # zdroje / ripy
        "web", "webrip", "webdl", "bluray", "bdrip", "brrip", "hdrip", "dvdrip", "hdtv",
        # kodeky / profily
        "x264", "x265", "h264", "h265", "hevc", "av1", "10bit", "8bit",
        # audio
        "aac", "ac3", "eac3", "dts", "truehd", "atmos",
        # hdr/dolby vision
        "hdr", "sdr", "dv", "dolby", "vision",
        # jazyk / titulky
        "cz", "sk", "en", "eng", "pl", "czdub", "czdab", "dabing", "titulky", "subs", "sub"
    }
    for r in releases:
        base_score = ReleaseFilter.compute_score(r)
        penalty = 0
        try:
            # HΦ5 (2026-07-07, analýza H4 §5.4): odseknout příponu kontejneru
            # PŘED tokenizací — jinak `norm("Matrix.avi")` → „matrix avi" a
            # přípona „avi" (∉ SAFE_SUFFIX) penalizovala PŘESNÝ název filmu
            # (Matrix.avi, Pinocchio.avi, The Matrix.mkv). avi/mkv/mp4 nejsou
            # obsah, ale kontejner.
            _stem = os.path.splitext(r.name)[0]
            n = name_norm(_stem)
            has_year = bool(YEAR_RE.search(plain_name(r.name)))
            # uvažujeme jen jednoslovné varianty cílového titulu
            single_targets = [t for t in title_norms if " " not in t]
            if single_targets and not has_year:
                tokens = n.split()
                hit_ix = None
                hit_token = None
                # najdi nejčasnější výskyt jakéhokoli jednoslovného titulku
                for idx, tok in enumerate(tokens):
                    for t in single_targets:
                        if tok == t:
                            if hit_ix is None or idx < hit_ix:
                                hit_ix = idx
                                hit_token = t
                            break
                    if hit_ix == idx:
                        break

                if hit_ix is not None:
                    # 1) pozice shody: chceme ji v prvních ~3 tokenech
                    if hit_ix >= 3:
                        penalty += 1
                    # 2) "suffix" za shodou – následující token by měl být bezpečný (nebo rok)
                    next_tok = tokens[hit_ix + 1] if (hit_ix + 1) < len(tokens) else ""
                    is_year_tok = next_tok.isdigit() and len(next_tok) == 4
                    if next_tok and (next_tok not in SAFE_SUFFIX) and not is_year_tok:
                        penalty += 1

                    if penalty:
                        try:
                            ctx = {
                                "penalty": penalty,
                                "reason": [
                                    "pos>=3" if hit_ix >= 3 else None,
                                    "bad_suffix" if (next_tok and (next_tok not in SAFE_SUFFIX) and not is_year_tok) else None,
                                ],
                                "hit_token": hit_token,
                                "hit_index": hit_ix,
                                "next_token": next_tok or "",
                                "has_year_in_name": has_year,
                                "title_norms": list(single_targets),
                            }
                            # odfiltruj None z reason
                            ctx["reason"] = [x for x in ctx["reason"] if x]
                            log("SCORE_PENALTY", r.ident, json.dumps(ctx, ensure_ascii=False), r.name)
                        except Exception:
                            log("SCORE_PENALTY", r.ident, penalty, r.name)
        except Exception as e:
            # nechceme spadnout na výjimce – penalizace je "best effort"
            log("SCORE_PENALTY_ERR", getattr(r, "ident", "?"), str(e), getattr(r, "name", "?"))

        # rozšíříme lexikografické skóre o 4. složku (=penalizace); 0 znamená "bez penalizace"
        # HΦ-C: + délková soft-penalta (mírný nesoulad délky řadí níž, nedropuje)
        r.score = tuple(base_score) + (penalty + int(getattr(r, "len_penalty", 0)),)

    releases.sort(key=lambda x: x.score)
    return releases
