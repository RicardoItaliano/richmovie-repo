# -*- coding: utf-8 -*-
"""
rm_core.ranking — SSOT třídy rozlišení streamu, řadicího klíče výpisu a hratelnosti podle schopností zařízení.

Dřív `richmovie_quality` (doplněk ho dál re-exportuje). Čistý modul bez závislosti na Kodi.

Proč (analýza 29.09.2026, `Handoff/PLAN_stream_order_20260929.md`):
  Z1  kvalita se určovala jen z VÝŠKY obrazu — nejbližší standard k výšce. Širokoúhlý film 1080p má ale
      1920×800 (2,39 : 1), takže vycházel jako „720p“; 1280×536 jako „576p“, 3840×1616 (4K) jako „1080p“.
      V MediaInfo cache PC bylo tak zařazeno špatně 500 z 2 423 souborů (21 %).
  Z2  štítek kvality se bral z NÁZVU souboru, řazení z výšky obrazu → „1080P“ pod „720P“.
  Z3  čtyři různá řazení téhož seznamu (výpis filmu, výpis dílu, výběr streamu v novém vzhledu, automatický
      výběr dalšího dílu) a dvě kopie `_quality_rank` — u filmu český dabing nerozhodoval vůbec a automaticky
      vybraný stream nebyl první řádek výpisu.

Rozlišení je vlastnost ŠÍŘKY i výšky:

    efektivní výška = max(výška, šířka × 9 / 16)

Film 1920×800 má efektivní výšku 1080 (šířka 1920 = Full HD), 4 : 3 video 1440×1080 také 1080.

Rozhodnutí Richieho 29.09.2026: D1 kvalita, hned za ní český dabing (kdo chce dabing vždy, má ho z preference
profilu — ta jde před kvalitu); D6 prodloužené verze a dvojdíly řadit mezi ostatní, ne na konec.

Modul je čistý (žádné `xbmc`, žádný import enginu) — testuje ho harness (scénáře 81 a 84).
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, NamedTuple, Optional, Sequence, Tuple

from rm_core.model import KIND_MOVIE, KIND_TV
from rm_core.source_grade import GRADE_CAM, GRADE_CAM_MAYBE, has_video_source

# Standardní třídy (výška v řádcích), od nejlepší.
STANDARDS: Tuple[int, ...] = (2160, 1080, 720, 576, 480, 360, 320, 240)
ASPECT_W, ASPECT_H = 16, 9


def _to_int(value: Any) -> int:
    try:
        return max(0, int(float(value or 0)))
    except (TypeError, ValueError):
        return 0


def effective_height(width: Any, height: Any) -> int:
    """Výška, kterou by obraz měl při poměru 16 : 9 a téže šířce — nebo skutečná výška, je-li větší."""
    w, h = _to_int(width), _to_int(height)
    if w <= 0:
        return h
    if h > w:
        # video na výšku (1080×1920) má kvalitu obrazu 1080p — delší strana je „šířka“
        w, h = h, w
    return max(h, int(round(w * ASPECT_H / float(ASPECT_W))))


def nearest_standard(height: Any) -> int:
    """Nejbližší standardní třída k výšce; 0 = neznámá."""
    h = _to_int(height)
    if h <= 0:
        return 0
    return min(STANDARDS, key=lambda s: (abs(h - s), -s))


def resolution_class(width: Any, height: Any) -> int:
    """Třída rozlišení (2160, 1080, 720, …) z rozměrů obrazu; 0 = rozměry neznámé."""
    return nearest_standard(effective_height(width, height))


def class_from_label(label: Any) -> int:
    """Třída z popisku kvality podle NÁZVU souboru (`1080p`, `2160P`, `4k`); 0 = popisek třídu nenese
    (`webrip`, `other`, `cam`)."""
    s = str(label or "").strip().lower()
    if s in ("4k", "uhd"):
        return 2160
    if s.endswith("p") and s[:-1].isdigit():
        n = int(s[:-1])
        return n if n in STANDARDS else nearest_standard(n)
    return 0


def resolve(flags: Optional[Dict[str, Any]], ws_width: Any = None, ws_height: Any = None,
            name_label: Any = "") -> Tuple[int, str]:
    """Třída rozlišení streamu a zdroj údaje. Priorita: MediaInfo (změřeno ze souboru) → rozměry
    z Webshare `/search` → popisek z názvu. Vrací (třída, zdroj), zdroj ∈ mi2 | ws | name | none."""
    fl = flags if isinstance(flags, dict) else {}
    if not fl.get("fail"):
        c = resolution_class(fl.get("video_w"), fl.get("video_h") or fl.get("video_height"))
        if c:
            return c, "mi2"
    c = resolution_class(ws_width, ws_height)
    if c:
        return c, "ws"
    c = class_from_label(name_label)
    if c:
        return c, "name"
    return 0, "none"


def class_label(res_class: int) -> str:
    """Popisek třídy pro telemetrii: 1080 → `1080p`; 0 → prázdný řetězec."""
    return ("%dp" % int(res_class)) if res_class else ""


# ═════════════════════════════════════════════════════════════════════════════
#  ŘAZENÍ VÝPISU STREAMŮ — JEDNO PRAVIDLO (Φ-D, 30.09.2026)
# ═════════════════════════════════════════════════════════════════════════════
# Pořadí klíče (nižší = výš ve výpisu; úplný seznam polí = `SORT_KEY_FIELDS`):
#   1. relevance ručního hledání · 2. nesedí délka (jádro 1.2.3, D-1: zašedlé úplně dolů, i pod CAM a preference)
#   · 3. jistý záznam z kina (D-4) · 4. preferovaný zvuk · 5. preferované titulky
#   6. penalizace názvu (cizí seriál) · 7. stejná verze jako minulý díl · 8. KVALITA (+ DV „asi ne“, pravděpodobný
#   CAM) · 9. ČESKÝ DABING (+ zvuk z kina) · 10. balast (trailer, sample…) · 11. potvrzená délka (D9: JEN mezi streamy
#   stejné kvality a dabingu — neznámá délka nesmí shodit 4K pod 1080p jen proto, že MediaInfo ještě neběžela)
#   · 12. ★ shoda · 13. velikost · 14. skóre
# Je to JEN pořadí — filtr (ReleaseFilter) se tím nemění.
LABEL_DVDRIP, LABEL_WEBRIP, LABEL_CAM, LABEL_OTHER = "DVDRip", "WEBRip", "CAM", "OTHER"
RANK_OTHER = 99
_DVDRIP_RE = re.compile(r"\bDVD[-_. ]?RIP\b", re.I)
_NAME_RES_RE = re.compile(r"(?<!\d)(2160|1080|720|576|480|360|320|240)p(?!\d)", re.I)
JUNK_MARKERS: Tuple[str, ...] = ("watch party", "behind the scenes", "bts", "sample", "trailer", "extras")

RUNTIME_TOLERANCE = 0.10          # ±10 % proti referenční délce (hodnota z původního výpisu)
# D6: prodloužená / režisérská verze je TÝŽ film. Nejdelší běžné prodloužení je +31 % (Pán prstenů: Dvě věže
# 235 min proti 179 min); strop +50 % nechává rezervu a pořád odliší dvojfilm nebo jiný obsah.
EXTENDED_MAX_RATIO = 1.50
MULTI_EPISODE_MAX = 3             # dvojdíl / trojdíl v jednom souboru (seriál)
FS_ROUNDED_STEP_S = 3600          # Fastshare hlásí délku zaokrouhlenou na hodiny → taková délka není důkaz

RUNTIME_OK, RUNTIME_MISMATCH, RUNTIME_UNKNOWN = "ok", "mismatch", "unknown"


def _field(item: Any, name: str, default: Any = None) -> Any:
    """Pole streamu z objektu `Release` i ze slovníku (výběr streamu v novém vzhledu)."""
    if isinstance(item, dict):
        return item.get(name, default)
    return getattr(item, name, default)


def quality_rank(flags: Optional[Dict[str, Any]], ws_width: Any, ws_height: Any, name_label: Any,
                 name: Any = "") -> Tuple[int, str]:
    """(pořadí, štítek) kvality streamu — JEDNA pravda pro řazení i pro štítek ve výpisu.

    Rozměry obrazu (MediaInfo, pak Webshare) mají přednost před názvem souboru; štítek je vždy třída, podle
    které se řadí. Bez rozměrů: DVDRip / WEBRip / CAM podle názvu, pak `NNNNp` z názvu, jinak OTHER."""
    res_class, _src = resolve(flags, ws_width, ws_height, "")
    if res_class:
        return STANDARDS.index(res_class), "%dP" % res_class
    label = str(name_label or "").strip().lower()
    nm = str(name or "")
    if _DVDRIP_RE.search(nm) or label == "dvdrip":
        return len(STANDARDS), LABEL_DVDRIP
    if label == "webrip":
        return len(STANDARDS) + 1, LABEL_WEBRIP
    if label == "cam":
        return len(STANDARDS) + 2, LABEL_CAM
    m = _NAME_RES_RE.search(label) or _NAME_RES_RE.search(nm)
    if m:
        std = int(m.group(1))
        return STANDARDS.index(std), "%dP" % std
    c = class_from_label(label)
    if c:
        return STANDARDS.index(c), "%dP" % c
    return RANK_OTHER, LABEL_OTHER


def quality_of(item: Any, flags: Optional[Dict[str, Any]] = None) -> Tuple[int, str]:
    """`quality_rank` pro stream (objekt `Release` nebo slovník)."""
    return quality_rank(flags, _field(item, "ws_width"), _field(item, "ws_height"),
                        _field(item, "quality", ""), _field(item, "name", ""))


def cz_rank(flags: Optional[Dict[str, Any]], audios: Any) -> int:
    """0 = český dabing jistě (MediaInfo) · 1 = podle názvu souboru · 2 = bez českého dabingu."""
    fl = flags if isinstance(flags, dict) else {}
    if not fl.get("fail"):
        if fl.get("cz_dub"):
            return 0
        if fl.get("aud"):
            # zvukové stopy ZMĚŘENÉ ze souboru mají přednost před názvem („CZ“ v názvu bývají titulky);
            # stejně je vidí výběr streamu v novém vzhledu (cross-check Pro B-P3)
            audios = fl.get("aud")
    try:
        if "CZ" in {str(a).strip().upper()[:2] for a in (audios or []) if a}:
            return 1
    except Exception:
        pass
    return 2


def junk_rank(name: Any) -> int:
    """1 = balast (watch party, trailer, sample, extras…), 0 = běžný soubor."""
    n = str(name or "").lower()
    return 1 if any(m in n for m in JUNK_MARKERS) else 0


def duration_s(item: Any, flags: Optional[Dict[str, Any]]) -> Tuple[float, str]:
    """Délka streamu v sekundách a zdroj (ws | est | mi2 | none). Délka z Fastshare zaokrouhlená na celé
    hodiny se NEBERE (není to měření) — použije se MediaInfo, nebo je délka neznámá."""
    fl = flags if isinstance(flags, dict) else {}
    src = str(_field(item, "source", "webshare") or "webshare")

    def _num(v: Any) -> float:
        try:
            f = float(str(v).strip())
            return f if f > 0 else 0.0
        except (TypeError, ValueError):
            return 0.0

    def _trusted(sec: float) -> bool:
        return not (src == "fastshare" and sec > 0 and int(sec) % FS_ROUNDED_STEP_S == 0)

    ws = _num(_field(item, "ws_len_s"))
    if ws and _trusted(ws):
        return ws, "ws"
    est = _num(_field(item, "est_min")) * 60.0
    if est and _trusted(est):
        return est, "est"
    if not fl.get("fail"):
        for k in ("duration_s", "duration", "dur_s"):
            mi = _num(fl.get(k))
            if mi:
                return mi, "mi2"
    return 0.0, "none"


def runtime_verdict(dur_s: float, refs_min: Any, kind: str = "movie") -> str:
    """Sedí délka streamu k titulu? `ok` / `mismatch` / `unknown` (délka nebo reference chybí).

    `ok` je: ±10 % kterékoli referenční délky; u FILMU i delší verze do +50 % nejdelší reference
    (prodloužená verze); u DÍLU i dvojnásobek / trojnásobek (dvojdíl v jednom souboru)."""
    try:
        refs = sorted({float(x) * 60.0 for x in (refs_min or []) if float(x) > 0})
    except (TypeError, ValueError):
        refs = []
    if not refs or not dur_s or dur_s <= 0:
        return RUNTIME_UNKNOWN
    for ref in refs:
        if abs(dur_s - ref) <= ref * RUNTIME_TOLERANCE:
            return RUNTIME_OK
    if kind == "movie":
        if refs[-1] < dur_s <= refs[-1] * EXTENDED_MAX_RATIO:
            return RUNTIME_OK
    else:
        for ref in refs:
            for k in range(2, MULTI_EPISODE_MAX + 1):
                if abs(dur_s - k * ref) <= k * ref * RUNTIME_TOLERANCE:
                    return RUNTIME_OK
    return RUNTIME_MISMATCH


# --------------------------------------------------------------------------- #
# „Časově totálně mimo“ = nezobrazit (jádro 1.2.0, 15.11.2026, Avengers: Doomsday)
# --------------------------------------------------------------------------- #
# Richie 15.11.2026: „zajistit, streamy, které jsou časově totálně mimo, vůbec nezobrazit a tudíž po opravách by se logicky
# toto nemělo objevit ani v trendy“. Studie `Temp/mi2_mp4_20261115/NAVRH.md` §4: nad 5 442 streamy snímků Trendů pravidlo
# skryje 192 (TV díly, F1 / UFC záznamy, trailery, jiné filmy stejného jména), skutečný film žádný; 45 dní přehrání:
# dokoukaný soubor pod 0,5× byl jen trailer nebo AVI s chybnou délkou z MediaInfo → AVI délka pro skrytí neplatí.
# JEDNA funkce pro filtr hledání (délka ze zdroje), výpis doplňku (MediaInfo), hlídač ✔ (délka z přehrávače) i Trendy (Gate).
RUNTIME_OFF = "off"
OFF_SHORT_RATIO = 0.5             # film kratší než půlka nejkratší reference …
OFF_SHORT_MIN_GAP_S = 900         # … a zároveň aspoň o 15 min (krátký film 13 min se tak skoro nikdy neskryje)
OFF_LONG_RATIO = 2.5              # film delší než 2,5× nejdelší reference …
OFF_LONG_MIN_GAP_S = 3600         # … a aspoň o hodinu …
OFF_LONG_MIN_REF_S = 2400         # … jen u celovečerní reference (krátkometrážní záznam TMDb dlouhý soubor neskryje)
TV_SAMPLE_RATIO = 0.25            # díl: jen ukázka — pod čtvrtinu reference …
TV_SAMPLE_MAX_S = 600             # … a kratší než 10 min (TMDb stopáž dílu často lže: Griffinovi 50 min × skutečných 22)
# MediaInfo z hlavičky kontejneru (Segment/Info/Duration, mvhd) je měření; AVI (OpenDML nad 1 GB = jen první RIFF), OGG,
# TS, MPG délku z části souboru ODHADUJÍ (Café de Flore: AVI 42 min, Kodi 121 min, dokoukáno) → skrýt podle nich nesmí.
# Hodnoty = `_CONTAINER_MAP` sondy Gate (`app/mediainfo/probe.py`) + přípony souborů, když MediaInfo kontejner nenese.
TRUSTED_MI_CONTAINERS = frozenset({"mkv", "webm", "mp4", "mov", "m4v"})
# Dělený soubor (CD1 / disk 2 / part1 / 1 z 2): kratší díl filmu je v pořádku → nikdy `off`. „díl“ ne — česky pokračování.
# Výjimka platí jen pro soubor aspoň SPLIT_PART_MIN_S dlouhý: „Part 2“ / „část 2“ bývá i v NÁZVU filmu (Relikvie smrti,
# Dead Reckoning) a ukázka 85 s by pak nebyla skrytá nikdy (audit Fable F18 V6); část filmu nemá pod 20 min.
SPLIT_PART_MIN_S = 1200
_SPLIT_FILE_RE = re.compile(
    r"(?<![a-z0-9])(?:cd|dis[ck]|part|pt|část|cast)[\s._-]*[1-9](?!\d)"
    r"|(?<!\d)[1-9]\s*(?:z|of|/)\s*[1-9](?!\d)", re.I)


def is_split_file(name: Any) -> bool:
    """Nese jméno značku děleného souboru (CD1, disk 2, part1, 1 z 2, 1/2)?"""
    return bool(_SPLIT_FILE_RE.search(str(name or "")))


def _container_of(flags: Optional[Dict[str, Any]], name: Any) -> str:
    fl = flags if isinstance(flags, dict) else {}
    c = str(fl.get("container") or "").strip().lower()
    if c:
        return c
    n = str(name or "").lower()
    dot = n.rfind(".")
    return n[dot + 1:] if dot >= 0 else ""


def duration_trusted(src: str, flags: Optional[Dict[str, Any]] = None, name: Any = "") -> bool:
    """Smí délka ze zdroje `src` (výstup `duration_s`, nebo "kodi" = změřeno přehrávačem) rozhodnout o skrytí?
    ws / est / kodi ano (Fastshare zaokrouhlené hodiny vyřadí už `duration_s`); mi2 jen z kontejneru, který délku nese
    v hlavičce (`TRUSTED_MI_CONTAINERS`; kontejner z MediaInfo, jinak přípona souboru)."""
    if src in ("ws", "est", "kodi"):
        return True
    if src == "mi2":
        return _container_of(flags, name) in TRUSTED_MI_CONTAINERS
    return False


def runtime_class(dur_s: float, trusted: bool, refs_min: Any, kind: str = "movie", name: Any = "") -> str:
    """Třída délky streamu vůči titulu: `ok` / `mismatch` / `off` / `unknown`.

    `ok`, `mismatch`, `unknown` = `runtime_verdict` beze změny. `off` (= nezobrazit) jen z DŮVĚRYHODNÉ délky a ne u děleného
    souboru: film < 0,5× nejkratší reference a o ≥ 15 min kratší, nebo (reference ≥ 40 min) > 2,5× nejdelší a o ≥ 60 min
    delší; díl seriálu jen ukázka (< 0,25× reference a < 10 min). Neznámá délka / reference = `unknown` (R2: zobrazit)."""
    verdict = runtime_verdict(dur_s, refs_min, kind)
    if verdict != RUNTIME_MISMATCH or not trusted:
        return verdict
    if is_split_file(name) and dur_s >= SPLIT_PART_MIN_S:
        return verdict          # CD1 / part1 = část filmu; ukázka 85 s se značkou „Part 2“ v názvu filmu výjimku nemá
    try:
        refs = sorted({float(x) * 60.0 for x in (refs_min or []) if float(x) > 0})
    except (TypeError, ValueError):
        return verdict
    if not refs:
        return verdict
    lo, hi = refs[0], refs[-1]
    if kind == "movie":
        if dur_s < lo * OFF_SHORT_RATIO and lo - dur_s >= OFF_SHORT_MIN_GAP_S:
            return RUNTIME_OFF
        if hi >= OFF_LONG_MIN_REF_S and dur_s > hi * OFF_LONG_RATIO and dur_s - hi >= OFF_LONG_MIN_GAP_S:
            return RUNTIME_OFF
        return verdict
    if dur_s < lo * TV_SAMPLE_RATIO and dur_s < TV_SAMPLE_MAX_S:
        return RUNTIME_OFF
    return verdict


def runtime_class_of(item: Any, flags: Optional[Dict[str, Any]], refs_min: Any, kind: str = "movie",
                     consensus: Optional["LengthConsensus"] = None) -> str:
    """`runtime_class` streamu (objekt `Release` i slovník výpisu) z jeho nejlepší známé délky (`duration_s`);
    `consensus` = shoda délek kopií téhož výpisu (`length_consensus`, jádro 1.2.3) — jen film."""
    dur, src = duration_s(item, flags)
    name = _field(item, "name", "")
    trusted = duration_trusted(src, flags, name)
    return with_consensus(runtime_class(dur, trusted, refs_min, kind, name), dur, trusted, refs_min, kind, name,
                          consensus)


# --------------------------------------------------------------------------- #
# Shoda délek kopií = ověřená délka filmu (jádro 1.2.3, 21.11.2026, D-2 — Hunger Games: Úsvit sklizně)
# --------------------------------------------------------------------------- #
# Richie 21.11.2026: „je to nějaký trailer ve smyčce, má 2 hodiny a cca 16 minut“ — padělek 8 214 s, čtyři skutečné kopie
# shodně 8 968 s, TMDb před premiérou 159 min (odhad). Délka, na které se shodne víc nezávislých kopií, je o filmu
# spolehlivější údaj než TMDb. Stream KRATŠÍ než tahle shoda o víc než `CONSENSUS_SHORT_TOL`, jehož délku nemá ani
# `CONSENSUS_MIN_COPIES` kopií a který je od TMDb dál než shoda, „nesedí“ (zašedlé, na konec) i uvnitř ±10 % od TMDb.
# Měření 21.11.2026 nad snímky Trendů (910 filmů, 15 283 streamů, `Temp/cam_trendy_20261121/mereni/`):
#   • shluk = řetěz délek, kde sousední se liší nejvýš o 1 % a celý shluk nejvýš o 3 % (kopie jednoho souboru / jedné
#     nahrávky se liší o sekundy; 3 % < 4,1 % PAL, takže verze PAL je vlastní shluk) — cross-check Codex N5.2 / Argon H2.4:
#     dřív rozpětí jen od první délky shluku, 5980 / 6030 / 6070 s se rozpadly a všechny tři zašedly;
#   • rychlost PAL zkracuje o 4,1 % (54 kratších streamů v pásmu 4 %) → práh 6 %; padělek Hunger Games je o 8,4 % kratší;
#   • vlastní shluk ≥ 3 kopie = jiná SKUTEČNÁ verze (Holy Night: tři kopie VIU / Amazon o 8 % kratší) → nezašedne;
#   • blíž k některé referenci TMDb než shoda = kinoverze proti prodloužené většině (D6) → nezašedne (cross-check
#     Flash N5.1 / Argon H2.3 / Codex N5.1: dřív se brala jen reference nejbližší shodě a s délkami [100, 140] zašedla
#     kinoverze 100 min, když většina kopií byla prodloužená);
#   • jen KRATŠÍ: delší = prodloužená verze (D6) — padělek delší než film tohle pravidlo nechytá (vědomá mez);
#   • vědomá mez (Argon H2, Codex H2): legitimní kratší verze v 1–2 kopiích (bez závěrečných titulků, TV střih) vedle ≥ 3
#     plných kopií zašedne — zůstává ve výpisu, jen dole s „Nesedí stopáž!“; počet kopií nedokládá nezávislé zdroje.
#   Nově zašedlých 20 z 15 283 (0,13 %; s referencí TMDb, `tools/overeni_jadra.py`): kratší CAM nahrávky,
#   „Young Washington 1080 / 720.mkv“, „Mortal Kombat II (2026).mkv“. Dostupnost filmu to nemění — shoda je vždy ≥ 3 kopie.
# Jen film s referenční délkou TMDb, jen důvěryhodná délka (`duration_trusted`), dělený soubor (CD1 / part) nikdy.
# Doplněk (výpis) i Gate (noc Trendů) volají TUTÉŽ funkci nad délkami celého výpisu.
CONSENSUS_MIN_COPIES = 3
CONSENSUS_CLUSTER_TOL = 0.01
CONSENSUS_CLUSTER_SPAN = 0.03
CONSENSUS_SHORT_TOL = 0.06


class LengthConsensus(NamedTuple):
    value_s: float                              # medián nejsilnějšího shluku; 0 = shoda není
    clusters: Tuple[Tuple[float, ...], ...]     # všechny shluky (seřazené délky), pro velikost vlastního shluku


NO_CONSENSUS = LengthConsensus(0.0, ())


def _length_clusters(durations: Iterable[float]) -> List[List[float]]:
    """Shluky délek: seřazeno; délka se napojí, když je od PŘEDCHOZÍ nejvýš o `CONSENSUS_CLUSTER_TOL` a od první délky
    shluku nejvýš o `CONSENSUS_CLUSTER_SPAN` (řetěz blízkých kopií, ale nikdy přes rozdíl PAL)."""
    out: List[List[float]] = []
    for d in sorted(float(x) for x in durations if x and float(x) > 0):
        if (out and d <= out[-1][-1] * (1.0 + CONSENSUS_CLUSTER_TOL)
                and d <= out[-1][0] * (1.0 + CONSENSUS_CLUSTER_SPAN)):
            out[-1].append(d)
        else:
            out.append([d])
    return out


def length_consensus(durations: Iterable[float]) -> LengthConsensus:
    """Shoda délek kopií výpisu: nejsilnější shluk má aspoň `CONSENSUS_MIN_COPIES` délek a je VĚTŠÍ než každý jiný
    (remíza = shoda není). `durations` = důvěryhodné délky streamů (`trusted_duration`; 0 se vynechá)."""
    clusters = _length_clusters(durations)
    if not clusters:
        return NO_CONSENSUS
    ranked = sorted(clusters, key=len, reverse=True)
    top = ranked[0]
    if len(top) < CONSENSUS_MIN_COPIES or (len(ranked) > 1 and len(ranked[1]) >= len(top)):
        return NO_CONSENSUS
    mid = len(top) // 2
    median = top[mid] if len(top) % 2 else (top[mid - 1] + top[mid]) / 2.0
    return LengthConsensus(float(median), tuple(tuple(c) for c in clusters))


def trusted_duration(item: Any, flags: Optional[Dict[str, Any]]) -> float:
    """Délka streamu, které smí věřit shoda kopií (`duration_trusted`), jinak 0."""
    dur, src = duration_s(item, flags)
    return float(dur) if dur and duration_trusted(src, flags, _field(item, "name", "")) else 0.0


def below_consensus(dur_s: float, consensus: Optional[LengthConsensus], refs_min: Any) -> bool:
    """Je důvěryhodná délka KRATŠÍ než shoda kopií tak, že nesedí? (pravidlo viz konstanty `CONSENSUS_*`)."""
    if consensus is None or consensus.value_s <= 0 or not dur_s or dur_s <= 0:
        return False
    cons = consensus.value_s
    if dur_s >= cons * (1.0 - CONSENSUS_SHORT_TOL):
        return False
    own = next((c for c in consensus.clusters if c and c[0] <= dur_s <= c[-1]), ())
    if len(own) >= CONSENSUS_MIN_COPIES:
        return False                    # jiná skutečná verze (vlastní shluk aspoň tří kopií)
    try:
        refs = [float(x) * 60.0 for x in (refs_min or []) if float(x) > 0]
    except (TypeError, ValueError):
        refs = []
    if not refs:
        return False                    # bez reference TMDb se o verzi nerozhoduje (= výpis doplňku bez délky titulu)
    # blíž k NĚKTERÉ referenci TMDb než shoda ke své nejbližší = jiná doložená verze (kinoverze × prodloužená většina, D6)
    return min(abs(dur_s - r) for r in refs) > min(abs(cons - r) for r in refs)


def with_consensus(verdict: str, dur_s: float, trusted: bool, refs_min: Any, kind: str, name: Any,
                   consensus: Optional[LengthConsensus]) -> str:
    """Třída délky po zohlednění shody kopií: `ok` → `mismatch`, když `below_consensus` (jen film, jen důvěryhodná
    délka, ne dělený soubor). Ostatní třídy beze změny — `unknown` znamená chybějící délku nebo referenci, a bez obojího
    shoda nerozhoduje (cross-check Flash N4.1: dřív slibovaná větev `unknown` → `mismatch` byla nedosažitelná)."""
    if consensus is None or kind != KIND_MOVIE or not trusted or verdict != RUNTIME_OK:
        return verdict
    if is_split_file(name):
        return verdict
    return RUNTIME_MISMATCH if below_consensus(dur_s, consensus, refs_min) else verdict


# --------------------------------------------------------------------------- #
# Dostupnost a „jistý originál“ (jádro 1.2.3, 21.11.2026, D-3 + D-4 — noc Trendů na Gate)
# --------------------------------------------------------------------------- #
# Richie 21.11.2026: „14% tolerance, která pustí do trendy je podle mě špatně“ → do „dostupné“ se počítá jen stream, kterému
# délka sedí, nebo ji zatím neznáme (`counts_for_availability`); zašedlé ne. A: „v trendy by mělo být … červeně tlustě
# "CAM" … pokud tedy není jistý stream originální“ → `source_class` nad počítanými streamy:
#   orig = aspoň jeden stream, který není záznam z kina OBRAZEM (stupeň ≠ cam / cam?) a jeho původ je doložený:
#          POTVRZENÁ délka (`ok`) NEBO zdroj obrazu ve jménu (`source_grade.has_video_source`: WEB-DL, BluRay…);
#   cam  = žádný takový, ale aspoň jeden počítaný záznam z kina (cam / cam?);
#   ""   = neznámo (jen neznámé délky bez CAM, SkTorrent…) → žádný štítek (R2).
# Proč i jméno: Gate zná MediaInfo jen u menšiny souborů (snímky 21.11.: 3 344 důvěryhodných délek z 15 283) — jen
# z potvrzené délky by štítek CAM dostaly i filmy s desítkami 4K WEB-DL kopií (Weapons, Minecraft). Holé jméno bez zdroje
# a bez potvrzené délky originál nedokládá (padělek „Název (2026).mp4“).
# „Zvuk z kina“ (`audio`) má obraz odjinud — štítek „záznam kamerou“ by lhal; SCREENER (`scr`) je originál obrazem.
SOURCE_ORIG, SOURCE_CAM = "orig", "cam"
SOURCE_CLASSES = (SOURCE_ORIG, SOURCE_CAM)
COUNTED_CLASSES = (RUNTIME_OK, RUNTIME_UNKNOWN)
_CAM_VIDEO_GRADES = (GRADE_CAM, GRADE_CAM_MAYBE)


def counts_for_availability(runtime_cls: str) -> bool:
    """Počítá se stream do verdiktu „dostupné“? Jen délka sedí nebo neznámá (`off` ani `mismatch` ne)."""
    return runtime_cls in COUNTED_CLASSES


def availability_class(runtime_cls: str, trusted: bool) -> str:
    """Třída délky pro DOSTUPNOST a třídu zdroje (noc Trendů): „nesedí“ jen z NEdůvěryhodné délky (AVI / OGG / TS
    z MediaInfo — odhad z části souboru, Café de Flore AVI 42 min × skutečných 121) = neznámo, ne důkaz cizího obsahu
    (audit Fable F37 R1: 341 takových streamů ve snímcích 21.11.). Výpis je dál šedý (zobrazení beze změny)."""
    if runtime_cls == RUNTIME_MISMATCH and not trusted:
        return RUNTIME_UNKNOWN
    return runtime_cls


def source_class(entries: Iterable[Tuple[Any, str, Any]], title_norms: Iterable[str] = ()) -> str:
    """Třída zdroje filmu z trojic (stupeň `source_grade`, třída délky `runtime_class`, jméno souboru) streamů výpisu —
    počítají se jen `counts_for_availability`; `title_norms` = názvy titulu (slovo názvu „Web“ zdroj obrazu nedokládá)."""
    norms = tuple(title_norms or ())
    any_cam = False
    for grade, cls, name in entries:
        if not counts_for_availability(cls):
            continue
        g = str(grade or "")
        if g in _CAM_VIDEO_GRADES:
            any_cam = True
        elif cls == RUNTIME_OK or has_video_source(str(name or ""), norms):
            return SOURCE_ORIG
    return SOURCE_CAM if any_cam else ""


# --------------------------------------------------------------------------- #
# Dolby Vision podle schopností zařízení (noc 03.11.2026, 4.0.6, plán Φ3)
# --------------------------------------------------------------------------- #
# Bětčin Mac: 4K stream s Dolby Vision = černý obraz (Kodi 21 na macOS/Windows DV neumí, `OutputPicture - timeout
# waiting for buffer`). Profil 5 nemá kompatibilní vrstvu → bez DV nikdy obraz; 7/8 (HDR10/SDR/HLG základ) hrají.
# D3 plánu: jen POŘADÍ, nikdy filtr. „ne“ (profil 5) jde za všechny hratelné (jako vadný soubor), „asi ne“ (DV bez
# známého profilu) jen za hratelné téže kvality. Zařízení, které DV umí (`richmovie_device_env.dv_supported`), nic nemění.
DV_OK = 0
DV_MAYBE = 1
DV_NO = 2
_DV_NAME_RE = re.compile(r"(?<![a-z0-9])(dv|dovi|dolby[\s._-]?vision)(?![a-z0-9])", re.I)
_HDR_NAME_RE = re.compile(r"(?<![a-z0-9])(hdr10\+?|hdr|hlg)(?![a-z0-9])", re.I)
_DV_COMPAT_OK = ("hdr10", "sdr", "hlg")


def dv_playability(flags: Optional[Dict[str, Any]], name: Any, dv_supported: bool) -> int:
    """Přehraje TOTO zařízení obraz streamu? DV_OK / DV_MAYBE / DV_NO (čistá funkce, harness scénář 94).
    MediaInfo (Gate probe) má přednost před názvem souboru; název rozhoduje jen bez MediaInfo."""
    if dv_supported:
        return DV_OK
    fl = flags if isinstance(flags, dict) else {}
    hdr = str(fl.get("hdr") or "").upper()
    if hdr and hdr != "DOVI":
        return DV_OK                     # MediaInfo zná jiné HDR / SDR → základ hraje (i když název říká DV)
    compat = str(fl.get("dv_compat") or "").lower()
    prof = fl.get("dv_profile")
    if hdr == "DOVI":
        # profil 5 nemá kompatibilní vrstvu ze specifikace — má přednost před textem kompatibility (cross-check Argon
        # P5/P8: statická metadata SMPTE ST 2086 u profilu 5 by jinak daly „hdr10“ a černý obraz nahoře)
        if prof == 5 or compat == "none":
            return DV_NO
        if compat in _DV_COMPAT_OK or prof in (7, 8, 9):
            return DV_OK
    text = str(name or "")
    if hdr != "DOVI" and not _DV_NAME_RE.search(text):
        return DV_OK
    if _HDR_NAME_RE.search(text):
        return DV_OK                     # „DV.HDR10“ / „DoVi HDR“ = hybrid s HDR10 vrstvou
    return DV_MAYBE


def dv_label_prefix(rank: int) -> str:
    """Štítek ve výpisu streamů (jen na zařízení bez DV)."""
    if rank == DV_NO:
        return "⚠ DV · "
    if rank == DV_MAYBE:
        return "DV? · "
    return ""


# Jádro 1.2.0 (D-4, `rm_core.source_grade`): jistý záznam z kina (`cam`) jde za VŠECHNY streamy, které z kina nejsou —
# i před preferencí dabingu (CZ dabing z kina pod anglický WEB-DL s titulky; CAM zůstává vidět a jde pustit);
# pravděpodobný (`cam_maybe`) jen za streamy téže kvality; zvuk z kina (`cine_audio`) jen za streamy téže kvality a dabingu.
# Jádro 1.2.3 (D-1, Richie 21.11.2026: „Zašedlé půjde opravdu úplně dolů, pod CAM.“): nesedící délka (`runtime_mismatch`)
# hned za relevancí ručního hledání — před CAM i před preferencí zvuku / titulků. Do 1.2.2 stála za CAM a za preferencemi,
# takže jediná kopie BEZ značky CAM (padělek „Hunger Games: Úsvit sklizně (2026).mp4“, trailer ve smyčce 2:16) šla mezi
# samými CAM kopiemi na první místo, i když byla šedá. Skutečné kopie filmu mají stejnou délku → jejich pořadí se nemění.
# Díl seriálu (`Release.kind` = tv) dál JAKO DO 1.2.2 — nesedící délka až za preferencemi (`runtime_mismatch_tv`): TMDb
# délku dílu často uvádí špatně (Griffinovi 50 min × skutečných 22) a nové pořadí by změřené díly s preferovaným dabingem
# stáhlo pod nezměřené cizojazyčné (cross-check Argon H1, Codex H1); padělky podle délky jsou problém filmů.
SORT_KEY_FIELDS: Tuple[str, ...] = ("ws_rel", "runtime_mismatch", "cam", "pref_audio", "pref_subs", "runtime_mismatch_tv",
                                    "title_penalty", "continuity", "quality", "dv_maybe", "cam_maybe", "cz_dub",
                                    "cine_audio", "junk", "runtime_unconfirmed", "no_match", "neg_size", "score")


def cam_ranks(item: Any) -> Tuple[int, int, int]:
    """(jistý CAM, pravděpodobný CAM, zvuk z kina) jako 0/1 podle `source_grade` streamu."""
    g = str(_field(item, "source_grade", "") or "")
    return (1 if g == "cam" else 0, 1 if g == "cam?" else 0, 1 if g in ("audio", "audio?") else 0)


def stream_sort_key(item: Any, flags: Optional[Dict[str, Any]] = None, pref_terms: Tuple[int, int] = (0, 0),
                    continuity_rank: int = 0, score_key: Tuple = (), dv_rank: int = DV_OK) -> Tuple:
    """SSOT řadicí klíč streamu (nižší = výš; pole viz `SORT_KEY_FIELDS`). `item` = `Release` nebo slovník;
    `flags` = MediaInfo z cache; `pref_terms` = (zvuk, titulky) podle preference diváka; `continuity_rank`
    = stejná verze jako minulý díl; `score_key` = skóre enginu jako n-tice; `dv_rank` = `dv_playability`
    (DV_MAYBE jen za hratelné téže kvality; DV_NO řadí výš `plugin._listing_sort_key`)."""
    try:
        size = int(float(_field(item, "size", 0) or 0))
    except (TypeError, ValueError):
        size = 0
    if not size:
        try:
            size = int(float(_field(item, "size_mb", 0) or 0)) * 1_048_576
        except (TypeError, ValueError):
            size = 0
    q_rank, _label = quality_of(item, flags)
    cam_sure, cam_maybe, cine_audio = cam_ranks(item)
    mismatch = 1 if _field(item, "runtime_mismatch", False) else 0
    episode = str(_field(item, "kind", "") or "") == KIND_TV         # D-1 jen film (viz `SORT_KEY_FIELDS`)
    return (
        int(_field(item, "ws_rel", 0) or 0),
        mismatch if not episode else 0,
        cam_sure,
        int(pref_terms[0]), int(pref_terms[1]),
        mismatch if episode else 0,
        int(_field(item, "title_penalty", 0) or 0),
        int(continuity_rank or 0),
        q_rank,
        1 if int(dv_rank or 0) == DV_MAYBE else 0,
        cam_maybe,
        cz_rank(flags, _field(item, "audios", None)),
        cine_audio,
        junk_rank(_field(item, "name", "")),
        0 if _field(item, "runtime_confirmed", False) else 1,
        0 if _field(item, "match", False) else 1,
        -size,
        tuple(score_key or ()),
    )


# --------------------------------------------------------------------------- #
# Schopnosti přehrávače (`caps`) — G1, 09.11.2026 (RichMovie Go pro TV, plán A9)
# --------------------------------------------------------------------------- #
# Televize přehrává hardwarem: DTS, Dolby Vision profil 5, HEVC v AVI ani MPEG-4 ASP s GMC na ní nejde
# (plán §3.3, S2 §1). `caps` říká, co zařízení UMÍ; chybějící klíč = umí (výchozí = Kodi: jeho softwarové
# dekodéry všechno z toho přehrají). Jen POŘADÍ, nikdy filtr — stejně jako `dv_playability`.
#   PLAY_NO   = jde za všechny hratelné (jako vadný soubor / DV bez kompatibilní vrstvy)
#   PLAY_MAYBE = jen za hratelné téže kvality (údaj z názvu souboru, MediaInfo to nepotvrdila)
PLAY_OK = DV_OK
PLAY_MAYBE = DV_MAYBE
PLAY_NO = DV_NO
_DTS_NAME_RE = re.compile(r"(?<![a-z0-9])dts(?:[.\s_-]?(?:hd|x|ma))?(?![a-z0-9])", re.I)
# jiný zvuk v názvu vedle DTS (pak název sám „jen DTS“ nedokazuje)
_OTHER_AUDIO_NAME_RE = re.compile(
    r"(?<![a-z0-9])(?:e?ac3|dd(?:p)?\s?[257]\.[01]|aac|mp3|opus|flac|truehd|atmos)(?![a-z0-9])", re.I)
_HEVC_NAME_RE = re.compile(r"(?<![a-z0-9])(?:hevc|x\.?265|h\.?265)(?![a-z0-9])", re.I)
_AVI_EXT = ".avi"

# Výchozí schopnosti: chybějící klíč = zařízení umí (Kodi software). Doplněk předává `{"dv": dv_supported}`, TV svůj
# seznam z `device/report` (P4: `listing_sort_key` s `{"dv": x}` = `plugin._listing_sort_key` na zařízení s DV = x).
DEFAULT_CAPS: Dict[str, Any] = {}


def _cap(caps: Optional[Dict[str, Any]], name: str) -> bool:
    return True if not isinstance(caps, dict) else caps.get(name, True) is not False


def _dts_only_flags(flags: Dict[str, Any]) -> Optional[bool]:
    """Jsou VŠECHNY zvukové stopy (MediaInfo) DTS? None = kodeky stop neznáme (starý záznam bez pole)."""
    codecs = flags.get("audio_codecs") if isinstance(flags, dict) else None
    if not isinstance(codecs, (list, tuple)) or not codecs:
        return None
    known = [str(c or "").strip().lower() for c in codecs if c]
    if not known:
        return None
    return all(c.startswith("dts") for c in known)


def playability(flags: Optional[Dict[str, Any]], name: Any, caps: Optional[Dict[str, Any]] = None) -> int:
    """Přehraje stream zařízení se schopnostmi `caps`? PLAY_OK / PLAY_MAYBE / PLAY_NO (nejhorší nález vyhrává).
    `flags` = MediaInfo (Gate probe; chybějící údaj = neznámo, bez trestu), `name` = název souboru. Bez `caps` se
    zvažuje jen DV podle chybějícího klíče (= zařízení DV umí); doplněk předává `{"dv": dv_supported}`, televize
    svůj seznam schopností z `POST /v1/go/device/report`."""
    fl = flags if isinstance(flags, dict) else {}
    # Dolby Vision: DV_OK/MAYBE/NO podle `dv` (výchozí Kodi předává zařízení, chybějící klíč = umí)
    worst = dv_playability(fl, name, _cap(caps, "dv"))
    if not isinstance(caps, dict) or not caps:
        return worst
    text = str(name or "")
    # DTS
    if not _cap(caps, "dts"):
        dts_only = _dts_only_flags(fl) if not fl.get("fail") else None
        if dts_only is True:
            worst = max(worst, PLAY_NO)
        elif dts_only is None and _DTS_NAME_RE.search(text) and not _OTHER_AUDIO_NAME_RE.search(text):
            worst = max(worst, PLAY_MAYBE)
    # HEVC v AVI (televize ho nedekóduje, Kodi ano)
    if not _cap(caps, "hevc_in_avi"):
        lname = text.lower()
        if lname.endswith(_AVI_EXT) or "%s " % _AVI_EXT in lname:
            codec = str(fl.get("video_codec") or "").strip().lower() if not fl.get("fail") else ""
            if codec.startswith(("hevc", "h265", "h.265", "x265")):
                worst = max(worst, PLAY_NO)
            elif not codec and _HEVC_NAME_RE.search(text):
                worst = max(worst, PLAY_MAYBE)
    # MPEG-4 ASP s Global Motion Compensation (známé jen z MediaInfo; bez údaje bez trestu)
    if not _cap(caps, "gmc") and fl.get("gmc") and not fl.get("fail"):
        worst = max(worst, PLAY_NO)
    return worst


def listing_sort_key(item: Any, flags: Optional[Dict[str, Any]] = None, *, caps: Optional[Dict[str, Any]] = None,
                     pref_terms: Tuple[int, int] = (0, 0), continuity_rank: int = 0, score_key: Tuple = (),
                     broken_rank: int = 0, ws_blocked: bool = False, unsure_rank: int = 0) -> Tuple:
    """SSOT úplného pořadí streamu ve výpisu (nižší = výš) nad jednotkou `stream_sort_key`:
    možná JINÝ pořad (`unsure_rank`) > vadný soubor (`broken_rank`) > nehratelné na tomto zařízení (`PLAY_NO`) > Webshare
    blokovaný Free účtem. S `caps={"dv": x}` odpovídá `plugin._listing_sort_key` na zařízení s DV = x (brána P4).
    `unsure_rank` (jádro 1.2.2, audit Fable F28 V8: nejistý díl, který automat nepustí — doplněk `plugin._unsure_rank`
    podle kontinuity diváka), `broken_rank` a `ws_blocked` počítá volající ze stavu zařízení, klíč je čistý. Jen pořadí,
    nikdy filtr."""
    play = playability(flags, _field(item, "name", ""), caps)
    blocked = _field(item, "ws_blocked", None)      # slovník nového vzhledu nese příznak přímo (jako `_rel_attr`)
    if blocked is None:
        blocked = bool(ws_blocked) and str(_field(item, "source", "webshare") or "webshare") == "webshare"
    return (int(unsure_rank or 0), int(broken_rank or 0), 1 if play == PLAY_NO else 0, 1 if blocked else 0,
            stream_sort_key(item, flags, pref_terms, continuity_rank, score_key, dv_rank=play))
