# -*- coding: utf-8 -*-
"""rm_core.errors — výjimky TMDb sdílené doplňkem i Gate (přesun z `tmdb_client`, G1)."""
from __future__ import annotations


# ───────────────────  VÝJIMKY  ──────────────────
class TMDbError(RuntimeError):
    """Chyba při komunikaci s TMDb."""


class TMDbTransientError(TMDbError):
    """Přechodná síťová chyba — volající SMÍ degradovat na expirovanou cache.

    Φ4 (2026-08-08). Podtřída `TMDbError` schválně: veškerý existující kód, který
    chytá `except TMDbError`, ji odbaví beze změny. Rozdíl je jen v tom, že metody
    s diskovou cache si podle ní můžou dovolit vrátit stará data místo chyby —
    film z roku 2016 se za 31 dní nezměnil a vyhodit kvůli tomu uživateli dialog
    je nesmysl.

    Trvalé chyby (403 identity, 404, nevalidní JSON) tuhle třídu NEDOSTANOU:
    tam by stará data zakrývala skutečný problém.
    """


class TMDbAuthError(TMDbError):
    """Gate autoritativně odmítl IDENTITU (401/403 s JSON kódem proof_mismatch,
    not_authorized, inactive…), nebo je identita už zamítnutá a volání selhalo
    lokálně bez sítě (fail-fast).

    3.5.118 (2026-08-21). Podtřída `TMDbError` — stávající `except TMDbError`
    odbaví beze změny. Rozdíl proti obecné `TMDbError("Status 403")`: volající
    s negativní cache (instalátor kolekcí, MI2) podle ní poznají, že výsledek
    NENÍ vlastnost titulu/souboru a NESMÍ se perzistovat jako „neexistuje".
    Cloudflare HTML 403 (bez Gate JSON) tuhle třídu NEDOSTANE — zůstává obecnou
    `TMDbError`, protože o identitě nic neříká.
    """


class TMDbNotFoundError(TMDbError):
    """HTTP 404 — AUTORITATIVNÍ odpověď zdroje pravdy „tohle neexistuje".

    3.5.118 (2026-08-21). Jediný druh selhání, který smí negativní cache
    perzistovat (R2 plánu): titul/sezóna na TMDb není a další pokus to nezmění.
    Všechno ostatní (transport, 5xx, 429, identita) je stav infrastruktury.
    """
