# -*- coding: utf-8 -*-
"""richmovie_list_focus — kurzor ve výpisu pluginu na zvolený řádek po vykreslení (4.5.3, BACKLOG S57).

Proč: Kodi 21 posadí kurzor na „první nezhlédnutý díl“ JEN ve videoknihovně (`CGUIWindowVideoNav::GetSettingSelectFirst
UnwatchedItem` → `m_vecItems->IsVideoDb()`); výpis pluginu otevře vždy nahoře. Richie 15.11.2026 (Hvězdná brána z „Naposledy
sledované seriály“): „proč to není seřazeno od posledního sledovaného?“ Pořadí dílů zůstává (číslo dílu), kurzor jde na díl,
kde divák pokračuje (`richmovie_series_nav.focus_episode`).

Jak (ověřeno ve zdrojích Kodi 21 Omega): builtin `SetFocus(id, pozice, absolute)` → `GUI_MSG_SETFOCUS` → `CGUIBaseContainer`
`SelectItem(pozice)` od začátku seznamu; položka „..“ (nastavení „zobrazit nadřazenou složku“) se do pozice POČÍTÁ.
`Container.CurrentItem` vrací pro řádek výpisu `r` (0 = první položka pluginu) vždy `r + 1` (PASTI 4.5.3, F2 V2) → po
posunu se ověří a při omylu v „..“ jednou opraví.

Kdy NE (kurzor se nikdy netahá divákovi pod rukama): jiný výpis / okno, výpis se ještě staví, existuje přehrávač, divák už
listuje (`richmovie_listing.viewer_browsing`), fokus není na seznamu. Čeká nejvýš `WAIT_S`, každých `POLL_S` (jen
`Monitor.waitForAbort`). Rozhodnutí = čisté `plan_focus`; Kodi jen v `focus_row_after_render`.
"""
from __future__ import annotations

from typing import Any, Optional, Tuple

import richmovie_listing as _listing

WAIT_S = 3.0
POLL_S = 0.05
VERIFY_S = 0.3

FOCUSED = "focused"
CORRECTED = "focused_corrected"
SKIP_BROWSING = "skip_browsing"
SKIP_PLAYER = "skip_player"
SKIP_NO_CONTROL = "skip_no_control"
SKIP_TIMEOUT = "skip_timeout"
SKIP_ABORT = "skip_abort"
SKIP_INVALID = "skip_invalid"
FAILED_VERIFY = "failed_verify"
FAILED_ERROR = "failed_error"


def target_position(row_index: int, has_parent: bool) -> int:
    """Absolutní pozice v seznamu Kodi pro řádek pluginu `row_index` (0 = první položka pluginu)."""
    return int(row_index) + (1 if has_parent else 0)


def expected_current_item(row_index: int) -> str:
    """`Container.CurrentItem` po správném posunu (PASTI 4.5.3: řádek r → r + 1, s „..“ i bez ní)."""
    return str(int(row_index) + 1)


def plan_focus(*, ready: bool, player: bool, current_item: Any, control_id: Any) -> Tuple[Optional[int], str]:
    """(id ovládacího prvku | None, důvod). `ready` = okno videí, TENTO výpis a dostavěný. Čistá."""
    if not ready:
        return None, SKIP_TIMEOUT
    if player:
        return None, SKIP_PLAYER
    if _listing.viewer_browsing(current_item):
        return None, SKIP_BROWSING
    try:
        cid = int(str(control_id or "").strip())
    except (TypeError, ValueError):
        return None, SKIP_NO_CONTROL
    if cid <= 0:
        return None, SKIP_NO_CONTROL
    return cid, ""


def _ready(xbmc: Any, listing_key: str) -> bool:
    return bool(xbmc.getCondVisibility("Window.IsActive(videos)")
                and _listing.same_listing(_listing.listing_key_from_kodi(), listing_key)
                and not xbmc.getCondVisibility("Container.IsUpdating"))


def _is_list(xbmc: Any, control_id: int) -> bool:
    """Má fokus seznam? (`Container(<id>).NumItems` > 0; boční menu / tlačítko položky nemá — cross-check 2. kola A2-1B)."""
    try:
        return int(str(xbmc.getInfoLabel("Container(%d).NumItems" % control_id) or "0").strip()) > 0
    except (TypeError, ValueError):
        return False


def _wait_current(xbmc: Any, mon: Any, want: str) -> str:
    """`Container.CurrentItem` po posunu (nejvýš VERIFY_S; obvykle hned — `executebuiltin(..., True)` čeká na provedení)."""
    waited = 0.0
    cur = (xbmc.getInfoLabel("Container.CurrentItem") or "").strip()
    while cur != want and waited < VERIFY_S:
        if mon.waitForAbort(POLL_S):
            break
        waited += POLL_S
        cur = (xbmc.getInfoLabel("Container.CurrentItem") or "").strip()
    return cur


def focus_row_after_render(row_index: Optional[int], listing_key: str, *, wait_s: float = WAIT_S) -> str:
    """Po `endOfDirectory`: počká na vykreslení výpisu `listing_key` a posadí kurzor na řádek `row_index` (1+ = řádek pluginu;
    0 / None = kurzor už je tam, kde má být). Vrací důvod (pro log `LIST_FOCUS`). Nikdy nevyhodí.

    Pojistky (cross-check 2. kola A2): stav se ověří znovu TĚSNĚ před posunem (divák mohl mezitím odejít), fokus musí být
    seznam, a druhý pokus s opačnou „..“ jen když první posun prokazatelně skončil o řádek vedle (ne když se popisek
    jen opozdil) — kurzor se nikdy nepřesune podruhé naslepo."""
    if row_index is None or int(row_index) <= 0:
        return SKIP_INVALID
    try:
        import xbmc
        mon = xbmc.Monitor()
        waited = 0.0
        ready = False
        while waited <= wait_s:
            if _ready(xbmc, listing_key):
                ready = True
                break
            if mon.waitForAbort(POLL_S):
                return SKIP_ABORT
            waited += POLL_S
        try:
            import richmovie_playback_dispatch as _dispatch
            player = bool(_dispatch.player_present(on_error=True))
        except Exception:
            player = True
        cid, why = plan_focus(ready=ready, player=player, current_item=xbmc.getInfoLabel("Container.CurrentItem"),
                              control_id=xbmc.getInfoLabel("System.CurrentControlId"))
        if cid is None:
            return why
        if not _is_list(xbmc, cid):
            return SKIP_NO_CONTROL
        has_parent = (xbmc.getInfoLabel("Container.ListItemAbsolute(0).Label") or "").strip() == ".."
        want = expected_current_item(row_index)
        cur0 = (xbmc.getInfoLabel("Container.CurrentItem") or "").strip()
        if not _ready(xbmc, listing_key) or _listing.viewer_browsing(cur0):
            return SKIP_BROWSING if _listing.viewer_browsing(cur0) else SKIP_TIMEOUT
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, target_position(row_index, has_parent)), True)
        cur = _wait_current(xbmc, mon, want)
        if cur == want:
            return FOCUSED
        # „..“ rozpoznaná špatně (skin / jazyk popisku): první posun skončil přesně o řádek vedle → jednou druhá varianta
        off_by_parent = str(int(row_index) + 2) if has_parent else str(int(row_index))
        if cur == cur0 or cur != off_by_parent:
            return FAILED_VERIFY
        xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, target_position(row_index, not has_parent)), True)
        return CORRECTED if _wait_current(xbmc, mon, want) == want else FAILED_VERIFY
    except Exception:
        return FAILED_ERROR
