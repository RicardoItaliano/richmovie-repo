# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 richmovie_title_suggest — „Mysleli jste…?“ při hledání titulu (4.5.3, A3b; Gate mig 0056)
───────────────────────────────────────────────────────────────────────────────
PROČ
  Audit flotily 10.11.2026 (A2-02 / A4-11): 12 % hledání filmu (20/169, 7 účtů) skončilo „Nic nenalezeno.“ kvůli
  překlepu nebo chybějící diakritice — „absulotni moc“, „scarry movie“, „jak ziji duchove“, „kralovsvi zverstev“.
  TMDb neodpouští, divák pak píše ovladačem znovu (3,8 s na znak na TV). Gate má z cache TMDb katalog ~38 tis.
  titulů česky i v originále a umí podobnost trigramů (`POST /v1/tmdb/suggest`).

PRAVIDLA
  • Jen když TMDb vrátí NULU — návrhy nikdy nemění výsledek, který TMDb našel (víc výsledků, nikdy míň).
  • Dotaz na Gate jen s identitou; rozpočet krátký (divák čeká na výsledek hledání), 429 se neopakuje (richmovie_http).
  • Chyba / neplatná odpověď = prázdný seznam = dnešní „Nic nenalezeno“ (R2: nic se neukládá, nic se nepředstírá).
  • Návrh se NIKDY nespouští sám (ani jediný) — divák ho musí potvrdit kliknutím.
  • Čistá funkce `parse_response` bez Kodi → harness scénář 123.
"""
from __future__ import annotations

from typing import Any, Dict, List

ENDPOINT = "/v1/tmdb/suggest"
KINDS = ("movie", "tv")
Q_MAX = 120                       # = Gate `SuggestIn.q` max_length (delší dotaz Gate odmítne 422)
REQUEST_BUDGET_S = 4.0            # divák právě čeká na výsledek hledání
REQUEST_TIMEOUT_S = 3.0
REQUEST_MAX_ATTEMPTS = 2
ITEMS_MAX = 8                     # = Gate `store.LIMIT`

TOAST_HEADING = "Hledání"
TOAST_TEXT = "„%s“ jsem přesně nenašel — mysleli jste některý z těchto?"
CATEGORY = "Mysleli jste: %s"     # nadpis výpisu s návrhy (plugin `_movie_search` / `_tv_search`)


def parse_response(status: Any, body: Any, kind: str) -> List[Dict[str, Any]]:
    """Položky ve tvaru výsledků `tmdb_client.search` (film: `title`, seriál: `name`) — přesný tvar, jinak []. Čistá."""
    if status != 200 or not isinstance(body, dict) or body.get("status") != "ok" or not isinstance(body.get("items"), list):
        return []
    out: List[Dict[str, Any]] = []
    for it in body["items"][:ITEMS_MAX]:
        if not isinstance(it, dict):
            continue
        try:
            tid = int(it.get("id"))
        except (TypeError, ValueError):
            continue
        title = str(it.get("title") or "").strip()
        if tid <= 0 or not title:
            continue
        try:
            year = int(it.get("year") or 0)
        except (TypeError, ValueError):
            year = 0
        try:
            rating = round(float(it.get("rating") or 0), 1)
        except (TypeError, ValueError):
            rating = 0.0
        row = {"id": tid, "year": year, "poster_path": str(it.get("poster_path") or ""), "backdrop_path": "",
               "overview": "", "rating": rating, "votes": int(it.get("votes") or 0) if str(it.get("votes") or "0").isdigit() else 0,
               "suggested": True}
        if kind == "tv":
            row["name"] = title
        else:
            row["title"] = title
        out.append(row)
    return out


def suggest(query: str, kind: str) -> List[Dict[str, Any]]:
    """Návrhy titulů pro dotaz s NULOU výsledků (film / seriál). Nikdy nevyhodí výjimku; chyba = []."""
    q = " ".join(str(query or "").split())[:Q_MAX]
    if not q or kind not in KINDS:
        return []
    try:
        import richmovie_gate_transport as _gt
        import richmovie_http as _http
        from richmovie_sync_queue import identity_body
        body = identity_body({"q": q, "kind": kind})
        if not body.get("ws_proof"):
            return []                                  # bez identity by Gate odmítl — nic neposílat
        profile = _http.profile_foreground().replace(budget_s=REQUEST_BUDGET_S, timeout_s=REQUEST_TIMEOUT_S,
                                                     max_attempts=REQUEST_MAX_ATTEMPTS)
        status, resp = _gt.post_json(ENDPOINT, body, profile=profile)
    except Exception:
        return []
    return parse_response(status, resp, kind)

