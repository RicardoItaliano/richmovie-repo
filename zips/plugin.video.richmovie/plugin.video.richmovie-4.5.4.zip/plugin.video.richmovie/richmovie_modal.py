# -*- coding: utf-8 -*-
"""richmovie_modal.py — SSOT modálního okna doplňku (4.5.3; incident 14.11.2026 23:01, PC Richie-Home)

Co se stalo
-----------
RichMovie se po startu Kodi otevřelo samo (autostart) a ukázalo „Kdo se dívá?“. O pět sekund později Kodi
z oficiálního repozitáře aktualizovalo češtinu (`resource.language.cs_cz` 11.0.103 → 11.0.104) a kvůli ní znovu
načetlo vzhled. Výběr profilu z obrazovky zmizel, Python ale dál čekal v `doModal()` a držel uvítací sekvenci.
Obnovené hlavní okno spustilo menu znovu, to 30 s ukazovalo „Dokončuji uvítání…“ a výběr profilu nepřišel vůbec;
`doModal` se vrátil až při vypnutí Kodi (kodi.log 23:01:19.232 → 23:02:01.567).

Proč (zdroj Kodi 21 „Omega“, ověřeno 14.11.2026)
------------------------------------------------
* `xbmc/interfaces/legacy/Window.cpp` `Window::doModal`: smyčka `while (bModal && !g_application.m_bStop)`;
  `bModal = false` nastaví JEN `close()` zavolané z Pythonu (`WindowDialogMixin::close`), nebo vypnutí Kodi.
* `xbmc/guilib/GUIWindowManager.cpp` `DeInitialize` (načtení vzhledu) a `CloseDialogs` (`Dialog.Close(all,true)`)
  zavřou aktivní dialog jen na straně Kodi (`Close(true)`); `WindowXMLDialog::OnDeinitWindow` Pythonu nic neřekne.
* `xbmc/application/ApplicationSkinHandling.cpp` `LoadSkin` po načtení vrátí jen hlavní okno
  (`ActivateWindow(currentWindowID)`), dialogy ne.
Okno, které zavřelo Kodi, už tedy nikdo neuvidí — a Python na ně čeká, dokud Kodi neskončí.

Pravidlo
--------
Každé naše `WindowXMLDialog` dědí `ModalMixin` (PRVNÍ v MRO) a otevírá se JEN přes `do_modal()` nebo
`show_until_answered()` (lint ve scénáři 125). Hlídač okno pozná podle `Window.IsActive(<soubor XML>)`
(GUIInfoManager parametr s „xml“ předá jako jméno souboru → `IsWindowActive(xmlFile)`: hlavní okno nebo aktivní
dialog se stejným souborem; dialog pod jiným dialogem je aktivní dál). Když okno zmizí, aniž ho zavřel Python,
hlídač zavolá `close()` a `do_modal` vrátí False = **divák nic nerozhodl**. Volající to NESMÍ vyložit jako volbu
(Zpět, „Později“, „Teď ne“, vypršený odpočet = spánek). Okna, bez jejichž odpovědi se nedá pokračovat (výběr profilu,
počet lidí, uvítání), otevře `show_until_answered` znovu — nejvýš `REOPEN_MAX`×, nikdy přes přehrávač ani při
vypínání Kodi.

Vlastní hromadné zavření (`Dialog.Close(all,true)` v Stream-pickeru, oknech RM 4.0 a navigaci služby po přehrání) jde
JEN přes `close_all_dialogs(důvod)`: zapíše čas, takže hlídač takto zavřená okna uvolní stejně, ale zaloguje je jako záměr
doplňku (INFO `MODAL_RELEASED`), ne jako zásah Kodi (WARNING `MODAL_LOST`). Časovač okna (odpočet hodnocení, „Díváš se
ještě?“) se před verdiktem „vypršelo“ zeptá `window_active` — okno, které nikdo nevidí, odpočet nevyhodnotí jako spánek.

Vědomé meze: dvě souběžně otevřená okna se STEJNÝM souborem XML hlídač nerozliší (zmizení jednoho nepozná — chová
se jako dřív, nic nezavře omylem). Hlídač se odjistí prvním pozorováním okna (`POLL_S` po startu): okno, které Kodi
zavře dřív (do ~0,25 s po otevření), nebo které se do `ARM_MAX_S` vůbec neukázalo, hlídač nehlídá — chová se jako před
4.5.3 a do user_logs jde WARNING `MODAL_WATCH_UNARMED`. Zavírat i „neukázané“ okno by bylo horší: kdyby dotaz
`Window.IsActive(<xml>)` na některé platformě nefungoval, hlídač by zavřel KAŽDÉ okno po 10 s (cross-check Flash F3b).
"""

from __future__ import annotations

import threading
import time
from typing import Any, Callable, Optional, Tuple

POLL_S = 0.25                # jak často se hlídač ptá Kodi (jeden výraz infomanageru, bez I/O)
LOST_CONFIRM_POLLS = 3       # okno musí chybět 3× za sebou (~0,5–0,75 s) — zavírací animace ani jeden snímek nerozhodnou
ARM_MAX_S = 10.0             # okno se do 10 s neukázalo → hlídač končí a nic nezavře
REOPEN_MAX = 2               # kolikrát smí `show_until_answered` znovu otevřít okno, které zavřelo Kodi
REOPEN_SETTLE_S = 0.5        # po zmizení okna počkat, až Kodi dokončí načtení vzhledu (14.11.2026 trvalo 0,1 s)

VERDICT_WAIT = "wait"
VERDICT_ARMED = "armed"      # okno se poprvé ukázalo
VERDICT_LOST = "lost"        # okno zmizelo, aniž ho zavřel Python
VERDICT_UNARMED = "unarmed"  # okno se do ARM_MAX_S neukázalo

PROP_CLOSE_ALL_AT = "richmovie.modal.close_all_at"   # Window(10000): čas posledního `close_all_dialogs` (napříč procesy)
CLOSE_ALL_GRACE_S = 5.0      # ztráta okna do 5 s po vlastním hromadném zavření = záměr doplňku (INFO), ne zásah Kodi


def _log(msg: str, level: Optional[int] = None) -> None:
    try:
        import xbmc
        from richmovie_logging import make_legacy_logger
        make_legacy_logger("richmovie.modal", "RichMovie/Modal")(msg, xbmc.LOGINFO if level is None else level)
    except Exception:
        try:
            import xbmc
            xbmc.log("[RichMovie/Modal] " + str(msg), xbmc.LOGINFO if level is None else level)
        except Exception:
            pass


def window_active(xml_file: str) -> bool:
    """Vede Kodi okno se souborem `xml_file` jako aktivní (hlavní okno nebo aktivní dialog)? Chyba = True (nic
    se nevyloží jako zmizelé okno). JEDINÁ definice dotazu — hlídač i časovače oken."""
    try:
        import xbmc
        return bool(xbmc.getCondVisibility("Window.IsActive(%s)" % xml_file))
    except Exception:
        return True


def close_all_dialogs(reason: str) -> None:
    """JEDINÉ místo pro `Dialog.Close(all,true)` z doplňku (lint 125). Zapíše čas (`PROP_CLOSE_ALL_AT`, napříč procesy),
    takže hlídače oken, které tím Kodi zavře, je uvolní jako záměr doplňku (INFO), a dialogy zavře."""
    import xbmc
    try:
        import richmovie_winprops as _winprops
        _winprops.set_prop(PROP_CLOSE_ALL_AT, "%.3f" % time.time())
    except Exception as exc:
        _log("MODAL_CLOSE_ALL reason=%s: značka nezapsána %r" % (reason, exc), xbmc.LOGWARNING)
    _log("MODAL_CLOSE_ALL reason=%s" % reason, xbmc.LOGDEBUG)
    xbmc.executebuiltin("Dialog.Close(all,true)")


def _closed_by_addon(now: float) -> bool:
    """Zavřel okna před chvílí sám doplněk (`close_all_dialogs`)?"""
    try:
        import richmovie_winprops as _winprops
        at = float(_winprops.get_prop(PROP_CLOSE_ALL_AT, "") or 0.0)
    except Exception:
        return False
    return 0.0 < at <= now + 1.0 and (now - at) <= CLOSE_ALL_GRACE_S


class Watch(object):
    """Čisté rozhodnutí hlídače (bez Kodi) — harness ho krmí pozorováními.

    `observe(active, elapsed_s, closing=)`: `active` = Kodi vede okno jako aktivní, `closing` = okno zavírá Python
    (vlastní `close()`: volba, Zpět, časovač) — pak se `doModal` vrací sám a hlídač nikdy nerozhodne „zmizelo“."""

    def __init__(self, *, arm_max_s: Optional[float] = None, confirm: Optional[int] = None) -> None:
        # výchozí hodnoty z modulu AŽ při vytvoření (harness zkracuje časy; výchozí argument by je zmrazil při importu)
        self.arm_max_s = float(ARM_MAX_S if arm_max_s is None else arm_max_s)
        self.confirm = max(1, int(LOST_CONFIRM_POLLS if confirm is None else confirm))
        self.armed = False
        self.misses = 0

    def observe(self, active: bool, elapsed_s: float, *, closing: bool = False) -> str:
        if closing:
            return VERDICT_WAIT
        if active:
            first = not self.armed
            self.armed = True
            self.misses = 0
            return VERDICT_ARMED if first else VERDICT_WAIT
        if not self.armed:
            return VERDICT_UNARMED if float(elapsed_s) >= self.arm_max_s else VERDICT_WAIT
        self.misses += 1
        return VERDICT_LOST if self.misses >= self.confirm else VERDICT_WAIT


class ModalMixin(object):
    """Mixin PRVNÍ v MRO (`class X(ModalMixin, xbmcgui.WindowXMLDialog)`, okna RM 4.0 přes `RMNavMixin`).

    `close()` zapíše, že okno zavírá Python — hlídač pak zmizení okna nevyloží jako zavření ze strany Kodi, i když
    obsluha kliknutí po `close()` ještě pracuje (Stream-picker po `close()` skládá okna a spouští přehrávání)."""

    rm_close_requested = False

    def close(self):  # noqa: A003 — jméno z API Kodi
        self.rm_close_requested = True
        super().close()

    def on_modal_lost(self) -> None:
        """Šablona: úklid okna, které zavřelo Kodi (vlákna okna, zvuk) — volá `do_modal` ve vlákně `doModal`
        po jeho návratu. Výchozí nic; okno přepíše, co jinak dělá jeho obsluha zavření."""
        return None


def do_modal(window: Any, xml_file: str, *, tag: str, monitor: Optional[Any] = None) -> bool:
    """`window.doModal()` s hlídačem zmizelého okna.

    Vrací True = okno zavřel Python (volba diváka, Zpět, časovač, vypnutí Kodi), False = okno zavřelo Kodi (načtení
    vzhledu, `Dialog.Close(all)`) a divák nic nerozhodl. Výjimka z `doModal` se propaguje jako dřív; hlídač sám
    nikdy nic nevyhodí."""
    import xbmc
    if not isinstance(window, ModalMixin):
        # Lint 125 to v repu nedovolí; za běhu se okno otevře jako dřív, jen bez hlídače — a nahlas.
        _log("MODAL_WATCH_SKIPPED tag=%s xml=%s: okno bez ModalMixin" % (tag, xml_file), xbmc.LOGERROR)
        window.doModal()
        return True
    stop = threading.Event()
    lost = threading.Event()
    started = time.monotonic()

    def _watch() -> None:
        mon = monitor if monitor is not None else xbmc.Monitor()
        watch = Watch()
        while not stop.wait(POLL_S):
            if mon.abortRequested():
                return                      # Kodi končí → `doModal` se vrátí sám (m_bStop)
            active = window_active(xml_file)
            verdict = watch.observe(active, time.monotonic() - started,
                                    closing=bool(getattr(window, "rm_close_requested", False)))
            if verdict == VERDICT_ARMED:
                _log("MODAL_SHOWN tag=%s after=%.2fs" % (tag, time.monotonic() - started), xbmc.LOGDEBUG)
            elif verdict == VERDICT_UNARMED:
                _log("MODAL_WATCH_UNARMED tag=%s xml=%s — okno se do %.0f s neukázalo, hlídač končí"
                     % (tag, xml_file, ARM_MAX_S), xbmc.LOGWARNING)
                return
            elif verdict == VERDICT_LOST:
                if stop.is_set() or getattr(window, "rm_close_requested", False):
                    return
                lost.set()
                if _closed_by_addon(time.time()):
                    _log("MODAL_RELEASED tag=%s open_s=%.1f — okno zavřel doplněk (close_all_dialogs), uvolňuji doModal"
                         % (tag, time.monotonic() - started), xbmc.LOGINFO)
                else:
                    _log("MODAL_LOST tag=%s xml=%s open_s=%.1f — okno zavřelo Kodi (načtení vzhledu / Dialog.Close), "
                         "uvolňuji doModal" % (tag, xml_file, time.monotonic() - started), xbmc.LOGWARNING)
                try:
                    window.close()
                except Exception as exc:
                    _log("MODAL_LOST tag=%s: close selhal %r" % (tag, exc), xbmc.LOGWARNING)
                return

    # daemon: vlákno nikdy nedělá I/O a končí do POLL_S po návratu `doModal` (join níže) nebo při vypínání Kodi
    thr = threading.Thread(target=_watch, name="RMModalWatch", daemon=True)
    thr.start()
    try:
        window.doModal()
    finally:
        stop.set()
        thr.join(timeout=2.0)
    if not lost.is_set():
        return True
    try:
        window.on_modal_lost()
    except Exception as exc:
        _log("MODAL_LOST tag=%s: úklid okna selhal %r" % (tag, exc), xbmc.LOGWARNING)
    return False


def _player_present() -> bool:
    """Existuje přehrávač (i pozastavený)? Chyba = ano — okno se přes možné video znovu neotevře (S24 D5)."""
    try:
        import richmovie_playback_dispatch as _dispatch
        return bool(_dispatch.player_present(on_error=True))
    except Exception:
        return True


def show_until_answered(make_window: Callable[[], Any], xml_file: str, *, tag: str,
                        reopen_max: Optional[int] = None, monitor: Optional[Any] = None) -> Tuple[Any, bool]:
    """Okno, bez jehož odpovědi se nedá pokračovat. `make_window()` vyrobí NOVÉ okno (Kodi zavřené okno znovu
    neotevře). Vrací `(okno, True)` = divák ho zavřel sám (výsledek čti z okna), `(okno, False)` = zavřelo ho Kodi
    i po `reopen_max` znovuotevřeních, Kodi končí, nebo existuje přehrávač → bez odpovědi."""
    import xbmc
    mon = monitor if monitor is not None else xbmc.Monitor()
    reopen_max = REOPEN_MAX if reopen_max is None else int(reopen_max)
    attempt = 0
    while True:
        win = make_window()
        if do_modal(win, xml_file, tag=tag, monitor=mon):
            if attempt:
                _log("MODAL_ANSWERED tag=%s po %d. znovuotevření" % (tag, attempt), xbmc.LOGINFO)
            return win, True
        if attempt >= reopen_max:
            _log("MODAL_GIVE_UP tag=%s — Kodi zavřelo okno %d× za sebou, bez odpovědi" % (tag, attempt + 1),
                 xbmc.LOGWARNING)
            return win, False
        if mon.waitForAbort(REOPEN_SETTLE_S):
            return win, False
        if _player_present():
            _log("MODAL_NO_REOPEN tag=%s — existuje přehrávač, okno se přes video znovu neotevře" % tag,
                 xbmc.LOGINFO)
            return win, False
        attempt += 1
        _log("MODAL_REOPEN tag=%s pokus=%d/%d" % (tag, attempt, reopen_max), xbmc.LOGINFO)
