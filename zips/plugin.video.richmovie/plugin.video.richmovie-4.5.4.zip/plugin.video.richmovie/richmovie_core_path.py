# -*- coding: utf-8 -*-
"""Přidá `resources/lib` do `sys.path` — balík `rm_core` (sdílené jádro hledání, G1 plánu RichMovie Go) tam leží.
Importuje se před prvním `import rm_core` z modulů doplňku; harness i služba tak nejsou závislé na pořadí importů.

`core_identity()` = JEDINÁ definice „kterým jádrem tento doplněk počítá“ (verze + SHA-256 bajtů balíku, `rm_core.core_sha`):
pojistka Trendů a přednačtených streamů (`richmovie_trendy.local_core`) i generace klíče mezipaměti hledání
(`richmovie_helpers.SearchCache.build_key`) — výsledek filtru z jiného jádra se nikdy nevydá za čerstvý (incident 16.11.2026:
Ebenezer z mezipaměti jádra 1.1.0 po nasazení 1.2.0 bez zvednutí verze doplňku)."""
from __future__ import annotations

import os
import sys
from typing import Any, Optional, Tuple

_LIB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib")
if os.path.isdir(_LIB_DIR) and _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

_UNSET = object()
_identity: Any = _UNSET


def core_identity() -> Optional[Tuple[str, str]]:
    """(verze, celý SHA-256) jádra TOHOTO doplňku; None = jádro se nenačetlo. Jednou za proces (čtení ~20 souborů) —
    plugin je nový interpret na každou invokaci, služba žije dny, ale soubory doplňku se mění jen s restartem Kodi."""
    global _identity
    if _identity is _UNSET:
        try:
            import rm_core
            _identity = (str(rm_core.RM_CORE_VERSION), str(rm_core.core_sha()))
        except Exception:
            _identity = None
    return _identity


def core_cache_tag() -> str:
    """Část klíče mezipaměti výsledků filtru: `c<verze>.<12 znaků SHA>`; jádro neznámé = `c0` (bez jádra se nehledá)."""
    ident = core_identity()
    if not ident:
        return "c0"
    return "c%s.%s" % (ident[0], ident[1][:12])
