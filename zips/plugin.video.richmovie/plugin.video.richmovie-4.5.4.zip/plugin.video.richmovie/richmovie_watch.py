# -*- coding: utf-8 -*-
"""„Hlídat“ v doplňku (F9, 4.5.3; Gate mig 0059 `POST /v1/tmdb/watch/*`, plán `Handoff/PLAN_hlidat_20261115.md`).

Divák u prázdného výsledku hledání streamů filmu klikne „🔔 Hlídat“ → Gate film každou noc ověří → jakmile je k dispozici,
hlavní menu ukáže nahoře „🔔 Nově k dispozici: …“ (klik = výpis streamů, řádek po otevření zmizí) a služba jednou ohlásí toast.
Stav „k dispozici“ počítá JEN Gate (z noční kontroly po začátku hlídání) — doplněk nic nepředpovídá ani neukládá na disk.

Paměť seznamu = vlastnosti okna Kodi (jen tento běh Kodi), jedna na účet a profil (`_prop_key`): menu ji čte BEZ sítě;
obnovuje ji služba (při startu, po změně účtu / profilu hned, jinak à 30 min — F16 V4) a každá akce Hlídat; když přibude
řádek „Nově k dispozici“, služba požádá o tichou obnovu hlavního menu frontou dispatcheru (jako D11). Chyba sítě / vadná
odpověď = nic se nemění (R2). Všechny operace Gate jsou idempotentní (přidání téhož filmu = „už hlídáš“, zrušení a označení
jen jednou), proto smí `gate_transport` přechodnou chybu zopakovat (prefix `/v1/tmdb/` v `_IDEMPOTENT_POST_PATHS`).

Python 3.8 (Kodi 21 Windows) — `from __future__ import annotations`, žádné `X | None` za běhu.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List, Optional, Sequence, Tuple

ENDPOINT_ADD = "/v1/tmdb/watch/add"
ENDPOINT_REMOVE = "/v1/tmdb/watch/remove"
ENDPOINT_LIST = "/v1/tmdb/watch/list"
ENDPOINT_MARK = "/v1/tmdb/watch/mark"

KIND_MOVIE = "movie"
STATE_WATCHING = "watching"
STATE_AVAILABLE = "available"
STATES = frozenset({STATE_WATCHING, STATE_AVAILABLE})
MARK_NOTIFIED = "notified"
MARK_SEEN = "seen"
MAX_IDS = 100
TITLE_MAX = 300
LIST_MAX = 200                             # strop přijatého seznamu (Gate dnes nejvýš 30 na profil)

REQUEST_TIMEOUT_S = 4.0
REQUEST_BUDGET_S = 6.0
REQUEST_MAX_ATTEMPTS = 2

PROP_LIST = "richmovie.watch.list"         # předpona vlastnosti okna s pamětí seznamu (+ otisk účtu a profilu)
PROP_NOTIFIED = "richmovie.watch.notified" # předpona: id filmů, o kterých už tento běh Kodi toast ukázal (F16 V8)
SERVICE_FIRST_S = 20.0                     # první kontrola služby po startu (přihlášení k Gate a výběr profilu)
SERVICE_EVERY_S = 30 * 60.0                # pak à 30 min (verdikty se mění v noci)
SERVICE_RETRY_S = 10 * 60.0                # po chybě
SERVICE_BUSY_RETRY_S = 5 * 60.0            # při přehrávání
SERVICE_NO_SUBJECT_S = 15.0                # profil ještě nevybraný / Host → zkusit brzy (bez sítě)

# výsledky akcí (SSOT textů v `action_message`)
RES_ADDED = "added"
RES_ALREADY = "already"
RES_LIMIT = "limit"
RES_DISABLED = "disabled"
RES_REMOVED = "removed"
RES_NOT_WATCHED = "not_watched"
RES_GUEST = "guest"
RES_NO_PROFILE = "no_profile"
RES_NO_IDENTITY = "no_identity"
RES_ERROR = "error"

HEADING = "Hlídat"

_CORE_KEYS = frozenset({"kind", "tmdb_id", "title", "year", "state", "notified", "seen"})   # tvar v paměti seznamu
_ITEM_KEYS = _CORE_KEYS | {"created_at", "expires_at"}                                       # povinná pole odpovědi Gate


class _NoIdentity(Exception):
    """Bez přihlášení (proof) se na Gate nic neposílá."""


# ── čisté rozhodnutí (harness 127) ───────────────────────────────────────────────────────────────────────────────────
def _pos_int(raw: Any) -> Optional[int]:
    return raw if type(raw) is int and raw > 0 else None


def parse_item(raw: Any) -> Optional[Dict[str, Any]]:
    """Položka odpovědi Gate (`watch.service.item_out`): VŠECHNA povinná pole v pořádku, pole navíc se ignorují (Gate smí
    přidat pole a starý doplněk dál funguje — cross-check Flash A2 N7); cokoli jiného = None."""
    if not isinstance(raw, dict) or not _ITEM_KEYS <= set(raw):
        return None
    if not isinstance(raw.get("created_at"), str) or not isinstance(raw.get("expires_at"), str):
        return None
    return _core_item(raw)


def _cached_item(raw: Any) -> Optional[Dict[str, Any]]:
    """Položka z paměti seznamu (přesně tvar `_CORE_KEYS`, jak ho zapsal `_store`)."""
    if not isinstance(raw, dict) or set(raw) != _CORE_KEYS:
        return None
    return _core_item(raw)


def _core_item(raw: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    tid, title, year = _pos_int(raw.get("tmdb_id")), raw.get("title"), raw.get("year")
    if raw.get("kind") != KIND_MOVIE or tid is None or not isinstance(title, str) or not title.strip():
        return None
    if year is not None and _pos_int(year) is None:
        return None
    if raw.get("state") not in STATES or type(raw.get("notified")) is not bool or type(raw.get("seen")) is not bool:
        return None
    return {"kind": KIND_MOVIE, "tmdb_id": tid, "title": title.strip()[:TITLE_MAX], "year": year,
            "state": raw["state"], "notified": raw["notified"], "seen": raw["seen"]}


def parse_list(status: Any, body: Any) -> Optional[List[Dict[str, Any]]]:
    """200 `{"status": "ok", "items": [...]}` s VŠEMI položkami v pořádku → seznam; jinak None (nic se nemění, R2)."""
    if type(status) is not int or status != 200 or not isinstance(body, dict) or body.get("status") != "ok":
        return None
    raw = body.get("items")
    if not isinstance(raw, list) or len(raw) > LIST_MAX:
        return None
    items = [parse_item(r) for r in raw]
    return None if any(i is None for i in items) else items  # type: ignore[return-value]


def _error_code(body: Any) -> str:
    err = body.get("error") if isinstance(body, dict) else None
    return str(err.get("code") or "") if isinstance(err, dict) else ""


def parse_add(status: Any, body: Any) -> Tuple[str, Optional[Dict[str, Any]], Optional[int]]:
    """(výsledek, položka, strop): 200 → added / already; 409 `watch_limit` → limit (+ strop); 409 `watch_disabled`."""
    if type(status) is int and status == 200 and isinstance(body, dict) and body.get("status") == "ok":
        item = parse_item(body.get("item"))
        if item is not None and type(body.get("added")) is bool:
            return (RES_ADDED if body["added"] else RES_ALREADY), item, None
        return RES_ERROR, None, None
    code = _error_code(body)
    if status == 409 and code == "watch_limit":
        cap = body["error"].get("max")
        return RES_LIMIT, None, (cap if type(cap) is int and cap > 0 else None)
    if status == 409 and code == "watch_disabled":
        return RES_DISABLED, None, None
    return RES_ERROR, None, None


def parse_flag(status: Any, body: Any, key: str) -> Optional[Any]:
    """Hodnota `key` z 200 `{"status": "ok", key: …}` (remove → bool, mark → int ≥ 0); jinak None."""
    if type(status) is not int or status != 200 or not isinstance(body, dict) or body.get("status") != "ok":
        return None
    val = body.get(key)
    if key == "removed":
        return val if type(val) is bool else None
    return val if type(val) is int and val >= 0 else None


def clean_title(raw: Any) -> str:
    if not isinstance(raw, str):
        return ""
    return "".join(ch for ch in raw if ch >= " " and ch != "\x7f").strip()[:TITLE_MAX].rstrip()


def year_of(det: Any) -> Optional[int]:
    """Rok z detailu TMDb (`release_date` RRRR-MM-DD); nečitelný = None."""
    try:
        text = str((det or {}).get("release_date") or "")[:4]
        year = int(text)
        return year if 1870 <= year <= 2100 else None
    except (TypeError, ValueError, AttributeError):
        return None


def _title_year(item: Dict[str, Any]) -> str:
    return "%s (%d)" % (item["title"], item["year"]) if item.get("year") else item["title"]


def offer_label(title: str, watching: bool) -> str:
    return ("🔔 Hlídám „%s“ – zrušit" if watching else "🔔 Hlídat „%s“ – dám vědět, až půjde pustit") % title


def offer_plot(watching: bool) -> str:
    if watching:
        return "Film hlídáš. Klikni, když už ho hlídat nechceš."
    return ("Každou noc zkusím, jestli už jde pustit. Jakmile půjde, najdeš ho nahoře v hlavním menu. "
            "Hlídání skončí samo po půl roce.")


def new_rows(items: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Řádky „Nově k dispozici“ do hlavního menu: k dispozici a ještě neotevřené (pořadí Gate = nejnovější hlídání první)."""
    return [i for i in items if i["state"] == STATE_AVAILABLE and not i["seen"]]


def new_row_label(item: Dict[str, Any]) -> str:
    return "🔔 Nově k dispozici: %s" % _title_year(item)


def to_notify(items: Sequence[Dict[str, Any]], already: Sequence[int] = ()) -> List[Dict[str, Any]]:
    """Filmy pro jednorázový toast služby: k dispozici, dosud neohlášené (Gate ani tento běh Kodi) a neotevřené."""
    done = set(already)
    return [i for i in items if i["state"] == STATE_AVAILABLE and not i["notified"] and not i["seen"]
            and i["tmdb_id"] not in done]


def toast_text(items: Sequence[Dict[str, Any]]) -> str:
    if not items:
        return ""
    first = _title_year(items[0])
    rest = len(items) - 1
    if rest <= 0:
        return "Nově k dispozici: %s" % first
    return "Nově k dispozici: %s a %d %s" % (first, rest, "další" if rest < 5 else "dalších")


def list_label(item: Dict[str, Any]) -> str:
    """Řádek v Nástroje → Hlídané filmy."""
    if item["seen"]:
        return "%s  [COLOR FF9E9E9E]✓ otevřeno[/COLOR]" % _title_year(item)
    if item["state"] == STATE_AVAILABLE:
        return "%s  [COLOR FF7CD992]✓ k dispozici[/COLOR]" % _title_year(item)
    return "%s  [COLOR FF9E9E9E]hlídám[/COLOR]" % _title_year(item)


def action_message(result: str, title: str = "", cap: Optional[int] = None) -> str:
    """Věta toastu po akci (SSOT textů)."""
    t = title or "film"
    return {
        RES_ADDED: "Hlídám „%s“. Až půjde pustit, najdeš ho nahoře v menu." % t,
        RES_ALREADY: "„%s“ už hlídáš." % t,
        RES_LIMIT: ("Hlídáš už %d filmů. Nějaký zruš v Nástrojích → Hlídané filmy." % cap if cap
                    else "Hlídáš už moc filmů. Nějaký zruš v Nástrojích → Hlídané filmy."),
        RES_DISABLED: "Hlídání je teď vypnuté.",
        RES_REMOVED: "Hlídání „%s“ zrušeno." % t,
        RES_NOT_WATCHED: "„%s“ už nehlídáš." % t,
        RES_GUEST: "Host filmy hlídat nemůže — přepni na svůj profil.",
        RES_NO_PROFILE: "Nejdřív vyber, kdo se dívá.",
        RES_NO_IDENTITY: "Nejdřív se přihlas k Webshare.",
    }.get(result, "Hlídání se teď nepodařilo. Zkus to za chvíli.")


def is_watching(items: Optional[Sequence[Dict[str, Any]]], tmdb_id: Any) -> bool:
    """Hlídá divák film? Otevřené hlídání (`seen`) už Gate nehlídá — nabídka pak správně říká „Hlídat“ (F16 V2)."""
    tid = _pos_int(tmdb_id)
    return bool(items) and tid is not None and any(i["tmdb_id"] == tid and not i["seen"] for i in items)  # type: ignore[union-attr]


def is_seen(items: Optional[Sequence[Dict[str, Any]]], tmdb_id: Any) -> bool:
    tid = _pos_int(tmdb_id)
    return bool(items) and tid is not None and any(i["tmdb_id"] == tid and i["seen"] for i in items)  # type: ignore[union-attr]


def apply_mark(items: Sequence[Dict[str, Any]], what: str, ids: Sequence[int]) -> List[Dict[str, Any]]:
    """Paměť po úspěšném označení (bez dalšího dotazu): `seen` = i upozorněno."""
    wanted = set(int(i) for i in ids)
    out = []
    for it in items:
        it = dict(it)
        if it["tmdb_id"] in wanted and it["state"] == STATE_AVAILABLE:
            it["notified"] = True
            if what == MARK_SEEN:
                it["seen"] = True
        out.append(it)
    return out


def without(items: Sequence[Dict[str, Any]], tmdb_id: int) -> List[Dict[str, Any]]:
    """Paměť po zrušení hlídání (Gate potvrdil) — i když následná obnova selže (cross-check Flash A2 N8)."""
    return [dict(i) for i in items if i["tmdb_id"] != tmdb_id]


def row_ids(items: Optional[Sequence[Dict[str, Any]]]) -> List[int]:
    return [i["tmdb_id"] for i in new_rows(items or [])]


# ── subjekt (účet / profil) ──────────────────────────────────────────────────────────────────────────────────────────
def subject() -> Tuple[str, Optional[int]]:
    """("ok", profile_id | None) / ("guest", None) / ("no_profile", None). Profil = SSOT `richmovie_profile`; nečitelný
    stav = účet (Gate multi účet bez profilu odmítne 400 a nic se nezapíše)."""
    try:
        import richmovie_profile as _rp
        if _rp.is_guest():
            return RES_GUEST, None
        if _rp.is_multi() and not _rp.has_active_profile():
            return RES_NO_PROFILE, None
        return "ok", _rp.telemetry_profile_id()
    except Exception:
        return "ok", None


def scope(profile_id: Optional[int]) -> str:
    """„účet|profil“ — paměť i toasty patří jen tomuto subjektu; bez přihlášení = ""."""
    try:
        from richmovie_gate_transport import get_identity
        user = (get_identity()[0] or "").strip().lower()
    except Exception:
        user = ""
    return "%s|%s" % (user, int(profile_id) if profile_id else 0) if user else ""


def current_scope() -> str:
    who, pid = subject()
    return scope(pid) if who == "ok" else ""


def _prop_key(prefix: str, scope_key: str) -> str:
    return "%s.%s" % (prefix, hashlib.sha1(scope_key.encode("utf-8")).hexdigest()[:12])


# ── paměť seznamu (vlastnosti okna, bez disku — R2) ──────────────────────────────────────────────────────────────────
def cached(profile_id: Optional[int] = None) -> Optional[List[Dict[str, Any]]]:
    """Seznam z paměti pro TENTO účet a profil, nebo None (nic / jiný subjekt / vadný zápis)."""
    sc = scope(profile_id)
    if not sc:
        return None
    try:
        import richmovie_winprops as _wp
        raw = json.loads(_wp.get_prop(_prop_key(PROP_LIST, sc)) or "null")
    except Exception:
        return None
    if not isinstance(raw, dict) or raw.get("scope") != sc or not isinstance(raw.get("items"), list):
        return None
    items = [_cached_item(r) for r in raw["items"]]
    return None if any(i is None for i in items) else items  # type: ignore[return-value]


def _store(profile_id: Optional[int], items: Sequence[Dict[str, Any]]) -> None:
    sc = scope(profile_id)
    if not sc:
        return
    try:
        import richmovie_winprops as _wp
        _wp.set_prop(_prop_key(PROP_LIST, sc), json.dumps({"scope": sc, "items": list(items)}, ensure_ascii=False))
    except Exception:
        pass


def _notified_here(profile_id: Optional[int]) -> List[int]:
    sc = scope(profile_id)
    try:
        import richmovie_winprops as _wp
        raw = json.loads(_wp.get_prop(_prop_key(PROP_NOTIFIED, sc)) or "[]") if sc else []
    except Exception:
        return []
    return [i for i in raw if type(i) is int] if isinstance(raw, list) else []


def _remember_notified(profile_id: Optional[int], ids: Sequence[int]) -> None:
    sc = scope(profile_id)
    if not sc:
        return
    try:
        import richmovie_winprops as _wp
        merged = sorted(set(_notified_here(profile_id)) | set(int(i) for i in ids))[-500:]
        _wp.set_prop(_prop_key(PROP_NOTIFIED, sc), json.dumps(merged))
    except Exception:
        pass


# ── Gate ─────────────────────────────────────────────────────────────────────────────────────────────────────────────
def _post(endpoint: str, extra: Dict[str, Any], profile_id: Optional[int]) -> Tuple[Any, Any]:
    """POST s identitou (SSOT `identity_body`) a profilem. Bez identity nic neposílá (`_NoIdentity`). Výjimky
    transportu propadnou volajícímu (ten je převede na `RES_ERROR`)."""
    import richmovie_gate_transport as _gt
    import richmovie_http as _http
    from richmovie_sync_queue import identity_body
    body = identity_body(dict(extra))
    if not body.get("ws_proof"):
        raise _NoIdentity()
    if profile_id is not None:
        body["profile_id"] = int(profile_id)
    body["has_fastshare"] = _device_has_fastshare()
    profile = _http.profile_foreground().replace(budget_s=REQUEST_BUDGET_S, timeout_s=REQUEST_TIMEOUT_S,
                                                 max_attempts=REQUEST_MAX_ATTEMPTS)
    return _gt.post_json(endpoint, body, profile=profile)


def _device_has_fastshare() -> bool:
    try:
        import richmovie_trendy
        return richmovie_trendy.device_has_fastshare()
    except Exception:
        return True


def refresh() -> Optional[List[Dict[str, Any]]]:
    """Seznam z Gate do paměti; None = nepovedlo se (paměť beze změny)."""
    who, pid = subject()
    if who != "ok":
        return None
    try:
        status, body = _post(ENDPOINT_LIST, {}, pid)
    except Exception:
        return None
    items = parse_list(status, body)
    if items is not None:
        _store(pid, items)
    return items


def add(tmdb_id: Any, title: Any, year: Any) -> Tuple[str, Optional[int]]:
    """(výsledek, strop) — přidání hlídání; při úspěchu obnoví paměť seznamu."""
    who, pid = subject()
    if who != "ok":
        return who, None
    tid, name = _pos_int(tmdb_id), clean_title(title)
    if tid is None or not name:
        return RES_ERROR, None
    try:
        status, body = _post(ENDPOINT_ADD, {"kind": KIND_MOVIE, "tmdb_id": tid, "title": name,
                                            "year": year if _pos_int(year) else None}, pid)
    except _NoIdentity:
        return RES_NO_IDENTITY, None
    except Exception:
        return RES_ERROR, None
    result, _item, cap = parse_add(status, body)
    if result in (RES_ADDED, RES_ALREADY):
        refresh()
    return result, cap


def remove(tmdb_id: Any) -> str:
    who, pid = subject()
    if who != "ok":
        return who
    tid = _pos_int(tmdb_id)
    if tid is None:
        return RES_ERROR
    try:
        status, body = _post(ENDPOINT_REMOVE, {"kind": KIND_MOVIE, "tmdb_id": tid}, pid)
    except _NoIdentity:
        return RES_NO_IDENTITY
    except Exception:
        return RES_ERROR
    removed = parse_flag(status, body, "removed")
    if removed is None:
        return RES_ERROR
    items = cached(pid)
    if items is not None:
        _store(pid, without(items, tid))   # Gate potvrdil: paměť hned, i když obnova níž selže
    refresh()
    return RES_REMOVED if removed else RES_NOT_WATCHED


def mark(what: str, tmdb_ids: Sequence[Any]) -> Optional[int]:
    """Označit upozornění / otevření (Gate označí jen dostupné a jen jednou); None = nepovedlo se."""
    who, pid = subject()
    ids = [t for t in (_pos_int(x) for x in tmdb_ids) if t is not None][:MAX_IDS]
    if who != "ok" or not ids or what not in (MARK_NOTIFIED, MARK_SEEN):
        return None
    try:
        status, body = _post(ENDPOINT_MARK, {"what": what, "kind": KIND_MOVIE, "tmdb_ids": ids}, pid)
    except Exception:
        return None
    marked = parse_flag(status, body, "marked")
    if marked is not None:
        items = cached(pid)
        if items is not None:
            _store(pid, apply_mark(items, what, ids))
    return marked


def open_title(tmdb_id: Any) -> Optional[int]:
    """Klik na „Nově k dispozici“: označit otevřené JEN poprvé (paměť už `seen` = bez dotazu — Zpět z přehrávání a obnova
    výpisu staví tentýž výpis znovu, F16 V7). Vrací počet označených / None (nic se neposlalo nebo se nepovedlo)."""
    who, pid = subject()
    if who != "ok" or is_seen(cached(pid), tmdb_id):
        return None
    return mark(MARK_SEEN, [tmdb_id])


def menu_rows() -> List[Dict[str, Any]]:
    """Řádky „Nově k dispozici“ z paměti (hlavní menu, BEZ sítě); nic v paměti = žádné řádky."""
    who, pid = subject()
    if who != "ok":
        return []
    return new_rows(cached(pid) or [])


def _request_menu_refresh() -> None:
    """Tichá obnova hlavního menu frontou dispatcheru (jako D11 — nikdy přímý `Container.Refresh`, lint 87)."""
    try:
        import richmovie_playback_dispatch as _d
        if _d.request_refresh(_d.ROOT_LISTING, "watch_new", silent=True):
            _d.flush_refresh_queue()
    except Exception:
        pass


def service_check(player_busy: bool) -> float:
    """Jedna kontrola služby: obnovit seznam, jednou ohlásit nově dostupné filmy a dát menu vědět, že přibyl řádek.
    Vrací za kolik sekund znovu."""
    if player_busy:
        return SERVICE_BUSY_RETRY_S            # nic nepřekrývat přehrávání; seznam počká
    who, pid = subject()
    if who != "ok":
        return SERVICE_NO_SUBJECT_S            # profil se teprve vybírá → brzy znovu (bez sítě)
    before = row_ids(cached(pid))
    items = refresh()
    if items is None:
        return SERVICE_RETRY_S
    if row_ids(items) != before and new_rows(items):
        _request_menu_refresh()
    fresh = to_notify(items, _notified_here(pid))
    if fresh:
        try:
            import richmovie_feedback as _fb
            _fb.info("🔔 " + toast_text(fresh), heading=HEADING)
        except Exception:
            return SERVICE_RETRY_S
        _remember_notified(pid, [i["tmdb_id"] for i in fresh])   # i když označení na Gate selže: tento běh už ne (V8)
        mark(MARK_NOTIFIED, [i["tmdb_id"] for i in fresh])
    return SERVICE_EVERY_S
